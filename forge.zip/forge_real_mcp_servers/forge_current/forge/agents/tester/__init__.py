__all__ = ["TesterAgent"]
def __getattr__(name):
    if name == "TesterAgent":
        from agents.tester.agent import TesterAgent; return TesterAgent
    raise AttributeError(f"module 'agents.tester' has no attribute {name!r}")
