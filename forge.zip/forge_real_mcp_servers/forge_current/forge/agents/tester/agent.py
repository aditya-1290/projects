"""
agents/tester/agent.py
-----------------------
Tester Agent — analyses codebases and generates test suites.

Responsibilities:
- Receive write_tests / run_tests tasks from Orchestrator
- Analyse what exists and what needs testing
- Generate unit, integration, and E2E tests (based on depth)
- Run tests via Terminal MCP and report results
- Identify coverage gaps and suggest edge cases
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Callable, Optional

from agents.base_agent import BaseAgent
from shared.constants import CHANNEL_AGENT_EVENTS, QUEUE_TESTER
from shared.types import (
    AgentEvent, AgentMessage, AgentName, TaskType, TestDepth,
)


_SYSTEM_PROMPT = """You are the Tester Agent for Forge, an autonomous programming assistant.
Your role is to write comprehensive, meaningful tests.

Rules:
1. Write tests that actually verify behaviour — not just coverage padding
2. Include: happy path, edge cases, error cases, boundary values
3. Use the appropriate testing library for the language/framework
4. Each test must have a clear, descriptive name explaining what it tests
5. Tests must be independent — no shared state between test functions
6. Mock external dependencies (DB, HTTP, filesystem) appropriately
7. Output raw test code only — no explanations, no markdown fences

For Python: use pytest with fixtures. For JS/TS: use Jest or Vitest.
For Go: use the standard testing package. For Rust: use #[cfg(test)].
"""


class TesterAgent(BaseAgent):
    """
    Generates and runs test suites for Forge projects.
    """

    def __init__(
        self,
        response_callback: Optional[Callable[[str, str], None]] = None,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self._response_callback = response_callback

    @property
    def name(self) -> AgentName:
        return AgentName.TESTER

    @property
    def queue(self) -> str:
        return QUEUE_TESTER

    # ------------------------------------------------------------------
    # handle_message
    # ------------------------------------------------------------------

    async def handle_message(self, message: AgentMessage) -> None:
        task = message.task_type

        if task == TaskType.WRITE_TESTS:
            await self._write_tests(message)
        elif task == TaskType.RUN_TESTS:
            await self._run_tests(message)
        else:
            self.logger.warning(f"Tester received unexpected task: {task.value}")

    # ------------------------------------------------------------------
    # Write tests
    # ------------------------------------------------------------------

    async def _write_tests(self, message: AgentMessage) -> None:
        session_id  = message.session_id
        payload     = message.payload
        target_file = payload.get("target_file", "")
        target_code = payload.get("target_code", "")
        language    = payload.get("language", "python")
        depth       = TestDepth(payload.get("test_depth", TestDepth.UNIT.value))
        framework   = payload.get("framework", "")
        project_path = payload.get("project_path", "")

        self.logger.info(
            f"Writing tests for {target_file} "
            f"(depth={depth.value}, lang={language}) "
            f"session={session_id[:8]}"
        )
        self._reply(session_id, f"Analysing {target_file} for test generation...")

        # Determine test file path
        test_file_path = self._derive_test_path(target_file, language)

        # Build prompt based on depth
        messages = self._build_test_prompt(
            target_file, target_code, language, depth, framework
        )

        # Generate tests via LLM
        try:
            test_code = await self.chat(messages, stream=False)
        except Exception as e:
            self.logger.error(f"Test generation failed: {e}")
            self._reply(session_id, f"Test generation failed: {e}")
            return

        # Emit result for the Orchestrator to route to Coder/Patcher for writing
        await self._bus.broadcast(
            CHANNEL_AGENT_EVENTS,
            AgentEvent(
                event_type = "tests_generated",
                source     = self.name,
                session_id = session_id,
                data       = {
                    "session_id":     session_id,
                    "test_file_path": test_file_path,
                    "test_code":      test_code,
                    "target_file":    target_file,
                    "language":       language,
                    "depth":          depth.value,
                },
            ),
        )

        self._reply(
            session_id,
            f"Tests generated for {target_file} → {test_file_path}\n"
            f"Run them with: forge test"
        )

    # ------------------------------------------------------------------
    # Run tests
    # ------------------------------------------------------------------

    async def _run_tests(self, message: AgentMessage) -> None:
        session_id   = message.session_id
        payload      = message.payload
        project_path = payload.get("project_path", "")
        framework    = payload.get("framework", "auto")
        test_path    = payload.get("test_path", ".")
        language     = payload.get("language", "python")

        self.logger.info(
            f"Running tests for session {session_id[:8]} "
            f"framework={framework}"
        )
        self._reply(session_id, "Running test suite...")

        try:
            from mcp.terminal.server import TerminalServer
            terminal = TerminalServer(
                project_root = project_path,
                session_id   = session_id,
            )
            result = terminal.run_tests(
                framework = framework,
                path      = test_path,
            )
        except Exception as e:
            self.logger.error(f"Test run failed: {e}")
            self._reply(session_id, f"Test run error: {e}")
            return

        # Parse and emit results
        summary = self._parse_test_output(result.stdout + result.stderr, framework)

        await self._bus.broadcast(
            CHANNEL_AGENT_EVENTS,
            AgentEvent(
                event_type = "tests_complete",
                source     = self.name,
                session_id = session_id,
                data       = {
                    "session_id": session_id,
                    "success":    result.success,
                    "exit_code":  result.exit_code,
                    "summary":    summary,
                    "output":     result.output[:3000],  # cap for event
                    "duration_ms": result.duration_ms,
                },
            ),
        )

        status = "✓ All tests passed" if result.success else "✗ Some tests failed"
        self._reply(
            session_id,
            f"{status}\n\n{summary}"
        )

    # ------------------------------------------------------------------
    # Prompt building
    # ------------------------------------------------------------------

    def _build_test_prompt(
        self,
        target_file:  str,
        target_code:  str,
        language:     str,
        depth:        TestDepth,
        framework:    str,
    ) -> list[dict[str, Any]]:
        """Build LLM messages for test generation."""
        depth_instructions = {
            TestDepth.UNIT: "Write unit tests only. Test each function/method in isolation.",
            TestDepth.INTEGRATION: (
                "Write unit tests AND integration tests. "
                "Integration tests may use a test database or real HTTP calls."
            ),
            TestDepth.FULL: (
                "Write unit tests, integration tests, and E2E tests. "
                "Cover the full stack from API to database."
            ),
            TestDepth.AUTO: (
                "Write appropriate tests based on the code complexity. "
                "Start with unit tests; add integration tests for API endpoints."
            ),
            TestDepth.CUSTOM: "Write comprehensive tests covering all code paths.",
        }

        framework_hint = f"Use {framework}." if framework else ""

        user_content = (
            f"Write tests for this file: {target_file}\n"
            f"Language: {language}\n"
            f"Test depth: {depth_instructions.get(depth, '')}\n"
            f"{framework_hint}\n\n"
            f"Source code to test:\n\n{target_code}\n\n"
            f"Write the complete test file now:"
        )

        return [
            {"role": "system", "content": _SYSTEM_PROMPT},
            {"role": "user",   "content": user_content},
        ]

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _derive_test_path(self, source_file: str, language: str) -> str:
        """Derive the test file path from the source file path."""
        p = Path(source_file)

        if language == "python":
            # src/auth/login.py → tests/test_auth_login.py
            parts = [p.stem] + [part for part in p.parent.parts if part not in ("src", ".")]
            name = "test_" + "_".join(reversed(parts)) + ".py"
            return str(Path("tests") / name)

        elif language in ("javascript", "typescript"):
            # src/auth/login.ts → src/auth/login.test.ts
            return str(p.parent / f"{p.stem}.test{p.suffix}")

        elif language == "go":
            # auth/login.go → auth/login_test.go
            return str(p.parent / f"{p.stem}_test.go")

        elif language == "rust":
            # src/auth.rs → src/auth.rs (tests are inline in Rust)
            return source_file

        else:
            return str(Path("tests") / f"test_{p.stem}{p.suffix}")

    def _parse_test_output(self, output: str, framework: str) -> str:
        """Extract a human-readable summary from raw test output."""
        lines = output.strip().splitlines()

        if framework in ("pytest", "auto"):
            # Look for the pytest summary line: "X passed, Y failed in Zs"
            for line in reversed(lines):
                if "passed" in line or "failed" in line or "error" in line:
                    return line.strip()

        elif framework in ("jest", "vitest"):
            # Look for "Tests: X passed, Y failed"
            for line in reversed(lines):
                if "Tests:" in line or "Test Suites:" in line:
                    return line.strip()

        elif framework == "go":
            for line in reversed(lines):
                if line.startswith("ok") or line.startswith("FAIL"):
                    return line.strip()

        # Fallback: last non-empty line
        for line in reversed(lines):
            if line.strip():
                return line.strip()

        return "Tests complete."

    def _reply(self, session_id: str, text: str) -> None:
        self.logger.debug(f"Tester → {session_id[:8]}: {text[:60]}")
        if self._response_callback:
            try:
                self._response_callback(session_id, text)
            except Exception as e:
                self.logger.warning(f"Response callback error: {e}")
