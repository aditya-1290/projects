"""
agents/patcher/agent.py
------------------------
Patcher Agent — applies targeted code patches to existing files.

Responsibilities:
- Receive apply_patch tasks from Orchestrator
- Generate a diff preview before writing
- Always check Permission Gateway before patching
- Show diff to user via CLI and wait for decision
- Apply patch via Filesystem MCP
- Log all actions for rollback (Phase 5)
"""

from __future__ import annotations

from typing import Any, Callable, Optional

from agents.base_agent import BaseAgent
from shared.constants import CHANNEL_AGENT_EVENTS, QUEUE_PATCHER
from shared.types import (
    AgentEvent, AgentMessage, AgentName, TaskType,
)


_SYSTEM_PROMPT = """You are the Patcher Agent for Forge.
Your role is to make precise, targeted changes to existing code files.

Rules:
1. Make ONLY the change requested — do not refactor or improve other code
2. Preserve existing style, indentation, and conventions
3. When asked to patch a function, output the complete new version of that function only
4. When asked for a full file patch, output the complete new file
5. Never add unrequested changes
6. Output raw code only — no explanations, no markdown

If given an OLD block and asked to replace it, output ONLY the NEW block.
"""


class PatcherAgent(BaseAgent):
    """
    Applies targeted patches to existing code files.
    Always permission-gated, always shows diff before writing.
    """

    def __init__(
        self,
        response_callback: Optional[Callable[[str, str], None]] = None,
        permission_check:  Optional[Callable[[str, str, str], bool]] = None,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self._response_callback = response_callback
        self._permission_check  = permission_check

    @property
    def name(self) -> AgentName:
        return AgentName.PATCHER

    @property
    def queue(self) -> str:
        return QUEUE_PATCHER

    # ------------------------------------------------------------------
    # handle_message
    # ------------------------------------------------------------------

    async def handle_message(self, message: AgentMessage) -> None:
        if message.task_type == TaskType.APPLY_PATCH:
            await self._apply_patch(message)
        else:
            self.logger.warning(f"Patcher received unexpected task: {message.task_type.value}")

    # ------------------------------------------------------------------
    # Core: apply a patch
    # ------------------------------------------------------------------

    async def _apply_patch(self, message: AgentMessage) -> None:
        session_id   = message.session_id
        payload      = message.payload

        file_path    = payload.get("file_path", "")
        instructions = payload.get("instructions", "")
        old_block    = payload.get("old_block", "")
        new_block    = payload.get("new_block", "")
        project_path = payload.get("project_path", "")
        mode         = payload.get("mode", "replace_block")  # replace_block | full_rewrite | llm_generate

        self.logger.info(
            f"Patching {file_path} mode={mode} session={session_id[:8]}"
        )

        # Validate inputs
        if not file_path:
            self.logger.error("Patch task missing file_path")
            return

        # If no new_block provided, generate it via LLM
        if not new_block and instructions:
            new_block = await self._generate_patch(
                file_path, old_block, instructions, project_path
            )
            if not new_block:
                self._reply(session_id, f"Failed to generate patch for {file_path}")
                return

        # Generate diff for permission prompt
        diff = self._make_diff(file_path, old_block, new_block, project_path)

        # Permission check
        if self._permission_check:
            permitted = self._permission_check(session_id, file_path, diff)
            if not permitted:
                self.logger.info(f"Patch denied for {file_path}")
                await self._bus.broadcast(
                    CHANNEL_AGENT_EVENTS,
                    AgentEvent(
                        event_type = "patch_denied",
                        source     = self.name,
                        session_id = session_id,
                        data       = {"session_id": session_id, "file_path": file_path},
                    ),
                )
                return

        # Apply the patch via Filesystem MCP
        try:
            from mcp.filesystem.server import FilesystemServer
            fs = FilesystemServer(
                project_root     = project_path,
                session_id       = session_id,
                permission_check = None,  # already checked above
            )

            if mode == "replace_block" and old_block:
                new_content = fs.patch_file(file_path, old_block, new_block)
            else:
                # Full file rewrite
                new_content = new_block
                fs.write_file(file_path, new_content, skip_permission=True)

        except Exception as e:
            self.logger.error(f"Patch application failed: {e}")
            self._reply(session_id, f"Patch failed for {file_path}: {e}")
            await self._emit_event("patch_error", {
                "session_id": session_id,
                "file_path":  file_path,
                "error":      str(e),
            })
            return

        # Success
        self.logger.info(f"Patched: {file_path}")
        self._reply(session_id, f"✓ Patched {file_path}")

        await self._bus.broadcast(
            CHANNEL_AGENT_EVENTS,
            AgentEvent(
                event_type = "patch_applied",
                source     = self.name,
                session_id = session_id,
                data       = {
                    "session_id": session_id,
                    "file_path":  file_path,
                    "diff":       diff,
                },
            ),
        )

    # ------------------------------------------------------------------
    # LLM patch generation
    # ------------------------------------------------------------------

    async def _generate_patch(
        self,
        file_path:    str,
        old_block:    str,
        instructions: str,
        project_path: str,
    ) -> str:
        """Use the LLM to generate the replacement block."""
        user_content = (
            f"File: {file_path}\n"
            f"Instructions: {instructions}\n\n"
        )
        if old_block:
            user_content += (
                f"Replace this block:\n\n{old_block}\n\n"
                f"Write the replacement block now:"
            )
        else:
            user_content += "Write the change now:"

        messages = [
            {"role": "system", "content": _SYSTEM_PROMPT},
            {"role": "user",   "content": user_content},
        ]

        try:
            return await self.chat(messages, stream=False)
        except Exception as e:
            self.logger.error(f"LLM patch generation failed: {e}")
            return ""

    # ------------------------------------------------------------------
    # Diff generation
    # ------------------------------------------------------------------

    def _make_diff(
        self,
        file_path:    str,
        old_block:    str,
        new_block:    str,
        project_path: str,
    ) -> str:
        """Generate a readable unified diff string."""
        import difflib

        old_lines = old_block.splitlines(keepends=True) if old_block else []
        new_lines = new_block.splitlines(keepends=True) if new_block else []

        diff = difflib.unified_diff(
            old_lines,
            new_lines,
            fromfile=f"a/{file_path}",
            tofile=f"b/{file_path}",
            n=3,
        )
        return "".join(diff)

    # ------------------------------------------------------------------
    # Reply helper
    # ------------------------------------------------------------------

    def _reply(self, session_id: str, text: str) -> None:
        self.logger.debug(f"Patcher → {session_id[:8]}: {text[:60]}")
        if self._response_callback:
            try:
                self._response_callback(session_id, text)
            except Exception as e:
                self.logger.warning(f"Response callback error: {e}")
