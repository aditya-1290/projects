__all__ = ["MemoryManagerAgent"]

from forge_real_mcp_servers.forge_current.forge.agents.memory_manager.agent import MemoryManagerAgent


def __getattr__(name):
    if name == "MemoryManagerAgent":
        from agents.memory_manager.agent import MemoryManagerAgent; return MemoryManagerAgent
    raise AttributeError(f"module 'agents.memory_manager' has no attribute {name!r}")
