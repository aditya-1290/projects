__all__ = ["ReviewerAgent"]
def __getattr__(name):
    if name == "ReviewerAgent":
        from agents.reviewer.agent import ReviewerAgent; return ReviewerAgent
    raise AttributeError(f"module 'agents.reviewer' has no attribute {name!r}")
