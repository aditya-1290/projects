# from typing import Optional, List
from rich.panel import Panel
from rich.syntax import Syntax
from rich.console import Console
from rich.prompt import Prompt

console = Console()

class PermissionManager:
    def __init__(self):
        self.global_allow = False       # True = write/patch anything without asking
        self.allowed_files: set = set() # specific file paths allowed

    def has_permission(self, action_type: str, path: str) -> bool:
        if self.global_allow:
            return True
        if path in self.allowed_files:
            return True
        return False

    def ask_for_permission(self, action_type: str, path: str, content: str) -> bool:
        """
        Displays a diff (for patch) or full file (for write) and asks the user.
        Returns True if allowed, False otherwise.
        """
        if action_type == "patch":
            # Assume content is a unified diff
            syntax = Syntax(content, "diff", theme="monokai", line_numbers=True)
        else:
            # Write action: detect language by extension
            lang = _guess_language(path)
            syntax = Syntax(content, lang, theme="monokai", line_numbers=True)

        console.print(Panel(syntax, title=f"Proposed {action_type.upper()} for {path}"))
        console.print("[P] Patch now   [G] Generate only   [A] Allow all this session   [S] Skip")
        choice = input("Choice [P/G/A/S]: ").strip().upper()

        if choice == "P":
            return True
        elif choice == "G":
            console.print("[yellow]Code generated but not applied.[/yellow]")
            return False
        elif choice == "A":
            self.global_allow = True
            console.print("[green]All future writes/patches will be applied automatically this session.[/green]")
            return True
        elif choice == "S":
            console.print("[dim]Skipping this change.[/dim]")
            return False
        else:
            console.print("[red]Invalid choice. Skipping.[/red]")
            return False


def _guess_language(path: str) -> str:
    ext = path.rsplit(".", 1)[-1] if "." in path else ""
    mapping = {
        "py": "python",
        "js": "javascript",
        "ts": "typescript",
        "jsx": "javascript",
        "tsx": "typescript",
        "go": "go",
        "rs": "rust",
        "java": "java",
        "c": "c",
        "cpp": "cpp",
        "h": "c",
        "hpp": "cpp",
        "sh": "bash",
        "yaml": "yaml",
        "yml": "yaml",
        "json": "json",
        "html": "html",
        "css": "css",
        "md": "markdown",
        "sql": "sql",
        "dockerfile": "dockerfile",
    }
    return mapping.get(ext, "text")