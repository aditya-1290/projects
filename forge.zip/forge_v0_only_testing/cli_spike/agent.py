import re
import json
from typing import List, Dict, Any, Generator, Tuple, Optional
from openai import OpenAI

# ---------- Tag parsing state machine ----------
class ActionType:
    WRITE = "write"
    PATCH = "patch"
    READ = "read"

class Action:
    def __init__(self, action_type: str, path: str, content: str):
        self.type = action_type
        self.path = path
        self.content = content

    def __repr__(self):
        return f"Action(type={self.type}, path={self.path})"


class TagStreamParser:
    """
    Parses the model's output stream in real time, detecting
    <write path="...">...</write> and <patch path="...">...</patch> blocks.
    """
    def __init__(self):
        self.buffer = ""
        self.in_tag = False
        self.tag_type = None
        self.tag_path = None
        self.collected_text = []
        self.text_so_far = []      # for status display (non-tag content)
        self.actions = []
        self.current_tag_content = []
        self.start_tag_pattern = re.compile(
            r'<(write|patch)\s+path="([^"]*)"\s*>'
        )
        self.end_tag_pattern = re.compile(
            r'</(write|patch)\s*>'
        )

    def feed(self, chunk: str) -> Generator[str, None, None]:
        """
        Yields plain text meant for display (status view) as it processes chunks.
        Once a full action is detected, it is appended to self.actions.
        """
        for ch in chunk:
            self.buffer += ch
            if not self.in_tag:
                # Check if a start tag begins at the beginning of buffer
                m = self.start_tag_pattern.search(self.buffer)
                if m:
                    # Output any text before the tag
                    before = self.buffer[:m.start()]
                    if before:
                        yield before
                    # Set tag state
                    self.in_tag = True
                    self.tag_type = m.group(1)
                    self.tag_path = m.group(2)
                    self.current_tag_content = []
                    # Keep the part after the start tag in buffer for next iteration
                    self.buffer = self.buffer[m.end():]
                else:
                    # No tag started; accumulate but may need to emit partial text carefully.
                    # To avoid emitting a partial tag, we need to hold back characters
                    # that could be the start of a tag. Simple approach: emit if no '<' near end.
                    # For a spike, we'll emit everything except the last 5 chars if they contain '<'
                    if len(self.buffer) > 10:
                        # Emit all but a few chars that might form '<write'
                        safe_end = 0
                        for i in range(len(self.buffer)-1, -1, -1):
                            if self.buffer[i] == '<':
                                safe_end = i
                                break
                        if safe_end == 0:
                            safe_end = len(self.buffer)
                        yield self.buffer[:safe_end]
                        self.buffer = self.buffer[safe_end:]
            else:
                # Inside a tag, look for end tag
                m = self.end_tag_pattern.search(self.buffer)
                if m:
                    # Capture tag content before end tag
                    content = self.buffer[:m.start()]
                    self.current_tag_content.append(content)
                    # Full action detected
                    full_content = "".join(self.current_tag_content)
                    self.actions.append(
                        Action(self.tag_type, self.tag_path, full_content)
                    )
                    # Reset state
                    self.buffer = self.buffer[m.end():]
                    self.in_tag = False
                    self.tag_type = None
                    self.tag_path = None
                    self.current_tag_content = []
                else:
                    # Still inside tag; keep accumulating but we can emit nothing
                    # because content might be long; just accumulate.
                    # To avoid buffer growing, we can move part to current_tag_content.
                    # We'll keep it simple: just let buffer grow.
                    # For better memory usage, periodically shift buffer to current_tag_content.
                    pass

    def finalize(self) -> str:
        """
        Call after stream ends to flush any remaining text.
        Returns trailing text (non-tag).
        """
        remaining = self.buffer
        self.buffer = ""
        if self.in_tag:
            # Unclosed tag; treat as plain text (edge case)
            return remaining
        else:
            return remaining


# ---------- Agent ----------
SYSTEM_PROMPT = """You are Forge, an autonomous coding agent that writes files on the user's machine.

CRITICAL RULE: When you need to create or modify a file, you MUST output the following XML tags directly — do NOT use markdown code fences (```). Do NOT wrap the tag in quotes. Output it as plain text:

To create a new file:
<write path="relative/path/to/file.ext">
entire file contents here
</write>

To modify an existing file:
<patch path="relative/path/to/file.ext">
--- a/file.ext
+++ b/file.ext
@@ -1,4 +1,4 @@
-old line
+new line
</patch>

IMPORTANT: Before you write or patch an existing file, you MUST first request its current content using the <read> tag. The system will then provide the file content so you can produce an accurate modification.

To request file contents:
<read path="relative/path/to/file.ext">
</read>

After you receive the file content, you may then output the appropriate <write> or <patch> block.

You may include explanatory text before or after these blocks, but any file creation or read request MUST use the appropriate tag.
"""
# SYSTEM_PROMPT = """You are Forge, an autonomous coding agent that writes files on the user's machine.
#
# CRITICAL RULE: When you need to create or modify a file, you MUST output the following XML tag directly — do NOT use markdown code fences (```). Do NOT wrap the tag in quotes. Output it as plain text:
#
# <write path="relative/path/to/file.ext">
# entire file contents here
# </write>
#
# You may include explanatory text before or after the block, but the block itself must be exactly as shown.
#
# If you need to modify an existing file, use:
# <patch path="relative/path/to/file.ext">
# --- a/file.ext
# +++ b/file.ext
# @@ -1,4 +1,4 @@
# -old line
# +new line
# </patch>
#
# Never use triple backticks inside the <write> or <patch> blocks. Write the file content directly.
# """

class ForgeAgent:
    def __init__(self, config: dict):
        self.client = OpenAI(
            base_url=config["model_url"],
            api_key="not-needed",
            timeout=1200.0,
            max_retries=1,
        )
        self.model_name = config["model_name"]
        self.context_window = config.get("context_window", 32768)
        self.history: List[Dict[str, str]] = [
            {"role": "system", "content": SYSTEM_PROMPT}
        ]

    def estimate_tokens(self, text: str) -> int:
        """Rough token count (4 chars ~ 1 token)."""
        return len(text) // 4

    def token_count_history(self) -> int:
        total = 0
        for msg in self.history:
            total += self.estimate_tokens(msg["content"])
        return total

    def append_user_message(self, content: str):
        self.history.append({"role": "user", "content": content})

    def append_assistant_message(self, content: str):
        self.history.append({"role": "assistant", "content": content})

    def send_message(self) -> Generator[Tuple[str, List[Action]], None, None]:
        """
        Streams the model response, yielding (status_text, []) for display.
        Accumulates the full text, and after the stream ends, parses actions
        using a reliable regex and yields (None, actions).
        """
        full_text = ""
        stream = self.client.chat.completions.create(
            model=self.model_name,
            messages=self.history,
            stream=True,
            temperature=0.2,
            max_tokens=16384,
        )
        # Stream chunks for display
        for chunk in stream:
            if chunk.choices and chunk.choices[0].delta.content:
                raw = chunk.choices[0].delta.content
                full_text += raw
                # Yield raw text for the status view – no parsing yet
                yield (raw, [])
        # Now parse the accumulated full_text with regex
        actions = []
        pattern = r'<(write|patch|read)\s+path="([^"]+)"\s*>(.*?)</\1\s*>'
        for match in re.finditer(pattern, full_text, re.DOTALL):
            action_type = match.group(1)
            path = match.group(2)
            content = match.group(3).strip()
            actions.append(Action(action_type, path, content))
        # Yield the parsed actions at the end
        yield (None, actions)

    # Temporary purpose just to rove the piepline is working ok
    def send_message_simple(self) -> tuple[List[Action], str]:
        """Non-streaming version for reliable action extraction."""
        response = self.client.chat.completions.create(
            model=self.model_name,
            messages=self.history,
            temperature=0.2,
            max_tokens=16384,
        )
        full_text = response.choices[0].message.content
        actions = []
        # Regex that matches <write path="...">...</write> or <patch path="...">...</patch>
        pattern = r'<(write|patch|read)\s+path="([^"]+)"\s*>(.*?)</\1\s*>'
        for match in re.finditer(pattern, full_text, re.DOTALL):
            action_type = match.group(1)
            path = match.group(2)
            content = match.group(3).strip()
            actions.append(Action(action_type, path, content))
        return actions, full_text
