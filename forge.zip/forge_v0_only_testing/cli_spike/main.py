import typer
import json
# import time
# import sys
from pathlib import Path
from typing import List

from prompt_toolkit import PromptSession
from prompt_toolkit.history import FileHistory
# from prompt_toolkit.key_binding import KeyBindings
from rich.console import Console
from rich.live import Live
# from rich.markdown import Markdown
from rich.panel import Panel
from rich.syntax import Syntax
from rich.text import Text

from agent import ForgeAgent, Action
from permissions import PermissionManager
from checkpoint import save_checkpoint, load_latest_checkpoint
app = typer.Typer()
console = Console()
session_history = FileHistory(str(Path.home() / ".forge_v0_generated_using_coding_agent" / "cli_history"))

# Load config
CONFIG_PATH = Path(__file__).parent.parent / "config.json"
if not CONFIG_PATH.exists():
    console.print("[red]config.json not found. Copy config.json.example?[/red]")
    raise SystemExit(1)
with open(CONFIG_PATH) as f:
    config = json.load(f)

def handle_read_action(action: Action, agent: ForgeAgent):
    """Read a file and feed its content back into the conversation."""
    target = Path(action.path)
    if not target.exists():
        content = f"[ERROR: File not found: {action.path}]"
    else:
        content = target.read_text(encoding='utf-8')
    # Inject as a system message so the agent knows it's file content
    agent.history.append({
        "role": "user",
        "content": f"[FILE CONTENTS of {action.path}]\n{content}\n\nNow, using the above file contents, perform the requested modification."
    })
    console.print(f"[dim]Read {action.path} and fed back to agent.[/dim]")

# ---------- Helper functions ----------
def display_status(text: str, agent: ForgeAgent, actions_done: List[str], checkpoint_num: int):
    """Builds a Rich renderable for the status view."""
    info = Text()
    info.append(f"Session: {session_id[:8]}... ", style="dim")
    info.append(f"Checkpoint: {checkpoint_num} ", style="bold cyan")
    info.append(f"Tokens: ~{agent.token_count_history()}", style="dim")
    info.append("\n")
    info.append(f"Files touched: {', '.join(actions_done) if actions_done else 'None'}", style="green")
    if text:
        info.append("\n\n")
        info.append(text)
    return Panel(info, title="Forge Status", border_style="blue")

def display_code_view(agent_output: str, actions: List[Action]):
    """Show only the generated code (actions) and minimal explanation."""
    # In code view we display the raw write/patch content with syntax.
    # We'll just print them using Rich Syntax.
    from .permissions import _guess_language as _guess_lang
    for action in actions:
        lang = _guess_lang(action.path)
        console.print(Panel(Syntax(action.content, lang, theme="monokai", line_numbers=True),
                            title=f"[bold]{action.type.upper()}: {action.path}[/bold]"))

def apply_action(action: Action, perm_mgr: PermissionManager, agent: ForgeAgent, files_touched: List[str]):
    """
    Ask permission and write/patch the file if allowed.
    Returns True if file was actually modified.
    """
    if not perm_mgr.ask_for_permission(action.type, action.path, action.content):
        return False

    target = Path(action.path)
    target.parent.mkdir(parents=True, exist_ok=True)
    if action.type == "write":
        target.write_text(action.content, encoding='utf-8')
        console.print(f"[green]✓ Wrote {target}[/green]")
    elif action.type == "patch":
        # Apply the unified diff using simple patch logic (for spike we can use `unidiff`)
        # Since it's complex, we can write the content as a .patch file and ask user to apply,
        # or implement a basic apply. For now, we'll simply replace the file with the '+' lines?
        # Proper approach: use `unidiff` library. To keep deps light, we'll try to parse and apply.
        try:
            from unidiff import PatchSet
            patch = PatchSet.from_string(action.content)
            original = target.read_text()
            new_content = str(patch.apply())
            target.write_text(new_content, encoding='utf-8')
            console.print(f"[green]✓ Patched {target}[/green]")
        except (ImportError, Exception) as e:
            # If unidiff fails for any reason, save as .patch file
            console.print(f"[yellow]Patch application failed ({e}). Saving as .patch file instead.[/yellow]")
            patch_file = target.with_suffix(target.suffix + ".patch")
            patch_file.write_text(action.content, encoding='utf-8')
            console.print(f"[dim]Patch saved to {patch_file}. Please apply it manually or ask me to rewrite the file.[/dim]")
    else:
        return False

    files_touched.append(str(target))
    return True

def check_context_and_save(agent: ForgeAgent, session_id: str, step: int, files_touched: List[str], next_step: str = "Continue"):
    """If token count exceeds 80% of context window, trigger checkpoint and context refresh."""
    limit = int(agent.context_window * 0.8)
    if agent.token_count_history() > limit:
        console.print("[bold yellow]⚠ Approaching context limit — saving checkpoint...[/bold yellow]")
        # Ask the model for a summary (blocking call, no streaming)
        summary_request = "Please summarise the conversation so far in a few sentences, preserving key decisions, files created/modified, and the next planned step."
        # Append the summary request temporarily
        agent.history.append({"role": "user", "content": summary_request})
        summary_resp = agent.client.chat.completions.create(
            model=agent.model_name,
            messages=agent.history,
            max_tokens=200,
            temperature=0.0
        )
        summary = summary_resp.choices[0].message.content
        agent.history.pop()  # remove summary request
        # Save checkpoint
        step += 1
        save_checkpoint(session_id, step, summary, files_touched, next_step, agent.token_count_history())
        # Reset context: keep system prompt + summary + last user request
        last_user = None
        for msg in reversed(agent.history):
            if msg["role"] == "user":
                last_user = msg["content"]
                break
        agent.history = [
            {"role": "system", "content": agent.history[0]["content"]},  # system prompt
            {"role": "user", "content": f"[CONTEXT FROM CHECKPOINT #{step}]\n{summary}\n\nYour last task was: {next_step}"}
        ]
        if last_user:
            agent.history.append({"role": "user", "content": last_user})
        console.print(f"[cyan]⟳ Context refreshed — continuing from checkpoint #{step}[/cyan]")
        return step
    return step

# ---------- Main command ----------
@app.command()
def start():
    """Start a new Forge session."""
    global session_id
    session_id = str(__import__('uuid').uuid4())
    files_touched = []
    step = 0
    perm_mgr = PermissionManager()
    agent = ForgeAgent(config)

    console.print(Panel.fit(
        "[bold cyan]Forge CLI Spike[/bold cyan]\n"
        "Powered by Gemma4 E4B via llama.cpp\n"
        "Type /help for commands.",
        border_style="green"
    ))

    # Optionally resume from checkpoint
    latest = load_latest_checkpoint(session_id)
    if latest:
        console.print(f"[yellow]Found checkpoint from step {latest['step_number']}.[/yellow]")
        if typer.confirm("Resume?"):
            # Inject checkpoint context
            agent.history = [
                {"role": "system", "content": agent.history[0]["content"]},
                {"role": "user", "content": f"[CHECKPOINT SUMMARY]\n{latest['summary']}\n\nYour next step: {latest['next_step']}"}
            ]
            files_touched = latest['files_touched']
            step = latest['step_number']
            console.print(f"[cyan]Resumed from checkpoint #{step}.[/cyan]")

    # Main conversation loop
    prompt_session = PromptSession(history=session_history)
    while True:
        try:
            user_input = prompt_session.prompt("forge_v0_generated_using_coding_agent> ")
        except (KeyboardInterrupt, EOFError):
            break

        if user_input.startswith("/"):
            # Handle slash commands
            cmd = user_input.strip().lower()
            if cmd == "/exit":
                break
            elif cmd == "/checkpoint":
                console.print("Saving checkpoint...")
                step = check_context_and_save(agent, session_id, step, files_touched, "User forced checkpoint")
                # force a save anyway
                summary = "User-forced checkpoint."
                save_checkpoint(session_id, step, summary, files_touched, "Resume", agent.token_count_history())
                console.print("[green]Checkpoint saved.[/green]")
            elif cmd == "/view status":
                # default is status, so do nothing
                pass
            elif cmd == "/view code":
                console.print("[dim]Switched to code view. Type /view status to return.[/dim]")
                # set a flag; we'll handle in display logic
                # For now, just display next actions as code only (handled later)
                pass
            elif cmd == "/permissions":
                if perm_mgr.global_allow:
                    console.print("Global auto-allow: [green]ON[/green]")
                else:
                    console.print("Auto-allow: [red]OFF[/red]")
                console.print(f"Specifically allowed files: {perm_mgr.allowed_files}")
            elif cmd == "/help":
                console.print("Commands: /exit, /checkpoint, /view status, /view code, /permissions, /help")
            else:
                console.print("[red]Unknown command.[/red]")
            continue

        # Regular user input
        agent.append_user_message(user_input)
        console.print("[dim]Forge is thinking...[/dim]")
        step += 1

        # Collect streaming output
        live_display = Live(auto_refresh=False, console=console)
        live_display.start()

        actions_this_turn = []
        full_output = ""

        # --- FIRST GENERATION (response to user input) ---
        try:
            for status_text, actions in agent.send_message():
                if status_text:
                    full_output += status_text
                    live_display.update(
                        display_status(full_output, agent, files_touched, step),
                        refresh=True
                    )
                if actions:
                    actions_this_turn.extend(actions)
            live_display.stop()
        except Exception as e:
            live_display.stop()
            console.print(f"[red]Error during generation: {e}[/red]")
            continue

        # Append full response to history
        agent.append_assistant_message(full_output)

        # --- HANDLE READ ACTIONS (inject file contents, then re‑generate) ---
        read_actions = [a for a in actions_this_turn if a.type == "read"]
        write_actions = [a for a in actions_this_turn if a.type in ("write", "patch")]

        if read_actions:
            for ra in read_actions:
                handle_read_action(ra, agent)
            console.print("[dim]Agent is re-generating after reading files...[/dim]")

            # Re‑run the agent to let it use the file contents
            full_output = ""
            actions_this_turn = []
            live_display.start()
            try:
                for status_text, actions in agent.send_message():
                    if status_text:
                        full_output += status_text
                        live_display.update(
                            display_status(full_output, agent, files_touched, step),
                            refresh=True
                        )
                    if actions:
                        actions_this_turn.extend(actions)
                live_display.stop()
            except Exception as e:
                live_display.stop()
                console.print(f"[red]Error during re-generation: {e}[/red]")
                continue
            agent.append_assistant_message(full_output)
            # Re‑separate after re‑generation
            write_actions = [a for a in actions_this_turn if a.type in ("write", "patch")]

        # --- PROCESS WRITE/PATCH ACTIONS (permission gated) ---
        for action in write_actions:
            if perm_mgr.has_permission(action.type, action.path):
                apply_action(action, perm_mgr, agent, files_touched)
            else:
                if perm_mgr.ask_for_permission(action.type, action.path, action.content):
                    apply_action(action, perm_mgr, agent, files_touched)
                else:
                    console.print("[dim]Change skipped.[/dim]")

        # Check context and maybe checkpoint
        step = check_context_and_save(agent, session_id, step, files_touched, "Continue from last user request")

    # End session: final checkpoint
    console.print("[bold green]Goodbye![/bold green]")

def main():
    app()

if __name__ == "__main__":
    main()
