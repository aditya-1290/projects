import sqlite3
import json
import uuid
import time
from typing import Dict, List, Optional
from pathlib import Path

DB_PATH = Path.home() / ".forge_v0_generated_using_coding_agent" / "checkpoints.db"

def get_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    conn.execute("""
        CREATE TABLE IF NOT EXISTS checkpoints (
            id INTEGER PRIMARY KEY,
            session_id TEXT,
            step_number INTEGER,
            summary TEXT,
            files_touched TEXT,
            next_step TEXT,
            token_count INTEGER,
            created_at REAL
        )
    """)
    conn.commit()
    return conn

def save_checkpoint(
    session_id: str,
    step_number: int,
    summary: str,
    files_touched: List[str],
    next_step: str,
    token_count: int
) -> int:
    conn = get_db()
    cur = conn.execute(
        "INSERT INTO checkpoints (session_id, step_number, summary, files_touched, next_step, token_count, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (session_id, step_number, summary, json.dumps(files_touched), next_step, token_count, time.time())
    )
    conn.commit()
    return cur.lastrowid

def load_latest_checkpoint(session_id: str) -> Optional[Dict]:
    conn = get_db()
    row = conn.execute(
        "SELECT * FROM checkpoints WHERE session_id = ? ORDER BY step_number DESC LIMIT 1",
        (session_id,)
    ).fetchone()
    if not row:
        return None
    return {
        "session_id": row["session_id"],
        "step_number": row["step_number"],
        "summary": row["summary"],
        "files_touched": json.loads(row["files_touched"]),
        "next_step": row["next_step"],
        "token_count": row["token_count"],
        "created_at": row["created_at"]
    }

def list_sessions() -> List[Dict]:
    conn = get_db()
    rows = conn.execute(
        "SELECT DISTINCT session_id, max(step_number) as latest, count(*) as count FROM checkpoints GROUP BY session_id"
    ).fetchall()
    return [{"session_id": r[0], "latest_step": r[1], "total_checkpoints": r[2]} for r in rows]
