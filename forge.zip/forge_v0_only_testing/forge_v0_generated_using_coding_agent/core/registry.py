from typing import List, Dict, Any
from core.agent_card import AgentCard

class CapabilityRegistry:
    """
    A central registry to track all agents and their declared capabilities 
    within the ADK ecosystem. This allows for dynamic routing and discovery.
    """
    def __init__(self):
        # Stores agent cards keyed by agent_id for quick lookup
        self._agents: Dict[str, AgentCard] = {}
        # Stores capability -> list of agent_ids that possess it
        self._capability_map: Dict[str, List[str]] = {}

    def register(self, agent_card: AgentCard) -> None:
        """
        Registers a new agent card into the system.

        Args:
            agent_card: The AgentCard object describing the agent.
        """
        if agent_card.agent_id in self._agents:
            print(f"Warning: Agent ID {agent_card.agent_id} is already registered and will be overwritten.")
        
        self._agents[agent_card.agent_id] = agent_card
        
        # Update capability map
        for capability in agent_card.capabilities:
            if capability not in self._capability_map:
                self._capability_map[capability] = []
            
            if agent_card.agent_id not in self._capability_map[capability]:
                self._capability_map[capability].append(agent_card.agent_id)

    def get_agents_by_capability(self, capability: str) -> List[AgentCard]:
        """
        Retrieves all registered agents that possess a specific capability.

        Args:
            capability: The name of the capability to search for (e.g., "data_analysis").

        Returns:
            A list of AgentCard objects matching the capability. Returns an empty list if none are found.
        """
        agent_ids = self._capability_map.get(capability, [])
        return [self._agents[agent_id] for agent_id in agent_ids if agent_id in self._agents]

    def health_check(self) -> Dict[str, Any]:
        """
        Performs a basic health check on all registered agents. 
        In a real system, this would ping the running instances of the agents.

        Returns:
            A dictionary summarizing the status of all known agents.
        """
        status_report = {}
        for agent_id, card in self._agents.items():
            # Placeholder for actual health check logic (e.g., checking if the agent process is alive)
            # For now, we assume registered means 'healthy' unless proven otherwise.
            status_report[agent_id] = {
                "name": card.name,
                "is_active": True, # Placeholder
                "capabilities": card.capabilities
            }
        return {"registry_status": "OK", "agents": status_report}

# Note: We need to import Any from typing for the health_check return type hint if we want strictness.
from typing import Any
