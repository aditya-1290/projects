import queue
import threading
from typing import Callable, Dict, List, Any

# Assuming A2AMessage is defined in a2a_protocol.py and accessible via forge_v0_generated_using_coding_agent.core
try:
    from core.a2a_protocol import A2AMessage
except ImportError:
    # Define a placeholder if running outside the full structure for testing purposes, 
    # but this should be replaced by the actual import in the final environment.
    class A2AMessage:
        """Placeholder for A2AMessage."""
        def __init__(self, message_type: str, payload: Any):
            self.message_type = message_type
            self.payload = payload

from collections import defaultdict

class CommunicationBus:
    """
    A thread-safe, in-memory Publish/Subscribe mechanism for asynchronous message dispatching.

    Messages published to the bus are placed into an internal queue and processed 
    by a dedicated background worker thread, ensuring that publishing is non-blocking.
    """
    def __init__(self):
        # Stores subscribers: {message_type: [callback1, callback2, ...]}
        self._subscribers: Dict[str, List[Callable[[A2AMessage], None]]] = defaultdict(list)
        
        # Thread-safe queue for incoming messages
        self._message_queue: queue.Queue[A2AMessage] = queue.Queue()
        
        # Control flag and thread management
        self._running = True
        self._worker_thread = threading.Thread(target=self._process_messages, daemon=True)
        self._worker_thread.start()

    def subscribe(self, message_type: str, callback: Callable[[A2AMessage], None]) -> None:
        """
        Registers a callback function to be executed when a message of the specified type is published.

        Args:
            message_type: The string identifier for the message type (e.g., "AGENT_INIT").
            callback: The callable function that accepts an A2AMessage object.
        """
        self._subscribers[message_type].append(callback)
        print(f"Bus: Subscribed callback to {message_type}")

    def publish(self, message: A2AMessage) -> None:
        """
        Publishes a message to the bus. This operation is non-blocking; 
        the message is immediately placed in the queue for asynchronous delivery.

        Args:
            message: The A2AMessage object containing the message details.
        """
        self._message_queue.put(message)
        # print(f"Bus: Published message of type {message.message_type}") # Optional logging

    def _process_messages(self):
        """
        The main loop for the background worker thread. It continuously pulls messages 
        from the queue and dispatches them to all registered subscribers.
        """
        while self._running:
            try:
                # Wait up to 0.1 seconds for a message to avoid busy-waiting when shutting down
                message = self._message_queue.get(timeout=0.1)
                
                msg_type = message.message_type
                subscribers = self._subscribers.get(msg_type, [])

                if not subscribers:
                    # print(f"Bus: No subscribers for {msg_type}") # Optional logging
                    self._message_queue.task_done()
                    continue

                for callback in subscribers:
                    try:
                        # Execute the callback in the worker thread context
                        callback(message)
                    except Exception as e:
                        # Gracefully handle exceptions within a specific subscriber's callback
                        print(f"Error executing callback for {msg_type}: {e}")
                
                self._message_queue.task_done()

            except queue.Empty:
                # Expected when the queue is empty and we are waiting/shutting down
                continue
            except Exception as e:
                # Catch unexpected errors in the worker loop itself
                print(f"Critical error in CommunicationBus worker thread: {e}")
        
        print("CommunicationBus worker thread stopped gracefully.")


    def shutdown(self) -> None:
        """
        Stops the background message processing thread cleanly. 
        It waits for all currently queued messages to be processed before stopping.
        """
        if not self._running:
            return

        print("Initiating CommunicationBus shutdown...")
        self._running = False
        
        # Wait until all items in the queue have been retrieved and processed
        try:
            self._message_queue.join()
        except Exception as e:
             print(f"Warning during queue join on shutdown: {e}")

        # The thread will naturally exit its loop when _running becomes False, 
        # but we rely on the daemon status or explicit joining if necessary for strict cleanup.
        # Since it's a daemon thread, exiting is usually sufficient upon main program exit, 
        # but calling join() ensures graceful completion of current tasks.
        if self._worker_thread.is_alive():
            self._worker_thread.join(timeout=1) # Wait briefly for the thread to finish its loop iteration


# Singleton instance accessible from other modules
bus = CommunicationBus()

if __name__ == '__main__':
    # Example Usage Test (Requires A2AMessage definition or mock setup)
    print("--- Testing CommunicationBus ---")
    
    def handler_a(message: A2AMessage):
        print(f"[Handler A] Received {message.message_type}: {message.payload}")

    def handler_b(message: A2AMessage):
        print(f"[Handler B] Processing {message.message_type} payload: {message.payload['data']}")

    # Subscribe handlers
    bus.subscribe("SYSTEM_EVENT", handler_a)
    bus.subscribe("TASK_REQUEST", handler_b)

    # Publish messages (non-blocking)
    msg1 = A2AMessage("SYSTEM_EVENT", "System initialized successfully.")
    bus.publish(msg1)

    msg2 = A2AMessage("TASK_REQUEST", {"data": "Process large dataset"})
    bus.publish(msg2)
    
    # Publish another message that has no subscribers
    msg3 = A2AMessage("UNKNOWN_EVENT", "Should be ignored.")
    bus.publish(msg3)

    print("Messages published. Waiting for processing...")
    
    # Give time for the background thread to process messages
    import time
    time.sleep(1) 

    # Shutdown gracefully
    bus.shutdown()
    print("--- Test Complete ---")