from pydantic import BaseModel
from typing import List, Optional, Dict

class AgentCard(BaseModel):
    """
    Defines the metadata and capabilities of an agent.
    This acts as a standardized schema for describing agents in the system.
    """
    agent_id: str
    name: str
    description: str
    capabilities: List[str] = []
    llm_config: Optional[Dict] = None