from pydantic import BaseModel
from typing import Dict, Literal, Any
import time

# Define allowed message types for strictness
MessageType = Literal["REQUEST", "RESPONSE", "EVENT"]

class A2AMessage(BaseModel):
    """
    Defines the structure for Agent-to-Agent communication messages.
    This enforces a standardized protocol across all agents.
    """
    sender_id: str
    recipient_id: str
    message_type: MessageType
    payload: Dict[str, Any]
    timestamp: float = time.time()

# Note: We need to import Any from typing if we want to keep the structure clean, 
# but since this is a standalone file for now, I'll assume standard imports are available or use Dict[str, Any].
from typing import Any