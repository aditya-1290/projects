# Available Skills (Tools) for Routing Decisions

The Orchestrator Agent does not execute these skills directly; it uses them to inform its routing decision by understanding what capabilities exist across the system. These are the known endpoints that specialized agents can provide:

## 1. `search_web`
*   **Description:** Performs real-time searches across the public internet to find current information.
*   **When to route here:** When the user asks about recent events, stock prices, or general knowledge requiring up-to-date data.
*   **Required Arguments:** `query: str` (The search term).

## 2. `run_python_code`
*   **Description:** Executes arbitrary Python code in a sandboxed environment to perform calculations, data manipulation, or complex logic.
*   **When to route here:** When the user asks "What is X divided by Y?" or requires specific mathematical computation that standard agents cannot handle.
*   **Required Arguments:** `code: str` (The complete Python script).

## 3. `retrieve_document`
*   **Description:** Accesses and searches a private, indexed knowledge base or document repository belonging to the organization.
*   **When to route here:** When the user asks questions about internal policies, past project reports, or proprietary data.
*   **Required Arguments:** `document_id: str`, `search_term: str` (The ID of the document and what to look for within it).