from typing import List, Dict, Any
from agents.base_agent import BaseAgent
from core.agent_card import AgentCard
from core.model_manager import ModelManager
from core.a2a_protocol import A2AMessage
import json

class OrchestratorAgent(BaseAgent):
    """
    The central routing and planning agent responsible for interpreting user intent 
    and directing the request to the most appropriate specialized agent.
    """
    def __init__(self, agent_id: str, model_manager: ModelManager, communication_bus=None):
        # Define the Orchestrator's card details
        orchestrator_card = AgentCard(
            agent_id=agent_id,
            name="Orchestrator",
            description="Routes user requests to specialized agents based on intent.",
            capabilities=["intent_detection", "routing", "planning"],
            llm_config={"temperature": 0.1} # Example config
        )
        
        # Initialize BaseAgent, passing the card and model manager
        super().__init__(agent_id, orchestrator_card, model_manager)
        self.communication_bus = communication_bus
        print(f"Orchestrator initialized with ID: {agent_id}")

    def initialize(self) -> None:
        """
        Performs any necessary setup for the Orchestrator (e.g., loading routing rules).
        """
        print("Orchestrator initializing routing logic...")
        # In a real system, this might load agent capability maps from the registry

    def run(self, user_query: str) -> Any:
        """
        Processes a user query by determining intent and routing it.

        Args:
            user_query: The raw input string from the end-user.

        Returns:
            A status message indicating the action taken.
        """
        print(f"\n--- Orchestrator received query: '{user_query}' ---")

        # 1. Call model_manager.generate for intent analysis and routing decision
        system_prompt = (
            "You are an expert router agent. Analyze the user's request and determine "
            "the single best specialized agent to handle it. Respond ONLY in a strict JSON format: "
            "{'target_agent': 'AGENT_ID', 'confidence': 0.95, 'reasoning': 'brief explanation'}. "
            "If no specific agent is suitable, use 'fallback'."
        )
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_query}
        ]

        routing_response_text = self.model_manager.generate(messages=messages, tools=None)
        print(f"LLM Routing Response: {routing_response_text}")

        # 2. Parse the response to determine which agent to route to
        try:
            routing_decision = json.loads(routing_response_text)
            target_agent_id = routing_decision.get("target_agent", "fallback")
            confidence = routing_decision.get("confidence", 0.0)
            reasoning = routing_decision.get("reasoning", "No reasoning provided.")

        except json.JSONDecodeError:
            print("ERROR: Failed to parse LLM JSON response. Defaulting to fallback.")
            target_agent_id = "fallback"
            confidence = 0.0
            reasoning = "Parsing failed."


        # 3. Publish an A2AMessage to the communication bus
        if self.communication_bus:
            message = A2AMessage(
                sender_id=self.agent_id,
                recipient_id=target_agent_id,
                message_type="REQUEST",
                payload={"original_query": user_query, "routing_context": {"confidence": confidence, "reasoning": reasoning}},
                timestamp=0 # Timestamp handled by A2AMessage model default
            )
            self.communication_bus.publish(message)
            print(f"SUCCESS: Routed request to {target_agent_id} via Communication Bus.")
        else:
            print("WARNING: Communication bus not available. Cannot publish message.")

        return {
            "status": "Routing Complete", 
            "target": target_agent_id, 
            "confidence": confidence,
            "reasoning": reasoning
        }