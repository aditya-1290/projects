from abc import ABC, abstractmethod
from typing import Any
from core.model_manager import ModelManager
from core.agent_card import AgentCard

class BaseAgent(ABC):
    """
    Abstract base class for all agents in the ADK ecosystem.
    Provides fundamental structure and required interfaces.
    """
    def __init__(self, agent_id: str, card: AgentCard, model_manager: ModelManager):
        self.agent_id = agent_id
        self.card = card
        self.model_manager = model_manager

    @abstractmethod
    def initialize(self) -> None:
        """
        Called once during the agent's setup phase to perform initializations, 
        load configurations, or register capabilities.
        """
        pass

    @abstractmethod
    def run(self) -> Any:
        """
        The main execution loop or logic of the agent. This method is called 
        to process inputs and generate outputs/actions.
        """
        pass

    def get_identity(self) -> str:
        """
        Returns a unique identifier for this agent.
        """
        return self.agent_id