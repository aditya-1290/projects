import time
from typing import Dict, Any, List

# Import components from the forge_v0_generated_using_coding_agent directory structure
from core.model_manager import ModelManager
from core.registry import CapabilityRegistry
from agents.orchestrator.agent import OrchestratorAgent
# from forge_v0_generated_using_coding_agent.core.agent_card import AgentCard
# from forge_v0_generated_using_coding_agent.core.a2a_protocol import A2AMessage
# Import the real communication bus
from core.communication_bus import bus

# --- MOCK COMMUNICATION BUS IMPLEMENTATION (REMOVED) ---
# The mock implementation is replaced by the actual import above.

# --- MAIN APPLICATION LOGIC ---

def main():
    """
    Initializes the ADK components and runs the main interaction loop.
    """
    print("--- Starting Multi-Agent Development Kit (ADK) Boilerplate ---")

    # 1. Start the CommunicationBus using the real implementation
    communication_bus = bus

    try:
        # 2. Instantiate the ModelManager (Requires config.json to exist!)
        print("\n[STEP 1] Initializing Model Manager...")
        model_manager = ModelManager(config_path="config.json")
        print("ModelManager successfully initialized.")

    except FileNotFoundError as e:
        print(f"\nFATAL ERROR: {e}")
        print("Please ensure a '/config.json' file exists with LLM settings before running main.py.")
        return
    except ValueError as e:
        print(f"\nFATAL CONFIGURATION ERROR: {e}")
        return

    # 3. Instantiate the CapabilityRegistry
    registry = CapabilityRegistry()

    # 4. Instantiate the OrchestratorAgent
    orchestrator_id = "orch_001"
    orchestrator = OrchestratorAgent(
        agent_id=orchestrator_id, 
        model_manager=model_manager, 
        communication_bus=communication_bus
    )

    # 5. Register it with the CapabilityRegistry
    registry.register(orchestrator.card)
    print("\n[STEP 2] Orchestrator registered successfully.")
    
    # Optional: Check registry health
    print("--- Registry Health Check ---")
    print(registry.health_check())

    # 6. Enter the simple loop
    print("\n=========================================")
    print("ADK System Ready. Type 'exit' to quit.")
    print("=========================================\n")

    while True:
        try:
            user_input = input("User Query > ").strip()
            if user_input.lower() in ['exit', 'quit']:
                print("\nShutting down ADK system. Goodbye!")
                break
            
            if not user_input:
                continue

            # Call orchestrator.run()
            result = orchestrator.run(user_query=user_input)
            
            print("\n--- Orchestrator Final Report ---")
            print(f"Status: {result['status']}")
            print(f"Target Agent: {result['target']}")
            print(f"Confidence: {result['confidence']:.2f}")
            print("---------------------------------\n")

        except Exception as e:
            print(f"\n[CRITICAL LOOP ERROR]: An unexpected error occurred: {e}")
            time.sleep(1)


if __name__ == "__main__":
    # To run this successfully, you must create forge_v0_generated_using_coding_agent/config.json
    # in the root directory containing LLM settings.
    main()