"""
backend/services/agent_runner.py
----------------------------------
Owns the ADK RunnerRegistry for the FastAPI app.
Created once at startup via create_all_agents().
"""

from __future__ import annotations

from agents.factory import create_all_agents
from agents.runner_registry import RunnerRegistry
from agents.adk_config import configure_llm_env
from shared.logger import get_logger

logger = get_logger(__name__)

_registry: RunnerRegistry | None = None


async def startup() -> RunnerRegistry:
    """
    Call during FastAPI lifespan startup.
    Configures LLM env vars and creates all agents.
    """
    global _registry
    configure_llm_env()
    _registry = create_all_agents()
    logger.info("AgentRunner startup complete")
    return _registry


async def shutdown() -> None:
    """Call during FastAPI lifespan shutdown."""
    global _registry
    if _registry:
        await _registry.close_all()
        _registry = None
    logger.info("AgentRunner shutdown complete")


def get_registry() -> RunnerRegistry:
    if _registry is None:
        raise RuntimeError("AgentRunner not started — call startup() first")
    return _registry
