"""
backend/services/session_service.py
-------------------------------------
SessionService — routes user messages through ADK runners.

With ADK, "routing" is simply calling runner.run() on the Orchestrator.
The Orchestrator decides which sub-agents to call via AgentTool.
Session state is persisted in SQLite; ADK conversation history lives
in InMemorySessionService (per ADK session).
"""

from __future__ import annotations

import asyncio
from typing import Optional, AsyncIterator

from fastapi import Depends

from backend.services.stream_service import get_stream_service, StreamService
import backend.services.agent_runner as agent_runner_svc
from memory.session_store import (
    create_session, delete_session, get_session,
    list_sessions, make_session, update_session,
)
from shared.exceptions import SessionNotFoundError
from shared.logger import get_logger
from shared.types import (
    ProjectMode, SessionState, SessionStatus, UserType,
)

logger = get_logger(__name__)


class SessionService:
    """Handles session lifecycle and routes messages to ADK runners."""

    def __init__(self, stream_service: StreamService):
        self._stream = stream_service

    async def create_and_start(
        self,
        project_name:  str,
        project_path:  str,
        mode:          ProjectMode,
        user_type:     UserType     = UserType.DEVELOPER,
        initial_input: Optional[str] = None,
    ) -> SessionState:
        """
        Create a Forge session in SQLite and optionally send the first message.
        The project_path is passed to MCP servers via FORGE_PROJECT_ROOT.
        """
        session = make_session(
            project_name = project_name,
            project_path = project_path,
            mode         = mode,
            user_type    = user_type,
        )
        await create_session(session)
        logger.info(f"Session created: {session.session_id[:8]} mode={mode.value}")

        # Send opening message to kick off the agent flow
        if initial_input:
            asyncio.create_task(
                self._run_and_stream(session.session_id, initial_input)
            )
        else:
            # Send a default greeting based on mode
            greeting = _opening_message(mode, project_path)
            asyncio.create_task(
                self._run_and_stream(session.session_id, greeting)
            )

        return session

    async def handle_user_message(
        self,
        session_id: str,
        user_input: str,
    ) -> None:
        """
        Accept a user message and run it through the Orchestrator.
        Response streams to the SSE endpoint via StreamService.
        """
        session = await self._get_or_raise(session_id)
        if session.status not in (SessionStatus.ACTIVE, SessionStatus.PAUSED):
            raise ValueError(f"Session {session_id[:8]} is not active")

        # Update status to active
        await update_session(session_id, status=SessionStatus.ACTIVE)

        # Fire-and-forget — response streams via SSE
        asyncio.create_task(
            self._run_and_stream(session_id, user_input)
        )

    async def _run_and_stream(self, session_id: str, message: str) -> None:
        """
        Run a message through the Orchestrator and stream tokens to SSE.
        user_id = session_id (one user per session in Phase 1).
        """
        registry = agent_runner_svc.get_registry()
        orchestrator = registry.get("orchestrator")

        try:
            async for chunk in orchestrator.run(
                user_id    = session_id,
                session_id = session_id,
                message    = message,
            ):
                await self._stream.push(session_id, {
                    "type":    "token",
                    "content": chunk,
                })

            # Signal end of response
            await self._stream.push(session_id, {"type": "done"})

        except Exception as e:
            logger.error(f"Agent error in session {session_id[:8]}: {e}", exc_info=True)
            await self._stream.push(session_id, {
                "type":    "error",
                "content": str(e),
            })

    # ------------------------------------------------------------------
    # CRUD
    # ------------------------------------------------------------------

    async def get_session(self, session_id: str) -> SessionState:
        return await self._get_or_raise(session_id)

    async def list_sessions(
        self, status: Optional[str] = None
    ) -> list[SessionState]:
        return await list_sessions(status=status)

    async def update_status(
        self, session_id: str, status: SessionStatus
    ) -> SessionState:
        await self._get_or_raise(session_id)
        await update_session(session_id, status=status)
        return await get_session(session_id)

    async def delete_session(self, session_id: str) -> None:
        await self._get_or_raise(session_id)
        await delete_session(session_id)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _get_or_raise(self, session_id: str) -> SessionState:
        try:
            return await get_session(session_id)
        except Exception:
            raise SessionNotFoundError(f"Session not found: {session_id}")


def _opening_message(mode: ProjectMode, project_path: str) -> str:
    """Generate the opening message sent to the Orchestrator on session start."""
    if mode == ProjectMode.SCRATCH:
        return (
            "A new Forge session has started in BUILD mode. "
            "Greet the user and ask them to describe what they want to build."
        )
    elif mode == ProjectMode.INGEST:
        return (
            f"A new Forge session has started in INGEST mode. "
            f"The project is at: {project_path}. "
            f"Scan the project structure and report what you find, "
            f"then ask the user what they want to work on."
        )
    elif mode == ProjectMode.TEST:
        return (
            f"A new Forge session has started in TEST mode. "
            f"The project is at: {project_path}. "
            f"Scan the project and ask the user what test depth they want."
        )
    return "A new Forge session has started. How can I help?"


# Dependency injection
def get_session_service(
    stream: StreamService = Depends(get_stream_service),
) -> SessionService:
    return SessionService(stream_service=stream)
