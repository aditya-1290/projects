"""
backend/app.py
--------------
FastAPI application factory for Forge.

Startup order:
1. Database schema init
2. ADK LLM env configuration
3. All ADK agents created and runners registered
4. API routers mounted
"""

from __future__ import annotations

from contextlib import asynccontextmanager
from typing import AsyncGenerator

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from backend.api import sessions, stream, permissions, health
import backend.services.agent_runner as agent_runner_svc
from config.settings import get_settings
from shared.constants import APP_NAME, APP_VERSION, API_PREFIX
from shared.exceptions import ForgeError, SessionNotFoundError, PermissionDeniedError
from shared.logger import get_logger
from storage.database.connection import create_schema, init_db_path

logger = get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Startup / shutdown lifecycle."""
    logger.info(f"Starting {APP_NAME} v{APP_VERSION}")

    # 1. Database
    init_db_path()
    create_schema()
    logger.info("Database ready")

    # 2. ADK agents + runners
    await agent_runner_svc.startup()
    logger.info("ADK agents ready")

    yield  # ← app runs here

    # Shutdown
    logger.info("Shutting down...")
    await agent_runner_svc.shutdown()
    logger.info(f"{APP_NAME} stopped")


def create_app() -> FastAPI:
    settings = get_settings()

    app = FastAPI(
        title       = APP_NAME,
        version     = APP_VERSION,
        description = "Forge — Autonomous Programming Agent API",
        docs_url    = "/docs",
        redoc_url   = "/redoc",
        lifespan    = lifespan,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=[
            "http://localhost:3000",
            "http://localhost:5173",
            f"http://{settings.server.host}:{settings.server.port}",
        ],
        allow_credentials = True,
        allow_methods     = ["*"],
        allow_headers     = ["*"],
    )

    app.include_router(health.router,      prefix=API_PREFIX)
    app.include_router(sessions.router,    prefix=API_PREFIX)
    app.include_router(stream.router,      prefix=API_PREFIX)
    app.include_router(permissions.router, prefix=API_PREFIX)

    @app.exception_handler(SessionNotFoundError)
    async def session_not_found(request: Request, exc: SessionNotFoundError):
        return JSONResponse(status_code=404, content={"error": str(exc)})

    @app.exception_handler(PermissionDeniedError)
    async def permission_denied(request: Request, exc: PermissionDeniedError):
        return JSONResponse(status_code=403, content={"error": str(exc)})

    @app.exception_handler(ForgeError)
    async def forge_error(request: Request, exc: ForgeError):
        return JSONResponse(status_code=400, content={"error": str(exc)})

    @app.exception_handler(Exception)
    async def generic_error(request: Request, exc: Exception):
        logger.error(f"Unhandled exception: {exc}", exc_info=True)
        return JSONResponse(status_code=500, content={"error": "Internal server error"})

    return app


app = create_app()
