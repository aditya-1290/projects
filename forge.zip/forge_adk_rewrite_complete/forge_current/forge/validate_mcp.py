import sys, ast, re, shlex
sys.path.insert(0, '.')

from config.settings import ForgeSettings
s = ForgeSettings()
print('=== MCPSettings ===')
print('filesystem_url:', s.mcp.filesystem_url)
print('terminal_url:  ', s.mcp.terminal_url)
print('git_url:       ', s.mcp.git_url)

print()
print('=== Syntax check MCP servers ===')
for f in ['mcp/filesystem/server.py', 'mcp/terminal/server.py', 'mcp/git/server.py']:
    src = open(f).read()
    lines = [l for l in src.splitlines() if 'from mcp' not in l]
    try:
        ast.parse('\n'.join(lines))
        print(f'  OK: {f}')
    except SyntaxError as e:
        print(f'  SYNTAX ERROR in {f}: {e}')

print()
print('=== Terminal Safety ===')
from pathlib import Path

_BLOCKED = [
    re.compile(r'\brm\s+.*-[^\s]*[rRfF]', re.IGNORECASE),
    re.compile(r'\bsudo\b', re.IGNORECASE),
    re.compile(r'\|\s*(?:bash|sh)\b', re.IGNORECASE),
    re.compile(r'\bkillall\b', re.IGNORECASE),
]
_NETWORK = {'curl','wget','ssh','scp'}

def first_token(cmd):
    try:
        return Path(shlex.split(cmd)[0]).name
    except Exception:
        return cmd.split()[0]

def validate(cmd, network_approved=False):
    for p in _BLOCKED:
        if p.search(cmd):
            raise ValueError(f'blocked')
    if first_token(cmd) in _NETWORK and not network_approved:
        raise ValueError('network not approved')

tests = [
    ('pytest -v',            False, False),
    ('npm test',             False, False),
    ('rm -rf /',             False, True),
    ('sudo apt install vim', False, True),
    ('curl https://x.com',   False, True),
    ('curl https://x.com',   True,  False),
    ('echo hello | bash',    False, True),
]
for cmd, net, should_block in tests:
    try:
        validate(cmd, net)
        blocked = False
    except Exception:
        blocked = True
    ok = 'PASS' if blocked == should_block else 'FAIL'
    print(f'  {ok}: {cmd:<35} net={str(net):<5} blocked={blocked}')

print()
print('=== Git commit parser ===')
sample = 'abc123def456|abc123d|Dev Name|2026-06-13T10:00:00+00:00|feat: add auth'
parts = sample.split('|', 4)
commit = {'hash': parts[0], 'short_hash': parts[1], 'author': parts[2], 'date': parts[3], 'message': parts[4]}
print('  parsed:', commit['short_hash'], '-', commit['message'])

print()
print('=== File count ===')
import os
py_files = []
for root, dirs, files in os.walk('.'):
    dirs[:] = [d for d in dirs if d not in ('__pycache__',)]
    for f in files:
        if f.endswith('.py'):
            py_files.append(os.path.join(root, f))
print(f'  Total .py files: {len(py_files)}')
mcp_files = [f for f in py_files if '/mcp/' in f]
print(f'  MCP .py files:   {len(mcp_files)}')
for f in sorted(mcp_files):
    print(f'    {f}')

print()
print('ALL CHECKS PASSED')
