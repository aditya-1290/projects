"""
shared/types.py — All shared dataclasses and TypedDicts used across Forge.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Optional
from uuid import uuid4

class ProjectMode(str, Enum):
    SCRATCH = "scratch"
    INGEST  = "ingest"
    TEST    = "test"

class SessionStatus(str, Enum):
    ACTIVE   = "active"
    RUNNING  = "running"
    PAUSED   = "paused"
    COMPLETE = "complete"
    ERROR    = "error"

class UserType(str, Enum):
    DEVELOPER = "developer"
    TEAM      = "team"
    FOUNDER   = "founder"

class TestDepth(str, Enum):
    UNIT        = "unit"
    INTEGRATION = "integration"
    FULL        = "full"
    AUTO        = "auto"
    CUSTOM      = "custom"

class PatchPermission(str, Enum):
    NONE           = "none"
    ASK_EACH_TIME  = "ask_each_time"
    SESSION_GLOBAL = "session_global"

class PermissionType(str, Enum):
    PATCH         = "patch"
    DELETE        = "delete"
    GIT_COMMIT    = "git_commit"
    TERMINAL_EXEC = "terminal_exec"

class PermissionScope(str, Enum):
    GLOBAL        = "global"
    FILE_SPECIFIC = "file_specific"

class AgentName(str, Enum):
    ORCHESTRATOR   = "orchestrator"
    INTAKE         = "intake"
    ARCHITECT      = "architect"
    CODER          = "coder"
    TESTER         = "tester"
    PATCHER        = "patcher"
    REVIEWER       = "reviewer"
    SECURITY       = "security"
    DEBUGGER       = "debugger"
    ENVIRONMENT    = "environment"
    MEMORY_MANAGER = "memory_manager"

class TaskType(str, Enum):
    GATHER_REQUIREMENTS = "gather_requirements"
    DESIGN_ARCHITECTURE = "design_architecture"
    WRITE_MODULE        = "write_module"
    WRITE_TESTS         = "write_tests"
    RUN_TESTS           = "run_tests"
    APPLY_PATCH         = "apply_patch"
    REVIEW_CODE         = "review_code"
    CHECKPOINT_SAVE     = "checkpoint_save"
    CHECKPOINT_LOAD     = "checkpoint_load"
    INGEST_PROJECT      = "ingest_project"
    SCAN_SECURITY       = "scan_security"
    DEBUG_ERROR         = "debug_error"

class MessagePriority(str, Enum):
    LOW    = "low"
    NORMAL = "normal"
    HIGH   = "high"

class StreamViewMode(str, Enum):
    STATUS = "status"
    CODE   = "code"

@dataclass
class AgentMessage:
    task_type:   TaskType
    from_agent:  AgentName
    to_agent:    AgentName
    payload:     dict[str, Any]
    message_id:  str             = field(default_factory=lambda: str(uuid4()))
    session_id:  str             = field(default_factory=lambda: str(uuid4()))
    priority:    MessagePriority = MessagePriority.NORMAL
    reply_to:    Optional[str]   = None
    ttl_seconds: int             = 300
    timestamp:   datetime        = field(default_factory=datetime.utcnow)

    def to_dict(self) -> dict[str, Any]:
        return {
            "message_id":  self.message_id,
            "session_id":  self.session_id,
            "from_agent":  self.from_agent.value,
            "to_agent":    self.to_agent.value,
            "task_type":   self.task_type.value,
            "priority":    self.priority.value,
            "payload":     self.payload,
            "reply_to":    self.reply_to,
            "ttl_seconds": self.ttl_seconds,
            "timestamp":   self.timestamp.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AgentMessage:
        return cls(
            message_id  = data["message_id"],
            session_id  = data["session_id"],
            from_agent  = AgentName(data["from_agent"]),
            to_agent    = AgentName(data["to_agent"]),
            task_type   = TaskType(data["task_type"]),
            priority    = MessagePriority(data.get("priority", "normal")),
            payload     = data["payload"],
            reply_to    = data.get("reply_to"),
            ttl_seconds = data.get("ttl_seconds", 300),
            timestamp   = datetime.fromisoformat(data["timestamp"]),
        )

@dataclass
class AgentEvent:
    event_type: str
    source:     AgentName
    session_id: str
    data:       dict[str, Any]
    event_id:   str      = field(default_factory=lambda: str(uuid4()))
    timestamp:  datetime = field(default_factory=datetime.utcnow)

@dataclass
class SessionState:
    session_id:         str
    project_name:       str
    project_path:       str
    mode:               ProjectMode
    status:             SessionStatus
    user_type:          UserType
    language_stack:     list[str]       = field(default_factory=list)
    git_enabled:        bool            = False
    test_depth:         TestDepth       = TestDepth.AUTO
    patch_permission:   PatchPermission = PatchPermission.ASK_EACH_TIME
    created_at:         datetime        = field(default_factory=datetime.utcnow)
    updated_at:         datetime        = field(default_factory=datetime.utcnow)
    last_checkpoint_id: Optional[str]   = None

@dataclass
class CheckpointData:
    checkpoint_id:        str
    session_id:           str
    step_number:          int
    agent_who_saved:      AgentName
    summary_of_work_done: str
    files_touched:        list[dict[str, str]]
    next_planned_step:    str
    token_count_at_save:  int
    created_at:           datetime = field(default_factory=datetime.utcnow)

@dataclass
class PermissionRequest:
    session_id:      str
    permission_type: PermissionType
    scope:           PermissionScope
    requested_by:    AgentName
    file_path:       Optional[str] = None
    diff_preview:    Optional[str] = None
    request_id:      str           = field(default_factory=lambda: str(uuid4()))

@dataclass
class PermissionGrant:
    permission_id:   str
    session_id:      str
    permission_type: PermissionType
    scope:           PermissionScope
    file_path:       Optional[str]
    granted_at:      datetime           = field(default_factory=datetime.utcnow)
    expires_at:      Optional[datetime] = None

@dataclass
class ProjectFile:
    file_path:     str
    language:      str
    size_bytes:    int
    last_modified: datetime
    is_config:     bool = False
    is_incomplete: bool = False

@dataclass
class ProjectAnalysis:
    session_id:          str
    project_path:        str
    detected_languages:  list[str]
    detected_frameworks: list[str]
    total_files:         int
    incomplete_files:    list[ProjectFile]
    missing_modules:     list[str]
    config_files:        list[str]
    has_tests:           bool
    has_readme:          bool
    summary:             str

@dataclass
class ArchitecturePlan:
    session_id:     str
    project_name:   str
    language_stack: list[str]
    framework:      str
    directory_tree: dict[str, Any]
    build_order:    list[str]
    dependencies:   list[str]
    approved:       bool = False

@dataclass
class CodeModule:
    file_path:    str
    language:     str
    instructions: str
    context:      str
    depends_on:   list[str]

@dataclass
class StreamChunk:
    session_id: str
    agent:      AgentName
    chunk_type: str
    content:    str
    metadata:   dict[str, Any] = field(default_factory=dict)
    timestamp:  datetime       = field(default_factory=datetime.utcnow)

@dataclass
class StatusUpdate:
    session_id: str
    agent:      AgentName
    action:     str
    target:     str
    completed:  list[str]
    pending:    list[str]
    current:    str
