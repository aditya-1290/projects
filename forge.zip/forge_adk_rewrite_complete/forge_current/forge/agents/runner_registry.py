"""
agents/runner_registry.py
--------------------------
Forge ADK Runner Registry.

Each Forge agent is an ADK LlmAgent wrapped in an ADK Runner.
The Runner handles:
- Session management (per user_id + session_id)
- Message history
- Streaming event generation
- Tool call execution (MCP tools)

This registry owns all runners and exposes a clean interface
for the FastAPI backend to call.

ADK 2.2.0 API:
    Runner(agent, app_name, session_service)
    runner.run_async(user_id, session_id, new_message) → AsyncIterator[Event]

Events have:
    event.author          → "user" | agent_name
    event.content         → Content object
    event.content.parts   → list of Part
    part.text             → str (for text parts)
    event.is_final_response() → bool
"""

from __future__ import annotations

import asyncio
from typing import AsyncIterator, Optional

from google.adk.agents import LlmAgent
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types as genai_types

from agents.adk_config import FORGE_APP_NAME, get_model_id
from shared.logger import get_logger

logger = get_logger(__name__)


class ForgeRunner:
    """
    Wraps a single ADK Runner for one Forge agent.
    Provides a clean async interface for the backend.
    """

    def __init__(self, agent: LlmAgent, session_service: InMemorySessionService):
        self._agent = agent
        self._session_service = session_service
        self._runner = Runner(
            agent           = agent,
            app_name        = FORGE_APP_NAME,
            session_service = session_service,
        )
        logger.info(f"ForgeRunner created: agent={agent.name}")

    async def ensure_session(self, user_id: str, session_id: str) -> None:
        """Create the ADK session if it doesn't exist yet."""
        try:
            self._session_service.get_session(
                app_name   = FORGE_APP_NAME,
                user_id    = user_id,
                session_id = session_id,
            )
        except Exception:
            self._session_service.create_session(
                app_name   = FORGE_APP_NAME,
                user_id    = user_id,
                session_id = session_id,
            )

    async def run(
        self,
        user_id:    str,
        session_id: str,
        message:    str,
    ) -> AsyncIterator[str]:
        """
        Send a message to the agent and stream back text tokens.

        Yields text chunks as they arrive from the model.
        Raises on hard errors.
        """
        await self.ensure_session(user_id, session_id)

        new_message = genai_types.Content(
            role  = "user",
            parts = [genai_types.Part(text=message)],
        )

        async for event in self._runner.run_async(
            user_id    = user_id,
            session_id = session_id,
            new_message = new_message,
        ):
            # Stream text from partial and final responses
            if event.content and event.content.parts:
                for part in event.content.parts:
                    if hasattr(part, "text") and part.text:
                        yield part.text

    async def run_full(
        self,
        user_id:    str,
        session_id: str,
        message:    str,
    ) -> str:
        """
        Send a message and collect the complete response as a single string.
        Convenience wrapper over run() for non-streaming use cases.
        """
        chunks: list[str] = []
        async for chunk in self.run(user_id, session_id, message):
            chunks.append(chunk)
        return "".join(chunks)

    @property
    def agent_name(self) -> str:
        return self._agent.name


class RunnerRegistry:
    """
    Owns all ForgeRunner instances.
    Created once at FastAPI startup.
    """

    def __init__(self) -> None:
        self._runners:         dict[str, ForgeRunner]      = {}
        self._session_service: InMemorySessionService      = InMemorySessionService()

    def register(self, name: str, agent: LlmAgent) -> ForgeRunner:
        """Register an ADK agent and create its runner."""
        runner = ForgeRunner(agent, self._session_service)
        self._runners[name] = runner
        logger.info(f"Registered runner: {name}")
        return runner

    def get(self, name: str) -> ForgeRunner:
        """Get a runner by agent name."""
        if name not in self._runners:
            raise KeyError(f"No runner registered for agent: {name!r}")
        return self._runners[name]

    def names(self) -> list[str]:
        return list(self._runners.keys())

    async def close_all(self) -> None:
        """Clean up all runners (MCPToolset connections, etc.)."""
        for name, runner in self._runners.items():
            try:
                # MCPToolset cleanup if agent has toolsets
                for tool in runner._agent.tools or []:
                    if hasattr(tool, "close"):
                        await tool.close()
            except Exception as e:
                logger.warning(f"Error closing runner {name}: {e}")
        logger.info("All runners closed")
