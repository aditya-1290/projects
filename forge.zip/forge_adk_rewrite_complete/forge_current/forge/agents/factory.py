"""
agents/factory.py
------------------
Forge Agent Factory.

Single entry point for creating all ADK agents and their runners.
Called once during FastAPI lifespan startup.

Usage:
    from agents.factory import create_all_agents

    registry = create_all_agents()
    orchestrator_runner = registry.get("orchestrator")

    # Run a user message through the orchestrator
    async for chunk in orchestrator_runner.run(user_id, session_id, message):
        stream_to_client(chunk)
"""

from __future__ import annotations

from orchestrator.agent import create_orchestrator_agent
from intake.agent      import create_intake_agent
from architect.agent   import create_architect_agent
from coder.agent       import create_coder_agent
from tester.agent      import create_tester_agent
from patcher.agent     import create_patcher_agent
from reviewer.agent    import create_reviewer_agent
from runner_registry   import RunnerRegistry
from shared.logger import get_logger

logger = get_logger(__name__)


def create_all_agents() -> RunnerRegistry:
    """
    Instantiate all Forge agents and register them in a RunnerRegistry.

    Build order matters:
    1. Leaf agents first (they have no sub-agents as tools)
    2. Orchestrator last (it takes all other agents as AgentTools)

    Returns:
        RunnerRegistry with all agents registered and ready.
    """
    logger.info("Creating Forge agents...")

    # --- Leaf agents (no sub-agent tools) ---
    intake    = create_intake_agent()
    architect = create_architect_agent()
    coder     = create_coder_agent()
    tester    = create_tester_agent()
    patcher   = create_patcher_agent()
    reviewer  = create_reviewer_agent()

    # --- Root agent (takes all others as tools) ---
    orchestrator = create_orchestrator_agent(
        intake_agent    = intake,
        architect_agent = architect,
        coder_agent     = coder,
        tester_agent    = tester,
        patcher_agent   = patcher,
        reviewer_agent  = reviewer,
    )

    # --- Register all agents in the registry ---
    registry = RunnerRegistry()

    # Register orchestrator first — it's the primary entry point
    registry.register("orchestrator", orchestrator)

    # Register sub-agents individually so FastAPI can call them directly
    # (useful for the /suggest endpoint, direct test runs, etc.)
    registry.register("intake",    intake)
    registry.register("architect", architect)
    registry.register("coder",     coder)
    registry.register("tester",    tester)
    registry.register("patcher",   patcher)
    registry.register("reviewer",  reviewer)

    logger.info(f"Agents ready: {registry.names()}")
    return registry
