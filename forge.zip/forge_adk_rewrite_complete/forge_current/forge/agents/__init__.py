"""
Forge ADK Agents.
Use agents.factory.create_all_agents() to instantiate everything.
Lazy imports — pure logic submodules can be imported without google.adk.
"""

__all__ = ["create_all_agents", "RunnerRegistry", "ForgeRunner"]

def __getattr__(name):
    if name == "create_all_agents":
        from agents.factory import create_all_agents
        return create_all_agents
    if name in ("RunnerRegistry", "ForgeRunner"):
        from agents.runner_registry import RunnerRegistry, ForgeRunner
        return RunnerRegistry if name == "RunnerRegistry" else ForgeRunner
    raise AttributeError(f"module 'agents' has no attribute {name!r}")
