"""
agents/adk_config.py
---------------------
Shared ADK configuration for all Forge agents.

Provides:
- get_model()          → ADK-compatible model string for llama.cpp via LiteLlm
- get_mcp_toolset()    → MCPToolset connected to a Forge MCP server
- FORGE_APP_NAME       → app name used by all ADK runners

Google ADK 2.2.0 uses LiteLlm under the hood for OpenAI-compatible endpoints.
llama.cpp exposes an OpenAI-compatible API — we connect via:
    model = "openai/forge-local"   (LiteLlm openai-compat prefix)
    OPENAI_API_BASE = http://localhost:8080/v1
    OPENAI_API_KEY  = "local"  (llama.cpp ignores the key)

MCPToolset connects to our streamable-HTTP MCP servers.
"""

from __future__ import annotations

import os
from typing import Optional

from google.adk.tools.mcp_tool.mcp_toolset import (
    MCPToolset,
    StreamableHTTPConnectionParams,
)

from config.settings import get_settings
from shared.logger import get_logger

logger = get_logger(__name__)

FORGE_APP_NAME = "forge"


def configure_llm_env() -> None:
    """
    Set environment variables so ADK's LiteLlm backend can reach
    the llama.cpp server with the OpenAI-compatible API.

    Call once at app startup (in FastAPI lifespan).
    """
    settings = get_settings()
    base_url = settings.model.base_url  # e.g. http://localhost:8080

    # LiteLlm reads these standard env vars
    os.environ.setdefault("OPENAI_API_BASE", f"{base_url}/v1")
    os.environ.setdefault("OPENAI_API_KEY",  "local")  # llama.cpp ignores this

    logger.info(f"LLM configured: OPENAI_API_BASE={os.environ['OPENAI_API_BASE']}")


def get_model_id() -> str:
    """
    Return the ADK model string for the configured llama.cpp model.

    ADK 2.2.0 format for OpenAI-compatible custom endpoints via LiteLlm:
        "openai/<model-name>"

    The model name is what llama.cpp reports — we use the model_id from config.
    For llama.cpp, any string works as the model name since it serves one model.
    """
    settings = get_settings()
    # Strip path separators — ADK/LiteLlm uses this as an identifier
    raw = settings.model.model_id
    # Use just the filename without extension as the model identifier
    from pathlib import Path
    model_name = Path(raw).stem if raw else "forge-local"
    return f"openai/{model_name}"


def get_mcp_toolset(
    url:  str,
    name: str,
    headers: Optional[dict[str, str]] = None,
) -> MCPToolset:
    """
    Create an MCPToolset connected to one of the Forge MCP servers.

    Args:
        url:     Full MCP server URL, e.g. "http://127.0.0.1:8001/mcp"
        name:    Human-readable name for logging (e.g. "filesystem")
        headers: Optional HTTP headers (e.g. for auth in team mode)

    Returns:
        MCPToolset instance ready to pass into an LlmAgent's tools list.
    """
    logger.debug(f"Creating MCPToolset: {name} → {url}")
    return MCPToolset(
        connection_params=StreamableHTTPConnectionParams(
            url=url,
            headers=headers or {},
        )
    )


def get_filesystem_toolset() -> MCPToolset:
    """MCPToolset for the Forge Filesystem MCP server."""
    return get_mcp_toolset(
        url  = get_settings().mcp.filesystem_url,
        name = "filesystem",
    )


def get_terminal_toolset() -> MCPToolset:
    """MCPToolset for the Forge Terminal MCP server."""
    return get_mcp_toolset(
        url  = get_settings().mcp.terminal_url,
        name = "terminal",
    )


def get_git_toolset() -> MCPToolset:
    """MCPToolset for the Forge Git MCP server."""
    return get_mcp_toolset(
        url  = get_settings().mcp.git_url,
        name = "git",
    )
