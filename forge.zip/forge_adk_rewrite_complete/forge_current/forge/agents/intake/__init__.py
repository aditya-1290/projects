__all__ = ["create_intake_agent"]

def __getattr__(name):
    if name == "create_intake_agent":
        from agents.intake.agent import create_intake_agent
        return create_intake_agent
    raise AttributeError(f"module 'agents.intake' has no attribute {name!r}")
