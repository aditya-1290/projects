__all__ = ["create_tester_agent"]

def __getattr__(name):
    if name == "create_tester_agent":
        from agents.tester.agent import create_tester_agent
        return create_tester_agent
    raise AttributeError(f"module 'agents.tester' has no attribute {name!r}")
