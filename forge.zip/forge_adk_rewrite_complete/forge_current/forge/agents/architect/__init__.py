__all__ = ["create_architect_agent"]

def __getattr__(name):
    if name == "create_architect_agent":
        from agents.architect.agent import create_architect_agent
        return create_architect_agent
    raise AttributeError(f"module 'agents.architect' has no attribute {name!r}")
