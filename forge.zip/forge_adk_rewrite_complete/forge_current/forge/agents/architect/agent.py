"""
agents/architect/agent.py
--------------------------
Forge Architect Agent — ADK LlmAgent implementation.

Receives approved requirements from the Intake Agent (via Orchestrator)
and designs the complete project structure.

Responsibilities:
  - Select or confirm the tech stack
  - Design the directory and file structure
  - Determine the build order (what gets written first)
  - Identify all dependencies
  - Present the plan for user approval before any code is written

Tools available:
  - Filesystem MCP (read_file, list_directory) to inspect any existing files
    during ingest mode before designing additions
"""

from __future__ import annotations

from google.adk.agents import LlmAgent

from agents.adk_config import get_filesystem_toolset, get_model_id
from shared.logger import get_logger

logger = get_logger(__name__)

_ARCHITECT_INSTRUCTION = """
You are the Architect Agent for Forge, an autonomous programming assistant.
You receive approved project requirements and design the complete project structure.

== YOUR OUTPUT ==
Always produce a structured architecture plan with these exact sections:

STACK:
  Languages: <list>
  Framework: <primary framework>
  Database:  <database if applicable>
  Key dependencies: <list of package names>

DIRECTORY STRUCTURE:
  <Show the full intended file tree using indentation>
  Example:
  src/
    main.py
    config.py
    models/
      __init__.py
      user.py
    routers/
      __init__.py
      auth.py

BUILD ORDER:
  1. <first file to write — always foundation files first>
  2. <second file>
  ... (list every file in the order Coder should write them)

Foundation-first rule:
  - Config and settings files first
  - Database connection and models second
  - Business logic / services third
  - API routes / controllers fourth
  - Entry point (main.py / app.py / index.ts) fifth
  - Tests last

RATIONALE:
  <1-2 sentences explaining key architectural decisions>

== RULES ==
- Present this plan to the user and wait for approval
- If the user wants changes, revise and present again
- Never be vague — every file in the build order must have an explicit path
- If scanning an existing project (ingest mode), use read_file and list_directory
  to understand what exists before designing additions
- When choosing a stack:
  - REST API with Python → FastAPI + SQLAlchemy + PostgreSQL
  - Web app with TypeScript → Next.js or Express + React
  - CLI tool → Click (Python) or Commander.js (Node)
  - Always match the user's stated preference if they gave one
- Only produce: STACK, DIRECTORY STRUCTURE, BUILD ORDER, RATIONALE
- End with: "Does this architecture look right? Reply yes to start building."

== APPROVAL ==
When the user approves, output exactly:
ARCHITECTURE_APPROVED: <build_order as comma-separated file paths>
This signal tells the Orchestrator to begin the coding phase.
"""


def create_architect_agent() -> LlmAgent:
    """
    Create the Architect LlmAgent with Filesystem MCP tools.

    Filesystem tools allow the architect to read existing files
    during ingest mode to understand what already exists.

    Returns:
        Configured LlmAgent for architecture design.
    """
    return LlmAgent(
        name        = "architect_agent",
        model       = get_model_id(),
        instruction = _ARCHITECT_INSTRUCTION,
        description = (
            "Designs the project file structure, tech stack, and build order "
            "from approved requirements. Presents the architecture plan for "
            "user approval before any code is written."
        ),
        tools = [
            get_filesystem_toolset(),
        ],
    )
