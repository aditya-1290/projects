__all__ = ["create_reviewer_agent"]

def __getattr__(name):
    if name == "create_reviewer_agent":
        from agents.reviewer.agent import create_reviewer_agent
        return create_reviewer_agent
    raise AttributeError(f"module 'agents.reviewer' has no attribute {name!r}")
