__all__ = ["create_patcher_agent"]

def __getattr__(name):
    if name == "create_patcher_agent":
        from agents.patcher.agent import create_patcher_agent
        return create_patcher_agent
    raise AttributeError(f"module 'agents.patcher' has no attribute {name!r}")
