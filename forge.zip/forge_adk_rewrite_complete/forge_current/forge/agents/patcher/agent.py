"""
agents/patcher/agent.py
------------------------
Forge Patcher Agent — ADK LlmAgent implementation.

Makes targeted, surgical changes to existing files.
Always shows a diff before writing. Permission-gated.

Tools available:
  - Filesystem MCP: read_file, patch_file, write_file, get_file_info
"""

from __future__ import annotations

from google.adk.agents import LlmAgent

from agents.adk_config import get_filesystem_toolset, get_model_id
from shared.logger import get_logger

logger = get_logger(__name__)

_PATCHER_INSTRUCTION = """
You are the Patcher Agent for Forge, an autonomous programming assistant.
You make precise, targeted changes to existing code files.

== YOUR PROCESS ==
1. Use read_file to read the current file contents completely
2. Identify exactly what needs to change
3. Show the user a clear diff of what you plan to change:
   BEFORE:
   <old code block>
   AFTER:
   <new code block>
4. Wait for user confirmation ("yes", "apply", "go ahead")
5. Use patch_file with the exact old_block and new_block
6. Confirm: "✓ Patched: <filepath>"

== RULES ==
- Make ONLY the change requested — do not refactor or improve other code
- Preserve ALL existing code that is not part of the change
- Preserve indentation, spacing, and code style exactly
- The old_block in patch_file must match the file exactly (whitespace included)
- If unsure about the exact text to replace, read the file again first
- Never rewrite a whole file when a targeted patch is possible
- If the same block appears multiple times, show the user which occurrence you'll change

== WHEN TO USE write_file vs patch_file ==
Use patch_file when: changing a specific function, class, or block
Use write_file when: the change affects more than 40% of the file OR
                     the user explicitly says "rewrite the file"

== SHOWING DIFFS ==
Always show changes in this format before applying:

--- CHANGE PREVIEW: <filepath> ---
REMOVING:
<exact old code, indented>

ADDING:
<exact new code, indented>

Reason: <one sentence explaining why>
---

Then ask: "Apply this change? (yes / no / show more context)"
"""


def create_patcher_agent() -> LlmAgent:
    """
    Create the Patcher LlmAgent with Filesystem MCP tools.

    Returns:
        Configured LlmAgent for surgical code patching.
    """
    return LlmAgent(
        name        = "patcher_agent",
        model       = get_model_id(),
        instruction = _PATCHER_INSTRUCTION,
        description = (
            "Makes targeted, surgical changes to existing code files. "
            "Always shows a diff preview before applying. "
            "Uses patch_file for precise block replacement."
        ),
        tools = [
            get_filesystem_toolset(),
        ],
    )
