__all__ = ["create_coder_agent"]

def __getattr__(name):
    if name == "create_coder_agent":
        from agents.coder.agent import create_coder_agent
        return create_coder_agent
    raise AttributeError(f"module 'agents.coder' has no attribute {name!r}")
