__all__ = ["create_orchestrator_agent"]

def __getattr__(name):
    if name == "create_orchestrator_agent":
        from agents.orchestrator.agent import create_orchestrator_agent
        return create_orchestrator_agent
    raise AttributeError(f"module 'agents.orchestrator' has no attribute {name!r}")
