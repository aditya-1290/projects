"""
agents/orchestrator/agent.py
------------------------------
Forge Orchestrator Agent — ADK LlmAgent implementation.

The Orchestrator is the root agent. It receives all user messages and
delegates to sub-agents via ADK AgentTool. It decides:
  - Which operating mode the user wants (build / ingest / test)
  - Which specialist agent to call next
  - When to checkpoint
  - How to report progress back to the user

ADK 2.2.0 pattern:
    LlmAgent(name, model, instruction, tools=[AgentTool(sub_agent), ...])

Sub-agents are called as tools — the Orchestrator decides when to invoke them.
"""

from __future__ import annotations

from google.adk.agents import LlmAgent
from google.adk.tools import agent_tool

from agents.adk_config import get_model_id
from agents.orchestrator.mode_detector import detect_mode, mode_from_string
from shared.logger import get_logger

logger = get_logger(__name__)

_ORCHESTRATOR_INSTRUCTION = """
You are the Forge Orchestrator — the root agent of Forge, an autonomous programming assistant.

Your role:
1. Understand what the user wants to do
2. Detect the operating mode:
   - BUILD (scratch): User wants to build a new project from description
   - INGEST (complete): User has an existing project they want completed
   - TEST: User wants tests written for their project
3. Delegate to the correct specialist agent
4. Keep the user informed of progress at every step
5. Never write code yourself — always delegate to the Coder Agent
6. Never gather requirements yourself — always delegate to the Intake Agent

Workflow for BUILD mode:
  1. Call intake_agent to gather requirements and get user approval
  2. Call architect_agent to design the structure (after requirements approved)
  3. Call coder_agent for each file in the build order
  4. Call reviewer_agent after each file (optional, for quality gate)

Workflow for INGEST mode:
  1. Call intake_agent in ingest mode to scan the project
  2. Ask user what to focus on
  3. Call coder_agent for completion tasks

Workflow for TEST mode:
  1. Call tester_agent with the project details
  2. Report test results to the user

Always:
- Tell the user what you're doing before you do it
- After each agent completes, summarise what happened
- Ask the user if they want to continue before moving to the next major step
- If something goes wrong, explain clearly and ask how to proceed
"""


def create_orchestrator_agent(
    intake_agent:    LlmAgent,
    architect_agent: LlmAgent,
    coder_agent:     LlmAgent,
    tester_agent:    LlmAgent,
    patcher_agent:   LlmAgent,
    reviewer_agent:  LlmAgent,
) -> LlmAgent:
    """
    Create the Orchestrator LlmAgent with all sub-agents as tools.

    ADK AgentTool wraps each sub-agent so the Orchestrator can call them
    as if they were regular tools. The sub-agent runs to completion and
    returns its response as a tool result.

    Args:
        intake_agent:    Handles requirement gathering and project ingestion.
        architect_agent: Designs project structure and build order.
        coder_agent:     Writes code files via Filesystem MCP.
        tester_agent:    Generates and runs tests via Terminal MCP.
        patcher_agent:   Applies targeted patches to existing files.
        reviewer_agent:  Reviews code quality and generates suggestions.

    Returns:
        Configured LlmAgent for the Orchestrator.
    """
    return LlmAgent(
        name        = "orchestrator",
        model       = get_model_id(),
        instruction = _ORCHESTRATOR_INSTRUCTION,
        description = "Root Forge agent — routes tasks to specialist agents",
        tools       = [
            agent_tool.AgentTool(agent=intake_agent),
            agent_tool.AgentTool(agent=architect_agent),
            agent_tool.AgentTool(agent=coder_agent),
            agent_tool.AgentTool(agent=tester_agent),
            agent_tool.AgentTool(agent=patcher_agent),
            agent_tool.AgentTool(agent=reviewer_agent),
        ],
    )
