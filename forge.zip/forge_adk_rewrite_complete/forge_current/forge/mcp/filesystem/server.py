"""
mcp/filesystem/server.py
--------------------------
Forge Filesystem MCP Server — real MCP server using mcp 1.27.2 + FastMCP.
Transport: streamable-HTTP (default port 8001).

Tools exposed:
  read_file(path)                        → file contents
  write_file(path, content)              → write result
  patch_file(path, old_block, new_block) → patch result
  delete_file(path)                      → delete result (soft-delete to trash)
  list_directory(path)                   → directory listing
  read_multiple_files(paths)             → multiple file contents
  create_directory(path)                 → create result
  file_exists(path)                      → bool
  get_file_info(path)                    → metadata

All paths are sandboxed to the project root passed via env var FORGE_PROJECT_ROOT.
Attempts to read/write outside root are rejected.

Run:
    FORGE_PROJECT_ROOT=/path/to/project python -m mcp.filesystem.server
    # or via the launcher in scripts/start_mcp.py
"""

from __future__ import annotations

import difflib
import os
import shutil
from datetime import datetime
from pathlib import Path
from typing import Optional

from mcp.server.fastmcp import FastMCP

# ---------------------------------------------------------------------------
# Server setup
# ---------------------------------------------------------------------------

mcp = FastMCP(
    name        = "forge-filesystem",
    version     = "1.0.0",
    description = "Forge sandboxed filesystem operations",
)

# ---------------------------------------------------------------------------
# Root resolution — set once at startup from env var
# ---------------------------------------------------------------------------

def _get_root() -> Path:
    """
    Return the sandboxed project root.
    Always reads from env so the server can be pointed at any project.
    """
    root = os.environ.get("FORGE_PROJECT_ROOT", "")
    if not root:
        raise ValueError(
            "FORGE_PROJECT_ROOT environment variable is not set. "
            "Set it to the absolute path of the project directory."
        )
    return Path(root).resolve()


def _safe_path(relative_or_absolute: str) -> Path:
    """
    Resolve a path safely within the project root.
    Raises ValueError if the resolved path escapes the root.
    """
    root = _get_root()
    candidate = (root / relative_or_absolute).resolve()
    try:
        candidate.relative_to(root)
    except ValueError:
        raise ValueError(
            f"Path escape attempt denied: {relative_or_absolute!r} "
            f"resolves outside project root ({root})"
        )
    return candidate


def _trash_dir() -> Path:
    """Return the trash directory for soft-deleted files."""
    return _get_root() / ".forge" / "trash"


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------

@mcp.tool()
def read_file(path: str) -> str:
    """
    Read the contents of a file within the project.

    Args:
        path: File path relative to the project root (e.g. "src/main.py").

    Returns:
        The file contents as a string.
    """
    target = _safe_path(path)
    if not target.exists():
        raise FileNotFoundError(f"File not found: {path}")
    if not target.is_file():
        raise ValueError(f"Path is not a file: {path}")
    return target.read_text(encoding="utf-8", errors="replace")


@mcp.tool()
def read_multiple_files(paths: list[str]) -> dict[str, str]:
    """
    Read multiple files at once.

    Args:
        paths: List of file paths relative to the project root.

    Returns:
        Dict mapping each path to its contents (or an error message).
    """
    results: dict[str, str] = {}
    for path in paths:
        try:
            results[path] = read_file(path)
        except Exception as e:
            results[path] = f"ERROR: {e}"
    return results


@mcp.tool()
def write_file(path: str, content: str, create_dirs: bool = True) -> dict:
    """
    Write content to a file within the project.
    Creates parent directories if they don't exist (when create_dirs=True).
    Creates a .forge_bak backup of any existing file before overwriting.

    Args:
        path:        File path relative to the project root.
        content:     The content to write.
        create_dirs: Whether to create missing parent directories.

    Returns:
        Dict with keys: path, size_bytes, backed_up, created_dirs.
    """
    target = _safe_path(path)

    backed_up = False
    dirs_created = False

    # Create parent directories
    if create_dirs and not target.parent.exists():
        target.parent.mkdir(parents=True, exist_ok=True)
        dirs_created = True

    # Backup existing file
    if target.exists():
        backup = target.with_suffix(target.suffix + ".forge_bak")
        shutil.copy2(target, backup)
        backed_up = True

    # Write atomically via temp file
    tmp = target.with_suffix(target.suffix + ".forge_tmp")
    try:
        tmp.write_text(content, encoding="utf-8")
        tmp.replace(target)
    except Exception:
        tmp.unlink(missing_ok=True)
        raise

    return {
        "path":         str(target.relative_to(_get_root())),
        "size_bytes":   len(content.encode("utf-8")),
        "backed_up":    backed_up,
        "created_dirs": dirs_created,
    }


@mcp.tool()
def patch_file(path: str, old_block: str, new_block: str) -> dict:
    """
    Replace a block of text in an existing file.
    The old_block must appear exactly once in the file.
    Creates a .forge_bak backup before patching.

    Args:
        path:      File path relative to the project root.
        old_block: The exact block of text to replace.
        new_block: The replacement text.

    Returns:
        Dict with keys: path, diff, occurrences_found.
    """
    target = _safe_path(path)
    if not target.exists():
        raise FileNotFoundError(f"File not found: {path}")

    original = target.read_text(encoding="utf-8", errors="replace")
    count = original.count(old_block)

    if count == 0:
        raise ValueError(
            f"old_block not found in {path}. "
            f"Ensure the block matches the file exactly (including whitespace)."
        )
    if count > 1:
        raise ValueError(
            f"old_block appears {count} times in {path}. "
            f"Provide a more specific block to avoid ambiguity."
        )

    patched = original.replace(old_block, new_block, 1)

    # Generate diff for audit/display
    diff = "".join(difflib.unified_diff(
        original.splitlines(keepends=True),
        patched.splitlines(keepends=True),
        fromfile=f"a/{path}",
        tofile=f"b/{path}",
        n=3,
    ))

    # Backup + write
    backup = target.with_suffix(target.suffix + ".forge_bak")
    shutil.copy2(target, backup)
    target.write_text(patched, encoding="utf-8")

    return {
        "path":               str(target.relative_to(_get_root())),
        "diff":               diff,
        "occurrences_found":  count,
    }


@mcp.tool()
def delete_file(path: str) -> dict:
    """
    Soft-delete a file by moving it to .forge/trash/ (recoverable).
    Hard delete is not supported — Forge never permanently destroys files.

    Args:
        path: File path relative to the project root.

    Returns:
        Dict with keys: path, trash_path, deleted_at.
    """
    target = _safe_path(path)
    if not target.exists():
        raise FileNotFoundError(f"File not found: {path}")
    if not target.is_file():
        raise ValueError(f"Path is not a file: {path}")

    # Move to trash with timestamp to avoid collisions
    trash = _trash_dir()
    trash.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    trash_name = f"{timestamp}_{target.name}"
    trash_path = trash / trash_name

    shutil.move(str(target), str(trash_path))

    return {
        "path":       path,
        "trash_path": str(trash_path.relative_to(_get_root())),
        "deleted_at": timestamp,
    }


@mcp.tool()
def restore_file(trash_name: str, restore_to: str) -> dict:
    """
    Restore a soft-deleted file from .forge/trash/.

    Args:
        trash_name:  The filename in .forge/trash/ (as returned by delete_file).
        restore_to:  Path relative to project root to restore to.

    Returns:
        Dict with keys: restored_to, success.
    """
    trash_path = _safe_path(f".forge/trash/{trash_name}")
    if not trash_path.exists():
        raise FileNotFoundError(f"Trash file not found: {trash_name}")

    dest = _safe_path(restore_to)
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(trash_path), str(dest))

    return {"restored_to": restore_to, "success": True}


@mcp.tool()
def list_directory(
    path: str = ".",
    recursive: bool = False,
    include_hidden: bool = False,
) -> dict:
    """
    List files and directories within the project.

    Args:
        path:           Directory path relative to project root (default: root).
        recursive:      If True, walk subdirectories.
        include_hidden: If True, include files/dirs starting with '.'.

    Returns:
        Dict with keys: path, files (list), dirs (list), total_files.
    """
    target = _safe_path(path)
    if not target.exists():
        raise FileNotFoundError(f"Directory not found: {path}")
    if not target.is_dir():
        raise ValueError(f"Path is not a directory: {path}")

    root = _get_root()
    files: list[str] = []
    dirs:  list[str] = []

    _EXCLUDE = {".git", "__pycache__", "node_modules", ".venv", "venv", ".forge"}

    if recursive:
        for dirpath, dirnames, filenames in os.walk(target):
            dirnames[:] = [
                d for d in dirnames
                if (include_hidden or not d.startswith("."))
                and d not in _EXCLUDE
            ]
            for fname in filenames:
                if include_hidden or not fname.startswith("."):
                    fpath = Path(dirpath) / fname
                    files.append(str(fpath.relative_to(root)))
            for dname in dirnames:
                dpath = Path(dirpath) / dname
                dirs.append(str(dpath.relative_to(root)))
    else:
        for item in sorted(target.iterdir()):
            if not include_hidden and item.name.startswith("."):
                continue
            rel = str(item.relative_to(root))
            if item.is_dir():
                dirs.append(rel)
            else:
                files.append(rel)

    return {
        "path":        path,
        "files":       sorted(files),
        "dirs":        sorted(dirs),
        "total_files": len(files),
    }


@mcp.tool()
def create_directory(path: str) -> dict:
    """
    Create a directory (and all parents) within the project.

    Args:
        path: Directory path relative to the project root.

    Returns:
        Dict with keys: path, created.
    """
    target = _safe_path(path)
    already_existed = target.exists()
    target.mkdir(parents=True, exist_ok=True)
    return {
        "path":    path,
        "created": not already_existed,
    }


@mcp.tool()
def file_exists(path: str) -> bool:
    """
    Check whether a file or directory exists within the project.

    Args:
        path: Path relative to the project root.

    Returns:
        True if it exists, False otherwise.
    """
    try:
        target = _safe_path(path)
        return target.exists()
    except ValueError:
        return False


@mcp.tool()
def get_file_info(path: str) -> dict:
    """
    Get metadata for a file or directory.

    Args:
        path: Path relative to the project root.

    Returns:
        Dict with keys: path, exists, is_file, is_dir, size_bytes,
        modified_at, extension, line_count (for text files).
    """
    try:
        target = _safe_path(path)
    except ValueError as e:
        return {"path": path, "exists": False, "error": str(e)}

    if not target.exists():
        return {"path": path, "exists": False}

    stat = target.stat()
    info: dict = {
        "path":        path,
        "exists":      True,
        "is_file":     target.is_file(),
        "is_dir":      target.is_dir(),
        "size_bytes":  stat.st_size,
        "modified_at": datetime.utcfromtimestamp(stat.st_mtime).isoformat(),
        "extension":   target.suffix.lower(),
    }

    if target.is_file():
        try:
            content = target.read_text(encoding="utf-8", errors="replace")
            info["line_count"] = content.count("\n") + 1
        except Exception:
            info["line_count"] = None

    return info


@mcp.tool()
def search_files(
    pattern: str,
    path: str = ".",
    file_extension: Optional[str] = None,
) -> dict:
    """
    Search for files containing a text pattern.

    Args:
        pattern:        Text to search for (case-sensitive).
        path:           Directory to search (default: project root).
        file_extension: If set, only search files with this extension (e.g. ".py").

    Returns:
        Dict with keys: pattern, matches (list of {file, line_number, line}).
    """
    target = _safe_path(path)
    root   = _get_root()
    matches: list[dict] = []

    _EXCLUDE = {".git", "__pycache__", "node_modules", ".venv", "venv"}

    for dirpath, dirnames, filenames in os.walk(target):
        dirnames[:] = [d for d in dirnames if d not in _EXCLUDE]
        for fname in filenames:
            if file_extension and not fname.endswith(file_extension):
                continue
            fpath = Path(dirpath) / fname
            try:
                for i, line in enumerate(
                    fpath.read_text(encoding="utf-8", errors="replace").splitlines(),
                    start=1,
                ):
                    if pattern in line:
                        matches.append({
                            "file":        str(fpath.relative_to(root)),
                            "line_number": i,
                            "line":        line.rstrip(),
                        })
            except Exception:
                continue

    return {
        "pattern": pattern,
        "matches": matches,
        "total":   len(matches),
    }


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Forge Filesystem MCP Server")
    parser.add_argument("--host", default="127.0.0.1", help="Host to bind to")
    parser.add_argument("--port", type=int, default=8001, help="Port to listen on")
    parser.add_argument("--project-root", help="Project root (overrides env var)")
    args = parser.parse_args()

    if args.project_root:
        os.environ["FORGE_PROJECT_ROOT"] = args.project_root

    print(f"Forge Filesystem MCP Server starting on {args.host}:{args.port}")
    print(f"Project root: {os.environ.get('FORGE_PROJECT_ROOT', 'NOT SET')}")

    mcp.run(
        transport = "streamable-http",
        host      = args.host,
        port      = args.port,
        path      = "/mcp",
    )
