"""
mcp/git/server.py
------------------
Forge Git MCP Server — real MCP server using mcp 1.27.2 + FastMCP.
Transport: streamable-HTTP (default port 8003).

Tools exposed:
  git_status()                                → structured status
  git_diff(staged, path)                      → unified diff
  git_add(path)                               → stage result
  git_commit(message, stage_all)              → commit hash
  git_log(n, path)                            → list of commits
  git_branches()                              → branch list
  git_create_branch(name, checkout)           → result
  git_checkout(branch)                        → result
  git_push(remote, branch, set_upstream)      → result
  git_pull(remote, branch)                    → result
  git_init()                                  → result
  is_git_repo()                               → bool
  git_auto_commit(file_paths, description)    → commit hash or null

Permission model:
  - Read ops (status, diff, log, branches): always allowed
  - Commit: allowed (caller already checked permission via FastAPI)
  - Push/pull: allowed (caller must have confirmed each time)

Run:
    FORGE_PROJECT_ROOT=/path/to/project python -m mcp.git.server
"""

from __future__ import annotations

import os
import subprocess
from pathlib import Path
from typing import Optional

from mcp.server.fastmcp import FastMCP

# ---------------------------------------------------------------------------
# Server setup
# ---------------------------------------------------------------------------

mcp = FastMCP(
    name        = "forge-git",
    version     = "1.0.0",
    description = "Forge git operations",
)

# ---------------------------------------------------------------------------
# Root resolution
# ---------------------------------------------------------------------------

def _get_root() -> Path:
    root = os.environ.get("FORGE_PROJECT_ROOT", "")
    if not root:
        raise ValueError("FORGE_PROJECT_ROOT environment variable is not set.")
    return Path(root).resolve()


def _git(*args: str, timeout: int = 60) -> str:
    """
    Run a git command in the project root.
    Returns stdout. Raises ValueError on non-zero exit.
    """
    root = _get_root()
    cmd = ["git"] + list(args)

    try:
        result = subprocess.run(
            cmd,
            cwd            = str(root),
            capture_output = True,
            text           = True,
            encoding       = "utf-8",
            errors         = "replace",
            timeout        = timeout,
        )
    except FileNotFoundError:
        raise ValueError(
            "git is not installed or not in PATH."
        )
    except subprocess.TimeoutExpired:
        raise ValueError(f"git {args[0]} timed out after {timeout}s")

    if result.returncode != 0:
        raise ValueError(
            f"git {' '.join(args)} failed (exit {result.returncode}): "
            f"{result.stderr.strip()[:300]}"
        )

    return result.stdout


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------

@mcp.tool()
def is_git_repo() -> bool:
    """
    Check if the project root is a git repository.

    Returns:
        True if it's a git repo, False otherwise.
    """
    try:
        _git("rev-parse", "--git-dir")
        return True
    except ValueError:
        return False


@mcp.tool()
def git_init() -> dict:
    """
    Initialise a new git repository in the project root.

    Returns:
        Dict with: success, message, project_root.
    """
    try:
        output = _git("init")
        return {
            "success":      True,
            "message":      output.strip(),
            "project_root": str(_get_root()),
        }
    except ValueError as e:
        return {"success": False, "message": str(e)}


@mcp.tool()
def git_status() -> dict:
    """
    Get the current git status of the project.

    Returns:
        Dict with: branch, is_clean, staged (list), unstaged (list),
        untracked (list), ahead (int), behind (int), has_remote (bool).
    """
    # Branch
    try:
        branch = _git("rev-parse", "--abbrev-ref", "HEAD").strip()
    except ValueError:
        branch = "HEAD (no commits yet)"

    # Short status
    try:
        short = _git("status", "--short").strip()
    except ValueError:
        short = ""

    staged: list[str]   = []
    unstaged: list[str] = []
    untracked: list[str] = []

    for line in short.splitlines():
        if len(line) < 3:
            continue
        xy   = line[:2]
        path = line[3:].strip().strip('"')
        x, y = xy[0], xy[1]

        if x in ("A", "M", "D", "R", "C") and x != " ":
            staged.append(path)
        if y in ("M", "D") and y != " ":
            unstaged.append(path)
        if xy == "??":
            untracked.append(path)

    # Ahead/behind
    ahead, behind, has_remote = 0, 0, False
    try:
        info = _git(
            "rev-list", "--left-right", "--count",
            "HEAD...@{u}"
        ).strip().split()
        if len(info) == 2:
            ahead, behind = int(info[0]), int(info[1])
            has_remote = True
    except ValueError:
        pass

    return {
        "branch":     branch,
        "is_clean":   not (staged or unstaged or untracked),
        "staged":     staged,
        "unstaged":   unstaged,
        "untracked":  untracked,
        "ahead":      ahead,
        "behind":     behind,
        "has_remote": has_remote,
    }


@mcp.tool()
def git_diff(staged: bool = False, path: Optional[str] = None) -> str:
    """
    Get the unified diff for the project (or a specific file).

    Args:
        staged: If True, show staged diff (--cached). Default: unstaged.
        path:   Limit diff to this file path (relative to project root).

    Returns:
        Unified diff as a string. Empty string if no changes.
    """
    args = ["diff"]
    if staged:
        args.append("--cached")
    if path:
        args += ["--", path]
    try:
        return _git(*args)
    except ValueError:
        return ""


@mcp.tool()
def git_add(path: str = ".") -> dict:
    """
    Stage files for commit.

    Args:
        path: File or directory to stage (default: all changes).

    Returns:
        Dict with: success, staged_path.
    """
    try:
        _git("add", path)
        return {"success": True, "staged_path": path}
    except ValueError as e:
        return {"success": False, "error": str(e)}


@mcp.tool()
def git_commit(
    message:   str,
    stage_all: bool = False,
) -> dict:
    """
    Create a commit.

    Args:
        message:   Commit message (must not be empty).
        stage_all: If True, run git add -A before committing.

    Returns:
        Dict with: success, commit_hash, message, error (if failed).
    """
    if not message.strip():
        return {"success": False, "error": "Commit message cannot be empty"}

    try:
        if stage_all:
            _git("add", "-A")

        _git("commit", "-m", message)
        commit_hash = _git("rev-parse", "HEAD").strip()

        return {
            "success":     True,
            "commit_hash": commit_hash,
            "short_hash":  commit_hash[:8],
            "message":     message,
        }
    except ValueError as e:
        return {"success": False, "error": str(e)}


@mcp.tool()
def git_log(n: int = 10, path: Optional[str] = None) -> list[dict]:
    """
    Get recent commit history.

    Args:
        n:    Number of commits to return (default: 10).
        path: Limit log to this file path (optional).

    Returns:
        List of dicts with: hash, short_hash, author, date, message.
    """
    fmt = "%H|%h|%an|%ai|%s"
    args = ["log", f"-{n}", f"--format={fmt}"]
    if path:
        args += ["--", path]

    try:
        output = _git(*args)
    except ValueError:
        return []

    commits = []
    for line in output.strip().splitlines():
        parts = line.split("|", 4)
        if len(parts) == 5:
            commits.append({
                "hash":       parts[0],
                "short_hash": parts[1],
                "author":     parts[2],
                "date":       parts[3],
                "message":    parts[4],
            })
    return commits


@mcp.tool()
def git_branches() -> dict:
    """
    List all local branches.

    Returns:
        Dict with: current (str), branches (list of str).
    """
    try:
        current = _git("rev-parse", "--abbrev-ref", "HEAD").strip()
        output  = _git("branch", "--format=%(refname:short)")
        branches = [b.strip() for b in output.splitlines() if b.strip()]
        return {"current": current, "branches": branches}
    except ValueError as e:
        return {"current": "", "branches": [], "error": str(e)}


@mcp.tool()
def git_create_branch(name: str, checkout: bool = True) -> dict:
    """
    Create a new branch, optionally checking it out.

    Args:
        name:     Branch name.
        checkout: If True (default), check out the new branch.

    Returns:
        Dict with: success, branch, checked_out.
    """
    try:
        if checkout:
            _git("checkout", "-b", name)
        else:
            _git("branch", name)
        return {"success": True, "branch": name, "checked_out": checkout}
    except ValueError as e:
        return {"success": False, "error": str(e)}


@mcp.tool()
def git_checkout(branch: str) -> dict:
    """
    Check out an existing branch.

    Args:
        branch: Branch name to check out.

    Returns:
        Dict with: success, branch.
    """
    try:
        _git("checkout", branch)
        return {"success": True, "branch": branch}
    except ValueError as e:
        return {"success": False, "error": str(e)}


@mcp.tool()
def git_push(
    remote:       str  = "origin",
    branch:       Optional[str] = None,
    set_upstream: bool = False,
) -> dict:
    """
    Push commits to a remote repository.
    The caller must have obtained explicit user approval before calling this.

    Args:
        remote:       Remote name (default: origin).
        branch:       Branch to push (default: current branch).
        set_upstream: If True, set upstream tracking with -u.

    Returns:
        Dict with: success, remote, branch, output.
    """
    try:
        current = _git("rev-parse", "--abbrev-ref", "HEAD").strip()
        target_branch = branch or current

        args = ["push"]
        if set_upstream:
            args += ["-u", remote, target_branch]
        else:
            args += [remote, target_branch]

        output = _git(*args, timeout=120)
        return {
            "success": True,
            "remote":  remote,
            "branch":  target_branch,
            "output":  output.strip(),
        }
    except ValueError as e:
        return {"success": False, "error": str(e)}


@mcp.tool()
def git_pull(
    remote: str = "origin",
    branch: Optional[str] = None,
) -> dict:
    """
    Pull changes from a remote repository.

    Args:
        remote: Remote name (default: origin).
        branch: Branch to pull (default: current tracking branch).

    Returns:
        Dict with: success, output.
    """
    try:
        args = ["pull", remote]
        if branch:
            args.append(branch)
        output = _git(*args, timeout=120)
        return {"success": True, "output": output.strip()}
    except ValueError as e:
        return {"success": False, "error": str(e)}


@mcp.tool()
def git_auto_commit(
    file_paths:  list[str],
    description: str,
) -> dict:
    """
    Stage specific files and create an auto-generated commit.
    Used by the Coder Agent after writing each file.

    Args:
        file_paths:  List of file paths (relative to project root) to stage.
        description: Short description for the commit message.

    Returns:
        Dict with: success, commit_hash (or None if nothing to commit).
    """
    # Stage files
    stage_errors = []
    for path in file_paths:
        try:
            _git("add", path)
        except ValueError as e:
            stage_errors.append(f"{path}: {e}")

    # Check if anything is staged
    try:
        staged_diff = _git("diff", "--cached", "--stat")
        if not staged_diff.strip():
            return {
                "success":     True,
                "commit_hash": None,
                "message":     "Nothing staged to commit",
            }
    except ValueError:
        pass

    # Commit
    message = f"forge: {description}"
    try:
        _git("commit", "-m", message)
        commit_hash = _git("rev-parse", "HEAD").strip()
        return {
            "success":      True,
            "commit_hash":  commit_hash,
            "short_hash":   commit_hash[:8],
            "message":      message,
            "stage_errors": stage_errors,
        }
    except ValueError as e:
        return {"success": False, "error": str(e), "stage_errors": stage_errors}


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Forge Git MCP Server")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8003)
    parser.add_argument("--project-root")
    args = parser.parse_args()

    if args.project_root:
        os.environ["FORGE_PROJECT_ROOT"] = args.project_root

    print(f"Forge Git MCP Server starting on {args.host}:{args.port}")
    print(f"Project root: {os.environ.get('FORGE_PROJECT_ROOT', 'NOT SET')}")

    mcp.run(
        transport = "streamable-http",
        host      = args.host,
        port      = args.port,
        path      = "/mcp",
    )
