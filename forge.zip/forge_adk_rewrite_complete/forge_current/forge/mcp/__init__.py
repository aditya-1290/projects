"""
Forge MCP Servers — real MCP protocol servers using mcp 1.27.2 + FastMCP.
Transport: streamable-HTTP.

Ports (defaults):
  8001 — forge-filesystem
  8002 — forge-terminal
  8003 — forge-git

Start all servers via: python scripts/start_mcp_servers.py
"""
MCP_FILESYSTEM_PORT = 8001
MCP_TERMINAL_PORT   = 8002
MCP_GIT_PORT        = 8003
MCP_DEFAULT_HOST    = "127.0.0.1"
