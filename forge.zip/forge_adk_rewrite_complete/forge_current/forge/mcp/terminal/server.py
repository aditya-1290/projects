"""
mcp/terminal/server.py
-----------------------
Forge Terminal MCP Server — real MCP server using mcp 1.27.2 + FastMCP.
Transport: streamable-HTTP (default port 8002).

Tools exposed:
  run_command(command, timeout, network_approved)  → execution result
  run_tests(framework, path, extra_args)           → test results
  run_linter(language)                             → lint results
  run_formatter(language)                          → format results
  install_dependencies(language)                   → install results
  which(executable)                                → path or null
  is_available(executable)                         → bool
  get_environment_info()                           → python/node/etc versions

All commands run with cwd = FORGE_PROJECT_ROOT.
Destructive commands and directory traversal are blocked unconditionally.
Network commands require network_approved=True.

Run:
    FORGE_PROJECT_ROOT=/path/to/project python -m mcp.terminal.server
"""

from __future__ import annotations

import os
import re
import shlex
import subprocess
import time
from pathlib import Path
from typing import Optional

from mcp.server.fastmcp import FastMCP

# ---------------------------------------------------------------------------
# Server setup
# ---------------------------------------------------------------------------

mcp = FastMCP(
    name        = "forge-terminal",
    version     = "1.0.0",
    description = "Forge scoped terminal execution",
)

# ---------------------------------------------------------------------------
# Root resolution
# ---------------------------------------------------------------------------

def _get_root() -> Path:
    root = os.environ.get("FORGE_PROJECT_ROOT", "")
    if not root:
        raise ValueError("FORGE_PROJECT_ROOT environment variable is not set.")
    return Path(root).resolve()


# ---------------------------------------------------------------------------
# Safety: pre-approved, blocked, network commands
# ---------------------------------------------------------------------------

_PRE_APPROVED = {
    "python", "python3", "pip", "pip3", "pytest", "py.test",
    "mypy", "ruff", "black", "isort", "flake8", "pylint",
    "coverage", "uvicorn", "gunicorn",
    "node", "npm", "npx", "yarn", "pnpm",
    "tsc", "eslint", "prettier", "jest", "vitest", "vite",
    "next", "nuxt",
    "mvn", "gradle", "java", "javac",
    "go", "cargo", "rustc",
    "ruby", "bundle", "rake", "rspec",
    "make", "cmake",
    "cat", "head", "tail", "grep", "find", "ls", "tree",
    "wc", "diff", "echo", "pwd", "git",
}

_NETWORK_COMMANDS = {
    "curl", "wget", "fetch", "nc", "netcat",
    "ssh", "scp", "rsync", "ftp", "sftp",
    "ping", "traceroute", "nmap",
}

_BLOCKED_PATTERNS = [
    re.compile(r"\brm\s+.*-[^\s]*[rRfF]", re.IGNORECASE),
    re.compile(r"\brmdir\b", re.IGNORECASE),
    re.compile(r"\bshred\b", re.IGNORECASE),
    re.compile(r"\bdd\b.*\bof=", re.IGNORECASE),
    re.compile(r"\bmkfs\b", re.IGNORECASE),
    re.compile(r"\bsudo\b", re.IGNORECASE),
    re.compile(r"\bsu\s", re.IGNORECASE),
    re.compile(r"\bchmod\s+777\b", re.IGNORECASE),
    re.compile(r"\bkillall\b", re.IGNORECASE),
    re.compile(r"\bkill\s+-9\b", re.IGNORECASE),
    re.compile(r"\bsystemctl\b", re.IGNORECASE),
    re.compile(r"[`$]\("),
    re.compile(r"\|\s*(?:bash|sh)\b", re.IGNORECASE),
    re.compile(r">\s*/dev/sd"),
    re.compile(r"\bformat\b.*\b[A-Z]:", re.IGNORECASE),
]


def _first_token(command: str) -> str:
    try:
        tokens = shlex.split(command)
        if tokens:
            return Path(tokens[0]).name
    except ValueError:
        pass
    parts = command.strip().split()
    return Path(parts[0]).name if parts else ""


def _validate_command(command: str, network_approved: bool = False) -> None:
    """Raise ValueError if command is unsafe."""
    stripped = command.strip()
    if not stripped:
        raise ValueError("Empty command")

    for pattern in _BLOCKED_PATTERNS:
        if pattern.search(stripped):
            raise ValueError(
                f"Command blocked by Forge safety policy: {stripped[:80]!r}"
            )

    # Directory traversal check
    cd_match = re.search(r'\bcd\s+([^\s;&|]+)', stripped)
    if cd_match:
        target = cd_match.group(1)
        root = _get_root()
        try:
            resolved = (root / target).resolve()
            resolved.relative_to(root)
        except ValueError:
            raise ValueError(
                f"Directory traversal denied: 'cd {target}' escapes project root"
            )

    first = _first_token(stripped)
    if first in _NETWORK_COMMANDS and not network_approved:
        raise ValueError(
            f"Network command '{first}' requires network_approved=True"
        )


def _pick_timeout(command: str) -> int:
    first = _first_token(command.strip())
    if first in {"npm", "yarn", "pnpm", "mvn", "gradle", "cargo", "pip", "pip3"}:
        return 600
    if first in {"pytest", "jest", "vitest", "rspec", "go", "cargo"}:
        return 300
    return 120


def _exec(command: str, timeout: Optional[int] = None) -> dict:
    """Run a command, return structured result dict."""
    root = _get_root()
    effective_timeout = timeout or _pick_timeout(command)
    start = time.monotonic()

    try:
        result = subprocess.run(
            command,
            shell       = True,
            cwd         = str(root),
            capture_output = True,
            text        = True,
            encoding    = "utf-8",
            errors      = "replace",
            timeout     = effective_timeout,
        )
        duration_ms = (time.monotonic() - start) * 1000
        return {
            "command":     command,
            "exit_code":   result.returncode,
            "stdout":      result.stdout or "",
            "stderr":      result.stderr or "",
            "success":     result.returncode == 0,
            "timed_out":   False,
            "duration_ms": round(duration_ms, 1),
        }

    except subprocess.TimeoutExpired:
        return {
            "command":     command,
            "exit_code":   -1,
            "stdout":      "",
            "stderr":      f"Command timed out after {effective_timeout}s",
            "success":     False,
            "timed_out":   True,
            "duration_ms": effective_timeout * 1000,
        }

    except FileNotFoundError:
        return {
            "command":   command,
            "exit_code": 127,
            "stdout":    "",
            "stderr":    f"Command not found: {command.split()[0]!r}",
            "success":   False,
            "timed_out": False,
        }


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------

@mcp.tool()
def run_command(
    command:          str,
    timeout:          Optional[int]  = None,
    network_approved: bool           = False,
) -> dict:
    """
    Run a shell command inside the project directory.
    Pre-approved build/test/lint commands run immediately.
    Network commands require network_approved=True.
    Destructive commands are always blocked.

    Args:
        command:          Shell command to execute.
        timeout:          Timeout in seconds (auto-selected if None).
        network_approved: Set True only when the user has explicitly approved
                          network access for this specific invocation.

    Returns:
        Dict with: command, exit_code, stdout, stderr, success, timed_out, duration_ms.
    """
    _validate_command(command, network_approved=network_approved)
    return _exec(command, timeout=timeout)


@mcp.tool()
def run_tests(
    framework:  str = "auto",
    path:       str = ".",
    extra_args: str = "",
) -> dict:
    """
    Run the project test suite. Always pre-approved.
    Auto-detects the test framework if framework='auto'.

    Args:
        framework:  One of: auto, pytest, jest, vitest, cargo, go, rspec, mvn, gradle.
        path:       Test path or directory (default: current directory).
        extra_args: Additional arguments to pass to the test runner.

    Returns:
        Same structure as run_command, plus a parsed 'summary' field.
    """
    if framework == "auto":
        framework = _detect_test_framework()

    commands = {
        "pytest":  f"pytest {path} -v {extra_args}".strip(),
        "jest":    f"npx jest {path} --verbose {extra_args}".strip(),
        "vitest":  f"npx vitest run {path} {extra_args}".strip(),
        "cargo":   f"cargo test {extra_args}".strip(),
        "go":      f"go test ./... {extra_args}".strip(),
        "rspec":   f"bundle exec rspec {path} {extra_args}".strip(),
        "mvn":     f"mvn test {extra_args}".strip(),
        "gradle":  f"./gradlew test {extra_args}".strip(),
    }

    cmd = commands.get(framework, f"pytest {path} -v".strip())
    result = _exec(cmd, timeout=300)
    result["framework"] = framework
    result["summary"] = _parse_test_summary(
        result["stdout"] + result["stderr"], framework
    )
    return result


@mcp.tool()
def run_linter(language: str = "python") -> dict:
    """
    Run the appropriate linter for the given language.

    Args:
        language: One of: python, javascript, typescript, go, rust.

    Returns:
        Same structure as run_command.
    """
    commands = {
        "python":     "ruff check . --fix",
        "javascript": "npx eslint . --fix",
        "typescript": "npx eslint . --fix",
        "go":         "go vet ./...",
        "rust":       "cargo clippy",
    }
    cmd = commands.get(language, "ruff check .")
    return _exec(cmd, timeout=60)


@mcp.tool()
def run_formatter(language: str = "python") -> dict:
    """
    Run the appropriate formatter for the given language.

    Args:
        language: One of: python, javascript, typescript, rust, go.

    Returns:
        Same structure as run_command.
    """
    commands = {
        "python":     "black . && isort .",
        "javascript": "npx prettier --write .",
        "typescript": "npx prettier --write .",
        "rust":       "cargo fmt",
        "go":         "gofmt -w .",
    }
    cmd = commands.get(language, "black .")
    return _exec(cmd, timeout=60)


@mcp.tool()
def install_dependencies(language: str = "python") -> dict:
    """
    Install project dependencies. Always pre-approved.

    Args:
        language: One of: python, javascript, typescript, rust, go, java.

    Returns:
        Same structure as run_command.
    """
    commands = {
        "python":     "pip install -r requirements.txt",
        "javascript": "npm install",
        "typescript": "npm install",
        "rust":       "cargo fetch",
        "go":         "go mod download",
        "java":       "mvn dependency:resolve",
    }
    cmd = commands.get(language, "pip install -r requirements.txt")
    return _exec(cmd, timeout=600)


@mcp.tool()
def which(executable: str) -> Optional[str]:
    """
    Find the full path of an executable.

    Args:
        executable: The executable name (e.g. "python3").

    Returns:
        Full path string, or None if not found.
    """
    result = _exec(f"which {executable}", timeout=5)
    if result["success"] and result["stdout"].strip():
        return result["stdout"].strip()
    return None


@mcp.tool()
def is_available(executable: str) -> bool:
    """
    Check if an executable is available in PATH.

    Args:
        executable: The executable name.

    Returns:
        True if available, False otherwise.
    """
    return which(executable) is not None


@mcp.tool()
def get_environment_info() -> dict:
    """
    Get information about the runtime environment.

    Returns:
        Dict with: python_version, node_version, npm_version,
        project_root, platform.
    """
    import sys, platform

    def _ver(cmd: str) -> Optional[str]:
        r = _exec(cmd, timeout=5)
        return (r["stdout"] or r["stderr"]).strip() if r["success"] else None

    return {
        "python_version": sys.version.split()[0],
        "node_version":   _ver("node --version"),
        "npm_version":    _ver("npm --version"),
        "go_version":     _ver("go version"),
        "rust_version":   _ver("rustc --version"),
        "project_root":   str(_get_root()),
        "platform":       platform.system(),
        "cwd":            str(Path.cwd()),
    }


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _detect_test_framework() -> str:
    """Auto-detect test framework from project files."""
    root = _get_root()

    if (root / "Cargo.toml").exists():
        return "cargo"
    if (root / "go.mod").exists():
        return "go"
    if (root / "pom.xml").exists():
        return "mvn"
    if (root / "build.gradle").exists() or (root / "build.gradle.kts").exists():
        return "gradle"

    if (root / "package.json").exists():
        try:
            import json
            pkg = json.loads((root / "package.json").read_text())
            deps = {**pkg.get("dependencies", {}), **pkg.get("devDependencies", {})}
            if "vitest" in deps:
                return "vitest"
            if "jest" in deps:
                return "jest"
        except Exception:
            pass
        return "jest"

    return "pytest"  # default


def _parse_test_summary(output: str, framework: str) -> str:
    """Extract a one-line summary from test output."""
    lines = output.strip().splitlines()
    reversed_lines = list(reversed(lines))

    if framework in ("pytest", "auto"):
        for line in reversed_lines:
            if any(w in line for w in ("passed", "failed", "error", "warning")):
                return line.strip()
    elif framework in ("jest", "vitest"):
        for line in reversed_lines:
            if "Tests:" in line or "Test Suites:" in line:
                return line.strip()
    elif framework in ("go", "cargo"):
        for line in reversed_lines:
            if line.startswith(("ok", "FAIL", "test result")):
                return line.strip()

    for line in reversed_lines:
        if line.strip():
            return line.strip()
    return "Tests complete."


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Forge Terminal MCP Server")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8002)
    parser.add_argument("--project-root")
    args = parser.parse_args()

    if args.project_root:
        os.environ["FORGE_PROJECT_ROOT"] = args.project_root

    print(f"Forge Terminal MCP Server starting on {args.host}:{args.port}")
    print(f"Project root: {os.environ.get('FORGE_PROJECT_ROOT', 'NOT SET')}")

    mcp.run(
        transport = "streamable-http",
        host      = args.host,
        port      = args.port,
        path      = "/mcp",
    )
