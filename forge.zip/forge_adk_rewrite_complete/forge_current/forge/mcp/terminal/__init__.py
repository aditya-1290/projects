"""Forge Terminal MCP Server (streamable-HTTP)."""
