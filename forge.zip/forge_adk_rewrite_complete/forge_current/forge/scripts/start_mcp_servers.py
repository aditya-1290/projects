"""
scripts/start_mcp_servers.py
------------------------------
Starts all three Forge MCP servers as concurrent subprocesses.

Usage:
    python scripts/start_mcp_servers.py --project-root /path/to/project

    # or with custom ports:
    python scripts/start_mcp_servers.py \\
        --project-root /path/to/project \\
        --fs-port 8001 \\
        --terminal-port 8002 \\
        --git-port 8003

Each server runs in its own subprocess. Ctrl+C shuts down all three.
The FastAPI backend reads MCP URLs from config and connects ADK agents to them.
"""

from __future__ import annotations

import argparse
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

# Project root for imports
_HERE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_HERE))


def start_server(
    module:       str,
    host:         str,
    port:         int,
    project_root: str,
    label:        str,
) -> subprocess.Popen:
    """Start a single MCP server as a subprocess."""
    env = {**os.environ, "FORGE_PROJECT_ROOT": project_root}
    cmd = [
        sys.executable, "-m", module,
        "--host", host,
        "--port", str(port),
        "--project-root", project_root,
    ]
    proc = subprocess.Popen(
        cmd,
        cwd = str(_HERE),
        env = env,
        stdout = subprocess.PIPE,
        stderr = subprocess.STDOUT,
        text   = True,
        bufsize = 1,
    )
    print(f"  [{label}] PID={proc.pid} → http://{host}:{port}/mcp")
    return proc


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Start all Forge MCP servers"
    )
    parser.add_argument(
        "--project-root", required=True,
        help="Absolute path to the project directory"
    )
    parser.add_argument("--host",          default="127.0.0.1")
    parser.add_argument("--fs-port",       type=int, default=8001)
    parser.add_argument("--terminal-port", type=int, default=8002)
    parser.add_argument("--git-port",      type=int, default=8003)
    args = parser.parse_args()

    project_root = str(Path(args.project_root).resolve())
    if not Path(project_root).exists():
        print(f"ERROR: Project root does not exist: {project_root}")
        sys.exit(1)

    print(f"\nForge MCP Servers")
    print(f"Project root: {project_root}\n")

    servers = [
        ("mcp.filesystem.server", args.host, args.fs_port,       "filesystem"),
        ("mcp.terminal.server",   args.host, args.terminal_port, "terminal  "),
        ("mcp.git.server",        args.host, args.git_port,      "git       "),
    ]

    procs: list[subprocess.Popen] = []
    for module, host, port, label in servers:
        proc = start_server(module, host, port, project_root, label)
        procs.append(proc)
        time.sleep(0.3)  # small stagger to avoid port conflicts on startup

    print(f"\nAll 3 MCP servers running. Press Ctrl+C to stop.\n")

    # Print MCP URLs for pasting into config
    print("MCP endpoint URLs (add these to ~/.forge/config.json):")
    print(f'  "mcp_filesystem_url": "http://{args.host}:{args.fs_port}/mcp"')
    print(f'  "mcp_terminal_url":   "http://{args.host}:{args.terminal_port}/mcp"')
    print(f'  "mcp_git_url":        "http://{args.host}:{args.git_port}/mcp"')
    print()

    # Stream output from all subprocesses + wait for Ctrl+C
    def shutdown(sig, frame):
        print("\nShutting down MCP servers...")
        for p in procs:
            try:
                p.terminate()
            except Exception:
                pass
        time.sleep(1)
        for p in procs:
            try:
                p.kill()
            except Exception:
                pass
        print("All MCP servers stopped.")
        sys.exit(0)

    signal.signal(signal.SIGINT,  shutdown)
    signal.signal(signal.SIGTERM, shutdown)

    # Keep alive and forward stdout from servers
    import threading

    def forward(proc: subprocess.Popen, label: str) -> None:
        for line in proc.stdout:
            print(f"[{label.strip()}] {line}", end="")

    threads = []
    labels  = ["filesystem", "terminal  ", "git       "]
    for proc, label in zip(procs, labels):
        t = threading.Thread(target=forward, args=(proc, label), daemon=True)
        t.start()
        threads.append(t)

    # Wait for any server to exit unexpectedly
    while True:
        for i, proc in enumerate(procs):
            rc = proc.poll()
            if rc is not None:
                print(f"\nWARNING: [{labels[i].strip()}] server exited with code {rc}")
        time.sleep(2)


if __name__ == "__main__":
    main()
