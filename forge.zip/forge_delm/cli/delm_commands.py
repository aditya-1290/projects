"""
CLI commands for DELM mode.
"""

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.live import Live
from rich.text import Text
from typing import Optional
import asyncio

console = Console()
delm_app = typer.Typer(help="DELM decentralized coordination mode")


@delm_app.command()
def start(
        requirements: str = typer.Argument(..., help="Project requirements"),
        workers: int = typer.Option(3, help="Number of parallel workers"),
        architecture: Optional[str] = typer.Option(None, help="Path to architecture file")
):
    """Start DELM-coordinated build"""
    asyncio.run(_start_delm(requirements, workers, architecture))


async def _start_delm(requirements: str, workers: int, arch_path: Optional[str]):
    from delm.integration import DELMIntegration
    from storage.sqlite_backend import SQLiteBackend
    from llm.llama_client import LlamaClient

    console.print(Panel(
        "[bold green]Starting DELM Mode[/bold green]\n\n"
        f"Workers: {workers}\n"
        f"Requirements: {requirements[:100]}...",
        title="FORGE DELM"
    ))

    # Initialize components
    storage = SQLiteBackend()
    llm = LlamaClient()

    # Load architecture if provided
    architecture = None
    if arch_path:
        import json
        with open(arch_path) as f:
            architecture = json.load(f)

    # Create DELM integration
    delm = DELMIntegration(
        session_id="cli_session",
        storage_backend=storage,
        llm_client=llm,
        config={
            "project_path": ".",
            "task_description": requirements
        }
    )

    # Start with live status display
    with Live(generate_status_display(delm), refresh_per_second=2) as live:
        await delm.start_delm_mode(requirements, architecture, workers)

        # Wait for completion
        result = await delm.wait_for_completion(timeout=600)

        live.update(generate_final_display(result))


def generate_status_display(delm) -> Table:
    """Generate live status table"""
    # This would be called in a loop to get live updates
    table = Table(title="DELM Status")
    table.add_column("Component", style="cyan")
    table.add_column("Status", style="green")
    table.add_column("Details")

    # Shared context stats
    ctx = delm.shared_context.get_context_summary()
    table.add_row(
        "Shared Context",
        str(ctx["total_entries"]) + " entries",
        f"Pending: {ctx['pending_verification']}"
    )

    # Task queue stats
    queue = delm.task_queue.get_queue_status()
    table.add_row(
        "Task Queue",
        str(queue["total_tasks"]) + " tasks",
        f"Pending: {queue['by_status'].get('pending', 0)}, "
        f"Claimed: {queue['by_status'].get('claimed', 0)}"
    )

    # Workers
    for wid, winfo in delm.workers.items():
        task = winfo._current_task
        task_str = task.description[:30] + "..." if task else "Idle"
        table.add_row(
            f"Worker: {wid}",
            "Working" if task else "Idle",
            task_str
        )

    return table


def generate_final_display(result: dict) -> Panel:
    """Generate final result display"""
    return Panel(
        f"[bold green]Build Complete[/bold green]\n\n"
        f"Files modified: {result.get('files_modified', [])}\n"
        f"Facts established: {result.get('facts_established', 0)}\n"
        f"Failures avoided: {result.get('failures_avoided', 0)}\n"
        f"Constraints maintained: {result.get('constraints_maintained', 0)}\n\n"
        f"[bold]Summary:[/bold]\n{result.get('summary', 'No summary')}",
        title="DELM Result"
    )


@delm_app.command()
def status():
    """Show current DELM session status"""
    # Implementation would connect to running session
    console.print("[yellow]Connect to running session to see status[/yellow]")


@delm_app.command()
def context():
    """Show shared context entries"""
    # Implementation would display verified gists
    console.print("[yellow]Connect to running session to see context[/yellow]")


@delm_app.command()
def constraint(
        constraint: str = typer.Argument(..., help="Constraint to add")
):
    """Add a user constraint to shared context"""
    console.print(f"[green]Added constraint: {constraint}[/green]")
