"""
DELM configuration options.
"""

from dataclasses import dataclass
from typing import Optional, List


@dataclass
class DELMConfig:
    """Configuration for DELM coordination layer"""

    # Gist settings
    gist_max_tokens: int = 100
    summary_max_tokens: int = 500

    # Verification settings
    verification_enabled: bool = True
    verification_confidence_threshold: float = 0.5
    auto_regenerate_on_reject: bool = True
    max_regeneration_attempts: int = 2

    # Task queue settings
    task_claim_timeout: float = 30.0
    task_max_retries: int = 2
    max_concurrent_workers: int = 8

    # Context settings
    max_context_entries: int = 100
    context_eviction_policy: str = "lru"  # lru, fifo, by_type

    # Worker settings
    default_workers: int = 3
    worker_types: List[str] = None

    # Failure tracking
    track_failures: bool = True
    failure_expiry_hours: int = 24

    def __post_init__(self):
        if self.worker_types is None:
            self.worker_types = ["coder", "coder", "tester"]


# Default configuration
DEFAULT_DELM_CONFIG = DELMConfig()

# Preset configurations for different use cases
DELM_PRESETS = {
    "fast": DELMConfig(
        gist_max_tokens=50,
        verification_enabled=False,  # Skip verification for speed
        default_workers=5,
        worker_types=["coder"] * 4 + ["tester"]
    ),
    "thorough": DELMConfig(
        gist_max_tokens=150,
        summary_max_tokens=1000,
        verification_confidence_threshold=0.7,
        default_workers=2,
        worker_types=["coder", "tester"]
    ),
    "research": DELMConfig(
        gist_max_tokens=200,
        summary_max_tokens=1500,
        verification_enabled=True,
        verification_confidence_threshold=0.8,
        default_workers=4,
        worker_types=["analyzer"] * 3 + ["coder"]
    )
}
