"""
Integration layer to connect DELM components with existing FORGE backend.
"""

from typing import Optional, Dict, Any
from delm.shared_context import SharedContext, EntryType
from delm.task_queue import TaskQueue
from delm.verification_gate import VerificationGate
from agents.orchestrator.delm_orchestrator import DELMOrchestrator
from agents.coder.delm_worker import DELMWorker
import asyncio


class DELMIntegration:
    """
    Manages DELM coordination layer within FORGE.
    Bridges existing FORGE components with DELM architecture.
    """

    def __init__(self, session_id: str, storage_backend, llm_client, config: Dict):
        self.session_id = session_id
        self.llm = llm_client
        self.config = config

        # Initialize DELM components
        self.shared_context = SharedContext(session_id, storage_backend)
        self.task_queue = TaskQueue(session_id)
        self.verification_gate = VerificationGate(llm_client, self.shared_context)
        self.orchestrator = DELMOrchestrator(
            session_id,
            self.shared_context,
            self.task_queue,
            self.verification_gate,
            llm_client
        )

        self.workers: Dict[str, DELMWorker] = {}
        self._orchestrator_running = False

    async def start_delm_mode(self,
                              requirements: str,
                              architecture: Optional[Dict] = None,
                              num_workers: int = 3):
        """
        Start DELM-coordinated work on a task.
        """
        # Initialize tasks
        task_ids = await self.orchestrator.initialize_tasks(requirements, architecture)

        # Start verification loop
        await self.orchestrator.start_verification_loop()

        # Start task generation loop
        await self.orchestrator.start_task_generation_loop()

        # Spawn workers
        worker_types = ["coder", "coder", "tester"]  # 2 coders, 1 tester
        for i in range(min(num_workers, len(worker_types))):
            worker_id = f"{worker_types[i]}_worker_{i}"
            worker = DELMWorker(
                worker_id=worker_id,
                worker_type=worker_types[i],
                shared_context=self.shared_context,
                task_queue=self.task_queue,
                tools=self._get_tools_for_worker(worker_types[i]),
                llm_client=self.llm
            )
            self.workers[worker_id] = worker

            # Start worker in background
            asyncio.create_task(worker.run())

        self._orchestrator_running = True

    def _get_tools_for_worker(self, worker_type: str) -> Dict[str, Any]:
        """Get available tools for a worker type"""
        # Import FORGE's existing MCP tools
        from mcp.filesystem_mcp import FilesystemMCP
        from mcp.terminal_mcp import TerminalMCP

        tools = {
            "filesystem": FilesystemMCP(project_root=self.config.get("project_path", ".")),
            "terminal": TerminalMCP(project_root=self.config.get("project_path", "."))
        }

        if worker_type == "coder" and self.config.get("self_healing_enabled"):
            from quality.self_healing.healer import SelfHealer
            tools["self_heal"] = SelfHealer(tools["terminal"], self.llm)

        return tools

    async def wait_for_completion(self, timeout: float = 300) -> Dict[str, Any]:
        """Wait for all tasks to complete and get final result"""
        import time
        start_time = time.time()

        while time.time() - start_time < timeout:
            status = self.task_queue.get_queue_status()

            # Check if all tasks are completed
            pending = status["by_status"].get("pending", 0)
            claimed = status["by_status"].get("claimed", 0)
            blocked = status["by_status"].get("blocked", 0)

            if pending == 0 and claimed == 0 and blocked == 0:
                # All done, finalize
                result = await self.orchestrator.finalize(
                    self.config.get("task_description", "Build project")
                )
                return result

            await asyncio.sleep(2)

        # Timeout - return current state
        return {
            "status": "timeout",
            "context_state": self.shared_context.get_context_summary(),
            "queue_state": self.task_queue.get_queue_status()
        }

    async def stop(self):
        """Stop all DELM components"""
        # Stop workers
        for worker in self.workers.values():
            worker.stop()

        # Stop orchestrator loops
        await self.orchestrator.stop()

        self._orchestrator_running = False

    async def get_status(self) -> Dict[str, Any]:
        """Get current DELM status"""
        return {
            "shared_context": self.shared_context.get_context_summary(),
            "task_queue": self.task_queue.get_queue_status(),
            "workers": {
                wid: {
                    "type": w.worker_type,
                    "current_task": w._current_task.to_dict() if w._current_task else None
                }
                for wid, w in self.workers.items()
            }
        }

    async def inject_user_constraint(self, constraint: str):
        """Allow user to inject a constraint into shared context"""
        gist = await self.shared_context.submit_update(
            agent_id="user",
            entry_type=EntryType.CONSTRAINT,
            content=constraint,
            metadata={"source": "user_direct"}
        )
        return gist.gist_id
