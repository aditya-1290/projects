"""
DELM-Style Orchestrator
Transformed from central controller to task generator and finalizer.
"""

from typing import Optional, List, Dict, Any
from delm.shared_context import SharedContext, EntryType
from delm.task_queue import TaskQueue, TaskPriority, TaskStatus
from delm.verification_gate import VerificationGate
import asyncio


class DELMOrchestrator:
    """
    DELM-style orchestrator that:
    1. Generates initial tasks from requirements
    2. Monitors shared context for completion
    3. Generates additional tasks when needed
    4. Finalizes answer from verified shared state

    Does NOT route tasks to agents - they claim from queue.
    """

    def __init__(self,
                 session_id: str,
                 shared_context: SharedContext,
                 task_queue: TaskQueue,
                 verification_gate: VerificationGate,
                 llm_client):
        self.session_id = session_id
        self.context = shared_context
        self.task_queue = task_queue
        self.verifier = verification_gate
        self.llm = llm_client
        self._verification_loop = None
        self._task_generation_loop = None

    async def initialize_tasks(self,
                               requirements: str,
                               architecture_plan: Optional[Dict] = None) -> List[str]:
        """
        Generate initial tasks from requirements.
        This is the DELM "GENERATESUBTASKS" step.
        """
        task_ids = []

        if architecture_plan:
            # Generate tasks from architecture
            tasks = await self._generate_tasks_from_architecture(architecture_plan)
        else:
            # Generate tasks from requirements
            tasks = await self._generate_tasks_from_requirements(requirements)

        for task_spec in tasks:
            task = await self.task_queue.enqueue(
                task_type=task_spec["type"],
                description=task_spec["description"],
                priority=task_spec.get("priority", TaskPriority.NORMAL),
                dependencies=task_spec.get("dependencies", []),
                metadata=task_spec.get("metadata", {})
            )
            task_ids.append(task.task_id)

        return task_ids

    async def _generate_tasks_from_architecture(self,
                                                architecture: Dict) -> List[Dict]:
        """Generate build tasks from architecture plan"""
        tasks = []
        files = architecture.get("files", [])
        modules = architecture.get("modules", [])

        # Create tasks for each file/module
        for i, file_spec in enumerate(files):
            task = {
                "type": "write_module",
                "description": f"Implement {file_spec['path']}: {file_spec.get('description', '')}",
                "priority": TaskPriority.HIGH if file_spec.get("core", False) else TaskPriority.NORMAL,
                "dependencies": [],  # Will be filled based on imports
                "metadata": {
                    "file_path": file_spec["path"],
                    "language": file_spec.get("language"),
                    "module_type": file_spec.get("type", "module")
                }
            }
            tasks.append(task)

        # Add dependency analysis task
        if files:
            tasks.append({
                "type": "analyze_dependencies",
                "description": "Analyze dependencies and update task dependencies",
                "priority": TaskPriority.HIGH,
                "dependencies": [],
                "metadata": {"file_paths": [f["path"] for f in files]}
            })

        # Add testing task
        tasks.append({
            "type": "write_tests",
            "description": "Generate test suite for implemented modules",
            "priority": TaskPriority.NORMAL,
            "dependencies": [],  # Depends on all write_module tasks
            "metadata": {"test_depth": "unit"}
        })

        return tasks

    async def _generate_tasks_from_requirements(self,
                                                requirements: str) -> List[Dict]:
        """Generate tasks directly from requirements using LLM"""
        prompt = f"""Given these requirements, generate a list of implementation tasks.
Each task should be a discrete unit of work.

Requirements:
{requirements}

Respond in JSON format as a list of tasks:
[
    {{
        "type": "task_type",
        "description": "what to do",
        "priority": "high/normal/low",
        "depends_on": ["description of dependency"]
    }}
]

Task types: write_module, analyze_code, write_tests, research, configure
"""

        response = await self.llm.generate(prompt, temperature=0.2)

        # Parse and normalize
        import json
        try:
            raw_tasks = json.loads(response)
            tasks = []
            for t in raw_tasks:
                task = {
                    "type": t.get("type", "write_module"),
                    "description": t["description"],
                    "priority": TaskPriority[t.get("priority", "normal").upper()],
                    "dependencies": [],  # Resolve later
                    "metadata": {}
                }
                tasks.append(task)
            return tasks
        except:
            # Fallback: single task
            return [{
                "type": "write_module",
                "description": requirements,
                "priority": TaskPriority.NORMAL,
                "dependencies": [],
                "metadata": {}
            }]

    async def generate_more_tasks(self) -> bool:
        """
        DELM's "GENERATEMORESUBTASKS" step.
        Check if current shared context requires more work.
        """
        # Read current context
        context = await self.context.read_context()
        queue_status = self.task_queue.get_queue_status()

        # If queue is empty and there are incomplete goals, generate more
        if queue_status["by_status"].get("pending", 0) == 0:
            # Check for gaps in shared context
            gaps = await self._identify_gaps(context)

            if gaps:
                for gap in gaps:
                    await self.task_queue.enqueue(
                        task_type=gap["type"],
                        description=gap["description"],
                        priority=gap.get("priority", TaskPriority.NORMAL),
                        metadata=gap.get("metadata", {})
                    )
                return True

        return False

    async def _identify_gaps(self, context) -> List[Dict]:
        """Identify gaps in shared context that need addressing"""
        gaps = []

        # Check for failed tasks that might need retry with different approach
        fails = [c for c in context if c.entry_type == EntryType.FAIL]
        for fail in fails:
            if "retry" not in fail.metadata.get("handled", []):
                gaps.append({
                    "type": "retry_with_alternative",
                    "description": f"Retry with different approach: {fail.content}",
                    "priority": TaskPriority.NORMAL,
                    "metadata": {"original_fail_id": fail.gist_id}
                })

        # Check for constraints that need implementation
        constraints = [c for c in context if c.entry_type == EntryType.CONSTRAINT]
        for constraint in constraints:
            if not constraint.metadata.get("implemented"):
                gaps.append({
                    "type": "implement_constraint",
                    "description": f"Ensure constraint is implemented: {constraint.content}",
                    "priority": TaskPriority.HIGH,
                    "metadata": {"constraint_id": constraint.gist_id}
                })

        # Check if tests exist
        test_facts = [c for c in context
                      if c.entry_type == EntryType.FACT
                      and "test" in c.content.lower()]
        if not test_facts:
            gaps.append({
                "type": "write_tests",
                "description": "Generate tests for implemented code",
                "priority": TaskPriority.NORMAL
            })

        return gaps

    async def finalize(self, task_description: str) -> Dict[str, Any]:
        """
        DELM's "FINALIZE" step.
        Produce final answer from verified shared context.
        """
        # Read all verified context
        context = await self.context.read_context()

        # Organize by type
        facts = [c for c in context if c.entry_type == EntryType.FACT]
        fails = [c for c in context if c.entry_type == EntryType.FAIL]
        patches = [c for c in context if c.entry_type == EntryType.PATCH_SUMMARY]
        constraints = [c for c in context if c.entry_type == EntryType.CONSTRAINT]

        # Generate summary
        prompt = f"""Based on the following verified shared context, provide a final summary of work completed.

Original task: {task_description}

Verified Facts:
{self._format_entries(facts)}

Failed Approaches (avoided):
{self._format_entries(fails)}

Patches Applied:
{self._format_entries(patches)}

Constraints Maintained:
{self._format_entries(constraints)}

Provide a structured summary of:
1. What was built/changed
2. Key decisions made
3. What was tried and didn't work
4. Any remaining concerns
"""

        summary = await self.llm.generate(prompt, temperature=0.3)

        return {
            "summary": summary,
            "files_modified": [p.metadata.get("files", "") for p in patches if p.metadata],
            "facts_established": len(facts),
            "failures_avoided": len(fails),
            "constraints_maintained": len(constraints),
            "context_state": self.context.get_context_summary()
        }

    def _format_entries(self, entries) -> str:
        """Format entries for LLM prompt"""
        if not entries:
            return "None"
        return "\n".join(f"- [{e.entry_type.value}] {e.content}" for e in entries)

    async def start_verification_loop(self):
        """Background loop to verify pending entries"""

        async def loop():
            while True:
                pending = await self.context.get_pending_verifications()
                for gist in pending:
                    result = await self.verifier.verify_update(gist)
                    await self.context.admit_entry(
                        gist.gist_id,
                        result.result.value == "verified",
                        result.feedback
                    )
                await asyncio.sleep(1)  # Check every second

        self._verification_loop = asyncio.create_task(loop())

    async def start_task_generation_loop(self):
        """Background loop to generate more tasks when needed"""

        async def loop():
            while True:
                await self.generate_more_tasks()
                await asyncio.sleep(5)  # Check every 5 seconds

        self._task_generation_loop = asyncio.create_task(loop())

    async def stop(self):
        """Stop background loops"""
        if self._verification_loop:
            self._verification_loop.cancel()
        if self._task_generation_loop:
            self._task_generation_loop.cancel()
