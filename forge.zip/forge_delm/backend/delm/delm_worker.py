"""
DELM-Style Worker Agent
Claims tasks, reads shared context, performs work, submits verified updates.
"""

from typing import Optional, Dict, Any, List
from delm.shared_context import SharedContext, EntryType
from delm.task_queue import TaskQueue, Task
from delm.verification_gate import VerificationResult
import traceback


class DELMWorker:
    """
    A worker agent that:
    1. Claims tasks from queue (not assigned)
    2. Reads shared context for relevant info
    3. Performs local reasoning/work
    4. Submits compact verified updates
    """

    def __init__(self,
                 worker_id: str,
                 worker_type: str,  # "coder", "tester", "analyzer"
                 shared_context: SharedContext,
                 task_queue: TaskQueue,
                 tools: Dict[str, Any],
                 llm_client):
        self.worker_id = worker_id
        self.worker_type = worker_type
        self.context = shared_context
        self.task_queue = task_queue
        self.tools = tools
        self.llm = llm_client
        self._current_task: Optional[Task] = None
        self._running = False

    async def run(self,
                  preferred_types: Optional[List[str]] = None,
                  max_tasks: int = -1):
        """
        Main worker loop.
        Keep claiming and completing tasks.
        """
        self._running = True
        tasks_completed = 0

        while self._running:
            if max_tasks > 0 and tasks_completed >= max_tasks:
                break

            # Claim a task
            task = await self.task_queue.claim_task(
                self.worker_id,
                preferred_types
            )

            if not task:
                # No tasks available, wait a bit
                import asyncio
                await asyncio.sleep(2)
                continue

            self._current_task = task

            try:
                # Execute the task
                result = await self._execute_task(task)

                # Complete the task
                await self.task_queue.complete_task(
                    task.task_id,
                    self.worker_id,
                    result_gist_id=result.get("gist_id"),
                    success=True
                )

                tasks_completed += 1

            except Exception as e:
                # Log failure to shared context
                await self._submit_failure(task, str(e), traceback.format_exc())

                # Mark task as failed (may retry)
                await self.task_queue.complete_task(
                    task.task_id,
                    self.worker_id,
                    success=False
                )

            self._current_task = None

    async def _execute_task(self, task: Task) -> Dict[str, Any]:
        """Execute a single task"""
        # Read relevant shared context
        context = await self._read_relevant_context(task)

        # Build prompt with context
        prompt = self._build_work_prompt(task, context)

        # Execute based on task type
        if task.task_type == "write_module":
            return await self._execute_write_module(task, prompt, context)
        elif task.task_type == "write_tests":
            return await self._execute_write_tests(task, prompt, context)
        elif task.task_type == "analyze_code":
            return await self._execute_analyze(task, prompt, context)
        elif task.task_type == "run_tests":
            return await self._execute_run_tests(task, prompt, context)
        else:
            return await self._execute_generic(task, prompt, context)

    async def _read_relevant_context(self, task: Task) -> List:
        """Read shared context relevant to this task"""
        # Get all verified context
        all_context = await self.context.read_context()

        # Filter for relevance based on task
        relevant = []

        # Always include failures (to avoid repeating)
        fails = [c for c in all_context if c.entry_type == EntryType.FAIL]
        relevant.extend(fails)

        # Include constraints
        constraints = [c for c in all_context if c.entry_type == EntryType.CONSTRAINT]
        relevant.extend(constraints)

        # Include facts related to task's file/module
        file_path = task.metadata.get("file_path")
        if file_path:
            for c in all_context:
                if c.entry_type == EntryType.FACT and file_path in str(c.metadata.get("files", "")):
                    relevant.append(c)

        # If task has context requirements, unfold those
        for gist_id in task.context_requirements:
            unfolded = await self.context.unfold_gist(gist_id, "summary")
            relevant.append(unfolded)

        return relevant

    def _build_work_prompt(self, task: Task, context: List) -> str:
        """Build prompt including shared context"""
        context_section = ""
        if context:
            context_section = "\n\n## Shared Context (from other workers)\n"
            for c in context:
                if isinstance(c, dict):
                    # Unfolded context
                    context_section += f"- {c.get('gist', {}).get('content', '')}\n"
                else:
                    context_section += f"- [{c.entry_type.value}] {c.content}\n"

        return f"""You are a {self.worker_type} worker agent.
Your task: {task.description}

{context_section}

## Your Task
{task.description}

{f"File: {task.metadata.get('file_path')}" if task.metadata.get('file_path') else ""}

Important:
- Check shared context for relevant findings and constraints
- Do NOT repeat approaches marked as FAIL in shared context
- Respect all CONSTRAINT entries
- Build on FACT entries from other workers
"""

    async def _execute_write_module(self, task: Task, prompt: str, context: List) -> Dict:
        """Execute a write_module task"""
        # Generate code with LLM
        code_response = await self.llm.generate(
            prompt + "\n\nGenerate the code. Output only the code, no explanations.",
            temperature=0.2
        )

        # Get file path
        file_path = task.metadata.get("file_path")
        if not file_path:
            # Try to extract from description
            import re
            match = re.search(r'[\w/]+\.\w+', task.description)
            if match:
                file_path = match.group(0)
            else:
                file_path = "generated_module.py"

        # Write file using filesystem tool
        write_result = await self.tools["filesystem"].write_file(
            file_path=file_path,
            content=code_response
        )

        # Run self-healing if available
        heal_result = None
        if "self_heal" in self.tools:
            heal_result = await self.tools["self_heal"].check_and_fix(
                file_path=file_path,
                code=code_response
            )

        # Submit patch summary to shared context
        patch_content = f"files={file_path} | implemented {task.description}"
        if heal_result and heal_result.get("fixes"):
            patch_content += f" | self-healed: {heal_result['fixes']}"

        gist = await self.context.submit_update(
            agent_id=self.worker_id,
            entry_type=EntryType.PATCH_SUMMARY,
            content=patch_content,
            raw_content=code_response,
            task_id=task.task_id,
            metadata={
                "files": file_path,
                "evidence_type": "code",
                "source_path": file_path,
                "tests_passed": heal_result.get("tests_passed") if heal_result else None
            }
        )

        return {"gist_id": gist.gist_id, "file_path": file_path}

    async def _execute_write_tests(self, task: Task, prompt: str, context: List) -> Dict:
        """Execute a write_tests task"""
        # Get files to test from context
        files_to_test = []
        for c in context:
            if isinstance(c, dict):
                continue
            if c.entry_type == EntryType.PATCH_SUMMARY:
                files = c.metadata.get("files", "")
                if files:
                    files_to_test.append(files)

        test_prompt = prompt + f"""

## Files to Test
{chr(10).join('- ' + f for f in files_to_test)}

Generate comprehensive tests for these files.
"""

        test_code = await self.llm.generate(test_prompt, temperature=0.2)

        # Write test file
        test_path = f"tests/test_{task.metadata.get('test_target', 'generated')}.py"
        await self.tools["filesystem"].write_file(
            file_path=test_path,
            content=test_code
        )

        # Run tests
        test_result = await self.tools["terminal"].execute(
            command=f"python -m pytest {test_path} -v",
            timeout=60
        )

        # Submit result
        gist = await self.context.submit_update(
            agent_id=self.worker_id,
            entry_type=EntryType.FACT,
            content=f"Tests written for {', '.join(files_to_test)}: {test_result.get('summary', '')}",
            raw_content=test_code,
            task_id=task.task_id,
            metadata={
                "files": test_path,
                "test_results": test_result
            }
        )

        return {"gist_id": gist.gist_id, "test_path": test_path}

    async def _execute_analyze(self, task: Task, prompt: str, context: List) -> Dict:
        """Execute an analysis task"""
        # Read files to analyze
        file_path = task.metadata.get("file_path")
        if file_path:
            file_content = await self.tools["filesystem"].read_file(file_path)
            analysis_prompt = prompt + f"\n\nFile content:\n```\n{file_content}\n```"
        else:
            analysis_prompt = prompt

        analysis = await self.llm.generate(
            analysis_prompt + "\n\nProvide your analysis.",
            temperature=0.3
        )

        gist = await self.context.submit_update(
            agent_id=self.worker_id,
            entry_type=EntryType.FACT,
            content=analysis[:200] + "..." if len(analysis) > 200 else analysis,
            raw_content=analysis,
            task_id=task.task_id,
            metadata={"analysis_type": task.metadata.get("analysis_type", "general")}
        )

        return {"gist_id": gist.gist_id}

    async def _execute_run_tests(self, task: Task, prompt: str, context: List) -> Dict:
        """Execute tests and report results"""
        test_path = task.metadata.get("test_path", "tests/")

        result = await self.tools["terminal"].execute(
            command=f"python -m pytest {test_path} -v --tb=short",
            timeout=120
        )

        # Determine if tests passed
        passed = result.get("return_code", 1) == 0

        entry_type = EntryType.FACT if passed else EntryType.FAIL
        content = f"Test run {'passed' if passed else 'failed'}: {result.get('summary', '')}"

        gist = await self.context.submit_update(
            agent_id=self.worker_id,
            entry_type=entry_type,
            content=content,
            raw_content=result.get("output", ""),
            task_id=task.task_id,
            metadata={"test_results": result}
        )

        return {"gist_id": gist.gist_id, "passed": passed}

    async def _execute_generic(self, task: Task, prompt: str, context: List) -> Dict:
        """Execute a generic task"""
        result = await self.llm.generate(prompt, temperature=0.3)

        gist = await self.context.submit_update(
            agent_id=self.worker_id,
            entry_type=EntryType.FACT,
            content=result[:200] + "..." if len(result) > 200 else result,
            raw_content=result,
            task_id=task.task_id
        )

        return {"gist_id": gist.gist_id}

    async def _submit_failure(self, task: Task, error: str, traceback_str: str):
        """Submit a failure to shared context"""
        await self.context.submit_update(
            agent_id=self.worker_id,
            entry_type=EntryType.FAIL,
            content=f"Task '{task.description}' failed: {error}",
            raw_content=traceback_str,
            task_id=task.task_id,
            metadata={
                "error_type": type(Exception(error)).__name__,
                "handled": []
            }
        )

    def stop(self):
        """Stop the worker"""
        self._running = False
