"""
DELM-Style Task Queue
Asynchronous task claiming without central controller routing.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, List, Dict, Any, Callable
from datetime import datetime
import uuid
import asyncio
from collections import defaultdict


class TaskStatus(Enum):
    PENDING = "pending"
    CLAIMED = "claimed"
    COMPLETED = "completed"
    FAILED = "failed"
    BLOCKED = "blocked"  # Waiting on dependencies


class TaskPriority(Enum):
    HIGH = 3
    NORMAL = 2
    LOW = 1


@dataclass
class Task:
    """
    A unit of work in the task queue.
    Agents claim these asynchronously.
    """
    task_id: str
    task_type: str  # "write_module", "run_tests", "analyze_code", etc.
    description: str
    priority: TaskPriority = TaskPriority.NORMAL
    status: TaskStatus = TaskStatus.PENDING
    claimed_by: Optional[str] = None
    claimed_at: Optional[datetime] = None
    dependencies: List[str] = field(default_factory=list)  # Other task IDs
    context_requirements: List[str] = field(default_factory=list)  # Gist IDs needed
    result_gist_id: Optional[str] = None  # Gist produced by this task
    created_at: datetime = field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    retry_count: int = 0
    max_retries: int = 2

    def to_dict(self) -> dict:
        return {
            "task_id": self.task_id,
            "task_type": self.task_type,
            "description": self.description,
            "priority": self.priority.value,
            "status": self.status.value,
            "claimed_by": self.claimed_by,
            "dependencies": self.dependencies,
            "result_gist_id": self.result_gist_id,
            "created_at": self.created_at.isoformat(),
            "retry_count": self.retry_count
        }


class TaskQueue:
    """
    DELM-style task queue with dependency-aware scheduling.

    Key differences from Redis Streams approach:
    - Tasks have explicit dependencies
    - Agents claim tasks (not assigned)
    - Blocked tasks auto-unblock when dependencies complete
    """

    def __init__(self, session_id: str):
        self.session_id = session_id
        self.tasks: Dict[str, Task] = {}
        self._claim_locks: Dict[str, asyncio.Lock] = defaultdict(asyncio.Lock)
        self._waiters: List[asyncio.Future] = []

    async def enqueue(self,
                      task_type: str,
                      description: str,
                      priority: TaskPriority = TaskPriority.NORMAL,
                      dependencies: Optional[List[str]] = None,
                      context_requirements: Optional[List[str]] = None,
                      metadata: Optional[Dict] = None) -> Task:
        """Add a new task to the queue"""
        task = Task(
            task_id=str(uuid.uuid4()),
            task_type=task_type,
            description=description,
            priority=priority,
            dependencies=dependencies or [],
            context_requirements=context_requirements or [],
            metadata=metadata or {}
        )

        # Check if dependencies are satisfied
        if task.dependencies:
            dep_statuses = [self.tasks.get(d) for d in task.dependencies]
            if any(d is None or d.status != TaskStatus.COMPLETED for d in dep_statuses):
                task.status = TaskStatus.BLOCKED

        self.tasks[task.task_id] = task
        self._notify_waiters()

        return task

    async def claim_task(self,
                         agent_id: str,
                         preferred_types: Optional[List[str]] = None) -> Optional[Task]:
        """
        Claim an available task.
        Agents call this to get work - no central assignment.
        """
        # Get claimable tasks (pending, not blocked, not claimed)
        available = [
            t for t in self.tasks.values()
            if t.status == TaskStatus.PENDING
               and (not preferred_types or t.task_type in preferred_types)
        ]

        if not available:
            # Wait for new tasks
            return await self._wait_for_task(agent_id, preferred_types)

        # Sort by priority (high first), then by creation time
        available.sort(key=lambda t: (-t.priority.value, t.created_at))

        task = available[0]

        # Try to acquire lock for this task
        async with self._claim_locks[task.task_id]:
            # Double-check status after acquiring lock
            if task.status != TaskStatus.PENDING:
                return await self.claim_task(agent_id, preferred_types)

            task.status = TaskStatus.CLAIMED
            task.claimed_by = agent_id
            task.claimed_at = datetime.utcnow()

            return task

    async def complete_task(self,
                            task_id: str,
                            agent_id: str,
                            result_gist_id: Optional[str] = None,
                            success: bool = True):
        """Mark a task as completed and unblock dependents"""
        task = self.tasks.get(task_id)
        if not task:
            return

        if task.claimed_by != agent_id:
            raise ValueError(f"Agent {agent_id} cannot complete task claimed by {task.claimed_by}")

        if success:
            task.status = TaskStatus.COMPLETED
            task.completed_at = datetime.utcnow()
            task.result_gist_id = result_gist_id

            # Unblock dependent tasks
            await self._unblock_dependents(task_id)
        else:
            task.status = TaskStatus.FAILED
            task.retry_count += 1

            if task.retry_count < task.max_retries:
                # Reset for retry
                task.status = TaskStatus.PENDING
                task.claimed_by = None
                task.claimed_at = None

        self._notify_waiters()

    async def _unblock_dependents(self, completed_task_id: str):
        """Check and unblock tasks that depend on the completed task"""
        for task in self.tasks.values():
            if task.status == TaskStatus.BLOCKED and completed_task_id in task.dependencies:
                # Check if all dependencies are now complete
                all_deps_complete = all(
                    self.tasks.get(d, Task(task_id="", task_type="", description="")).status == TaskStatus.COMPLETED
                    for d in task.dependencies
                )
                if all_deps_complete:
                    task.status = TaskStatus.PENDING

    async def _wait_for_task(self,
                             agent_id: str,
                             preferred_types: Optional[List[str]],
                             timeout: float = 30.0) -> Optional[Task]:
        """Wait for a task to become available"""
        future = asyncio.get_event_loop().create_future()
        self._waiters.append((future, agent_id, preferred_types))

        try:
            return await asyncio.wait_for(future, timeout=timeout)
        except asyncio.TimeoutError:
            return None
        finally:
            if future in self._waiters:
                self._waiters.remove(future)

    def _notify_waiters(self):
        """Notify waiting agents that tasks are available"""
        for future, agent_id, preferred_types in self._waiters[:]:
            if not future.done():
                # Don't actually claim here, just wake up
                future.set_result(None)

    def get_queue_status(self) -> dict:
        """Get status of all tasks in queue"""
        status_counts = defaultdict(int)
        for task in self.tasks.values():
            status_counts[task.status.value] += 1

        return {
            "total_tasks": len(self.tasks),
            "by_status": dict(status_counts),
            "pending": [t.to_dict() for t in self.tasks.values() if t.status == TaskStatus.PENDING],
            "blocked": [t.to_dict() for t in self.tasks.values() if t.status == TaskStatus.BLOCKED]
        }

    def get_tasks_for_agent(self, agent_id: str) -> List[Task]:
        """Get all tasks claimed by a specific agent"""
        return [t for t in self.tasks.values() if t.claimed_by == agent_id]
    