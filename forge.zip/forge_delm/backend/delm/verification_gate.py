"""
DELM Verification Gate
Ensures all shared context updates are grounded in evidence before admission.
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any
from enum import Enum
import re

from delm.shared_context import EntryType


class VerificationResult(Enum):
    VERIFIED = "verified"
    REJECTED = "rejected"
    REGENERATE = "regenerate"


@dataclass
class VerificationOutcome:
    result: VerificationResult
    confidence: float  # 0.0 to 1.0
    issues: List[str]
    feedback: Optional[str] = None


class VerificationGate:
    """
    Admission-time verification for shared context entries.

    Prevents unsupported claims from becoming reusable state.
    """

    def __init__(self, llm_client, shared_context):
        self.llm = llm_client
        self.shared_context = shared_context

    async def verify_update(self, gist) -> VerificationOutcome:
        """
        Verify a gist before admitting to shared context.

        Checks:
        1. Evidence grounding - claims supported by cited evidence
        2. Factual consistency - doesn't contradict verified facts
        3. Completeness - captures relevant details from source
        4. Constraint preservation - maintains existing constraints
        """
        issues = []

        # Get supporting evidence if referenced
        evidence = None
        if gist.references:
            unfolded = await self.shared_context.unfold_gist(
                gist.gist_id,
                detail_level="full"
            )
            evidence = unfolded.get("raw_evidence", [])

        # Type-specific verification
        if gist.entry_type.value == "fact":
            result = await self._verify_fact(gist, evidence)
        elif gist.entry_type.value == "fail":
            result = await self._verify_failure(gist, evidence)
        elif gist.entry_type.value == "constraint":
            result = await self._verify_constraint(gist, evidence)
        elif gist.entry_type.value == "patch_summary":
            result = await self._verify_patch_summary(gist, evidence)
        else:
            result = await self._verify_generic(gist, evidence)

        issues.extend(result.issues)

        # Check for contradictions with existing verified facts
        contradiction_check = await self._check_contradictions(gist)
        if contradiction_check:
            issues.append(contradiction_check)
            return VerificationOutcome(
                result=VerificationResult.REJECTED,
                confidence=0.0,
                issues=issues,
                feedback=f"Contradicts existing fact: {contradiction_check}"
            )

        # Determine outcome
        if not issues:
            return VerificationOutcome(
                result=VerificationResult.VERIFIED,
                confidence=result.confidence,
                issues=[]
            )
        elif any("critical" in i.lower() for i in issues):
            return VerificationOutcome(
                result=VerificationResult.REJECTED,
                confidence=0.0,
                issues=issues,
                feedback="; ".join(issues)
            )
        else:
            return VerificationOutcome(
                result=VerificationResult.REGENERATE,
                confidence=0.3,
                issues=issues,
                feedback=f"Regenerate with fixes: {'; '.join(issues)}"
            )

    async def _verify_fact(self, gist, evidence) -> VerificationOutcome:
        """Verify a factual claim"""
        issues = []
        confidence = 0.8

        # Check if evidence exists for this claim
        if not evidence:
            # Try LLM verification if no explicit evidence
            llm_check = await self._llm_verify_claim(gist.content)
            if not llm_check["supported"]:
                issues.append(f"Claim not grounded: {gist.content}")
                confidence = 0.0
            else:
                confidence = llm_check.get("confidence", 0.7)
        else:
            # Check claim against evidence
            for ev in evidence:
                if not self._claim_in_evidence(gist.content, ev.get("content", "")):
                    issues.append(f"Claim not supported by evidence {ev.get('evidence_id')}")
                    confidence = max(0, confidence - 0.3)

        return VerificationOutcome(
            result=VerificationResult.VERIFIED if confidence > 0.5 else VerificationResult.REJECTED,
            confidence=confidence,
            issues=issues
        )

    async def _verify_failure(self, gist, evidence) -> VerificationOutcome:
        """
        Verify a failed hypothesis.
        Failures are valuable - we want to capture them accurately.
        """
        issues = []
        confidence = 0.9  # Failures are usually clear

        # Check that failure is specific (not vague)
        if len(gist.content) < 20:
            issues.append("Failure description too vague")
            confidence = 0.3

        # Check that it describes WHAT failed and WHY
        if "because" not in gist.content.lower() and "due to" not in gist.content.lower():
            if "does not" not in gist.content.lower() and "failed" not in gist.content.lower():
                issues.append("Failure lacks explanation of why it failed")
                confidence = 0.5

        return VerificationOutcome(
            result=VerificationResult.VERIFIED if confidence > 0.4 else VerificationResult.REGENERATE,
            confidence=confidence,
            issues=issues
        )

    async def _verify_constraint(self, gist, evidence) -> VerificationOutcome:
        """Verify a constraint that must be preserved"""
        issues = []
        confidence = 0.85

        # Constraints should be clear and testable
        if not any(word in gist.content.lower()
                   for word in ["must", "should", "cannot", "never", "always", "required"]):
            issues.append("Constraint lacks clear requirement language")
            confidence = 0.4

        # Check if constraint has scope
        if not any(scope in gist.content.lower()
                   for scope in ["when", "for", "in", "during", "before", "after"]):
            issues.append("Constraint lacks scope/context")
            confidence = 0.5

        return VerificationOutcome(
            result=VerificationResult.VERIFIED if confidence > 0.4 else VerificationResult.REGENERATE,
            confidence=confidence,
            issues=issues
        )

    async def _verify_patch_summary(self, gist, evidence) -> VerificationOutcome:
        """Verify a patch summary"""
        issues = []
        confidence = 0.8

        # Patch summaries should include: what changed, where, why
        required_elements = {
            "what": ["modify", "add", "remove", "fix", "change", "update"],
            "where": ["file", "function", "class", "module", "in ", "at "],
            "why": ["because", "to ", "for ", "fixes", "resolves"]
        }

        content_lower = gist.content.lower()
        for element, keywords in required_elements.items():
            if not any(kw in content_lower for kw in keywords):
                issues.append(f"Patch summary missing '{element}' element")
                confidence -= 0.2

        # Check for evidence of testing
        metadata = gist.metadata or {}
        if not metadata.get("tests_passed") and "passed" not in content_lower:
            issues.append("Patch summary doesn't indicate testing")
            confidence -= 0.1

        return VerificationOutcome(
            result=VerificationResult.VERIFIED if confidence > 0.4 else VerificationResult.REGENERATE,
            confidence=max(0, confidence),
            issues=issues
        )

    async def _verify_generic(self, gist, evidence) -> VerificationOutcome:
        """Generic verification for other entry types"""
        # Use LLM for generic verification
        llm_check = await self._llm_verify_claim(gist.content)
        return VerificationOutcome(
            result=VerificationResult.VERIFIED if llm_check["supported"] else VerificationResult.REJECTED,
            confidence=llm_check.get("confidence", 0.5),
            issues=[] if llm_check["supported"] else ["Claim not verified"]
        )

    def _claim_in_evidence(self, claim: str, evidence: str) -> bool:
        """Simple check if claim is supported by evidence"""
        # Extract key terms from claim
        claim_words = set(re.findall(r'\w+', claim.lower()))
        evidence_words = set(re.findall(r'\w+', evidence.lower()))

        # At least 60% of claim words should be in evidence
        if not claim_words:
            return False
        overlap = len(claim_words & evidence_words) / len(claim_words)
        return overlap >= 0.6

    async def _check_contradictions(self, gist) -> Optional[str]:
        """Check if new gist contradicts existing verified facts"""
        existing_facts = await self.shared_context.read_context(
            entry_types=[EntryType.FACT]
        )

        for fact in existing_facts:
            # Simple contradiction check
            if self._contradicts(gist.content, fact.content):
                return fact.content

        return None

    def _contradicts(self, new: str, existing: str) -> bool:
        """Simple contradiction detection"""
        new_lower = new.lower()
        existing_lower = existing.lower()

        # Check for explicit negations of existing facts
        contradiction_patterns = [
            (r"not\s+" + re.escape(existing_lower[:30]), True),
            (r"no\s+" + re.escape(existing_lower[:30]), True),
            (r"never\s+" + re.escape(existing_lower[:30]), True),
        ]

        for pattern, _ in contradiction_patterns:
            if re.search(pattern, new_lower):
                return True

        return False

    async def _llm_verify_claim(self, claim: str) -> dict:
        """Use LLM to verify a claim when no explicit evidence"""
        prompt = f"""Verify if this claim is well-grounded and specific:

Claim: "{claim}"

Respond in JSON format:
{{
    "supported": true/false,
    "confidence": 0.0-1.0,
    "reason": "brief explanation"
}}"""

        try:
            response = await self.llm.generate(prompt, temperature=0.1)
            # Parse JSON from response
            import json
            return json.loads(response)
        except:
            return {"supported": False, "confidence": 0.0, "reason": "LLM verification failed"}
