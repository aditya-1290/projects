"""
DELM-Style Shared Context Manager
Implements verified, hierarchical shared state for decentralized coordination.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, List, Dict, Any
from datetime import datetime
import uuid
import json
from pathlib import Path


class EntryType(Enum):
    """Types of entries in shared context"""
    FACT = "fact"  # Verified finding
    FAIL = "fail"  # Failed hypothesis (reusable!)
    CONSTRAINT = "constraint"  # Binding constraint
    PATCH_SUMMARY = "patch_summary"  # Compact patch description
    EVIDENCE_GIST = "evidence_gist"  # Compressed source evidence
    PARTIAL_SOLUTION = "partial"  # Incomplete but useful progress
    ERROR_FEEDBACK = "error_feedback"  # Execution/runtime errors


class VerificationStatus(Enum):
    PENDING = "pending"
    VERIFIED = "verified"
    REJECTED = "rejected"
    REGENERATING = "regenerating"


@dataclass
class GistEntry:
    """
    Compact gist stored in shared context.
    All agents see this layer.
    """
    gist_id: str
    entry_type: EntryType
    content: str  # Compressed representation (~100 tokens)
    source_agent: str
    task_id: Optional[str] = None
    verification_status: VerificationStatus = VerificationStatus.PENDING
    timestamp: datetime = field(default_factory=datetime.utcnow)
    references: List[str] = field(default_factory=list)  # IDs of S_i summaries
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "gist_id": self.gist_id,
            "entry_type": self.entry_type.value,
            "content": self.content,
            "source_agent": self.source_agent,
            "task_id": self.task_id,
            "verification_status": self.verification_status.value,
            "timestamp": self.timestamp.isoformat(),
            "references": self.references,
            "metadata": self.metadata
        }


@dataclass
class SummaryEntry:
    """
    Intermediate summary layer (S_i).
    More detailed than gist, references raw evidence.
    Not directly visible to agents unless unfolded.
    """
    summary_id: str
    gist_id: str  # Parent gist
    content: str  # ~500 tokens
    raw_references: List[str] = field(default_factory=list)  # Raw evidence IDs
    created_at: datetime = field(default_factory=datetime.utcnow)

    def to_dict(self) -> dict:
        return {
            "summary_id": self.summary_id,
            "gist_id": self.gist_id,
            "content": self.content,
            "raw_references": self.raw_references,
            "created_at": self.created_at.isoformat()
        }


@dataclass
class RawEvidence:
    """
    Raw source material (code, documents, traces).
    Only loaded on demand via unfolding.
    """
    evidence_id: str
    evidence_type: str  # "code", "document", "trace", "execution_output"
    content: Any  # str for text, dict for structured
    source_path: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.utcnow)


class SharedContext:
    """
    DELM-style shared context with hierarchical storage and verification.

    Hierarchy: Gist (G_i) -> Summary (S_i) -> Raw Evidence
    - Agents always read G_i (compact, fast)
    - S_i and Raw loaded on demand via selective unfolding
    """

    def __init__(self, session_id: str, storage_backend):
        self.session_id = session_id
        self.storage = storage_backend
        self.gists: Dict[str, GistEntry] = {}  # In-memory cache
        self.summaries: Dict[str, SummaryEntry] = {}
        self.raw_evidence: Dict[str, RawEvidence] = {}
        self._load_persisted_state()

    def _load_persisted_state(self):
        """Load existing context from storage on init"""
        # Implementation depends on storage backend
        pass

    async def read_context(self,
                           entry_types: Optional[List[EntryType]] = None,
                           max_gists: int = 50) -> List[GistEntry]:
        """
        Read compact gists from shared context.
        This is what agents see by default - lightweight global view.
        """
        gists = list(self.gists.values())

        # Filter by type if specified
        if entry_types:
            gists = [g for g in gists if g.entry_type in entry_types]

        # Only return verified entries
        gists = [g for g in gists if g.verification_status == VerificationStatus.VERIFIED]

        # Sort by timestamp, most recent first
        gists.sort(key=lambda g: g.timestamp, reverse=True)

        return gists[:max_gists]

    async def unfold_gist(self, gist_id: str, detail_level: str = "summary") -> dict:
        """
        Selective unfolding: expand gist to summary or raw evidence.

        detail_level:
        - "gist": return gist only (already have)
        - "summary": return gist + summary
        - "full": return gist + summary + raw evidence
        """
        gist = self.gists.get(gist_id)
        if not gist:
            raise ValueError(f"Gist {gist_id} not found")

        result = {"gist": gist.to_dict()}

        if detail_level in ["summary", "full"]:
            # Load all summaries for this gist
            summaries = [s for s in self.summaries.values() if s.gist_id == gist_id]
            result["summaries"] = [s.to_dict() for s in summaries]

        if detail_level == "full":
            # Load raw evidence referenced by summaries
            raw_ids = set()
            for summary in summaries:
                raw_ids.update(summary.raw_references)

            raw_items = []
            for raw_id in raw_ids:
                raw = self.raw_evidence.get(raw_id)
                if raw:
                    raw_items.append({
                        "evidence_id": raw.evidence_id,
                        "evidence_type": raw.evidence_type,
                        "content": raw.content,
                        "source_path": raw.source_path
                    })
            result["raw_evidence"] = raw_items

        return result

    async def submit_update(self,
                            agent_id: str,
                            entry_type: EntryType,
                            content: str,
                            supporting_evidence: Optional[List[str]] = None,
                            raw_content: Optional[Any] = None,
                            task_id: Optional[str] = None,
                            metadata: Optional[Dict] = None) -> GistEntry:
        """
        Submit an update for verification and admission.

        This is how agents write to shared context - goes through verification first.
        """
        # Create gist entry
        gist = GistEntry(
            gist_id=str(uuid.uuid4()),
            entry_type=entry_type,
            content=content,
            source_agent=agent_id,
            task_id=task_id,
            verification_status=VerificationStatus.PENDING,
            metadata=metadata or {}
        )

        # If there's raw content, create summary and raw evidence
        if raw_content is not None:
            summary_id = str(uuid.uuid4())
            raw_id = str(uuid.uuid4())

            # Create summary (could use LLM to generate)
            summary = SummaryEntry(
                summary_id=summary_id,
                gist_id=gist.gist_id,
                content=self._create_summary(raw_content),
                raw_references=[raw_id]
            )

            # Create raw evidence
            raw = RawEvidence(
                evidence_id=raw_id,
                evidence_type=metadata.get("evidence_type", "text") if metadata else "text",
                content=raw_content,
                source_path=metadata.get("source_path") if metadata else None
            )

            self.raw_evidence[raw_id] = raw
            self.summaries[summary_id] = summary
            gist.references = [summary_id]

        # Add to pending (not yet visible to other agents)
        self.gists[gist.gist_id] = gist

        return gist

    def _create_summary(self, raw_content: Any) -> str:
        """Create intermediate summary from raw content"""
        # In production, this would use an LLM
        # For now, simple truncation
        if isinstance(raw_content, str):
            return raw_content[:500] + "..." if len(raw_content) > 500 else raw_content
        return str(raw_content)[:500]

    async def get_pending_verifications(self) -> List[GistEntry]:
        """Get entries waiting for verification"""
        return [g for g in self.gists.values()
                if g.verification_status == VerificationStatus.PENDING]

    async def admit_entry(self, gist_id: str, verified: bool, feedback: Optional[str] = None):
        """
        Admit or reject an entry after verification.
        Only verified entries become visible to other agents.
        """
        gist = self.gists.get(gist_id)
        if not gist:
            return

        if verified:
            gist.verification_status = VerificationStatus.VERIFIED
            # Persist to storage
            await self._persist_verified_gist(gist)
        else:
            if feedback and "regenerate" in feedback.lower():
                gist.verification_status = VerificationStatus.REGENERATING
            else:
                gist.verification_status = VerificationStatus.REJECTED
                # Could clean up associated summaries/raw evidence

    async def _persist_verified_gist(self, gist: GistEntry):
        """Persist verified gist to long-term storage"""
        # Implementation depends on storage backend
        pass

    def get_context_summary(self) -> dict:
        """Get summary of current shared context state"""
        verified = [g for g in self.gists.values()
                    if g.verification_status == VerificationStatus.VERIFIED]

        by_type = {}
        for g in verified:
            t = g.entry_type.value
            by_type[t] = by_type.get(t, 0) + 1

        return {
            "total_entries": len(verified),
            "by_type": by_type,
            "pending_verification": len([g for g in self.gists.values()
                                         if g.verification_status == VerificationStatus.PENDING])
        }
