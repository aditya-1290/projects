"""shared/logger.py — Centralised logging."""
import logging, os, sys
from logging.handlers import RotatingFileHandler
from pathlib import Path

LOG_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)-30s | %(message)s"

def setup_logging(level: str = "INFO", log_to_file: bool = True, log_to_console: bool = False):
    path = Path(os.environ.get("FORGE_LOG_PATH", "~/.forge/forge.log")).expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    root = logging.getLogger("forge")
    root.setLevel(getattr(logging, level.upper(), logging.INFO))
    root.handlers.clear()
    fmt = logging.Formatter(LOG_FORMAT, datefmt="%Y-%m-%d %H:%M:%S")
    if log_to_file:
        fh = RotatingFileHandler(path, maxBytes=5*1024*1024, backupCount=3, encoding="utf-8")
        fh.setFormatter(fmt); root.addHandler(fh)
    if log_to_console:
        ch = logging.StreamHandler(sys.stderr)
        ch.setFormatter(fmt); root.addHandler(ch)
    for n in ("httpx","httpcore","asyncio","aiosqlite"):
        logging.getLogger(n).setLevel(logging.WARNING)

def get_logger(name: str) -> logging.Logger:
    if not name.startswith("forge"):
        name = f"forge.{name}"
    return logging.getLogger(name)
