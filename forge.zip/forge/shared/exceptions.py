"""shared/exceptions.py — All custom Forge exceptions."""

class ForgeError(Exception): pass
class ConfigError(ForgeError): pass
class ModelConnectionError(ForgeError): pass
class SessionError(ForgeError): pass
class SessionNotFoundError(SessionError): pass
class AgentError(ForgeError): pass
class AgentTimeoutError(AgentError): pass
class AgentContextBurstError(AgentError): pass

class AgentTaskError(AgentError):
    def __init__(self, agent: str, task: str, reason: str):
        self.agent = agent; self.task = task; self.reason = reason
        super().__init__(f"Agent '{agent}' failed task '{task}': {reason}")

class BusError(ForgeError): pass

class QueueFullError(BusError):
    def __init__(self, queue_name: str):
        self.queue_name = queue_name
        super().__init__(f"Queue '{queue_name}' is full.")

class MessageDeliveryError(BusError): pass
class PermissionDeniedError(ForgeError): pass

class ScopeViolationError(ForgeError):
    def __init__(self, attempted_path: str, project_root: str):
        super().__init__(f"Scope violation: '{attempted_path}' is outside '{project_root}'.")

class StorageError(ForgeError): pass
class CheckpointNotFoundError(StorageError): pass
class DatabaseError(StorageError): pass
class ProjectNotFoundError(ForgeError):
    def __init__(self, path: str): super().__init__(f"Project path not found: '{path}'")
class IngestionError(ForgeError): pass
class MCPError(ForgeError): pass
class FileReadError(MCPError): pass
class FileWriteError(MCPError): pass
class GitError(MCPError): pass
