"""config/settings.py — Pydantic settings for Forge."""
from __future__ import annotations
import json, os
from pathlib import Path
from typing import Optional
from pydantic import BaseModel, Field, field_validator
from shared.constants import (API_HOST, API_PORT, DEFAULT_CONFIG_PATH,
    DEFAULT_CONTEXT_WINDOW, DEFAULT_DB_PATH, DEFAULT_LOG_PATH,
    DEFAULT_MAX_TOKENS, DEFAULT_MODEL_BASE_URL, DEFAULT_MODEL_ID, DEFAULT_TEMPERATURE)

class ModelSettings(BaseModel):
    provider: str = "llama_cpp"
    base_url: str = DEFAULT_MODEL_BASE_URL
    model_id: str = DEFAULT_MODEL_ID
    context_window: int = DEFAULT_CONTEXT_WINDOW
    temperature: float = DEFAULT_TEMPERATURE
    max_tokens: int = DEFAULT_MAX_TOKENS
    stream: bool = True
    mode: str = "personal"

    @field_validator("base_url")
    @classmethod
    def strip_slash(cls, v): return v.rstrip("/")

class StorageSettings(BaseModel):
    db_path: str = DEFAULT_DB_PATH
    log_path: str = DEFAULT_LOG_PATH

class ServerSettings(BaseModel):
    host: str = API_HOST
    port: int = API_PORT

class BusSettings(BaseModel):
    backend: str = "memory"
    redis_url: str = "redis://localhost:6379"
    queue_max_size: int = 100

class TeamSettings(BaseModel):
    mode: str = "local"
    server_url: Optional[str] = None

class ForgeSettings(BaseModel):
    model:   ModelSettings   = Field(default_factory=ModelSettings)
    storage: StorageSettings = Field(default_factory=StorageSettings)
    server:  ServerSettings  = Field(default_factory=ServerSettings)
    bus:     BusSettings     = Field(default_factory=BusSettings)
    team:    TeamSettings    = Field(default_factory=TeamSettings)
    log_level: str = "INFO"
    debug_mode: bool = False

    def resolved_db_path(self) -> Path:
        return Path(self.storage.db_path).expanduser()

def load_settings(config_path: Optional[str] = None) -> ForgeSettings:
    path = Path(config_path or DEFAULT_CONFIG_PATH).expanduser()
    data = json.loads(path.read_text()) if path.exists() else {}
    if url := os.environ.get("FORGE_MODEL_BASE_URL"):
        data.setdefault("model", {})["base_url"] = url
    if mid := os.environ.get("FORGE_MODEL_ID"):
        data.setdefault("model", {})["model_id"] = mid
    return ForgeSettings(**data)

def save_settings(settings: ForgeSettings, config_path: Optional[str] = None):
    path = Path(config_path or DEFAULT_CONFIG_PATH).expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(settings.model_dump(), indent=2))

_settings: Optional[ForgeSettings] = None

def get_settings() -> ForgeSettings:
    global _settings
    if _settings is None:
        _settings = load_settings()
    return _settings

def reset_settings():
    global _settings
    _settings = None
