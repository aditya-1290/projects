"""
backend/app.py
--------------
FastAPI application factory for Forge.

Responsibilities:
- Create and configure the FastAPI app
- Lifespan handler: init DB, start bus, start agents
- Mount all API routers
- CORS middleware (localhost only in Phase 1)
- Global exception handlers
"""

from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
from typing import AsyncGenerator

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from backend.api import sessions, stream, permissions, health
from backend.services.agent_runner import AgentRunner
from broker.factory import get_bus, reset_bus
from config.settings import get_settings
from shared.constants import APP_NAME, APP_VERSION, API_PREFIX
from shared.exceptions import (
    ForgeError, SessionNotFoundError, PermissionDeniedError
)
from shared.logger import get_logger
from storage.database.connection import create_schema, init_db_path

logger = get_logger(__name__)

# Module-level agent runner — shared across requests
_agent_runner: AgentRunner | None = None


def get_agent_runner() -> AgentRunner:
    if _agent_runner is None:
        raise RuntimeError("AgentRunner not initialised — app not started yet")
    return _agent_runner


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """
    Startup / shutdown handler.
    - Initialises DB schema
    - Starts the message bus
    - Starts all Phase 1 agents
    """
    global _agent_runner

    settings = get_settings()
    logger.info(f"Starting {APP_NAME} v{APP_VERSION}")

    # 1. Database
    init_db_path()
    create_schema()
    logger.info("Database ready")

    # 2. Message bus
    bus = get_bus()
    await bus.start()
    logger.info("Message bus started")

    # 3. Agents
    _agent_runner = AgentRunner(bus=bus)
    await _agent_runner.start_all()
    logger.info("All agents started")

    yield  # ← application runs here

    # Shutdown
    logger.info("Shutting down...")
    await _agent_runner.stop_all()
    await bus.stop()
    reset_bus()
    logger.info(f"{APP_NAME} stopped")


def create_app() -> FastAPI:
    """Application factory — returns a configured FastAPI instance."""
    settings = get_settings()

    app = FastAPI(
        title=APP_NAME,
        version=APP_VERSION,
        description="Forge — Autonomous Programming Agent API",
        docs_url="/docs",
        redoc_url="/redoc",
        lifespan=lifespan,
    )

    # CORS — localhost only in Phase 1
    app.add_middleware(
        CORSMiddleware,
        allow_origins=[
            "http://localhost:3000",
            "http://localhost:5173",
            f"http://{settings.server.host}:{settings.server.port}",
        ],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Routers
    app.include_router(health.router,       prefix=API_PREFIX)
    app.include_router(sessions.router,     prefix=API_PREFIX)
    app.include_router(stream.router,       prefix=API_PREFIX)
    app.include_router(permissions.router,  prefix=API_PREFIX)

    # Global exception handlers
    @app.exception_handler(SessionNotFoundError)
    async def session_not_found_handler(request: Request, exc: SessionNotFoundError):
        return JSONResponse(status_code=404, content={"error": str(exc)})

    @app.exception_handler(PermissionDeniedError)
    async def permission_denied_handler(request: Request, exc: PermissionDeniedError):
        return JSONResponse(status_code=403, content={"error": str(exc)})

    @app.exception_handler(ForgeError)
    async def forge_error_handler(request: Request, exc: ForgeError):
        return JSONResponse(status_code=400, content={"error": str(exc)})

    @app.exception_handler(Exception)
    async def generic_error_handler(request: Request, exc: Exception):
        logger.error(f"Unhandled exception: {exc}", exc_info=True)
        return JSONResponse(status_code=500, content={"error": "Internal server error"})

    return app


# Entrypoint for `uvicorn backend.app:app`
app = create_app()
