"""
backend/middleware/logging.py
------------------------------
Request/response logging middleware for Forge.
Logs method, path, status, and duration for every request.
"""

from __future__ import annotations

import time

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware

from shared.logger import get_logger

logger = get_logger("forge.http")


class RequestLoggingMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next) -> Response:
        start = time.monotonic()
        response = await call_next(request)
        duration_ms = (time.monotonic() - start) * 1000

        # Skip logging for SSE keep-alive pings
        if request.url.path.startswith("/api/v1/stream"):
            return response

        logger.info(
            f"{request.method} {request.url.path} "
            f"→ {response.status_code} ({duration_ms:.1f}ms)"
        )
        return response
