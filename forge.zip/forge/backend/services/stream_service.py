"""
backend/services/stream_service.py
------------------------------------
StreamService — bridges agent callbacks to SSE event queues.

How it works:
1. Agents call push_*() methods (sync-safe) when they have updates.
2. Each session has an asyncio.Queue of SSE-formatted events.
3. The /stream/{session_id} endpoint consumes from that queue.

Thread safety: push_*() methods are called from agent callbacks
which run in the asyncio event loop, so no locking needed.
"""

from __future__ import annotations

import asyncio
import json
from collections import defaultdict
from typing import Any, AsyncGenerator, Optional

from shared.logger import get_logger
from shared.types import AgentName, StreamChunk

logger = get_logger(__name__)

# Max events to buffer per session before dropping oldest
_QUEUE_MAX = 500
# Sentinel to signal stream end
_STREAM_DONE = object()


class StreamService:
    """
    Manages per-session SSE event queues.
    Created once by AgentRunner; injected into API via dependency.
    """

    def __init__(self):
        # session_id → asyncio.Queue of SSE event dicts
        self._queues: dict[str, asyncio.Queue] = {}
        # session_id → last status snapshot (for polling fallback)
        self._snapshots: dict[str, dict[str, Any]] = {}

    def _get_queue(self, session_id: str) -> asyncio.Queue:
        if session_id not in self._queues:
            self._queues[session_id] = asyncio.Queue(maxsize=_QUEUE_MAX)
        return self._queues[session_id]

    def _put_event(self, session_id: str, event_type: str, data: dict[str, Any]) -> None:
        """Put an event onto the session queue. Drops if full (non-blocking)."""
        q = self._get_queue(session_id)
        event = {
            "event": event_type,
            "data": json.dumps(data),
        }
        try:
            q.put_nowait(event)
        except asyncio.QueueFull:
            logger.warning(f"SSE queue full for session {session_id[:8]}, dropping event")

    # ------------------------------------------------------------------
    # Agent callbacks (called from agent code)
    # ------------------------------------------------------------------

    def push_status_event(self, event_type: str, data: dict[str, Any]) -> None:
        """
        Called by OrchestratorAgent._notify().
        data must contain 'session_id'.
        """
        session_id = data.get("session_id", "")
        if not session_id:
            return
        self._snapshots[session_id] = {**data, "event_type": event_type}
        self._put_event(session_id, event_type, data)

    def push_agent_reply(self, session_id: str, text: str) -> None:
        """
        Called by IntakeAgent._reply() and ArchitectAgent._reply().
        Pushes an agent_reply event with the text.
        """
        self._put_event(session_id, "agent_reply", {
            "session_id": session_id,
            "text": text,
        })

    def push_token_chunk(self, chunk: StreamChunk) -> None:
        """
        Called by CoderAgent stream callback.
        Pushes a streaming token event for code-view mode.
        """
        self._put_event(chunk.session_id, "token", {
            "session_id": chunk.session_id,
            "agent":      chunk.agent.value,
            "chunk_type": chunk.chunk_type,
            "content":    chunk.content,
            "metadata":   chunk.metadata,
        })

    def push_completion(self, session_id: str) -> None:
        """Signal that a session is complete."""
        self._put_event(session_id, "complete", {"session_id": session_id})
        q = self._get_queue(session_id)
        try:
            q.put_nowait(_STREAM_DONE)
        except asyncio.QueueFull:
            pass

    # ------------------------------------------------------------------
    # SSE consumer (used by /stream/{session_id})
    # ------------------------------------------------------------------

    async def event_stream(
        self, session_id: str
    ) -> AsyncGenerator[dict[str, str], None]:
        """
        Async generator that yields SSE events for a session.
        Blocks until events are available; terminates on completion sentinel.
        """
        q = self._get_queue(session_id)

        while True:
            try:
                event = await asyncio.wait_for(q.get(), timeout=30.0)
            except asyncio.TimeoutError:
                # Send keep-alive comment
                yield {"event": "ping", "data": "{}"}
                continue

            if event is _STREAM_DONE:
                yield {"event": "complete", "data": json.dumps({"session_id": session_id})}
                break

            yield event

    # ------------------------------------------------------------------
    # Polling fallback
    # ------------------------------------------------------------------

    def get_status_snapshot(self, session_id: str) -> Optional[dict[str, Any]]:
        return self._snapshots.get(session_id)

    def cleanup_session(self, session_id: str) -> None:
        """Remove queue and snapshot for a completed/deleted session."""
        self._queues.pop(session_id, None)
        self._snapshots.pop(session_id, None)


# ---------------------------------------------------------------------------
# FastAPI dependency
# ---------------------------------------------------------------------------

_service: Optional[StreamService] = None


def get_stream_service() -> StreamService:
    """
    Returns the shared StreamService instance.
    In production this comes from AgentRunner; the dependency returns it.
    """
    from backend.app import get_agent_runner
    try:
        return get_agent_runner().stream_service
    except RuntimeError:
        # Fallback for testing
        global _service
        if _service is None:
            _service = StreamService()
        return _service
