"""
backend/services/agent_runner.py
---------------------------------
AgentRunner — owns all agent instances and manages their lifecycle.

Responsibilities:
- Instantiate all Phase 1 agents with correct callbacks
- Start/stop all agents together
- Provide access to agent instances for the API layer
- Wire stream callbacks: agent events → StreamService
- Wire permission callbacks: coder → PermissionService
"""

from __future__ import annotations

import asyncio
from typing import Optional

from broker.bus import MessageBus
from shared.logger import get_logger
from shared.types import StreamChunk

logger = get_logger(__name__)


class AgentRunner:
    """
    Owns and manages all agent instances.
    Created once at app startup; torn down on shutdown.
    """

    def __init__(self, bus: MessageBus):
        self._bus = bus
        self._agents: list = []

        # Lazy imports to avoid circular deps at module load
        from agents.orchestrator.agent import OrchestratorAgent
        from agents.intake.agent import IntakeAgent
        from agents.architect.agent import ArchitectAgent
        from agents.coder.agent import CoderAgent
        from agents.memory_manager.agent import MemoryManagerAgent
        from backend.services.stream_service import StreamService
        from backend.services.permission_service import PermissionService

        # Services (shared singletons)
        self._stream_service = StreamService()
        self._permission_service = PermissionService()

        # ── Orchestrator ──────────────────────────────────────────────
        self._orchestrator = OrchestratorAgent(
            bus             = bus,
            stream_callback = self._stream_service.push_status_event,
        )

        # ── Intake ────────────────────────────────────────────────────
        self._intake = IntakeAgent(
            bus               = bus,
            response_callback = self._stream_service.push_agent_reply,
        )

        # ── Architect ─────────────────────────────────────────────────
        self._architect = ArchitectAgent(
            bus               = bus,
            response_callback = self._stream_service.push_agent_reply,
        )

        # ── Coder ─────────────────────────────────────────────────────
        self._coder = CoderAgent(
            bus              = bus,
            stream_callback  = self._stream_service.push_token_chunk,
            permission_check = self._permission_service.check_sync,
        )

        # ── Memory Manager ────────────────────────────────────────────
        self._memory_manager = MemoryManagerAgent(bus=bus)

        self._agents = [
            self._orchestrator,
            self._intake,
            self._architect,
            self._coder,
            self._memory_manager,
        ]

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start_all(self) -> None:
        """Start all agents concurrently."""
        await asyncio.gather(*[agent.start() for agent in self._agents])
        logger.info(f"AgentRunner: {len(self._agents)} agents started")

    async def stop_all(self) -> None:
        """Stop all agents gracefully."""
        await asyncio.gather(
            *[agent.stop() for agent in self._agents],
            return_exceptions=True,
        )
        logger.info("AgentRunner: all agents stopped")

    # ------------------------------------------------------------------
    # Agent accessors (for testing / advanced routing)
    # ------------------------------------------------------------------

    @property
    def orchestrator(self):
        return self._orchestrator

    @property
    def intake(self):
        return self._intake

    @property
    def architect(self):
        return self._architect

    @property
    def coder(self):
        return self._coder

    @property
    def stream_service(self) -> "StreamService":
        return self._stream_service

    @property
    def permission_service(self) -> "PermissionService":
        return self._permission_service
