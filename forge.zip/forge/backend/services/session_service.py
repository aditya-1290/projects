"""
backend/services/session_service.py
-------------------------------------
SessionService — business logic for session management.

Responsibilities:
- Create sessions in the DB
- Register new sessions with the Orchestrator
- Route user messages to the correct agent via the bus
- Wrap memory store operations for the API layer
"""

from __future__ import annotations

from typing import Optional

from fastapi import Depends

from broker.factory import get_bus
from memory.session_store import (
    create_session, delete_session, get_session,
    list_sessions, make_session, update_session,
)
from shared.constants import QUEUE_ORCHESTRATOR, QUEUE_INTAKE
from shared.exceptions import SessionNotFoundError
from shared.logger import get_logger
from shared.types import (
    AgentMessage, AgentName, ProjectMode, SessionState,
    SessionStatus, TaskType, UserType,
)

logger = get_logger(__name__)


class SessionService:
    """
    Handles all session lifecycle operations.
    Used by the sessions API router.
    """

    def __init__(self):
        self._bus = get_bus()

    async def create_and_start(
        self,
        project_name:  str,
        project_path:  str,
        mode:          ProjectMode,
        user_type:     UserType = UserType.DEVELOPER,
        initial_input: Optional[str] = None,
    ) -> SessionState:
        """
        Create a session record and kick off the first agent task.

        For SCRATCH mode → sends GATHER_REQUIREMENTS to Orchestrator.
        For INGEST mode  → sends INGEST_PROJECT to Orchestrator.
        """
        # 1. Create and persist session
        session = make_session(
            project_name = project_name,
            project_path = project_path,
            mode         = mode,
            user_type    = user_type,
        )
        await create_session(session)
        logger.info(f"Session created: {session.session_id[:8]} mode={mode.value}")

        # 2. Register with orchestrator (in-memory cache)
        from backend.app import get_agent_runner
        try:
            runner = get_agent_runner()
            await runner.orchestrator.register_session(session)
        except RuntimeError:
            # App not fully started yet (e.g. during testing)
            pass

        # 3. Kick off the agent flow
        if mode == ProjectMode.SCRATCH:
            task_type = TaskType.GATHER_REQUIREMENTS
            payload = {"user_input": initial_input or ""}
        elif mode == ProjectMode.INGEST:
            task_type = TaskType.INGEST_PROJECT
            payload = {"project_path": project_path, "user_input": initial_input or ""}
        else:
            task_type = TaskType.GATHER_REQUIREMENTS
            payload = {"user_input": initial_input or ""}

        first_message = AgentMessage(
            task_type  = task_type,
            from_agent = AgentName.ORCHESTRATOR,
            to_agent   = AgentName.ORCHESTRATOR,
            session_id = session.session_id,
            payload    = payload,
        )
        await self._bus.publish(QUEUE_ORCHESTRATOR, first_message)
        logger.info(f"Kickoff message sent: {task_type.value}")

        return session

    async def get_session(self, session_id: str) -> SessionState:
        return await get_session(session_id)

    async def list_sessions(self, status: Optional[str] = None) -> list[SessionState]:
        return await list_sessions(status=status)

    async def update_status(
        self, session_id: str, status: SessionStatus
    ) -> SessionState:
        session = await get_session(session_id)
        session.status = status
        return await update_session(session)

    async def delete_session(self, session_id: str) -> None:
        await delete_session(session_id)

    async def handle_user_message(self, session_id: str, user_input: str) -> None:
        """
        Route a follow-up user message into the session's active agent.

        The orchestrator decides which agent is currently active and routes
        the message correctly. For Phase 1, we always send to intake queue
        since intake handles multi-turn conversations.
        """
        session = await get_session(session_id)

        message = AgentMessage(
            task_type  = TaskType.GATHER_REQUIREMENTS,
            from_agent = AgentName.ORCHESTRATOR,
            to_agent   = AgentName.INTAKE,
            session_id = session_id,
            payload    = {"user_input": user_input},
        )
        await self._bus.publish(QUEUE_INTAKE, message)
        logger.debug(f"User message routed for session {session_id[:8]}")


# ---------------------------------------------------------------------------
# FastAPI dependency
# ---------------------------------------------------------------------------

_service: Optional[SessionService] = None


def get_session_service() -> SessionService:
    global _service
    if _service is None:
        _service = SessionService()
    return _service
