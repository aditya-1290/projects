"""
backend/services/permission_service.py
----------------------------------------
PermissionService — the Phase 1 Permission Gateway.

Phase 1 behaviour: ASK_EACH_TIME
- Coder calls check_sync() before writing a file
- If no pre-existing grant → adds to pending queue and blocks until resolved
- CLI polls /permissions/{session_id}/pending
- User grants or denies via /permissions/{session_id}/grant or /deny
- Grant is stored in DB; check_sync() returns True/False

Scope logic:
- FILE_SPECIFIC → grant applies only to this file path
- GLOBAL        → grant applies to all remaining writes in this session
"""

from __future__ import annotations

import asyncio
from datetime import datetime
from typing import Optional
from uuid import uuid4

from shared.exceptions import PermissionDeniedError
from shared.logger import get_logger
from shared.types import (
    AgentName, PermissionGrant, PermissionRequest,
    PermissionScope, PermissionType,
)

logger = get_logger(__name__)


class PermissionService:
    """
    In-memory permission gateway with DB persistence for granted permissions.
    Created once by AgentRunner; shared across agents and API layer.
    """

    def __init__(self):
        # session_id → list[PermissionRequest]
        self._pending: dict[str, list[PermissionRequest]] = {}
        # session_id → list[PermissionGrant]
        self._granted: dict[str, list[PermissionGrant]] = {}
        # request_id → asyncio.Event (set when resolved)
        self._resolution_events: dict[str, asyncio.Event] = {}
        # request_id → bool (True=granted, False=denied)
        self._decisions: dict[str, bool] = {}

    # ------------------------------------------------------------------
    # Agent-facing: synchronous check (called from CoderAgent callback)
    # ------------------------------------------------------------------

    def check_sync(self, session_id: str, file_path: str, diff: str) -> bool:
        """
        Synchronous permission check — called by CoderAgent before writing.

        1. Check if a global grant exists for this session → return True
        2. Check if a file-specific grant exists → return True
        3. Otherwise: add a pending request and BLOCK until resolved

        Note: This runs in the asyncio event loop so we use
        asyncio.get_event_loop().run_until_complete() pattern via
        a Future that gets resolved from the API layer.
        """
        # Check for existing global grant
        if self._has_global_grant(session_id):
            logger.debug(f"Global grant active for session {session_id[:8]}")
            return True

        # Check for file-specific grant
        if self._has_file_grant(session_id, file_path):
            logger.debug(f"File grant exists for {file_path}")
            return True

        # No grant — create pending request
        request = PermissionRequest(
            request_id      = str(uuid4()),
            session_id      = session_id,
            permission_type = PermissionType.PATCH,
            scope           = PermissionScope.FILE_SPECIFIC,
            requested_by    = AgentName.CODER,
            file_path       = file_path,
            diff_preview    = diff[:2000] if diff else None,  # cap preview size
        )
        self._add_pending(session_id, request)
        logger.info(f"Permission requested: {file_path} (req={request.request_id[:8]})")

        # Block (via asyncio) until the user resolves this request
        loop = asyncio.get_event_loop()
        event = asyncio.Event()
        self._resolution_events[request.request_id] = event

        # Wait for resolution (with timeout)
        try:
            loop.run_until_complete(
                asyncio.wait_for(event.wait(), timeout=300.0)
            )
        except asyncio.TimeoutError:
            logger.warning(f"Permission request timed out: {request.request_id[:8]}")
            self._cleanup_request(session_id, request.request_id)
            return False

        decision = self._decisions.pop(request.request_id, False)
        self._cleanup_request(session_id, request.request_id)
        return decision

    # ------------------------------------------------------------------
    # API-facing: grant / deny
    # ------------------------------------------------------------------

    async def grant(
        self,
        session_id: str,
        request_id: str,
        scope:      PermissionScope = PermissionScope.FILE_SPECIFIC,
    ) -> PermissionGrant:
        """Grant a specific permission request."""
        request = self._find_pending(session_id, request_id)
        if not request:
            raise PermissionDeniedError(f"No pending request: {request_id}")

        grant = PermissionGrant(
            permission_id   = str(uuid4()),
            session_id      = session_id,
            permission_type = request.permission_type,
            scope           = scope,
            file_path       = request.file_path if scope == PermissionScope.FILE_SPECIFIC else None,
            granted_at      = datetime.utcnow(),
        )

        # Persist to DB
        await self._save_grant_to_db(grant)

        # Cache in memory
        self._granted.setdefault(session_id, []).append(grant)

        # Resolve the waiting agent
        self._decisions[request_id] = True
        if event := self._resolution_events.get(request_id):
            event.set()

        logger.info(
            f"Permission granted: {request.file_path} scope={scope.value} "
            f"(req={request_id[:8]})"
        )
        return grant

    def deny(self, session_id: str, request_id: str) -> None:
        """Deny a specific permission request."""
        self._decisions[request_id] = False
        if event := self._resolution_events.get(request_id):
            event.set()

        self._remove_pending(session_id, request_id)
        logger.info(f"Permission denied: req={request_id[:8]}")

    async def grant_all(self, session_id: str) -> int:
        """Grant all pending requests for a session at global scope."""
        pending = list(self._pending.get(session_id, []))
        count = 0
        for request in pending:
            await self.grant(session_id, request.request_id, PermissionScope.GLOBAL)
            count += 1

        # Also store a sentinel global grant so future requests auto-pass
        global_grant = PermissionGrant(
            permission_id   = str(uuid4()),
            session_id      = session_id,
            permission_type = PermissionType.PATCH,
            scope           = PermissionScope.GLOBAL,
            file_path       = None,
            granted_at      = datetime.utcnow(),
        )
        await self._save_grant_to_db(global_grant)
        self._granted.setdefault(session_id, []).append(global_grant)
        logger.info(f"Global grant set for session {session_id[:8]}")
        return count

    # ------------------------------------------------------------------
    # Query helpers
    # ------------------------------------------------------------------

    def get_pending(self, session_id: str) -> list[PermissionRequest]:
        return list(self._pending.get(session_id, []))

    async def list_granted(self, session_id: str) -> list[PermissionGrant]:
        return list(self._granted.get(session_id, []))

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _has_global_grant(self, session_id: str) -> bool:
        for g in self._granted.get(session_id, []):
            if g.scope == PermissionScope.GLOBAL:
                return True
        return False

    def _has_file_grant(self, session_id: str, file_path: str) -> bool:
        for g in self._granted.get(session_id, []):
            if g.scope == PermissionScope.FILE_SPECIFIC and g.file_path == file_path:
                return True
        return False

    def _add_pending(self, session_id: str, request: PermissionRequest) -> None:
        self._pending.setdefault(session_id, []).append(request)

    def _find_pending(
        self, session_id: str, request_id: str
    ) -> Optional[PermissionRequest]:
        for r in self._pending.get(session_id, []):
            if r.request_id == request_id:
                return r
        return None

    def _remove_pending(self, session_id: str, request_id: str) -> None:
        self._pending[session_id] = [
            r for r in self._pending.get(session_id, [])
            if r.request_id != request_id
        ]

    def _cleanup_request(self, session_id: str, request_id: str) -> None:
        self._remove_pending(session_id, request_id)
        self._resolution_events.pop(request_id, None)

    async def _save_grant_to_db(self, grant: PermissionGrant) -> None:
        """Persist a grant to the SQLite permissions table."""
        try:
            from storage.database.connection import async_db
            async with async_db() as db:
                await db.execute(
                    """
                    INSERT INTO permissions (
                        permission_id, session_id, permission_type,
                        scope, file_path, granted_at, expires_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        grant.permission_id,
                        grant.session_id,
                        grant.permission_type.value,
                        grant.scope.value,
                        grant.file_path,
                        grant.granted_at.isoformat(),
                        grant.expires_at.isoformat() if grant.expires_at else None,
                    ),
                )
                await db.commit()
        except Exception as e:
            logger.error(f"Failed to persist permission grant: {e}")


# ---------------------------------------------------------------------------
# FastAPI dependency
# ---------------------------------------------------------------------------

def get_permission_service() -> PermissionService:
    from backend.app import get_agent_runner
    try:
        return get_agent_runner().permission_service
    except RuntimeError:
        # Fallback for testing
        return PermissionService()
