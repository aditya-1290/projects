"""
backend/api/sessions.py
------------------------
Session management endpoints.

Routes:
  POST   /sessions              — create and start a new session
  GET    /sessions              — list all sessions
  GET    /sessions/{id}         — get a session by ID
  PATCH  /sessions/{id}/status  — update session status
  DELETE /sessions/{id}         — delete a session
  POST   /sessions/{id}/message — send a user message into an active session
"""

from __future__ import annotations

from typing import Optional
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from backend.services.session_service import SessionService, get_session_service
from shared.types import ProjectMode, SessionStatus, UserType

router = APIRouter(prefix="/sessions", tags=["sessions"])


# ---------------------------------------------------------------------------
# Request / Response schemas
# ---------------------------------------------------------------------------

class CreateSessionRequest(BaseModel):
    project_name: str                       = Field(..., min_length=1, max_length=200)
    project_path: str                       = Field(..., min_length=1)
    mode:         ProjectMode               = ProjectMode.SCRATCH
    user_type:    UserType                  = UserType.DEVELOPER
    user_input:   Optional[str]             = None  # optional first message


class SessionResponse(BaseModel):
    session_id:         str
    project_name:       str
    project_path:       str
    mode:               str
    status:             str
    user_type:          str
    language_stack:     list[str]
    git_enabled:        bool
    test_depth:         str
    patch_permission:   str
    created_at:         str
    updated_at:         str
    last_checkpoint_id: Optional[str]


class UpdateStatusRequest(BaseModel):
    status: SessionStatus


class UserMessageRequest(BaseModel):
    user_input: str = Field(..., min_length=1)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _to_response(session) -> SessionResponse:
    return SessionResponse(
        session_id         = session.session_id,
        project_name       = session.project_name,
        project_path       = session.project_path,
        mode               = session.mode.value,
        status             = session.status.value,
        user_type          = session.user_type.value,
        language_stack     = session.language_stack,
        git_enabled        = session.git_enabled,
        test_depth         = session.test_depth.value,
        patch_permission   = session.patch_permission.value,
        created_at         = session.created_at.isoformat(),
        updated_at         = session.updated_at.isoformat(),
        last_checkpoint_id = session.last_checkpoint_id,
    )


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@router.post("", status_code=201, response_model=SessionResponse)
async def create_session(
    body:    CreateSessionRequest,
    service: SessionService = Depends(get_session_service),
):
    """
    Create a new Forge session and kick off the intake flow.
    Returns the created session. Stream updates come via /stream/{session_id}.
    """
    session = await service.create_and_start(
        project_name = body.project_name,
        project_path = body.project_path,
        mode         = body.mode,
        user_type    = body.user_type,
        initial_input = body.user_input,
    )
    return _to_response(session)


@router.get("", response_model=list[SessionResponse])
async def list_sessions(
    status:  Optional[str] = None,
    service: SessionService = Depends(get_session_service),
):
    """List all sessions, optionally filtered by status."""
    sessions = await service.list_sessions(status=status)
    return [_to_response(s) for s in sessions]


@router.get("/{session_id}", response_model=SessionResponse)
async def get_session(
    session_id: str,
    service:    SessionService = Depends(get_session_service),
):
    """Fetch a session by ID."""
    session = await service.get_session(session_id)
    return _to_response(session)


@router.patch("/{session_id}/status", response_model=SessionResponse)
async def update_status(
    session_id: str,
    body:       UpdateStatusRequest,
    service:    SessionService = Depends(get_session_service),
):
    """Update a session's status (e.g. pause, resume)."""
    session = await service.update_status(session_id, body.status)
    return _to_response(session)


@router.delete("/{session_id}", status_code=204)
async def delete_session(
    session_id: str,
    service:    SessionService = Depends(get_session_service),
):
    """Hard delete a session and all related data."""
    await service.delete_session(session_id)


@router.post("/{session_id}/message", status_code=202)
async def send_message(
    session_id: str,
    body:       UserMessageRequest,
    service:    SessionService = Depends(get_session_service),
):
    """
    Send a user message into an active session.
    The message is routed to the appropriate agent via the bus.
    Responses arrive via the /stream/{session_id} SSE endpoint.
    """
    await service.handle_user_message(session_id, body.user_input)
    return {"accepted": True, "session_id": session_id}
