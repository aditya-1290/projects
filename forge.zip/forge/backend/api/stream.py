"""
backend/api/stream.py
----------------------
Server-Sent Events (SSE) endpoint.

Clients connect here to receive real-time updates from agents:
  - status updates (which agent is working, which file)
  - streamed code tokens (code-view mode)
  - checkpoint notifications
  - errors

Route:
  GET /stream/{session_id}        — SSE stream for a session
  GET /stream/{session_id}/status — last known status snapshot (polling fallback)
"""

from __future__ import annotations

import asyncio
import json
from typing import AsyncGenerator

from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse
from sse_starlette.sse import EventSourceResponse

from backend.services.stream_service import StreamService, get_stream_service
from shared.constants import SSE_KEEPALIVE_SECS
from shared.logger import get_logger

logger = get_logger(__name__)
router = APIRouter(prefix="/stream", tags=["stream"])


async def _event_generator(
    session_id: str,
    service: StreamService,
) -> AsyncGenerator[dict, None]:
    """
    Async generator that yields SSE events for a session.
    Runs until the client disconnects or the session completes.
    """
    logger.info(f"SSE client connected for session {session_id[:8]}")

    # Send an immediate connected event
    yield {
        "event": "connected",
        "data": json.dumps({"session_id": session_id, "status": "connected"}),
    }

    keepalive_counter = 0

    try:
        async for event in service.event_stream(session_id):
            yield event

            # Keep-alive comment every N iterations
            keepalive_counter += 1

    except asyncio.CancelledError:
        logger.info(f"SSE client disconnected for session {session_id[:8]}")
    except Exception as e:
        logger.error(f"SSE stream error for {session_id[:8]}: {e}", exc_info=True)
        yield {
            "event": "error",
            "data": json.dumps({"error": str(e)}),
        }


@router.get("/{session_id}")
async def session_stream(
    session_id: str,
    service:    StreamService = Depends(get_stream_service),
):
    """
    SSE stream endpoint for a Forge session.

    Events emitted:
      connected        — on first connect
      status           — agent status updates
      token            — streaming code tokens (code-view mode)
      agent_reply      — agent text replies (intake/architect)
      checkpoint       — checkpoint saved/loaded
      file_written     — a file was written to disk
      build_start      — coder starting a new build
      error            — task error from an agent
      complete         — session complete
    """
    return EventSourceResponse(
        _event_generator(session_id, service),
        ping=SSE_KEEPALIVE_SECS,
    )


@router.get("/{session_id}/status")
async def session_status_snapshot(
    session_id: str,
    service:    StreamService = Depends(get_stream_service),
):
    """
    Polling fallback — returns the last known status for a session.
    Useful for clients that can't use SSE.
    """
    snapshot = service.get_status_snapshot(session_id)
    return snapshot or {"session_id": session_id, "status": "unknown"}
