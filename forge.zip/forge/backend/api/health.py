"""
backend/api/health.py
---------------------
Health check endpoints.
"""

from __future__ import annotations

from fastapi import APIRouter
from shared.constants import APP_NAME, APP_VERSION

router = APIRouter(tags=["health"])


@router.get("/health")
async def health_check():
    return {"status": "ok", "app": APP_NAME, "version": APP_VERSION}


@router.get("/ready")
async def readiness_check():
    """
    Readiness probe — checks DB and bus are alive.
    Expand this in Phase 2 to verify model server connectivity.
    """
    from broker.factory import get_bus
    bus = get_bus()
    return {
        "status": "ready",
        "bus_backend": bus.__class__.__name__,
    }
