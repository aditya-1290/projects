"""
backend/api/permissions.py
---------------------------
Permission Gateway API.

The Coder and Patcher agents call the permission service before writing
or deleting files. The CLI polls this endpoint for pending requests,
displays a diff, and the user grants or denies.

Routes:
  GET    /permissions/{session_id}/pending   — list pending permission requests
  POST   /permissions/{session_id}/grant     — grant a specific request
  POST   /permissions/{session_id}/deny      — deny a specific request
  POST   /permissions/{session_id}/grant-all — grant all pending for session (session_global)
  GET    /permissions/{session_id}           — list all granted permissions for session
"""

from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends
from pydantic import BaseModel

from backend.services.permission_service import PermissionService, get_permission_service
from shared.types import PermissionType, PermissionScope

router = APIRouter(prefix="/permissions", tags=["permissions"])


# ---------------------------------------------------------------------------
# Schemas
# ---------------------------------------------------------------------------

class PendingPermissionResponse(BaseModel):
    request_id:      str
    session_id:      str
    permission_type: str
    scope:           str
    requested_by:    str
    file_path:       Optional[str]
    diff_preview:    Optional[str]


class GrantPermissionRequest(BaseModel):
    request_id: str
    scope:      PermissionScope = PermissionScope.FILE_SPECIFIC


class DenyPermissionRequest(BaseModel):
    request_id: str


class GrantedPermissionResponse(BaseModel):
    permission_id:   str
    session_id:      str
    permission_type: str
    scope:           str
    file_path:       Optional[str]
    granted_at:      str


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@router.get("/{session_id}/pending", response_model=list[PendingPermissionResponse])
async def list_pending(
    session_id: str,
    service:    PermissionService = Depends(get_permission_service),
):
    """Return all pending permission requests for a session."""
    pending = service.get_pending(session_id)
    return [
        PendingPermissionResponse(
            request_id      = r.request_id,
            session_id      = r.session_id,
            permission_type = r.permission_type.value,
            scope           = r.scope.value,
            requested_by    = r.requested_by.value,
            file_path       = r.file_path,
            diff_preview    = r.diff_preview,
        )
        for r in pending
    ]


@router.post("/{session_id}/grant", status_code=200)
async def grant_permission(
    session_id: str,
    body:       GrantPermissionRequest,
    service:    PermissionService = Depends(get_permission_service),
):
    """Grant a specific permission request."""
    grant = await service.grant(session_id, body.request_id, body.scope)
    return {
        "granted":       True,
        "permission_id": grant.permission_id,
        "scope":         grant.scope.value,
    }


@router.post("/{session_id}/deny", status_code=200)
async def deny_permission(
    session_id: str,
    body:       DenyPermissionRequest,
    service:    PermissionService = Depends(get_permission_service),
):
    """Deny a specific permission request."""
    service.deny(session_id, body.request_id)
    return {"denied": True, "request_id": body.request_id}


@router.post("/{session_id}/grant-all", status_code=200)
async def grant_all(
    session_id: str,
    service:    PermissionService = Depends(get_permission_service),
):
    """
    Grant all pending permission requests for a session at global scope.
    Equivalent to the user saying 'yes to all' for this session.
    """
    count = await service.grant_all(session_id)
    return {"granted_count": count, "scope": PermissionScope.GLOBAL.value}


@router.get("/{session_id}", response_model=list[GrantedPermissionResponse])
async def list_granted(
    session_id: str,
    service:    PermissionService = Depends(get_permission_service),
):
    """List all granted permissions for a session."""
    grants = await service.list_granted(session_id)
    return [
        GrantedPermissionResponse(
            permission_id   = g.permission_id,
            session_id      = g.session_id,
            permission_type = g.permission_type.value,
            scope           = g.scope.value,
            file_path       = g.file_path,
            granted_at      = g.granted_at.isoformat(),
        )
        for g in grants
    ]
