"""
memory/session_store.py
-----------------------
Session CRUD operations against SQLite.
All agent and backend code uses this — never touches the DB directly.
"""

from __future__ import annotations

import json
from datetime import datetime
from typing import List, Optional
from uuid import uuid4

from storage.database.connection import async_db, sync_db
from shared.exceptions import SessionNotFoundError, DatabaseError
from shared.logger import get_logger
from shared.types import (
    SessionState, ProjectMode, SessionStatus,
    UserType, TestDepth, PatchPermission
)

logger = get_logger(__name__)


def _row_to_session(row) -> SessionState:
    """Convert a DB row to a SessionState dataclass."""
    return SessionState(
        session_id         = row["session_id"],
        project_name       = row["project_name"],
        project_path       = row["project_path"],
        mode               = ProjectMode(row["mode"]),
        status             = SessionStatus(row["status"]),
        user_type          = UserType(row["user_type"]),
        language_stack     = json.loads(row["language_stack"]),
        git_enabled        = bool(row["git_enabled"]),
        test_depth         = TestDepth(row["test_depth"]),
        patch_permission   = PatchPermission(row["patch_permission"]),
        created_at         = datetime.fromisoformat(row["created_at"]),
        updated_at         = datetime.fromisoformat(row["updated_at"]),
        last_checkpoint_id = row["last_checkpoint_id"],
    )


# ---------------------------------------------------------------------------
# Async CRUD (used by FastAPI + agents)
# ---------------------------------------------------------------------------

async def create_session(session: SessionState) -> SessionState:
    """Persist a new session to the database."""
    async with async_db() as db:
        await db.execute(
            """
            INSERT INTO sessions (
                session_id, project_name, project_path, mode, status,
                user_type, language_stack, git_enabled, test_depth,
                patch_permission, created_at, updated_at, last_checkpoint_id
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                session.session_id,
                session.project_name,
                session.project_path,
                session.mode.value,
                session.status.value,
                session.user_type.value,
                json.dumps(session.language_stack),
                int(session.git_enabled),
                session.test_depth.value,
                session.patch_permission.value,
                session.created_at.isoformat(),
                session.updated_at.isoformat(),
                session.last_checkpoint_id,
            ),
        )
        await db.commit()
    logger.info(f"Session created: {session.session_id} ({session.project_name})")
    return session


async def get_session(session_id: str) -> SessionState:
    """Fetch a session by ID. Raises SessionNotFoundError if missing."""
    async with async_db() as db:
        cursor = await db.execute(
            "SELECT * FROM sessions WHERE session_id = ?", (session_id,)
        )
        row = await cursor.fetchone()

    if row is None:
        raise SessionNotFoundError(f"Session not found: {session_id}")
    return _row_to_session(row)


async def list_sessions(status: Optional[str] = None) -> List[SessionState]:
    """List all sessions, optionally filtered by status."""
    async with async_db() as db:
        if status:
            cursor = await db.execute(
                "SELECT * FROM sessions WHERE status = ? ORDER BY updated_at DESC",
                (status,)
            )
        else:
            cursor = await db.execute(
                "SELECT * FROM sessions ORDER BY updated_at DESC"
            )
        rows = await cursor.fetchall()
    return [_row_to_session(r) for r in rows]


async def update_session(session: SessionState) -> SessionState:
    """Update an existing session record."""
    session.updated_at = datetime.utcnow()
    async with async_db() as db:
        await db.execute(
            """
            UPDATE sessions SET
                project_name       = ?,
                status             = ?,
                user_type          = ?,
                language_stack     = ?,
                git_enabled        = ?,
                test_depth         = ?,
                patch_permission   = ?,
                updated_at         = ?,
                last_checkpoint_id = ?
            WHERE session_id = ?
            """,
            (
                session.project_name,
                session.status.value,
                session.user_type.value,
                json.dumps(session.language_stack),
                int(session.git_enabled),
                session.test_depth.value,
                session.patch_permission.value,
                session.updated_at.isoformat(),
                session.last_checkpoint_id,
                session.session_id,
            ),
        )
        await db.commit()
    return session


async def delete_session(session_id: str) -> None:
    """Hard delete a session and all its related records."""
    async with async_db() as db:
        await db.execute("DELETE FROM permissions WHERE session_id = ?", (session_id,))
        await db.execute("DELETE FROM project_files WHERE session_id = ?", (session_id,))
        await db.execute("DELETE FROM checkpoints WHERE session_id = ?", (session_id,))
        await db.execute("DELETE FROM sessions WHERE session_id = ?", (session_id,))
        await db.commit()
    logger.info(f"Session deleted: {session_id}")


# ---------------------------------------------------------------------------
# Sync CRUD (used by CLI in non-async contexts)
# ---------------------------------------------------------------------------

def get_session_sync(session_id: str) -> SessionState:
    with sync_db() as db:
        cursor = db.execute(
            "SELECT * FROM sessions WHERE session_id = ?", (session_id,)
        )
        row = cursor.fetchone()
    if row is None:
        raise SessionNotFoundError(f"Session not found: {session_id}")
    return _row_to_session(row)


def list_sessions_sync() -> List[SessionState]:
    with sync_db() as db:
        cursor = db.execute(
            "SELECT * FROM sessions ORDER BY updated_at DESC"
        )
        rows = cursor.fetchall()
    return [_row_to_session(r) for r in rows]


# ---------------------------------------------------------------------------
# Factory helper
# ---------------------------------------------------------------------------

def make_session(
    project_name: str,
    project_path: str,
    mode: ProjectMode,
    user_type: UserType = UserType.DEVELOPER,
) -> SessionState:
    """Create a new SessionState with a generated ID and sensible defaults."""
    now = datetime.utcnow()
    return SessionState(
        session_id   = str(uuid4()),
        project_name = project_name,
        project_path = project_path,
        mode         = mode,
        status       = SessionStatus.ACTIVE,
        user_type    = user_type,
        created_at   = now,
        updated_at   = now,
    )
