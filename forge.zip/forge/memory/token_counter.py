"""
memory/token_counter.py
------------------------
Tracks estimated token usage per agent call.
Used by the checkpoint monitor to trigger saves before context burst.

We use character-based estimation (chars / 4) since we have no tokenizer
for the local model. This is a safe conservative estimate.
"""

from __future__ import annotations

from shared.constants import CHECKPOINT_TOKEN_THRESHOLD, DEFAULT_CONTEXT_WINDOW
from shared.exceptions import AgentContextBurstError
from shared.logger import get_logger

logger = get_logger(__name__)


def estimate_tokens(text: str) -> int:
    """
    Estimate token count from text.
    Rule of thumb: ~4 characters per token for English/code.
    """
    return max(1, len(text) // 4)


def estimate_messages_tokens(messages: list[dict]) -> int:
    """Estimate total tokens for a list of chat messages."""
    total = 0
    for msg in messages:
        content = msg.get("content", "")
        if isinstance(content, str):
            total += estimate_tokens(content)
        elif isinstance(content, list):
            for block in content:
                if isinstance(block, dict) and "text" in block:
                    total += estimate_tokens(block["text"])
        # Add ~4 tokens overhead per message (role, formatting)
        total += 4
    return total


class TokenBudget:
    """
    Tracks token usage for a single agent session.
    Raises AgentContextBurstError when approaching the limit.
    """

    def __init__(
        self,
        context_window: int = DEFAULT_CONTEXT_WINDOW,
        threshold: float = CHECKPOINT_TOKEN_THRESHOLD,
    ):
        self.context_window  = context_window
        self.threshold       = threshold
        self.used_tokens     = 0
        self.checkpoint_limit = int(context_window * threshold)

    def add(self, text: str) -> int:
        """Add text to the budget. Returns current total. Raises on threshold breach."""
        tokens = estimate_tokens(text)
        self.used_tokens += tokens

        pct = self.used_tokens / self.context_window
        logger.debug(
            f"Token budget: {self.used_tokens}/{self.context_window} "
            f"({pct:.1%}) limit={self.checkpoint_limit}"
        )

        if self.used_tokens >= self.checkpoint_limit:
            raise AgentContextBurstError(
                f"Token budget at {pct:.1%} — checkpoint required before continuing."
            )
        return self.used_tokens

    def add_messages(self, messages: list[dict]) -> int:
        """Add a list of messages to the budget."""
        tokens = estimate_messages_tokens(messages)
        self.used_tokens += tokens
        if self.used_tokens >= self.checkpoint_limit:
            pct = self.used_tokens / self.context_window
            raise AgentContextBurstError(
                f"Token budget at {pct:.1%} — checkpoint required."
            )
        return self.used_tokens

    def remaining(self) -> int:
        return max(0, self.checkpoint_limit - self.used_tokens)

    def percent_used(self) -> float:
        return self.used_tokens / self.context_window

    def reset(self) -> None:
        self.used_tokens = 0

    def __repr__(self) -> str:
        return (
            f"TokenBudget("
            f"used={self.used_tokens}, "
            f"limit={self.checkpoint_limit}, "
            f"window={self.context_window})"
        )
