"""
memory/checkpoint_store.py
---------------------------
Checkpoint CRUD operations against SQLite.
Checkpoints are the backbone of Forge's context recovery system.
"""

from __future__ import annotations

import json
from datetime import datetime
from typing import List, Optional

from storage.database.connection import async_db, sync_db
from shared.exceptions import CheckpointNotFoundError
from shared.logger import get_logger
from shared.types import AgentName, CheckpointData

logger = get_logger(__name__)


def _row_to_checkpoint(row) -> CheckpointData:
    return CheckpointData(
        checkpoint_id        = row["checkpoint_id"],
        session_id           = row["session_id"],
        step_number          = row["step_number"],
        agent_who_saved      = AgentName(row["agent_who_saved"]),
        summary_of_work_done = row["summary_of_work_done"],
        files_touched        = json.loads(row["files_touched"]),
        next_planned_step    = row["next_planned_step"],
        token_count_at_save  = row["token_count_at_save"],
        created_at           = datetime.fromisoformat(row["created_at"]),
    )


async def save_checkpoint(checkpoint: CheckpointData) -> CheckpointData:
    """Persist a checkpoint. Also updates the session's last_checkpoint_id."""
    async with async_db() as db:
        await db.execute(
            """
            INSERT INTO checkpoints (
                checkpoint_id, session_id, step_number, agent_who_saved,
                summary_of_work_done, files_touched, next_planned_step,
                token_count_at_save, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                checkpoint.checkpoint_id,
                checkpoint.session_id,
                checkpoint.step_number,
                checkpoint.agent_who_saved.value,
                checkpoint.summary_of_work_done,
                json.dumps(checkpoint.files_touched),
                checkpoint.next_planned_step,
                checkpoint.token_count_at_save,
                checkpoint.created_at.isoformat(),
            ),
        )
        # Update session's last_checkpoint_id pointer
        await db.execute(
            "UPDATE sessions SET last_checkpoint_id = ?, updated_at = ? WHERE session_id = ?",
            (checkpoint.checkpoint_id, datetime.utcnow().isoformat(), checkpoint.session_id),
        )
        await db.commit()

    logger.info(
        f"Checkpoint saved: {checkpoint.checkpoint_id[:8]} "
        f"step={checkpoint.step_number} "
        f"tokens={checkpoint.token_count_at_save}"
    )
    return checkpoint


async def get_checkpoint(checkpoint_id: str) -> CheckpointData:
    """Fetch a specific checkpoint by ID."""
    async with async_db() as db:
        cursor = await db.execute(
            "SELECT * FROM checkpoints WHERE checkpoint_id = ?", (checkpoint_id,)
        )
        row = await cursor.fetchone()
    if row is None:
        raise CheckpointNotFoundError(f"Checkpoint not found: {checkpoint_id}")
    return _row_to_checkpoint(row)


async def get_latest_checkpoint(session_id: str) -> Optional[CheckpointData]:
    """Fetch the most recent checkpoint for a session. Returns None if none exist."""
    async with async_db() as db:
        cursor = await db.execute(
            """
            SELECT * FROM checkpoints
            WHERE session_id = ?
            ORDER BY step_number DESC
            LIMIT 1
            """,
            (session_id,),
        )
        row = await cursor.fetchone()
    return _row_to_checkpoint(row) if row else None


async def list_checkpoints(session_id: str) -> List[CheckpointData]:
    """List all checkpoints for a session, newest first."""
    async with async_db() as db:
        cursor = await db.execute(
            "SELECT * FROM checkpoints WHERE session_id = ? ORDER BY step_number DESC",
            (session_id,),
        )
        rows = await cursor.fetchall()
    return [_row_to_checkpoint(r) for r in rows]


async def get_next_step_number(session_id: str) -> int:
    """Return the next step number for a session's checkpoint sequence."""
    async with async_db() as db:
        cursor = await db.execute(
            "SELECT MAX(step_number) as max_step FROM checkpoints WHERE session_id = ?",
            (session_id,),
        )
        row = await cursor.fetchone()
    max_step = row["max_step"] if row and row["max_step"] is not None else 0
    return max_step + 1


# ---------------------------------------------------------------------------
# Factory helper
# ---------------------------------------------------------------------------

def make_checkpoint(
    session_id:           str,
    step_number:          int,
    agent_who_saved:      AgentName,
    summary_of_work_done: str,
    files_touched:        List[dict],
    next_planned_step:    str,
    token_count_at_save:  int,
) -> CheckpointData:
    """Create a CheckpointData with a generated ID."""
    from uuid import uuid4
    return CheckpointData(
        checkpoint_id        = str(uuid4()),
        session_id           = session_id,
        step_number          = step_number,
        agent_who_saved      = agent_who_saved,
        summary_of_work_done = summary_of_work_done,
        files_touched        = files_touched,
        next_planned_step    = next_planned_step,
        token_count_at_save  = token_count_at_save,
        created_at           = datetime.utcnow(),
    )
