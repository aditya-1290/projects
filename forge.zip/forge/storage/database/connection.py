"""
storage/database/connection.py
-------------------------------
SQLite database connection management.
Uses aiosqlite for async operations and provides a sync fallback.

Phase 1: SQLite (local file at ~/.forge/forge.db)
Phase 2: PostgreSQL (team server mode) — swap connection string only
"""

from __future__ import annotations

import sqlite3
from contextlib import asynccontextmanager, contextmanager
from pathlib import Path
from typing import AsyncGenerator, Generator, Optional

import aiosqlite

from shared.logger import get_logger

logger = get_logger(__name__)

_db_path: Optional[str] = None


def init_db_path(path: Optional[str] = None) -> str:
    """
    Resolve and store the DB path. Call once at startup.
    Creates the parent directory if it doesn't exist.
    """
    global _db_path
    from config.settings import get_settings
    resolved = path or get_settings().resolved_db_path()
    _db_path = str(Path(resolved).expanduser())
    Path(_db_path).parent.mkdir(parents=True, exist_ok=True)
    logger.info(f"Database path: {_db_path}")
    return _db_path


def get_db_path() -> str:
    if _db_path is None:
        return init_db_path()
    return _db_path


# ---------------------------------------------------------------------------
# Async connection (used by FastAPI and async agents)
# ---------------------------------------------------------------------------

@asynccontextmanager
async def async_db() -> AsyncGenerator[aiosqlite.Connection, None]:
    """
    Async context manager — yields an aiosqlite connection.

    Usage:
        async with async_db() as db:
            await db.execute("SELECT ...")
            await db.commit()
    """
    path = get_db_path()
    async with aiosqlite.connect(path) as conn:
        conn.row_factory = aiosqlite.Row   # rows accessible as dicts
        await conn.execute("PRAGMA journal_mode=WAL")   # better concurrency
        await conn.execute("PRAGMA foreign_keys=ON")
        yield conn


# ---------------------------------------------------------------------------
# Sync connection (used by CLI sync code and migrations)
# ---------------------------------------------------------------------------

@contextmanager
def sync_db() -> Generator[sqlite3.Connection, None, None]:
    """
    Sync context manager — yields a sqlite3 connection.

    Usage:
        with sync_db() as db:
            db.execute("SELECT ...")
            db.commit()
    """
    path = get_db_path()
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Schema creation — run once at startup
# ---------------------------------------------------------------------------

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS sessions (
    session_id          TEXT PRIMARY KEY,
    project_name        TEXT NOT NULL,
    project_path        TEXT NOT NULL,
    mode                TEXT NOT NULL,
    status              TEXT NOT NULL DEFAULT 'active',
    user_type           TEXT NOT NULL DEFAULT 'developer',
    language_stack      TEXT NOT NULL DEFAULT '[]',
    git_enabled         INTEGER NOT NULL DEFAULT 0,
    test_depth          TEXT NOT NULL DEFAULT 'auto',
    patch_permission    TEXT NOT NULL DEFAULT 'ask_each_time',
    created_at          TEXT NOT NULL,
    updated_at          TEXT NOT NULL,
    last_checkpoint_id  TEXT
);

CREATE TABLE IF NOT EXISTS checkpoints (
    checkpoint_id           TEXT PRIMARY KEY,
    session_id              TEXT NOT NULL REFERENCES sessions(session_id),
    step_number             INTEGER NOT NULL,
    agent_who_saved         TEXT NOT NULL,
    summary_of_work_done    TEXT NOT NULL,
    files_touched           TEXT NOT NULL DEFAULT '[]',
    next_planned_step       TEXT NOT NULL,
    token_count_at_save     INTEGER NOT NULL DEFAULT 0,
    created_at              TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS permissions (
    permission_id       TEXT PRIMARY KEY,
    session_id          TEXT NOT NULL REFERENCES sessions(session_id),
    permission_type     TEXT NOT NULL,
    scope               TEXT NOT NULL,
    file_path           TEXT,
    granted_at          TEXT NOT NULL,
    expires_at          TEXT
);

CREATE TABLE IF NOT EXISTS project_files (
    file_id             TEXT PRIMARY KEY,
    session_id          TEXT NOT NULL REFERENCES sessions(session_id),
    file_path           TEXT NOT NULL,
    language            TEXT NOT NULL DEFAULT '',
    last_read_at        TEXT,
    last_written_at     TEXT,
    chroma_embedded     INTEGER NOT NULL DEFAULT 0,
    UNIQUE(session_id, file_path)
);

CREATE INDEX IF NOT EXISTS idx_checkpoints_session
    ON checkpoints(session_id);

CREATE INDEX IF NOT EXISTS idx_permissions_session
    ON permissions(session_id);

CREATE INDEX IF NOT EXISTS idx_project_files_session
    ON project_files(session_id);
"""


def create_schema() -> None:
    """Create all tables if they don't exist. Safe to call on every startup."""
    with sync_db() as conn:
        conn.executescript(SCHEMA_SQL)
    logger.info("Database schema verified/created")


async def create_schema_async() -> None:
    """Async version of create_schema for use in async startup handlers."""
    async with async_db() as conn:
        await conn.executescript(SCHEMA_SQL)
        await conn.commit()
    logger.info("Database schema verified/created (async)")
