"""
cli/views/code_view.py
-----------------------
Code view — live code streaming display.
Shows tokens as the Coder agent generates them, with syntax highlighting.
Toggled by the user pressing 'v' during a session.
"""

from __future__ import annotations

from typing import Optional

from rich.console import Console
from rich.syntax import Syntax
from rich.text import Text


class CodeView:
    """
    Renders streaming code tokens to the terminal.
    Buffers per-file output and re-renders with syntax highlighting.
    """

    def __init__(self, console: Console):
        self._console = console
        self._current_file: Optional[str] = None
        self._current_language: str = "python"
        self._buffer: str = ""
        self._files_completed: list[tuple[str, str, str]] = []  # (path, lang, code)

    def start_file(self, file_path: str, language: str) -> None:
        """Called when coder starts a new file."""
        if self._buffer and self._current_file:
            self._flush_completed()

        self._current_file = file_path
        self._current_language = language or "text"
        self._buffer = ""

        self._console.print()
        self._console.print(
            f"[dim]── writing[/dim] [bold cyan]{file_path}[/bold cyan]"
        )

    def add_token(self, token: str) -> None:
        """Append a streaming token. Print it raw (no re-render for speed)."""
        self._buffer += token
        # Print token directly for low-latency streaming feel
        self._console.print(token, end="", highlight=False, markup=False)

    def finish_file(self, file_path: str) -> None:
        """Called when a file write is confirmed. Print final highlighted version."""
        if self._buffer:
            # Clear the raw-streamed content by overwriting with highlighted version
            self._console.print()  # end the raw token line
            self._console.print(
                f"[bold green]✓[/bold green] [cyan]{file_path}[/cyan] [dim]({len(self._buffer)} chars)[/dim]"
            )
            self._files_completed.append(
                (file_path, self._current_language, self._buffer)
            )
            self._buffer = ""
            self._current_file = None

    def _flush_completed(self) -> None:
        """Flush current buffer as a completed file."""
        if self._current_file and self._buffer:
            self._files_completed.append(
                (self._current_file, self._current_language, self._buffer)
            )

    def show_highlighted(self, file_path: str, language: str, code: str) -> None:
        """Re-render a completed file with full syntax highlighting."""
        self._console.print()
        self._console.print(
            f"[dim]── [/dim][bold cyan]{file_path}[/bold cyan]"
        )
        syntax = Syntax(
            code,
            language,
            theme="monokai",
            line_numbers=True,
            word_wrap=False,
        )
        self._console.print(syntax)

    def print_token_raw(self, token: str) -> None:
        """Print a raw token without any buffering (for simple passthrough)."""
        self._console.print(token, end="", highlight=False, markup=False)
