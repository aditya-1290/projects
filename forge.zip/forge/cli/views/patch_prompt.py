"""
cli/views/patch_prompt.py
--------------------------
Patch permission prompt.
Shown when the Coder agent requests permission to write a file.
Displays the diff preview and waits for user input (y/n/a).
"""

from __future__ import annotations

from typing import Optional

from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax
from rich.text import Text


class PatchPrompt:
    """
    Displays a permission request and captures the user's decision.
    """

    def __init__(self, console: Console):
        self._console = console

    def ask(
        self,
        file_path: str,
        diff_preview: Optional[str],
        request_id: str,
    ) -> str:
        """
        Show the patch prompt and return the user's choice:
          'y'  — grant (file-specific)
          'a'  — grant all (session-global, no more prompts)
          'n'  — deny this file
        """
        self._console.print()
        self._console.rule(
            f"[bold yellow]Permission Request[/bold yellow]", style="yellow"
        )
        self._console.print(
            f"  Forge wants to write: [bold cyan]{file_path}[/bold cyan]"
        )

        if diff_preview:
            self._console.print()
            self._console.print("  [dim]Preview:[/dim]")
            # Show diff with simple syntax highlighting
            syntax = Syntax(
                diff_preview[:1500],  # cap display length
                "diff",
                theme="monokai",
                word_wrap=True,
            )
            self._console.print(
                Panel(syntax, border_style="dim", padding=(0, 1))
            )

        self._console.print()
        self._console.print(
            "  [bold cyan]y[/bold cyan] write this file  "
            "[bold cyan]a[/bold cyan] write all (no more prompts)  "
            "[bold cyan]n[/bold cyan] skip this file"
        )
        self._console.print()

        while True:
            choice = self._console.input("  [bold cyan]>[/bold cyan] ").strip().lower()
            if choice in ("y", "yes"):
                return "y"
            elif choice in ("a", "all"):
                return "a"
            elif choice in ("n", "no", "skip"):
                return "n"
            else:
                self._console.print(
                    "  [dim]Enter y (yes), a (all), or n (no)[/dim]"
                )

    def show_granted(self, file_path: str) -> None:
        self._console.print(
            f"  [bold green]✓[/bold green] Writing [cyan]{file_path}[/cyan]"
        )

    def show_denied(self, file_path: str) -> None:
        self._console.print(
            f"  [dim]✗ Skipped {file_path}[/dim]"
        )

    def show_all_granted(self) -> None:
        self._console.print(
            "  [bold green]✓[/bold green] [dim]All future writes approved for this session[/dim]"
        )
