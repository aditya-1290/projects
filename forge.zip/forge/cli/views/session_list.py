"""
cli/views/session_list.py
--------------------------
Session list view — renders a Rich table of all Forge sessions.
Used by `forge sessions` command.
"""

from __future__ import annotations

from rich.console import Console
from rich.table import Table
from rich.text import Text

from cli.themes.forge_theme import STATUS_ICONS


def render_session_list(console: Console, sessions: list[dict]) -> None:
    """Render sessions as a Rich table."""
    if not sessions:
        console.print("[dim]No sessions found.[/dim]")
        return

    table = Table(
        show_header=True,
        header_style="bold dim white",
        border_style="dim",
        box=None,
        padding=(0, 2),
        expand=False,
    )

    table.add_column("ID",       style="dim", width=10)
    table.add_column("Project",  style="bold white", min_width=20)
    table.add_column("Mode",     style="cyan", width=8)
    table.add_column("Status",   width=12)
    table.add_column("Updated",  style="dim", width=20)

    for s in sessions:
        session_id = s.get("session_id", "")[:8]
        project    = s.get("project_name", "unknown")
        mode       = s.get("mode", "")
        status     = s.get("status", "")
        updated    = s.get("updated_at", "")[:19].replace("T", " ")

        # Status icon
        icon, color = STATUS_ICONS.get(status, ("●", "white"))
        status_text = Text()
        status_text.append(f"{icon} ", style=color)
        status_text.append(status, style=color)

        table.add_row(session_id, project, mode, status_text, updated)

    console.print()
    console.print(table)
    console.print(
        f"  [dim]{len(sessions)} session{'s' if len(sessions) != 1 else ''}[/dim]"
    )
    console.print()


def render_session_detail(console: Console, session: dict) -> None:
    """Render a single session's full detail."""
    console.print()
    console.rule(
        f"[bold cyan]{session.get('project_name', 'Session')}[/bold cyan]",
        style="cyan",
    )

    fields = [
        ("ID",           session.get("session_id", "")[:16]),
        ("Project",      session.get("project_name", "")),
        ("Path",         session.get("project_path", "")),
        ("Mode",         session.get("mode", "")),
        ("Status",       session.get("status", "")),
        ("User type",    session.get("user_type", "")),
        ("Languages",    ", ".join(session.get("language_stack", [])) or "none"),
        ("Git enabled",  str(session.get("git_enabled", False))),
        ("Test depth",   session.get("test_depth", "")),
        ("Permissions",  session.get("patch_permission", "")),
        ("Checkpoint",   session.get("last_checkpoint_id", "none") or "none"),
        ("Created",      session.get("created_at", "")[:19].replace("T", " ")),
        ("Updated",      session.get("updated_at", "")[:19].replace("T", " ")),
    ]

    for label, value in fields:
        console.print(f"  [dim]{label:<14}[/dim] [white]{value}[/white]")

    console.rule(style="dim")
