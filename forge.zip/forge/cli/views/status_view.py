"""
cli/views/status_view.py
-------------------------
Status view — shown during agent execution.
Displays: active agent, current action, files written, token usage.
Uses Rich Live for real-time updates without screen flicker.
"""

from __future__ import annotations

from datetime import datetime
from typing import Optional

from rich.columns import Columns
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from cli.themes.forge_theme import AGENT_STYLES, STATUS_ICONS, FORGE_THEME


class StatusView:
    """
    Real-time status display during a Forge session.
    Call update() whenever an SSE event arrives.
    """

    def __init__(self, console: Console, session_id: str, project_name: str):
        self._console = console
        self._session_id = session_id
        self._project_name = project_name

        self._current_agent: str = "orchestrator"
        self._current_action: str = "Initialising..."
        self._current_file: Optional[str] = None
        self._files_written: list[str] = []
        self._started_at = datetime.now()
        self._checkpoints: int = 0
        self._last_event: str = ""

    # ------------------------------------------------------------------
    # Update from SSE events
    # ------------------------------------------------------------------

    def update(self, event_type: str, data: dict) -> None:
        """Update internal state from an SSE event dict."""
        self._last_event = event_type

        if event_type == "status":
            action = data.get("detail") or data.get("action", "")
            if action:
                self._current_action = action

        elif event_type == "agent_reply":
            agent = data.get("agent", "")
            if agent:
                self._current_agent = agent

        elif event_type == "writing":
            self._current_action = f"Writing {data.get('detail', '')}"
            self._current_file = data.get("detail")

        elif event_type == "file_written":
            fp = data.get("file_path", "")
            if fp and fp not in self._files_written:
                self._files_written.append(fp)
            self._current_file = None

        elif event_type == "checkpoint":
            self._checkpoints += 1
            self._current_action = f"Checkpoint #{self._checkpoints} saved"

        elif event_type == "build_start":
            self._current_agent = "coder"
            n = len(data.get("build_order", []))
            self._current_action = f"Building {n} files..."

        elif event_type == "designing":
            self._current_agent = "architect"
            self._current_action = "Designing architecture..."

        elif event_type == "error":
            self._current_action = f"[bold red]Error: {data.get('error', 'unknown')}[/bold red]"

    # ------------------------------------------------------------------
    # Render
    # ------------------------------------------------------------------

    def render(self) -> Panel:
        """Build the Rich renderable for the current state."""
        elapsed = datetime.now() - self._started_at
        elapsed_str = f"{int(elapsed.total_seconds())}s"

        # Header row
        agent_style = AGENT_STYLES.get(self._current_agent, "white")
        header = Text()
        header.append("  forge ", style="bold cyan")
        header.append("/ ", style="dim")
        header.append(self._project_name, style="bold white")
        header.append(f"  [{elapsed_str}]", style="dim")

        # Agent + action
        body = Table.grid(padding=(0, 2))
        body.add_column(style="dim white", min_width=12)
        body.add_column()

        body.add_row(
            "agent",
            Text(self._current_agent, style=agent_style),
        )
        body.add_row(
            "status",
            Text(self._current_action, style="white"),
        )

        if self._current_file:
            body.add_row(
                "writing",
                Text(self._current_file, style="bold green"),
            )

        body.add_row(
            "written",
            Text(
                f"{len(self._files_written)} file{'s' if len(self._files_written) != 1 else ''}",
                style="cyan",
            ),
        )

        if self._checkpoints:
            body.add_row(
                "checkpoints",
                Text(str(self._checkpoints), style="yellow"),
            )

        # Recent files (last 5)
        file_lines = Text()
        for fp in self._files_written[-5:]:
            file_lines.append(f"  ✓ {fp}\n", style="dim green")

        content = Text()
        content.append_text(header)
        content.append("\n\n")

        from rich.console import Group
        renderable = Panel(
            Group(body, file_lines) if self._files_written else body,
            title="[bold cyan]forge[/bold cyan]",
            subtitle=f"[dim]{self._session_id[:8]}[/dim]",
            border_style="cyan",
            padding=(1, 2),
        )
        return renderable

    def print_final_summary(self) -> None:
        """Print a completion summary after the session ends."""
        elapsed = datetime.now() - self._started_at

        self._console.print()
        self._console.rule("[bold cyan]Session Complete[/bold cyan]", style="cyan")
        self._console.print(
            f"  [dim]Project[/dim]   [white]{self._project_name}[/white]"
        )
        self._console.print(
            f"  [dim]Files[/dim]     [bold green]{len(self._files_written)} written[/bold green]"
        )
        self._console.print(
            f"  [dim]Time[/dim]      [white]{int(elapsed.total_seconds())}s[/white]"
        )
        self._console.print(
            f"  [dim]Checkpoints[/dim] [yellow]{self._checkpoints}[/yellow]"
        )
        if self._files_written:
            self._console.print()
            self._console.print("  [dim]Files written:[/dim]")
            for fp in self._files_written:
                self._console.print(f"    [green]✓[/green] {fp}")
        self._console.rule(style="dim")
