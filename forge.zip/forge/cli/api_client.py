"""
cli/api_client.py
------------------
HTTP client for the Forge backend API.
All CLI commands use this — never call requests/httpx directly.

Wraps:
  - Session CRUD
  - Message sending
  - Permission grant/deny
  - SSE stream consumption
  - Health check
"""

from __future__ import annotations

import json
import sys
from typing import Any, Generator, Optional

import httpx

from shared.constants import API_HOST, API_PORT, API_PREFIX
from shared.logger import get_logger

logger = get_logger(__name__)

_BASE = f"http://{API_HOST}:{API_PORT}{API_PREFIX}"
_TIMEOUT = httpx.Timeout(30.0, read=300.0)


class APIError(Exception):
    def __init__(self, status: int, message: str):
        self.status = status
        self.message = message
        super().__init__(f"HTTP {status}: {message}")


class ForgeClient:
    """Synchronous HTTP client for Forge API."""

    def __init__(self, base_url: str = _BASE):
        self._base = base_url.rstrip("/")
        self._client = httpx.Client(timeout=_TIMEOUT)

    def close(self):
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _get(self, path: str, params: dict = None) -> Any:
        resp = self._client.get(f"{self._base}{path}", params=params)
        self._raise(resp)
        return resp.json()

    def _post(self, path: str, body: dict = None) -> Any:
        resp = self._client.post(f"{self._base}{path}", json=body or {})
        self._raise(resp)
        return resp.json()

    def _patch(self, path: str, body: dict = None) -> Any:
        resp = self._client.patch(f"{self._base}{path}", json=body or {})
        self._raise(resp)
        return resp.json()

    def _delete(self, path: str) -> None:
        resp = self._client.delete(f"{self._base}{path}")
        self._raise(resp)

    @staticmethod
    def _raise(resp: httpx.Response) -> None:
        if resp.status_code >= 400:
            try:
                msg = resp.json().get("error", resp.text)
            except Exception:
                msg = resp.text
            raise APIError(resp.status_code, msg)

    # ------------------------------------------------------------------
    # Health
    # ------------------------------------------------------------------

    def health(self) -> dict:
        return self._get("/health")

    def is_running(self) -> bool:
        try:
            self.health()
            return True
        except Exception:
            return False

    # ------------------------------------------------------------------
    # Sessions
    # ------------------------------------------------------------------

    def create_session(
        self,
        project_name: str,
        project_path: str,
        mode: str = "scratch",
        user_type: str = "developer",
        user_input: Optional[str] = None,
    ) -> dict:
        body = {
            "project_name": project_name,
            "project_path": project_path,
            "mode":         mode,
            "user_type":    user_type,
        }
        if user_input:
            body["user_input"] = user_input
        return self._post("/sessions", body)

    def get_session(self, session_id: str) -> dict:
        return self._get(f"/sessions/{session_id}")

    def list_sessions(self, status: Optional[str] = None) -> list[dict]:
        params = {"status": status} if status else None
        return self._get("/sessions", params=params)

    def delete_session(self, session_id: str) -> None:
        self._delete(f"/sessions/{session_id}")

    def update_status(self, session_id: str, status: str) -> dict:
        return self._patch(f"/sessions/{session_id}/status", {"status": status})

    def send_message(self, session_id: str, user_input: str) -> dict:
        return self._post(
            f"/sessions/{session_id}/message",
            {"user_input": user_input},
        )

    # ------------------------------------------------------------------
    # Permissions
    # ------------------------------------------------------------------

    def get_pending_permissions(self, session_id: str) -> list[dict]:
        return self._get(f"/permissions/{session_id}/pending")

    def grant_permission(
        self,
        session_id: str,
        request_id: str,
        scope: str = "file_specific",
    ) -> dict:
        return self._post(
            f"/permissions/{session_id}/grant",
            {"request_id": request_id, "scope": scope},
        )

    def deny_permission(self, session_id: str, request_id: str) -> dict:
        return self._post(
            f"/permissions/{session_id}/deny",
            {"request_id": request_id},
        )

    def grant_all_permissions(self, session_id: str) -> dict:
        return self._post(f"/permissions/{session_id}/grant-all")

    # ------------------------------------------------------------------
    # SSE stream (synchronous generator)
    # ------------------------------------------------------------------

    def stream_events(
        self, session_id: str
    ) -> Generator[dict[str, str], None, None]:
        """
        Consume the SSE stream for a session.
        Yields parsed event dicts: {"event": str, "data": str}
        """
        url = f"{self._base}/stream/{session_id}"
        with self._client.stream("GET", url) as resp:
            self._raise(resp)
            event_type = "message"
            for line in resp.iter_lines():
                line = line.strip()
                if not line:
                    continue
                if line.startswith("event:"):
                    event_type = line[6:].strip()
                elif line.startswith("data:"):
                    data_raw = line[5:].strip()
                    try:
                        data = json.loads(data_raw)
                    except json.JSONDecodeError:
                        data = {"raw": data_raw}
                    yield {"event": event_type, "data": data}
                    event_type = "message"


def get_client() -> ForgeClient:
    """Return a ForgeClient pointed at the default backend."""
    return ForgeClient()
