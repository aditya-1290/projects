"""
cli/themes/forge_theme.py
--------------------------
All Rich styling constants for the Forge CLI.
One place to change colors for the entire UI.
"""

from rich.theme import Theme
from rich.style import Style

FORGE_THEME = Theme({
    # Brand
    "forge.brand":      "bold cyan",
    "forge.accent":     "cyan",
    "forge.dim":        "dim white",

    # Status
    "forge.success":    "bold green",
    "forge.warning":    "bold yellow",
    "forge.error":      "bold red",
    "forge.info":       "bold blue",

    # Agents
    "agent.orchestrator": "bold magenta",
    "agent.intake":       "bold cyan",
    "agent.architect":    "bold blue",
    "agent.coder":        "bold green",
    "agent.memory":       "dim cyan",

    # UI elements
    "forge.header":     "bold white on #1a1a2e",
    "forge.panel":      "white",
    "forge.label":      "dim white",
    "forge.value":      "white",
    "forge.highlight":  "bold yellow",
    "forge.prompt":     "bold cyan",
    "forge.muted":      "dim",

    # Code
    "code.writing":     "green",
    "code.token":       "bright_green",
    "code.file":        "bold cyan",
    "code.done":        "bold green",
})

# Separator lines
SEPARATOR     = "[dim]" + "─" * 60 + "[/dim]"
SEPARATOR_THIN = "[dim]" + "·" * 60 + "[/dim]"

# Agent name → Rich style
AGENT_STYLES: dict[str, str] = {
    "orchestrator":   "bold magenta",
    "intake":         "bold cyan",
    "architect":      "bold blue",
    "coder":          "bold green",
    "memory_manager": "dim cyan",
    "tester.txt":         "bold yellow",
    "patcher":        "bold orange3",
    "reviewer":       "bold purple",
}

# Status → icon + color
STATUS_ICONS: dict[str, tuple[str, str]] = {
    "active":   ("●", "green"),
    "running":  ("◉", "cyan"),
    "paused":   ("◌", "yellow"),
    "complete": ("✓", "bold green"),
    "error":    ("✗", "bold red"),
}

# Agent event type → display label
EVENT_LABELS: dict[str, str] = {
    "starting":        "Starting",
    "designing":       "Designing architecture",
    "writing":         "Writing",
    "ingesting":       "Ingesting project",
    "checkpoint":      "Checkpoint saved",
    "checkpoint_loaded": "Checkpoint loaded",
    "file_written":    "File written",
    "build_start":     "Build started",
    "error":           "Error",
    "complete":        "Complete",
}
