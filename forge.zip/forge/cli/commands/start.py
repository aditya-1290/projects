"""
cli/commands/start.py
----------------------
forge start — create a new session and begin the conversation.

Usage:
  forge start
  forge start --path /my/project
  forge start --mode ingest --path /existing/project
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console

from cli.api_client import ForgeClient, APIError, get_client
from cli.conversation.loop import ConversationLoop
from cli.themes.forge_theme import FORGE_THEME

app = typer.Typer()
console = Console(theme=FORGE_THEME)


def start_command(
    path:      Optional[str] = typer.Option(None,       "--path", "-p",  help="Project directory path"),
    mode:      str           = typer.Option("scratch",  "--mode", "-m",  help="Mode: scratch | ingest | test"),
    user_type: str           = typer.Option("developer","--type", "-t",  help="User type: developer | founder | team"),
    name:      Optional[str] = typer.Option(None,       "--name", "-n",  help="Project name (defaults to directory name)"),
):
    """Start a new Forge session."""

    # Resolve project path
    project_path = Path(path).resolve() if path else Path.cwd()
    project_name = name or project_path.name

    console.print()
    console.print(f"[bold cyan]forge[/bold cyan] [dim]starting new session[/dim]")
    console.print(f"  [dim]project[/dim]  [white]{project_name}[/white]")
    console.print(f"  [dim]path[/dim]     [white]{project_path}[/white]")
    console.print(f"  [dim]mode[/dim]     [white]{mode}[/white]")
    console.print()

    with get_client() as client:
        # Check server is up
        if not client.is_running():
            console.print(
                "[bold red]✗[/bold red] Forge server is not running.\n"
                "  Start it with: [bold cyan]forge server start[/bold cyan]"
            )
            raise typer.Exit(1)

        # Create session
        try:
            session = client.create_session(
                project_name = project_name,
                project_path = str(project_path),
                mode         = mode,
                user_type    = user_type,
            )
        except APIError as e:
            console.print(f"[bold red]Failed to create session:[/bold red] {e.message}")
            raise typer.Exit(1)

        session_id = session["session_id"]
        console.print(
            f"[bold green]✓[/bold green] Session created [dim]{session_id[:8]}[/dim]"
        )

        # Enter conversation loop
        loop = ConversationLoop(
            console      = console,
            client       = client,
            session_id   = session_id,
            project_name = project_name,
        )
        loop.run()
