"""
cli/commands/checkpoint.py
---------------------------
forge checkpoint — show checkpoint information for a session.

Usage:
  forge checkpoint                  # checkpoints for most recent session
  forge checkpoint <session_id>     # checkpoints for a specific session
"""

from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from cli.api_client import APIError, get_client
from cli.themes.forge_theme import FORGE_THEME

console = Console(theme=FORGE_THEME)


def checkpoint_command(
    session_id: Optional[str] = typer.Argument(None, help="Session ID or prefix"),
):
    """Show checkpoint history for a session."""

    with get_client() as client:
        if not client.is_running():
            console.print("[bold red]✗[/bold red] Forge server is not running.")
            raise typer.Exit(1)

        try:
            sessions = client.list_sessions()
        except APIError as e:
            console.print(f"[bold red]Error:[/bold red] {e.message}")
            raise typer.Exit(1)

        if not sessions:
            console.print("[dim]No sessions.[/dim]")
            raise typer.Exit(0)

        if session_id:
            target = next(
                (s for s in sessions if s["session_id"].startswith(session_id)),
                None,
            )
            if not target:
                console.print(f"[bold red]Not found:[/bold red] {session_id}")
                raise typer.Exit(1)
        else:
            target = sessions[0]

        sid  = target["session_id"]
        name = target["project_name"]
        last = target.get("last_checkpoint_id")

    console.print()
    console.rule(
        f"[bold cyan]Checkpoints[/bold cyan] [dim]— {name}[/dim]",
        style="cyan",
    )
    console.print()

    if not last:
        console.print("  [dim]No checkpoints saved yet for this session.[/dim]")
    else:
        console.print(f"  [dim]Last checkpoint:[/dim] [yellow]{last[:16]}...[/yellow]")
        console.print()
        console.print(
            "  [dim]Checkpoints are saved automatically by the Memory Manager agent[/dim]"
        )
        console.print(
            "  [dim]when token usage approaches context limits.[/dim]"
        )

    console.print()
    console.rule(style="dim")
