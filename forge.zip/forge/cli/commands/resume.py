"""
cli/commands/resume.py
-----------------------
forge resume — resume a saved session.

Usage:
  forge resume                    # resume most recent active session
  forge resume <session_id>       # resume a specific session
"""

from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console

from cli.api_client import ForgeClient, APIError, get_client
from cli.conversation.loop import ConversationLoop
from cli.themes.forge_theme import FORGE_THEME
from cli.views.session_list import render_session_list

console = Console(theme=FORGE_THEME)


def resume_command(
    session_id: Optional[str] = typer.Argument(None, help="Session ID to resume (or partial prefix)"),
):
    """Resume an existing Forge session."""

    with get_client() as client:
        if not client.is_running():
            console.print(
                "[bold red]✗[/bold red] Forge server is not running.\n"
                "  Start it with: [bold cyan]forge server start[/bold cyan]"
            )
            raise typer.Exit(1)

        try:
            sessions = client.list_sessions()
        except APIError as e:
            console.print(f"[bold red]Error:[/bold red] {e.message}")
            raise typer.Exit(1)

        if not sessions:
            console.print("[dim]No sessions found. Start one with:[/dim] [bold cyan]forge start[/bold cyan]")
            raise typer.Exit(0)

        # Resolve which session to resume
        target = None

        if session_id:
            # Match by prefix
            for s in sessions:
                if s["session_id"].startswith(session_id):
                    target = s
                    break
            if not target:
                console.print(f"[bold red]Session not found:[/bold red] {session_id}")
                raise typer.Exit(1)
        else:
            # Most recent non-complete session
            active = [
                s for s in sessions
                if s.get("status") in ("active", "running", "paused")
            ]
            if not active:
                console.print("[dim]No active sessions found.[/dim]")
                render_session_list(console, sessions)
                raise typer.Exit(0)
            target = active[0]

        sid  = target["session_id"]
        name = target["project_name"]

        console.print()
        console.print(
            f"[bold cyan]forge[/bold cyan] [dim]resuming[/dim] [white]{name}[/white] "
            f"[dim]{sid[:8]}[/dim]"
        )

        # Mark session as active again
        try:
            client.update_status(sid, "active")
        except APIError:
            pass  # non-fatal

        loop = ConversationLoop(
            console      = console,
            client       = client,
            session_id   = sid,
            project_name = name,
        )
        loop.run()
