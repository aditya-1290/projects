"""
cli/commands/status.py
-----------------------
forge status — show current status of a session (non-interactive).

Usage:
  forge status                # status of most recent session
  forge status <session_id>   # status of a specific session
"""

from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console

from cli.api_client import APIError, get_client
from cli.themes.forge_theme import FORGE_THEME, STATUS_ICONS
from cli.views.session_list import render_session_detail

console = Console(theme=FORGE_THEME)


def status_command(
    session_id: Optional[str] = typer.Argument(None, help="Session ID or prefix"),
):
    """Show status of a Forge session."""

    with get_client() as client:
        if not client.is_running():
            console.print("[bold red]✗[/bold red] Forge server is not running.")
            raise typer.Exit(1)

        try:
            sessions = client.list_sessions()
        except APIError as e:
            console.print(f"[bold red]Error:[/bold red] {e.message}")
            raise typer.Exit(1)

        if not sessions:
            console.print("[dim]No sessions.[/dim]")
            raise typer.Exit(0)

        # Resolve target
        if session_id:
            target = next(
                (s for s in sessions if s["session_id"].startswith(session_id)),
                None,
            )
            if not target:
                console.print(f"[bold red]Not found:[/bold red] {session_id}")
                raise typer.Exit(1)
        else:
            target = sessions[0]

        try:
            session = client.get_session(target["session_id"])
        except APIError as e:
            console.print(f"[bold red]Error:[/bold red] {e.message}")
            raise typer.Exit(1)

        # Also show stream status snapshot
        try:
            snapshot = client._get(f"/stream/{session['session_id']}/status")
        except Exception:
            snapshot = None

        render_session_detail(console, session)

        if snapshot and snapshot.get("status") != "unknown":
            console.print()
            console.print(f"  [dim]Last event[/dim]  [white]{snapshot.get('status', '')}[/white]")
            if snapshot.get("detail"):
                console.print(f"  [dim]Detail[/dim]     [white]{snapshot['detail']}[/white]")
