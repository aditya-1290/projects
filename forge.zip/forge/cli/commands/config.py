"""
cli/commands/config.py
-----------------------
forge config — view and set Forge configuration.

Usage:
  forge config              # show all config
  forge config get <key>    # get a value
  forge config set <key> <value>  # set a value
"""

from __future__ import annotations

import typer
from rich.console import Console
from rich.table import Table

from cli.themes.forge_theme import FORGE_THEME
from config.settings import get_settings

app = typer.Typer(help="Manage Forge configuration.")
console = Console(theme=FORGE_THEME)


@app.callback(invoke_without_command=True)
def config_command(ctx: typer.Context):
    """Show all current Forge configuration."""
    if ctx.invoked_subcommand is not None:
        return

    settings = get_settings()
    console.print()
    console.rule("[bold cyan]Forge Configuration[/bold cyan]", style="cyan")
    console.print()

    table = Table(
        show_header=False,
        box=None,
        padding=(0, 2),
    )
    table.add_column(style="dim white", width=24)
    table.add_column(style="white")

    # Server
    table.add_row("[bold]Server[/bold]", "")
    table.add_row("  host",    settings.server.host)
    table.add_row("  port",    str(settings.server.port))
    table.add_row("", "")

    # Model
    table.add_row("[bold]Model[/bold]", "")
    table.add_row("  backend",    settings.model.backend)
    table.add_row("  model_name", settings.model.model_name)
    table.add_row("  base_url",   settings.model.base_url)
    table.add_row("  max_tokens", str(settings.model.max_tokens))
    table.add_row("", "")

    # Storage
    table.add_row("[bold]Storage[/bold]", "")
    table.add_row("  db_path",   settings.storage.db_path)
    table.add_row("  forge_dir", settings.storage.forge_dir)
    table.add_row("", "")

    # Bus
    table.add_row("[bold]Bus[/bold]", "")
    table.add_row("  backend", settings.bus.backend)
    if settings.bus.redis_url:
        table.add_row("  redis_url", settings.bus.redis_url)
    table.add_row("", "")

    # Misc
    table.add_row("[bold]Misc[/bold]", "")
    table.add_row("  debug_mode", str(settings.debug_mode))
    table.add_row("  log_level",  settings.log_level)

    console.print(table)
    console.rule(style="dim")


@app.command("get")
def config_get(key: str = typer.Argument(..., help="Config key (e.g. model.model_name)")):
    """Get a specific config value."""
    settings = get_settings()
    parts = key.split(".")

    try:
        val = settings
        for part in parts:
            val = getattr(val, part)
        console.print(f"  [dim]{key}[/dim]  [white]{val}[/white]")
    except AttributeError:
        console.print(f"[bold red]Unknown config key:[/bold red] {key}")
        raise typer.Exit(1)


@app.command("set")
def config_set(
    key:   str = typer.Argument(..., help="Config key"),
    value: str = typer.Argument(..., help="New value"),
):
    """
    Set a config value.
    Note: Changes are applied via environment variables or .env file.
    This command shows you what to set.
    """
    env_key = "FORGE_" + key.upper().replace(".", "_")
    console.print()
    console.print(
        f"  To set [bold cyan]{key}[/bold cyan] to [white]{value}[/white],"
        f" add to your [dim].env[/dim] file:"
    )
    console.print()
    console.print(f"  [bold green]{env_key}={value}[/bold green]")
    console.print()
    console.print(
        "  [dim]Then restart the Forge server:[/dim] "
        "[bold cyan]forge server restart[/bold cyan]"
    )
