"""
cli/commands/sessions.py
-------------------------
forge sessions — list and manage sessions.

Usage:
  forge sessions              # list all sessions
  forge sessions show <id>    # show session detail
  forge sessions delete <id>  # delete a session
"""

from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console

from cli.api_client import APIError, get_client
from cli.themes.forge_theme import FORGE_THEME
from cli.views.session_list import render_session_list, render_session_detail

app = typer.Typer(help="Manage Forge sessions.")
console = Console(theme=FORGE_THEME)


@app.callback(invoke_without_command=True)
def sessions_command(ctx: typer.Context):
    """List all Forge sessions."""
    if ctx.invoked_subcommand is not None:
        return

    with get_client() as client:
        if not client.is_running():
            console.print("[bold red]✗[/bold red] Forge server is not running.")
            raise typer.Exit(1)
        try:
            sessions = client.list_sessions()
        except APIError as e:
            console.print(f"[bold red]Error:[/bold red] {e.message}")
            raise typer.Exit(1)

    render_session_list(console, sessions)


@app.command("show")
def sessions_show(
    session_id: str = typer.Argument(..., help="Session ID or prefix"),
):
    """Show full detail for a session."""
    with get_client() as client:
        try:
            sessions = client.list_sessions()
            target = next(
                (s for s in sessions if s["session_id"].startswith(session_id)),
                None,
            )
            if not target:
                console.print(f"[bold red]Session not found:[/bold red] {session_id}")
                raise typer.Exit(1)
            session = client.get_session(target["session_id"])
        except APIError as e:
            console.print(f"[bold red]Error:[/bold red] {e.message}")
            raise typer.Exit(1)

    render_session_detail(console, session)


@app.command("delete")
def sessions_delete(
    session_id: str = typer.Argument(..., help="Session ID or prefix"),
    yes:        bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
):
    """Delete a session and all its data."""
    with get_client() as client:
        try:
            sessions = client.list_sessions()
            target = next(
                (s for s in sessions if s["session_id"].startswith(session_id)),
                None,
            )
            if not target:
                console.print(f"[bold red]Session not found:[/bold red] {session_id}")
                raise typer.Exit(1)

            sid  = target["session_id"]
            name = target["project_name"]

            if not yes:
                confirm = console.input(
                    f"  Delete session [bold red]{name}[/bold red] ({sid[:8]})? [dim][y/N][/dim] "
                )
                if confirm.strip().lower() not in ("y", "yes"):
                    console.print("[dim]Cancelled.[/dim]")
                    raise typer.Exit(0)

            client.delete_session(sid)
            console.print(
                f"[bold green]✓[/bold green] Deleted session [dim]{sid[:8]}[/dim]"
            )
        except APIError as e:
            console.print(f"[bold red]Error:[/bold red] {e.message}")
            raise typer.Exit(1)
