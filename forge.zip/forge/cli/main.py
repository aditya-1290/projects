"""
cli/main.py
-----------
Forge CLI entrypoint.

Commands:
  forge start       — start a new session
  forge resume      — resume a saved session
  forge sessions    — list / manage sessions
  forge status      — show session status
  forge checkpoint  — show checkpoint info
  forge config      — view / set config
  forge server      — start / stop the backend server

Run with: forge --help
"""

from __future__ import annotations

import subprocess
import sys

import typer
from rich.console import Console

from cli.themes.forge_theme import FORGE_THEME
from shared.constants import APP_NAME, APP_VERSION

# Sub-command apps
from cli.commands.sessions   import app as sessions_app
from cli.commands.config     import app as config_app

app = typer.Typer(
    name            = "forge",
    help            = "Forge — Autonomous Programming Agent",
    add_completion  = True,
    no_args_is_help = True,
    rich_markup_mode= "rich",
)

console = Console(theme=FORGE_THEME)

# Mount sub-apps
app.add_typer(sessions_app,  name="sessions",  help="List and manage sessions.")
app.add_typer(config_app,    name="config",    help="View and set configuration.")


# ------------------------------------------------------------------
# Simple commands (functions, not sub-apps)
# ------------------------------------------------------------------

@app.command("start")
def start(
    path:      str = typer.Option("",          "--path", "-p",  help="Project directory"),
    mode:      str = typer.Option("scratch",   "--mode", "-m",  help="scratch | ingest | test"),
    user_type: str = typer.Option("developer", "--type", "-t",  help="developer | founder | team"),
    name:      str = typer.Option("",          "--name", "-n",  help="Project name"),
):
    """Start a new Forge session."""
    from cli.commands.start import start_command
    start_command(
        path      = path or None,
        mode      = mode,
        user_type = user_type,
        name      = name or None,
    )


@app.command("resume")
def resume(
    session_id: str = typer.Argument("", help="Session ID or prefix (empty = most recent)"),
):
    """Resume a saved session."""
    from cli.commands.resume import resume_command
    resume_command(session_id=session_id or None)


@app.command("status")
def status(
    session_id: str = typer.Argument("", help="Session ID or prefix (empty = most recent)"),
):
    """Show status of a session."""
    from cli.commands.status import status_command
    status_command(session_id=session_id or None)


@app.command("checkpoint")
def checkpoint(
    session_id: str = typer.Argument("", help="Session ID or prefix"),
):
    """Show checkpoint history for a session."""
    from cli.commands.checkpoint import checkpoint_command
    checkpoint_command(session_id=session_id or None)


# ------------------------------------------------------------------
# Server management
# ------------------------------------------------------------------

server_app = typer.Typer(help="Start and stop the Forge backend server.")
app.add_typer(server_app, name="server")


@server_app.command("start")
def server_start(
    host:   str = typer.Option("127.0.0.1", "--host", help="Bind host"),
    port:   int = typer.Option(7337,        "--port", help="Bind port"),
    reload: bool = typer.Option(False,      "--reload", help="Auto-reload on changes"),
):
    """Start the Forge backend server."""
    console.print(
        f"\n[bold cyan]forge[/bold cyan] [dim]starting server on[/dim] "
        f"[white]{host}:{port}[/white]\n"
    )
    cmd = [
        sys.executable, "-m", "uvicorn",
        "backend.app:app",
        "--host", host,
        "--port", str(port),
        "--log-level", "warning",
    ]
    if reload:
        cmd.append("--reload")
    try:
        subprocess.run(cmd)
    except KeyboardInterrupt:
        console.print("\n[dim]Server stopped.[/dim]")


@server_app.command("stop")
def server_stop():
    """Stop the running Forge server (if started via forge server start)."""
    console.print("[dim]Use Ctrl+C in the server terminal to stop it.[/dim]")


# ------------------------------------------------------------------
# Version
# ------------------------------------------------------------------

@app.command("version")
def version():
    """Show Forge version."""
    console.print(f"[bold cyan]{APP_NAME}[/bold cyan] [dim]v{APP_VERSION}[/dim]")


# ------------------------------------------------------------------
# CLI __init__ helpers
# ------------------------------------------------------------------

def _print_banner():
    console.print()
    console.print(f"  [bold cyan]forge[/bold cyan] [dim]v{APP_VERSION}[/dim]")
    console.print(
        "  [dim]Autonomous programming agent.[/dim]  "
        "[dim]Run[/dim] [bold cyan]forge --help[/bold cyan] [dim]to get started.[/dim]"
    )
    console.print()


def main():
    app()


if __name__ == "__main__":
    main()
