"""
cli/conversation/input_handler.py
-----------------------------------
Parses user input during an active session conversation.
Distinguishes slash commands from regular messages.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass
class ParsedInput:
    is_command: bool
    command: Optional[str]    # e.g. "view", "status", "quit"
    args: list[str]
    raw: str                  # original input


# Commands available during an active session
SESSION_COMMANDS = {
    "/view":       "Toggle code view (see streaming tokens)",
    "/status":     "Toggle status view",
    "/quit":       "Exit this session (session stays saved)",
    "/exit":       "Same as /quit",
    "/q":          "Same as /quit",
    "/checkpoint": "Show latest checkpoint info",
    "/files":      "List files written so far",
    "/help":       "Show available commands",
    "/yes":        "Approve the current plan",
    "/no":         "Reject or request changes to the current plan",
}


def parse_input(raw: str) -> ParsedInput:
    """
    Parse a line of user input.
    Returns ParsedInput with is_command=True if it starts with '/'.
    """
    stripped = raw.strip()

    if not stripped:
        return ParsedInput(is_command=False, command=None, args=[], raw=raw)

    if stripped.startswith("/"):
        parts = stripped.split()
        cmd = parts[0].lower()
        args = parts[1:]
        return ParsedInput(is_command=True, command=cmd, args=args, raw=raw)

    return ParsedInput(is_command=False, command=None, args=[], raw=raw)


def is_quit_command(inp: ParsedInput) -> bool:
    return inp.is_command and inp.command in ("/quit", "/exit", "/q")


def is_approval(text: str) -> bool:
    """Check if free-text is an approval of a plan."""
    words = ("yes", "ok", "okay", "approved", "looks good", "go ahead",
             "correct", "proceed", "yep", "sure", "start", "build it")
    return any(w in text.lower() for w in words)
