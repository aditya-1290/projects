"""
cli/conversation/loop.py
-------------------------
The main conversation loop for an active Forge session.

Responsibilities:
- Connect to the SSE stream for the session
- Display agent replies and status updates in real-time
- Accept user input and route it to the correct handler
- Handle permission prompts when the coder requests a write
- Support view mode toggling (status ↔ code)
- Gracefully handle disconnect and errors
"""

from __future__ import annotations

import threading
import time
from typing import Optional

from rich.console import Console
from rich.live import Live

from cli.api_client import ForgeClient, APIError
from cli.conversation.input_handler import parse_input, is_quit_command, SESSION_COMMANDS
from cli.views.code_view import CodeView
from cli.views.patch_prompt import PatchPrompt
from cli.views.status_view import StatusView
from shared.types import StreamViewMode


class ConversationLoop:
    """
    Drives an interactive Forge session in the terminal.

    Architecture:
    - SSE stream runs in a background thread, pushing events to a queue
    - Main thread reads the queue and updates the display
    - User input is read with console.input() between display updates
    """

    def __init__(
        self,
        console: Console,
        client: ForgeClient,
        session_id: str,
        project_name: str,
    ):
        self._console = console
        self._client = client
        self._session_id = session_id
        self._project_name = project_name

        self._view_mode = StreamViewMode.STATUS
        self._status_view = StatusView(console, session_id, project_name)
        self._code_view = CodeView(console)
        self._patch_prompt = PatchPrompt(console)

        self._running = False
        self._session_complete = False
        self._pending_permissions: list[dict] = []

        # Buffer for agent replies that need user response
        self._awaiting_reply = False
        self._last_agent_reply: Optional[str] = None

    # ------------------------------------------------------------------
    # Entry point
    # ------------------------------------------------------------------

    def run(self) -> None:
        """Run the conversation loop until the session completes or user quits."""
        self._running = True
        self._console.print()
        self._console.print(
            f"[bold cyan]forge[/bold cyan] [dim]/[/dim] [white]{self._project_name}[/white]"
        )
        self._console.print(
            "[dim]Type your message and press Enter. /help for commands.[/dim]"
        )
        self._console.print()

        # Start SSE listener thread
        sse_thread = threading.Thread(
            target=self._sse_listener, daemon=True
        )
        sse_thread.start()

        try:
            self._input_loop()
        except KeyboardInterrupt:
            self._console.print("\n[dim]Interrupted.[/dim]")
        finally:
            self._running = False

        if self._session_complete:
            self._status_view.print_final_summary()

    # ------------------------------------------------------------------
    # SSE listener (runs in background thread)
    # ------------------------------------------------------------------

    def _sse_listener(self) -> None:
        """Background thread: consume SSE events and update display."""
        try:
            for event in self._client.stream_events(self._session_id):
                if not self._running:
                    break

                event_type = event.get("event", "")
                data = event.get("data", {})

                self._handle_sse_event(event_type, data)

        except APIError as e:
            if self._running:
                self._console.print(
                    f"\n[bold red]Stream error:[/bold red] {e.message}"
                )
        except Exception as e:
            if self._running:
                self._console.print(f"\n[dim]Stream ended: {e}[/dim]")

    def _handle_sse_event(self, event_type: str, data: dict) -> None:
        """Process a single SSE event."""

        if event_type == "connected":
            return

        elif event_type == "ping":
            return

        elif event_type == "agent_reply":
            text = data.get("text", "")
            if text:
                self._console.print()
                self._console.print(
                    f"[bold cyan]forge[/bold cyan]  {text}"
                )
                self._console.print()
                self._last_agent_reply = text
                self._awaiting_reply = True

        elif event_type == "token":
            if self._view_mode == StreamViewMode.CODE:
                self._code_view.print_token_raw(data.get("content", ""))

        elif event_type in ("status", "writing", "designing", "ingesting",
                             "checkpoint", "file_written", "build_start", "error"):
            self._status_view.update(event_type, data)

            # Print notable events
            if event_type == "file_written":
                fp = data.get("file_path", "")
                self._console.print(
                    f"  [bold green]✓[/bold green] [cyan]{fp}[/cyan]"
                )

            elif event_type == "checkpoint":
                self._console.print(
                    f"  [yellow]◆[/yellow] [dim]Checkpoint saved[/dim]"
                )

            elif event_type == "error":
                self._console.print(
                    f"  [bold red]✗[/bold red] {data.get('error', 'unknown error')}"
                )

        elif event_type == "complete":
            self._session_complete = True
            self._running = False

        # Check for pending permissions after each event
        self._check_permissions()

    # ------------------------------------------------------------------
    # Permission handling
    # ------------------------------------------------------------------

    def _check_permissions(self) -> None:
        """Poll for pending permission requests and handle them."""
        try:
            pending = self._client.get_pending_permissions(self._session_id)
            for req in pending:
                req_id = req.get("request_id", "")
                # Only prompt for requests we haven't handled
                if req_id not in [p.get("request_id") for p in self._pending_permissions]:
                    self._pending_permissions.append(req)
                    self._handle_permission(req)
        except Exception:
            pass  # non-fatal

    def _handle_permission(self, req: dict) -> None:
        """Show patch prompt and act on user's decision."""
        choice = self._patch_prompt.ask(
            file_path=req.get("file_path", "unknown"),
            diff_preview=req.get("diff_preview"),
            request_id=req.get("request_id", ""),
        )

        req_id = req.get("request_id", "")

        if choice == "y":
            try:
                self._client.grant_permission(self._session_id, req_id, "file_specific")
                self._patch_prompt.show_granted(req.get("file_path", ""))
            except Exception as e:
                self._console.print(f"[red]Grant failed: {e}[/red]")

        elif choice == "a":
            try:
                self._client.grant_all_permissions(self._session_id)
                self._patch_prompt.show_all_granted()
            except Exception as e:
                self._console.print(f"[red]Grant-all failed: {e}[/red]")

        elif choice == "n":
            try:
                self._client.deny_permission(self._session_id, req_id)
                self._patch_prompt.show_denied(req.get("file_path", ""))
            except Exception as e:
                self._console.print(f"[red]Deny failed: {e}[/red]")

    # ------------------------------------------------------------------
    # Input loop
    # ------------------------------------------------------------------

    def _input_loop(self) -> None:
        """Main thread: read user input and handle it."""
        while self._running:
            try:
                raw = self._console.input("[bold cyan]>[/bold cyan] ")
            except EOFError:
                break

            inp = parse_input(raw)

            if is_quit_command(inp):
                self._console.print("[dim]Session saved. Resume with: forge resume[/dim]")
                self._running = False
                break

            if inp.is_command:
                self._handle_command(inp)
            else:
                if raw.strip():
                    self._send_message(raw)

    def _handle_command(self, inp) -> None:
        """Handle a slash command."""
        cmd = inp.command

        if cmd == "/help":
            self._console.print()
            for c, desc in SESSION_COMMANDS.items():
                self._console.print(
                    f"  [bold cyan]{c:<14}[/bold cyan] [dim]{desc}[/dim]"
                )
            self._console.print()

        elif cmd == "/view":
            if self._view_mode == StreamViewMode.STATUS:
                self._view_mode = StreamViewMode.CODE
                self._console.print("[dim]Switched to code view[/dim]")
            else:
                self._view_mode = StreamViewMode.STATUS
                self._console.print("[dim]Switched to status view[/dim]")

        elif cmd == "/status":
            panel = self._status_view.render()
            self._console.print(panel)

        elif cmd == "/files":
            files = self._status_view._files_written
            if not files:
                self._console.print("[dim]No files written yet.[/dim]")
            else:
                self._console.print()
                for fp in files:
                    self._console.print(f"  [green]✓[/green] {fp}")
                self._console.print()

        elif cmd == "/checkpoint":
            self._console.print(
                f"  [dim]Checkpoints saved: [/dim][yellow]{self._status_view._checkpoints}[/yellow]"
            )

        elif cmd in ("/yes",):
            self._send_message("yes")

        elif cmd in ("/no",):
            self._send_message("no")

        else:
            self._console.print(
                f"[dim]Unknown command: {cmd}. Try /help[/dim]"
            )

    def _send_message(self, text: str) -> None:
        """Send a user message to the active session."""
        try:
            self._client.send_message(self._session_id, text)
        except APIError as e:
            self._console.print(
                f"[bold red]Send failed:[/bold red] {e.message}"
            )
        except Exception as e:
            self._console.print(f"[red]Error: {e}[/red]")
