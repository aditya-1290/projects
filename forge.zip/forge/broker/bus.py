"""broker/bus.py — Abstract MessageBus interface."""
from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Awaitable, Callable
from shared.types import AgentMessage, AgentEvent

MessageHandler = Callable[[AgentMessage], Awaitable[None]]
EventHandler   = Callable[[AgentEvent],   Awaitable[None]]

class MessageBus(ABC):
    @abstractmethod
    async def publish(self, queue: str, message: AgentMessage) -> None: ...
    @abstractmethod
    async def subscribe(self, queue: str, handler: MessageHandler) -> None: ...
    @abstractmethod
    async def broadcast(self, channel: str, event: AgentEvent) -> None: ...
    @abstractmethod
    async def subscribe_events(self, channel: str, handler: EventHandler) -> None: ...
    @abstractmethod
    async def start(self) -> None: ...
    @abstractmethod
    async def stop(self) -> None: ...
