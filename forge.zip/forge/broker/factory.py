"""broker/factory.py — Returns the right MessageBus based on settings."""
from __future__ import annotations
from typing import Optional
from broker.bus import MessageBus
from shared.logger import get_logger

logger = get_logger(__name__)
_bus: Optional[MessageBus] = None

def get_bus() -> MessageBus:
    global _bus
    if _bus is None:
        _bus = _create_bus()
    return _bus

def _create_bus() -> MessageBus:
    from config.settings import get_settings
    backend = get_settings().bus.backend
    if backend == "memory":
        from broker.backends.memory import InMemoryBus
        logger.info("MessageBus: InMemoryBus")
        return InMemoryBus()
    elif backend == "redis":
        from broker.backends.redis_bus import RedisBus
        return RedisBus()
    raise ValueError(f"Unknown bus backend: '{backend}'")

def reset_bus():
    global _bus
    _bus = None
