"""broker/backends/redis_bus.py — Redis Streams bus (Phase 2 stub)."""
from broker.bus import EventHandler, MessageBus, MessageHandler
from shared.types import AgentEvent, AgentMessage

class RedisBus(MessageBus):
    async def publish(self, queue, message): raise NotImplementedError("Phase 2")
    async def subscribe(self, queue, handler): raise NotImplementedError("Phase 2")
    async def broadcast(self, channel, event): raise NotImplementedError("Phase 2")
    async def subscribe_events(self, channel, handler): raise NotImplementedError("Phase 2")
    async def start(self): raise NotImplementedError("Phase 2")
    async def stop(self): raise NotImplementedError("Phase 2")
