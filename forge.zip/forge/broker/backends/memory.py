"""broker/backends/memory.py — In-memory asyncio.Queue bus (Phase 1)."""
from __future__ import annotations
import asyncio
from collections import defaultdict
from typing import Dict, List, Optional
from broker.bus import EventHandler, MessageBus, MessageHandler
from shared.constants import BUS_QUEUE_MAX_SIZE
from shared.exceptions import QueueFullError
from shared.logger import get_logger
from shared.types import AgentEvent, AgentMessage

logger = get_logger(__name__)

class InMemoryBus(MessageBus):
    def __init__(self, queue_max_size: int = BUS_QUEUE_MAX_SIZE):
        self._queue_max_size = queue_max_size
        self._queues:        Dict[str, asyncio.Queue]      = {}
        self._handlers:      Dict[str, List[MessageHandler]] = defaultdict(list)
        self._event_handlers: Dict[str, List[EventHandler]] = defaultdict(list)
        self._workers:       Dict[str, asyncio.Task]       = {}
        self._loop:          Optional[asyncio.AbstractEventLoop] = None
        self._running = False

    def _get_or_create_queue(self, name: str) -> asyncio.Queue:
        if name not in self._queues:
            self._queues[name] = asyncio.Queue(maxsize=self._queue_max_size)
        return self._queues[name]

    async def _worker(self, queue_name: str):
        queue = self._get_or_create_queue(queue_name)
        while self._running:
            try:
                message: AgentMessage = await asyncio.wait_for(queue.get(), timeout=1.0)
            except asyncio.TimeoutError:
                continue
            except asyncio.CancelledError:
                break
            for handler in self._handlers.get(queue_name, []):
                try:
                    await handler(message)
                except Exception as e:
                    logger.error(f"Handler error on '{queue_name}': {e}", exc_info=True)
            queue.task_done()

    def _ensure_worker(self, queue_name: str):
        if queue_name not in self._workers or self._workers[queue_name].done():
            self._workers[queue_name] = asyncio.ensure_future(self._worker(queue_name))

    async def publish(self, queue: str, message: AgentMessage):
        q = self._get_or_create_queue(queue)
        if q.full():
            raise QueueFullError(queue)
        await q.put(message)
        logger.debug(f"→ {queue} | {message.task_type} | from={message.from_agent}")
        self._ensure_worker(queue)

    async def subscribe(self, queue: str, handler: MessageHandler):
        self._handlers[queue].append(handler)
        self._get_or_create_queue(queue)
        self._ensure_worker(queue)

    async def broadcast(self, channel: str, event: AgentEvent):
        for handler in self._event_handlers.get(channel, []):
            try:
                await handler(event)
            except Exception as e:
                logger.error(f"Event handler error on '{channel}': {e}", exc_info=True)

    async def subscribe_events(self, channel: str, handler: EventHandler):
        self._event_handlers[channel].append(handler)

    def publish_sync(self, queue: str, message: AgentMessage):
        if not self._loop or not self._loop.is_running():
            raise RuntimeError("Bus not started. Call await bus.start() first.")
        asyncio.run_coroutine_threadsafe(self.publish(queue, message), self._loop).result(timeout=5.0)

    def broadcast_sync(self, channel: str, event: AgentEvent):
        if not self._loop or not self._loop.is_running():
            raise RuntimeError("Bus not started.")
        asyncio.run_coroutine_threadsafe(self.broadcast(channel, event), self._loop).result(timeout=5.0)

    async def start(self):
        self._loop = asyncio.get_running_loop()
        self._running = True
        for q in self._handlers:
            self._ensure_worker(q)
        logger.info("InMemoryBus started")

    async def stop(self):
        self._running = False
        for name, q in self._queues.items():
            try:
                await asyncio.wait_for(q.join(), timeout=10.0)
            except asyncio.TimeoutError:
                logger.warning(f"Queue '{name}' did not drain in time")
        for t in self._workers.values():
            t.cancel()
        await asyncio.gather(*self._workers.values(), return_exceptions=True)
        logger.info("InMemoryBus stopped")

    def queue_sizes(self) -> dict:
        return {n: q.qsize() for n, q in self._queues.items()}
