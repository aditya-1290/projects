"""
agents/intake/project_plan_generator.py
-----------------------------------------
Builds the project plan summary shown to the user before coding begins.
Also contains the async project scanner used in ingest mode (Mode 2).
"""

from __future__ import annotations

import asyncio
import os
from pathlib import Path
from typing import Any

from shared.constants import (
    CONFIG_FILE_NAMES,
    EXTENSION_LANGUAGE_MAP,
    INGEST_EXCLUDE_PATTERNS,
)


# ---------------------------------------------------------------------------
# Project structure scanner (Mode 2 — ingest existing project)
# ---------------------------------------------------------------------------

async def scan_project_structure(project_path: str) -> dict[str, Any]:
    """
    Walk a project directory and return a findings dict.
    Runs in a thread executor to avoid blocking the event loop.
    """
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, _scan_sync, project_path)


def _scan_sync(project_path: str) -> dict[str, Any]:
    """Synchronous directory walk — called from executor."""
    root = Path(project_path)
    if not root.exists():
        return {"error": f"Path not found: {project_path}"}

    languages:        set[str]  = set()
    frameworks:       set[str]  = set()
    config_files:     list[str] = []
    incomplete_files: list[str] = []
    total_files:      int       = 0
    has_tests:        bool      = False
    has_readme:       bool      = False

    for dirpath, dirnames, filenames in os.walk(root):
        # Prune excluded directories in-place
        dirnames[:] = [
            d for d in dirnames
            if d not in INGEST_EXCLUDE_PATTERNS and not d.startswith(".")
        ]

        for filename in filenames:
            filepath = Path(dirpath) / filename
            ext = filepath.suffix.lower()

            total_files += 1

            # Language detection
            if lang := EXTENSION_LANGUAGE_MAP.get(ext):
                languages.add(lang)

            # Config file detection
            if filename in CONFIG_FILE_NAMES:
                config_files.append(str(filepath.relative_to(root)))
                # Framework hints from config files
                frameworks.update(_detect_frameworks_from_config(filepath))

            # README detection
            if filename.lower().startswith("readme"):
                has_readme = True

            # Test detection
            rel = str(filepath.relative_to(root)).lower()
            if "test" in rel or "spec" in rel:
                has_tests = True

            # Stub / incomplete detection (files with very little content)
            if ext in (".py", ".js", ".ts", ".java", ".go", ".rs"):
                try:
                    size = filepath.stat().st_size
                    if size < 100:  # bytes — likely a stub or empty
                        incomplete_files.append(str(filepath.relative_to(root)))
                except OSError:
                    pass

    return {
        "project_path":    project_path,
        "languages":       sorted(languages),
        "frameworks":      sorted(frameworks),
        "config_files":    config_files,
        "incomplete_files": incomplete_files,
        "total_files":     total_files,
        "has_tests":       has_tests,
        "has_readme":      has_readme,
    }


def _detect_frameworks_from_config(config_path: Path) -> list[str]:
    """
    Peek inside a config file to detect frameworks.
    Best-effort — won't crash on malformed files.
    """
    frameworks: list[str] = []
    try:
        text = config_path.read_text(encoding="utf-8", errors="ignore").lower()
        _FRAMEWORK_HINTS = {
            "fastapi":   "fastapi",
            "django":    "django",
            "flask":     "flask",
            "express":   "express",
            "react":     "react",
            "vue":       "vue",
            "angular":   "angular",
            "next":      "next.js",
            "spring":    "spring",
            "rails":     "rails",
        }
        for keyword, name in _FRAMEWORK_HINTS.items():
            if keyword in text:
                frameworks.append(name)
    except Exception:
        pass
    return frameworks


# ---------------------------------------------------------------------------
# Plan summary builder (for Mode 1 — build from scratch)
# ---------------------------------------------------------------------------

def build_approval_plan(
    description:  str,
    tech_stack:   str,
    timeline:     str,
    user_stories: str,
) -> str:
    """
    Format a project plan for user review before coding begins.
    Returns a multi-line string suitable for CLI display.
    """
    lines = [
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
        "  FORGE — Project Plan",
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
        "",
        f"  Description  {description}",
        f"  Stack        {tech_stack or 'To be recommended'}",
        f"  Timeline     {timeline or 'Not specified'}",
    ]
    if user_stories:
        preview = user_stories[:200] + ("..." if len(user_stories) > 200 else "")
        lines += ["", f"  Requirements", f"  {preview}"]

    lines += [
        "",
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
        "  Reply 'yes' to begin, or tell me what to change.",
    ]
    return "\n".join(lines)
