"""
agents/intake/requirements_builder.py
---------------------------------------
Accumulates answers from the intake conversation and
produces a structured requirements dict + human-readable plan summary.
"""

from __future__ import annotations

from typing import Any


class RequirementsBuilder:
    """
    Collects intake answers incrementally.
    Call set_* methods as answers arrive, then call to_dict() or build_plan_summary().
    """

    def __init__(self) -> None:
        self._description:   str = ""
        self._tech_stack:    str = ""
        self._timeline:      str = ""
        self._user_stories:  str = ""
        self._corrections:   list[str] = []

    # ------------------------------------------------------------------
    # Setters (called by intake conversation stages)
    # ------------------------------------------------------------------

    def set_description(self, text: str) -> None:
        self._description = text.strip()

    def set_tech_stack(self, text: str) -> None:
        self._tech_stack = text.strip()

    def set_timeline(self, text: str) -> None:
        self._timeline = text.strip()

    def set_user_stories(self, text: str) -> None:
        self._user_stories = text.strip()

    def apply_correction(self, feedback: str) -> None:
        """Store a correction for incorporation into the next plan summary."""
        self._corrections.append(feedback.strip())

    # ------------------------------------------------------------------
    # Output
    # ------------------------------------------------------------------

    def build_plan_summary(self) -> str:
        """
        Build a human-readable plan summary for the user to approve.
        Incorporates any corrections that were applied.
        """
        lines: list[str] = []

        lines.append(f"📋 Project Description\n   {self._description or '(not provided)'}")

        lines.append(f"\n🛠  Tech Stack\n   {self._parse_tech_stack() or 'Will be recommended by Architect'}")

        lines.append(f"\n📅 Timeline\n   {self._timeline or 'Not specified'}")

        if self._user_stories:
            # Truncate long user stories for display
            stories_preview = self._user_stories[:300]
            if len(self._user_stories) > 300:
                stories_preview += "..."
            lines.append(f"\n📝 User Stories / Requirements\n   {stories_preview}")

        if self._corrections:
            lines.append(f"\n✏️  Applied Corrections\n   " + "\n   ".join(self._corrections))

        return "\n".join(lines)

    def to_dict(self) -> dict[str, Any]:
        """Return the full structured requirements as a dict (passed to Architect)."""
        return {
            "description":   self._description,
            "tech_stack_raw": self._tech_stack,
            "parsed_stack":  self._parse_tech_stack(),
            "timeline":      self._timeline,
            "user_stories":  self._user_stories,
            "corrections":   self._corrections,
        }

    def is_complete(self) -> bool:
        """Minimum viable requirements: description + tech stack."""
        return bool(self._description and self._tech_stack)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _parse_tech_stack(self) -> str:
        """
        Normalise the tech stack answer into a clean string.
        If the user said 'choose for me' or similar, return empty string
        so the Architect Agent knows to recommend one.
        """
        auto_phrases = [
            "choose", "recommend", "you decide", "up to you",
            "whatever", "best", "i don't know", "don't know",
            "no preference", "any",
        ]
        lower = self._tech_stack.lower()
        if any(p in lower for p in auto_phrases):
            return ""
        return self._tech_stack
