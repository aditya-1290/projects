__all__ = ["IntakeAgent", "detect_user_type", "RequirementsBuilder", "scan_project_structure", "build_approval_plan"]

def __getattr__(name):
    if name == "IntakeAgent":
        from agents.intake.agent import IntakeAgent; return IntakeAgent
    if name == "detect_user_type":
        from agents.intake.user_type_detector import detect_user_type; return detect_user_type
    if name == "RequirementsBuilder":
        from agents.intake.requirements_builder import RequirementsBuilder; return RequirementsBuilder
    if name in ("scan_project_structure", "build_approval_plan"):
        from agents.intake import project_plan_generator
        return getattr(project_plan_generator, name)
    raise AttributeError(f"module 'agents.intake' has no attribute {name!r}")