"""
agents/intake/user_type_detector.py
-------------------------------------
Detects whether the user is a technical developer or a non-technical founder.
Used by the Intake Agent to switch conversation mode.
"""

from __future__ import annotations

from shared.types import UserType

_TECHNICAL_SIGNALS = [
    "api", "rest", "graphql", "fastapi", "django", "flask", "express",
    "react", "vue", "angular", "next.js", "node", "python", "typescript",
    "javascript", "java", "golang", "rust", "sql", "postgres", "mongodb",
    "redis", "docker", "kubernetes", "microservice", "endpoint", "schema",
    "database", "backend", "frontend", "fullstack", "full-stack",
    "jwt", "oauth", "authentication", "middleware", "framework",
    "repository", "orm", "migration", "deployment", "ci/cd", "devops",
    "unit test", "integration test", "pytest", "jest",
]

_FOUNDER_SIGNALS = [
    "app", "product", "users", "customers", "sign up", "signup",
    "dashboard", "marketplace", "platform", "saas", "startup",
    "revenue", "subscription", "payment", "stripe", "feature",
    "onboarding", "landing page", "mvp", "launch",
    "my idea", "i want to build", "i need an app",
    "non-technical", "not a developer", "no coding experience",
]


def detect_user_type(text: str) -> UserType:
    """
    Infer user type from their first message.

    Returns UserType.DEVELOPER if the text contains technical terminology,
    UserType.FOUNDER if it sounds product/business focused,
    defaults to DEVELOPER if ambiguous (technical users are the majority).
    """
    lower = text.lower()

    tech_score    = sum(1 for sig in _TECHNICAL_SIGNALS if sig in lower)
    founder_score = sum(1 for sig in _FOUNDER_SIGNALS   if sig in lower)

    # Strong founder signals win outright
    if "non-technical" in lower or "not a developer" in lower:
        return UserType.FOUNDER

    if founder_score > tech_score and founder_score >= 2:
        return UserType.FOUNDER

    # Default to developer (technical users are majority)
    return UserType.DEVELOPER
