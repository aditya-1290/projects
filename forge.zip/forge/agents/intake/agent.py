"""
agents/intake/agent.py
-----------------------
Intake Agent — first point of contact with the user.

Responsibilities:
- Gather project requirements via structured conversation
- Detect user type (developer vs non-technical founder)
- Switch between technical mode and product-manager mode
- Build a complete requirements object
- Present a project plan and wait for user approval
- Never pass incomplete requirements downstream

For Mode 2 (ingest): scan an existing project and report findings.
"""

from __future__ import annotations

import asyncio
from typing import Any, Callable, Optional

from agents.base_agent import BaseAgent
from agents.intake.requirements_builder import RequirementsBuilder
from agents.intake.user_type_detector import detect_user_type
from shared.constants import CHANNEL_AGENT_EVENTS, QUEUE_INTAKE, QUEUE_ORCHESTRATOR
from shared.types import (
    AgentEvent,
    AgentMessage,
    AgentName,
    ProjectMode,
    TaskType,
    UserType,
)


class IntakeAgent(BaseAgent):
    """
    Conversational intake agent.
    Drives the requirements-gathering conversation and produces
    a structured requirements payload for the Architect Agent.
    """

    def __init__(
        self,
        response_callback: Optional[Callable[[str, str], None]] = None,
        **kwargs,
    ):
        super().__init__(**kwargs)
        # response_callback(session_id, text) — sends agent replies to CLI
        self._response_callback = response_callback
        # Active conversation states per session
        self._conversations: dict[str, dict[str, Any]] = {}

    @property
    def name(self) -> AgentName:
        return AgentName.INTAKE

    @property
    def queue(self) -> str:
        return QUEUE_INTAKE

    # ------------------------------------------------------------------
    # handle_message
    # ------------------------------------------------------------------

    async def handle_message(self, message: AgentMessage) -> None:
        task = message.task_type

        if task == TaskType.GATHER_REQUIREMENTS:
            await self._gather_requirements(message)
        elif task == TaskType.INGEST_PROJECT:
            await self._ingest_project(message)
        else:
            self.logger.warning(f"Intake received unexpected task: {task.value}")

    # ------------------------------------------------------------------
    # Mode 1: Gather requirements (build from scratch)
    # ------------------------------------------------------------------

    async def _gather_requirements(self, message: AgentMessage) -> None:
        session_id = message.session_id
        payload = message.payload

        # Initialise conversation state for this session
        if session_id not in self._conversations:
            self._conversations[session_id] = {
                "stage": "greeting",
                "user_type": UserType.DEVELOPER,
                "answers": {},
                "builder": RequirementsBuilder(),
                "mode": ProjectMode.SCRATCH,
            }

        state = self._conversations[session_id]
        user_input = payload.get("user_input", "")
        stage = state["stage"]

        self.logger.info(f"Intake stage={stage} for session {session_id[:8]}")

        # Route to correct stage handler
        if stage == "greeting":
            await self._stage_greeting(session_id, state, user_input)
        elif stage == "project_description":
            await self._stage_project_description(session_id, state, user_input)
        elif stage == "tech_stack":
            await self._stage_tech_stack(session_id, state, user_input)
        elif stage == "timeline":
            await self._stage_timeline(session_id, state, user_input)
        elif stage == "user_stories":
            await self._stage_user_stories(session_id, state, user_input)
        elif stage == "present_plan":
            await self._stage_present_plan(session_id, state, user_input)
        elif stage == "awaiting_approval":
            await self._stage_awaiting_approval(session_id, state, user_input, message)
        else:
            self.logger.error(f"Unknown intake stage: {stage}")

    async def _stage_greeting(self, session_id: str, state: dict, user_input: str) -> None:
        """Detect user type and open the conversation."""
        user_type = detect_user_type(user_input)
        state["user_type"] = user_type

        if user_type == UserType.FOUNDER:
            reply = (
                "Hi! I'm Forge. Tell me about what you want to build — "
                "what problem does it solve, and who will use it?"
            )
        else:
            reply = (
                "Welcome to Forge. What would you like to build? "
                "Describe the project — the more detail the better."
            )

        state["stage"] = "project_description"
        self._reply(session_id, reply)

    async def _stage_project_description(
        self, session_id: str, state: dict, user_input: str
    ) -> None:
        """Capture the project description and ask about tech stack."""
        state["answers"]["description"] = user_input
        state["builder"].set_description(user_input)

        user_type = state["user_type"]
        if user_type == UserType.FOUNDER:
            reply = (
                "Got it. Do you have a preference for the technology used to build this, "
                "or should I recommend something based on your requirements?"
            )
        else:
            reply = (
                "Understood. What's your preferred tech stack? "
                "(e.g. FastAPI + PostgreSQL, Node.js + React, Django — or tell me "
                "to choose based on the project.)"
            )

        state["stage"] = "tech_stack"
        self._reply(session_id, reply)

    async def _stage_tech_stack(self, session_id: str, state: dict, user_input: str) -> None:
        """Capture tech stack preferences."""
        state["answers"]["tech_stack"] = user_input
        state["builder"].set_tech_stack(user_input)

        reply = (
            "What's your target timeline or deadline for this project? "
            "(e.g. '2 weeks', 'end of month', 'no rush' — any answer is fine.)"
        )
        state["stage"] = "timeline"
        self._reply(session_id, reply)

    async def _stage_timeline(self, session_id: str, state: dict, user_input: str) -> None:
        """Capture timeline and ask about user stories."""
        state["answers"]["timeline"] = user_input
        state["builder"].set_timeline(user_input)

        reply = (
            "Do you have any user stories, requirements documents, or feature lists "
            "you'd like me to take into account? "
            "(Paste them here, or say 'no' to continue.)"
        )
        state["stage"] = "user_stories"
        self._reply(session_id, reply)

    async def _stage_user_stories(self, session_id: str, state: dict, user_input: str) -> None:
        """Capture user stories (optional) and move to plan presentation."""
        if user_input.lower().strip() not in ("no", "none", "skip", "n"):
            state["answers"]["user_stories"] = user_input
            state["builder"].set_user_stories(user_input)

        state["stage"] = "present_plan"
        await self._stage_present_plan(session_id, state, "")

    async def _stage_present_plan(self, session_id: str, state: dict, user_input: str) -> None:
        """Generate and present the project plan for user approval."""
        builder: RequirementsBuilder = state["builder"]
        plan_text = builder.build_plan_summary()

        reply = (
            f"Here's what I've understood:\n\n"
            f"{plan_text}\n\n"
            f"Does this look right? Reply 'yes' to proceed, or tell me what to change."
        )
        state["stage"] = "awaiting_approval"
        self._reply(session_id, reply)

    async def _stage_awaiting_approval(
        self,
        session_id: str,
        state: dict,
        user_input: str,
        message: AgentMessage,
    ) -> None:
        """Handle user's approval or correction of the plan."""
        approval_words = ("yes", "approved", "looks good", "go ahead",
                          "correct", "right", "proceed", "ok", "okay", "yep", "sure")

        if any(word in user_input.lower() for word in approval_words):
            # Plan approved — emit event so orchestrator routes to Architect
            builder: RequirementsBuilder = state["builder"]
            requirements = builder.to_dict()

            self.logger.info(f"Requirements approved for session {session_id[:8]}")
            self._reply(
                session_id,
                "Great! Moving on to architecture design..."
            )

            await self._bus.broadcast(
                CHANNEL_AGENT_EVENTS,
                AgentEvent(
                    event_type="requirements_complete",
                    source=self.name,
                    session_id=session_id,
                    data={
                        "session_id": session_id,
                        "requirements": requirements,
                    },
                ),
            )
            # Clean up conversation state
            del self._conversations[session_id]
        else:
            # User wants changes — incorporate feedback and re-present
            state["builder"].apply_correction(user_input)
            state["stage"] = "present_plan"
            self._reply(
                session_id,
                f"Understood. Let me update the plan based on: \"{user_input}\""
            )
            await self._stage_present_plan(session_id, state, "")

    # ------------------------------------------------------------------
    # Mode 2: Ingest existing project
    # ------------------------------------------------------------------

    async def _ingest_project(self, message: AgentMessage) -> None:
        """Scan an existing project and report findings to user."""
        session_id = message.session_id
        project_path = message.payload.get("project_path", "")

        self.logger.info(f"Ingesting project at: {project_path}")
        self._reply(session_id, f"Scanning your project at `{project_path}`...")

        from agents.intake.project_plan_generator import scan_project_structure
        findings = await scan_project_structure(project_path)

        report = self._format_ingest_report(findings)
        self._reply(session_id, report)

        # Emit event so orchestrator knows ingest is ready
        await self._bus.broadcast(
            CHANNEL_AGENT_EVENTS,
            AgentEvent(
                event_type="ingest_complete",
                source=self.name,
                session_id=session_id,
                data={"session_id": session_id, "findings": findings},
            ),
        )

    def _format_ingest_report(self, findings: dict) -> str:
        lines = ["Here's what I found in your project:\n"]
        langs = findings.get("languages", [])
        if langs:
            lines.append(f"  Languages detected: {', '.join(langs)}")
        frameworks = findings.get("frameworks", [])
        if frameworks:
            lines.append(f"  Frameworks: {', '.join(frameworks)}")
        total = findings.get("total_files", 0)
        lines.append(f"  Total files: {total}")
        incomplete = findings.get("incomplete_files", [])
        if incomplete:
            lines.append(f"  Incomplete/stub files: {len(incomplete)}")
        has_tests = findings.get("has_tests", False)
        lines.append(f"  Tests present: {'yes' if has_tests else 'no'}")
        lines.append(
            "\nWhat would you like me to focus on first?"
        )
        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Reply helper
    # ------------------------------------------------------------------

    def _reply(self, session_id: str, text: str) -> None:
        """Send a text reply to the user via the response callback."""
        self.logger.debug(f"Intake reply → session {session_id[:8]}: {text[:60]}...")
        if self._response_callback:
            try:
                self._response_callback(session_id, text)
            except Exception as e:
                self.logger.warning(f"Response callback error: {e}")

    # ------------------------------------------------------------------
    # Continuation: handle follow-up user messages
    # ------------------------------------------------------------------

    async def handle_user_message(
        self, session_id: str, user_input: str, message: AgentMessage
    ) -> None:
        """
        Called by the CLI when the user sends a follow-up message during intake.
        Routes back into the conversation state machine.
        """
        if session_id not in self._conversations:
            self.logger.warning(f"No active conversation for session {session_id[:8]}")
            return

        state = self._conversations[session_id]
        stage = state["stage"]

        # Replay into the correct stage handler
        await self._gather_requirements(AgentMessage(
            task_type=TaskType.GATHER_REQUIREMENTS,
            from_agent=AgentName.ORCHESTRATOR,
            to_agent=self.name,
            session_id=session_id,
            payload={"user_input": user_input},
        ))
