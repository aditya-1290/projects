__all__ = ["CoderAgent", "detect_language", "StreamHandler"]

def __getattr__(name):
    if name == "CoderAgent":
        from agents.coder.agent import CoderAgent; return CoderAgent
    if name == "detect_language":
        from agents.coder.language_detector import detect_language; return detect_language
    if name == "StreamHandler":
        from agents.coder.stream_handler import StreamHandler; return StreamHandler
    raise AttributeError(f"module 'agents.coder' has no attribute {name!r}")
