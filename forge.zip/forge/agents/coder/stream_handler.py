"""
agents/coder/stream_handler.py
--------------------------------
Packages streaming tokens into StreamChunk objects for the CLI.
Handles both status-view and code-view modes.
"""

from __future__ import annotations

from shared.types import AgentName, StreamChunk, StreamViewMode


class StreamHandler:
    """
    Wraps raw token output into typed StreamChunk objects.
    The CLI consumes these to render either status updates or live code.
    """

    def __init__(
        self,
        session_id: str,
        agent:      AgentName,
        file_path:  str,
        view_mode:  StreamViewMode = StreamViewMode.STATUS,
    ):
        self.session_id = session_id
        self.agent      = agent
        self.file_path  = file_path
        self.view_mode  = view_mode
        self._buffer    = ""
        self._line_count = 0

    def make_chunk(self, token: str) -> StreamChunk:
        """
        Package a raw token into a StreamChunk.
        Includes file metadata so the CLI can render the right view.
        """
        self._buffer += token
        if "\n" in token:
            self._line_count += token.count("\n")

        return StreamChunk(
            session_id = self.session_id,
            agent      = self.agent,
            chunk_type = "code_token" if self.view_mode == StreamViewMode.CODE else "status_token",
            content    = token,
            metadata   = {
                "file_path":   self.file_path,
                "view_mode":   self.view_mode.value,
                "line_count":  self._line_count,
                "buffer_size": len(self._buffer),
            },
        )

    def make_status_chunk(self, action: str, detail: str = "") -> StreamChunk:
        """Create a status-type chunk (not a code token)."""
        return StreamChunk(
            session_id = self.session_id,
            agent      = self.agent,
            chunk_type = "status",
            content    = action,
            metadata   = {
                "file_path": self.file_path,
                "detail":    detail,
            },
        )

    @property
    def buffered_code(self) -> str:
        return self._buffer

    def reset(self) -> None:
        self._buffer = ""
        self._line_count = 0
