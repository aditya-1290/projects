"""
agents/coder/language_detector.py
-----------------------------------
Detect the programming language from a file path.
"""

from __future__ import annotations
from shared.constants import EXTENSION_LANGUAGE_MAP


def detect_language(file_path: str) -> str:
    """Return the language name for a given file path, defaulting to 'text'."""
    from pathlib import Path
    ext = Path(file_path).suffix.lower()
    return EXTENSION_LANGUAGE_MAP.get(ext, "text")
