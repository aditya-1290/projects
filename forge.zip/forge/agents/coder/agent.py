"""
agents/coder/agent.py
----------------------
Coder Agent — writes code iteratively, one module at a time.

Responsibilities:
- Receive write_module tasks from Orchestrator
- Generate code using the LLM with streaming output
- Track token budget and checkpoint when approaching limit
- Never write to files without permission (delegates to Permission Gateway)
- Emit status events per file written
- Support both status-view and code-view streaming modes
"""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any, Callable, Optional

from agents.base_agent import BaseAgent
from agents.coder.language_detector import detect_language
from agents.coder.stream_handler import StreamHandler
from shared.constants import CHANNEL_AGENT_EVENTS, QUEUE_CODER
from shared.exceptions import AgentContextBurstError
from shared.types import (
    AgentEvent,
    AgentMessage,
    AgentName,
    StreamChunk,
    StreamViewMode,
    TaskType,
)


_SYSTEM_PROMPT = """You are the Coder Agent for Forge, an autonomous programming assistant.
You write clean, production-quality code. Rules:

1. Write ONLY the code for the specific file requested — no explanations, no markdown fences
2. Include appropriate imports, type hints, docstrings, and error handling
3. Follow the conventions of the language and framework in use
4. If context about other files is provided, keep your code consistent with it
5. Never include placeholder comments like "# TODO: implement this" — write real code

Output raw code only. No preamble, no explanation, no markdown.
"""


class CoderAgent(BaseAgent):
    """
    Generates code for individual modules, one file at a time.
    Streams output to the CLI and tracks files written per session.
    """

    def __init__(
        self,
        stream_callback: Optional[Callable[[StreamChunk], None]] = None,
        permission_check: Optional[Callable[[str, str, str], bool]] = None,
        **kwargs,
    ):
        super().__init__(**kwargs)
        # stream_callback(chunk) — forwards tokens to CLI
        self._stream_callback = stream_callback
        # permission_check(session_id, file_path, diff) → bool
        # Returns True if writing is permitted, False if denied
        self._permission_check = permission_check
        # Per-session tracking: session_id → list of written file paths
        self._files_written: dict[str, list[str]] = {}
        # Current view mode per session
        self._view_mode: dict[str, StreamViewMode] = {}

    @property
    def name(self) -> AgentName:
        return AgentName.CODER

    @property
    def queue(self) -> str:
        return QUEUE_CODER

    # ------------------------------------------------------------------
    # handle_message
    # ------------------------------------------------------------------

    async def handle_message(self, message: AgentMessage) -> None:
        if message.task_type == TaskType.WRITE_MODULE:
            await self._write_module(message)
        else:
            self.logger.warning(f"Coder received unexpected task: {message.task_type.value}")

    # ------------------------------------------------------------------
    # Core: write a single module
    # ------------------------------------------------------------------

    async def _write_module(self, message: AgentMessage) -> None:
        session_id = message.session_id
        payload    = message.payload

        file_path    = payload.get("file_path", "")
        instructions = payload.get("instructions", "")
        context      = payload.get("context_summary", "")
        language     = payload.get("language") or detect_language(file_path)

        self.logger.info(f"Writing {file_path} ({language}) for session {session_id[:8]}")

        # Emit status: starting this file
        await self._emit_event("writing_started", {
            "session_id": session_id,
            "file_path":  file_path,
            "language":   language,
        })

        # Build the prompt
        messages = self._build_prompt(file_path, language, instructions, context)

        # Stream the code generation
        view_mode = self._view_mode.get(session_id, StreamViewMode.STATUS)
        handler = StreamHandler(session_id, self.name, file_path, view_mode)

        generated_code = ""
        try:
            async for token in self.chat_stream(messages):
                generated_code += token
                chunk = handler.make_chunk(token)
                self._forward_chunk(chunk)
        except AgentContextBurstError:
            # Save what we have and checkpoint
            self.logger.warning(f"Context burst while writing {file_path}")
            await self._handle_context_burst(session_id, file_path, generated_code, payload)
            return

        # Code generation complete
        self.logger.info(f"Generated {len(generated_code)} chars for {file_path}")

        # Request permission to write (or write directly if pre-approved)
        await self._request_write(session_id, file_path, generated_code, language)

    def _build_prompt(
        self,
        file_path:    str,
        language:     str,
        instructions: str,
        context:      str,
    ) -> list[dict[str, Any]]:
        """Build the chat messages list for code generation."""
        user_content = (
            f"Write the file: {file_path}\n"
            f"Language: {language}\n"
        )
        if context:
            user_content += f"\nProject context:\n{context}\n"
        if instructions:
            user_content += f"\nInstructions:\n{instructions}\n"
        user_content += "\nWrite the complete file contents now:"

        return [
            {"role": "system", "content": _SYSTEM_PROMPT},
            {"role": "user",   "content": user_content},
        ]

    # ------------------------------------------------------------------
    # Permission + write
    # ------------------------------------------------------------------

    async def _request_write(
        self,
        session_id:     str,
        file_path:      str,
        generated_code: str,
        language:       str,
    ) -> None:
        """
        Check permission and write the file.
        If a permission_check callback is set, call it.
        If no callback (e.g. in tests), write directly.
        """
        if self._permission_check:
            permitted = self._permission_check(session_id, file_path, generated_code)
            if not permitted:
                self.logger.info(f"Write denied for {file_path} — showing generated code only")
                await self._emit_event("write_denied", {
                    "session_id": session_id,
                    "file_path":  file_path,
                })
                return

        # Write the file
        await self._write_file(session_id, file_path, generated_code)

    async def _write_file(
        self,
        session_id: str,
        file_path:  str,
        content:    str,
    ) -> None:
        """
        Write code to the file system.
        In Phase 1: writes directly. In Phase 2: routes through Filesystem MCP.
        """
        path = Path(file_path)
        path.parent.mkdir(parents=True, exist_ok=True)

        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, path.write_text, content, "utf-8")

        # Track written files
        self._files_written.setdefault(session_id, []).append(file_path)

        self.logger.info(f"Written: {file_path}")

        # Emit success event
        await self._emit_event("module_written", {
            "session_id": session_id,
            "file_path":  file_path,
            "size_bytes": len(content.encode()),
        })

    # ------------------------------------------------------------------
    # Context burst recovery
    # ------------------------------------------------------------------

    async def _handle_context_burst(
        self,
        session_id:     str,
        file_path:      str,
        partial_code:   str,
        original_payload: dict[str, Any],
    ) -> None:
        """
        Save partial progress and emit a checkpoint event so the
        Orchestrator can trigger a save and restart this task.
        """
        files_written = self._files_written.get(session_id, [])

        await self._emit_event("context_burst", {
            "session_id":    session_id,
            "files_touched": [{"path": f, "op": "write"} for f in files_written],
            "next_step":     f"Continue writing {file_path} from where it stopped",
            "token_count":   int(self.token_percent_used() * self._settings.model.context_window),
        })

        # Reset token budget for fresh context
        self.reset_token_budget()

    # ------------------------------------------------------------------
    # View mode control
    # ------------------------------------------------------------------

    def set_view_mode(self, session_id: str, mode: StreamViewMode) -> None:
        self._view_mode[session_id] = mode

    # ------------------------------------------------------------------
    # Stream forwarding
    # ------------------------------------------------------------------

    def _forward_chunk(self, chunk: StreamChunk) -> None:
        if self._stream_callback:
            try:
                self._stream_callback(chunk)
            except Exception as e:
                self.logger.warning(f"Stream callback error: {e}")

    # ------------------------------------------------------------------
    # Session helpers
    # ------------------------------------------------------------------

    def get_files_written(self, session_id: str) -> list[str]:
        return self._files_written.get(session_id, [])

    def clear_session(self, session_id: str) -> None:
        self._files_written.pop(session_id, None)
        self._view_mode.pop(session_id, None)
