"""
agents/reviewer/agent.py
--------------------------
Reviewer / Suggester Agent — reviews code quality and suggests improvements.

Responsibilities:
- Receive review_code tasks from Orchestrator
- Analyse code for quality, patterns, potential bugs
- Suggest enhancements (never forces — always optional)
- Generate changelog entries per session
- Support the /suggest CLI command
"""

from __future__ import annotations

from typing import Any, Callable, Optional

from agents.base_agent import BaseAgent
from shared.constants import CHANNEL_AGENT_EVENTS, QUEUE_REVIEWER
from shared.types import (
    AgentEvent, AgentMessage, AgentName, TaskType,
)


_REVIEW_SYSTEM_PROMPT = """You are the Reviewer Agent for Forge, a code review specialist.
Your role is to review code and provide clear, actionable feedback.

Review dimensions:
1. Correctness — logical errors, off-by-one, null/None handling, error paths
2. Security — hardcoded secrets, injection risks, exposed data
3. Performance — obvious inefficiencies, N+1 queries, blocking calls
4. Maintainability — naming, complexity, duplication, missing docstrings
5. Patterns — inconsistency with the rest of the codebase

Format your response as:

SUMMARY: One sentence overall assessment.

ISSUES:
- [severity: high/medium/low] description of issue (line hint if applicable)

SUGGESTIONS:
- description of optional improvement

VERDICT: approved | approved_with_suggestions | needs_revision
"""

_CHANGELOG_SYSTEM_PROMPT = """You are generating a changelog entry for a software project.
Given a list of files changed and what was done, write a concise changelog entry
in the style of Keep a Changelog (https://keepachangelog.com/).

Format:
### [type] Short description
- Detail bullet 1
- Detail bullet 2

Types: Added | Changed | Fixed | Removed | Security | Performance

Write only the changelog entry, no preamble.
"""


class ReviewerAgent(BaseAgent):
    """
    Reviews code quality and generates suggestions and changelogs.
    """

    def __init__(
        self,
        response_callback: Optional[Callable[[str, str], None]] = None,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self._response_callback = response_callback

    @property
    def name(self) -> AgentName:
        return AgentName.REVIEWER

    @property
    def queue(self) -> str:
        return QUEUE_REVIEWER

    # ------------------------------------------------------------------
    # handle_message
    # ------------------------------------------------------------------

    async def handle_message(self, message: AgentMessage) -> None:
        if message.task_type == TaskType.REVIEW_CODE:
            await self._review_code(message)
        else:
            self.logger.warning(f"Reviewer received unexpected task: {message.task_type.value}")

    # ------------------------------------------------------------------
    # Code review
    # ------------------------------------------------------------------

    async def _review_code(self, message: AgentMessage) -> None:
        session_id   = message.session_id
        payload      = message.payload

        file_path    = payload.get("file_path", "")
        code_content = payload.get("code_content", "")
        language     = payload.get("language", "python")
        context      = payload.get("context_summary", "")
        auto_review  = payload.get("auto_review", False)  # silent gate vs user-visible

        if not code_content:
            self.logger.warning("Review task received with no code_content")
            return

        self.logger.info(
            f"Reviewing {file_path} ({language}) session={session_id[:8]}"
        )

        if not auto_review:
            self._reply(session_id, f"Reviewing {file_path}...")

        # Build review prompt
        messages = [
            {"role": "system", "content": _REVIEW_SYSTEM_PROMPT},
            {
                "role": "user",
                "content": (
                    f"Review this {language} code from {file_path}:\n\n"
                    f"{code_content}\n\n"
                    + (f"Project context: {context}\n\n" if context else "")
                    + "Provide your review:"
                ),
            },
        ]

        try:
            review_text = await self.chat(messages, stream=False)
        except Exception as e:
            self.logger.error(f"Review generation failed: {e}")
            return

        # Parse verdict
        verdict = self._extract_verdict(review_text)
        has_issues = verdict in ("needs_revision", "approved_with_suggestions")

        # Emit review event
        await self._bus.broadcast(
            CHANNEL_AGENT_EVENTS,
            AgentEvent(
                event_type = "review_complete",
                source     = self.name,
                session_id = session_id,
                data       = {
                    "session_id":  session_id,
                    "file_path":   file_path,
                    "review_text": review_text,
                    "verdict":     verdict,
                    "has_issues":  has_issues,
                    "auto_review": auto_review,
                },
            ),
        )

        if not auto_review:
            self._reply(session_id, f"Review of {file_path}:\n\n{review_text}")
        elif has_issues:
            # In auto-review mode, only surface if there are problems
            self._reply(
                session_id,
                f"Review note for {file_path} [{verdict}]:\n{self._extract_issues(review_text)}"
            )

    # ------------------------------------------------------------------
    # Changelog generation
    # ------------------------------------------------------------------

    async def generate_changelog_entry(
        self,
        session_id:    str,
        files_written: list[str],
        session_summary: str,
    ) -> str:
        """
        Generate a CHANGELOG.md entry for this session's work.
        Called automatically at session completion.
        """
        self.logger.info(f"Generating changelog for session {session_id[:8]}")

        files_list = "\n".join(f"- {f}" for f in files_written)

        messages = [
            {"role": "system", "content": _CHANGELOG_SYSTEM_PROMPT},
            {
                "role": "user",
                "content": (
                    f"Session summary: {session_summary}\n\n"
                    f"Files changed:\n{files_list}\n\n"
                    f"Write the changelog entry:"
                ),
            },
        ]

        try:
            entry = await self.chat(messages, stream=False)
        except Exception as e:
            self.logger.error(f"Changelog generation failed: {e}")
            entry = f"### Changed\n- Session {session_id[:8]}: {session_summary}"

        return entry.strip()

    # ------------------------------------------------------------------
    # Suggestion on demand (/suggest command)
    # ------------------------------------------------------------------

    async def suggest_improvements(
        self,
        session_id:   str,
        file_path:    str,
        code_content: str,
        language:     str = "python",
    ) -> None:
        """
        Generate improvement suggestions on user request.
        Less strict than a full review — focused on enhancements.
        """
        messages = [
            {
                "role": "system",
                "content": (
                    "You are a senior developer suggesting improvements to code. "
                    "Focus on enhancements that would make the code more robust, "
                    "maintainable, or efficient. Be specific and practical. "
                    "List 3-5 concrete suggestions, prioritised by impact."
                ),
            },
            {
                "role": "user",
                "content": (
                    f"Suggest improvements for {file_path} ({language}):\n\n"
                    f"{code_content}\n\n"
                    f"List your top suggestions:"
                ),
            },
        ]

        try:
            suggestions = await self.chat(messages, stream=False)
            self._reply(session_id, f"Suggestions for {file_path}:\n\n{suggestions}")
        except Exception as e:
            self.logger.error(f"Suggestion generation failed: {e}")
            self._reply(session_id, f"Could not generate suggestions: {e}")

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _extract_verdict(self, review_text: str) -> str:
        """Extract the VERDICT line from a review response."""
        for line in review_text.splitlines():
            lower = line.lower()
            if "verdict:" in lower:
                if "needs_revision" in lower or "needs revision" in lower:
                    return "needs_revision"
                if "approved_with" in lower or "with suggestions" in lower:
                    return "approved_with_suggestions"
                if "approved" in lower:
                    return "approved"
        return "approved_with_suggestions"  # conservative default

    def _extract_issues(self, review_text: str) -> str:
        """Extract the ISSUES section from a review response."""
        lines = review_text.splitlines()
        in_issues = False
        issues = []
        for line in lines:
            if line.strip().startswith("ISSUES:"):
                in_issues = True
                continue
            if in_issues:
                if line.strip().startswith("SUGGESTIONS:") or line.strip().startswith("VERDICT:"):
                    break
                if line.strip():
                    issues.append(line.strip())
        return "\n".join(issues) if issues else "No critical issues found."

    def _reply(self, session_id: str, text: str) -> None:
        self.logger.debug(f"Reviewer → {session_id[:8]}: {text[:60]}")
        if self._response_callback:
            try:
                self._response_callback(session_id, text)
            except Exception as e:
                self.logger.warning(f"Response callback error: {e}")
