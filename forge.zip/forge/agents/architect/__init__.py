__all__ = ["ArchitectAgent", "select_stack", "plan_file_tree", "plan_build_order"]

def __getattr__(name):
    if name == "ArchitectAgent":
        from agents.architect.agent import ArchitectAgent; return ArchitectAgent
    if name == "select_stack":
        from agents.architect.stack_selector import select_stack; return select_stack
    if name == "plan_file_tree":
        from agents.architect.file_tree_planner import plan_file_tree; return plan_file_tree
    if name == "plan_build_order":
        from agents.architect.build_order_planner import plan_build_order; return plan_build_order
    raise AttributeError(f"module 'agents.architect' has no attribute {name!r}")
