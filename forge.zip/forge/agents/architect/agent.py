"""
agents/architect/agent.py
--------------------------
Architect Agent — receives approved requirements and designs the project.

Responsibilities:
- Select or confirm tech stack
- Design the file/module/directory structure
- Plan the build order (what gets written first)
- Present the architecture plan for user review
- Emit architecture_approved event once confirmed
"""

from __future__ import annotations

from typing import Any, Callable, Optional

from agents.base_agent import BaseAgent
from agents.architect.stack_selector import select_stack
from agents.architect.file_tree_planner import plan_file_tree
from agents.architect.build_order_planner import plan_build_order
from shared.constants import CHANNEL_AGENT_EVENTS, QUEUE_ARCHITECT
from shared.types import (
    AgentEvent,
    AgentMessage,
    AgentName,
    ArchitecturePlan,
    TaskType,
)


_SYSTEM_PROMPT = """You are the Architect Agent for Forge, an autonomous programming assistant.
Your role is to design clear, well-structured project architectures based on requirements.

When given requirements, you will:
1. Confirm or select the appropriate technology stack
2. Design a logical directory and module structure
3. Define a sensible build order (foundations first, features second)
4. Keep the architecture simple — no over-engineering

Respond in structured JSON only when asked. Be concise and practical.
"""


class ArchitectAgent(BaseAgent):
    """
    Designs the project architecture from approved requirements.
    """

    def __init__(
        self,
        response_callback: Optional[Callable[[str, str], None]] = None,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self._response_callback = response_callback
        # Pending plans awaiting user approval: session_id → ArchitecturePlan
        self._pending_plans: dict[str, ArchitecturePlan] = {}

    @property
    def name(self) -> AgentName:
        return AgentName.ARCHITECT

    @property
    def queue(self) -> str:
        return QUEUE_ARCHITECT

    # ------------------------------------------------------------------
    # handle_message
    # ------------------------------------------------------------------

    async def handle_message(self, message: AgentMessage) -> None:
        if message.task_type == TaskType.DESIGN_ARCHITECTURE:
            await self._design_architecture(message)
        else:
            self.logger.warning(f"Architect received unexpected task: {message.task_type.value}")

    # ------------------------------------------------------------------
    # Core flow: design → present → wait for approval
    # ------------------------------------------------------------------

    async def _design_architecture(self, message: AgentMessage) -> None:
        session_id = message.session_id
        requirements = message.payload.get("requirements", message.payload)

        self.logger.info(f"Designing architecture for session {session_id[:8]}")
        self._reply(session_id, "Designing project architecture...")

        # 1. Select tech stack
        stack = select_stack(requirements)
        self.logger.info(f"Stack selected: {stack}")

        # 2. Use LLM to generate the file tree and build order
        plan = await self._generate_plan_with_llm(session_id, requirements, stack)

        # 3. Store pending plan
        self._pending_plans[session_id] = plan

        # 4. Present to user
        plan_text = self._format_plan(plan)
        self._reply(
            session_id,
            f"{plan_text}\n\nDoes this architecture look right? "
            f"Reply 'yes' to start building, or tell me what to change."
        )

    async def _generate_plan_with_llm(
        self,
        session_id: str,
        requirements: dict[str, Any],
        stack: dict[str, Any],
    ) -> ArchitecturePlan:
        """
        Ask the LLM to generate the file tree and build order.
        Falls back to template-based generation if model is unavailable.
        """
        description = requirements.get("description", "")
        user_stories = requirements.get("user_stories", "")

        prompt_messages = [
            {"role": "system", "content": _SYSTEM_PROMPT},
            {
                "role": "user",
                "content": (
                    f"Design the file structure and build order for this project.\n\n"
                    f"Description: {description}\n"
                    f"Tech stack: {stack.get('summary', '')}\n"
                    f"User stories: {user_stories or 'None provided'}\n\n"
                    f"Return JSON with keys: directory_tree (nested dict), "
                    f"build_order (list of file paths), dependencies (list of package names)."
                ),
            },
        ]

        try:
            response = await self.chat(prompt_messages, stream=False)
            plan_data = self._parse_llm_plan(response)
        except Exception as e:
            self.logger.warning(f"LLM plan generation failed ({e}), using template")
            plan_data = plan_file_tree(requirements, stack)

        build_order = plan_data.get("build_order") or plan_build_order(plan_data.get("directory_tree", {}), stack)

        return ArchitecturePlan(
            session_id     = session_id,
            project_name   = requirements.get("description", "Project")[:50],
            language_stack = stack.get("languages", []),
            framework      = stack.get("primary_framework", ""),
            directory_tree = plan_data.get("directory_tree", {}),
            build_order    = build_order,
            dependencies   = plan_data.get("dependencies", stack.get("dependencies", [])),
            approved       = False,
        )

    def _parse_llm_plan(self, response: str) -> dict[str, Any]:
        """Parse JSON from LLM response, stripping markdown fences."""
        import json, re
        # Strip ```json ... ``` fences
        cleaned = re.sub(r"```(?:json)?", "", response).strip().rstrip("`").strip()
        return json.loads(cleaned)

    # ------------------------------------------------------------------
    # User approval handling
    # ------------------------------------------------------------------

    async def handle_approval(self, session_id: str, user_input: str) -> None:
        """
        Called when the user responds to the architecture plan presentation.
        Routes to approval or correction.
        """
        if session_id not in self._pending_plans:
            self.logger.warning(f"No pending plan for session {session_id[:8]}")
            return

        approval_words = (
            "yes", "approved", "looks good", "go ahead", "correct",
            "right", "proceed", "ok", "okay", "yep", "sure", "start"
        )

        if any(word in user_input.lower() for word in approval_words):
            await self._approve_plan(session_id)
        else:
            await self._revise_plan(session_id, user_input)

    async def _approve_plan(self, session_id: str) -> None:
        """Mark plan as approved and emit event for orchestrator."""
        plan = self._pending_plans.pop(session_id)
        plan.approved = True

        self.logger.info(f"Architecture approved for session {session_id[:8]}")
        self._reply(session_id, "Architecture confirmed. Starting to build...")

        await self._bus.broadcast(
            CHANNEL_AGENT_EVENTS,
            AgentEvent(
                event_type="architecture_approved",
                source=self.name,
                session_id=session_id,
                data={
                    "session_id":    session_id,
                    "build_order":   plan.build_order,
                    "directory_tree": plan.directory_tree,
                    "dependencies":  plan.dependencies,
                    "language_stack": plan.language_stack,
                    "framework":     plan.framework,
                },
            ),
        )

    async def _revise_plan(self, session_id: str, feedback: str) -> None:
        """Incorporate user feedback and re-present."""
        plan = self._pending_plans[session_id]
        self.logger.info(f"Revising plan for session {session_id[:8]}: {feedback[:60]}")
        self._reply(session_id, f"Adjusting the plan based on: \"{feedback}\"...")

        # For now: append to build order feedback note, re-present same plan
        # A full revision would re-invoke the LLM with the feedback
        revised_text = self._format_plan(plan)
        self._reply(
            session_id,
            f"Updated plan:\n\n{revised_text}\n\n"
            f"Does this look right now? (Reply 'yes' to proceed.)"
        )

    # ------------------------------------------------------------------
    # Formatting
    # ------------------------------------------------------------------

    def _format_plan(self, plan: ArchitecturePlan) -> str:
        lines = [
            "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
            "  FORGE — Architecture Plan",
            "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
            f"",
            f"  Stack       {', '.join(plan.language_stack) or 'TBD'}",
            f"  Framework   {plan.framework or 'TBD'}",
            f"",
            "  Build Order:",
        ]
        for i, fp in enumerate(plan.build_order, 1):
            lines.append(f"    {i:2}. {fp}")

        if plan.dependencies:
            lines.append("")
            lines.append("  Dependencies:")
            for dep in plan.dependencies[:10]:  # cap display at 10
                lines.append(f"    • {dep}")

        lines.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        return "\n".join(lines)

    def _reply(self, session_id: str, text: str) -> None:
        self.logger.debug(f"Architect → session {session_id[:8]}: {text[:60]}...")
        if self._response_callback:
            try:
                self._response_callback(session_id, text)
            except Exception as e:
                self.logger.warning(f"Response callback error: {e}")
