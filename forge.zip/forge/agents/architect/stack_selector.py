"""
agents/architect/stack_selector.py
------------------------------------
Recommends or confirms a technology stack based on requirements.
"""

from __future__ import annotations

from typing import Any

# Canonical stack profiles
_STACKS = {
    "fastapi": {
        "languages":          ["python", "sql"],
        "primary_framework":  "fastapi",
        "dependencies":       ["fastapi", "uvicorn", "pydantic", "sqlalchemy", "alembic"],
        "summary":            "Python / FastAPI / PostgreSQL",
    },
    "django": {
        "languages":          ["python", "sql"],
        "primary_framework":  "django",
        "dependencies":       ["django", "djangorestframework", "psycopg2-binary"],
        "summary":            "Python / Django REST Framework / PostgreSQL",
    },
    "express": {
        "languages":          ["typescript", "sql"],
        "primary_framework":  "express",
        "dependencies":       ["express", "typescript", "ts-node", "prisma"],
        "summary":            "TypeScript / Express / PostgreSQL",
    },
    "nextjs": {
        "languages":          ["typescript"],
        "primary_framework":  "next.js",
        "dependencies":       ["next", "react", "react-dom", "typescript"],
        "summary":            "TypeScript / Next.js / React",
    },
    "react": {
        "languages":          ["typescript"],
        "primary_framework":  "react",
        "dependencies":       ["react", "react-dom", "typescript", "vite"],
        "summary":            "TypeScript / React / Vite",
    },
    "flask": {
        "languages":          ["python"],
        "primary_framework":  "flask",
        "dependencies":       ["flask", "flask-sqlalchemy", "flask-migrate"],
        "summary":            "Python / Flask / SQLAlchemy",
    },
}

_FRAMEWORK_KEYWORDS = {
    "fastapi": "fastapi",
    "django":  "django",
    "express": "express",
    "next.js": "nextjs",
    "next":    "nextjs",
    "react":   "react",
    "flask":   "flask",
    "node":    "express",
    "vue":     "express",  # default node stack
}


def select_stack(requirements: dict[str, Any]) -> dict[str, Any]:
    """
    Select or confirm the tech stack based on requirements.

    If the user specified a stack, parse it. If empty, recommend based on description.
    Always returns a full stack profile dict.
    """
    tech_raw = requirements.get("parsed_stack") or requirements.get("tech_stack_raw", "")
    description = requirements.get("description", "").lower()

    # Try to match a known framework from the user's input
    if tech_raw:
        for keyword, profile_key in _FRAMEWORK_KEYWORDS.items():
            if keyword in tech_raw.lower():
                return _STACKS[profile_key]

    # Auto-recommend from description keywords
    if any(w in description for w in ("api", "backend", "rest", "microservice")):
        return _STACKS["fastapi"]
    if any(w in description for w in ("website", "web app", "frontend", "dashboard")):
        return _STACKS["nextjs"]
    if any(w in description for w in ("admin", "cms", "content")):
        return _STACKS["django"]

    # Default: FastAPI — solid, modern, well-suited to most projects
    return _STACKS["fastapi"]
