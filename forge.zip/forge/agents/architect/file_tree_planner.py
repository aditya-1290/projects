"""
agents/architect/file_tree_planner.py
---------------------------------------
Generates a template-based file tree when the LLM is unavailable.
"""

from __future__ import annotations
from typing import Any

_FASTAPI_TREE = {
    "src": {
        "main.py":          None,
        "config.py":        None,
        "database.py":      None,
        "models":           {"__init__.py": None},
        "routers":          {"__init__.py": None},
        "services":         {"__init__.py": None},
        "schemas":          {"__init__.py": None},
    },
    "tests":                {"__init__.py": None, "test_main.py": None},
    "requirements.txt":     None,
    ".env.example":         None,
    "README.md":            None,
}

_NEXTJS_TREE = {
    "src": {
        "app":              {"layout.tsx": None, "page.tsx": None, "globals.css": None},
        "components":       {"__init__": None},
        "lib":              {"utils.ts": None},
        "types":            {"index.ts": None},
    },
    "public":               {},
    "package.json":         None,
    "tsconfig.json":        None,
    "README.md":            None,
}

_TEMPLATES = {
    "fastapi": _FASTAPI_TREE,
    "django":  _FASTAPI_TREE,  # placeholder — reuse fastapi for now
    "express": _FASTAPI_TREE,
    "nextjs":  _NEXTJS_TREE,
    "react":   _NEXTJS_TREE,
    "flask":   _FASTAPI_TREE,
}


def plan_file_tree(requirements: dict[str, Any], stack: dict[str, Any]) -> dict[str, Any]:
    """Return a template file tree + empty build_order + dependencies."""
    framework = stack.get("primary_framework", "fastapi")
    tree = _TEMPLATES.get(framework, _FASTAPI_TREE)
    return {
        "directory_tree": tree,
        "build_order":    [],
        "dependencies":   stack.get("dependencies", []),
    }
