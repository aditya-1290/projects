"""
agents/architect/build_order_planner.py
-----------------------------------------
Determines the order in which files should be written.
Foundation files (config, models, db) always come before feature files.
"""

from __future__ import annotations
from typing import Any


_PRIORITY_PATTERNS = [
    # Earlier index = written first
    ("config",      0),
    ("settings",    0),
    ("database",    1),
    ("db",          1),
    ("models",      2),
    ("schema",      2),
    ("types",       2),
    ("utils",       3),
    ("helpers",     3),
    ("services",    4),
    ("routers",     5),
    ("routes",      5),
    ("views",       5),
    ("main",        6),
    ("app",         6),
    ("index",       7),
    ("test",        99),  # always last
]


def plan_build_order(directory_tree: dict[str, Any], stack: dict[str, Any]) -> list[str]:
    """
    Walk the directory tree and return file paths in build order.
    """
    paths = _flatten_tree(directory_tree)
    paths.sort(key=lambda p: _priority(p))
    return paths


def _flatten_tree(tree: dict[str, Any], prefix: str = "") -> list[str]:
    """Recursively collect all file paths from a nested dict tree."""
    paths: list[str] = []
    for name, children in tree.items():
        full = f"{prefix}/{name}" if prefix else name
        if children is None:
            paths.append(full)
        elif isinstance(children, dict):
            paths.extend(_flatten_tree(children, full))
    return paths


def _priority(path: str) -> int:
    lower = path.lower()
    for pattern, pri in _PRIORITY_PATTERNS:
        if pattern in lower:
            return pri
    return 50  # default mid-priority
