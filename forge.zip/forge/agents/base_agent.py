"""
agents/base_agent.py
---------------------
Base class for all Forge agents.

Handles:
- Model connection via llama.cpp OpenAI-compatible API
- Streaming chat completions
- Token budget tracking + checkpoint hook
- Message bus subscribe/publish helpers
- Structured logging per agent
"""

from __future__ import annotations

import asyncio
import json
from abc import ABC, abstractmethod
from typing import Any, AsyncIterator, Callable, Optional

import httpx

from broker.bus import MessageBus
from broker.factory import get_bus
from config.settings import get_settings
from memory.token_counter import TokenBudget
from shared.constants import CHECKPOINT_TOKEN_THRESHOLD, CHANNEL_AGENT_EVENTS
from shared.exceptions import AgentContextBurstError, ModelConnectionError
from shared.logger import get_logger
from shared.types import AgentEvent, AgentMessage, AgentName, TaskType


class BaseAgent(ABC):
    """
    All Forge agents inherit from this.

    Subclasses must implement:
        - name: AgentName property
        - queue: str property (which queue to subscribe to)
        - handle_message(message): the task handler

    Optionally override:
        - on_start(): called once when agent starts
        - on_stop(): called once when agent stops
    """

    def __init__(
        self,
        bus: Optional[MessageBus] = None,
        on_checkpoint_needed: Optional[Callable[[AgentMessage], asyncio.Future]] = None,
    ):
        self._settings = get_settings()
        self._bus = bus or get_bus()
        self._on_checkpoint_needed = on_checkpoint_needed
        self._token_budget = TokenBudget(
            context_window=self._settings.model.context_window,
            threshold=CHECKPOINT_TOKEN_THRESHOLD,
        )
        self._running = False
        self._http: Optional[httpx.AsyncClient] = None
        self.logger = get_logger(f"agent.{self.name.value}")

    # ------------------------------------------------------------------
    # Abstract interface
    # ------------------------------------------------------------------

    @property
    @abstractmethod
    def name(self) -> AgentName:
        """The agent's identity."""

    @property
    @abstractmethod
    def queue(self) -> str:
        """The message bus queue this agent listens on."""

    @abstractmethod
    async def handle_message(self, message: AgentMessage) -> None:
        """Process a single task message."""

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        """Start the agent — subscribe to queue and begin processing."""
        self._http = httpx.AsyncClient(timeout=httpx.Timeout(300.0))
        self._running = True
        await self._bus.subscribe(self.queue, self._dispatch)
        await self.on_start()
        self.logger.info(f"{self.name.value} agent started → queue={self.queue}")

    async def stop(self) -> None:
        """Gracefully stop the agent."""
        self._running = False
        await self.on_stop()
        if self._http:
            await self._http.aclose()
        self.logger.info(f"{self.name.value} agent stopped")

    async def on_start(self) -> None:
        """Override for agent-specific startup logic."""

    async def on_stop(self) -> None:
        """Override for agent-specific teardown logic."""

    # ------------------------------------------------------------------
    # Internal dispatch (wraps handle_message with error handling)
    # ------------------------------------------------------------------

    async def _dispatch(self, message: AgentMessage) -> None:
        self.logger.info(
            f"← {message.task_type.value} | from={message.from_agent.value} | id={message.message_id[:8]}"
        )
        try:
            await self.handle_message(message)
        except AgentContextBurstError:
            self.logger.warning("Context burst — checkpoint required")
            await self._emit_event("context_burst", {"message_id": message.message_id})
            if self._on_checkpoint_needed:
                await self._on_checkpoint_needed(message)
        except Exception as e:
            self.logger.error(f"Error handling {message.task_type.value}: {e}", exc_info=True)
            await self._emit_event("task_error", {
                "message_id": message.message_id,
                "task_type": message.task_type.value,
                "error": str(e),
            })

    # ------------------------------------------------------------------
    # Model: streaming chat completion
    # ------------------------------------------------------------------

    async def chat(
        self,
        messages: list[dict[str, Any]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        stream: bool = True,
    ) -> str:
        """
        Send a chat completion request to the llama.cpp server.
        Tracks token usage against the budget.
        Returns the full response text.
        """
        cfg = self._settings.model
        url = f"{cfg.base_url}/v1/chat/completions"

        # Track input tokens
        for msg in messages:
            content = msg.get("content", "")
            if isinstance(content, str):
                self._token_budget.add(content)

        payload = {
            "model": cfg.model_id,
            "messages": messages,
            "temperature": temperature if temperature is not None else cfg.temperature,
            "max_tokens": max_tokens or cfg.max_tokens,
            "stream": stream,
        }

        if not self._http:
            raise ModelConnectionError("HTTP client not initialised — call start() first")

        try:
            if stream:
                return await self._stream_chat(url, payload)
            else:
                return await self._simple_chat(url, payload)
        except httpx.ConnectError as e:
            raise ModelConnectionError(
                f"Cannot connect to model server at {cfg.base_url}. "
                f"Is llama.cpp running? Error: {e}"
            )

    async def _simple_chat(self, url: str, payload: dict) -> str:
        payload = {**payload, "stream": False}
        resp = await self._http.post(url, json=payload)
        resp.raise_for_status()
        data = resp.json()
        text = data["choices"][0]["message"]["content"]
        self._token_budget.add(text)
        return text

    async def _stream_chat(self, url: str, payload: dict) -> str:
        """Stream response, collect full text, track tokens."""
        full_text = ""
        async with self._http.stream("POST", url, json=payload) as resp:
            resp.raise_for_status()
            async for line in resp.aiter_lines():
                if not line.startswith("data: "):
                    continue
                chunk = line[6:]
                if chunk.strip() == "[DONE]":
                    break
                try:
                    data = json.loads(chunk)
                    delta = data["choices"][0].get("delta", {})
                    token = delta.get("content", "")
                    if token:
                        full_text += token
                        yield_token = token  # noqa — collected below
                except (json.JSONDecodeError, KeyError):
                    continue

        self._token_budget.add(full_text)
        return full_text

    async def chat_stream(
        self,
        messages: list[dict[str, Any]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
    ) -> AsyncIterator[str]:
        """
        Streaming variant — yields tokens as they arrive.
        Use this when you want to forward tokens to the CLI in real time.
        """
        cfg = self._settings.model
        url = f"{cfg.base_url}/v1/chat/completions"

        for msg in messages:
            content = msg.get("content", "")
            if isinstance(content, str):
                self._token_budget.add(content)

        payload = {
            "model": cfg.model_id,
            "messages": messages,
            "temperature": temperature if temperature is not None else cfg.temperature,
            "max_tokens": max_tokens or cfg.max_tokens,
            "stream": True,
        }

        if not self._http:
            raise ModelConnectionError("HTTP client not initialised")

        full_text = ""
        async with self._http.stream("POST", url, json=payload) as resp:
            resp.raise_for_status()
            async for line in resp.aiter_lines():
                if not line.startswith("data: "):
                    continue
                chunk = line[6:]
                if chunk.strip() == "[DONE]":
                    break
                try:
                    data = json.loads(chunk)
                    delta = data["choices"][0].get("delta", {})
                    token = delta.get("content", "")
                    if token:
                        full_text += token
                        yield token
                except (json.JSONDecodeError, KeyError):
                    continue

        self._token_budget.add(full_text)

    # ------------------------------------------------------------------
    # Bus helpers
    # ------------------------------------------------------------------

    async def publish(self, queue: str, message: AgentMessage) -> None:
        """Send a message to another agent's queue."""
        self.logger.debug(f"→ {queue} | {message.task_type.value}")
        await self._bus.publish(queue, message)

    async def _emit_event(self, event_type: str, data: dict[str, Any]) -> None:
        """Broadcast an event on the agent events channel."""
        event = AgentEvent(
            event_type=event_type,
            source=self.name,
            session_id=data.get("session_id", ""),
            data=data,
        )
        await self._bus.broadcast(CHANNEL_AGENT_EVENTS, event)

    # ------------------------------------------------------------------
    # Token budget helpers
    # ------------------------------------------------------------------

    def reset_token_budget(self) -> None:
        """Reset after a checkpoint save."""
        self._token_budget.reset()

    def token_percent_used(self) -> float:
        return self._token_budget.percent_used()

    def tokens_remaining(self) -> int:
        return self._token_budget.remaining()

    # ------------------------------------------------------------------
    # Prompt loading helper
    # ------------------------------------------------------------------

    def _load_prompt(self, filename: str) -> str:
        """Load a prompt file from this agent's prompts/ directory."""
        from pathlib import Path
        prompt_path = Path(__file__).parent / self.name.value / "prompts" / filename
        if prompt_path.exists():
            return prompt_path.read_text(encoding="utf-8")
        self.logger.warning(f"Prompt file not found: {prompt_path}")
        return ""

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__} queue={self.queue} running={self._running}>"
