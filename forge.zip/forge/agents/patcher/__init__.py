__all__ = ["PatcherAgent"]
def __getattr__(name):
    if name == "PatcherAgent":
        from agents.patcher.agent import PatcherAgent; return PatcherAgent
    raise AttributeError(f"module 'agents.patcher' has no attribute {name!r}")
