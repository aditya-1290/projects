"""
agents/memory_manager/agent.py
--------------------------------
Memory Manager — background service for checkpoint save/load and context recovery.

Not a conversational agent. Runs silently in the background.
Monitors token usage and triggers checkpoint saves before context burst.
On restart, rebuilds agent context from the last checkpoint.
"""

from __future__ import annotations

from typing import Optional

from agents.base_agent import BaseAgent
from memory.checkpoint_store import (
    get_latest_checkpoint,
    get_next_step_number,
    make_checkpoint,
    save_checkpoint,
)
from memory.session_store import get_session, update_session
from shared.constants import QUEUE_MEMORY
from shared.types import (
    AgentMessage,
    AgentName,
    CheckpointData,
    SessionStatus,
    TaskType,
)


class MemoryManagerAgent(BaseAgent):
    """
    Handles all checkpoint persistence and context recovery.
    Invoked by the Orchestrator whenever a checkpoint event fires.
    """

    @property
    def name(self) -> AgentName:
        return AgentName.MEMORY_MANAGER

    @property
    def queue(self) -> str:
        return QUEUE_MEMORY

    # ------------------------------------------------------------------
    # handle_message
    # ------------------------------------------------------------------

    async def handle_message(self, message: AgentMessage) -> None:
        task = message.task_type

        if task == TaskType.CHECKPOINT_SAVE:
            await self._handle_save(message)
        elif task == TaskType.CHECKPOINT_LOAD:
            await self._handle_load(message)
        else:
            self.logger.warning(f"MemoryManager: unknown task {task.value}")

    # ------------------------------------------------------------------
    # Save
    # ------------------------------------------------------------------

    async def _handle_save(self, message: AgentMessage) -> None:
        session_id = message.session_id
        payload    = message.payload

        step_number = await get_next_step_number(session_id)

        checkpoint = make_checkpoint(
            session_id           = session_id,
            step_number          = step_number,
            agent_who_saved      = AgentName(payload.get("agent", AgentName.ORCHESTRATOR.value)),
            summary_of_work_done = payload.get("summary", ""),
            files_touched        = payload.get("files_touched", []),
            next_planned_step    = payload.get("next_step", ""),
            token_count_at_save  = payload.get("token_count", 0),
        )

        await save_checkpoint(checkpoint)
        self.logger.info(
            f"Checkpoint #{step_number} saved for session {session_id[:8]} "
            f"— tokens={checkpoint.token_count_at_save}"
        )

        await self._emit_event("checkpoint_saved", {
            "session_id":    session_id,
            "checkpoint_id": checkpoint.checkpoint_id,
            "step_number":   step_number,
        })

    # ------------------------------------------------------------------
    # Load
    # ------------------------------------------------------------------

    async def _handle_load(self, message: AgentMessage) -> None:
        session_id = message.session_id
        checkpoint_id = message.payload.get("checkpoint_id")

        if checkpoint_id:
            from memory.checkpoint_store import get_checkpoint
            checkpoint = await get_checkpoint(checkpoint_id)
        else:
            checkpoint = await get_latest_checkpoint(session_id)

        if not checkpoint:
            self.logger.warning(f"No checkpoint found for session {session_id[:8]}")
            return

        context = self.build_recovery_context(checkpoint)
        self.logger.info(
            f"Checkpoint #{checkpoint.step_number} loaded for session {session_id[:8]}"
        )

        await self._emit_event("checkpoint_loaded", {
            "session_id":      session_id,
            "checkpoint_id":   checkpoint.checkpoint_id,
            "step_number":     checkpoint.step_number,
            "recovery_context": context,
            "next_step":       checkpoint.next_planned_step,
        })

    # ------------------------------------------------------------------
    # Context recovery prompt builder
    # ------------------------------------------------------------------

    @staticmethod
    def build_recovery_context(checkpoint: CheckpointData) -> str:
        """
        Build the injected context string used to resume an agent after
        a context burst or session restart.

        This is injected as a system message at the top of the next call.
        """
        files_summary = ", ".join(
            f"{f.get('path', '?')} ({f.get('op', 'write')})"
            for f in checkpoint.files_touched[:10]
        )
        if not files_summary:
            files_summary = "none yet"

        return (
            f"You are a Forge agent continuing a session after a context refresh.\n\n"
            f"Progress so far (checkpoint #{checkpoint.step_number}):\n"
            f"{checkpoint.summary_of_work_done}\n\n"
            f"Files written: {files_summary}\n\n"
            f"Your next task: {checkpoint.next_planned_step}\n\n"
            f"Continue from here. Do not repeat work already completed."
        )
