__all__ = ["MemoryManagerAgent"]

def __getattr__(name):
    if name == "MemoryManagerAgent":
        from agents.memory_manager.agent import MemoryManagerAgent; return MemoryManagerAgent
    raise AttributeError(f"module 'agents.memory_manager' has no attribute {name!r}")
