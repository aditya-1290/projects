# agents/__init__.py
# Lazy imports — submodules can be imported independently without
# triggering the full agent stack (which requires httpx at runtime).
__all__ = [
    "BaseAgent",
    "OrchestratorAgent",
    "IntakeAgent",
    "ArchitectAgent",
    "CoderAgent",
    "MemoryManagerAgent",
]

from agents.architect.agent import ArchitectAgent
from agents.base_agent import BaseAgent
from agents.coder.agent import CoderAgent
from agents.intake.agent import IntakeAgent
from agents.memory_manager.agent import MemoryManagerAgent
from agents.orchestrator.agent import OrchestratorAgent


def __getattr__(name):
    if name == "BaseAgent":
        from agents.base_agent import BaseAgent
        return BaseAgent
    if name == "OrchestratorAgent":
        from agents.orchestrator.agent import OrchestratorAgent
        return OrchestratorAgent
    if name == "IntakeAgent":
        from agents.intake.agent import IntakeAgent
        return IntakeAgent
    if name == "ArchitectAgent":
        from agents.architect.agent import ArchitectAgent
        return ArchitectAgent
    if name == "CoderAgent":
        from agents.coder.agent import CoderAgent
        return CoderAgent
    if name == "MemoryManagerAgent":
        from agents.memory_manager.agent import MemoryManagerAgent
        return MemoryManagerAgent
    raise AttributeError(f"module 'agents' has no attribute {name!r}")
