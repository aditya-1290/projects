"""
agents/orchestrator/router.py
------------------------------
Helper for constructing AgentMessage objects for routing between agents.
Keeps the orchestrator agent clean — all message construction lives here.
"""

from __future__ import annotations

from typing import Any
from uuid import uuid4

from shared.types import AgentMessage, AgentName, MessagePriority, TaskType


def build_task_message(
    task_type:  TaskType,
    from_agent: AgentName,
    to_agent:   AgentName,
    session_id: str,
    payload:    dict[str, Any],
    queue:      str,
    priority:   MessagePriority = MessagePriority.NORMAL,
    reply_to:   str | None = None,
    ttl_seconds: int = 300,
) -> AgentMessage:
    """
    Construct a well-formed AgentMessage for agent-to-agent routing.

    Args:
        task_type:   What the receiving agent should do.
        from_agent:  Sender identity.
        to_agent:    Target agent identity.
        session_id:  Active session UUID.
        payload:     Task-specific data dict.
        queue:       Target queue name (for logging / routing).
        priority:    Message priority (default: NORMAL).
        reply_to:    Optional reply queue name.
        ttl_seconds: Message TTL in seconds.

    Returns:
        A populated AgentMessage ready to publish.
    """
    return AgentMessage(
        message_id  = str(uuid4()),
        session_id  = session_id,
        from_agent  = from_agent,
        to_agent    = to_agent,
        task_type   = task_type,
        priority    = priority,
        payload     = payload,
        reply_to    = reply_to or "orchestrator.results",
        ttl_seconds = ttl_seconds,
    )


def build_checkpoint_message(
    session_id:    str,
    from_agent:    AgentName,
    summary:       str,
    files_touched: list[dict],
    next_step:     str,
    token_count:   int,
) -> AgentMessage:
    """Convenience builder for checkpoint save messages."""
    return build_task_message(
        task_type  = TaskType.CHECKPOINT_SAVE,
        from_agent = from_agent,
        to_agent   = AgentName.MEMORY_MANAGER,
        session_id = session_id,
        payload    = {
            "agent":         from_agent.value,
            "summary":       summary,
            "files_touched": files_touched,
            "next_step":     next_step,
            "token_count":   token_count,
        },
        queue = "memory_manager.tasks",
    )
