"""
agents/orchestrator/agent.py
-----------------------------
Orchestrator Agent — the root of the Forge agent system.

Responsibilities:
- Receive all initial user requests
- Detect operating mode (build / ingest / test)
- Delegate tasks to specialised agents via the message bus
- Track overall session state and progress
- Handle checkpoint triggers and context burst recovery
- Report back to the CLI via SSE stream callbacks
"""

from __future__ import annotations

import asyncio
from typing import Any, Callable, Optional
from uuid import uuid4

from agents.base_agent import BaseAgent
from agents.orchestrator.mode_detector import detect_mode
from agents.orchestrator.router import build_task_message
from memory.checkpoint_store import (
    get_latest_checkpoint,
    get_next_step_number,
    make_checkpoint,
    save_checkpoint,
)
from memory.session_store import get_session, update_session
from shared.constants import (
    CHANNEL_AGENT_EVENTS,
    QUEUE_ARCHITECT,
    QUEUE_CODER,
    QUEUE_INTAKE,
    QUEUE_MEMORY,
    QUEUE_ORCHESTRATOR,
)
from shared.types import (
    AgentMessage,
    AgentName,
    CheckpointData,
    ProjectMode,
    SessionState,
    SessionStatus,
    TaskType,
)


class OrchestratorAgent(BaseAgent):
    """
    Root orchestrator. Receives user requests, routes to specialist agents,
    tracks session progress, and manages checkpoints.
    """

    def __init__(
        self,
        stream_callback: Optional[Callable[[str, str], None]] = None,
        **kwargs,
    ):
        super().__init__(**kwargs)
        # stream_callback(event_type, data) — forwards updates to CLI/SSE
        self._stream_callback = stream_callback
        # Track active sessions: session_id → SessionState
        self._active_sessions: dict[str, SessionState] = {}
        # Track pending step info per session: session_id → step description
        self._pending_steps: dict[str, list[str]] = {}

    @property
    def name(self) -> AgentName:
        return AgentName.ORCHESTRATOR

    @property
    def queue(self) -> str:
        return QUEUE_ORCHESTRATOR

    # ------------------------------------------------------------------
    # on_start — subscribe to result events from all agents
    # ------------------------------------------------------------------

    async def on_start(self) -> None:
        await self._bus.subscribe_events(CHANNEL_AGENT_EVENTS, self._handle_agent_event)
        self.logger.info("Orchestrator subscribed to agent events")

    # ------------------------------------------------------------------
    # handle_message — main dispatch
    # ------------------------------------------------------------------

    async def handle_message(self, message: AgentMessage) -> None:
        task = message.task_type

        if task == TaskType.GATHER_REQUIREMENTS:
            await self._start_intake(message)

        elif task == TaskType.DESIGN_ARCHITECTURE:
            await self._delegate_to_architect(message)

        elif task == TaskType.WRITE_MODULE:
            await self._delegate_to_coder(message)

        elif task == TaskType.CHECKPOINT_SAVE:
            await self._save_checkpoint(message)

        elif task == TaskType.CHECKPOINT_LOAD:
            await self._load_checkpoint(message)

        elif task == TaskType.INGEST_PROJECT:
            await self._start_ingest(message)

        else:
            self.logger.warning(f"Unhandled task type: {task.value}")

    # ------------------------------------------------------------------
    # Session management
    # ------------------------------------------------------------------

    async def register_session(self, session: SessionState) -> None:
        """Called when a new session is created. Loads it into memory."""
        self._active_sessions[session.session_id] = session
        self._pending_steps[session.session_id] = []
        self.logger.info(f"Session registered: {session.session_id[:8]} ({session.project_name})")

    async def get_active_session(self, session_id: str) -> Optional[SessionState]:
        if session_id in self._active_sessions:
            return self._active_sessions[session_id]
        try:
            session = await get_session(session_id)
            self._active_sessions[session_id] = session
            return session
        except Exception:
            return None

    # ------------------------------------------------------------------
    # Mode-specific flows
    # ------------------------------------------------------------------

    async def _start_intake(self, message: AgentMessage) -> None:
        """Route to Intake Agent to gather requirements."""
        session_id = message.session_id
        self.logger.info(f"Starting intake for session {session_id[:8]}")
        self._notify("status", {
            "session_id": session_id,
            "action": "starting",
            "detail": "Gathering requirements...",
        })

        intake_msg = build_task_message(
            task_type=TaskType.GATHER_REQUIREMENTS,
            from_agent=self.name,
            to_agent=AgentName.INTAKE,
            session_id=session_id,
            payload=message.payload,
            queue=QUEUE_INTAKE,
        )
        await self.publish(QUEUE_INTAKE, intake_msg)

    async def _delegate_to_architect(self, message: AgentMessage) -> None:
        """Route approved requirements to Architect Agent."""
        session_id = message.session_id
        self.logger.info(f"Delegating to architect for session {session_id[:8]}")
        self._notify("status", {
            "session_id": session_id,
            "action": "designing",
            "detail": "Designing project architecture...",
        })

        arch_msg = build_task_message(
            task_type=TaskType.DESIGN_ARCHITECTURE,
            from_agent=self.name,
            to_agent=AgentName.ARCHITECT,
            session_id=session_id,
            payload=message.payload,
            queue=QUEUE_ARCHITECT,
        )
        await self.publish(QUEUE_ARCHITECT, arch_msg)

    async def _delegate_to_coder(self, message: AgentMessage) -> None:
        """Route a specific module write task to Coder Agent."""
        session_id = message.session_id
        file_path = message.payload.get("file_path", "unknown")
        self.logger.info(f"Delegating write task: {file_path}")
        self._notify("status", {
            "session_id": session_id,
            "action": "writing",
            "detail": f"Writing {file_path}",
        })

        coder_msg = build_task_message(
            task_type=TaskType.WRITE_MODULE,
            from_agent=self.name,
            to_agent=AgentName.CODER,
            session_id=session_id,
            payload=message.payload,
            queue=QUEUE_CODER,
        )
        await self.publish(QUEUE_CODER, coder_msg)

    async def _start_ingest(self, message: AgentMessage) -> None:
        """Route an ingest request to Intake Agent in ingest mode."""
        session_id = message.session_id
        self.logger.info(f"Starting ingest for session {session_id[:8]}")
        self._notify("status", {
            "session_id": session_id,
            "action": "ingesting",
            "detail": "Scanning existing project...",
        })

        intake_msg = build_task_message(
            task_type=TaskType.INGEST_PROJECT,
            from_agent=self.name,
            to_agent=AgentName.INTAKE,
            session_id=session_id,
            payload=message.payload,
            queue=QUEUE_INTAKE,
        )
        await self.publish(QUEUE_INTAKE, intake_msg)

    # ------------------------------------------------------------------
    # Checkpoint management
    # ------------------------------------------------------------------

    async def _save_checkpoint(self, message: AgentMessage) -> None:
        """Save a checkpoint on behalf of any agent."""
        session_id = message.session_id
        payload = message.payload

        step_number = await get_next_step_number(session_id)
        checkpoint = make_checkpoint(
            session_id=session_id,
            step_number=step_number,
            agent_who_saved=AgentName(payload.get("agent", self.name.value)),
            summary_of_work_done=payload.get("summary", ""),
            files_touched=payload.get("files_touched", []),
            next_planned_step=payload.get("next_step", ""),
            token_count_at_save=payload.get("token_count", 0),
        )
        await save_checkpoint(checkpoint)

        self._notify("checkpoint", {
            "session_id": session_id,
            "checkpoint_id": checkpoint.checkpoint_id,
            "step_number": step_number,
        })
        self.logger.info(f"Checkpoint #{step_number} saved for session {session_id[:8]}")

    async def _load_checkpoint(self, message: AgentMessage) -> None:
        """Load the latest checkpoint for a session and resume."""
        session_id = message.session_id
        checkpoint = await get_latest_checkpoint(session_id)
        if not checkpoint:
            self.logger.warning(f"No checkpoint found for session {session_id[:8]}")
            return

        self._notify("checkpoint_loaded", {
            "session_id": session_id,
            "checkpoint_id": checkpoint.checkpoint_id,
            "step_number": checkpoint.step_number,
            "summary": checkpoint.summary_of_work_done,
            "next_step": checkpoint.next_planned_step,
        })
        self.logger.info(
            f"Checkpoint #{checkpoint.step_number} loaded for session {session_id[:8]}"
        )

    # ------------------------------------------------------------------
    # Agent event handler (results + errors from specialist agents)
    # ------------------------------------------------------------------

    async def _handle_agent_event(self, event) -> None:
        """Handle broadcast events from specialist agents."""
        event_type = event.event_type
        session_id = event.session_id
        data = event.data

        self.logger.debug(f"Agent event: {event_type} from {event.source.value}")

        if event_type == "requirements_complete":
            # Intake finished — move to architecture
            await self._delegate_to_architect(AgentMessage(
                task_type=TaskType.DESIGN_ARCHITECTURE,
                from_agent=self.name,
                to_agent=AgentName.ARCHITECT,
                session_id=session_id,
                payload=data,
            ))

        elif event_type == "architecture_approved":
            # Architecture approved — begin coding
            build_order: list[str] = data.get("build_order", [])
            self.logger.info(f"Architecture approved. Build order: {len(build_order)} files")
            self._notify("build_start", {"session_id": session_id, "build_order": build_order})

        elif event_type == "module_written":
            # A file was written — log and notify
            file_path = data.get("file_path", "")
            self._notify("file_written", {"session_id": session_id, "file_path": file_path})

        elif event_type == "context_burst":
            # An agent hit its context limit — trigger checkpoint
            self.logger.warning(f"Context burst in session {session_id[:8]} — saving checkpoint")
            await self._save_checkpoint(AgentMessage(
                task_type=TaskType.CHECKPOINT_SAVE,
                from_agent=self.name,
                to_agent=AgentName.MEMORY_MANAGER,
                session_id=session_id,
                payload={
                    "agent": event.source.value,
                    "summary": "Auto-checkpoint: context burst",
                    "files_touched": data.get("files_touched", []),
                    "next_step": data.get("next_step", ""),
                    "token_count": data.get("token_count", 0),
                },
            ))

        elif event_type == "task_error":
            self.logger.error(
                f"Task error in session {session_id[:8]}: "
                f"{data.get('task_type')} — {data.get('error')}"
            )
            self._notify("error", {"session_id": session_id, **data})

    # ------------------------------------------------------------------
    # Notification helper
    # ------------------------------------------------------------------

    def _notify(self, event_type: str, data: dict[str, Any]) -> None:
        """Forward a notification to the CLI/SSE layer."""
        if self._stream_callback:
            try:
                self._stream_callback(event_type, data)
            except Exception as e:
                self.logger.warning(f"Stream callback error: {e}")
