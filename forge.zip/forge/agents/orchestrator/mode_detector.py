"""
agents/orchestrator/mode_detector.py
--------------------------------------
Detects which operating mode the user intends based on their input and context.

Modes:
  scratch — build a new project from description
  ingest  — complete or analyse an existing codebase
  test    — generate tests for an existing project
"""

from __future__ import annotations

from shared.types import ProjectMode

# Keywords that signal each mode
_SCRATCH_SIGNALS = [
    "build", "create", "make", "start", "new project", "from scratch",
    "i want to build", "i need a", "write me a", "generate a",
]

_INGEST_SIGNALS = [
    "existing", "already have", "continue", "complete", "finish",
    "here's my code", "here is my code", "ingest", "look at my",
    "help me with my", "my project", "my codebase",
]

_TEST_SIGNALS = [
    "test", "tests", "testing", "unit test", "integration test",
    "write tests", "add tests", "generate tests", "test suite",
    "coverage", "spec", "specs",
]


def detect_mode(user_input: str, project_path: str | None = None) -> ProjectMode:
    """
    Determine which mode the user intends based on natural language input.

    Args:
        user_input:   Raw text from the user.
        project_path: If provided and non-empty, biases toward ingest/test.

    Returns:
        ProjectMode enum value.
    """
    text = user_input.lower().strip()

    scratch_score = sum(1 for signal in _SCRATCH_SIGNALS if signal in text)
    ingest_score  = sum(1 for signal in _INGEST_SIGNALS  if signal in text)
    test_score    = sum(1 for signal in _TEST_SIGNALS    if signal in text)

    # If a project path is given and no scratch signals, lean toward ingest
    if project_path and scratch_score == 0:
        ingest_score += 2

    # Test mode wins if it dominates and there's no scratch signal
    if test_score > scratch_score and test_score > ingest_score:
        return ProjectMode.TEST

    if ingest_score > scratch_score:
        return ProjectMode.INGEST

    return ProjectMode.SCRATCH


def mode_from_string(value: str) -> ProjectMode:
    """Parse a mode from a string (e.g. from config or CLI flag)."""
    mapping = {
        "scratch": ProjectMode.SCRATCH,
        "build":   ProjectMode.SCRATCH,
        "ingest":  ProjectMode.INGEST,
        "complete": ProjectMode.INGEST,
        "test":    ProjectMode.TEST,
        "tests":   ProjectMode.TEST,
    }
    return mapping.get(value.lower(), ProjectMode.SCRATCH)
