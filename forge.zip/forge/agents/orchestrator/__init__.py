__all__ = ["OrchestratorAgent", "detect_mode", "mode_from_string", "build_task_message", "build_checkpoint_message"]

def __getattr__(name):
    if name == "OrchestratorAgent":
        from agents.orchestrator.agent import OrchestratorAgent; return OrchestratorAgent
    if name in ("detect_mode", "mode_from_string"):
        from agents.orchestrator import mode_detector
        return getattr(mode_detector, name)
    if name in ("build_task_message", "build_checkpoint_message"):
        from agents.orchestrator import router
        return getattr(router, name)
    raise AttributeError(f"module 'agents.orchestrator' has no attribute {name!r}")
