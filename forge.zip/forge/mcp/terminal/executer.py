"""
mcp/terminal/executor.py
--------------------------
Runs shell commands inside the project directory sandbox.

Features:
- All commands run with cwd = project root
- stdout/stderr captured and returned
- Configurable timeout (default 120s, build commands get 600s)
- Streaming output support via async generator
- Environment inherits from parent process + optional overrides
- Never runs as root (safety check)
"""

from __future__ import annotations

import asyncio
import os
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import AsyncIterator, Optional

from shared.exceptions import ForgeError
from shared.logger import get_logger

logger = get_logger(__name__)

# Default timeouts in seconds
DEFAULT_TIMEOUT = 120
BUILD_TIMEOUT = 600        # long-running builds
TEST_TIMEOUT = 300         # test suites
QUICK_TIMEOUT = 30         # linters, formatters

# Commands that get extended timeout
BUILD_COMMANDS = {"npm", "yarn", "pnpm", "mvn", "gradle", "cargo", "pip", "pip3"}
TEST_COMMANDS = {"pytest", "jest", "vitest", "rspec", "go", "cargo"}


@dataclass
class CommandResult:
    """Result of a completed command execution."""
    command:     str
    exit_code:   int
    stdout:      str
    stderr:      str
    timed_out:   bool = False
    duration_ms: float = 0.0

    @property
    def success(self) -> bool:
        return self.exit_code == 0 and not self.timed_out

    @property
    def output(self) -> str:
        """Combined stdout + stderr (stdout first)."""
        parts = []
        if self.stdout:
            parts.append(self.stdout)
        if self.stderr:
            parts.append(self.stderr)
        return "\n".join(parts)

    def summary(self) -> str:
        """One-line summary for logging/display."""
        status = "✓" if self.success else "✗"
        timeout_tag = " [TIMED OUT]" if self.timed_out else ""
        return (
            f"{status} exit={self.exit_code}{timeout_tag} "
            f"({self.duration_ms:.0f}ms)"
        )


class CommandExecutor:
    """
    Executes shell commands inside the project sandbox.
    All commands run with cwd=project_root.
    """

    def __init__(
        self,
        project_root: str,
        env_overrides: Optional[dict[str, str]] = None,
    ):
        self._root = Path(project_root).resolve()
        if not self._root.exists():
            raise ForgeError(f"Project root does not exist: {project_root}")

        # Build environment: inherit parent + apply overrides
        self._env = {**os.environ}
        if env_overrides:
            self._env.update(env_overrides)

        # Ensure PATH is reasonable
        if "PATH" not in self._env:
            self._env["PATH"] = "/usr/local/bin:/usr/bin:/bin"

    # ------------------------------------------------------------------
    # Synchronous execution
    # ------------------------------------------------------------------

    def run(
        self,
        command: str,
        timeout: Optional[int] = None,
        shell: bool = True,
        stdin_input: Optional[str] = None,
    ) -> CommandResult:
        """
        Run a command synchronously. Blocks until complete.

        Args:
            command:     Shell command string.
            timeout:     Seconds before killing process (auto-selected if None).
            shell:       Use shell=True (default). Set False for raw argv.
            stdin_input: Optional stdin data.

        Returns:
            CommandResult with exit code, stdout, stderr, duration.
        """
        import time
        effective_timeout = timeout or self._pick_timeout(command)

        logger.info(f"exec: {command[:120]!r} (timeout={effective_timeout}s)")
        start = time.monotonic()

        try:
            result = subprocess.run(
                command,
                shell=shell,
                cwd=str(self._root),
                env=self._env,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=effective_timeout,
                input=stdin_input,
            )
            duration_ms = (time.monotonic() - start) * 1000

            cmd_result = CommandResult(
                command     = command,
                exit_code   = result.returncode,
                stdout      = result.stdout or "",
                stderr      = result.stderr or "",
                duration_ms = duration_ms,
            )

        except subprocess.TimeoutExpired:
            duration_ms = (time.monotonic() - start) * 1000
            cmd_result = CommandResult(
                command     = command,
                exit_code   = -1,
                stdout      = "",
                stderr      = f"Command timed out after {effective_timeout}s",
                timed_out   = True,
                duration_ms = duration_ms,
            )

        except FileNotFoundError as e:
            cmd_result = CommandResult(
                command   = command,
                exit_code = 127,
                stdout    = "",
                stderr    = f"Command not found: {e}",
            )

        except Exception as e:
            cmd_result = CommandResult(
                command   = command,
                exit_code = -1,
                stdout    = "",
                stderr    = f"Execution error: {e}",
            )

        logger.info(f"result: {cmd_result.summary()}")
        return cmd_result

    # ------------------------------------------------------------------
    # Async streaming execution
    # ------------------------------------------------------------------

    async def run_streaming(
        self,
        command: str,
        timeout: Optional[int] = None,
    ) -> AsyncIterator[str]:
        """
        Run a command asynchronously, yielding output lines as they arrive.
        Used when the caller wants live streaming (e.g. test runner output).

        Yields lines of combined stdout+stderr in real time.
        Raises ForgeError on non-zero exit after completion.
        """
        effective_timeout = timeout or self._pick_timeout(command)
        logger.info(f"streaming exec: {command[:120]!r}")

        try:
            proc = await asyncio.create_subprocess_shell(
                command,
                cwd      = str(self._root),
                env      = self._env,
                stdout   = asyncio.subprocess.PIPE,
                stderr   = asyncio.subprocess.STDOUT,  # merge stderr into stdout
            )

            exit_code = None
            try:
                async with asyncio.timeout(effective_timeout):
                    async for line in proc.stdout:
                        decoded = line.decode("utf-8", errors="replace").rstrip()
                        yield decoded

                    exit_code = await proc.wait()

            except asyncio.TimeoutError:
                proc.kill()
                await proc.wait()
                yield f"[Forge] Command timed out after {effective_timeout}s"
                return

            if exit_code != 0:
                raise ForgeError(
                    f"Command exited with code {exit_code}: {command[:80]}"
                )

        except FileNotFoundError:
            raise ForgeError(f"Command not found: {command.split()[0]!r}")

    # ------------------------------------------------------------------
    # Common high-level shortcuts
    # ------------------------------------------------------------------

    def run_tests(
        self,
        framework: str = "auto",
        path: str = ".",
        extra_args: str = "",
    ) -> CommandResult:
        """
        Run the project's test suite.
        Auto-detects framework if framework='auto'.
        """
        if framework == "auto":
            framework = self._detect_test_framework()

        commands = {
            "pytest":  f"pytest {path} -v {extra_args}",
            "jest":    f"npx jest {path} --verbose {extra_args}",
            "vitest":  f"npx vitest run {path} {extra_args}",
            "cargo":   f"cargo test {extra_args}",
            "go":      f"go test ./... {extra_args}",
            "rspec":   f"bundle exec rspec {path} {extra_args}",
            "mvn":     f"mvn test {extra_args}",
            "gradle":  f"./gradlew test {extra_args}",
        }

        cmd = commands.get(framework, f"pytest {path} -v {extra_args}")
        return self.run(cmd, timeout=TEST_TIMEOUT)

    def run_linter(self, language: str = "python") -> CommandResult:
        """Run the appropriate linter for the given language."""
        commands = {
            "python":     "ruff check . --fix",
            "javascript": "npx eslint . --fix",
            "typescript": "npx eslint . --fix",
            "go":         "go vet ./...",
            "rust":       "cargo clippy",
        }
        cmd = commands.get(language, "ruff check .")
        return self.run(cmd, timeout=QUICK_TIMEOUT)

    def run_formatter(self, language: str = "python") -> CommandResult:
        """Run the appropriate formatter for the given language."""
        commands = {
            "python":     "black . && isort .",
            "javascript": "npx prettier --write .",
            "typescript": "npx prettier --write .",
            "rust":       "cargo fmt",
            "go":         "gofmt -w .",
        }
        cmd = commands.get(language, "black .")
        return self.run(cmd, timeout=QUICK_TIMEOUT)

    def install_dependencies(self, language: str = "python") -> CommandResult:
        """Install project dependencies."""
        commands = {
            "python":     "pip install -r requirements.txt",
            "javascript": "npm install",
            "typescript": "npm install",
            "rust":       "cargo fetch",
            "go":         "go mod download",
            "java":       "mvn dependency:resolve",
        }
        cmd = commands.get(language, "pip install -r requirements.txt")
        return self.run(cmd, timeout=BUILD_TIMEOUT)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _pick_timeout(self, command: str) -> int:
        """Auto-select a timeout based on the command type."""
        first = command.strip().split()[0] if command.strip() else ""
        first_name = Path(first).name

        if first_name in BUILD_COMMANDS:
            return BUILD_TIMEOUT
        if first_name in TEST_COMMANDS:
            return TEST_TIMEOUT
        return DEFAULT_TIMEOUT

    def _detect_test_framework(self) -> str:
        """Detect the test framework from config files present in the project."""
        root = self._root

        if (root / "pytest.ini").exists() or (root / "pyproject.toml").exists():
            # Check pyproject.toml for pytest
            try:
                content = (root / "pyproject.toml").read_text()
                if "pytest" in content:
                    return "pytest"
            except Exception:
                pass
            if (root / "requirements.txt").exists():
                try:
                    if "pytest" in (root / "requirements.txt").read_text():
                        return "pytest"
                except Exception:
                    pass

        if (root / "package.json").exists():
            try:
                import json
                pkg = json.loads((root / "package.json").read_text())
                scripts = pkg.get("scripts", {})
                devdeps = pkg.get("devDependencies", {})
                if "vitest" in devdeps or "vitest" in str(scripts):
                    return "vitest"
                if "jest" in devdeps or "jest" in str(scripts):
                    return "jest"
            except Exception:
                pass

        if (root / "Cargo.toml").exists():
            return "cargo"
        if (root / "go.mod").exists():
            return "go"
        if (root / "pom.xml").exists():
            return "mvn"

        # Default
        return "pytest"

    @property
    def project_root(self) -> str:
        return str(self._root)
