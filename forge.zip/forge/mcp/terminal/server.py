"""
mcp/terminal/server.py
-----------------------
Terminal MCP Server — the unified tool interface for running commands.

Agents call this server's methods directly (in-process for Phase 1).
Every call passes through ScopeEnforcer before reaching the executor.

Tools exposed:
  run(command)                      → CommandResult
  run_streaming(command)            → AsyncIterator[str]
  run_tests(framework, path)        → CommandResult
  run_linter(language)              → CommandResult
  run_formatter(language)           → CommandResult
  install_dependencies(language)    → CommandResult
  which(executable)                 → str | None
  is_available(executable)          → bool
"""

from __future__ import annotations

from typing import AsyncIterator, Callable, Optional

from terminal.executor import CommandExecutor, CommandResult
from terminal.scope_enforcer import ScopeEnforcer
from shared.exceptions import ForgeError
from shared.logger import get_logger

logger = get_logger(__name__)

# Callback type: (session_id, command, result) → None
ExecutionCallback = Callable[[str, str, CommandResult], None]


class TerminalServer:
    """
    In-process Terminal MCP Server.

    One instance per session. Wraps ScopeEnforcer + CommandExecutor
    behind a single clean interface that agents call directly.

    Permission model:
    - Pre-approved commands (build, test, lint): run immediately
    - Network commands: require network_approved=True per call
    - Blocked commands: raise ForgeError, never executed
    """

    def __init__(
        self,
        project_root:      str,
        session_id:        str,
        permission_check:  Optional[Callable[[str, str], bool]] = None,
        on_exec:           Optional[ExecutionCallback] = None,
        env_overrides:     Optional[dict[str, str]] = None,
    ):
        self._project_root = project_root
        self._session_id   = session_id
        self._permission_check = permission_check
        self._on_exec = on_exec

        self._enforcer = ScopeEnforcer(project_root)
        self._executor = CommandExecutor(project_root, env_overrides)

        # Audit log: list of (command, exit_code)
        self._history: list[tuple[str, int]] = []

        logger.info(
            f"TerminalServer ready: root={project_root} "
            f"session={session_id[:8]}"
        )

    # ------------------------------------------------------------------
    # Core execution
    # ------------------------------------------------------------------

    def run(
        self,
        command:          str,
        timeout:          Optional[int] = None,
        network_approved: bool = False,
        skip_permission:  bool = False,
    ) -> CommandResult:
        """
        Run a command after scope validation.

        Args:
            command:          Shell command to execute.
            timeout:          Override default timeout (seconds).
            network_approved: User has explicitly approved network access.
            skip_permission:  Bypass permission check (pre-approved flows).

        Returns:
            CommandResult.

        Raises:
            ForgeError: If command is blocked or permission denied.
        """
        # 1. Scope enforcement (always runs — can't be skipped)
        self._enforcer.validate(command, network_approved=network_approved)

        # 2. Permission check for non-pre-approved commands
        if not skip_permission and not self._enforcer.is_pre_approved(command):
            if self._permission_check:
                approved = self._permission_check(self._session_id, command)
                if not approved:
                    raise ForgeError(
                        f"Command not approved by user: {command[:80]!r}"
                    )

        # 3. Execute
        result = self._executor.run(command, timeout=timeout)

        # 4. Audit + callback
        self._history.append((command, result.exit_code))
        if self._on_exec:
            try:
                self._on_exec(self._session_id, command, result)
            except Exception as e:
                logger.warning(f"exec callback error: {e}")

        return result

    async def run_streaming(
        self,
        command:          str,
        network_approved: bool = False,
        timeout:          Optional[int] = None,
    ) -> AsyncIterator[str]:
        """
        Run a command with streaming output.
        Yields output lines as they arrive from the process.
        """
        self._enforcer.validate(command, network_approved=network_approved)

        if not self._enforcer.is_pre_approved(command):
            if self._permission_check:
                approved = self._permission_check(self._session_id, command)
                if not approved:
                    raise ForgeError(f"Command not approved: {command[:80]!r}")

        async for line in self._executor.run_streaming(command, timeout=timeout):
            yield line

    # ------------------------------------------------------------------
    # High-level shortcuts (always pre-approved)
    # ------------------------------------------------------------------

    def run_tests(
        self,
        framework:  str = "auto",
        path:       str = ".",
        extra_args: str = "",
    ) -> CommandResult:
        """Run the project test suite. Always pre-approved."""
        return self._executor.run_tests(framework, path, extra_args)

    def run_linter(self, language: str = "python") -> CommandResult:
        """Run linter for the given language. Always pre-approved."""
        return self._executor.run_linter(language)

    def run_formatter(self, language: str = "python") -> CommandResult:
        """Run formatter for the given language. Always pre-approved."""
        return self._executor.run_formatter(language)

    def install_dependencies(self, language: str = "python") -> CommandResult:
        """Install project dependencies. Always pre-approved."""
        return self._executor.install_dependencies(language)

    # ------------------------------------------------------------------
    # Utility
    # ------------------------------------------------------------------

    def which(self, executable: str) -> Optional[str]:
        """Return the full path of an executable, or None if not found."""
        result = self._executor.run(
            f"which {executable}",
            timeout=5,
        )
        if result.success and result.stdout.strip():
            return result.stdout.strip()
        return None

    def is_available(self, executable: str) -> bool:
        """Check if an executable is available in PATH."""
        return self.which(executable) is not None

    def get_python_version(self) -> Optional[str]:
        """Return the Python version string, or None."""
        result = self._executor.run("python3 --version", timeout=5)
        if result.success:
            return result.stdout.strip() or result.stderr.strip()
        return None

    def get_node_version(self) -> Optional[str]:
        """Return the Node.js version string, or None."""
        result = self._executor.run("node --version", timeout=5)
        if result.success:
            return result.stdout.strip()
        return None

    # ------------------------------------------------------------------
    # Audit
    # ------------------------------------------------------------------

    def get_history(self) -> list[tuple[str, int]]:
        """Return the execution history: list of (command, exit_code)."""
        return list(self._history)

    def clear_history(self) -> None:
        self._history.clear()

    @property
    def project_root(self) -> str:
        return self._project_root

    @property
    def session_id(self) -> str:
        return self._session_id
