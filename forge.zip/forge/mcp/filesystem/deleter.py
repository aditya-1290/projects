"""
mcp/filesystem/deleter.py
--------------------------
Safe file and directory deletion for the Forge MCP server.
All deletes are permission-gated and logged.
Deleted files are moved to a .forge/trash/ folder, not hard-deleted,
so they can be recovered in Phase 2 (rollback system).
"""

from __future__ import annotations

import shutil
from datetime import datetime
from pathlib import Path
from typing import Callable, Optional

from shared.exceptions import ForgeError, PermissionDeniedError
from shared.logger import get_logger

logger = get_logger(__name__)

PermissionCheckFn = Callable[[str, str, str], bool]


class FilesystemDeleter:
    """
    Permission-gated file deleter.
    Moves files to .forge/trash/ instead of hard-deleting.
    """

    def __init__(
        self,
        project_root:     str,
        session_id:       str,
        permission_check: Optional[PermissionCheckFn] = None,
    ):
        self._root = Path(project_root).resolve()
        self._session_id = session_id
        self._permission_check = permission_check
        self._trash = self._root / ".forge" / "trash"

    def _safe_path(self, relative_path: str) -> Path:
        resolved = (self._root / relative_path).resolve()
        try:
            resolved.relative_to(self._root)
        except ValueError:
            raise ForgeError(f"Path traversal denied: {relative_path!r}")
        return resolved

    def delete_file(self, relative_path: str) -> None:
        """
        Move a file to .forge/trash/ after permission check.
        Raises PermissionDeniedError if denied.
        """
        full = self._safe_path(relative_path)
        if not full.exists():
            raise ForgeError(f"File not found: {relative_path}")

        # Permission gate
        if self._permission_check:
            granted = self._permission_check(
                self._session_id, relative_path, f"DELETE {relative_path}"
            )
            if not granted:
                raise PermissionDeniedError(f"Delete denied: {relative_path}")

        # Move to trash
        self._trash.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        trash_name = f"{timestamp}_{full.name}"
        trash_dest = self._trash / trash_name

        shutil.move(str(full), trash_dest)
        logger.info(f"Deleted (trashed): {relative_path} → .forge/trash/{trash_name}")

    def delete_directory(self, relative_path: str, force: bool = False) -> None:
        """
        Remove an empty directory (or all contents if force=True).
        Always permission-gated.
        """
        full = self._safe_path(relative_path)
        if not full.is_dir():
            raise ForgeError(f"Directory not found: {relative_path}")

        if self._permission_check:
            granted = self._permission_check(
                self._session_id, relative_path, f"DELETE DIR {relative_path}"
            )
            if not granted:
                raise PermissionDeniedError(f"Delete denied: {relative_path}")

        if force:
            shutil.rmtree(full)
            logger.info(f"Force-deleted directory: {relative_path}")
        else:
            full.rmdir()  # raises if not empty
            logger.info(f"Deleted empty directory: {relative_path}")

    def list_trash(self) -> list[str]:
        """List files currently in the trash."""
        if not self._trash.exists():
            return []
        return [f.name for f in sorted(self._trash.iterdir()) if f.is_file()]

    def restore_from_trash(self, trash_filename: str, restore_to: str) -> None:
        """Restore a trashed file back to the project."""
        src = self._trash / trash_filename
        if not src.exists():
            raise ForgeError(f"Trash file not found: {trash_filename}")

        dest = self._safe_path(restore_to)
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(src), dest)
        logger.info(f"Restored from trash: {trash_filename} → {restore_to}")
