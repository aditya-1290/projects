"""
mcp/filesystem/writer.py
-------------------------
Safe filesystem writer for the Forge MCP server.

Responsibilities:
- Write files atomically (write to temp → rename)
- Create parent directories automatically
- Keep a single-level backup of overwritten files
- Enforce path safety (same sandbox as reader)
- Emit file_written events via callback
- Respect permission checks before every write
"""

from __future__ import annotations

import os
import shutil
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Callable, Optional

from shared.constants import EXTENSION_LANGUAGE_MAP, INGEST_EXCLUDE_PATTERNS
from shared.exceptions import ForgeError, PermissionDeniedError
from shared.logger import get_logger

logger = get_logger(__name__)

# Callback signature: (session_id, file_path, diff) -> bool
PermissionCheckFn = Callable[[str, str, str], bool]

# Callback signature: (file_path: str) -> None
FileWrittenCallback = Callable[[str], None]


class FilesystemWriter:
    """
    Atomic file writer with permission gating and backup.
    Created per-session by the MCP server.
    """

    def __init__(
        self,
        project_root:       str,
        session_id:         str,
        permission_check:   Optional[PermissionCheckFn] = None,
        on_file_written:    Optional[FileWrittenCallback] = None,
    ):
        self._root = Path(project_root).resolve()
        self._session_id = session_id
        self._permission_check = permission_check
        self._on_file_written = on_file_written

        # Track what was written this session
        self._written: list[str] = []

    # ------------------------------------------------------------------
    # Path safety (mirrors reader)
    # ------------------------------------------------------------------

    def _safe_path(self, relative_path: str) -> Path:
        resolved = (self._root / relative_path).resolve()
        try:
            resolved.relative_to(self._root)
        except ValueError:
            raise ForgeError(
                f"Path traversal denied: {relative_path!r} escapes project root"
            )
        return resolved

    # ------------------------------------------------------------------
    # Core write
    # ------------------------------------------------------------------

    def write_file(
        self,
        relative_path: str,
        content:       str,
        skip_permission: bool = False,
    ) -> str:
        """
        Write content to a file atomically.

        1. Permission check (unless skip_permission=True)
        2. Create parent directories
        3. Write to a temp file
        4. Rename to final path (atomic on POSIX; best-effort on Windows)
        5. Fire on_file_written callback

        Returns the absolute path written.
        Raises PermissionDeniedError if the permission check fails.
        """
        full = self._safe_path(relative_path)

        # Generate a simple diff preview for the permission prompt
        diff = self._make_diff_preview(full, content)

        # Permission gate
        if not skip_permission and self._permission_check:
            granted = self._permission_check(self._session_id, relative_path, diff)
            if not granted:
                raise PermissionDeniedError(
                    f"Write denied by user: {relative_path}"
                )

        # Create parent dirs
        full.parent.mkdir(parents=True, exist_ok=True)

        # Backup existing file (one level deep)
        if full.exists():
            backup = full.with_suffix(full.suffix + ".forge_bak")
            shutil.copy2(full, backup)
            logger.debug(f"Backed up {relative_path} → {backup.name}")

        # Atomic write
        try:
            tmp_fd, tmp_path = tempfile.mkstemp(
                dir=full.parent, suffix=".forge_tmp"
            )
            with os.fdopen(tmp_fd, "w", encoding="utf-8") as f:
                f.write(content)

            # Atomic rename
            os.replace(tmp_path, full)

        except Exception as e:
            # Clean up temp file if rename failed
            if os.path.exists(tmp_path):
                os.unlink(tmp_path)
            raise ForgeError(f"Write failed for {relative_path}: {e}") from e

        self._written.append(relative_path)
        logger.info(f"Written: {relative_path} ({len(content)} chars)")

        # Notify caller (used to push file_written SSE event)
        if self._on_file_written:
            self._on_file_written(relative_path)

        return str(full)

    def write_files(
        self,
        files: dict[str, str],
        skip_permission: bool = False,
    ) -> list[str]:
        """
        Write multiple files. Stops on first permission denial.
        Returns list of successfully written relative paths.
        """
        written = []
        for path, content in files.items():
            try:
                self.write_file(path, content, skip_permission=skip_permission)
                written.append(path)
            except PermissionDeniedError:
                logger.warning(f"Skipped (denied): {path}")
            except ForgeError as e:
                logger.error(f"Write error for {path}: {e}")
        return written

    # ------------------------------------------------------------------
    # Create directories
    # ------------------------------------------------------------------

    def create_directory(self, relative_path: str) -> None:
        """Create a directory (and parents) inside the project root."""
        full = self._safe_path(relative_path)
        full.mkdir(parents=True, exist_ok=True)
        logger.debug(f"Directory created: {relative_path}")

    # ------------------------------------------------------------------
    # Diff preview
    # ------------------------------------------------------------------

    def _make_diff_preview(self, full_path: Path, new_content: str) -> str:
        """
        Generate a simple unified diff preview for the permission prompt.
        Returns an empty string if the file doesn't exist yet (new file).
        """
        if not full_path.exists():
            # New file — show first 30 lines as preview
            lines = new_content.splitlines()[:30]
            preview = f"--- /dev/null\n+++ {full_path.name}\n"
            for line in lines:
                preview += f"+ {line}\n"
            if len(new_content.splitlines()) > 30:
                preview += f"... ({len(new_content.splitlines())} lines total)\n"
            return preview

        try:
            import difflib
            old = full_path.read_text(encoding="utf-8", errors="replace")
            diff = list(difflib.unified_diff(
                old.splitlines(keepends=True),
                new_content.splitlines(keepends=True),
                fromfile=f"a/{full_path.name}",
                tofile=f"b/{full_path.name}",
                n=3,
            ))
            return "".join(diff[:80])  # cap at 80 diff lines
        except Exception:
            return f"(diff unavailable for {full_path.name})"

    # ------------------------------------------------------------------
    # Query
    # ------------------------------------------------------------------

    def get_written_files(self) -> list[str]:
        """Return list of relative paths written this session."""
        return list(self._written)