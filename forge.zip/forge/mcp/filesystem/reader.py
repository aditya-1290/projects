"""
mcp/filesystem/reader.py
-------------------------
Safe filesystem reader for the Forge MCP server.

Responsibilities:
- Read individual file contents
- List directory contents (filtered)
- Scan a project tree and return ProjectFile metadata
- Enforce path safety (no traversal outside project root)
- Respect INGEST_EXCLUDE_PATTERNS
"""

from __future__ import annotations

import os
from datetime import datetime
from pathlib import Path
from typing import Optional

from shared.constants import (
    EXTENSION_LANGUAGE_MAP,
    INGEST_EXCLUDE_PATTERNS,
    CONFIG_FILE_NAMES,
)
from shared.exceptions import ForgeError
from shared.logger import get_logger
from shared.types import ProjectFile

logger = get_logger(__name__)

# Max file size we'll read into memory (5 MB)
MAX_READ_BYTES = 5 * 1024 * 1024


class FilesystemReader:
    """
    Safe, sandboxed file reader.
    All paths are resolved relative to a project root.
    """

    def __init__(self, project_root: str):
        self._root = Path(project_root).resolve()
        if not self._root.exists():
            raise ForgeError(f"Project root does not exist: {project_root}")

    # ------------------------------------------------------------------
    # Path safety
    # ------------------------------------------------------------------

    def _safe_path(self, relative_path: str) -> Path:
        """
        Resolve a path and verify it stays inside the project root.
        Raises ForgeError if the path escapes the sandbox.
        """
        resolved = (self._root / relative_path).resolve()
        try:
            resolved.relative_to(self._root)
        except ValueError:
            raise ForgeError(
                f"Path traversal denied: {relative_path!r} escapes project root"
            )
        return resolved

    def _should_exclude(self, path: Path) -> bool:
        """Return True if any path component is in the exclude list."""
        parts = set(path.parts)
        return bool(parts & set(INGEST_EXCLUDE_PATTERNS))

    # ------------------------------------------------------------------
    # File reading
    # ------------------------------------------------------------------

    def read_file(self, relative_path: str) -> str:
        """
        Read a file's contents as a UTF-8 string.
        Falls back to latin-1 if UTF-8 fails (e.g. some config files).
        """
        full = self._safe_path(relative_path)

        if not full.exists():
            raise ForgeError(f"File not found: {relative_path}")
        if not full.is_file():
            raise ForgeError(f"Not a file: {relative_path}")

        size = full.stat().st_size
        if size > MAX_READ_BYTES:
            raise ForgeError(
                f"File too large to read ({size} bytes): {relative_path}"
            )

        try:
            content = full.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            content = full.read_text(encoding="latin-1")
            logger.debug(f"Fell back to latin-1 for {relative_path}")

        logger.debug(f"Read {relative_path} ({size} bytes)")
        return content

    def read_file_bytes(self, relative_path: str) -> bytes:
        """Read a file as raw bytes."""
        full = self._safe_path(relative_path)
        if not full.exists():
            raise ForgeError(f"File not found: {relative_path}")
        return full.read_bytes()

    def file_exists(self, relative_path: str) -> bool:
        """Check if a file exists inside the project root."""
        try:
            return self._safe_path(relative_path).is_file()
        except ForgeError:
            return False

    # ------------------------------------------------------------------
    # Directory listing
    # ------------------------------------------------------------------

    def list_directory(self, relative_path: str = ".") -> list[dict]:
        """
        List contents of a directory.
        Returns list of dicts with: name, type (file/dir), size, language.
        """
        full = self._safe_path(relative_path)
        if not full.is_dir():
            raise ForgeError(f"Not a directory: {relative_path}")

        entries = []
        for entry in sorted(full.iterdir()):
            if self._should_exclude(entry):
                continue

            rel = str(entry.relative_to(self._root))
            if entry.is_dir():
                entries.append({
                    "name":     entry.name,
                    "path":     rel,
                    "type":     "dir",
                    "size":     None,
                    "language": None,
                })
            elif entry.is_file():
                ext = entry.suffix.lower()
                entries.append({
                    "name":     entry.name,
                    "path":     rel,
                    "type":     "file",
                    "size":     entry.stat().st_size,
                    "language": EXTENSION_LANGUAGE_MAP.get(ext),
                })

        return entries

    # ------------------------------------------------------------------
    # Project tree scan
    # ------------------------------------------------------------------

    def scan_project(self) -> list[ProjectFile]:
        """
        Walk the entire project tree and return ProjectFile metadata.
        Used by the Ingest agent to understand the codebase.
        """
        files: list[ProjectFile] = []

        for full_path in sorted(self._root.rglob("*")):
            if not full_path.is_file():
                continue

            # Check each component against exclude list
            rel = full_path.relative_to(self._root)
            skip = False
            for part in rel.parts:
                if part in INGEST_EXCLUDE_PATTERNS:
                    skip = True
                    break
            if skip:
                continue

            ext = full_path.suffix.lower()
            language = EXTENSION_LANGUAGE_MAP.get(ext, "unknown")
            stat = full_path.stat()

            files.append(ProjectFile(
                file_path     = str(rel),
                language      = language,
                size_bytes    = stat.st_size,
                last_modified = datetime.fromtimestamp(stat.st_mtime),
                is_config     = full_path.name in CONFIG_FILE_NAMES,
            ))

        logger.info(f"Scanned {len(files)} files in {self._root}")
        return files

    def get_project_root(self) -> str:
        return str(self._root)
