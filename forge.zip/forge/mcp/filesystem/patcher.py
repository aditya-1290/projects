"""
mcp/filesystem/patcher.py
--------------------------
Applies unified diffs / patches to existing files.
Used by the Patcher agent (Phase 2) and by the Coder agent
when modifying an existing file rather than rewriting it.
"""

from __future__ import annotations

import difflib
from pathlib import Path
from typing import Optional

from shared.exceptions import ForgeError
from shared.logger import get_logger

logger = get_logger(__name__)


class FilesystemPatcher:
    """
    Applies patches (unified diff format or line-level replacements)
    to files inside the project sandbox.
    """

    def __init__(self, project_root: str):
        self._root = Path(project_root).resolve()

    def _safe_path(self, relative_path: str) -> Path:
        resolved = (self._root / relative_path).resolve()
        try:
            resolved.relative_to(self._root)
        except ValueError:
            raise ForgeError(f"Path traversal denied: {relative_path!r}")
        return resolved

    # ------------------------------------------------------------------
    # Replace-block patch (most common for agent use)
    # ------------------------------------------------------------------

    def replace_block(
        self,
        relative_path:  str,
        old_block:      str,
        new_block:      str,
        occurrence:     int = 1,
    ) -> str:
        """
        Replace the Nth occurrence of old_block with new_block in a file.
        Returns the new file content.
        Raises ForgeError if the block is not found.
        """
        full = self._safe_path(relative_path)
        if not full.is_file():
            raise ForgeError(f"File not found: {relative_path}")

        content = full.read_text(encoding="utf-8")
        count = content.count(old_block)

        if count == 0:
            raise ForgeError(
                f"Block not found in {relative_path}. "
                f"First 80 chars of block: {old_block[:80]!r}"
            )

        if occurrence > count:
            raise ForgeError(
                f"Occurrence {occurrence} requested but block appears {count} time(s) in {relative_path}"
            )

        # Replace the Nth occurrence
        idx = -1
        for _ in range(occurrence):
            idx = content.find(old_block, idx + 1)

        new_content = content[:idx] + new_block + content[idx + len(old_block):]

        import tempfile, os
        tmp_fd, tmp_path = tempfile.mkstemp(dir=full.parent, suffix=".forge_tmp")
        with os.fdopen(tmp_fd, "w", encoding="utf-8") as f:
            f.write(new_content)
        os.replace(tmp_path, full)

        logger.info(f"Patched block in {relative_path} (occurrence {occurrence})")
        return new_content

    # ------------------------------------------------------------------
    # Unified diff apply
    # ------------------------------------------------------------------

    def apply_unified_diff(
        self,
        relative_path: str,
        unified_diff:  str,
    ) -> str:
        """
        Apply a unified diff string to a file.
        Returns the patched file content.
        """
        full = self._safe_path(relative_path)
        if not full.is_file():
            raise ForgeError(f"File not found: {relative_path}")

        original_lines = full.read_text(encoding="utf-8").splitlines(keepends=True)

        try:
            patched_lines = list(
                difflib._patch_unified(original_lines, unified_diff.splitlines(keepends=True))
            )
        except Exception as e:
            raise ForgeError(f"Failed to apply diff to {relative_path}: {e}") from e

        new_content = "".join(patched_lines)

        import tempfile, os
        tmp_fd, tmp_path = tempfile.mkstemp(dir=full.parent, suffix=".forge_tmp")
        with os.fdopen(tmp_fd, "w", encoding="utf-8") as f:
            f.write(new_content)
        os.replace(tmp_path, full)

        logger.info(f"Applied unified diff to {relative_path}")
        return new_content

    # ------------------------------------------------------------------
    # Insert at line
    # ------------------------------------------------------------------

    def insert_at_line(
        self,
        relative_path: str,
        line_number:   int,
        content:       str,
    ) -> str:
        """Insert content before a given line number (1-indexed)."""
        full = self._safe_path(relative_path)
        if not full.is_file():
            raise ForgeError(f"File not found: {relative_path}")

        lines = full.read_text(encoding="utf-8").splitlines(keepends=True)

        insert_idx = max(0, min(line_number - 1, len(lines)))
        if not content.endswith("\n"):
            content += "\n"
        lines.insert(insert_idx, content)

        new_content = "".join(lines)
        full.write_text(new_content, encoding="utf-8")
        logger.info(f"Inserted at line {line_number} in {relative_path}")
        return new_content

    # ------------------------------------------------------------------
    # Generate diff (for preview / logging)
    # ------------------------------------------------------------------

    def diff(self, relative_path: str, new_content: str) -> str:
        """Return a unified diff between current file content and new_content."""
        full = self._safe_path(relative_path)
        if not full.is_file():
            old_lines = []
        else:
            old_lines = full.read_text(encoding="utf-8").splitlines(keepends=True)

        new_lines = new_content.splitlines(keepends=True)
        return "".join(difflib.unified_diff(
            old_lines, new_lines,
            fromfile=f"a/{relative_path}",
            tofile=f"b/{relative_path}",
            n=3,
        ))