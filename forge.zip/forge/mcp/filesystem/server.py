"""
mcp/filesystem/server.py
-------------------------
Filesystem MCP Server — the unified tool interface for agents.

Agents call this server's methods directly (in-process for Phase 1).
In Phase 2 this will be wrapped in the MCP protocol over stdio/HTTP.

Tools exposed:
  read_file(path)              → str
  write_file(path, content)    → str (abs path written)
  write_files(files_dict)      → list[str]
  patch_file(path, old, new)   → str (new content)
  delete_file(path)            → None
  list_directory(path)         → list[dict]
  file_exists(path)            → bool
  scan_project()               → list[ProjectFile]
  get_project_summary()        → dict
"""

from __future__ import annotations

from typing import Callable, Optional

from mcp.filesystem.deleter import FilesystemDeleter
from mcp.filesystem.patcher import FilesystemPatcher
from mcp.filesystem.reader import FilesystemReader
from mcp.filesystem.writer import FilesystemWriter
from shared.logger import get_logger
from shared.types import ProjectFile

logger = get_logger(__name__)

PermissionCheckFn = Callable[[str, str, str], bool]
FileWrittenCallback = Callable[[str], None]


class FilesystemServer:
    """
    In-process MCP Filesystem Server.

    One instance per session. Wraps the four specialist classes
    (reader, writer, patcher, deleter) behind a single clean interface.
    Agents import and call this directly.
    """

    def __init__(
        self,
        project_root:     str,
        session_id:       str,
        permission_check: Optional[PermissionCheckFn] = None,
        on_file_written:  Optional[FileWrittenCallback] = None,
    ):
        self._project_root = project_root
        self._session_id = session_id

        self._reader = FilesystemReader(project_root)
        self._writer = FilesystemWriter(
            project_root     = project_root,
            session_id       = session_id,
            permission_check = permission_check,
            on_file_written  = on_file_written,
        )
        self._patcher = FilesystemPatcher(project_root)
        self._deleter = FilesystemDeleter(
            project_root     = project_root,
            session_id       = session_id,
            permission_check = permission_check,
        )

        logger.info(
            f"FilesystemServer ready: root={project_root} session={session_id[:8]}"
        )

    # ------------------------------------------------------------------
    # Read tools
    # ------------------------------------------------------------------

    def read_file(self, path: str) -> str:
        """Read a file and return its contents as a string."""
        return self._reader.read_file(path)

    def file_exists(self, path: str) -> bool:
        """Check if a file exists in the project."""
        return self._reader.file_exists(path)

    def list_directory(self, path: str = ".") -> list[dict]:
        """
        List directory contents.
        Returns: [{"name", "path", "type", "size", "language"}, ...]
        """
        return self._reader.list_directory(path)

    def scan_project(self) -> list[ProjectFile]:
        """
        Scan the entire project tree.
        Returns list of ProjectFile metadata objects.
        Used by intake/architect agents at session start.
        """
        return self._reader.scan_project()

    def get_project_summary(self) -> dict:
        """
        Return a high-level summary of the project:
        file count, languages present, config files found.
        Used by the Architect agent to understand the codebase quickly.
        """
        files = self._reader.scan_project()

        languages: dict[str, int] = {}
        config_files: list[str] = []
        total_size = 0

        for f in files:
            lang = f.language or "unknown"
            languages[lang] = languages.get(lang, 0) + 1
            total_size += f.size_bytes
            if f.is_config:
                config_files.append(f.file_path)

        # Sort languages by file count
        top_languages = sorted(languages.items(), key=lambda x: -x[1])

        return {
            "project_root":   self._project_root,
            "total_files":    len(files),
            "total_size_kb":  round(total_size / 1024, 1),
            "languages":      dict(top_languages),
            "top_language":   top_languages[0][0] if top_languages else "unknown",
            "config_files":   config_files,
        }

    # ------------------------------------------------------------------
    # Write tools
    # ------------------------------------------------------------------

    def write_file(
        self,
        path:             str,
        content:          str,
        skip_permission:  bool = False,
    ) -> str:
        """
        Write a file.
        Triggers permission check unless skip_permission=True.
        Returns absolute path of the written file.
        """
        return self._writer.write_file(path, content, skip_permission=skip_permission)

    def write_files(
        self,
        files: dict[str, str],
        skip_permission: bool = False,
    ) -> list[str]:
        """
        Write multiple files in one call.
        Returns list of successfully written relative paths.
        """
        return self._writer.write_files(files, skip_permission=skip_permission)

    def create_directory(self, path: str) -> None:
        """Create a directory (and parents) inside the project."""
        self._writer.create_directory(path)

    def get_written_files(self) -> list[str]:
        """Return all file paths written in this session."""
        return self._writer.get_written_files()

    # ------------------------------------------------------------------
    # Patch tools
    # ------------------------------------------------------------------

    def patch_file(
        self,
        path:       str,
        old_block:  str,
        new_block:  str,
        occurrence: int = 1,
    ) -> str:
        """
        Replace a block of text in a file.
        Returns the new file content.
        """
        return self._patcher.replace_block(path, old_block, new_block, occurrence)

    def apply_diff(self, path: str, unified_diff: str) -> str:
        """Apply a unified diff string to a file."""
        return self._patcher.apply_unified_diff(path, unified_diff)

    def get_diff(self, path: str, new_content: str) -> str:
        """Return a unified diff between current file and new_content."""
        return self._patcher.diff(path, new_content)

    # ------------------------------------------------------------------
    # Delete tools
    # ------------------------------------------------------------------

    def delete_file(self, path: str) -> None:
        """Move a file to .forge/trash/ (permission-gated)."""
        self._deleter.delete_file(path)

    def delete_directory(self, path: str, force: bool = False) -> None:
        """Delete a directory (permission-gated)."""
        self._deleter.delete_directory(path, force=force)

    def list_trash(self) -> list[str]:
        """List files in the project's trash folder."""
        return self._deleter.list_trash()

    def restore_file(self, trash_filename: str, restore_to: str) -> None:
        """Restore a file from trash back into the project."""
        self._deleter.restore_from_trash(trash_filename, restore_to)

    # ------------------------------------------------------------------
    # Info
    # ------------------------------------------------------------------

    @property
    def project_root(self) -> str:
        return self._project_root

    @property
    def session_id(self) -> str:
        return self._session_id
