"""
mcp/git/server.py
------------------
Git MCP Server — wraps git operations for Forge agents.

Git integration is opt-in per session (git_enabled flag on SessionState).
All operations are permission-gated at appropriate levels:
  - Read ops (status, diff, log): always allowed
  - Commit: requires git_commit permission
  - Push:   requires explicit user approval every time

Uses subprocess + git CLI directly (no gitpython dependency in Phase 1).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

from shared.exceptions import ForgeError
from shared.logger import get_logger

logger = get_logger(__name__)

# Permission callback: (session_id, operation) → bool
GitPermissionFn = Callable[[str, str], bool]


@dataclass
class GitStatus:
    """Result of `git status`."""
    branch:        str
    is_clean:      bool
    staged:        list[str]     = field(default_factory=list)
    unstaged:      list[str]     = field(default_factory=list)
    untracked:     list[str]     = field(default_factory=list)
    ahead:         int           = 0
    behind:        int           = 0
    has_remote:    bool          = False


@dataclass
class GitCommit:
    """Metadata for a single commit."""
    hash:      str
    short_hash: str
    author:    str
    date:      str
    message:   str


class GitServer:
    """
    In-process Git MCP Server.
    All git commands run in the project root via subprocess.
    """

    def __init__(
        self,
        project_root:      str,
        session_id:        str,
        permission_check:  Optional[GitPermissionFn] = None,
    ):
        self._root = Path(project_root).resolve()
        self._session_id = session_id
        self._permission_check = permission_check

        if not self._root.exists():
            raise ForgeError(f"Project root does not exist: {project_root}")

        logger.info(
            f"GitServer ready: root={project_root} session={session_id[:8]}"
        )

    # ------------------------------------------------------------------
    # Internal runner
    # ------------------------------------------------------------------

    def _git(self, *args: str, check_permission: Optional[str] = None) -> str:
        """
        Run a git command in the project root.
        Returns stdout as string. Raises ForgeError on failure.

        Args:
            *args:             git subcommand + args (e.g. "status", "--short")
            check_permission:  If set, run permission check with this operation name.
        """
        import subprocess

        if check_permission and self._permission_check:
            approved = self._permission_check(self._session_id, check_permission)
            if not approved:
                raise ForgeError(f"Git operation denied: {check_permission}")

        cmd = ["git"] + list(args)
        logger.debug(f"git: {' '.join(cmd)}")

        try:
            result = subprocess.run(
                cmd,
                cwd=str(self._root),
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=60,
            )
        except FileNotFoundError:
            raise ForgeError(
                "git is not installed or not in PATH. "
                "Install git to use Git integration."
            )
        except subprocess.TimeoutExpired:
            raise ForgeError(f"git {args[0]} timed out after 60s")

        if result.returncode != 0:
            raise ForgeError(
                f"git {args[0]} failed (exit {result.returncode}): "
                f"{result.stderr.strip()[:200]}"
            )

        return result.stdout

    # ------------------------------------------------------------------
    # Repository state
    # ------------------------------------------------------------------

    def is_git_repo(self) -> bool:
        """Return True if the project root is inside a git repository."""
        try:
            self._git("rev-parse", "--git-dir")
            return True
        except ForgeError:
            return False

    def init(self) -> None:
        """Initialise a new git repository in the project root."""
        self._git("init")
        logger.info(f"Git repo initialised at {self._root}")

    def status(self) -> GitStatus:
        """Return structured git status for the project."""
        # Branch
        try:
            branch = self._git("rev-parse", "--abbrev-ref", "HEAD").strip()
        except ForgeError:
            branch = "HEAD"

        # Short status
        short = self._git("status", "--short").strip()

        staged, unstaged, untracked = [], [], []
        for line in short.splitlines():
            if len(line) < 2:
                continue
            xy = line[:2]
            path = line[3:].strip().strip('"')
            x, y = xy[0], xy[1]

            if x in ("A", "M", "D", "R", "C") and x != " ":
                staged.append(path)
            if y in ("M", "D") and y != " ":
                unstaged.append(path)
            if xy == "??":
                untracked.append(path)

        # Ahead/behind
        ahead, behind = 0, 0
        has_remote = False
        try:
            remote_info = self._git(
                "rev-list", "--left-right", "--count",
                f"HEAD...@{{u}}"
            ).strip()
            parts = remote_info.split()
            if len(parts) == 2:
                ahead, behind = int(parts[0]), int(parts[1])
                has_remote = True
        except ForgeError:
            pass

        return GitStatus(
            branch     = branch,
            is_clean   = not (staged or unstaged or untracked),
            staged     = staged,
            unstaged   = unstaged,
            untracked  = untracked,
            ahead      = ahead,
            behind     = behind,
            has_remote = has_remote,
        )

    def current_branch(self) -> str:
        """Return the name of the current branch."""
        return self._git("rev-parse", "--abbrev-ref", "HEAD").strip()

    # ------------------------------------------------------------------
    # Diff
    # ------------------------------------------------------------------

    def diff(self, staged: bool = False, path: Optional[str] = None) -> str:
        """
        Return unified diff output.

        Args:
            staged: If True, show staged diff (--cached).
            path:   Limit diff to this file path.
        """
        args = ["diff"]
        if staged:
            args.append("--cached")
        if path:
            args += ["--", path]
        return self._git(*args)

    def diff_file(self, file_path: str) -> str:
        """Return the diff for a specific file (unstaged changes)."""
        return self.diff(staged=False, path=file_path)

    # ------------------------------------------------------------------
    # Staging
    # ------------------------------------------------------------------

    def add(self, path: str = ".") -> None:
        """Stage files for commit."""
        self._git("add", path)
        logger.debug(f"Staged: {path}")

    def add_all(self) -> None:
        """Stage all changes."""
        self._git("add", "-A")
        logger.debug("Staged all changes")

    def reset(self, path: Optional[str] = None) -> None:
        """Unstage files (git reset HEAD)."""
        args = ["reset", "HEAD"]
        if path:
            args.append(path)
        self._git(*args)

    # ------------------------------------------------------------------
    # Commit
    # ------------------------------------------------------------------

    def commit(
        self,
        message:      str,
        stage_all:    bool = False,
        allow_empty:  bool = False,
    ) -> str:
        """
        Create a commit. Requires git_commit permission.

        Args:
            message:     Commit message.
            stage_all:   If True, git add -A before committing.
            allow_empty: Allow empty commits.

        Returns:
            The new commit hash.
        """
        if not message.strip():
            raise ForgeError("Commit message cannot be empty")

        if stage_all:
            self.add_all()

        args = ["commit", "-m", message]
        if allow_empty:
            args.append("--allow-empty")

        self._git(*args, check_permission="git_commit")

        # Return the new commit hash
        return self._git("rev-parse", "HEAD").strip()

    def amend(self, message: Optional[str] = None) -> str:
        """Amend the last commit. Requires git_commit permission."""
        args = ["commit", "--amend"]
        if message:
            args += ["-m", message]
        else:
            args.append("--no-edit")
        self._git(*args, check_permission="git_commit")
        return self._git("rev-parse", "HEAD").strip()

    # ------------------------------------------------------------------
    # Branching
    # ------------------------------------------------------------------

    def branches(self) -> list[str]:
        """List all local branches."""
        output = self._git("branch", "--format=%(refname:short)")
        return [b.strip() for b in output.splitlines() if b.strip()]

    def create_branch(self, name: str, checkout: bool = True) -> None:
        """Create a new branch, optionally checking it out."""
        if checkout:
            self._git("checkout", "-b", name)
        else:
            self._git("branch", name)
        logger.info(f"Branch created: {name}")

    def checkout(self, branch: str) -> None:
        """Check out an existing branch."""
        self._git("checkout", branch)
        logger.info(f"Checked out: {branch}")

    def delete_branch(self, name: str, force: bool = False) -> None:
        """Delete a branch."""
        flag = "-D" if force else "-d"
        self._git("branch", flag, name,
                  check_permission="git_branch_delete")
        logger.info(f"Deleted branch: {name}")

    # ------------------------------------------------------------------
    # Remote operations (always require explicit approval)
    # ------------------------------------------------------------------

    def pull(self, remote: str = "origin", branch: Optional[str] = None) -> str:
        """Pull from remote. Requires push_pull permission."""
        args = ["pull", remote]
        if branch:
            args.append(branch)
        return self._git(*args, check_permission="git_pull")

    def push(
        self,
        remote:     str = "origin",
        branch:     Optional[str] = None,
        force:      bool = False,
        set_upstream: bool = False,
    ) -> str:
        """
        Push to remote. Always requires explicit approval.

        Forge spec: push requires explicit user approval EVERY time.
        """
        args = ["push", remote]
        if branch:
            args.append(branch)
        if force:
            args.append("--force-with-lease")  # safer than --force
        if set_upstream:
            args += ["--set-upstream", remote, branch or self.current_branch()]

        return self._git(*args, check_permission="git_push")

    def fetch(self, remote: str = "origin") -> str:
        """Fetch from remote."""
        return self._git("fetch", remote, check_permission="git_fetch")

    # ------------------------------------------------------------------
    # Log
    # ------------------------------------------------------------------

    def log(self, n: int = 10, path: Optional[str] = None) -> list[GitCommit]:
        """Return the last N commits as GitCommit objects."""
        fmt = "%H|%h|%an|%ai|%s"
        args = ["log", f"-{n}", f"--format={fmt}"]
        if path:
            args += ["--", path]

        output = self._git(*args)
        commits = []
        for line in output.strip().splitlines():
            parts = line.split("|", 4)
            if len(parts) == 5:
                commits.append(GitCommit(
                    hash       = parts[0],
                    short_hash = parts[1],
                    author     = parts[2],
                    date       = parts[3],
                    message    = parts[4],
                ))
        return commits

    # ------------------------------------------------------------------
    # Auto-commit helper (used by Coder Agent after each file write)
    # ------------------------------------------------------------------

    def auto_commit(self, file_paths: list[str], description: str) -> Optional[str]:
        """
        Stage specific files and commit with an auto-generated message.
        Returns the commit hash, or None if nothing to commit.
        """
        for path in file_paths:
            try:
                self.add(path)
            except ForgeError as e:
                logger.warning(f"git add failed for {path}: {e}")

        # Check if there's anything staged
        staged_diff = self.diff(staged=True)
        if not staged_diff.strip():
            logger.debug("auto_commit: nothing staged, skipping")
            return None

        message = f"forge: {description}"
        try:
            return self.commit(message)
        except ForgeError as e:
            logger.warning(f"auto_commit failed: {e}")
            return None

    # ------------------------------------------------------------------
    # Info
    # ------------------------------------------------------------------

    @property
    def project_root(self) -> str:
        return str(self._root)
