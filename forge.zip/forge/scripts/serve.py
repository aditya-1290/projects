"""
scripts/serve.py
-----------------
Starts the Forge FastAPI server with uvicorn.
Run with: python scripts/serve.py
Or:       python -m uvicorn backend.app:app --reload
"""

from __future__ import annotations

import sys
import os

# Add forge root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import uvicorn
from config.settings import get_settings


def main():
    settings = get_settings()
    uvicorn.run(
        "backend.app:app",
        host=settings.server.host,
        port=settings.server.port,
        reload=settings.debug_mode,
        log_level=settings.log_level.lower(),
        access_log=False,  # We use our own middleware
    )


if __name__ == "__main__":
    main()
