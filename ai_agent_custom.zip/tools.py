"""
tools.py — All agent tools (shared by HuggingFace runner and ADK runner).
Each function is a plain Python callable with full docstrings so both
HuggingFace's chat template and Google ADK can auto-generate schemas from them.
"""

import os
import requests
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()

OPENWEATHER_KEY  = os.getenv("OPENWEATHER_KEY")
EXCHANGERATE_KEY = os.getenv("EXCHANGERATE_KEY")
TIMEZONEDB_KEY   = os.getenv("TIMEZONEDB_KEY")


# ---------------------------------------------------------------------------
# Tool: Get Current Time
# ---------------------------------------------------------------------------
def get_current_time(city: str) -> dict:
    """Returns the current local time and timezone for a specified city.

    Args:
        city: The name of the city to get the current time for.
    """
    try:
        url = "http://api.timezonedb.com/v2.1/get-time-zone"
        params = {"key": TIMEZONEDB_KEY, "format": "json", "by": "city", "city": city}
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()
        if data.get("status") != "OK":
            return {"status": "error", "message": data.get("message", "Unknown error.")}
        return {
            "status": "success",
            "city": city.title(),
            "time": data["formatted"].split(" ")[1],
            "date": data["formatted"].split(" ")[0],
            "timezone": data["zoneName"],
            "utc_offset": f"UTC{'+' if data['gmtOffset'] >= 0 else ''}{data['gmtOffset'] // 3600}",
        }
    except requests.exceptions.RequestException as e:
        return {"status": "error", "message": str(e)}


# ---------------------------------------------------------------------------
# Tool: Get Weather
# ---------------------------------------------------------------------------
def get_weather(city: str, unit: str = "celsius") -> dict:
    """Returns real-time weather conditions for a specified city.

    Args:
        city: The name of the city to get weather for.
        unit: Temperature unit — 'celsius' or 'fahrenheit'. Defaults to 'celsius'.
    """
    try:
        units_param = "imperial" if unit.lower() == "fahrenheit" else "metric"
        unit_label  = "°F" if units_param == "imperial" else "°C"
        url = "https://api.openweathermap.org/data/2.5/weather"
        params = {"q": city, "appid": OPENWEATHER_KEY, "units": units_param}
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()
        return {
            "status": "success",
            "city": data["name"],
            "country": data["sys"]["country"],
            "temperature": f"{round(data['main']['temp'], 1)}{unit_label}",
            "feels_like": f"{round(data['main']['feels_like'], 1)}{unit_label}",
            "condition": data["weather"][0]["description"].title(),
            "humidity": f"{data['main']['humidity']}%",
            "wind_speed": f"{data['wind']['speed']} {'mph' if units_param == 'imperial' else 'm/s'}",
        }
    except requests.exceptions.HTTPError as e:
        if e.response.status_code == 404:
            return {"status": "error", "message": f"City '{city}' not found."}
        return {"status": "error", "message": str(e)}
    except requests.exceptions.RequestException as e:
        return {"status": "error", "message": str(e)}


# ---------------------------------------------------------------------------
# Tool: Currency Converter
# ---------------------------------------------------------------------------
def convert_currency(amount: float, from_currency: str, to_currency: str) -> dict:
    """Converts an amount from one currency to another using live exchange rates.

    Args:
        amount: The numeric amount to convert.
        from_currency: The source currency code (e.g., 'USD').
        to_currency: The target currency code (e.g., 'INR').
    """
    try:
        src = from_currency.upper()
        tgt = to_currency.upper()
        url = f"https://v6.exchangerate-api.com/v6/{EXCHANGERATE_KEY}/pair/{src}/{tgt}/{amount}"
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        data = response.json()
        if data.get("result") != "success":
            return {"status": "error", "message": data.get("error-type", "Unknown error.")}
        return {
            "status": "success",
            "from": src,
            "to": tgt,
            "original_amount": amount,
            "converted_amount": round(data["conversion_result"], 4),
            "exchange_rate": data["conversion_rate"],
            "last_updated": data.get("time_last_update_utc", "N/A"),
        }
    except requests.exceptions.RequestException as e:
        return {"status": "error", "message": str(e)}


# ---------------------------------------------------------------------------
# Tool: Date & Timezone Info
# ---------------------------------------------------------------------------
def get_date_info(city: str) -> dict:
    """Returns the current date, day of the week, week number, and timezone details for a city.

    Args:
        city: The name of the city to get date and timezone info for.
    """
    try:
        url = "http://api.timezonedb.com/v2.1/get-time-zone"
        params = {"key": TIMEZONEDB_KEY, "format": "json", "by": "city", "city": city}
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()
        if data.get("status") != "OK":
            return {"status": "error", "message": data.get("message", "Unknown error.")}
        local_dt = datetime.strptime(data["formatted"], "%Y-%m-%d %H:%M:%S")
        return {
            "status": "success",
            "city": city.title(),
            "date": local_dt.strftime("%B %d, %Y"),
            "day_of_week": local_dt.strftime("%A"),
            "week_number": local_dt.isocalendar()[1],
            "timezone": data["zoneName"],
            "utc_offset": f"UTC{'+' if data['gmtOffset'] >= 0 else ''}{data['gmtOffset'] // 3600}",
            "is_weekend": local_dt.weekday() >= 5,
        }
    except requests.exceptions.RequestException as e:
        return {"status": "error", "message": str(e)}


# ---------------------------------------------------------------------------
# Tool: World Clock
# ---------------------------------------------------------------------------
def get_world_clock(cities: list) -> dict:
    """Returns the current time for multiple cities at once.

    Args:
        cities: A list of city names to get times for (e.g., ['Tokyo', 'London', 'New York']).
    """
    results, errors = [], []
    for city in cities:
        result = get_current_time(city)
        if result["status"] == "success":
            results.append(result)
        else:
            errors.append({"city": city, "error": result["message"]})
    return {
        "status": "success",
        "clock_count": len(results),
        "world_clock": results,
        "errors": errors if errors else None,
    }


# ---------------------------------------------------------------------------
# Convenience: all tools as a list (used by both runners)
# ---------------------------------------------------------------------------
ALL_TOOLS = [
    get_current_time,
    get_weather,
    convert_currency,
    get_date_info,
    get_world_clock,
]

# Name → function mapping (used by HF runner for tool dispatch)
TOOL_REGISTRY = {fn.__name__: fn for fn in ALL_TOOLS}