import os
import json
import inspect
import requests
from datetime import datetime
from dotenv import load_dotenv
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM

load_dotenv()

OPENWEATHER_KEY   = os.getenv("OPENWEATHER_KEY")
EXCHANGERATE_KEY  = os.getenv("EXCHANGERATE_KEY")
TIMEZONEDB_KEY    = os.getenv("TIMEZONEDB_KEY")

# ---------------------------------------------------------------------------
# Load local Qwen2.5-7B-Instruct model
# ---------------------------------------------------------------------------
MODEL_PATH = "D:/python_tasks/models/qwen2.5-7b-instruct"   # or replace with your local folder path

print("Loading tokenizer and model — this may take a moment...")
tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH)
model = AutoModelForCausalLM.from_pretrained(
    MODEL_PATH,
    torch_dtype=torch.bfloat16,   # efficient on GPU; use torch.float32 for CPU-only
    device_map="auto",             # auto-selects GPU/CPU
)
print("Model loaded!\n")


# ---------------------------------------------------------------------------
# Tool: Get Current Time
# ---------------------------------------------------------------------------
def get_current_time(city: str) -> dict:
    """Returns the current local time and timezone for a specified city.

    Args:
        city: The name of the city.
    """
    try:
        url = "http://api.timezonedb.com/v2.1/get-time-zone"
        params = {"key": TIMEZONEDB_KEY, "format": "json", "by": "city", "city": city}
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()
        if data.get("status") != "OK":
            return {"status": "error", "message": data.get("message", "Unknown error.")}
        return {
            "status": "success",
            "city": city.title(),
            "time": data["formatted"].split(" ")[1],
            "date": data["formatted"].split(" ")[0],
            "timezone": data["zoneName"],
            "utc_offset": f"UTC{'+' if data['gmtOffset'] >= 0 else ''}{data['gmtOffset'] // 3600}",
        }
    except requests.exceptions.RequestException as e:
        return {"status": "error", "message": str(e)}


# ---------------------------------------------------------------------------
# Tool: Get Weather
# ---------------------------------------------------------------------------
def get_weather(city: str, unit: str = "celsius") -> dict:
    """Returns real-time weather conditions for a specified city.

    Args:
        city: The name of the city.
        unit: Temperature unit — 'celsius' or 'fahrenheit'. Defaults to 'celsius'.
    """
    try:
        units_param = "imperial" if unit.lower() == "fahrenheit" else "metric"
        unit_label  = "°F" if units_param == "imperial" else "°C"
        url = "https://api.openweathermap.org/data/2.5/weather"
        params = {"q": city, "appid": OPENWEATHER_KEY, "units": units_param}
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()
        return {
            "status": "success",
            "city": data["name"],
            "country": data["sys"]["country"],
            "temperature": f"{round(data['main']['temp'], 1)}{unit_label}",
            "feels_like": f"{round(data['main']['feels_like'], 1)}{unit_label}",
            "condition": data["weather"][0]["description"].title(),
            "humidity": f"{data['main']['humidity']}%",
            "wind_speed": f"{data['wind']['speed']} {'mph' if units_param == 'imperial' else 'm/s'}",
        }
    except requests.exceptions.HTTPError as e:
        if e.response.status_code == 404:
            return {"status": "error", "message": f"City '{city}' not found."}
        return {"status": "error", "message": str(e)}
    except requests.exceptions.RequestException as e:
        return {"status": "error", "message": str(e)}


# ---------------------------------------------------------------------------
# Tool: Currency Converter
# ---------------------------------------------------------------------------
def convert_currency(amount: float, from_currency: str, to_currency: str) -> dict:
    """Converts an amount from one currency to another using live exchange rates.

    Args:
        amount: The numeric amount to convert.
        from_currency: The source currency code (e.g., 'USD').
        to_currency: The target currency code (e.g., 'INR').
    """
    try:
        src = from_currency.upper()
        tgt = to_currency.upper()
        url = f"https://v6.exchangerate-api.com/v6/{EXCHANGERATE_KEY}/pair/{src}/{tgt}/{amount}"
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        data = response.json()
        if data.get("result") != "success":
            return {"status": "error", "message": data.get("error-type", "Unknown error.")}
        return {
            "status": "success",
            "from": src,
            "to": tgt,
            "original_amount": amount,
            "converted_amount": round(data["conversion_result"], 4),
            "exchange_rate": data["conversion_rate"],
            "last_updated": data.get("time_last_update_utc", "N/A"),
        }
    except requests.exceptions.RequestException as e:
        return {"status": "error", "message": str(e)}


# ---------------------------------------------------------------------------
# Tool: Date & Timezone Info
# ---------------------------------------------------------------------------
def get_date_info(city: str) -> dict:
    """Returns the current date, day of the week, week number, and timezone details for a city.

    Args:
        city: The name of the city.
    """
    try:
        url = "http://api.timezonedb.com/v2.1/get-time-zone"
        params = {"key": TIMEZONEDB_KEY, "format": "json", "by": "city", "city": city}
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()
        if data.get("status") != "OK":
            return {"status": "error", "message": data.get("message", "Unknown error.")}
        local_dt = datetime.strptime(data["formatted"], "%Y-%m-%d %H:%M:%S")
        return {
            "status": "success",
            "city": city.title(),
            "date": local_dt.strftime("%B %d, %Y"),
            "day_of_week": local_dt.strftime("%A"),
            "week_number": local_dt.isocalendar()[1],
            "timezone": data["zoneName"],
            "utc_offset": f"UTC{'+' if data['gmtOffset'] >= 0 else ''}{data['gmtOffset'] // 3600}",
            "is_weekend": local_dt.weekday() >= 5,
        }
    except requests.exceptions.RequestException as e:
        return {"status": "error", "message": str(e)}


# ---------------------------------------------------------------------------
# Tool: World Clock
# ---------------------------------------------------------------------------
def get_world_clock(cities: list) -> dict:
    """Returns the current time for multiple cities at once.

    Args:
        cities: A list of city names (e.g., ['Tokyo', 'London', 'New York']).
    """
    results, errors = [], []
    for city in cities:
        result = get_current_time(city)
        if result["status"] == "success":
            results.append(result)
        else:
            errors.append({"city": city, "error": result["message"]})
    return {
        "status": "success",
        "clock_count": len(results),
        "world_clock": results,
        "errors": errors if errors else None,
    }


# ---------------------------------------------------------------------------
# Tool registry — maps tool names to actual Python functions
# ---------------------------------------------------------------------------
TOOLS = {
    "get_current_time":  get_current_time,
    "get_weather":       get_weather,
    "convert_currency":  convert_currency,
    "get_date_info":     get_date_info,
    "get_world_clock":   get_world_clock,
}

# ---------------------------------------------------------------------------
# Auto-build OpenAI-style tool schema from Python function signatures
# ---------------------------------------------------------------------------
def build_tool_schema(fn) -> dict:
    sig  = inspect.signature(fn)
    doc  = inspect.getdoc(fn) or ""
    desc = doc.split("\n")[0]
    params, required = {}, []

    for name, param in sig.parameters.items():
        ann = param.annotation
        if ann in (int, float):      ptype = "number"
        elif ann == bool:            ptype = "boolean"
        elif ann in (list,):         ptype = "array"
        else:                        ptype = "string"

        param_desc = ""
        for line in doc.split("\n"):
            if line.strip().startswith(f"{name}:"):
                param_desc = line.strip()[len(name)+1:].strip()

        params[name] = {"type": ptype, "description": param_desc}
        if param.default == inspect.Parameter.empty:
            required.append(name)

    return {
        "type": "function",
        "function": {
            "name": fn.__name__,
            "description": desc,
            "parameters": {"type": "object", "properties": params, "required": required},
        },
    }

tool_schemas = [build_tool_schema(fn) for fn in TOOLS.values()]


# ---------------------------------------------------------------------------
# System prompt
# ---------------------------------------------------------------------------
SYSTEM_PROMPT = """You are a knowledgeable and friendly global assistant. You help users with:

1. Current Time     — Use `get_current_time` for the time in a specific city.
2. Weather          — Use `get_weather` for real-time weather. Default to Celsius.
3. Currency         — Use `convert_currency` for live forex conversions.
4. Date & Timezone  — Use `get_date_info` for date/day/week info for a city.
5. World Clock      — Use `get_world_clock` to compare times across multiple cities.

Always use tools for data — never guess. Be concise and friendly."""


# ---------------------------------------------------------------------------
# Agentic loop
# ---------------------------------------------------------------------------
def run_agent(user_message: str) -> str:
    """Run the agentic loop: prompt → model → tool call (if needed) → final reply."""
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user",   "content": user_message},
    ]

    while True:
        # Apply Qwen2.5 chat template with tool schemas
        text = tokenizer.apply_chat_template(
            messages,
            tools=tool_schemas,
            tokenize=False,
            add_generation_prompt=True,
        )
        inputs = tokenizer([text], return_tensors="pt").to(model.device)

        with torch.no_grad():
            output_ids = model.generate(
                **inputs,
                max_new_tokens=512,
                do_sample=False,
            )

        # Decode only newly generated tokens
        new_tokens   = output_ids[0][inputs["input_ids"].shape[-1]:]
        response_text = tokenizer.decode(new_tokens, skip_special_tokens=False)

        # Check if the model wants to call a tool
        if "<tool_call>" in response_text:
            try:
                tool_block = response_text.split("<tool_call>")[1].split("</tool_call>")[0].strip()
                tool_call  = json.loads(tool_block)
                fn_name    = tool_call["name"]
                fn_args    = tool_call.get("arguments", tool_call.get("parameters", {}))

                print(f"[Tool Call]   {fn_name}({fn_args})")

                tool_result = TOOLS[fn_name](**fn_args) if fn_name in TOOLS else {
                    "status": "error", "message": f"Unknown tool: {fn_name}"
                }
                print(f"[Tool Result] {tool_result}\n")

                # Feed result back and loop for final answer
                messages.append({"role": "assistant", "content": response_text})
                messages.append({
                    "role": "tool",
                    "name": fn_name,
                    "content": json.dumps(tool_result),
                })
                continue

            except (json.JSONDecodeError, KeyError, IndexError) as e:
                return f"[Error parsing tool call: {e}]\nRaw output: {response_text}"
        else:
            # Final natural language answer — strip special tokens
            clean = (response_text
                     .replace("<|im_end|>", "")
                     .replace("<|im_start|>", "")
                     .strip())
            return clean


# ---------------------------------------------------------------------------
# Interactive CLI
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    print("=== Qwen2.5-7B Local Agent ===")
    print("Ask me about time, weather, currency, or dates. Type 'exit' to quit.\n")
    while True:
        user_input = input("You: ").strip()
        if user_input.lower() in ("exit", "quit"):
            break
        if not user_input:
            continue
        answer = run_agent(user_input)
        print(f"\nAgent: {answer}\n")