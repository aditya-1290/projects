import json
import re

from llm import llm

# ---------------------------------------------------------------------------
# Required args per tool — used by the validator
# ---------------------------------------------------------------------------
TOOL_REQUIRED_ARGS = {
    "get_weather": ["city"],
    "get_current_time": ["city"],
    "get_date_info": ["city"],
    "get_world_clock": ["cities"],
    "convert_currency": ["amount", "from_currency", "to_currency"],
    "get_stock_price": ["ticker"],
    "get_news": ["topic"],  # query is optional
    "web_search": ["query"],  # NEW
    "calculate": ["expression"],
    "get_gold_price": [],
    "convert_units": ["value", "from_unit", "to_unit"],  # NEW
}

TOOL_VALID_ARGS = {
    "get_weather": {"city", "unit"},
    "get_current_time": {"city"},
    "get_date_info": {"city"},
    "get_world_clock": {"cities"},
    "convert_currency": {"amount", "from_currency", "to_currency"},
    "get_stock_price": {"ticker"},
    "get_news": {"topic", "query", "limit", "original_query"},
    "web_search": {"query", "num_results"},
    "calculate": {"expression"},
    "get_gold_price": set(),
    "convert_units": {"value", "from_unit", "to_unit"},
}

VALID_TOOLS = set(TOOL_REQUIRED_ARGS.keys())

PLANNER_PROMPT = """
You are a planning agent.

Return ONLY a valid JSON plan. No explanation, no markdown, no extra text.

Format:
{
  "steps": [
    {
      "task": "short description",
      "agent": "weather | finance | time | news | search | general",
      "tool": "tool_name or null",
      "args": {}
    }
  ]
}

Available tools and their required args:
- get_weather(city, unit?)                              → agent: weather
- get_current_time(city)                               → agent: time
- get_date_info(city)                                  → agent: time
- get_world_clock(cities: list)                        → agent: time
- convert_currency(amount, from_currency, to_currency) → agent: finance
- get_stock_price(ticker)                              → agent: finance
- get_gold_price()                                     → agent: finance  ← USE THIS for gold/gold price queries, NEVER get_stock_price
- get_news(topic?, query?, limit?)                     → agent: news
  • topic: category (technology, business, sports, politics, science, health, world, top)
  • query: optional search term for specific company/topic (e.g., "NVIDIA", "Apple", "AI")
  • limit: number of articles (default 3, max 10)
- web_search(query, num_results?)                      → agent: search  ← USE THIS for general knowledge, definitions, comparisons, unknown facts
  • query: what to search for (e.g., "FastAPI vs Flask architecture")
  • num_results: number of results (default 5)
- calculate(expression)                                → agent: general
- convert_units(value, from_unit, to_unit)             → agent: general  ← NEW: convert between units (km→miles, kg→lbs, celsius→fahrenheit, etc.)

CRITICAL RULES:

1. City args — ALWAYS use a specific city name, NEVER a country or region:
   - "India" → "Mumbai", "United States/America" → "New York"
   - "UK/Britain" → "London", "UAE" → "Dubai", "France" → "Paris"
   - Neighbourhoods like "Colaba" → use parent city "Mumbai"

2. Stock tickers — use the correct symbol:
   US stocks:
   - Apple → "AAPL", Tesla → "TSLA", Google → "GOOGL"
   - Microsoft → "MSFT", Amazon → "AMZN", Meta → "META"
   - Dow Jones → "^DJI", S&P 500 → "^GSPC", Nasdaq → "^IXIC"
   Indian stocks (NSE use .NS suffix, BSE use .BO suffix):
   - Tata Consultancy Services / TCS → "TCS.NS"
   - Infosys → "INFY.NS", Wipro → "WIPRO.NS"
   - Reliance Industries → "RELIANCE.NS"
   - HDFC Bank → "HDFCBANK.NS", ICICI Bank → "ICICIBANK.NS"
   - Nifty 50 index → "^NSEI", Sensex → "^BSESN"
   - ALWAYS add .NS for Indian NSE stocks if user mentions Indian company

3. Gold and commodities — NEVER use get_stock_price for commodities:
   - Gold price → use get_gold_price() with NO args
   - Silver, Oil etc → tell user these are not supported yet

4. News vs Web Search — CRITICAL DISTINCTION:
   - get_news → for broad news categories: "tech news", "sports headlines", "business news"
   - web_search → for specific information: "news about NVIDIA", "what is FastAPI", "difference between X and Y"
   - For company-specific news ("NVIDIA news", "Apple updates") → use web_search with query="NVIDIA latest news"
   - For definitions, comparisons, general knowledge → use web_search

5. News topics — use newsdata.io category names exactly:
   - "technology", "business", "sports", "politics", "science", "health",
     "entertainment", "world", "environment", "food", "tourism", "top"
   - "finance" → use "business" (newsdata.io doesn't have "finance" category)
   - "tech" or "technology" → use "technology"
   - "general" or "latest" → use "top"

6. Calculator — pass the raw math expression as a string:
   - "what is 15000 * 18%" → expression: "15000 * 0.18"
   - "500 USD in INR then 10% tax" → two steps: convert_currency then calculate
   - "sqrt of 144" → expression: "sqrt(144)"

7. Unit Converter — use for any unit conversion:
   - Length: km→miles, meters→feet, inches→cm, etc.
   - Weight: kg→lbs, grams→ounces, etc.
   - Volume: liters→gallons, ml→cups, etc.
   - Temperature: celsius→fahrenheit, etc.
   - Example: "10 km to miles" → convert_units(value=10, from_unit="km", to_unit="miles")

8. General rules:
   - If tool needed → always include "args" with ALL required arguments
   - If general reasoning → "tool": null, "args": {}
   - For simple single-intent queries → ONE step only
   - For multi-intent queries → one step per intent, in logical order
   - For questions about concepts, definitions, comparisons → use web_search

Examples:
{"steps": [{"task": "Get Apple stock price", "agent": "finance", "tool": "get_stock_price", "args": {"ticker": "AAPL"}}]}

{"steps": [{"task": "Get tech news", "agent": "news", "tool": "get_news", "args": {"topic": "technology", "limit": 5}}]}

{"steps": [{"task": "Search for NVIDIA news", "agent": "search", "tool": "web_search", "args": {"query": "NVIDIA latest news", "num_results": 5}}]}

{"steps": [{"task": "Explain difference between FastAPI and Flask", "agent": "search", "tool": "web_search", "args": {"query": "FastAPI vs Flask architecture differences"}}]}

{"steps": [{"task": "Calculate 15000 * 1.18", "agent": "general", "tool": "calculate", "args": {"expression": "15000 * 1.18"}}]}

{"steps": [{"task": "Convert 10 kilometers to miles", "agent": "general", "tool": "convert_units", "args": {"value": 10, "from_unit": "km", "to_unit": "miles"}}]}

{"steps": [{"task": "Convert 500 USD to INR", "agent": "finance", "tool": "convert_currency", "args": {"amount": 500, "from_currency": "USD", "to_currency": "INR"}}, {"task": "Calculate 10% tax on result", "agent": "general", "tool": "calculate", "args": {"expression": "result * 0.10"}}]}
"""


def _extract_json(text: str) -> dict | None:
    try:
        return json.loads(text.strip())
    except Exception:
        pass
    match = re.search(r"```(?:json)?\s*(\{.*?})\s*```", text, re.DOTALL)
    if match:
        try:
            return json.loads(match.group(1))
        except Exception:
            pass
    match = re.search(r"(\{.*})", text, re.DOTALL)
    if match:
        try:
            return json.loads(match.group(1))
        except Exception:
            pass
    return None


def _validate_and_fix_steps(steps: list) -> list:
    """
    Validate and fix planner output:
    - Drop steps with unknown tools
    - Strip hallucinated arguments
    - Validate required args
    - Fix news topics and extract entities
    """
    validated = []

    # Valid news topics from newsdata.io
    VALID_NEWS_TOPICS = {
        "technology", "business", "sports", "politics", "science",
        "health", "world", "top", "entertainment", "environment",
        "food", "tourism", "crime", "education"
    }

    # Common entities for news query extraction
    COMMON_ENTITIES = [
        "nvidia", "apple", "tesla", "google", "microsoft", "amazon",
        "meta", "openai", "anthropic", "intel", "amd", "netflix",
        "tcs", "infosys", "wipro", "reliance", "hdfc", "icici",
        "bitcoin", "ethereum", "crypto"
    ]

    for step in steps:
        tool_name = step.get("tool")
        args = step.get("args", {})

        # ── Step 1: Handle no-tool steps ────────────────────────────────
        if not tool_name:
            validated.append(step)
            continue

        # ── Step 2: Validate tool exists ────────────────────────────────
        if tool_name not in VALID_TOOLS:
            print(f"[Planner Validator] ⚠ Unknown tool '{tool_name}' — dropping step")
            continue

        # ── Step 3: Tool-specific fixes ─────────────────────────────────
        if tool_name == "get_news":
            task = step.get("task", "").lower()

            # Store original query for context
            args["original_query"] = task

            # Extract specific entity from task
            for entity in COMMON_ENTITIES:
                if entity in task:
                    args["query"] = entity
                    print(f"[Planner Fix] News entity detected: '{entity}'")
                    break

            # Validate/fix topic
            topic = args.get("topic", "").lower().strip()
            if not topic or topic not in VALID_NEWS_TOPICS:
                print(f"[Planner Fix] Invalid/missing topic '{topic}' → using 'technology'")
                args["topic"] = "technology"

            step["args"] = args

        elif tool_name == "web_search":
            # Ensure query exists
            if "query" not in args or not args["query"]:
                # Use task as fallback query
                args["query"] = step.get("task", "")
                print(f"[Planner Fix] web_search missing query → using task")
                step["args"] = args

        elif tool_name == "convert_units":
            # Normalize unit names
            if "from_unit" in args:
                args["from_unit"] = args["from_unit"].lower().strip()
            if "to_unit" in args:
                args["to_unit"] = args["to_unit"].lower().strip()
            step["args"] = args

        elif tool_name == "get_weather":
            # Ensure unit is valid
            if "unit" in args:
                unit = args["unit"].lower()
                if unit not in ["celsius", "fahrenheit"]:
                    args["unit"] = "celsius"
            step["args"] = args

        # ── Step 4: Strip hallucinated args ──────────────────────────────
        valid_args = TOOL_VALID_ARGS.get(tool_name, set())
        hallucinated = [k for k in args if k not in valid_args]
        if hallucinated:
            print(f"[Planner Validator] ⚠ Stripping hallucinated args {hallucinated} from '{tool_name}'")
            args = {k: v for k, v in args.items() if k in valid_args}
            step = {**step, "args": args}

        # ── Step 5: Validate required args ───────────────────────────────
        required = TOOL_REQUIRED_ARGS.get(tool_name, [])
        missing = [arg for arg in required if arg not in args or args[arg] is None]

        if missing:
            print(f"[Planner Validator] ⚠ Tool '{tool_name}' missing args {missing} — dropping step")
            continue

        # ── Step 6: Step is valid ────────────────────────────────────────
        validated.append(step)

    return validated


def create_plan(user_input: str) -> dict:
    messages = [
        {"role": "system", "content": PLANNER_PROMPT},
        {"role": "user", "content": user_input}
    ]

    response = llm.chat(messages)
    raw = response.get("content", "")

    plan = _extract_json(raw)

    if not plan or "steps" not in plan:
        print("[Planner] ⚠ Could not parse plan, falling back to single general step")
        return {"steps": [{"task": user_input, "agent": "general", "tool": None, "args": {}}]}

    plan["steps"] = _validate_and_fix_steps(plan.get("steps", []))

    if not plan["steps"]:
        print("[Planner] ⚠ All steps dropped after validation — falling back")
        return {"steps": [{"task": user_input, "agent": "general", "tool": None, "args": {}}]}

    print(f"[Planner] ✅ Plan validated: {len(plan['steps'])} step(s)")
    return plan
