"""
llama_backend.py — LlamaCpp backend with context window management and token truncation.

Features:
- Auto-detects model context size from GGUF metadata
- Intelligent message truncation to prevent context overflow
- Token estimation for safety
- Graceful fallback on context errors
- Streaming support with truncation
"""

import multiprocessing
import os
from typing import List, Dict, Any, Optional, Generator

from llama_cpp import Llama

from logger import log

# Suppress llama.cpp debug output
os.environ["LLAMA_CPP_LOG_LEVEL"] = "ERROR"


class LlamaBackend:
    """
    LlamaCpp backend wrapper with automatic context management.

    Args:
        model_path: Path to GGUF model file
        n_ctx: Context window size (auto-detected if not provided)
        n_threads: Number of CPU threads (default: all cores)
        n_batch: Batch size for prompt processing
        use_mmap: Use memory mapping for faster loading
        verbose: Enable verbose logging
    """

    def __init__(
            self,
            model_path: str,
            n_ctx: Optional[int] = None,
            n_threads: Optional[int] = None,
            n_batch: int = 1024,
            use_mmap: bool = True,
            verbose: bool = False
    ):
        self.model_path = model_path

        # Use all CPU cores by default
        if n_threads is None:
            n_threads = multiprocessing.cpu_count()

            # FIX: Force n_ctx to 4096 if auto-detection fails
            if n_ctx is None:
                n_ctx = 4096  # ← FORCE THIS, don't rely on auto-detection

        log.info(f"Loading model from {model_path}")

        # Load model with initial settings
        # If n_ctx not provided, llama.cpp will use model's trained context
        load_params = {
            "model_path": model_path,
            "n_ctx": n_ctx,  # ← ALWAYS pass this
            "n_threads": n_threads,
            "n_batch": n_batch,
            "use_mmap": use_mmap,
            "verbose": verbose,
        }

        if n_ctx is not None:
            load_params["n_ctx"] = n_ctx

        try:
            self.llm = Llama(**load_params)
        except Exception as e:
            log.error(f"Failed to load model: {e}")
            raise

        # Get actual context size from model metadata
        # Llama.cpp stores this in context_params.n_ctx
        try:
            self.context_size = self.llm.context_params.n_ctx
        except AttributeError:
            # Fallback: estimate from model or use conservative default
            self.context_size = n_ctx or 4096
            log.warning(f"Could not detect context size, using {self.context_size}")

        # Reserve tokens for model response
        self.reserved_tokens = 512
        self.max_input_tokens = self.context_size - self.reserved_tokens

        log.info(f"Model loaded ✅")
        log.info(f"  Context window: {self.context_size} tokens")
        log.info(f"  Max input tokens: {self.max_input_tokens}")
        log.info(f"  Threads: {n_threads}")

        # Statistics for monitoring
        self.stats = {
            "total_requests": 0,
            "truncations": 0,
            "context_errors": 0,
            "total_tokens_processed": 0,
        }

    def _estimate_tokens(self, text: str) -> int:
        """
        Rough token estimation: 1 token ≈ 4 characters for English.
        This is a conservative estimate that works for most cases.
        """
        if not text:
            return 0
        # Count words for better estimation
        words = len(text.split())
        chars = len(text)
        # Average: 4 chars per token, or 0.75 tokens per word
        return max(int(chars / 4), int(words * 0.75), 1)

    def _truncate_messages(
            self,
            messages: List[Dict[str, str]],
            max_tokens: Optional[int] = None
    ) -> List[Dict[str, str]]:
        """
        Intelligently truncate messages to fit within context window.

        Strategy:
        1. Keep ALL system messages intact (they're critical)
        2. Keep most recent conversation turns
        3. Truncate individual message content if needed
        4. Never drop the current user query

        Args:
            messages: List of message dicts with 'role' and 'content'
            max_tokens: Maximum tokens allowed (default: self.max_input_tokens)

        Returns:
            Truncated message list
        """
        if not messages:
            return messages

        if max_tokens is None:
            max_tokens = self.max_input_tokens

        # Separate system messages (must keep intact)
        system_msgs = [m for m in messages if m.get("role") == "system"]
        other_msgs = [m for m in messages if m.get("role") != "system"]

        # Estimate total tokens
        total_text = " ".join([m.get("content", "") for m in messages])
        estimated_tokens = self._estimate_tokens(total_text)

        if estimated_tokens <= max_tokens:
            return messages

        self.stats["truncations"] += 1
        log.warning(f"[LLM] Truncating messages: ~{estimated_tokens} → {max_tokens} tokens")

        # Calculate tokens used by system messages
        system_tokens = sum(self._estimate_tokens(m.get("content", "")) for m in system_msgs)
        remaining_tokens = max_tokens - system_tokens

        truncated = system_msgs.copy()

        # Process messages from newest to oldest
        # The last message is usually the current user query — MUST keep
        if other_msgs:
            last_msg = other_msgs[-1]
            last_msg_tokens = self._estimate_tokens(last_msg.get("content", ""))

            if remaining_tokens >= last_msg_tokens:
                # Can fit the last message completely
                truncated.append(last_msg)
                remaining_tokens -= last_msg_tokens
                other_msgs = other_msgs[:-1]
            else:
                # Last message is too large — truncate its content
                content = last_msg.get("content", "")
                max_chars = remaining_tokens * 4  # Convert tokens to chars
                if max_chars > 50:  # Keep if at least 50 chars meaningful
                    truncated_content = content[:max_chars] + "... [truncated]"
                    truncated.append({
                        "role": last_msg.get("role", "user"),
                        "content": truncated_content
                    })
                    log.warning(f"[LLM] Truncated last message from {len(content)} to {len(truncated_content)} chars")
                remaining_tokens = 0

        # Add older messages if space permits (newest first)
        for msg in reversed(other_msgs):
            if remaining_tokens <= 0:
                break

            msg_tokens = self._estimate_tokens(msg.get("content", ""))
            if remaining_tokens >= msg_tokens:
                truncated.insert(len(system_msgs), msg)
                remaining_tokens -= msg_tokens
            else:
                # Try to truncate this message
                content = msg.get("content", "")
                max_chars = remaining_tokens * 4
                if max_chars > 50:
                    msg["content"] = content[:max_chars] + "... [truncated]"
                    truncated.insert(len(system_msgs), msg)
                break

        log.debug(f"[LLM] Kept {len(truncated)}/{len(messages)} messages after truncation")
        return truncated

    def chat(
            self,
            messages: List[Dict[str, str]],
            tools: Optional[List[Dict]] = None,
            temperature: float = 0.7,
            max_tokens: int = 512,
            max_retries: int = 2
    ) -> Dict[str, Any]:
        """
        Standard blocking chat — returns full response with automatic truncation.

        Args:
            messages: List of message dicts with 'role' and 'content'
            tools: Optional tool definitions for function calling
            temperature: Sampling temperature (0.0 - 1.0)
            max_tokens: Maximum tokens in response
            max_retries: Number of retries on context errors

        Returns:
            Response message dict with 'role' and 'content'
        """
        self.stats["total_requests"] += 1

        # Try with progressively aggressive truncation
        for attempt in range(max_retries):
            try:
                # Calculate max input tokens based on attempt
                input_limit = self.max_input_tokens
                if attempt == 1:
                    input_limit = int(self.context_size * 0.6)  # 60% on first retry
                elif attempt >= 2:
                    input_limit = int(self.context_size * 0.4)  # 40% on second retry

                safe_messages = self._truncate_messages(messages, max_tokens=input_limit)

                # Estimate tokens for logging
                total_text = " ".join([m.get("content", "") for m in safe_messages])
                estimated_tokens = self._estimate_tokens(total_text)
                self.stats["total_tokens_processed"] += estimated_tokens

                log.debug(f"[LLM] Sending ~{estimated_tokens} tokens (limit: {input_limit})")

                response = self.llm.create_chat_completion(
                    messages=safe_messages,
                    tools=tools,
                    max_tokens=max_tokens,
                    temperature=temperature,
                )

                return response["choices"][0]["message"]

            except Exception as e:
                error_msg = str(e).lower()

                # Check if it's a context overflow error
                if "exceed context window" in error_msg or "context" in error_msg:
                    self.stats["context_errors"] += 1

                    if attempt < max_retries - 1:
                        log.warning(f"[LLM] Context overflow, retrying with smaller input (attempt {attempt + 1})")
                        continue
                    else:
                        log.error(f"[LLM] Context overflow even after {max_retries} retries")
                        # Return error message as response
                        return {
                            "role": "assistant",
                            "content": "I'm sorry, the conversation is too long for me to process. Please try a shorter query."
                        }
                else:
                    # Other error — don't retry
                    log.error(f"[LLM] Chat error: {e}")
                    raise

        # Should never reach here
        return {"role": "assistant", "content": "An unexpected error occurred."}

    def stream_chat(
            self,
            messages: List[Dict[str, str]],
            temperature: float = 0.7,
            max_tokens: int = 512
    ) -> Generator[str, None, None]:
        """
        Streaming chat — yields text tokens one by one as they are generated.

        Use this for real-time terminal output or SSE streaming in FastAPI.

        Args:
            messages: List of message dicts with 'role' and 'content'
            temperature: Sampling temperature (0.0 - 1.0)
            max_tokens: Maximum tokens in response

        Yields:
            String tokens as they are generated
        """
        self.stats["total_requests"] += 1

        try:
            safe_messages = self._truncate_messages(messages, max_tokens=self.max_input_tokens)

            # Estimate tokens for logging
            total_text = " ".join([m.get("content", "") for m in safe_messages])
            estimated_tokens = self._estimate_tokens(total_text)
            self.stats["total_tokens_processed"] += estimated_tokens

            log.debug(f"[LLM] Streaming ~{estimated_tokens} input tokens")

            stream = self.llm.create_chat_completion(
                messages=safe_messages,
                stream=True,
                max_tokens=max_tokens,
                temperature=temperature,
            )

            for chunk in stream:
                delta = chunk["choices"][0].get("delta", {})
                token = delta.get("content")
                if token:
                    yield token

        except Exception as e:
            error_msg = str(e).lower()
            if "exceed context window" in error_msg or "context" in error_msg:
                self.stats["context_errors"] += 1
                log.error(f"[LLM] Context overflow in stream")
                yield "I'm sorry, the conversation is too long. Please try a shorter query."
            else:
                log.error(f"[LLM] Stream error: {e}")
                yield f"Error: {str(e)[:100]}"

    def get_stats(self) -> Dict[str, Any]:
        """Get backend statistics for monitoring."""
        return {
            **self.stats,
            "context_size": self.context_size,
            "max_input_tokens": self.max_input_tokens,
            "model_path": self.model_path,
        }

    def reset_stats(self) -> None:
        """Reset usage statistics."""
        self.stats = {
            "total_requests": 0,
            "truncations": 0,
            "context_errors": 0,
            "total_tokens_processed": 0,
        }


# ---------------------------------------------------------------------------
# Singleton instance (optional — can be created in llm.py)
# ---------------------------------------------------------------------------
_llm_instance: Optional[LlamaBackend] = None


def get_llm(model_path: Optional[str] = None) -> LlamaBackend:
    """
    Get or create the global LLM instance.

    Args:
        model_path: Path to model file (only used on first call)

    Returns:
        LlamaBackend singleton instance
    """
    global _llm_instance

    if _llm_instance is None:
        if model_path is None:
            model_path = os.getenv("MODEL_PATH", "models/qwen_q4.gguf")
        _llm_instance = LlamaBackend(model_path)

    return _llm_instance
