"""
evaluator.py — Evaluates agent answers with confidence scoring.

Returns structured JSON:
{
  "status": "COMPLETE" | "INCOMPLETE",
  "confidence": 0.0 - 1.0,
  "reason": "brief explanation"
}

Confidence thresholds used by orchestrator:
  >= 0.8  → Accept and return — high confidence, no retry needed
  >= 0.5  → Accept if last cycle — low confidence but acceptable
  <  0.5  → Retry — answer is too weak or wrong
"""

import json
import re

from llm import llm
from logger import log

EVAL_PROMPT = """
You are an evaluator that scores how well an answer satisfies a user's goal.

You are given:
- The original goal
- The final answer

Respond ONLY with a valid JSON object — no explanation, no markdown, no extra text:

{
  "status": "COMPLETE" or "INCOMPLETE",
  "confidence": <float between 0.0 and 1.0>,
  "reason": "<one sentence explanation>"
}

Confidence scoring guide:
  1.0  → Perfect answer, directly addresses the goal with full data
  0.8  → Good answer, minor gaps (e.g. delayed price, approximate data)
  0.6  → Partial answer, some information missing or vague
  0.4  → Weak answer, mostly missing or off-topic
  0.2  → Very poor answer, barely related to the goal
  0.0  → Wrong or harmful answer

Rules:
- COMPLETE only if the answer actually answers the goal with real data
- INCOMPLETE if the answer says "I don't know", "not available", or deflects
- INCOMPLETE if tool results were available but not used
- INCOMPLETE if answer is generic knowledge instead of tool-based
- Be strict — a vague answer is not COMPLETE even if it sounds confident
"""


def _parse_eval_response(raw: str) -> dict:
    """
    Parse the evaluator LLM output into a structured dict.
    Falls back gracefully if JSON parsing fails.
    """
    # Try direct JSON parse
    try:
        return json.loads(raw.strip())
    except Exception:
        pass

    # Try extracting from ```json ... ``` block
    match = re.search(r"```(?:json)?\s*(\{.*?})\s*```", raw, re.DOTALL)
    if match:
        try:
            return json.loads(match.group(1))
        except Exception:
            pass

    # Try finding first { ... } block
    match = re.search(r"(\{.*?})", raw, re.DOTALL)
    if match:
        try:
            return json.loads(match.group(1))
        except Exception:
            pass

    # Last resort — infer from text
    log.warning(f"[Evaluator] Could not parse JSON, inferring from text: {raw[:100]}")
    status = "COMPLETE" if "COMPLETE" in raw.upper() else "INCOMPLETE"
    return {
        "status": status,
        "confidence": 0.8 if status == "COMPLETE" else 0.3,
        "reason": raw[:200].strip()
    }


def evaluate(goal: str, answer: str) -> dict:
    """
    Evaluate how well the answer satisfies the goal.

    Returns:
        {
            "status": "COMPLETE" | "INCOMPLETE",
            "confidence": float (0.0 - 1.0),
            "reason": str
        }
    """
    messages = [
        {"role": "system", "content": EVAL_PROMPT},
        {"role": "user", "content": f"Goal: {goal}\n\nAnswer:\n{answer}"}
    ]

    response = llm.chat(messages)
    raw = response.get("content", "")

    result = _parse_eval_response(raw)

    # Ensure confidence is a valid float
    try:
        result["confidence"] = round(float(result.get("confidence", 0.5)), 2)
    except (ValueError, TypeError):
        result["confidence"] = 0.5

    # Ensure status is valid
    if result.get("status") not in ("COMPLETE", "INCOMPLETE"):
        result["status"] = "COMPLETE" if result["confidence"] >= 0.5 else "INCOMPLETE"

    log.info(f"[Evaluator] {result['status']} (confidence={result['confidence']}) — {result['reason']}")
    return result
