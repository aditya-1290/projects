#!/usr/bin/env python3
"""
terminal_agent.py — Professional Terminal-Based CodeBase Agent

A rich terminal interface for the AI agent with:
- Syntax highlighting for code
- Markdown rendering
- Progress spinners
- Session management
- Command history
- Tab completion
- Multi-line input support
- Color themes
- Split pane views
- Keyboard shortcuts

Run:
    python terminal_agent.py
    python terminal_agent.py --session myproject
    python terminal_agent.py --config config.json
"""

import os
import sys
import json
import time
import readline
import atexit
from pathlib import Path
from datetime import datetime
from typing import Optional, List, Dict, Any
from dataclasses import dataclass, field
from enum import Enum

# Terminal UI libraries
try:
    from rich.console import Console
    from rich.layout import Layout
    from rich.panel import Panel
    from rich.syntax import Syntax
    from rich.markdown import Markdown
    from rich.table import Table
    from rich.progress import (
        Progress, SpinnerColumn, TextColumn, BarColumn,
        TaskProgressColumn, TimeRemainingColumn
    )
    from rich.prompt import Prompt, Confirm, IntPrompt
    from rich.live import Live
    from rich.text import Text
    from rich.columns import Columns
    from rich.tree import Tree
    from rich import box
    from rich.align import Align

    RICH_AVAILABLE = True
except ImportError:
    print("⚠️ Rich library not installed. Install with: pip install rich")
    RICH_AVAILABLE = False
    Console = object

try:
    from prompt_toolkit import PromptSession
    from prompt_toolkit.history import FileHistory
    from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
    from prompt_toolkit.completion import WordCompleter
    from prompt_toolkit.styles import Style
    from prompt_toolkit.formatted_text import HTML
    from prompt_toolkit.key_binding import KeyBindings
    from prompt_toolkit.keys import Keys

    PROMPT_TOOLKIT_AVAILABLE = True
except ImportError:
    print("⚠️ prompt_toolkit not installed. Install with: pip install prompt_toolkit")
    PROMPT_TOOLKIT_AVAILABLE = False

# Agent imports
from orchestrator import run_system_with_refinement, get_or_create_session, clear_all_sessions
from cache import tool_cache
from response_cache import response_cache
from logger import log

# GitHub indexer
try:
    from github_indexer import (
        index_github_repo, search_indexed_code,
        list_github_repos, index_all_user_repos
    )

    GITHUB_AVAILABLE = True
except ImportError:
    GITHUB_AVAILABLE = False


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
@dataclass
class TerminalConfig:
    """Terminal agent configuration."""

    # Appearance
    theme: str = "dark"  # dark, light, monokai, solarized
    show_timestamps: bool = True
    show_tool_calls: bool = True
    show_progress: bool = True
    syntax_highlight: bool = True

    # Behavior
    auto_save_history: bool = True
    max_history: int = 1000
    confirm_exit: bool = False
    auto_index_github: bool = False

    # Paths
    history_file: str = "~/.agent_history"
    config_file: str = "~/.agent_config.json"
    session_dir: str = "~/.agent_sessions"

    # GitHub
    github_token: Optional[str] = None
    github_username: Optional[str] = None

    def save(self):
        """Save configuration to file."""
        config_path = Path(self.config_file).expanduser()
        config_path.parent.mkdir(parents=True, exist_ok=True)

        data = {k: v for k, v in self.__dict__.items() if not k.startswith('_')}
        data['github_token'] = '***' if data['github_token'] else None  # Don't save token

        with open(config_path, 'w') as f:
            json.dump(data, f, indent=2)

    @classmethod
    def load(cls, path: Optional[str] = None) -> 'TerminalConfig':
        """Load configuration from file."""
        config = cls()

        if path:
            config_path = Path(path)
        else:
            config_path = Path(config.config_file).expanduser()

        if config_path.exists():
            try:
                with open(config_path, 'r') as f:
                    data = json.load(f)
                for k, v in data.items():
                    if hasattr(config, k) and v != '***':
                        setattr(config, k, v)
            except Exception:
                pass

        return config


# ---------------------------------------------------------------------------
# Terminal UI Themes
# ---------------------------------------------------------------------------
class Theme(Enum):
    DARK = {
        "user": "bold cyan",
        "agent": "bold green",
        "tool": "yellow",
        "error": "bold red",
        "success": "bold green",
        "warning": "bold yellow",
        "info": "blue",
        "code": "bright_black",
        "timestamp": "dim",
        "border": "bright_black",
    }

    LIGHT = {
        "user": "bold blue",
        "agent": "bold green",
        "tool": "yellow",
        "error": "bold red",
        "success": "bold green",
        "warning": "bold yellow",
        "info": "cyan",
        "code": "bright_black",
        "timestamp": "dim",
        "border": "bright_black",
    }

    MONOKAI = {
        "user": "bold #66d9ef",
        "agent": "bold #a6e22e",
        "tool": "#e6db74",
        "error": "bold #f92672",
        "success": "bold #a6e22e",
        "warning": "bold #fd971f",
        "info": "#ae81ff",
        "code": "#75715e",
        "timestamp": "#49483e",
        "border": "#49483e",
    }


# ---------------------------------------------------------------------------
# Command System
# ---------------------------------------------------------------------------
class CommandHandler:
    """Handle slash commands in the terminal."""

    def __init__(self, terminal: 'TerminalAgent'):
        self.terminal = terminal
        self.commands = {
            '/help': self.cmd_help,
            '/clear': self.cmd_clear,
            '/history': self.cmd_history,
            '/session': self.cmd_session,
            '/cache': self.cmd_cache,
            '/tools': self.cmd_tools,
            '/github': self.cmd_github,
            '/config': self.cmd_config,
            '/theme': self.cmd_theme,
            '/export': self.cmd_export,
            '/stats': self.cmd_stats,
            '/exit': self.cmd_exit,
            '/quit': self.cmd_exit,
            '/q': self.cmd_exit,
        }

    def handle(self, user_input: str) -> bool:
        """Handle a command. Returns True if command was handled."""
        if not user_input.startswith('/'):
            return False

        parts = user_input.strip().split()
        cmd = parts[0].lower()
        args = parts[1:] if len(parts) > 1 else []

        if cmd in self.commands:
            return self.commands[cmd](args)

        self.terminal.print_error(f"Unknown command: {cmd}")
        self.terminal.print_info("Type /help for available commands")
        return True

    def cmd_help(self, args: List[str]) -> bool:
        """Show help."""
        help_text = """
╔══════════════════════════════════════════════════════════════════╗
║                         AVAILABLE COMMANDS                         ║
╠══════════════════════════════════════════════════════════════════╣
║ /help                    Show this help message                   ║
║ /clear                   Clear the screen                         ║
║ /history                 Show conversation history                ║
║ /session [new|list|switch] Manage sessions                        ║
║ /cache [stats|clear]     Manage response cache                    ║
║ /tools [list|info]       List available tools                     ║
║ /github [index|search|list] GitHub integration                    ║
║ /config [get|set]        View/change configuration                ║
║ /theme [dark|light|monokai] Change color theme                    ║
║ /export [path]           Export conversation                      ║
║ /stats                   Show session statistics                  ║
║ /exit, /quit, /q         Exit the agent                           ║
╠══════════════════════════════════════════════════════════════════╣
║ Keyboard Shortcuts:                                                ║
║   Ctrl+C      Interrupt current operation                         ║
║   Ctrl+D      Exit (on empty line)                                ║
║   Ctrl+L      Clear screen                                        ║
║   Ctrl+R      Search history                                      ║
║   Tab         Auto-complete                                       ║
║   ↑/↓         Navigate history                                    ║
║   Alt+Enter   Insert newline (multi-line mode)                    ║
╚══════════════════════════════════════════════════════════════════╝
        """
        self.terminal.console.print(help_text, style="bold blue")
        return True

    def cmd_clear(self, args: List[str]) -> bool:
        """Clear screen."""
        os.system('cls' if os.name == 'nt' else 'clear')
        self.terminal._print_banner()
        return True

    def cmd_history(self, args: List[str]) -> bool:
        """Show history."""
        history = self.terminal.conversation_history[-20:]

        table = Table(title="Conversation History", box=box.ROUNDED)
        table.add_column("#", style="dim")
        table.add_column("Time", style="cyan")
        table.add_column("Type", style="yellow")
        table.add_column("Message", style="white")

        for i, entry in enumerate(history, 1):
            table.add_row(
                str(i),
                entry.get("time", "")[:16],
                entry.get("type", ""),
                entry.get("message", "")[:50] + ("..." if len(entry.get("message", "")) > 50 else "")
            )

        self.terminal.console.print(table)
        return True

    def cmd_session(self, args: List[str]) -> bool:
        """Manage sessions."""
        if not args:
            self.terminal.print_info(f"Current session: {self.terminal.session_id[:8]}...")
            return True

        subcmd = args[0].lower()

        if subcmd == "new":
            new_id = self.terminal._create_session()
            self.terminal.print_success(f"Created new session: {new_id[:8]}...")

        elif subcmd == "list":
            # Show active sessions
            from agent_qwen import get_session_stats
            stats = get_session_stats()

            table = Table(title="Active Sessions", box=box.ROUNDED)
            table.add_column("Session ID", style="cyan")
            table.add_column("Messages", style="yellow")
            table.add_column("Created", style="dim")
            table.add_column("Last Active", style="dim")

            for sess in stats.get("sessions", []):
                table.add_row(
                    sess.get("id", "")[:12],
                    str(sess.get("messages", 0)),
                    sess.get("created", "")[:16],
                    sess.get("last_active", "")[:16],
                )

            self.terminal.console.print(table)

        return True

    def cmd_cache(self, args: List[str]) -> bool:
        """Manage cache."""
        if not args:
            stats = response_cache.stats()
            tool_stats = tool_cache.stats()

            table = Table(title="Cache Statistics", box=box.ROUNDED)
            table.add_column("Type", style="cyan")
            table.add_column("Entries", style="yellow")
            table.add_column("Hits", style="green")
            table.add_column("Misses", style="red")
            table.add_column("Hit Rate", style="bold")

            table.add_row(
                "Response",
                str(stats.get("entries", 0)),
                str(stats.get("hits", 0)),
                str(stats.get("misses", 0)),
                stats.get("hit_rate", "0%")
            )

            table.add_row(
                "Tool",
                str(tool_stats.get("entries", 0)),
                str(tool_stats.get("hits", 0)),
                str(tool_stats.get("misses", 0)),
                tool_stats.get("hit_rate", "0%")
            )

            self.terminal.console.print(table)

        elif args[0] == "clear":
            response_cache.invalidate()
            tool_cache.invalidate()
            self.terminal.print_success("Cache cleared")

        return True

    def cmd_tools(self, args: List[str]) -> bool:
        """List tools."""
        from tools import TOOL_REGISTRY

        # Group tools by category
        categories = {
            "🌤️ Weather & Time": ["get_weather", "get_current_time", "get_date_info", "get_world_clock"],
            "💰 Finance": ["get_stock_price", "get_gold_price", "convert_currency"],
            "📰 News & Search": ["get_news", "web_search", "search_timed_news", "get_entity_timeline"],
            "🧮 Utilities": ["calculate", "convert_units"],
            "💻 CodeBase": ["read_file", "write_file", "list_directory", "search_code",
                           "execute_command", "analyze_code", "git_operation"],
            "🐙 GitHub": ["index_github_repo", "search_indexed_code", "list_github_repos"],
        }

        tree = Tree("🔧 Available Tools", guide_style="bold bright_blue")

        for category, tools in categories.items():
            cat_node = tree.add(f"[bold yellow]{category}[/bold yellow]")
            for tool in tools:
                if tool in TOOL_REGISTRY:
                    cat_node.add(f"[green]✓[/green] {tool}")
                else:
                    cat_node.add(f"[dim]✗ {tool} (not loaded)[/dim]")

        self.terminal.console.print(tree)
        self.terminal.console.print(f"\n[dim]Total: {len(TOOL_REGISTRY)} tools available[/dim]")

        return True

    def cmd_github(self, args: List[str]) -> bool:
        """GitHub commands."""
        if not GITHUB_AVAILABLE:
            self.terminal.print_error("GitHub integration not available")
            return True

        if not args:
            self.terminal.print_info("Usage: /github [index|search|list|index-all]")
            return True

        subcmd = args[0].lower()

        if subcmd == "list":
            result = list_github_repos()
            if result["status"] == "success":
                for repo in result.get("repositories", []):
                    self.terminal.console.print(f"  📦 {repo['name']} - {repo['files']} files, {repo['chunks']} chunks")

        elif subcmd == "search":
            if len(args) < 2:
                self.terminal.print_error("Usage: /github search <query>")
                return True
            query = " ".join(args[1:])

            with Progress() as progress:
                task = progress.add_task("[cyan]Searching code...", total=None)
                result = search_indexed_code(query, limit=10)
                progress.update(task, completed=True)

            if result["status"] == "success":
                for r in result.get("results", []):
                    self.terminal.console.print(Panel(
                        f"[cyan]{r['file']}:{r['lines']}[/cyan]\n\n{r['content']}",
                        title=f"Relevance: {r['relevance']:.2f}",
                        border_style="green"
                    ))

        elif subcmd == "index":
            if len(args) < 2:
                self.terminal.print_error("Usage: /github index <repo_url>")
                return True

            repo_url = args[1]
            token = self.terminal.config.github_token

            with Progress() as progress:
                task = progress.add_task(f"[cyan]Indexing {repo_url}...", total=None)
                result = index_github_repo(repo_url, token)
                progress.update(task, completed=True)

            if result["status"] == "success":
                self.terminal.print_success(
                    f"Indexed {result['files_indexed']} files, {result['chunks_stored']} chunks")

        elif subcmd == "index-all":
            if not self.terminal.config.github_token or not self.terminal.config.github_username:
                self.terminal.print_error("Set github_token and github_username in config first")
                return True

            username = self.terminal.config.github_username
            token = self.terminal.config.github_token

            with Progress() as progress:
                task = progress.add_task(f"[cyan]Indexing all repos for {username}...", total=None)
                result = index_all_user_repos(username, token)
                progress.update(task, completed=True)

            if result["status"] == "success":
                self.terminal.print_success(f"Indexed {len(result['indexed'])} repositories")

        return True

    def cmd_config(self, args: List[str]) -> bool:
        """View/change config."""
        if not args:
            # Show current config
            table = Table(title="Current Configuration", box=box.ROUNDED)
            table.add_column("Setting", style="cyan")
            table.add_column("Value", style="yellow")

            for k, v in self.terminal.config.__dict__.items():
                if not k.startswith('_') and not k.endswith('token'):
                    table.add_row(k, str(v))

            self.terminal.console.print(table)

        elif args[0] == "set" and len(args) >= 3:
            key = args[1]
            value = args[2]

            if hasattr(self.terminal.config, key):
                # Convert value type
                current = getattr(self.terminal.config, key)
                if isinstance(current, bool):
                    value = value.lower() in ('true', 'yes', '1')
                elif isinstance(current, int):
                    value = int(value)

                setattr(self.terminal.config, key, value)
                self.terminal.config.save()
                self.terminal.print_success(f"Set {key} = {value}")
            else:
                self.terminal.print_error(f"Unknown config key: {key}")

        return True

    def cmd_theme(self, args: List[str]) -> bool:
        """Change theme."""
        if not args:
            self.terminal.print_info(f"Current theme: {self.terminal.config.theme}")
            return True

        theme_name = args[0].lower()
        themes = {"dark": Theme.DARK, "light": Theme.LIGHT, "monokai": Theme.MONOKAI}

        if theme_name in themes:
            self.terminal.config.theme = theme_name
            self.terminal.theme = themes[theme_name].value
            self.terminal.config.save()
            self.terminal.print_success(f"Theme changed to {theme_name}")
        else:
            self.terminal.print_error(f"Unknown theme: {theme_name}")

        return True

    def cmd_export(self, args: List[str]) -> bool:
        """Export conversation."""
        path = args[0] if args else f"conversation_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"

        export_data = {
            "session_id": self.terminal.session_id,
            "exported_at": datetime.now().isoformat(),
            "history": self.terminal.conversation_history,
        }

        with open(path, 'w') as f:
            json.dump(export_data, f, indent=2)

        self.terminal.print_success(f"Exported to {path}")
        return True

    def cmd_stats(self, args: List[str]) -> bool:
        """Show stats."""
        from agent_qwen import get_session_stats

        stats = get_session_stats()
        cache_stats = response_cache.stats()
        tool_stats = tool_cache.stats()
        llm_stats = self.terminal._get_llm_stats()

        layout = Layout()
        layout.split_column(
            Layout(name="header", size=3),
            Layout(name="body"),
        )

        layout["header"].update(Panel("[bold]Session Statistics[/bold]", style="cyan"))

        stats_table = Table(box=box.SIMPLE)
        stats_table.add_column("Metric", style="cyan")
        stats_table.add_column("Value", style="yellow")

        stats_table.add_row("Active Sessions", str(stats.get("active_sessions", 0)))
        stats_table.add_row("Total Messages", str(stats.get("total_messages", 0)))
        stats_table.add_row("Cache Hit Rate", cache_stats.get("hit_rate", "0%"))
        stats_table.add_row("Tool Cache Hits", str(tool_stats.get("hits", 0)))
        stats_table.add_row("LLM Requests", str(llm_stats.get("total_requests", 0)))
        stats_table.add_row("Context Truncations", str(llm_stats.get("truncations", 0)))

        layout["body"].update(Panel(stats_table, title="Statistics", border_style="green"))

        self.terminal.console.print(layout)
        return True

    def cmd_exit(self, args: List[str]) -> bool:
        """Exit agent."""
        if self.terminal.config.confirm_exit:
            if Confirm.ask("Are you sure you want to exit?"):
                self.terminal.running = False
        else:
            self.terminal.running = False
        return True


# ---------------------------------------------------------------------------
# Main Terminal Agent
# ---------------------------------------------------------------------------
class TerminalAgent:
    """Professional terminal-based AI agent."""

    def __init__(self, config_path: Optional[str] = None, session_name: Optional[str] = None):
        """Initialize terminal agent."""

        # Load configuration
        self.config = TerminalConfig.load(config_path)

        # Set theme
        theme_name = self.config.theme.upper()
        self.theme = getattr(Theme, theme_name, Theme.DARK).value

        # Initialize rich console
        if RICH_AVAILABLE:
            self.console = Console()
        else:
            print("Rich not available. Install with: pip install rich")
            sys.exit(1)

        # Initialize prompt toolkit session
        if PROMPT_TOOLKIT_AVAILABLE:
            history_path = Path(self.config.history_file).expanduser()
            history_path.parent.mkdir(parents=True, exist_ok=True)

            self.prompt_session = PromptSession(
                history=FileHistory(str(history_path)),
                auto_suggest=AutoSuggestFromHistory(),
                enable_history_search=True,
            )
        else:
            self.prompt_session = None

        # Session management
        self.session_id = None
        self.session_name = session_name
        self.conversation_history = []

        # State
        self.running = True
        self.command_handler = CommandHandler(self)
        self.multi_line_mode = False
        self.multi_line_buffer = []

        # Create session
        self._create_session()

    def _create_session(self) -> str:
        """Create a new session."""
        from agent_qwen import create_session
        self.session_id = create_session()
        return self.session_id

    def _get_llm_stats(self) -> Dict:
        """Get LLM statistics."""
        try:
            from llm import llm
            return llm.get_stats()
        except:
            return {}

    def _print_banner(self):
        """Print welcome banner."""
        banner = f"""
╔══════════════════════════════════════════════════════════════════════╗
║                                                                                             ║
║   ██████╗  ██████╗ ██████╗ ███████╗██████╗  █████╗ ███████╗███████╗      ║
║   ██╔════╝ ██╔═══██╗██╔══██╗██╔════╝██╔══██╗██╔══██╗██╔════╝██╔════╝  ║
║   ██║      ██║   ██║██║  ██║█████╗  ██████╔╝███████║███████╗█████╗         ║
║   ██║      ██║   ██║██║  ██║██╔══╝  ██╔══██╗██╔══██║╚════██║██╔══╝         ║
║   ╚██████╗ ╚██████╔╝██████╔╝███████╗██████╔╝██║  ██║███████║███████╗   ║
║    ╚═════╝  ╚═════╝ ╚═════╝ ╚══════╝╚═════╝ ╚═╝  ╚═╝╚══════╝╚══════╝     ║
║                                                                                             ║
║                    AI-Powered CodeBase Assistant                                            ║
║                         Terminal Edition v2.0                                               ║
╠══════════════════════════════════════════════════════════════════════╣
║  Session: {self.session_id[:8] if self.session_id else 'new':<48}                           ║
║  Type /help for commands • Ctrl+C to interrupt • Ctrl+D to exit                             ║
╚══════════════════════════════════════════════════════════════════════╝
        """
        self.console.print(banner, style="bold cyan")

    def print_error(self, message: str):
        """Print error message."""
        self.console.print(f"❌ {message}", style=self.theme.get("error", "bold red"))

    def print_success(self, message: str):
        """Print success message."""
        self.console.print(f"✅ {message}", style=self.theme.get("success", "bold green"))

    def print_info(self, message: str):
        """Print info message."""
        self.console.print(f"ℹ️  {message}", style=self.theme.get("info", "blue"))

    def print_warning(self, message: str):
        """Print warning message."""
        self.console.print(f"⚠️  {message}", style=self.theme.get("warning", "bold yellow"))

    def _get_prompt(self) -> str:
        """Get the prompt string."""
        if self.multi_line_mode:
            return "... "
        return "You: "

    def _get_input(self) -> Optional[str]:
        """Get user input with rich prompt."""
        try:
            if PROMPT_TOOLKIT_AVAILABLE and not self.multi_line_mode:
                # Use prompt_toolkit for advanced features
                style = Style.from_dict({
                    'prompt': self.theme.get("user", "bold cyan"),
                })

                user_input = self.prompt_session.prompt(
                    HTML('<prompt>You: </prompt>'),
                    style=style,
                    multiline=False,
                )
            else:
                # Fallback to simple input
                user_input = input(self._get_prompt())

            return user_input.strip() if user_input else None

        except KeyboardInterrupt:
            return None
        except EOFError:
            return None

    def _display_response(self, response: str):
        """Display agent response with formatting."""
        # Check if response contains code blocks
        if "```" in response:
            parts = response.split("```")
            for i, part in enumerate(parts):
                if i % 2 == 0:
                    # Regular text - render as markdown
                    if part.strip():
                        md = Markdown(part.strip())
                        self.console.print(md)
                else:
                    # Code block - syntax highlight
                    lines = part.split('\n')
                    language = lines[0].strip() if lines else "python"
                    code = '\n'.join(lines[1:]) if len(lines) > 1 else part

                    if self.config.syntax_highlight and code.strip():
                        syntax = Syntax(code, language, theme="monokai", line_numbers=True)
                        self.console.print(syntax)
                    else:
                        self.console.print(Panel(code, title=language, border_style="dim"))
        else:
            # No code blocks - render as markdown
            md = Markdown(response)
            self.console.print(md)

    def _progress_callback(self, event_type: str, message: str):
        """Handle progress updates."""
        if not self.config.show_progress:
            return

        icons = {
            "thinking": "🤔",
            "searching": "🔍",
            "tool": "⚙️",
            "tool_done": "✅",
            "generating": "📝",
            "refining": "🔄",
        }

        icon = icons.get(event_type, "•")

        if self.config.show_tool_calls or event_type not in ["tool", "tool_done"]:
            self.console.print(f"  {icon} {message}", style=self.theme.get("tool", "yellow"))

    def _process_query(self, query: str) -> Optional[str]:
        """Process a user query."""

        # Add to history
        timestamp = datetime.now().strftime("%H:%M:%S")

        if self.config.show_timestamps:
            self.console.print(f"[{timestamp}] ", style=self.theme.get("timestamp", "dim"), end="")

        self.console.print(f"You: ", style=self.theme.get("user", "bold cyan"), end="")
        self.console.print(query)

        self.conversation_history.append({
            "time": timestamp,
            "type": "user",
            "message": query,
        })

        # Show thinking indicator
        with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                transient=True,
        ) as progress:
            task = progress.add_task("[cyan]Thinking...", total=None)

            try:
                # Run agent with refinement
                response = run_system_with_refinement(
                    query,
                    session_id=self.session_id,
                    progress_callback=self._progress_callback if self.config.show_progress else None
                )
            except KeyboardInterrupt:
                progress.update(task, description="[yellow]Interrupted")
                self.print_warning("Operation interrupted")
                return None
            except Exception as e:
                progress.update(task, description="[red]Error")
                self.print_error(f"Error: {e}")
                return None

        # Display response
        if response:
            if self.config.show_timestamps:
                timestamp = datetime.now().strftime("%H:%M:%S")
                self.console.print(f"[{timestamp}] ", style=self.theme.get("timestamp", "dim"), end="")

            self.console.print("Agent: ", style=self.theme.get("agent", "bold green"), end="")

            self._display_response(response)

            self.conversation_history.append({
                "time": timestamp,
                "type": "agent",
                "message": response,
            })

        return response

    def _handle_slash_command(self, user_input: str) -> bool:
        """Handle slash commands."""
        return self.command_handler.handle(user_input)

    def run(self):
        """Main loop."""
        self._print_banner()

        # Auto-index GitHub if configured
        if self.config.auto_index_github and GITHUB_AVAILABLE:
            if self.config.github_token and self.config.github_username:
                self.print_info(f"Auto-indexing GitHub repos for {self.config.github_username}...")

        while self.running:
            try:
                user_input = self._get_input()

                if user_input is None:
                    # EOF or Ctrl+D on empty line
                    if not self.multi_line_buffer:
                        self.console.print("\nGoodbye! 👋", style="bold yellow")
                        break
                    continue

                if not user_input:
                    continue

                # Handle slash commands
                if user_input.startswith('/'):
                    self._handle_slash_command(user_input)
                    continue

                # Process query
                self._process_query(user_input)
                self.console.print()  # Empty line for spacing

            except KeyboardInterrupt:
                self.console.print("\n")
                self.print_warning("Use /exit to quit")
                continue
            except Exception as e:
                self.print_error(f"Unexpected error: {e}")
                log.error(f"Terminal error: {e}")
                continue

        # Save session on exit
        if self.config.auto_save_history:
            self.console.print("[dim]Saving session...[/dim]")

        self.console.print("\n👋 Goodbye!\n", style="bold green")

    def run_once(self, query: str) -> str:
        """Run a single query and return response (for scripting)."""
        return self._process_query(query) or ""


# ---------------------------------------------------------------------------
# Entry Point
# ---------------------------------------------------------------------------
def main():
    """Main entry point."""
    import argparse

    parser = argparse.ArgumentParser(description="CodeBase Agent - Terminal Edition")
    parser.add_argument("--session", "-s", help="Session name")
    parser.add_argument("--config", "-c", help="Config file path")
    parser.add_argument("--query", "-q", help="Run single query and exit")
    parser.add_argument("--no-banner", action="store_true", help="Skip banner")

    args = parser.parse_args()

    # Initialize agent
    agent = TerminalAgent(
        config_path=args.config,
        session_name=args.session
    )

    if args.query:
        # Single query mode
        response = agent.run_once(args.query)
        print(response)
    else:
        # Interactive mode
        agent.run()


if __name__ == "__main__":
    main()