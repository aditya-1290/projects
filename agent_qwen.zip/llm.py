"""
llm.py — LLM singleton with configurable model path.
"""

import os

from llama_backend import LlamaBackend

# Configurable via environment variable
MODEL_PATH = os.getenv("MODEL_PATH", "D:/python_tasks/models/qwen_q4.gguf")

# Optional: override context size via env
N_CTX = os.getenv("N_CTX")
if N_CTX:
    N_CTX = int(N_CTX)
else:
    N_CTX = None  # Auto-detect

# 🔥 SINGLE INSTANCE
llm = LlamaBackend(
    model_path=MODEL_PATH,
    n_ctx=N_CTX,  # Auto-detect if None
)
