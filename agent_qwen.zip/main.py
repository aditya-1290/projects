from llm import llm
from logger import log
from orchestrator import run_system

if __name__ == "__main__":
    log.info("Agent started. Type 'exit' to quit.")

    try:
        while True:
            user_input = input("\nYou: ").strip()

            if not user_input:
                continue

            if user_input.lower() == "exit":
                log.info("Shutting down.")
                break

            if user_input.lower() == "stats":
                stats = llm.get_stats()
                print(f"\n📊 LLM Statistics:")
                print(f"  Total requests: {stats['total_requests']}")
                print(f"  Truncations: {stats['truncations']}")
                print(f"  Context errors: {stats['context_errors']}")
                print(f"  Tokens processed: {stats['total_tokens_processed']}")
                continue

            answer = run_system(user_input)
            print(f"\nAgent: {answer}")

    except KeyboardInterrupt:
        log.info("Interrupted by user")
    finally:
        stats = llm.get_stats()
        log.info(f"Session stats: {stats['total_requests']} requests, {stats['truncations']} truncations")
