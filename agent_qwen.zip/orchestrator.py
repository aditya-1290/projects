"""
orchestrator.py — Pure ReAct agent orchestrator (Planner REMOVED).

Phase 2: Pure ReAct loop — Think → Act → Observe → Repeat
Phase 3: Session isolation for multi-user deployment
Phase 4: Failure memory integration

Pipeline:
  classify()
    ├─ conversational  → run_agent() directly
    ├─ simple_tool     → fast single-step ReAct
    └─ complex         → full multi-cycle ReAct loop
"""

import json
import re
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Dict, Tuple
from typing import Optional, Callable

from agent_qwen import run_agent, stream_agent
from cache import tool_cache
from classifier import classify, QueryClass
from evaluator import evaluate
from logger import log
# Import memory functions
from memory_store import (
    store_tool_memory,
    should_avoid_tool,
)
from response_cache import response_cache
from tools import TOOL_REGISTRY

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
NO_ARG_TOOLS = {"get_gold_price"}
CONFIDENCE_THRESHOLD = 0.6
TOOL_RETRY_COUNT = 2
TOOL_TIMEOUT = 15
MAX_REACT_CYCLES = 5  # Maximum ReAct cycles before forcing answer
MAX_PROMPT_CHARS = 8000  # Token safety limit


# ---------------------------------------------------------------------------
# Progress Tracking for Streaming Updates
# ---------------------------------------------------------------------------

class ProgressTracker:
    """Track and stream progress updates to users."""

    def __init__(self, callback: Optional[Callable[[str, str], None]] = None):
        self.callback = callback
        self.current_step = 0
        self.total_steps = 0

    def thinking(self, message: str = "Analyzing query..."):
        """Agent is thinking about what to do."""
        if self.callback:
            self.callback("thinking", message)
        log.debug(f"[Progress] 🤔 {message}")

    def searching(self, query: str):
        """Searching for information."""
        if self.callback:
            self.callback("searching", f"🔍 Searching: {query}")
        log.info(f"[Progress] 🔍 Searching: {query}")

    def executing_tool(self, tool_name: str, args: dict):
        """Executing a tool."""
        msg = f"⚙️ Running {tool_name}..."
        if self.callback:
            self.callback("tool", msg)
        log.info(f"[Progress] {msg}")

    def tool_complete(self, tool_name: str, success: bool):
        """Tool execution complete."""
        status = "✅" if success else "❌"
        msg = f"{status} {tool_name} complete"
        if self.callback:
            self.callback("tool_done", msg)
        log.info(f"[Progress] {msg}")

    def generating_answer(self):
        """Generating final answer."""
        if self.callback:
            self.callback("generating", "📝 Writing response...")
        log.debug("[Progress] 📝 Generating answer...")

    def refining_query(self, original: str, refined: str):
        """Refining query for better results."""
        if self.callback:
            self.callback("refining", f"🔄 Refining query for better results...")
        log.info(f"[Progress] 🔄 Refining query")


# ---------------------------------------------------------------------------
# Variable Resolution for Tool Chaining
# ---------------------------------------------------------------------------
def _resolve_variables(args: Dict, state: Dict) -> Dict:
    """Resolve variables like {tool_result.field} from state."""

    def resolve(val):
        if not isinstance(val, str):
            return val

        # Pattern: {tool_result.field} or tool_result.field
        pattern = r"\{?(\w+_result)\.(\w+)\}?"
        matches = re.findall(pattern, val)

        for tool_key, field in matches:
            if tool_key in state:
                result_data = state[tool_key]
                if isinstance(result_data, dict):
                    replacement = result_data.get(field)
                    if replacement is not None:
                        val = val.replace(f"{{{tool_key}.{field}}}", str(replacement))
                        val = val.replace(f"{tool_key}.{field}", str(replacement))

        return val

    return {k: resolve(v) for k, v in args.items()}


# ---------------------------------------------------------------------------
# Tool Result Compression (Prevent Token Overflow)
# ---------------------------------------------------------------------------
def _compress_tool_results(tool_results: List[Dict]) -> List[Dict]:
    """Compress tool results for ReAct prompt."""
    compressed = []

    for tr in tool_results[-3:]:  # Keep last 3 results
        tool = tr.get("tool")
        result = tr.get("result", {})

        simplified = {"tool": tool}

        # Essential fields per tool
        essential = {
            "get_weather": ["temperature", "city", "humidity", "feels_like"],
            "get_stock_price": ["ticker", "price", "currency"],
            "get_gold_price": ["price_per_troy_oz"],
            "convert_currency": ["converted_amount", "from", "to"],
            "calculate": ["result"],
            "web_search": ["count", "query"],
            "get_news": ["article_count", "topic"],
            "convert_units": ["formatted", "to"],
            "get_current_time": ["datetime", "city"],
            "get_date_info": ["date", "city"],
        }

        fields = essential.get(tool, [])
        for key in fields:
            if key in result:
                simplified[key] = result[key]

        # Special handling for articles
        if "articles" in result and result["articles"]:
            simplified["articles"] = [
                {"title": a.get("title", "")[:80]}
                for a in result["articles"][:2]
            ]

        # Special handling for web search
        if "results" in result and result["results"]:
            simplified["results"] = [
                {"title": r.get("title", "")[:60]}
                for r in result["results"][:3]
            ]

        compressed.append(simplified)

    return compressed


# ---------------------------------------------------------------------------
# ReAct Thinking Step
# ---------------------------------------------------------------------------
def _think_step(
        user_input: str,
        tool_results: List[Dict],
        history: List[str],
        last_tool: Optional[str] = None,
        available_tools: Optional[List[str]] = None
) -> Dict:
    """
    ReAct reasoning step — decides next action or final answer.
    """
    compressed_results = _compress_tool_results(tool_results)

    # Build tool list
    if available_tools is None:
        available_tools = list(TOOL_REGISTRY.keys())

    tools_desc = "\n".join([
        f"- {t}" for t in available_tools
    ])

    prompt = f"""You are an AI agent that uses tools to answer queries.

USER QUERY: {user_input}

OBSERVED DATA (use this!):
{json.dumps(compressed_results, indent=2)}

PREVIOUS THOUGHTS:
{history[-3:] if history else 'None'}

AVAILABLE TOOLS:
{tools_desc}

LAST TOOL USED: {last_tool or 'none'}

RULES:
1. If you have enough data → return "final" answer
2. If you need data → return "action" with ONE tool
3. NEVER call the same tool twice in a row
4. Use web_search for definitions, comparisons, general knowledge
5. Use calculate for math, convert_units for unit conversion

OUTPUT (JSON only):
{{"thought": "...", "action": {{"tool": "...", "args": {{...}}}} or null, "final": "..." or null}}"""

    # Truncate if needed
    if len(prompt) > MAX_PROMPT_CHARS:
        prompt = prompt[:MAX_PROMPT_CHARS] + "\n[TRUNCATED]"

    # Prevent tool repetition
    if last_tool:
        prompt += f"\n\n⚠️ Do NOT use '{last_tool}' again. Try a different approach."

    response = run_agent(prompt)

    try:
        # Extract JSON
        json_match = re.search(r'\{.*\}', response, re.DOTALL)
        if json_match:
            result = json.loads(json_match.group())

            # Guard against tool repetition
            if result.get("action") and result["action"].get("tool") == last_tool:
                log.warning(f"[ReAct] Blocked repeat of '{last_tool}'")
                return {
                    "thought": f"Cannot repeat {last_tool}",
                    "action": None,
                    "final": None
                }

            return result
    except Exception as e:
        log.error(f"[ReAct] Parse error: {e}")

    return {"thought": "Error parsing", "action": None, "final": None}


# ---------------------------------------------------------------------------
# Tool Execution with Retry and Memory
# ---------------------------------------------------------------------------
def _call_tool_with_retry(
        tool_name: str,
        args: Dict,
        query_context: str = ""
) -> Dict:
    """Call tool with retries and memory integration."""
    last_result = {"status": "error", "message": "Tool never executed"}
    start_time = time.time()

    # Check if we should avoid this tool based on past failures
    if query_context:
        avoid, reason = should_avoid_tool(tool_name, query_context)
        if avoid:
            log.warning(f"[Tool] Avoiding '{tool_name}': {reason}")
            return {"status": "error", "message": reason}

    for attempt in range(1, TOOL_RETRY_COUNT + 1):
        try:
            log.info(f"[Tool] {tool_name}({args}) — attempt {attempt}/{TOOL_RETRY_COUNT}")
            result = TOOL_REGISTRY[tool_name](**args)

            latency = round((time.time() - start_time) * 1000, 0)
            log.info(f"[Tool] {tool_name} completed in {latency}ms")

            # Store in memory (success or failure)
            store_tool_memory(tool_name, args, result)

            if result.get("status") == "success":
                return result

            last_result = result
            if attempt < TOOL_RETRY_COUNT:
                wait = attempt
                log.warning(f"[Tool] '{tool_name}' failed — retrying in {wait}s")
                time.sleep(wait)

        except Exception as e:
            last_result = {"status": "error", "message": str(e)}
            log.error(f"[Tool] '{tool_name}' exception: {e}")
            store_tool_memory(tool_name, args, last_result)
            if attempt < TOOL_RETRY_COUNT:
                time.sleep(attempt)

    log.error(f"[Tool] '{tool_name}' failed after {TOOL_RETRY_COUNT} attempts")
    return last_result


# ---------------------------------------------------------------------------
# Parallel Tool Execution (for multiple tools at once)
# ---------------------------------------------------------------------------
def _execute_tools_parallel(
        actions: List[Dict],
        query_context: str = ""
) -> List[Dict]:
    """Execute multiple tools in parallel."""
    results = []

    with ThreadPoolExecutor(max_workers=min(len(actions), 5)) as executor:
        futures = {}
        for action in actions:
            tool_name = action.get("tool")
            args = action.get("args", {})
            if tool_name in TOOL_REGISTRY:
                future = executor.submit(_call_tool_with_retry, tool_name, args, query_context)
                futures[future] = {"tool": tool_name, "args": args}

        for future in as_completed(futures):
            info = futures[future]
            try:
                result = future.result()
                results.append({
                    "tool": info["tool"],
                    "args": info["args"],
                    "result": result
                })
            except Exception as e:
                log.error(f"[Parallel] {info['tool']} failed: {e}")
                results.append({
                    "tool": info["tool"],
                    "args": info["args"],
                    "result": {"status": "error", "message": str(e)}
                })

    return results


# ---------------------------------------------------------------------------
# Build Tool Results for Summarization
# ---------------------------------------------------------------------------
def _build_tool_results(react_results: List[Dict]) -> List[Dict]:
    """Build structured tool results for final summarization."""
    tool_results = []

    for tr in react_results:
        result = tr.get("result", {})

        if result.get("status") == "success":
            # Filter news by relevance
            if tr.get("tool") == "get_news" and "articles" in result:
                task = tr.get("task", "").lower()
                keywords = [w for w in task.split() if len(w) > 3]

                if keywords:
                    filtered = []
                    for a in result.get("articles", []):
                        title = (a.get("title") or "").lower()
                        desc = (a.get("description") or "").lower()
                        text = title + " " + desc
                        if any(kw in text for kw in keywords):
                            filtered.append(a)

                    if filtered:
                        result = {**result, "articles": filtered}

            tool_results.append({
                "tool": tr["tool"],
                "task": tr.get("task", "Tool execution"),
                "result": result,
            })

    return tool_results


# ---------------------------------------------------------------------------
# Final Summarization
# ---------------------------------------------------------------------------
def _summarise(original_input: str, tool_results: List[Dict]) -> str:
    """Generate final answer using tool results."""
    if not tool_results:
        return "I couldn't retrieve the data. Please try rephrasing your query."

    prompt = f"""Answer using ONLY the tool results.

User Question: {original_input}

INSTRUCTIONS:
- Use ONLY data from tool results
- Write naturally in full sentences
- If no relevant data → say "No relevant data found"
- Do NOT add outside knowledge

Answer:"""

    return run_agent(prompt, tool_results=tool_results)


# ---------------------------------------------------------------------------
# Fast Path: Simple Tool (Single Step)
# ---------------------------------------------------------------------------
def _run_simple_react(
        user_input: str,
        plan: Dict,
        session_id: Optional[str] = None
) -> Optional[str]:
    """Fast path for simple single-tool queries."""
    steps = plan.get("steps", [])
    if not steps:
        return None

    log.info("[Orchestrator] ⚡ Fast path — single tool")

    step = steps[0]
    tool_name = step.get("tool")
    args = step.get("args", {})
    task = step.get("task", user_input)

    if tool_name not in TOOL_REGISTRY:
        return None

    # Check cache
    cached = tool_cache.get(tool_name, args)
    if cached:
        result = cached
        from_cache = True
    else:
        result = _call_tool_with_retry(tool_name, args, user_input)
        from_cache = False
        if result.get("status") == "success":
            tool_cache.set(tool_name, args, result)

    if result.get("status") != "success":
        log.warning(f"[Fast Path] Tool failed: {tool_name}")
        return None

    tool_results = [{
        "tool": tool_name,
        "task": task,
        "result": result,
        "cached": from_cache,
    }]

    answer = _summarise(user_input, tool_results)
    log.info("[Orchestrator] ✅ Fast path complete")
    return answer


# ---------------------------------------------------------------------------
# Full ReAct Loop (Complex Queries)
# ---------------------------------------------------------------------------
def _run_react_loop(
        user_input: str,
        session_id: Optional[str] = None,
        progress: Optional[ProgressTracker] = None
) -> str:
    """Full multi-cycle ReAct loop with progress tracking."""

    if progress is None:
        progress = ProgressTracker()

    progress.thinking("Starting ReAct reasoning...")

    tool_results_history = []
    thought_history = []
    state = {}
    last_tool = None
    final_answer = ""

    for cycle in range(MAX_REACT_CYCLES):
        log.info(f"[ReAct] Cycle {cycle + 1}/{MAX_REACT_CYCLES}")

        if cycle == 0:
            progress.thinking("Planning first step...")
        else:
            progress.thinking(f"Step {cycle + 1} of {MAX_REACT_CYCLES}...")

        # Think step - pass available tools
        thought = _think_step(
            user_input,
            tool_results_history,
            thought_history,
            last_tool,
            available_tools=list(TOOL_REGISTRY.keys())  # Pass tool list
        )

        thought_text = thought.get("thought", "")
        if thought_text:
            thought_history.append(thought_text)
            log.info(f"[ReAct] Thought: {thought_text[:100]}...")

        # Check for final answer
        if thought.get("final"):
            # Guard: don't allow final before any tool use for tool-requiring queries
            if not tool_results_history and not _is_conversational(user_input):
                log.warning("[ReAct] Premature final — forcing tool usage")
                # Force it to think again with a nudge
                continue
            else:
                final_answer = thought["final"]
                progress.generating_answer()
                log.info("[ReAct] Final answer reached")
                break

        # Execute action
        action = thought.get("action")
        if action:
            tool_name = action.get("tool")
            args = action.get("args", {})

            if not tool_name:
                log.warning("[ReAct] Action missing tool name")
                continue

            progress.executing_tool(tool_name, args)

            # Resolve variables from state
            args = _resolve_variables(args, state)

            if tool_name in TOOL_REGISTRY:
                # Prevent repetition
                if tool_name == last_tool and tool_results_history:
                    log.warning(f"[ReAct] Skipping repeat of {tool_name}")
                    # Force exit if stuck repeating
                    if len(tool_results_history) >= 2:
                        break
                    continue

                last_tool = tool_name

                # Check cache first
                cached = tool_cache.get(tool_name, args)
                if cached:
                    result = cached
                    log.info(f"[ReAct] Cache hit for {tool_name}")
                    progress.tool_complete(tool_name, True)
                else:
                    result = _call_tool_with_retry(tool_name, args, user_input)
                    if result.get("status") == "success":
                        tool_cache.set(tool_name, args, result)
                    progress.tool_complete(tool_name, result.get("status") == "success")

                tool_results_history.append({
                    "tool": tool_name,
                    "task": f"ReAct step: {tool_name}",
                    "result": result
                })

                if result.get("status") == "success":
                    state[f"{tool_name}_result"] = result

                    # Store in memory
                    from memory_store import store_tool_memory
                    store_tool_memory(tool_name, args, result)
            else:
                log.error(f"[ReAct] Unknown tool: {tool_name}")
        else:
            # No action and no final
            if tool_results_history:
                # We have results but no decision - force summarization
                log.info("[ReAct] No action/final but have results — summarizing")
                break
            else:
                log.warning("[ReAct] No action or final — continuing")
                continue

    # Generate final answer if ReAct didn't produce one
    if not final_answer and tool_results_history:
        progress.generating_answer()
        tool_results = _build_tool_results(tool_results_history)
        final_answer = _summarise(user_input, tool_results)
    elif not final_answer:
        final_answer = "I couldn't retrieve enough information to answer this query. Please try rephrasing."

    return final_answer


def _is_conversational(user_input: str) -> bool:
    """Quick check if query is purely conversational."""
    conversational_patterns = [
        r"\b(hi|hello|hey|howdy)\b",
        r"\b(how are you|what's up)\b",
        r"\b(thank|thanks)\b",
        r"\b(bye|goodbye)\b",
        r"\b(who are you|what are you)\b",
    ]
    import re
    user_lower = user_input.lower()
    return any(re.search(p, user_lower) for p in conversational_patterns)


def _needs_calculation(user_input: str, tool_results: List[Dict]) -> bool:
    """Check if calculation is needed."""
    calc_keywords = ["multiply", "divide", "add", "subtract", "calculate", "percent", "%"]
    user_lower = user_input.lower()
    has_calc_keyword = any(kw in user_lower for kw in calc_keywords)
    has_calculated = any(tr.get("tool") == "calculate" for tr in tool_results)
    return has_calc_keyword and not has_calculated


def _auto_calculate(result: Dict, tool_results: List[Dict]) -> Optional[Dict]:
    """Auto-trigger calculation if needed."""
    # Extract numeric values
    numeric_values = []
    for key, value in result.items():
        if isinstance(value, (int, float)):
            numeric_values.append(value)
        elif isinstance(value, str):
            import re
            match = re.search(r'[\d.]+', value)
            if match:
                numeric_values.append(float(match.group()))

    if numeric_values:
        num = numeric_values[0]
        expr = f"{num} * 2"  # Default, can be enhanced
        log.info(f"[Auto Calc] Using {expr}")
        return _call_tool_with_retry("calculate", {"expression": expr})

    return None

# ---------------------------------------------------------------------------
# Parallel Tool Execution with Web Search Comparison
# ---------------------------------------------------------------------------

def _execute_tools_with_comparison(
        primary_action: Dict,
        query_context: str,
        state: Dict
) -> Tuple[Dict, Optional[Dict]]:
    """
    Execute primary tool AND parallel web search for comparison.

    Returns:
        (primary_result, comparison_result)
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed

    primary_tool = primary_action.get("tool")
    primary_args = primary_action.get("args", {})

    # Resolve variables
    primary_args = _resolve_variables(primary_args, state)

    # Create comparison web search query
    comparison_query = _generate_comparison_query(query_context, primary_tool, primary_args)

    results = {}

    with ThreadPoolExecutor(max_workers=2) as executor:
        futures = {}

        # Submit primary tool
        if primary_tool in TOOL_REGISTRY:
            future = executor.submit(_call_tool_with_retry, primary_tool, primary_args, query_context)
            futures[future] = "primary"

        # Submit comparison web search
        if comparison_query:
            future = executor.submit(
                web_search,
                comparison_query,
                num_results=3,
                time_filter='m' if 'recent' in query_context.lower() else None
            )
            futures[future] = "comparison"

        # Collect results
        for future in as_completed(futures):
            task_type = futures[future]
            try:
                result = future.result(timeout=30)
                results[task_type] = result
            except Exception as e:
                log.error(f"[Parallel] {task_type} failed: {e}")
                results[task_type] = {"status": "error", "message": str(e)}

    primary_result = results.get("primary", {"status": "error", "message": "Tool execution failed"})
    comparison_result = results.get("comparison")

    return primary_result, comparison_result


def _generate_comparison_query(query: str, tool_name: str, args: Dict) -> str:
    """Generate a web search query for comparison."""

    query_templates = {
        "get_weather": lambda a: f"current weather {a.get('city', '')} temperature forecast",
        "get_stock_price": lambda a: f"{a.get('ticker', '')} stock price today analysis",
        "get_gold_price": lambda a: "gold price today per ounce market update",
        "get_news": lambda a: f"{a.get('topic', 'technology')} news latest headlines",
        "convert_currency": lambda a: f"{a.get('from_currency', 'USD')} to {a.get('to_currency', 'INR')} exchange rate",
        "get_current_time": lambda a: f"current time in {a.get('city', '')} timezone",
    }

    if tool_name in query_templates:
        return query_templates[tool_name](args)

    # Default: use original query with context
    return f"{query} latest information"


def _merge_comparison_results(primary_result: Dict, comparison_result: Optional[Dict]) -> Dict:
    """Merge and compare results from primary tool and web search."""

    merged = {
        "primary_source": "tool",
        "primary_result": primary_result,
        "comparison_available": comparison_result is not None,
    }

    if comparison_result and comparison_result.get("status") == "success":
        merged["comparison_source"] = "web_search"
        merged["comparison_result"] = comparison_result

        # Add comparison note
        web_results = comparison_result.get("results", [])
        if web_results:
            merged["comparison_note"] = f"Web search found {len(web_results)} additional sources for verification."

    return merged

# ---------------------------------------------------------------------------
# Query Refinement
# ---------------------------------------------------------------------------

def _refine_query(original_query: str, evaluator_feedback: str) -> str:
    """Refine a query based on evaluator feedback."""

    refinement_prompt = f"""You are a query refinement assistant.

Original query: {original_query}

Evaluator feedback: {evaluator_feedback}

Please rewrite the query to be more specific and likely to yield better results.
Focus on:
- Adding time constraints if missing
- Being more specific about what information is needed
- Including relevant keywords for better search results

Return ONLY the refined query, no explanation.

Refined query:"""

    # Use run_agent directly without tool_results
    from agent_qwen import run_agent
    refined = run_agent(refinement_prompt)
    return refined.strip()


def run_system_with_refinement(
        user_input: str,
        session_id: Optional[str] = None,
        max_refinements: int = 2,
        progress_callback: Optional[Callable[[str, str], None]] = None
) -> str:
    """
    Run system with automatic query refinement on low confidence.
    """
    progress = ProgressTracker(progress_callback)

    # Check response cache first
    cached_response = response_cache.get(user_input)
    if cached_response:
        log.info(f"[Cache] Response cache HIT for: {user_input[:50]}...")
        return cached_response

    current_query = user_input
    refinement_count = 0
    last_answer = ""

    while refinement_count <= max_refinements:
        # Run the system
        progress.thinking(f"Processing: {current_query[:50]}...")

        answer = run_system(current_query, session_id)
        last_answer = answer

        # Evaluate
        eval_result = evaluate(user_input, answer)  # Always evaluate against original
        confidence = eval_result.get("confidence", 0.0)
        status = eval_result.get("status", "INCOMPLETE")
        reason = eval_result.get("reason", "")

        log.info(f"[Refinement] Cycle {refinement_count}: confidence={confidence}, status={status}")

        # Check if answer is good enough
        if confidence >= 0.7 and status == "COMPLETE":
            log.info(f"[Refinement] ✅ Good answer (confidence={confidence})")
            response_cache.set(user_input, answer)
            return answer

        # Check if we should refine
        if refinement_count < max_refinements and confidence < 0.7:
            progress.refining_query(current_query, "")

            refined_query = _refine_query(
                current_query,
                f"Confidence: {confidence}, Reason: {reason}"
            )

            log.info(f"[Refinement] Refined query: {refined_query[:100]}...")
            current_query = refined_query
            refinement_count += 1
        else:
            # Max refinements reached
            log.info(f"[Refinement] Stopping after {refinement_count} refinements")
            if confidence >= 0.5:
                response_cache.set(user_input, answer)
            return answer

    return last_answer


# ---------------------------------------------------------------------------
# Main Entry Point
# ---------------------------------------------------------------------------

def run_system(user_input: str, session_id: Optional[str] = None) -> str:
    """
    Main orchestrator entry point with session isolation.

    Args:
        user_input: The user's query
        session_id: Optional session ID for conversation continuity.
                   If None, creates a new session for this request.

    Returns:
        Agent's response
    """
    # Create session if not provided
    if session_id is None:
        from agent_qwen import create_session
        session_id = create_session()
        log.debug(f"[Orchestrator] Created session {session_id[:8]}...")

    # Classify the query
    classification = classify(user_input)
    query_type = classification["type"]
    log.info(f"[Classifier] Query type: {query_type.upper()} (session: {session_id[:8]}...)")

    # ── Conversational → Direct to agent ────────────────────────────────
    if query_type == QueryClass.CONVERSATIONAL:
        log.info("[Orchestrator] 💬 Conversational — direct to run_agent")
        return run_agent(user_input, session_id=session_id)

    # ── Simple Tool → Fast path ─────────────────────────────────────────
    if query_type == QueryClass.SIMPLE_TOOL:
        answer = _run_simple_react(user_input, classification.get("plan", {}), session_id)
        if answer is not None:
            # Log cache stats periodically
            stats = tool_cache.stats()
            log.debug(f"[Cache] Stats — hits={stats['hits']} misses={stats['misses']} rate={stats['hit_rate']}")
            return answer
        log.info("[Orchestrator] Fast path failed — falling through to full ReAct")

    # ── Complex → Full ReAct loop ───────────────────────────────────────
    final_answer = _run_react_loop(user_input, session_id)

    # Final cache stats
    stats = tool_cache.stats()
    log.info(f"[Cache] Final stats — {stats['hits']} hits / {stats['misses']} misses / {stats['hit_rate']} hit rate")

    # Clean up stale sessions periodically (every ~100 requests)
    if stats['hits'] + stats['misses'] % 100 == 0:
        from agent_qwen import cleanup_stale_sessions
        cleanup_stale_sessions(max_age_hours=24)

    return final_answer if final_answer else "Sorry, I couldn't complete the task. Please try rephrasing your query."


def run_system_stream(user_input: str, session_id: Optional[str] = None):
    """
    Streaming version of run_system — yields tokens as they're generated.

    Note: Complex ReAct queries will still be blocking internally,
    but the final answer is streamed.
    """
    if session_id is None:
        from agent_qwen import create_session
        session_id = create_session()

    classification = classify(user_input)
    query_type = classification["type"]

    # For conversational and simple queries, we can truly stream
    if query_type == QueryClass.CONVERSATIONAL:
        for token in stream_agent(user_input, session_id=session_id):
            yield token
        return

    if query_type == QueryClass.SIMPLE_TOOL:
        plan = classification.get("plan", {})
        steps = plan.get("steps", [])
        if steps:
            step = steps[0]
            tool_name = step.get("tool")
            args = step.get("args", {})

            if tool_name in TOOL_REGISTRY:
                cached = tool_cache.get(tool_name, args)
                if cached:
                    result = cached
                else:
                    result = _call_tool_with_retry(tool_name, args, user_input)
                    if result.get("status") == "success":
                        tool_cache.set(tool_name, args, result)

                if result.get("status") == "success":
                    tool_results = [{
                        "tool": tool_name,
                        "task": step.get("task", user_input),
                        "result": result,
                    }]

                    prompt = f"""Answer using ONLY the tool results.

                        User Question: {user_input}
                        
                        INSTRUCTIONS: Use only tool results. Write naturally.
                        
                        Answer:"""

                    for token in stream_agent(prompt, tool_results=tool_results, session_id=session_id):
                        yield token
                    return

    # For complex queries, run full ReAct then stream the final summarization
    final_answer = run_system(user_input, session_id)

    # Stream the final answer token by token
    for char in final_answer:
        yield char
        time.sleep(0.01)  # Small delay for natural streaming feel


# ---------------------------------------------------------------------------
# Session-aware API wrapper (for FastAPI integration)
# ---------------------------------------------------------------------------

class OrchestratorSession:
    """Session wrapper for API endpoints."""

    def __init__(self):
        self.session_id = None

    def get_or_create_session(self) -> str:
        """Get existing session or create new one."""
        if self.session_id is None:
            from agent_qwen import create_session
            self.session_id = create_session()
        return self.session_id

    def process(self, user_input: str) -> str:
        """Process a message with session persistence."""
        session_id = self.get_or_create_session()
        return run_system(user_input, session_id)

    def process_stream(self, user_input: str):
        """Process with streaming."""
        session_id = self.get_or_create_session()
        yield from run_system_stream(user_input, session_id)

    def clear(self) -> None:
        """Clear the current session."""
        if self.session_id:
            from agent_qwen import clear_session
            clear_session(self.session_id)
            self.session_id = None


# Global session store for API (dictionary of session_id -> OrchestratorSession)
_active_sessions: Dict[str, OrchestratorSession] = {}


def get_or_create_session(session_id: Optional[str] = None) -> Tuple[str, OrchestratorSession]:
    """Get or create a session for API use."""
    if session_id and session_id in _active_sessions:
        return session_id, _active_sessions[session_id]

    new_session = OrchestratorSession()
    new_session_id = new_session.get_or_create_session()
    _active_sessions[new_session_id] = new_session
    return new_session_id, new_session


def clear_all_sessions() -> int:
    """Clear all active sessions."""
    count = len(_active_sessions)
    for session in _active_sessions.values():
        session.clear()
    _active_sessions.clear()
    return count


# ---------------------------------------------------------------------------
# CLI Entry Point (for testing)
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    from agent_qwen import create_session, get_session_stats

    session_id = create_session()
    log.info(f"Agent started. Session: {session_id[:8]}... Type 'exit' to quit.")
    log.info("Commands: 'exit', 'clear', 'stats', 'cache'")

    while True:
        try:
            user_input = input("\nYou: ").strip()
        except (EOFError, KeyboardInterrupt):
            log.info("Shutting down.")
            break

        if not user_input:
            continue

        if user_input.lower() == "exit":
            log.info("Shutting down.")
            break

        if user_input.lower() == "clear":
            from agent_qwen import clear_session

            clear_session(session_id)
            session_id = create_session()
            print("🔄 Session cleared. New session created.")
            continue

        if user_input.lower() == "stats":
            stats = get_session_stats()
            cache_stats = tool_cache.stats()
            print(f"\n📊 Session Stats:")
            print(f"  Active sessions: {stats['active_sessions']}")
            print(f"  Total messages: {stats['total_messages']}")
            print(f"\n📊 Cache Stats:")
            print(f"  Entries: {cache_stats['entries']}")
            print(f"  Hit rate: {cache_stats['hit_rate']}")
            continue

        if user_input.lower() == "cache":
            entries = tool_cache.list_entries()
            print(f"\n💾 Cached Tools ({len(entries)}):")
            for e in entries[:10]:
                print(f"  {e['tool']}: age={e['age_s']}s, remaining={e['remaining']}s")
            continue

        print("🤔 Thinking...", end="", flush=True)
        answer = run_system(user_input, session_id)
        print(f"\r✅ Agent: {answer}")
