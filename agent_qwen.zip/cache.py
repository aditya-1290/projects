"""
cache.py — In-memory response cache for tool results.

Each tool has its own TTL (time-to-live) based on how fast its data changes:

  get_current_time    →  60s   (time changes every minute)
  get_date_info       →  60s   (same)
  get_weather         →  600s  (weather changes slowly, 10 min)
  get_stock_price     →  300s  (stock prices update ~15min anyway on free plan)
  get_gold_price      →  300s  (commodity prices, 5 min)
  convert_currency    →  3600s (exchange rates, 1 hour)
  get_news            →  1800s (news, 30 min)
  get_world_clock     →  60s   (same as time)
  calculate           →  ∞     (math is deterministic — never expires)
  get_date_info       →  60s

Cache key = tool_name + sorted args
Cache hit  → return stored result instantly, zero API call
Cache miss → execute tool, store result, return

Usage:
    from cache import tool_cache
    result = tool_cache.get("get_weather", {"city": "Mumbai"})
    if result is None:
        result = get_weather("Mumbai")
        tool_cache.set("get_weather", {"city": "Mumbai"}, result)
"""

import hashlib
import json
import time

from logger import log

# ---------------------------------------------------------------------------
# TTL config per tool (seconds)
# ---------------------------------------------------------------------------
TOOL_TTL = {
    "get_current_time": 60,
    "get_date_info": 60,
    "get_world_clock": 60,
    "get_weather": 600,
    "get_stock_price": 300,
    "get_gold_price": 300,
    "convert_currency": 3600,
    "get_news": 1800,
    "calculate": 86400,  # math never changes — 24h TTL effectively ∞
}

DEFAULT_TTL = 300  # fallback for unknown tools


class ToolCache:
    """
    Simple in-memory TTL cache for tool results.
    Thread-safe for reads. Writes use a simple dict (GIL protects us for CPython).
    Resets on every server restart — intentional, avoids stale data across sessions.
    """

    def __init__(self):
        self._store: dict[str, dict] = {}
        # Stats for logging
        self._hits = 0
        self._misses = 0

    def _make_key(self, tool_name: str, args: dict) -> str:
        """
        Create a stable cache key from tool name + args.
        Args dict is sorted before hashing so {"city": "Mumbai", "unit": "celsius"}
        and {"unit": "celsius", "city": "Mumbai"} produce the same key.
        """
        normalized = json.dumps(args, sort_keys=True, ensure_ascii=False)
        raw = f"{tool_name}:{normalized}"
        return hashlib.md5(raw.encode()).hexdigest()

    def get(self, tool_name: str, args: dict) -> dict | None:
        """
        Return cached result if it exists and hasn't expired.
        Returns None on cache miss or expiry.
        """
        key = self._make_key(tool_name, args)
        entry = self._store.get(key)

        if entry is None:
            self._misses += 1
            return None

        ttl = TOOL_TTL.get(tool_name, DEFAULT_TTL)
        age = time.time() - entry["stored_at"]

        if age > ttl:
            # Expired — remove and return miss
            del self._store[key]
            self._misses += 1
            log.debug(f"[Cache] EXPIRED — {tool_name}({args}) aged {age:.0f}s > TTL {ttl}s")
            return None

        self._hits += 1
        remaining = round(ttl - age, 0)
        log.info(f"[Cache] ✅ HIT — {tool_name}({args}) | age={age:.0f}s | TTL remaining={remaining}s")
        return entry["result"]

    def set(self, tool_name: str, args: dict, result: dict) -> None:
        """
        Store a tool result in the cache.
        Only caches successful results — errors are never cached.
        """
        if result.get("status") != "success":
            log.debug(f"[Cache] Skipping cache for failed result: {tool_name}")
            return

        key = self._make_key(tool_name, args)
        self._store[key] = {
            "result": result,
            "stored_at": time.time(),
            "tool": tool_name,
            "args": args,
        }
        ttl = TOOL_TTL.get(tool_name, DEFAULT_TTL)
        log.info(f"[Cache] 💾 STORED — {tool_name}({args}) | TTL={ttl}s")

    def invalidate(self, tool_name: str = None) -> int:
        """
        Manually invalidate cache entries.
        If tool_name given → invalidate only that tool's entries.
        If None → clear everything.
        Returns number of entries removed.
        """
        if tool_name is None:
            count = len(self._store)
            self._store.clear()
            log.info(f"[Cache] 🗑 Cleared all {count} entries")
            return count

        keys_to_remove = [
            k for k, v in self._store.items()
            if v.get("tool") == tool_name
        ]
        for k in keys_to_remove:
            del self._store[k]
        log.info(f"[Cache] 🗑 Invalidated {len(keys_to_remove)} entries for '{tool_name}'")
        return len(keys_to_remove)

    def stats(self) -> dict:
        """Return cache hit/miss stats and current entry count."""
        total = self._hits + self._misses
        hit_rate = round(self._hits / total * 100, 1) if total > 0 else 0.0
        return {
            "entries": len(self._store),
            "hits": self._hits,
            "misses": self._misses,
            "hit_rate": f"{hit_rate}%",
            "tools_cached": list({v["tool"] for v in self._store.values()}),
        }

    def list_entries(self) -> list:
        """Return a human-readable list of all cached entries with age and TTL."""
        now = time.time()
        entries = []
        for entry in self._store.values():
            tool = entry["tool"]
            ttl = TOOL_TTL.get(tool, DEFAULT_TTL)
            age = now - entry["stored_at"]
            entries.append({
                "tool": tool,
                "args": entry["args"],
                "age_s": round(age, 0),
                "ttl_s": ttl,
                "remaining": max(0, round(ttl - age, 0)),
                "expired": age > ttl,
            })
        return sorted(entries, key=lambda x: x["tool"])


# Global singleton — imported everywhere
tool_cache = ToolCache()
