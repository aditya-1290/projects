"""
memory_store.py — ChromaDB vector memory with failure tracking.

Features:
- Main memory collection for successful interactions
- Failure memory collection to avoid repeating mistakes
- Automatic trimming to prevent unbounded growth
- Semantic search for relevant memories
- Tool execution memory with success/failure tracking

Collections:
- agent_memory: Stores successful tool calls and conversations
- failure_memory: Tracks failed tool calls with error details
"""

import json
import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional

import chromadb
from chromadb.utils import embedding_functions

from logger import log

# ---------------------------------------------------------------------------
# ChromaDB Setup
# ---------------------------------------------------------------------------
# Use default embedding model (all-MiniLM-L6-v2)
embedding_function = embedding_functions.DefaultEmbeddingFunction()

client = chromadb.PersistentClient(path="./chroma_db")

# Main memory collection — successful interactions
collection = client.get_or_create_collection(
    name="agent_memory",
    embedding_function=embedding_function,
    metadata={"description": "Successful tool calls and conversations"}
)

# Failure memory collection — tracks what didn't work
failure_collection = client.get_or_create_collection(
    name="failure_memory",
    embedding_function=embedding_function,
    metadata={"description": "Failed tool calls to avoid repeating mistakes"}
)

# Configuration
MAX_MEMORY_ITEMS = 500
MAX_FAILURE_ITEMS = 200


# ---------------------------------------------------------------------------
# Core Memory Functions
# ---------------------------------------------------------------------------

def store_memory(text: str, metadata: Optional[Dict[str, Any]] = None) -> bool:
    """
    Store a successful interaction in vector memory.

    Args:
        text: The text content to store
        metadata: Optional metadata dict (source, tool, args, etc.)

    Returns:
        True if stored successfully, False otherwise
    """
    if not text or not text.strip():
        log.debug("[Memory] Skipping empty text")
        return False

    if metadata is None:
        metadata = {"source": "chat"}

        # Sanitize metadata - ChromaDB only accepts str, int, float, bool
    sanitized = {}
    for k, v in metadata.items():
        if isinstance(v, (str, int, float, bool)):
            sanitized[k] = v
        elif v is None:
            sanitized[k] = ""
        else:
            sanitized[k] = json.dumps(v)[:500]  # Convert dicts/lists to JSON string

    # Add timestamp
    sanitized["timestamp"] = datetime.now().isoformat()

    try:
        collection.add(
            documents=[text],
            metadatas=[sanitized],  # ← Use sanitized
            ids=[str(uuid.uuid4())]
        )
        log.debug(f"[Memory] Stored: {text[:50]}...")

        trim_memory()
        return True
    except Exception as e:
        log.error(f"[Memory] Store error: {e}")
        return False


def retrieve_memory(query: str, n_results: int = 3) -> List[Dict[str, Any]]:
    """
    Retrieve relevant memories for a query using semantic search.

    Args:
        query: Search query string
        n_results: Number of results to return

    Returns:
        List of memory dicts with 'text' and 'metadata'
    """
    if not query or not query.strip():
        return []

    try:
        results = collection.query(
            query_texts=[query],
            n_results=n_results
        )

        if not results.get("documents") or not results["documents"][0]:
            return []

        docs = []
        for doc, meta in zip(results["documents"][0], results["metadatas"][0]):
            docs.append({
                "text": doc,
                "metadata": meta
            })

        log.debug(f"[Memory] Retrieved {len(docs)} memories for: {query[:50]}...")
        return docs

    except Exception as e:
        log.error(f"[Memory] Retrieve error: {e}")
        return []


def get_last_exact(tool: Optional[str] = None) -> Optional[str]:
    """
    Get the most recent memory, optionally filtered by tool.

    Args:
        tool: Optional tool name to filter by

    Returns:
        Most recent memory text, or None if not found
    """
    try:
        results = collection.get()

        if not results or not results.get("documents"):
            return None

        docs = list(zip(
            results["documents"],
            results["metadatas"]
        ))

        # Search from newest to oldest
        docs.reverse()

        for doc, meta in docs:
            if tool and meta.get("tool") == tool:
                return doc

        # Return newest if no tool match
        return docs[0][0] if docs else None

    except Exception as e:
        log.error(f"[Memory] get_last_exact error: {e}")
        return None


def trim_memory(max_items: int = MAX_MEMORY_ITEMS) -> int:
    """
    Trim main memory collection to prevent unbounded growth.

    Args:
        max_items: Maximum number of items to keep

    Returns:
        Number of items deleted
    """
    try:
        results = collection.get()

        if not results or len(results.get("ids", [])) <= max_items:
            return 0

        excess = len(results["ids"]) - max_items
        ids_to_delete = results["ids"][:excess]

        if ids_to_delete:
            collection.delete(ids=ids_to_delete)
            log.debug(f"[Memory] Trimmed {len(ids_to_delete)} items (kept {max_items})")

        return len(ids_to_delete)

    except Exception as e:
        log.error(f"[Memory] Trim error: {e}")
        return 0


# ---------------------------------------------------------------------------
# Failure Memory Functions
# ---------------------------------------------------------------------------

def store_failure_memory(
        query: str,
        tool_name: str,
        error_message: str,
        metadata: Optional[Dict[str, Any]] = None
) -> bool:
    """
    Store failed tool calls to avoid repeating mistakes.

    Args:
        query: The original query that caused the failure
        tool_name: Name of the tool that failed
        error_message: Error message from the tool
        metadata: Additional metadata

    Returns:
        True if stored successfully, False otherwise
    """
    if metadata is None:
        metadata = {}

    metadata.update({
        "type": "failure",
        "tool": tool_name,
        "query": query[:200],
        "error": error_message[:200],
        "timestamp": datetime.now().isoformat(),
    })

    text = f"FAILED: {tool_name} | Query: {query} | Error: {error_message}"

    try:
        failure_collection.add(
            documents=[text],
            metadatas=[metadata],
            ids=[str(uuid.uuid4())]
        )
        log.debug(f"[Failure Memory] Stored: {tool_name} failure")

        # Trim failure collection
        trim_failure_memory()

        return True
    except Exception as e:
        log.error(f"[Failure Memory] Store error: {e}")
        return False


def get_past_failures(query: str, n_results: int = 3) -> List[Dict[str, Any]]:
    """
    Retrieve similar past failures to avoid repeating.

    Args:
        query: Search query to find similar failures
        n_results: Number of results to return

    Returns:
        List of failure dicts with text, metadata, tool, and error
    """
    if not query or not query.strip():
        return []

    try:
        results = failure_collection.query(
            query_texts=[query],
            n_results=n_results
        )

        if not results.get("documents") or not results["documents"][0]:
            return []

        failures = []
        for doc, meta in zip(results["documents"][0], results["metadatas"][0]):
            failures.append({
                "text": doc,
                "metadata": meta,
                "tool": meta.get("tool"),
                "error": meta.get("error"),
                "timestamp": meta.get("timestamp"),
            })

        log.debug(f"[Failure Memory] Found {len(failures)} similar failures")
        return failures

    except Exception as e:
        log.error(f"[Failure Memory] Query error: {e}")
        return []


def trim_failure_memory(max_items: int = MAX_FAILURE_ITEMS) -> int:
    """
    Trim failure memory collection to prevent unbounded growth.

    Args:
        max_items: Maximum number of items to keep

    Returns:
        Number of items deleted
    """
    try:
        results = failure_collection.get()

        if not results or len(results.get("ids", [])) <= max_items:
            return 0

        excess = len(results["ids"]) - max_items
        ids_to_delete = results["ids"][:excess]

        if ids_to_delete:
            failure_collection.delete(ids=ids_to_delete)
            log.debug(f"[Failure Memory] Trimmed {len(ids_to_delete)} items")

        return len(ids_to_delete)

    except Exception as e:
        log.error(f"[Failure Memory] Trim error: {e}")
        return 0


# ---------------------------------------------------------------------------
# Tool Memory Functions
# ---------------------------------------------------------------------------

def store_tool_memory(tool_name: str, args: Dict[str, Any], result: Dict[str, Any]) -> bool:
    """
    Store tool execution result in memory.
    - Success: stores in main collection
    - Failure: stores in failure collection

    Args:
        tool_name: Name of the tool executed
        args: Arguments passed to the tool
        result: Result dict from the tool

    Returns:
        True if stored successfully, False otherwise
    """
    # Handle failure case
    if result.get("status") != "success":
        query = f"{tool_name} with args {json.dumps(args, default=str)}"
        error_msg = result.get("message", "Unknown error")

        return store_failure_memory(
            query=query,
            tool_name=tool_name,
            error_message=error_msg,
            metadata={"args": json.dumps(args, default=str)}
        )

    # Handle success case
    # Create a readable text representation
    result_summary = _summarize_result(result)
    text = f"Tool: {tool_name} | Args: {json.dumps(args, default=str)} | Result: {result_summary}"

    # Build metadata
    metadata = {
        "type": "tool_success",
        "tool": tool_name,
        "source": "tool_execution",
    }

    # Add flattened args as metadata (for filtering)
    for k, v in args.items():
        if isinstance(v, (str, int, float, bool)):
            metadata[f"arg_{k}"] = str(v)[:100]
        else:
            metadata[f"arg_{k}"] = json.dumps(v)[:100]  # ← Stringify dicts/lists

    # Add key result fields as metadata - CONVERT TO STRINGS
    for key in ["temperature", "price", "result", "city", "amount", "converted_amount"]:
        if key in result:
            val = result[key]
            if isinstance(val, (str, int, float)):
                metadata[f"result_{key}"] = str(val)[:100]

    return store_memory(text=text, metadata=metadata)


def _summarize_result(result: Dict[str, Any], max_length: int = 200) -> str:
    """
    Create a concise summary of a tool result for storage.

    Args:
        result: Tool result dict
        max_length: Maximum length of summary

    Returns:
        Summarized string
    """
    if not result:
        return "empty"

    # Extract key information based on common patterns
    key_fields = [
        "temperature", "feels_like", "city",
        "price", "ticker", "currency",
        "converted_amount", "exchange_rate",
        "result", "value",
        "datetime", "timezone",
        "article_count", "topic",
    ]

    summary_parts = []
    for field in key_fields:
        if field in result:
            summary_parts.append(f"{field}={result[field]}")

    if summary_parts:
        summary = ", ".join(summary_parts)
    else:
        # Fallback: use first few keys
        summary = ", ".join(f"{k}={v}" for k, v in list(result.items())[:3])

    if len(summary) > max_length:
        summary = summary[:max_length] + "..."

    return summary


def should_avoid_tool(tool_name: str, query: str) -> tuple[bool, Optional[str]]:
    """
    Check if a tool should be avoided based on past failures.

    Args:
        tool_name: Name of the tool being considered
        query: Current user query

    Returns:
        Tuple of (should_avoid, reason)
    """
    failures = get_past_failures(query, n_results=3)

    for failure in failures:
        if failure.get("tool") == tool_name:
            # Check if failure is recent (within last hour)
            timestamp = failure.get("timestamp")
            if timestamp:
                try:
                    failure_time = datetime.fromisoformat(timestamp)
                    age = (datetime.now() - failure_time).total_seconds()
                    if age < 3600:  # Within last hour
                        return True, f"Tool '{tool_name}' failed recently: {failure.get('error')}"
                except (ValueError, TypeError):
                    pass

            return True, f"Tool '{tool_name}' previously failed: {failure.get('error')}"

    return False, None


# ---------------------------------------------------------------------------
# Collection Management Functions
# ---------------------------------------------------------------------------

def clear_all_memory() -> Dict[str, int]:
    """
    Clear all memory collections.

    Returns:
        Dict with counts of deleted items per collection
    """
    counts = {}

    # Clear main collection
    try:
        results = collection.get()
        ids = results.get("ids", [])
        count = len(ids)
        if ids:
            collection.delete(ids=ids)
        counts["main"] = count
        log.info(f"[Memory] Cleared {count} items from main collection")
    except Exception as e:
        log.error(f"[Memory] Clear main error: {e}")
        counts["main"] = -1

    # Clear failure collection
    try:
        results = failure_collection.get()
        ids = results.get("ids", [])
        count = len(ids)
        if ids:
            failure_collection.delete(ids=ids)
        counts["failure"] = count
        log.info(f"[Memory] Cleared {count} items from failure collection")
    except Exception as e:
        log.error(f"[Memory] Clear failure error: {e}")
        counts["failure"] = -1

    return counts


def get_memory_stats() -> Dict[str, Any]:
    """
    Get statistics about memory collections.

    Returns:
        Dict with collection stats
    """
    stats = {}

    # Main collection stats
    try:
        results = collection.get()
        stats["main"] = {
            "count": len(results.get("ids", [])),
            "has_data": bool(results.get("ids")),
        }
    except Exception as e:
        log.error(f"[Memory] Stats main error: {e}")
        stats["main"] = {"count": -1, "error": str(e)}

    # Failure collection stats
    try:
        results = failure_collection.get()
        stats["failure"] = {
            "count": len(results.get("ids", [])),
            "has_data": bool(results.get("ids")),
        }
    except Exception as e:
        log.error(f"[Memory] Stats failure error: {e}")
        stats["failure"] = {"count": -1, "error": str(e)}

    # Collection info
    stats["collections"] = {
        "main_name": collection.name,
        "failure_name": failure_collection.name,
    }

    return stats


def get_recent_memories(limit: int = 10, include_failures: bool = False) -> List[Dict[str, Any]]:
    """
    Get the most recent memories from collections.

    Args:
        limit: Maximum number of memories to return
        include_failures: Whether to include failure memories

    Returns:
        List of recent memories
    """
    memories = []

    try:
        # Get from main collection
        results = collection.get()
        if results and results.get("metadatas"):
            for i in range(min(limit, len(results["ids"]))):
                idx = -(i + 1)  # From end
                memories.append({
                    "type": "success",
                    "text": results["documents"][idx] if results.get("documents") else None,
                    "metadata": results["metadatas"][idx],
                    "id": results["ids"][idx],
                })
    except Exception as e:
        log.error(f"[Memory] Get recent error: {e}")

    if include_failures:
        try:
            results = failure_collection.get()
            if results and results.get("metadatas"):
                for i in range(min(limit, len(results["ids"]))):
                    idx = -(i + 1)
                    memories.append({
                        "type": "failure",
                        "text": results["documents"][idx] if results.get("documents") else None,
                        "metadata": results["metadatas"][idx],
                        "id": results["ids"][idx],
                    })
        except Exception as e:
            log.error(f"[Memory] Get recent failures error: {e}")

    # Sort by timestamp (newest first)
    memories.sort(
        key=lambda x: x.get("metadata", {}).get("timestamp", ""),
        reverse=True
    )

    return memories[:limit]


def search_all_memories(query: str, limit: int = 5) -> Dict[str, List[Dict[str, Any]]]:
    """
    Search both success and failure memories.

    Args:
        query: Search query
        limit: Maximum results per collection

    Returns:
        Dict with 'successes' and 'failures' lists
    """
    return {
        "successes": retrieve_memory(query, n_results=limit),
        "failures": get_past_failures(query, n_results=limit),
    }


# ---------------------------------------------------------------------------
# Export collections for direct access (used by api.py)
# ---------------------------------------------------------------------------
__all__ = [
    # Collections
    "collection",
    "failure_collection",

    # Core functions
    "store_memory",
    "retrieve_memory",
    "get_last_exact",
    "trim_memory",

    # Failure functions
    "store_failure_memory",
    "get_past_failures",
    "trim_failure_memory",

    # Tool functions
    "store_tool_memory",
    "should_avoid_tool",

    # Management functions
    "clear_all_memory",
    "get_memory_stats",
    "get_recent_memories",
    "search_all_memories",
]
