"""
api.py — FastAPI wrapper for the agent system.

Endpoints:
  POST /chat          → standard blocking response
  POST /chat/stream   → streaming response (Server-Sent Events)
  GET  /health        → health check
  GET  /tools         → list all available tools

  # Cache Management
  GET  /cache/stats   → cache hit/miss statistics
  GET  /cache/entries → list all cached entries
  DELETE /cache       → clear cache (all or specific tool)

  # Memory Management (NEW)
  GET  /memory/stats  → vector memory statistics
  GET  /memory/failures → list past tool failures
  POST /memory/clear  → clear all memory (requires confirm=yes)

  # System
  GET  /system/status → full system health and stats
  GET  /system/config → current configuration (safe)

Run with:
  pip install fastapi uvicorn
  uvicorn api:app --host 0.0.0.0 --port 8080 --reload

Then call:
  curl -X POST http://localhost:8080/chat \
       -H "Content-Type: application/json" \
       -d '{"message": "weather in Mumbai?"}'
"""
import asyncio
import json
import os
import time
from typing import Any, Dict, Optional

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, HTMLResponse
from pydantic import BaseModel
from fastapi.staticfiles import StaticFiles

from agent_qwen import stream_agent
from cache import tool_cache
from logger import log
from orchestrator import run_system, get_or_create_session

# Import memory functions - with fallback if not available
try:
    from memory_store import (
        clear_all_memory,
        get_memory_stats,
        get_past_failures,
        collection as main_collection,
        failure_collection,
        store_memory,
        retrieve_memory,
    )
    MEMORY_AVAILABLE = True
except ImportError as e:
    log.warning(f"[API] Memory module not available: {e}")
    MEMORY_AVAILABLE = False

# Import tools for listing
try:
    from tools import TOOL_REGISTRY
except ImportError:
    TOOL_REGISTRY = {}

# ---------------------------------------------------------------------------
# App setup
# ---------------------------------------------------------------------------
app = FastAPI(
    title="AI Agent API",
    description="""
    Multi-tool AI agent with:
    - 🌤️ Weather & time queries
    - 💰 Finance (stocks, gold, currency conversion)
    - 📰 News & web search
    - 🧮 Calculator & unit converter
    - 💾 Persistent memory with ChromaDB
    - ⚡ Smart caching with TTL
    """,
    version="2.0.0",
)

# Allow all origins — tighten this for production
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Serve static files (HTML, CSS, JS)
app.mount("/static", StaticFiles(directory="static", html=True), name="static")

# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------
class ChatRequest(BaseModel):
    message: str
    stream: bool = False  # convenience flag — use /chat/stream instead for SSE


class ChatResponse(BaseModel):
    message: str
    answer: str
    time_taken: float


class MemoryStatsResponse(BaseModel):
    main_collection: Dict[str, Any]
    failure_collection: Dict[str, Any]
    stats: Dict[str, Any]


class SystemStatusResponse(BaseModel):
    status: str
    memory_available: bool
    cache: Dict[str, Any]
    memory: Dict[str, Any]
    tools_available: list
    tool_count: int


class ClearMemoryResponse(BaseModel):
    status: str
    cleared: Dict[str, Any]

# ---------------------------------------------------------------------------
# CODEBASE TOOL ENDPOINTS
# ---------------------------------------------------------------------------

class ReadFileRequest(BaseModel):
    path: str
    start_line: int = 0
    end_line: Optional[int] = None

class WriteFileRequest(BaseModel):
    path: str
    content: str
    append: bool = False

class ListDirectoryRequest(BaseModel):
    path: str = "."
    pattern: Optional[str] = None

class SearchCodeRequest(BaseModel):
    directory: str
    query: str
    file_pattern: str = "*"

class ExecuteCommandRequest(BaseModel):
    command: str
    timeout: int = 30

class AnalyzeCodeRequest(BaseModel):
    file_path: str

class GitOperationRequest(BaseModel):
    repo_path: str
    operation: str  # status, log, diff, branch, remote

class WebSearchRequest(BaseModel):
    query: str
    num_results: int = 5
    time_filter: Optional[str] = None  # d, w, m, y

class TimedNewsRequest(BaseModel):
    query: str
    months_back: int = 6
    limit: int = 5

class EntityTimelineRequest(BaseModel):
    entity: str
    months_back: int = 12

class GitHubIndexRequest(BaseModel):
    repo_url: str
    github_token: Optional[str] = None

class GitHubSearchRequest(BaseModel):
    query: str
    repo_name: Optional[str] = None
    limit: int = 10

class GitHubIndexAllRequest(BaseModel):
    github_username: str
    github_token: str


# ---------------------------------------------------------------------------
# Health check
# ---------------------------------------------------------------------------
@app.get("/health")
def health():
    """Basic health check endpoint."""
    return {
        "status": "ok",
        "agent": "running",
        "memory_available": MEMORY_AVAILABLE,
        "tools_loaded": len(TOOL_REGISTRY),
        "timestamp": time.time()
    }


# ---------------------------------------------------------------------------
# POST /chat — standard blocking response
# ---------------------------------------------------------------------------
@app.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    """
    Main chat endpoint — returns complete answer.

    Supports all query types:
    - Conversational: "Hello", "How are you?"
    - Weather: "Weather in Mumbai"
    - Time: "What time is it in Tokyo?"
    - Finance: "Stock price of AAPL", "Convert 100 USD to INR", "Gold price"
    - News: "Latest tech news", "News about NVIDIA"
    - Web Search: "Difference between FastAPI and Flask"
    - Calculations: "Calculate 156 * 23"
    - Unit Conversion: "10 km to miles"
    """
    if not req.message.strip():
        raise HTTPException(status_code=400, detail="Message cannot be empty.")

    log.info(f"[API /chat] message='{req.message[:100]}...'")
    start = time.time()

    try:
        answer = run_system(req.message)
    except Exception as e:
        log.error(f"[API /chat] Error: {e}")
        import traceback
        log.error(traceback.format_exc())
        raise HTTPException(status_code=500, detail=str(e))

    elapsed = round(time.time() - start, 2)
    log.info(f"[API /chat] Answered in {elapsed}s")

    return ChatResponse(
        message=req.message,
        answer=answer,
        time_taken=elapsed,
    )


# ---------------------------------------------------------------------------
# POST /chat/stream — streaming response via Server-Sent Events (SSE)
# ---------------------------------------------------------------------------
@app.post("/chat/stream")
async def chat_stream_with_progress(req: ChatRequest):
    """
    Streaming chat endpoint — yields tokens as they are generated.

    SSE format:
        data: {"token": "hello"}\n\n
        data: {"done": true}\n\n

    Frontend JS example:
        const res = await fetch('/chat/stream', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({message: 'Hello'})
        });
        const reader = res.body.getReader();
        const decoder = new TextDecoder();
        while(true) {
            const {done, value} = await reader.read();
            if (done) break;
            const text = decoder.decode(value);
            // Parse SSE format and extract token
        }
    """
    if not req.message.strip():
        raise HTTPException(status_code=400, detail="Message cannot be empty.")

    # Create Session
    session_id, session_obj = get_or_create_session()

    log.info(f"[API /chat/stream] message='{req.message[:100]}...'")

    async def event_generator():
        progress_messages = []

        def progress_callback(event_type: str, message: str):
            progress_messages.append({"type": event_type, "message": message})
            # Send progress immediately
            payload = json.dumps({"progress": {"type": event_type, "message": message}})
            return f"data: {payload}\n\n"

        try:
            # Send initial progress
            yield f"data: {json.dumps({'progress': {'type': 'start', 'message': 'Starting...'}})}\n\n"

            # Run with progress
            from orchestrator import run_system_with_refinement
            answer = run_system_with_refinement(
                req.message,
                session_id=session_id,
                progress_callback=progress_callback
            )

            # Stream the answer token by token
            for char in answer:
                yield f"data: {json.dumps({'token': char})}\n\n"
                await asyncio.sleep(0.01)

            yield f"data: {json.dumps({'done': True})}\n\n"

        except Exception as e:
            yield f"data: {json.dumps({'error': str(e)})}\n\n"

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"}
    )


# ---------------------------------------------------------------------------
# GET /tools — list all available tools
# ---------------------------------------------------------------------------
@app.get("/tools")
def list_tools():
    """List all registered tools with their names."""
    return {
        "tools": list(TOOL_REGISTRY.keys()) if TOOL_REGISTRY else [],
        "count": len(TOOL_REGISTRY),
        "available": bool(TOOL_REGISTRY)
    }


# ---------------------------------------------------------------------------
# CACHE ENDPOINTS
# ---------------------------------------------------------------------------
@app.get("/cache/stats")
def cache_stats():
    """Get cache hit/miss statistics and current entry count."""
    return tool_cache.stats()


@app.get("/cache/entries")
def cache_entries():
    """List all currently cached tool results with TTL info."""
    return {"entries": tool_cache.list_entries()}


@app.delete("/cache")
def cache_clear(tool: Optional[str] = Query(None, description="Tool name to clear (omit for all)")):
    """
    Clear cache entries.

    - No parameter: clears ALL cached results
    - ?tool=get_weather: clears only weather cache
    """
    count = tool_cache.invalidate(tool_name=tool)
    return {
        "status": "success",
        "cleared": count,
        "tool": tool or "all",
        "message": f"Cleared {count} cache entries"
    }


# ---------------------------------------------------------------------------
# MEMORY ENDPOINTS (Vector Database)
# ---------------------------------------------------------------------------
@app.get("/memory/stats")
def memory_stats():
    """
    Get vector memory statistics.

    Returns:
        - main_collection: count of stored memories
        - failure_collection: count of stored failures
        - stats: detailed memory statistics
    """
    if not MEMORY_AVAILABLE:
        raise HTTPException(status_code=503, detail="Memory module not available")

    try:
        stats = get_memory_stats()

        main_results = main_collection.get() if main_collection else {"ids": []}
        failure_results = failure_collection.get() if failure_collection else {"ids": []}

        return {
            "main_collection": {
                "count": len(main_results.get("ids", [])),
                "name": "agent_memory"
            },
            "failure_collection": {
                "count": len(failure_results.get("ids", [])),
                "name": "failure_memory"
            },
            "stats": stats
        }
    except Exception as e:
        log.error(f"[API /memory/stats] Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/memory/failures")
def get_failures(
    query: Optional[str] = Query(None, description="Search for similar failures"),
    limit: int = Query(10, ge=1, le=50, description="Number of results")
):
    """
    Get past tool failure records.

    - ?query=weather: find failures similar to "weather"
    - No query: returns most recent failures
    """
    if not MEMORY_AVAILABLE:
        raise HTTPException(status_code=503, detail="Memory module not available")

    try:
        if query:
            failures = get_past_failures(query, n_results=limit)
        else:
            # Get recent failures from collection
            results = failure_collection.get() if failure_collection else {"metadatas": []}
            failures = []
            if results and results.get("metadatas"):
                for meta in results["metadatas"][-limit:]:
                    failures.append({"metadata": meta})

        return {
            "failures": failures,
            "count": len(failures),
            "query": query
        }
    except Exception as e:
        log.error(f"[API /memory/failures] Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/memory/clear", response_model=ClearMemoryResponse)
def clear_memory(
    confirm: str = Query("no", description="Must be 'yes' to confirm deletion")
):
    """
    Clear ALL vector memory (main + failure collections) and memory.json.

    ⚠️ WARNING: This is irreversible!

    Requires: ?confirm=yes
    """
    if confirm != "yes":
        return ClearMemoryResponse(
            status="cancelled",
            cleared={"message": "Add ?confirm=yes to clear memory"}
        )

    cleared_info = {
        "main_collection": 0,
        "failure_collection": 0,
        "memory_json": False
    }

    # Clear ChromaDB collections if available
    if MEMORY_AVAILABLE:
        try:
            counts = clear_all_memory()
            cleared_info["main_collection"] = counts.get("main", 0)
            cleared_info["failure_collection"] = counts.get("failure", 0)
        except Exception as e:
            log.error(f"[API] ChromaDB clear error: {e}")

    # Clear memory.json file
    memory_file = "memory.json"
    if os.path.exists(memory_file):
        try:
            os.remove(memory_file)
            cleared_info["memory_json"] = True
            log.info("[API] Deleted memory.json")
        except Exception as e:
            log.error(f"[API] Failed to delete memory.json: {e}")

    log.info(f"[API] Memory cleared: {cleared_info}")

    return ClearMemoryResponse(
        status="success",
        cleared=cleared_info
    )


@app.post("/memory/store")
def store_custom_memory(
    text: str,
    metadata: Optional[str] = None,
    source: str = "api"
):
    """
    Manually store a memory entry.

    Body (JSON):
        {
            "text": "Memory content to store",
            "metadata": "{\"key\": \"value\"}",  // optional JSON string
            "source": "api"
        }
    """
    if not MEMORY_AVAILABLE:
        raise HTTPException(status_code=503, detail="Memory module not available")

    try:
        meta_dict = {"source": source}
        if metadata:
            try:
                meta_dict.update(json.loads(metadata))
            except json.JSONDecodeError:
                meta_dict["raw_metadata"] = metadata

        store_memory(text, metadata=meta_dict)

        return {
            "status": "success",
            "stored": text[:100] + "..." if len(text) > 100 else text
        }
    except Exception as e:
        log.error(f"[API /memory/store] Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/memory/search")
def search_memory(
    query: str,
    limit: int = Query(5, ge=1, le=20)
):
    """
    Search for similar memories.

    Body (JSON):
        {
            "query": "search term",
            "limit": 5
        }
    """
    if not MEMORY_AVAILABLE:
        raise HTTPException(status_code=503, detail="Memory module not available")

    try:
        results = retrieve_memory(query, n_results=limit)
        return {
            "query": query,
            "results": results,
            "count": len(results)
        }
    except Exception as e:
        log.error(f"[API /memory/search] Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ---------------------------------------------------------------------------
# SYSTEM ENDPOINTS
# ---------------------------------------------------------------------------
@app.get("/system/status", response_model=SystemStatusResponse)
def system_status():
    """
    Get full system status including cache, memory, and tools.
    """
    # Cache stats
    cache_stats_data = tool_cache.stats()

    # Memory stats
    memory_data = {"main": 0, "failures": 0}
    if MEMORY_AVAILABLE:
        try:
            stats = get_memory_stats()
            memory_data["main"] = stats.get("main", {}).get("count", 0)
            memory_data["failures"] = stats.get("failure", {}).get("count", 0)
        except Exception as e:
            log.error(f"[API] Memory stats error: {e}")

    return SystemStatusResponse(
        status="running",
        memory_available=MEMORY_AVAILABLE,
        cache={
            "entries": cache_stats_data.get("entries", 0),
            "hits": cache_stats_data.get("hits", 0),
            "misses": cache_stats_data.get("misses", 0),
            "hit_rate": cache_stats_data.get("hit_rate", "0%"),
            "tools_cached": cache_stats_data.get("tools_cached", [])
        },
        memory={
            "main_collection": memory_data["main"],
            "failure_collection": memory_data["failures"]
        },
        tools_available=list(TOOL_REGISTRY.keys()) if TOOL_REGISTRY else [],
        tool_count=len(TOOL_REGISTRY)
    )


@app.get("/system/config")
def system_config():
    """
    Get current system configuration (safe values only — no API keys).
    """
    from cache import TOOL_TTL, DEFAULT_TTL

    return {
        "cache": {
            "ttl_config": TOOL_TTL,
            "default_ttl": DEFAULT_TTL
        },
        "tools": {
            "count": len(TOOL_REGISTRY),
            "names": list(TOOL_REGISTRY.keys()) if TOOL_REGISTRY else []
        },
        "memory": {
            "available": MEMORY_AVAILABLE
        }
    }

# ---------------------------------------------------------------------------
# INDIVIDUAL TOOL ENDPOINTS (for web UI)
# ---------------------------------------------------------------------------

@app.post("/tools/get_weather")
def api_get_weather(city: str, unit: str = "celsius"):
    """Get weather for a city."""
    from tools import get_weather
    return get_weather(city, unit)

@app.post("/tools/get_current_time")
def api_get_current_time(city: str):
    """Get current time for a city."""
    from tools import get_current_time
    return get_current_time(city)

@app.post("/tools/get_date_info")
def api_get_date_info(city: str):
    """Get date info for a city."""
    from tools import get_date_info
    return get_date_info(city)

@app.post("/tools/get_stock_price")
def api_get_stock_price(ticker: str):
    """Get stock price."""
    from tools import get_stock_price
    return get_stock_price(ticker)

@app.post("/tools/get_gold_price")
def api_get_gold_price():
    """Get gold price."""
    from tools import get_gold_price
    return get_gold_price()

@app.post("/tools/convert_currency")
def api_convert_currency(amount: float, from_currency: str, to_currency: str):
    """Convert currency."""
    from tools import convert_currency
    return convert_currency(amount, from_currency, to_currency)

@app.post("/tools/get_news")
def api_get_news(topic: str = "technology", limit: int = 3):
    """Get news."""
    from tools import get_news
    return get_news(topic, limit)

@app.post("/tools/calculate")
def api_calculate(expression: str):
    """Calculate math expression."""
    from tools import calculate
    return calculate(expression)

@app.post("/tools/convert_units")
def api_convert_units(value: float, from_unit: str, to_unit: str):
    """Convert units."""
    from tools import convert_units
    return convert_units(value, from_unit, to_unit)

# ---------------------------------------------------------------------------
# CODEBASE TOOLS
# ---------------------------------------------------------------------------

@app.post("/tools/read_file")
def api_read_file(path: str, start_line: int = 0, end_line: int = None):
    """Read a file."""
    from tools import read_file
    return read_file(path, start_line, end_line)

@app.post("/tools/write_file")
def api_write_file(path: str, content: str, append: bool = False):
    """Write a file."""
    from tools import write_file
    return write_file(path, content, append)

@app.post("/tools/list_directory")
def api_list_directory(path: str = ".", pattern: str = None):
    """List directory."""
    from tools import list_directory
    return list_directory(path, pattern)

@app.post("/tools/search_code")
def api_search_code(directory: str, query: str, file_pattern: str = "*"):
    """Search code."""
    from tools import search_code
    return search_code(directory, query, file_pattern)

@app.post("/tools/execute_command")
def api_execute_command(command: str, timeout: int = 30):
    """Execute command."""
    from tools import execute_command
    return execute_command(command, timeout)

@app.post("/tools/analyze_code")
def api_analyze_code(file_path: str):
    """Analyze code."""
    from tools import analyze_code
    return analyze_code(file_path)

@app.post("/tools/git_operation")
def api_git_operation(repo_path: str, operation: str):
    """Git operation."""
    from tools import git_operation
    return git_operation(repo_path, operation)

# ---------------------------------------------------------------------------
# SEARCH TOOLS
# ---------------------------------------------------------------------------

@app.post("/tools/web_search")
def api_web_search(query: str, num_results: int = 5, time_filter: str = None):
    """Web search."""
    from tools import web_search
    return web_search(query, num_results, time_filter)

@app.post("/tools/search_timed_news")
def api_search_timed_news(query: str, months_back: int = 6, limit: int = 5):
    """Search timed news."""
    from tools import search_timed_news
    return search_timed_news(query, months_back, limit)

@app.post("/tools/get_entity_timeline")
def api_get_entity_timeline(entity: str, months_back: int = 12):
    """Get entity timeline."""
    from tools import get_entity_timeline
    return get_entity_timeline(entity, months_back)

# ---------------------------------------------------------------------------
# GITHUB TOOLS
# ---------------------------------------------------------------------------

@app.post("/github/index_repo")
def api_index_github_repo(repo_url: str, github_token: str = None):
    """Index GitHub repo."""
    from tools import index_github_repo
    return index_github_repo(repo_url, github_token)

@app.post("/github/search_code")
def api_search_indexed_code(query: str, repo_name: str = None, limit: int = 10):
    """Search indexed code."""
    from tools import search_indexed_code
    return search_indexed_code(query, repo_name, limit)

@app.get("/github/list_repos")
def api_list_github_repos():
    """List indexed repos."""
    from tools import list_github_repos
    return list_github_repos()

@app.post("/github/index_all")
def api_index_all_user_repos(github_username: str, github_token: str):
    """Index all user repos."""
    from tools import index_all_user_repos
    return index_all_user_repos(github_username, github_token)

# ---------------------------------------------------------------------------
# CODEBASE TOOLS
# ---------------------------------------------------------------------------

@app.post("/tools/read_file")
def api_read_file(req: ReadFileRequest):
    """Read a file from the filesystem."""
    from tools import read_file
    return read_file(req.path, req.start_line, req.end_line)

@app.post("/tools/write_file")
def api_write_file(req: WriteFileRequest):
    """Write content to a file."""
    from tools import write_file
    return write_file(req.path, req.content, req.append)

@app.post("/tools/list_directory")
def api_list_directory(req: ListDirectoryRequest):
    """List files and directories."""
    from tools import list_directory
    return list_directory(req.path, req.pattern)

@app.post("/tools/search_code")
def api_search_code(req: SearchCodeRequest):
    """Search for text in files."""
    from tools import search_code
    return search_code(req.directory, req.query, req.file_pattern)

@app.post("/tools/execute_command")
def api_execute_command(req: ExecuteCommandRequest):
    """Execute a safe shell command."""
    from tools import execute_command
    return execute_command(req.command, req.timeout)

@app.post("/tools/analyze_code")
def api_analyze_code(req: AnalyzeCodeRequest):
    """Analyze a Python file structure."""
    from tools import analyze_code
    return analyze_code(req.file_path)

@app.post("/tools/git_operation")
def api_git_operation(req: GitOperationRequest):
    """Perform git operations."""
    from tools import git_operation
    return git_operation(req.repo_path, req.operation)


# ---------------------------------------------------------------------------
# DATE-AWARE TOOLS
# ---------------------------------------------------------------------------

@app.post("/tools/web_search")
def api_web_search(req: WebSearchRequest):
    """Web search with date filtering."""
    from tools import web_search
    return web_search(req.query, req.num_results, req.time_filter)

@app.post("/tools/search_timed_news")
def api_search_timed_news(req: TimedNewsRequest):
    """Search news within time window."""
    from tools import search_timed_news
    return search_timed_news(req.query, req.months_back, req.limit)

@app.post("/tools/get_entity_timeline")
def api_get_entity_timeline(req: EntityTimelineRequest):
    """Get timeline of events for an entity."""
    from tools import get_entity_timeline
    return get_entity_timeline(req.entity, req.months_back)


# ---------------------------------------------------------------------------
# GITHUB TOOLS
# ---------------------------------------------------------------------------

@app.post("/github/index_repo")
def api_index_github_repo(req: GitHubIndexRequest):
    """Clone and index a GitHub repository."""
    from tools import index_github_repo
    return index_github_repo(req.repo_url, req.github_token)

@app.post("/github/search_code")
def api_search_indexed_code(req: GitHubSearchRequest):
    """Search indexed GitHub code."""
    from tools import search_indexed_code
    return search_indexed_code(req.query, req.repo_name, req.limit)

@app.get("/github/list_repos")
def api_list_github_repos():
    """List all indexed GitHub repositories."""
    from tools import list_github_repos
    return list_github_repos()

@app.post("/github/index_all")
def api_index_all_user_repos(req: GitHubIndexAllRequest):
    """Index all repositories for a GitHub user."""
    from tools import index_all_user_repos
    return index_all_user_repos(req.github_username, req.github_token)

# ---------------------------------------------------------------------------
# DASHBOARD (Simple HTML)
# ---------------------------------------------------------------------------
@app.get("/dashboard", response_class=HTMLResponse)
def dashboard():
    """
    Simple monitoring dashboard with auto-refresh.
    """
    return HTMLResponse("""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Agent Dashboard</title>
        <style>
            body { font-family: system-ui, sans-serif; margin: 2rem; background: #f5f5f5; }
            .card { background: white; border-radius: 8px; padding: 1.5rem; margin: 1rem 0; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
            .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; }
            .stat { text-align: center; }
            .stat-value { font-size: 2.5rem; font-weight: bold; color: #2563eb; }
            .stat-label { color: #6b7280; text-transform: uppercase; font-size: 0.875rem; }
            .tool-tag { display: inline-block; background: #e5e7eb; padding: 0.25rem 0.75rem; border-radius: 9999px; margin: 0.25rem; font-size: 0.875rem; }
            h1 { color: #1f2937; }
            h2 { color: #374151; border-bottom: 2px solid #e5e7eb; padding-bottom: 0.5rem; }
            .refresh { color: #6b7280; font-size: 0.875rem; }
        </style>
    </head>
    <body>
        <h1>🤖 AI Agent Dashboard</h1>
        <p class="refresh">Auto-refreshes every 5 seconds</p>
        
        <div class="card">
            <h2>📊 System Status</h2>
            <div class="grid">
                <div class="stat">
                    <div class="stat-value" id="status">-</div>
                    <div class="stat-label">Status</div>
                </div>
                <div class="stat">
                    <div class="stat-value" id="cache-entries">-</div>
                    <div class="stat-label">Cache Entries</div>
                </div>
                <div class="stat">
                    <div class="stat-value" id="hit-rate">-</div>
                    <div class="stat-label">Cache Hit Rate</div>
                </div>
                <div class="stat">
                    <div class="stat-value" id="memory-count">-</div>
                    <div class="stat-label">Memories</div>
                </div>
                <div class="stat">
                    <div class="stat-value" id="tool-count">-</div>
                    <div class="stat-label">Active Tools</div>
                </div>
                <div class="stat">
                    <div class="stat-value" id="failures">-</div>
                    <div class="stat-label">Failures</div>
                </div>
            </div>
        </div>
        
        <div class="card">
            <h2>🔧 Available Tools</h2>
            <div id="tools-list">Loading...</div>
        </div>
        
        <div class="card">
            <h2>💾 Cached Tools</h2>
            <div id="cached-tools">Loading...</div>
        </div>
        
        <div class="card">
            <h2>⚡ Quick Actions</h2>
            <button onclick="clearCache()" style="margin-right: 1rem; padding: 0.5rem 1rem;">Clear Cache</button>
            <button onclick="clearMemory()" style="padding: 0.5rem 1rem; background: #dc2626; color: white; border: none; border-radius: 4px;">Clear Memory</button>
        </div>
        
        <script>
            async function fetchStatus() {
                try {
                    const res = await fetch('/system/status');
                    const data = await res.json();
                    
                    document.getElementById('status').textContent = data.status;
                    document.getElementById('cache-entries').textContent = data.cache.entries;
                    document.getElementById('hit-rate').textContent = data.cache.hit_rate;
                    document.getElementById('memory-count').textContent = data.memory.main_collection;
                    document.getElementById('tool-count').textContent = data.tool_count;
                    document.getElementById('failures').textContent = data.memory.failure_collection;
                    
                    // Display tools
                    const toolsDiv = document.getElementById('tools-list');
                    toolsDiv.innerHTML = data.tools_available.map(t => 
                        `<span class="tool-tag">${t}</span>`
                    ).join('');
                    
                    // Display cached tools
                    const cachedDiv = document.getElementById('cached-tools');
                    if (data.cache.tools_cached && data.cache.tools_cached.length > 0) {
                        cachedDiv.innerHTML = data.cache.tools_cached.map(t => 
                            `<span class="tool-tag">${t}</span>`
                        ).join('');
                    } else {
                        cachedDiv.innerHTML = '<span style="color: #6b7280;">No cached results</span>';
                    }
                } catch (e) {
                    console.error('Failed to fetch status:', e);
                }
            }
            
            async function clearCache() {
                if (confirm('Clear all cache?')) {
                    await fetch('/cache', { method: 'DELETE' });
                    fetchStatus();
                }
            }
            
            async function clearMemory() {
                if (confirm('⚠️ Clear ALL memory? This cannot be undone!')) {
                    await fetch('/memory/clear?confirm=yes', { method: 'POST' });
                    fetchStatus();
                }
            }
            
            // Initial fetch
            fetchStatus();
            
            // Refresh every 5 seconds
            setInterval(fetchStatus, 5000);
        </script>
    </body>
    </html>
    """)


# ---------------------------------------------------------------------------
# Root endpoint
# ---------------------------------------------------------------------------
# Root redirects to web UI
@app.get("/")
def root():
    """Redirect to web UI."""
    from fastapi.responses import RedirectResponse
    return RedirectResponse(url="/static/index.html")