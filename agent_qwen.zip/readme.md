# Log Analysis Multi-Agent System (Terminal-Based)

A **modular, decentralized multi-agent system** for analyzing logs from multiple sources (text, files, images, terminal), classifying them, debugging errors, and generating intelligent solutions using locally hosted LLMs. Built with peer-to-peer agent communication via the Agent-to-Agent (A2A) protocol.

Built with:
* 🐍 Python
* 🧠 Google ADK (Agent Development Kit)
* 🧩 MCP (Model Context Protocol)
* ⚡ Local inference via llama-cpp-python
* 🤖 LLMs: Gemma-4-E4B-IT + Qwen2.5-3B-Instruct (GGUF)
* 🖼️ OCR: DeepSeek-OCR2

---

## 🚀 Features

### 📥 Multi-Source Log Ingestion
* Files (`.log`, `.txt`, `.json`, `.csv`, `.xml`)
* Terminal commands output
* Image-based logs via OCR
* Structured log formats (syslog, Apache logs)

### 🧹 Intelligent Preprocessing
* Noise removal via Qwen2.5-3B
* Log structuring and normalization
* Smart chunking for large inputs
* Timestamp and IP normalization

### 🧠 Log Analysis (Merged Classifier + Intent)
* Error logs
* Server logs
* Application logs
* Security logs
* Intent: Debugging, Explanation, Optimization

### 🛠️ Multi-Step Reasoning Solver
* Root cause analysis
* High-level fix suggestions
* Human-readable explanation generation

### 👨‍💻 Code Debugging Agent
* Stack trace parsing
* Code context analysis
* Patch generation with validation

### ✅ Critic & Safety Agent
* Output quality validation
* Hallucination reduction
* Security audit of generated patches and commands
* Checklist-based verification

### 💾 Memory System
* Vector-based storage (ChromaDB)
* Past log & solution retrieval
* Reflexion loop for continuous improvement

### 🔄 Decentralized Agent Communication
* **A2A Protocol**: Agents communicate peer-to-peer
* **Capability Discovery**: Agents auto-discover who can handle tasks
* **Graceful Degradation**: Out-of-scope detection and handoff
* **No Central Controller**: Orchestrator is just another agent

### ⚙️ Multi-Model Strategy
* **Gemma-4-E4B-IT**: Primary reasoning (analyzer, solver, debugger, critic, orchestrator)
* **Qwen2.5-3B-Instruct**: Lightweight preprocessing and memory retrieval
* **DeepSeek-OCR2**: On-demand image text extraction
* **BGE-Small-EN**: Embeddings for memory system
* Smart model swapping to stay within 16GB RAM

### 🔒 Security-First Design
* Terminal command whitelist
* Sandboxed execution environment
* User approval gates for destructive operations
* Input sanitization pipeline
* Safety audit logging

---

## 🏗️ Architecture Overview

```text
┌─────────────────────────────────────────────────────────────────┐
│                    AGENT ECOSYSTEM (A2A Protocol)               │
│                                                                 │
│  ┌──────────┐         ┌──────────┐         ┌──────────┐       │
│  │ Extractor│◄───────►│Preprocess│◄───────►│ Analyzer │       │
│  │(OCR+File)│  A2A    │(Qwen 3B) │  A2A    │(Gemma 4B)│       │
│  └────┬─────┘         └────┬─────┘         └────┬─────┘       │
│       │                    │                    │              │
│       │              ┌─────┼────────────┐       │              │
│       │              │     │            │       │              │
│       │         ┌────▼─────┐  ┌───────▼──┐  ┌──▼────────┐    │
│       │         │ Debugger │  │  Solver  │  │  Memory   │    │
│       │         │(Gemma 4B)│  │(Gemma 4B)│  │(Qwen 3B)  │    │
│       │         └──────────┘  └──────────┘  └───────────┘    │
│       │                                                       │
│  ┌────▼──────────────────────────────────────────────────┐    │
│  │              Orchestrator Agent (Gemma 4B)             │    │
│  │   Task decomposition, coordination, user interface     │    │
│  └───────────────────────────────────────────────────────┘    │
│                            │                                   │
│                       ┌────▼─────┐                            │
│                       │  Critic  │                            │
│                       │(Gemma 4B)│                            │
│                       └──────────┘                            │
│                                                                 │
│  Communication Bus: Agent-to-Agent Protocol                     │
│  Model Manager: Smart loading/unloading of multiple LLMs        │
└─────────────────────────────────────────────────────────────────┘

Model Memory Footprint


┌─────────────────────────────────────────┐
│         SYSTEM MEMORY (16GB RAM)        │
│                                         │
│  ALWAYS LOADED:                         │
│  ├── Gemma-4-E4B-IT (Q4_K_M)   ~3.0GB  │
│  ├── Qwen2.5-3B-IT (Q4_K_M)    ~2.0GB  │
│  └── BGE Embedding Model        ~0.5GB  │
│  TOTAL BASE: ~5.5GB                     │
│                                         │
│  ON-DEMAND:                             │
│  └── DeepSeek-OCR2              ~2.0GB  │
│  PEAK TOTAL: ~7.5GB                     │
│                                         │
│  FREE FOR SYSTEM/CONTEXT: ~8.5GB        │
└─────────────────────────────────────────┘

Project Structure:

log_multi_agent/
│
├── main.py                    # Entry point (async CLI runner)
├── config.py                  # Global configs (models, paths, flags)
├── requirements.txt
├── README.md
├── pyproject.toml             # ADK project configuration
├── .env                       # Environment variables
│
├── agentos/                   # 🧠 ADK runtime system
│   ├── __init__.py
│   ├── agent_registry.py      # Central agent registration
│   ├── capability_registry.py # Global capability aggregation
│   ├── communication_bus.py   # A2A message broker
│   ├── message_protocol.py    # A2A message schemas
│   ├── model_manager.py       # Multi-model lifecycle manager
│   └── session_manager.py     # Session & context management
│
├── agents/                    # 🤖 All autonomous agents
│   ├── __init__.py
│   ├── base_agent.py          # ADK-compliant base class
│   ├── agent_config.py        # Model-to-agent assignments
│   │
│   ├── extractor/             # Multi-source log extraction
│   │   ├── __init__.py
│   │   ├── agent.py
│   │   ├── capabilities.json  # Machine-readable capability contract
│   │   ├── prompts.py
│   │   ├── tools.py
│   │   ├── loaders/           # File & terminal loaders
│   │   │   ├── __init__.py
│   │   │   ├── file_loader.py
│   │   │   ├── image_loader.py    # DeepSeek-OCR2 integration
│   │   │   └── terminal_loader.py
│   │   ├── parsers/           # Custom parsers (no LLM needed)
│   │   │   ├── __init__.py
│   │   │   ├── json_parser.py
│   │   │   ├── csv_parser.py
│   │   │   ├── xml_parser.py
│   │   │   ├── syslog_parser.py
│   │   │   └── apache_log_parser.py
│   │   └── tests/
│   │       ├── __init__.py
│   │       └── test_extractor.py
│   │
│   ├── preprocessor/          # Qwen2.5-3B: Cleaning & parsing
│   │   ├── __init__.py
│   │   ├── agent.py
│   │   ├── capabilities.json
│   │   ├── prompts.py
│   │   ├── tools.py
│   │   ├── cleaner.py
│   │   ├── parser.py
│   │   ├── chunker.py
│   │   ├── normalizer.py      # Timestamp/IP normalization
│   │   └── tests/
│   │       ├── __init__.py
│   │       └── test_preprocessor.py
│   │
│   ├── analyzer/              # Gemma-4-E4B: Classification + Intent
│   │   ├── __init__.py
│   │   ├── agent.py
│   │   ├── capabilities.json
│   │   ├── prompts.py
│   │   ├── tools.py
│   │   └── tests/
│   │       ├── __init__.py
│   │       └── test_analyzer.py
│   │
│   ├── solver/                # Gemma-4-E4B: Analysis & solutions
│   │   ├── __init__.py
│   │   ├── agent.py
│   │   ├── capabilities.json
│   │   ├── prompts.py
│   │   ├── tools.py
│   │   ├── error_analyzer.py
│   │   ├── fix_generator.py
│   │   ├── explanation_generator.py
│   │   └── tests/
│   │       ├── __init__.py
│   │       └── test_solver.py
│   │
│   ├── debugger/              # Gemma-4-E4B: Code debugging
│   │   ├── __init__.py
│   │   ├── agent.py
│   │   ├── capabilities.json
│   │   ├── prompts.py
│   │   ├── tools.py
│   │   ├── code_parser.py
│   │   ├── patch_generator.py
│   │   └── tests/
│   │       ├── __init__.py
│   │       └── test_debugger.py
│   │
│   ├── critic/                # Gemma-4-E4B: Validation & safety
│   │   ├── __init__.py
│   │   ├── agent.py
│   │   ├── capabilities.json
│   │   ├── prompts.py
│   │   ├── tools.py
│   │   ├── evaluator.py
│   │   ├── safety_checker.py
│   │   └── tests/
│   │       ├── __init__.py
│   │       └── test_critic.py
│   │
│   ├── memory/                # Qwen2.5-3B: Retrieval
│   │   ├── __init__.py
│   │   ├── agent.py
│   │   ├── capabilities.json
│   │   ├── prompts.py
│   │   ├── tools.py
│   │   ├── vector_store.py    # ChromaDB wrapper
│   │   ├── retrieval.py
│   │   └── tests/
│   │       ├── __init__.py
│   │       └── test_memory.py
│   │
│   └── orchestrator/          # Gemma-4-E4B: Coordination
│       ├── __init__.py
│       ├── agent.py
│       ├── capabilities.json
│       ├── prompts.py
│       ├── tools.py
│       ├── planner.py
│       ├── router.py
│       └── tests/
│           ├── __init__.py
│           └── test_orchestrator.py
│
├── models/                    # 🧪 Model layer
│   ├── __init__.py
│   ├── model_configs.py      # Model registry & configurations
│   ├── manager.py            # Lifecycle management
│   ├── llm/
│   │   ├── __init__.py
│   │   ├── loader.py         # llama-cpp-python loader
│   │   ├── gemma.py          # Gemma-4-E4B-IT wrapper
│   │   ├── qwen.py           # Qwen2.5-3B wrapper
│   │   ├── inference.py      # Shared inference logic
│   │   └── context_manager.py
│   ├── ocr/
│   │   ├── __init__.py
│   │   └── deepseek_ocr.py   # DeepSeek-OCR2 wrapper
│   └── embeddings/
│       ├── __init__.py
│       └── embedding_model.py
│
├── tools/                     # 🔧 MCP-compatible tools
│   ├── __init__.py
│   ├── base_tool.py
│   ├── file_tool.py
│   ├── terminal_tool.py      # Sandboxed execution
│   ├── ocr_tool.py
│   ├── search_tool.py
│   ├── code_analysis_tool.py
│   ├── registry.py           # Tool registry
│   └── sandbox.py            # Terminal sandbox
│
├── safety/                    # 🔒 Security layer
│   ├── __init__.py
│   ├── command_whitelist.py
│   ├── permission_manager.py
│   ├── input_sanitizer.py
│   └── audit_logger.py
│
├── communication/             # 📡 A2A protocol
│   ├── __init__.py
│   ├── a2a_protocol.py       # Message format definitions
│   ├── message_broker.py     # Pub/sub message routing
│   ├── discovery.py          # Agent capability discovery
│   └── schemas.py            # Message type definitions
│
├── memory_store/              # 💾 Persistent storage
│   ├── chroma_db/
│   └── logs/
│
├── prompts/                   # 🧾 Prompt templates
│   ├── extractor_ocr.txt
│   ├── preprocessor_qwen.txt
│   ├── analyzer_gemma.txt
│   ├── solver_gemma.txt
│   ├── debugger_gemma.txt
│   ├── critic_gemma.txt
│   ├── orchestrator_gemma.txt
│   └── memory_qwen.txt
│
├── utils/                     # 🧩 Utilities
│   ├── __init__.py
│   ├── logger.py
│   ├── json_utils.py
│   ├── validators.py
│   ├── chunking.py
│   ├── response_formatter.py
│   ├── confidence.py
│   └── model_utils.py
│
├── tests/                     # 🧪 Testing
│   ├── __init__.py
│   ├── conftest.py
│   ├── integration/
│   │   ├── __init__.py
│   │   ├── test_a2a_communication.py
│   │   ├── test_agent_collaboration.py
│   │   ├── test_model_switching.py
│   │   └── test_edge_cases.py
│   └── e2e/
│       ├── __init__.py
│       ├── test_full_pipeline.py
│       └── test_security_scenarios.py
│
├── scripts/                   # ⚙️ Utilities
│   ├── download_models.sh    # Download all models
│   ├── quantize_model.sh
│   ├── run_server.sh
│   ├── benchmark_models.py
│   └── init_adk_project.sh
│
└── docs/                      # 📚 Documentation
    ├── architecture.md
    ├── model_strategy.md
    ├── a2a_protocol_spec.md
    ├── agent_capabilities.md
    ├── security_model.md
    └── adk_setup_guide.md

 Agent Capabilities Overview:
 
Agent	                   Model	                                      Can Do	                                                     Cannot Do
Extractor	     Custom Parsers + DeepSeek-OCR2	  Extract from files, images, terminal; Parse JSON/CSV/XML/syslog/Apache	Handle proprietary binary formats; Fix corrupted images
Preprocessor	 Qwen2.5-3B	                      Clean noise, structure logs, normalize data, smart chunking	            Interpret log semantics; Classify errors
Analyzer	     Gemma-4-E4B	                  Classify log types, determine user intent, confidence scoring	            Generate fixes; Debug code
Solver	         Gemma-4-E4B	                  Root cause analysis, high-level fix suggestions, explanations	            Modify production code; Execute fixes
Debugger	     Gemma-4-E4B	                  Parse stack traces, analyze code context, generate patches	            Execute patches; Modify infrastructure
Critic	         Gemma-4-E4B	                  Validate output quality, detect hallucinations, security audit	        Generate new solutions; Access external data
Memory	         Qwen2.5-3B + BGE	              Store/retrieve past solutions, find similar cases	                        Generate new solutions independently
Orchestrator	 Gemma-4-E4B	                  Decompose tasks, coordinate agents, handle edge cases	                    Specialize in any single domain

Installation
1. System Requirements
    -CPU with 16GB+ RAM recommended
    -Python 3.11+
    -20GB free disk space for models

2. Create Virtual Environment
    python -m venv venv
    source venv/bin/activate   # Linux/Mac
    venv\Scripts\activate      # Windows


