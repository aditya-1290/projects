"""
classifier.py — Zero-LLM intent classifier and argument extractor.

Sits at the entry point of run_system() BEFORE the planner.

Query types:
  conversational   → greetings, small talk, identity questions, general knowledge
                     → goes straight to run_agent(), no tools, no evaluator
  simple_tool      → single known tool, args extractable from keywords
                     → bypasses planner AND evaluator
  complex          → multi-step, ambiguous, or no keyword match
                     → falls through to full planner + evaluator cycle

FIXES in this version:
  1. Conversational check is no longer anchored to full string — partial match
     catches "Hello! How are you today?" and similar mixed greetings
  2. Added identity/general-knowledge triggers ("who built you", "what are you",
     "explain X", "tell me about X") — routes to conversational, skips tools
  3. City extractor now has a broader ignore list to stop words like
     "Hello", "Today", "Latest", "Tell" being geocoded as cities
  4. Date trigger "today" now ignored when surrounded by greeting words
"""

import re

# ---------------------------------------------------------------------------
# CONVERSATIONAL — check FIRST before anything else
# Now uses search() not match() — catches greetings anywhere in the string
# Also covers identity + general knowledge questions
# ---------------------------------------------------------------------------
_GREETING_PATTERNS = re.compile(
    r"\b(hi+|hello+|hey+|howdy|good\s*(morning|afternoon|evening|night)"
    r"|how are you|how's it going|how do you do"
    r"|thanks?|thank you|bye|goodbye|see you"
    r"|ok|okay|cool|great|awesome|got it|nice|sure|sounds good)\b",
    re.IGNORECASE
)

_IDENTITY_PATTERNS = re.compile(
    r"\b(who (are|built|made|created|developed) you"
    r"|what are you|what can you do|what('s| is) your name"
    r"|are you an? (ai|bot|assistant|robot|llm|model)"
    r"|tell me about yourself|introduce yourself"
    r"|who (is|was) (your|the) (creator|developer|maker))\b",
    re.IGNORECASE
)

# Memory/recall queries — "what did I last ask", "do you remember", etc.
# These should go to CONVERSATIONAL so session history handles them
_MEMORY_PATTERNS = re.compile(
    r"\b(last time (i|you)|do you remember|what did i (ask|say|tell)"
    r"|previously|earlier (i|you)|remind me|what was the (last|previous)"
    r"|recall|you (told|said|mentioned))\b",
    re.IGNORECASE
)

_GENERAL_KNOWLEDGE_PATTERNS = re.compile(
    r"\b(explain|describe|what is|what are|what('s| is) the difference"
    r"|differentiate|compare|define|tell me about|how does|why is|why are"
    r"|give me an? (overview|summary|explanation|example))\b",
    re.IGNORECASE
)

# Words that signal the query is NOT purely conversational even if it
# contains a greeting word — forces tool path
_TOOL_OVERRIDE_PATTERNS = re.compile(
    r"\b(weather|temperature|time|date|stock|price|gold|currency|convert|news|calculate|sqrt)\b",
    re.IGNORECASE
)

# ---------------------------------------------------------------------------
# TOOL TRIGGERS
# ---------------------------------------------------------------------------
_WEATHER_TRIGGERS = re.compile(
    r"\b(weather|temperature|temp|humid|rain|forecast|hot|cold|climate)\b",
    re.IGNORECASE
)

_TIME_TRIGGERS = re.compile(
    r"\b(time|clock|timezone|what time|current time)\b",
    re.IGNORECASE
)

_DATE_TRIGGERS = re.compile(
    r"\b(date|day|what day|which day)\b"  # ← removed "today" — causes false positives
    r"|\btoday'?s?\s+(date|day)\b",  # only match "today" when paired with date/day
    re.IGNORECASE
)

_CURRENCY_TRIGGERS = re.compile(
    r"\b(convert|conversion|exchange|rate)\b.*\b(usd|inr|eur|gbp|jpy|aed|cad|aud|chf|sgd|currency)\b"
    r"|\b(usd|inr|eur|gbp|jpy|aed|cad|aud|chf|sgd)\b.*\b(to|in|into)\b.*\b(usd|inr|eur|gbp|jpy|aed|cad|aud|chf|sgd)\b",
    re.IGNORECASE
)

_STOCK_TRIGGERS = re.compile(
    r"\b(stock|share|price of|ticker|market cap|nifty|sensex|nasdaq|dow jones|s&p)\b",
    re.IGNORECASE
)

_GOLD_TRIGGERS = re.compile(
    r"\b(gold price|price of gold|gold today|gold rate|xau|gold stock)\b",
    re.IGNORECASE
)

_NEWS_TRIGGERS = re.compile(
    r"\b(news|headlines|latest news|news updates?)\b",
    re.IGNORECASE
)

_CALC_TRIGGERS = re.compile(
    r"\b(calculate|compute|how much is|result of|solve|sqrt|square root)\b.*[\d\+\-\*\/\(\)]"
    r"|[\d]+\s*[\+\-\*\/\%\*\*]\s*[\d]",
    re.IGNORECASE
)

# Multi-step signals → force complex (except currency "to" queries)
_MULTI_SIGNALS = re.compile(
    r"\b(and|also|then|compare|vs|versus|difference between|both|all)\b",
    re.IGNORECASE
)

# ---------------------------------------------------------------------------
# Known stock tickers
# ---------------------------------------------------------------------------
_TICKER_MAP = {
    "apple": "AAPL", "tesla": "TSLA", "google": "GOOGL", "alphabet": "GOOGL",
    "microsoft": "MSFT", "amazon": "AMZN", "meta": "META", "facebook": "META",
    "netflix": "NFLX", "nvidia": "NVDA", "amd": "AMD", "intel": "INTC",
    "dow jones": "^DJI", "dow": "^DJI", "s&p 500": "^GSPC", "s&p": "^GSPC",
    "nasdaq": "^IXIC",
    "tcs": "TCS.NS", "tata consultancy": "TCS.NS",
    "infosys": "INFY.NS", "infy": "INFY.NS",
    "wipro": "WIPRO.NS",
    "reliance": "RELIANCE.NS", "reliance industries": "RELIANCE.NS",
    "hdfc bank": "HDFCBANK.NS", "hdfc": "HDFCBANK.NS",
    "icici": "ICICIBANK.NS", "icici bank": "ICICIBANK.NS",
    "nifty": "^NSEI", "nifty 50": "^NSEI",
    "sensex": "^BSESN",
}

# newsdata.io valid category names
_NEWS_TOPICS = {
    "technology", "business", "sports", "politics", "science",
    "health", "entertainment", "world", "environment", "food",
    "tourism", "top",
}

# Map common user words → newsdata.io categories
_NEWS_TOPIC_MAP = {
    "tech": "technology",
    "finance": "business",
    "financial": "business",
    "economy": "business",
    "sport": "sports",
    "crypto": "technology",
    "general": "top",
    "latest": "top",
    "breaking": "top",
    "education": "science",
}

_CURRENCY_CODES = {
    "usd", "inr", "eur", "gbp", "jpy", "aed", "cad", "aud", "chf", "sgd",
    "cny", "hkd", "nzd", "sek", "nok", "dkk", "mxn", "brl", "zar", "thb",
}

_CURRENCY_WORDS = {
    "dollar": "USD", "dollars": "USD", "usd": "USD",
    "rupee": "INR", "rupees": "INR", "inr": "INR",
    "euro": "EUR", "euros": "EUR", "eur": "EUR",
    "pound": "GBP", "pounds": "GBP", "gbp": "GBP",
    "yen": "JPY", "jpy": "JPY",
    "dirham": "AED", "aed": "AED",
    "franc": "CHF", "chf": "CHF",
    "yuan": "CNY", "cny": "CNY",
}

# ---------------------------------------------------------------------------
# City extractor — expanded ignore list to stop common words being geocoded
# ---------------------------------------------------------------------------
_CITY_IGNORE = {
    # Greetings and filler
    "Hello", "Hey", "Hi", "Howdy", "Okay", "Thanks", "Sure",
    # Question words
    "What", "How", "The", "Can", "Tell", "Show", "Get", "Give",
    # Time words
    "Current", "Today", "Latest", "Now", "Recent", "Live",
    # Other common caps
    "Please", "Help", "Find", "Check", "News", "Stock", "Price",
    "Weather", "Time", "Date", "Gold", "Silver", "Update",
}


def _extract_city(text: str) -> str | None:
    """
    Extract a city from patterns like:
      "weather in Mumbai", "time in New York", "weather Tokyo"
    Returns None if no city found.
    """
    # "in/for/at/of <City>" — most reliable pattern
    match = re.search(r"\b(?:in|for|at|of)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)", text)
    if match:
        candidate = match.group(1).strip()
        if candidate not in _CITY_IGNORE:
            return candidate

    # Last capitalised word(s) as fallback
    matches = re.findall(r"\b([A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})?)\b", text)
    cities = [m for m in matches if m not in _CITY_IGNORE]
    if cities:
        return cities[-1]

    return None


def _extract_ticker(text: str) -> str | None:
    lower = text.lower()
    for name, ticker in sorted(_TICKER_MAP.items(), key=lambda x: -len(x[0])):
        if name in lower:
            return ticker
    raw = re.search(r"\b([A-Z]{2,5}(?:\.[A-Z]{2})?|\^[A-Z]{2,5})\b", text)
    if raw:
        return raw.group(1)
    return None


def _extract_currency_args(text: str) -> dict | None:
    amount_match = re.search(r"(\d+(?:\.\d+)?)", text)
    if not amount_match:
        return None
    amount = float(amount_match.group(1))
    lower = text.lower()
    found = []
    for word, code in _CURRENCY_WORDS.items():
        if re.search(r"\b" + word + r"\b", lower):
            found.append((lower.index(word), code))
    for code in _CURRENCY_CODES:
        if re.search(r"\b" + code + r"\b", lower):
            found.append((lower.index(code), code.upper()))
    if len(found) < 2:
        return None
    found.sort(key=lambda x: x[0])
    from_currency = found[0][1]
    to_currency = found[1][1]
    if from_currency == to_currency:
        return None
    return {"amount": amount, "from_currency": from_currency, "to_currency": to_currency}


def _extract_news_topic(text: str) -> str:
    """
    Extract news topic/keyword from user query.

    Two cases:
      1. Broad category ("tech news", "sports headlines") → return mapped category
      2. Company/product/keyword ("news about NVIDIA", "Apple news") → return as-is keyword

    The get_news tool handles routing:
      valid category → category= param
      anything else  → q= keyword search
    """
    lower = text.lower()

    # "news on/about/for X" pattern — extract X as keyword (preserving case)
    match = re.search(r"\bnews\s+(?:on|about|for|regarding|of)\s+([\w\s]+)", text, re.IGNORECASE)
    if match:
        keyword = match.group(1).strip().split()[0]  # first word after "about"
        # If it's a mapped category word, return the category
        if keyword.lower() in _NEWS_TOPIC_MAP:
            return _NEWS_TOPIC_MAP[keyword.lower()]
        if keyword.lower() in _NEWS_TOPICS:
            return keyword.lower()
        # Otherwise it's a company/product keyword — return as-is for q= search
        return keyword

    # Check topic map first (finance → business etc.)
    for word, mapped in _NEWS_TOPIC_MAP.items():
        if re.search(r"\b" + word + r"\b", lower):
            return mapped

    # Check exact category names
    for topic in _NEWS_TOPICS:
        if re.search(r"\b" + topic + r"\b", lower):
            return topic

    # Last word before "news" might be the keyword
    # e.g. "NVIDIA news" → "NVIDIA"
    match = re.search(r"([\w]+)\s+news", text, re.IGNORECASE)
    if match:
        word = match.group(1)
        if word.lower() not in ("latest", "recent", "current", "today", "breaking", "top"):
            if word.lower() in _NEWS_TOPIC_MAP:
                return _NEWS_TOPIC_MAP[word.lower()]
            if word.lower() not in _NEWS_TOPICS:
                return word  # company/product keyword

    return "top"


def _extract_math_expression(text: str) -> str | None:
    expr = re.search(
        r"([\d\s\+\-\*\/\%\(\)\.\*\*]+(?:sqrt|log|abs|ceil|floor|round|pi|e)?[\d\s\+\-\*\/\%\(\)\.]*)",
        text
    )
    if expr:
        candidate = expr.group(1).strip()
        if any(op in candidate for op in ["+", "-", "*", "/", "**", "%"]) or re.search(r"\d", candidate):
            return candidate
    sqrt_match = re.search(r"sqrt\s+(?:of\s+)?(\d+(?:\.\d+)?)", text, re.IGNORECASE)
    if sqrt_match:
        return f"sqrt({sqrt_match.group(1)})"
    return None


# ---------------------------------------------------------------------------
# Query class constants
# ---------------------------------------------------------------------------
class QueryClass:
    SIMPLE_TOOL = "simple_tool"
    CONVERSATIONAL = "conversational"
    COMPLEX = "complex"


# ---------------------------------------------------------------------------
# Main classifier
# ---------------------------------------------------------------------------
def classify(user_input: str) -> dict:
    text = user_input.strip()

    # ── Step 1: Check for tool keywords first ────────────────────────────
    # If the message contains tool keywords, skip conversational check
    has_tool_keyword = bool(_TOOL_OVERRIDE_PATTERNS.search(text))

    # ── Step 2: Conversational check ─────────────────────────────────────
    # Catches greetings, identity questions, general knowledge
    # Only skipped if explicit tool keywords are present
    if not has_tool_keyword:
        if (_GREETING_PATTERNS.search(text)
                or _IDENTITY_PATTERNS.search(text)
                or _MEMORY_PATTERNS.search(text)
                or _GENERAL_KNOWLEDGE_PATTERNS.search(text)):
            return {"type": QueryClass.CONVERSATIONAL, "skip_evaluator": True}

    # ── Step 3: Multi-step signal → always complex ────────────────────────
    is_currency_query = bool(_CURRENCY_TRIGGERS.search(text))
    if _MULTI_SIGNALS.search(text) and not is_currency_query:
        return {"type": QueryClass.COMPLEX, "skip_evaluator": False}

    # ── Step 4: Gold ──────────────────────────────────────────────────────
    if _GOLD_TRIGGERS.search(text):
        return {
            "type": QueryClass.SIMPLE_TOOL,
            "plan": {"steps": [{"task": "Get current gold price", "agent": "finance",
                                "tool": "get_gold_price", "args": {}}]},
            "skip_evaluator": True
        }

    # ── Step 5: Weather ───────────────────────────────────────────────────
    if _WEATHER_TRIGGERS.search(text):
        city = _extract_city(text)
        if city:
            return {
                "type": QueryClass.SIMPLE_TOOL,
                "plan": {"steps": [{"task": f"Get weather in {city}", "agent": "weather",
                                    "tool": "get_weather", "args": {"city": city, "unit": "celsius"}}]},
                "skip_evaluator": True
            }

    # ── Step 6: Time ──────────────────────────────────────────────────────
    if _TIME_TRIGGERS.search(text) and not _DATE_TRIGGERS.search(text):
        city = _extract_city(text)
        if city:
            return {
                "type": QueryClass.SIMPLE_TOOL,
                "plan": {"steps": [{"task": f"Get current time in {city}", "agent": "time",
                                    "tool": "get_current_time", "args": {"city": city}}]},
                "skip_evaluator": True
            }

    # ── Step 7: Date ──────────────────────────────────────────────────────
    if _DATE_TRIGGERS.search(text):
        city = _extract_city(text)
        if city:
            return {
                "type": QueryClass.SIMPLE_TOOL,
                "plan": {"steps": [{"task": f"Get date info for {city}", "agent": "time",
                                    "tool": "get_date_info", "args": {"city": city}}]},
                "skip_evaluator": True
            }

    # ── Step 8: Currency ──────────────────────────────────────────────────
    if is_currency_query:
        args = _extract_currency_args(text)
        if args:
            return {
                "type": QueryClass.SIMPLE_TOOL,
                "plan": {
                    "steps": [{"task": f"Convert {args['amount']} {args['from_currency']} to {args['to_currency']}",
                               "agent": "finance", "tool": "convert_currency", "args": args}]},
                "skip_evaluator": True
            }

    # ── Step 9: Stock ─────────────────────────────────────────────────────
    if _STOCK_TRIGGERS.search(text):
        ticker = _extract_ticker(text)
        if ticker:
            return {
                "type": QueryClass.SIMPLE_TOOL,
                "plan": {"steps": [{"task": f"Get stock price for {ticker}", "agent": "finance",
                                    "tool": "get_stock_price", "args": {"ticker": ticker}}]},
                "skip_evaluator": True
            }

    # ── Step 10: News / Info → Web Search (UPGRADED) ──────────────────────
    if _NEWS_TRIGGERS.search(text) or any(word in text.lower() for word in ["about", "latest", "info"]):
        return {
            "type": QueryClass.SIMPLE_TOOL,
            "plan": {"steps": [{
                "task": f"Search web for: {text}",
                "agent": "search",
                "tool": "web_search",
                "args": {"query": text}
            }]},
            "skip_evaluator": True
        }
    # ── Step 11: Calculator ───────────────────────────────────────────────
    if _CALC_TRIGGERS.search(text):
        expr = _extract_math_expression(text)
        if expr:
            return {
                "type": QueryClass.SIMPLE_TOOL,
                "plan": {"steps": [{"task": f"Calculate: {expr}", "agent": "general",
                                    "tool": "calculate", "args": {"expression": expr}}]},
                "skip_evaluator": True
            }

    # ── Default: planner handles it ───────────────────────────────────────
    return {"type": QueryClass.COMPLEX, "skip_evaluator": False}
