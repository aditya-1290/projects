"""
agent_qwen.py — Core agent with structured message building and session isolation.

Phase 1 upgrade: Structured context via role=tool messages.
Phase 2 upgrade: Session isolation for multi-user deployment.

WHY THIS MATTERS:
  Old way: tool results → dumped as a string inside user message
  New way: tool results → passed as role="tool" messages

  LLMs are trained with tool result messages. Passing results as
  role=tool means the model treats them as ground truth, not just
  text it read somewhere. This alone fixes many hallucinations.

Context priority order (highest → lowest):
  1. role=tool results     (highest — LLM trusts these most)
  2. role=user query       (current intent)
  3. role=assistant/user   (session history — last 6 turns, isolated per session)
  4. role=system memory    (lowest — background context)
"""

import json
import os
import uuid
from datetime import datetime
from typing import Optional, List, Dict, Any

from llm import llm
from logger import log
from memory_store import retrieve_memory, store_memory

MEMORY_FILE = "memory.json"


# ---------------------------------------------------------------------------
# Session Management — ISOLATED PER USER
# ---------------------------------------------------------------------------
class SessionManager:
    """Manages isolated conversation history per session."""

    def __init__(self):
        self._sessions: Dict[str, List[Dict[str, str]]] = {}
        self._session_metadata: Dict[str, Dict[str, Any]] = {}

    def get_history(self, session_id: str) -> List[Dict[str, str]]:
        """Get conversation history for a session."""
        if session_id not in self._sessions:
            self._sessions[session_id] = []
            self._session_metadata[session_id] = {
                "created_at": datetime.now().isoformat(),
                "message_count": 0,
            }
        return self._sessions[session_id]

    def add_exchange(self, session_id: str, user_msg: str, assistant_msg: str) -> None:
        """Add a user-assistant exchange to session history."""
        history = self.get_history(session_id)
        history.append({"role": "user", "content": user_msg})
        history.append({"role": "assistant", "content": assistant_msg})

        # Trim to last 10 turns (20 messages) to prevent memory bloat
        if len(history) > 20:
            self._sessions[session_id] = history[-20:]

        self._session_metadata[session_id]["message_count"] += 2
        self._session_metadata[session_id]["last_active"] = datetime.now().isoformat()

    def clear_session(self, session_id: str) -> None:
        """Clear a specific session."""
        if session_id in self._sessions:
            del self._sessions[session_id]
            del self._session_metadata[session_id]
            log.debug(f"[Session] Cleared session {session_id[:8]}...")

    def clear_all_sessions(self) -> int:
        """Clear all sessions. Returns number of sessions cleared."""
        count = len(self._sessions)
        self._sessions.clear()
        self._session_metadata.clear()
        log.info(f"[Session] Cleared all {count} sessions")
        return count

    def get_stats(self) -> Dict[str, Any]:
        """Get session statistics."""
        return {
            "active_sessions": len(self._sessions),
            "total_messages": sum(m.get("message_count", 0) for m in self._session_metadata.values()),
            "sessions": [
                {
                    "id": sid[:8] + "...",
                    "messages": len(hist),
                    "created": meta.get("created_at"),
                    "last_active": meta.get("last_active"),
                }
                for sid, hist in self._sessions.items()
                for meta in [self._session_metadata.get(sid, {})]
            ]
        }

    def cleanup_stale_sessions(self, max_age_hours: int = 24) -> int:
        """Remove sessions older than max_age_hours."""
        now = datetime.now()
        stale_sessions = []

        for sid, meta in self._session_metadata.items():
            last_active = meta.get("last_active")
            if last_active:
                try:
                    last_time = datetime.fromisoformat(last_active)
                    age_hours = (now - last_time).total_seconds() / 3600
                    if age_hours > max_age_hours:
                        stale_sessions.append(sid)
                except (ValueError, TypeError):
                    pass

        for sid in stale_sessions:
            self.clear_session(sid)

        if stale_sessions:
            log.info(f"[Session] Cleaned up {len(stale_sessions)} stale sessions")
        return len(stale_sessions)


# Global session manager
session_manager = SessionManager()

# Backward compatibility: global session_history for single-user mode
session_history = []


# ---------------------------------------------------------------------------
# Memory File Management (Long-term storage, shared across sessions)
# ---------------------------------------------------------------------------
def _load_memory_file() -> list:
    if not os.path.exists(MEMORY_FILE):
        return []
    try:
        with open(MEMORY_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data if isinstance(data, list) else []
    except (json.JSONDecodeError, IOError):
        log.warning("[Memory] memory.json corrupt — starting fresh")
        return []


def _append_memory_file(query: str, answer: str, session_id: Optional[str] = None) -> None:
    """Append to memory.json with strong deduplication and session tracking."""
    entries = _load_memory_file()
    query_lower = query.lower().strip()
    answer_lower = answer.lower().strip()

    # Check ALL entries for duplicates
    for entry in entries:
        entry_query = entry.get("query", "").lower().strip()
        entry_answer = entry.get("answer", "").lower().strip()

        # Same query with same answer → skip
        if entry_query == query_lower and entry_answer == answer_lower:
            log.debug(f"[Memory] Duplicate skipped: '{query[:40]}'")
            return

    entries.append({
        "timestamp": datetime.now().isoformat(),
        "query": query,
        "answer": answer,
        "session_id": session_id[:8] + "..." if session_id else None,
    })

    # Trim to last 1000 entries to prevent file bloat
    if len(entries) > 1000:
        entries = entries[-1000:]

    try:
        with open(MEMORY_FILE, "w", encoding="utf-8") as f:
            json.dump(entries, f, indent=2, ensure_ascii=False)
        log.debug(f"[Memory] Saved ({len(entries)} total entries)")
    except IOError as e:
        log.error(f"[Memory] Write failed: {e}")


# ---------------------------------------------------------------------------
# System Prompt
# ---------------------------------------------------------------------------
SYSTEM_PROMPT = """
You are a helpful AI assistant with access to real-time tool results.

Your job:
- Use tool results to answer the user in natural, conversational language
- If tool results are present → ALWAYS use them, never ignore them
- If no tool results → answer from your knowledge

Formatting rules:
- Write in full sentences, NOT raw key-value pairs
- BAD:  "temperature: 34°C, feels_like: 36°C"
- GOOD: "The current temperature in Mumbai is 34°C, feeling like 36°C with 43% humidity."
- For news → list article titles with sources naturally
- For stocks → mention price, exchange, and currency in a sentence
- For time → say it naturally: "It's 2:41 PM on Saturday in Mumbai"
- For unit conversions → state clearly: "10 kilometers is approximately 6.21 miles"
- Keep answers concise but human-readable

Other rules:
- NEVER simulate tool calls
- NEVER say you cannot access tools
- NEVER suggest the user try again
- For follow-up questions ("what about Paris?") use conversation history
"""


# ---------------------------------------------------------------------------
# Message Building
# ---------------------------------------------------------------------------
def _build_messages(
        user_input: str,
        tool_results: Optional[List[Dict]] = None,
        session_id: Optional[str] = None
) -> list:
    """
    Build structured message list with correct priority order.

    Priority (highest to lowest):
      1. System prompt
      2. Long-term memory (background, shared)
      3. Session history (last 6 turns, isolated per session)
      4. Tool results as role=system messages
      5. Current user query
    """
    relevant_memories = retrieve_memory(user_input)

    messages = [{"role": "system", "content": SYSTEM_PROMPT}]

    # Long-term memory — lowest priority, injected as system context
    if relevant_memories:
        memory_texts = [m.get("text", "") for m in relevant_memories[:3]]
        memory_content = "\n".join(memory_texts)
        log.debug(f"[Memory] Injecting {len(relevant_memories)} memories")
        messages.append({
            "role": "system",
            "content": f"Relevant past context (background only):\n{memory_content}"
        })

    # Session history — conversational context (ISOLATED)
    if session_id:
        history = session_manager.get_history(session_id)
        if history:
            messages.extend(history[-6:])  # Last 3 exchanges
    elif session_history:
        # Backward compatibility for single-user mode
        messages.extend(session_history[-6:])

    # Tool results — injected as role=system message BEFORE user query
    if tool_results:
        def _truncate_result(result: dict, max_chars: int = 600) -> dict:
            """Truncate large tool results to prevent context window overflow."""
            if result.get("articles"):
                return {
                    **{k: v for k, v in result.items() if k != "articles"},
                    "articles": [
                        {
                            "title": a.get("title"),
                            "source": a.get("source"),
                            "url": a.get("url")
                        }
                        for a in result.get("articles", [])[:3]
                    ]
                }
            if result.get("results"):  # web_search results
                return {
                    **{k: v for k, v in result.items() if k != "results"},
                    "results": [
                        {"title": r.get("title"), "snippet": (r.get("snippet") or "")[:150]}
                        for r in result.get("results", [])[:3]
                    ]
                }
            raw = json.dumps(result, ensure_ascii=False)
            if len(raw) > max_chars:
                return {"truncated": True, "preview": raw[:max_chars] + "..."}
            return result

        formatted = "\n\n".join(
            f"[Tool: {r.get('tool', 'unknown')}]\n"
            f"Task: {r.get('task', 'N/A')}\n"
            f"Result:\n{json.dumps(_truncate_result(r.get('result', {})), indent=2, ensure_ascii=False)}"
            for r in tool_results
        )
        messages.append({
            "role": "system",
            "content": (
                    "TOOL EXECUTION RESULTS (treat as ground truth):\n\n"
                    + formatted +
                    "\n\nYou MUST use these results to answer. "
                    "Do NOT say data is unavailable."
            ),
        })
        log.debug(f"[Agent] Injected {len(tool_results)} tool result(s) as role=system")

    # Current user query — always last
    messages.append({"role": "user", "content": user_input})
    return messages


def _extract_user_query(user_input: str) -> str:
    """Strip orchestrator wrapper — only store the real user question."""
    marker = "User Query:"
    if marker in user_input:
        after = user_input.split(marker, 1)[1].strip()
        for stop in ("Execution Results", "Tool Results:", "Rules:", "Answer:"):
            if stop in after:
                after = after.split(stop, 1)[0]
        return after.strip()
    return user_input.strip()


def _should_store(answer: str) -> bool:
    """Determine if an answer should be stored in long-term memory."""
    if not answer or not answer.strip():
        return False
    if "<tool_call>" in answer:
        return False
    if len(answer) < 20:  # Too short to be meaningful
        return False
    # Skip error messages
    skip_phrases = ["error", "sorry", "could not", "unable to", "no relevant data"]
    answer_lower = answer.lower()
    if any(phrase in answer_lower for phrase in skip_phrases):
        return False
    return True


# ---------------------------------------------------------------------------
# Main Agent Functions
# ---------------------------------------------------------------------------
def run_agent(
        user_input: str,
        tool_results: Optional[List[Dict]] = None,
        session_id: Optional[str] = None
) -> str:
    """
    Standard blocking agent with session isolation.

    Args:
        user_input:   The user's question or orchestrator prompt
        tool_results: List of tool result dicts to inject
        session_id:   Unique session identifier for conversation isolation
    """
    messages = _build_messages(user_input, tool_results=tool_results, session_id=session_id)
    log.debug(
        f"[Agent] Calling LLM with {len(messages)} messages (session: {session_id[:8] if session_id else 'none'}...)")

    response = llm.chat(messages)
    answer = response.get("content", "")

    clean_query = _extract_user_query(user_input)

    # Store in session history (isolated)
    if session_id:
        session_manager.add_exchange(session_id, clean_query, answer)
    else:
        # Backward compatibility
        global session_history
        session_history.append({"role": "user", "content": clean_query})
        session_history.append({"role": "assistant", "content": answer})

    # Store in long-term memory if meaningful
    if _should_store(answer):
        store_memory(
            answer,
            metadata={
                "source": "agent_response",
                "query": clean_query,
                "session_id": session_id[:8] if session_id else None
            }
        )
        _append_memory_file(clean_query, answer, session_id)

    return answer


def stream_agent(
        user_input: str,
        tool_results: Optional[List[Dict]] = None,
        session_id: Optional[str] = None
):
    """
    Streaming agent — yields tokens as generated.
    """
    messages = _build_messages(user_input, tool_results=tool_results, session_id=session_id)
    full_answer = ""

    for token in llm.stream_chat(messages):
        full_answer += token
        yield token

    clean_query = _extract_user_query(user_input)

    # Store in session history
    if session_id:
        session_manager.add_exchange(session_id, clean_query, full_answer)
    else:
        global session_history
        session_history.append({"role": "user", "content": clean_query})
        session_history.append({"role": "assistant", "content": full_answer})

    # Store in long-term memory
    if _should_store(full_answer):
        store_memory(
            full_answer,
            metadata={
                "source": "agent_response",
                "query": clean_query,
                "session_id": session_id[:8] if session_id else None
            }
        )
        _append_memory_file(clean_query, full_answer, session_id)


# ---------------------------------------------------------------------------
# Session Management Functions (for API)
# ---------------------------------------------------------------------------
def create_session() -> str:
    """Create a new session and return its ID."""
    session_id = str(uuid.uuid4())
    session_manager.get_history(session_id)  # Initialize
    log.info(f"[Session] Created session {session_id[:8]}...")
    return session_id


def clear_session(session_id: str) -> bool:
    """Clear a specific session."""
    session_manager.clear_session(session_id)
    return True


def get_session_stats() -> Dict[str, Any]:
    """Get session statistics."""
    return session_manager.get_stats()


def cleanup_stale_sessions(max_age_hours: int = 24) -> int:
    """Clean up stale sessions."""
    return session_manager.cleanup_stale_sessions(max_age_hours)


# ---------------------------------------------------------------------------
# CLI Entry Point
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    # Single-user mode with default session
    default_session = create_session()
    log.info(f"Agent started. Session: {default_session[:8]}... Type 'exit' to quit.")

    while True:
        user_input = input("\nYou: ").strip()

        if not user_input:
            continue

        if user_input.lower() == "exit":
            log.info("Shutting down.")
            break

        if user_input.lower() == "clear":
            clear_session(default_session)
            default_session = create_session()
            print("Session cleared. New session created.")
            continue

        if user_input.lower() == "stats":
            stats = get_session_stats()
            print(f"\n📊 Session Stats:")
            print(f"  Active sessions: {stats['active_sessions']}")
            print(f"  Total messages: {stats['total_messages']}")
            continue

        answer = run_agent(user_input, session_id=default_session)
        print(f"\nAgent: {answer}")
