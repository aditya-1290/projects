"""
response_cache.py — Cache for final agent responses.
"""

import hashlib
import time
from typing import Optional, Dict, Any

from logger import log


class ResponseCache:
    """TTL cache for final agent responses."""

    def __init__(self, default_ttl: int = 3600):
        """
        Args:
            default_ttl: Default time-to-live in seconds (1 hour)
        """
        self._store: Dict[str, Dict[str, Any]] = {}
        self.default_ttl = default_ttl
        self._hits = 0
        self._misses = 0

    def _make_key(self, query: str) -> str:
        """Create cache key from query."""
        normalized = query.lower().strip()
        return hashlib.md5(normalized.encode()).hexdigest()

    def get(self, query: str) -> Optional[str]:
        """Get cached response if not expired."""
        key = self._make_key(query)
        entry = self._store.get(key)

        if entry is None:
            self._misses += 1
            return None

        age = time.time() - entry["stored_at"]
        if age > entry["ttl"]:
            del self._store[key]
            self._misses += 1
            log.debug(f"[ResponseCache] EXPIRED: {query[:50]}...")
            return None

        self._hits += 1
        log.info(f"[ResponseCache] ✅ HIT: {query[:50]}... (age={age:.0f}s)")
        return entry["response"]

    def set(self, query: str, response: str, ttl: Optional[int] = None) -> None:
        """Store response in cache."""
        if ttl is None:
            # Shorter TTL for time-sensitive queries
            time_keywords = ["time", "weather", "stock", "price", "gold", "news"]
            query_lower = query.lower()
            if any(kw in query_lower for kw in time_keywords):
                ttl = 300  # 5 minutes for time-sensitive queries
            else:
                ttl = self.default_ttl

        key = self._make_key(query)
        self._store[key] = {
            "query": query,
            "response": response,
            "stored_at": time.time(),
            "ttl": ttl,
        }
        log.info(f"[ResponseCache] 💾 STORED: {query[:50]}... (TTL={ttl}s)")

    def invalidate(self, query: Optional[str] = None) -> int:
        """Invalidate cache entries."""
        if query is None:
            count = len(self._store)
            self._store.clear()
            return count

        key = self._make_key(query)
        if key in self._store:
            del self._store[key]
            return 1
        return 0

    def stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        total = self._hits + self._misses
        hit_rate = round(self._hits / total * 100, 1) if total > 0 else 0.0
        return {
            "entries": len(self._store),
            "hits": self._hits,
            "misses": self._misses,
            "hit_rate": f"{hit_rate}%",
        }

    def cleanup_expired(self) -> int:
        """Remove all expired entries."""
        now = time.time()
        expired_keys = [
            k for k, v in self._store.items()
            if now - v["stored_at"] > v["ttl"]
        ]
        for k in expired_keys:
            del self._store[k]
        return len(expired_keys)


# Global singleton
response_cache = ResponseCache()
