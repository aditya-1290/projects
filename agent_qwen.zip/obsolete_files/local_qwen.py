from llama_cpp import Llama
import multiprocessing

MODEL_PATH = "D:/python_tasks/models/qwen_q4.gguf"

n_threads = multiprocessing.cpu_count()

llm = Llama(
    model_path=MODEL_PATH,
    n_ctx=2048,
    n_threads=n_threads,
    n_batch=256,
    use_mmap=True,
    use_mlock=False,
)

print("Model loaded ✅")

output = llm.create_chat_completion(
    messages=[
        {"role": "user", "content": "Hello"}
    ]
)

print(output["choices"][0]["message"]["content"])