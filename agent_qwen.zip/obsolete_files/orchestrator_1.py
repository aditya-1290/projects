from planner import create_plan
from evaluator import evaluate
# from router import route_task
from agent_qwen import run_agent

from weather_agent import weather_agent
from finance_agent import finance_agent
from time_agent import time_agent

def run_system(user_input):
    context = ""
    MAX_CYCLES = 3
    final_answer = ""
    failed_tools = set()

    for cycle in range(MAX_CYCLES):
        print(f"\n=== Cycle {cycle+1} ===")

        plan = create_plan(user_input)

        for step in plan.get("steps", []):
            task = step["task"].strip()

            # Remove accidental junk
            if "context:" in task.lower():
                task = task.split("context:")[0].strip()

            agent_type = step.get("agent", "general")
            tool_name = step.get("tool")

            print(f"\n[Planner → {agent_type.upper()} | Tool → {tool_name}]")
            # 🔥 TOOL-DRIVEN EXECUTION
            if tool_name:
                from tools import TOOL_REGISTRY

                if tool_name in failed_tools:
                    print(f"[Skipping failed tool: {tool_name}]")
                    continue

                if tool_name in TOOL_REGISTRY:
                    print(f"[Direct Tool Execution] {tool_name}")

                    try:
                        # 🔥 (still simple args for now)
                        if tool_name == "get_weather":
                            result = TOOL_REGISTRY[tool_name](city="Mumbai")
                        elif tool_name == "convert_currency":
                            result = TOOL_REGISTRY[tool_name](amount=100, from_currency="USD", to_currency="INR")
                        else:
                            result = TOOL_REGISTRY[tool_name]()

                    except Exception as e:
                        result = {"status": "error", "message": str(e)}

                else:
                    result = {"status": "error", "message": "Invalid tool"}
            else:
                if agent_type == "weather":
                    result = weather_agent(task)
                elif agent_type == "finance":
                    result = finance_agent(task)
                elif agent_type == "time":
                    result = time_agent(task)
                else:
                    result = run_agent(task) # fallback

            failure = False
            error_message = ""

            if isinstance(result, dict) and result.get("status") == "error":
                print("[Failure Detected]")
                failure = True
                error_message = result.get("message", "Unknown error")
                failed_tools.add(tool_name)

            if failure:
                print("\n[Replanning due to failure]")

                # Inject failure info into next planning cycle
                user_input += f"\n\nPrevious step failed: {error_message}"

                break  # 🔥 exit step loop → go to next cycle

            print(f"[Result] {result}")

            context += f"\nStep: {task}\nResult: {str(result)}\n"

        final_answer = run_agent(
            f"Based on this context:\n{context}\n\nProvide final answer to user."
        )

        print("\n[Final Answer]")
        print(final_answer)

        eval_result = evaluate(user_input, context)

        if "COMPLETE" in eval_result.upper():
            break

    return final_answer if final_answer else "Sorry, I couldn't complete the task."