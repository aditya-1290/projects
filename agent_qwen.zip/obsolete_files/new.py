"""
orchestrator.py — Multi-cycle agent orchestrator.

Phase 1 upgrades:
  1. Structured tool results → passed as role=tool via run_agent(tool_results=[...])
  2. Tool retry layer — each tool retried up to 2x before marking failed
  3. Evaluator feedback injected into replan prompt — retries are now guided

Phase 2 upgrades:
  4. State passing system between steps
  5. Tool chaining with variable resolution
  6. ReAct reasoning loop with token overflow protection
"""

import json
import re
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Dict, List, Optional

from agent_qwen import run_agent
from cache import tool_cache
from classifier import QueryClass, classify
from evaluator import evaluate
from logger import log
# Import memory functions
from memory_store import store_tool_memory, get_last_exact
from tools import TOOL_REGISTRY

NO_ARG_TOOLS = {"get_gold_price"}
CONFIDENCE_THRESHOLD = 0.6
TOOL_RETRY_COUNT = 2
TOOL_TIMEOUT = 15
MAX_CYCLES = 3
MAX_PROMPT_TOKENS = 3500  # Safe for 4096 context window


# ----------------------------------------------------------------------------
# Token-aware prompt truncation
# ----------------------------------------------------------------------------
def _truncate_prompt_for_context(prompt: str, max_chars: int = 8000) -> str:
    """
    Truncate prompt to fit within context window.
    Rough estimate: 1 token ≈ 4 chars for English text.
    For 3500 tokens, that's ~14,000 chars safe limit.
    """
    if len(prompt) <= max_chars:
        return prompt

    # Keep the beginning (instructions) and end (user query/context)
    half = max_chars // 2
    first_part = prompt[:half]
    last_part = prompt[-half:]

    truncated = first_part + "\n\n[... CONTENT TRUNCATED TO FIT CONTEXT WINDOW ...]\n\n" + last_part
    log.warning(f"[Context] Prompt truncated from {len(prompt)} to {len(truncated)} chars")
    return truncated


# ----------------------------------------------------------------------------
# Variable resolution for tool chaining
# ----------------------------------------------------------------------------
def _resolve_variables(args: dict, state: dict) -> dict:
    """Resolve variables like {get_weather_result.temperature} from state."""

    def resolve(val):
        if not isinstance(val, str):
            return val

        # Pattern: {tool_result.field} or tool_result.field
        pattern = r"\{?(\w+_result)\.(\w+)\}?"
        matches = re.findall(pattern, val)

        for tool_key, field in matches:
            if tool_key in state:
                result_data = state[tool_key]
                if isinstance(result_data, dict):
                    replacement = result_data.get(field)
                    if replacement is not None:
                        val = val.replace(f"{{{tool_key}.{field}}}", str(replacement))
                        val = val.replace(f"{tool_key}.{field}", str(replacement))

        return val

    return {k: resolve(v) for k, v in args.items()}


# ----------------------------------------------------------------------------
# Tool result compression for ReAct
# ----------------------------------------------------------------------------
def _compress_tool_results(tool_results: List[Dict]) -> List[Dict]:
    """Compress tool results to prevent context overflow."""
    compressed = []

    for tr in tool_results[-3:]:  # Keep last 3 results max
        tool = tr.get("tool")
        result = tr.get("result", {})

        simplified = {"tool": tool}

        # Extract only essential fields
        essential_fields = {
            "get_weather": ["temperature", "city", "humidity"],
            "get_stock_price": ["ticker", "price", "currency"],
            "get_gold_price": ["price_per_troy_oz"],
            "convert_currency": ["converted_amount", "exchange_rate"],
            "calculate": ["result"],
            "web_search": ["count"],
            "get_news": ["article_count"],
            "get_current_time": ["datetime", "city"],
            "get_date_info": ["date", "city"],
        }

        fields_to_keep = essential_fields.get(tool, [])
        for key in fields_to_keep:
            if key in result:
                simplified[key] = result[key]

        # Special handling for articles
        if "articles" in result and result["articles"]:
            simplified["articles"] = [
                {"title": a.get("title", "")[:80]}
                for a in result["articles"][:2]
            ]

        # Special handling for web search results
        if "results" in result and result["results"]:
            simplified["results"] = [
                {"title": r.get("title", "")[:60], "snippet": r.get("snippet", "")[:100]}
                for r in result["results"][:3]
            ]

        compressed.append(simplified)

    return compressed


# ----------------------------------------------------------------------------
# ReAct reasoning step with token overflow protection
# ----------------------------------------------------------------------------
def _think_step(
        user_input: str,
        tool_results: List[Dict],
        history: List[str],
        last_tool: Optional[str] = None
) -> Dict:
    """
    ReAct reasoning step with:
    - Token overflow protection
    - Prevention of tool repetition
    - State awareness
    """
    compressed_results = _compress_tool_results(tool_results)

    # Build compact prompt
    prompt = f"""You are an AI agent that MUST use tools. Do NOT guess.

USER QUERY: {user_input}

OBSERVED DATA:
{json.dumps(compressed_results, indent=2)}

AVAILABLE TOOLS:
- web_search(query) → internet search for ANY unknown topic
- get_news(topic) → news by category (technology, business, sports, world, top)
- get_weather(city) → current weather
- calculate(expression) → math evaluation
- get_stock_price(ticker) → stock prices
- get_gold_price() → gold price
- convert_currency(amount, from, to) → currency conversion

CRITICAL RULES:
1. If you have data → return "final" answer
2. If you need data → return "action" with ONE tool
3. NEVER call the same tool twice in a row
4. For general knowledge/definitions → use web_search
5. For news about specific companies → use web_search, not get_news
6. Last tool used: {last_tool or 'none'}

OUTPUT FORMAT (JSON only):
{{"thought": "reasoning", "action": {{"tool": "name", "args": {{...}}}} or null, "final": "answer" or null}}"""

    # Truncate to safe length
    prompt = _truncate_prompt_for_context(prompt)

    # Prevent same tool repetition
    if last_tool:
        prompt += f"\n\nWARNING: Do NOT use '{last_tool}' again. Try a different approach."

    try:
        response = run_agent(prompt)

        # Extract JSON from response
        json_match = re.search(r'\{.*\}', response, re.DOTALL)
        if json_match:
            result = json.loads(json_match.group())

            # Guard against tool repetition
            if result.get("action") and result["action"].get("tool") == last_tool:
                log.warning(f"[ReAct] Blocked repeat of tool '{last_tool}'")
                return {
                    "thought": f"Cannot repeat {last_tool}, need alternative",
                    "action": None,
                    "final": f"Unable to get data. Last attempt with {last_tool} failed."
                }

            return result
    except Exception as e:
        log.error(f"[ReAct] Parse error: {e}")

    return {"thought": "Error in reasoning", "action": None, "final": None}


# ----------------------------------------------------------------------------
# Tool execution with retry and memory storage
# ----------------------------------------------------------------------------
def _call_tool_with_retry(tool_name: str, args: dict) -> dict:
    """
    Call a tool with retries, timeout, and memory storage.
    """
    last_result = {"status": "error", "message": "Tool never executed"}
    start_time = time.time()

    for attempt in range(1, TOOL_RETRY_COUNT + 1):
        try:
            log.info(f"[Tool] {tool_name}({args}) — attempt {attempt}/{TOOL_RETRY_COUNT}")
            result = TOOL_REGISTRY[tool_name](**args)

            latency = round((time.time() - start_time) * 1000, 0)
            log.info(f"[Tool] {tool_name} completed in {latency}ms")

            if result.get("status") == "success":
                # Store successful tool result in memory
                store_tool_memory(tool_name, args, result)
                return result

            last_result = result
            if attempt < TOOL_RETRY_COUNT:
                wait = attempt
                log.warning(f"[Tool] '{tool_name}' failed — retrying in {wait}s")
                time.sleep(wait)

        except Exception as e:
            last_result = {"status": "error", "message": str(e)}
            log.error(f"[Tool] '{tool_name}' exception: {e}")
            if attempt < TOOL_RETRY_COUNT:
                time.sleep(attempt)

    log.error(f"[Tool] '{tool_name}' failed after {TOOL_RETRY_COUNT} attempts")
    return last_result


# ----------------------------------------------------------------------------
# Step execution with cache and memory awareness
# ----------------------------------------------------------------------------
def _execute_step(step: dict, failed_tools: set, state: dict) -> dict:
    """Execute a single plan step with cache check, memory awareness, and retry."""
    task = step.get("task", "").strip()
    tool_name = step.get("tool")
    args = step.get("args", {})

    # Resolve variables from state
    args = _resolve_variables(args, state)

    if not tool_name:
        return {
            "step": step, "task": task, "tool": None,
            "result": {"status": "skipped", "message": "No tool"},
            "failure": False,
        }

    if tool_name in failed_tools:
        log.warning(f"[Execute] Skipping failed tool: {tool_name}")
        return {
            "step": step, "task": task, "tool": tool_name,
            "result": {"status": "skipped", "message": f"Previously failed"},
            "failure": False,
        }

    if tool_name not in TOOL_REGISTRY:
        return {
            "step": step, "task": task, "tool": tool_name,
            "result": {"status": "error", "message": f"Unknown tool '{tool_name}'"},
            "failure": True,
        }

    # Check cache first
    cached = tool_cache.get(tool_name, args)
    if cached is not None:
        log.info(f"[Execute] Cache hit for {tool_name}")
        return {
            "step": step, "task": task, "tool": tool_name,
            "result": cached, "failure": False, "from_cache": True,
        }

    # Check memory for recent identical call
    recent = get_last_exact(tool_name)
    if recent:
        log.info(f"[Execute] Found recent memory for {tool_name}")
        # Could parse and reuse, but let's just note it

    # Execute with retry
    result = _call_tool_with_retry(tool_name, args)
    failure = result.get("status") == "error"

    if not failure:
        tool_cache.set(tool_name, args, result)
        # Store in state for chaining
        state[f"{tool_name}_result"] = result

    return {
        "step": step, "task": task, "tool": tool_name,
        "result": result, "failure": failure, "from_cache": False,
    }


# ----------------------------------------------------------------------------
# Parallel step execution
# ----------------------------------------------------------------------------
def _run_steps_parallel(steps: list, failed_tools: set, state: dict) -> tuple:
    results = []
    had_failure = False
    tool_steps = [s for s in steps if s.get("tool")]
    general_steps = [s for s in steps if not s.get("tool")]

    if tool_steps:
        with ThreadPoolExecutor(max_workers=min(len(tool_steps), 5)) as executor:
            futures = {
                executor.submit(_execute_step, step, failed_tools, state): step
                for step in tool_steps
            }
            for future in as_completed(futures):
                try:
                    outcome = future.result()
                    results.append(outcome)
                    if outcome["failure"]:
                        had_failure = True
                        if outcome["tool"]:
                            failed_tools.add(outcome["tool"])
                except Exception as e:
                    had_failure = True
                    log.error(f"[Thread Error] {e}")

    for step in general_steps:
        outcome = _execute_step(step, failed_tools, state)
        results.append(outcome)

    return results, had_failure


# ----------------------------------------------------------------------------
# Build tool results for agent
# ----------------------------------------------------------------------------
def _build_tool_results(outcomes: list) -> list:
    tool_results = []

    for outcome in outcomes:
        result = outcome["result"]
        if result.get("status") == "success":
            # Filter news results by relevance
            if outcome["tool"] == "get_news" and "articles" in result:
                task = outcome.get("task", "").lower()
                keywords = [w for w in task.split() if len(w) > 3]

                if keywords:
                    filtered = []
                    for a in result.get("articles", []):
                        title = (a.get("title") or "").lower()
                        desc = (a.get("description") or "").lower()
                        text = title + " " + desc
                        if any(kw in text for kw in keywords):
                            filtered.append(a)

                    if filtered:
                        result = {**result, "articles": filtered}

            tool_results.append({
                "tool": outcome["tool"],
                "task": outcome["task"],
                "result": result,
                "cached": outcome.get("from_cache", False),
            })

    return tool_results


# ----------------------------------------------------------------------------
# Summarize with tool results
# ----------------------------------------------------------------------------
def _summarise(original_input: str, tool_results: list) -> str:
    if not tool_results:
        return "I couldn't retrieve the data. Please try rephrasing your query."

    prompt = f"""Answer using ONLY the tool results provided.

User Question: {original_input}

INSTRUCTIONS:
- Use ONLY data from tool results
- Write in natural, conversational language
- If no relevant data → say "No relevant data found"
- Do NOT add information not in results

Answer:"""

    return run_agent(prompt, tool_results=tool_results)


# ----------------------------------------------------------------------------
# Main orchestration
# ----------------------------------------------------------------------------
def run_system(user_input: str) -> str:
    """Main entry point — handles all query types."""

    classification = classify(user_input)
    query_type = classification["type"]
    log.info(f"[Classifier] Query type: {query_type.upper()}")

    # Conversational → direct to agent
    if query_type == QueryClass.CONVERSATIONAL:
        log.info("[Orchestrator] Conversational — direct to run_agent")
        return run_agent(user_input)

    # Simple tool → fast path
    if query_type == QueryClass.SIMPLE_TOOL:
        plan = classification.get("plan", {})
        steps = plan.get("steps", [])
        if steps:
            failed_tools = set()
            state = {}
            outcomes, _ = _run_steps_parallel(steps, failed_tools, state)
            tool_results = _build_tool_results(outcomes)
            if tool_results:
                return _summarise(user_input, tool_results)

    # Complex → ReAct loop
    log.info("[Orchestrator] Starting ReAct loop")

    tool_results_history = []
    thought_history = []
    last_tool = None
    state = {}
    final_answer = ""

    for cycle in range(MAX_CYCLES):
        log.info(f"[ReAct] Cycle {cycle + 1}/{MAX_CYCLES}")

        # Think step
        thought = _think_step(
            user_input,
            tool_results_history,
            thought_history,
            last_tool
        )

        thought_text = thought.get("thought", "")
        thought_history.append(thought_text)
        log.info(f"[ReAct] Thought: {thought_text[:100]}...")

        # Check for final answer
        if thought.get("final"):
            final_answer = thought["final"]
            log.info(f"[ReAct] Final answer reached")
            break

        # Execute action
        action = thought.get("action")
        if action:
            tool_name = action.get("tool")
            args = action.get("args", {})

            # Resolve variables
            args = _resolve_variables(args, state)

            if tool_name in TOOL_REGISTRY:
                # Prevent repetition
                if tool_name == last_tool:
                    log.warning(f"[ReAct] Skipping repeat of {tool_name}")
                    continue

                last_tool = tool_name
                result = _call_tool_with_retry(tool_name, args)

                tool_results_history.append({
                    "tool": tool_name,
                    "result": result
                })

                if result.get("status") == "success":
                    state[f"{tool_name}_result"] = result

                log.info(f"[ReAct] Tool result: {tool_name} → {result.get('status')}")
            else:
                log.error(f"[ReAct] Unknown tool: {tool_name}")
        else:
            # No action, no final — force exit
            log.warning("[ReAct] No action or final — exiting")
            break

    # Generate final answer if ReAct didn't produce one
    if not final_answer and tool_results_history:
        tool_results = [
            {"tool": tr["tool"], "task": user_input, "result": tr["result"]}
            for tr in tool_results_history
            if tr["result"].get("status") == "success"
        ]
        final_answer = _summarise(user_input, tool_results)

    # Evaluate and potentially retry
    if final_answer:
        eval_result = evaluate(user_input, final_answer)
        confidence = eval_result.get("confidence", 0.0)
        log.info(f"[Evaluator] Confidence: {confidence}")

        if confidence < 0.5 and len(tool_results_history) < 2:
            log.warning("[Orchestrator] Low confidence — consider retry")

    # Log cache stats
    stats = tool_cache.stats()
    log.info(f"[Cache] Hits: {stats['hits']}, Misses: {stats['misses']}, Rate: {stats['hit_rate']}")

    return final_answer or "I couldn't complete this task. Please try again."
