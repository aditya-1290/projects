from planner import create_plan
from agent_qwen import run_agent
from evaluator import evaluate

def run_system(user_input):
    context = ""
    MAX_CYCLES = 3

    for cycle in range(MAX_CYCLES):
        print(f"\n=== Cycle {cycle+1} ===")

        print("\n[Planner]")
        plan = create_plan(user_input)
        print(plan)

        for step in plan.get("steps", []):
            task = step["task"].strip()

            # Remove accidental junk
            if "context:" in task.lower():
                task = task.split("context:")[0].strip()

            task_with_context = f"""
            You are executing a specific task.

            Previous context (may or may not be relevant):
            {context}

            Your current task:
            {task}

            IMPORTANT:
            - Focus ONLY on the current task
            - Ignore irrelevant previous context
            - Do NOT assume this is related to previous tasks unless clearly connected
            """

            print(f"\n[Executing Step] {task}")

            result = run_agent(task_with_context)

            # print(f"[Result] {result}")

            context += f"\nStep: {task}\nResult: {result}\n"

        print("\n[Evaluator]")
        eval_result = evaluate(user_input, context)
        print(eval_result)

        if "COMPLETE" in eval_result.upper():
            break

    return context