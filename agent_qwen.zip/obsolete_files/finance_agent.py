from agent_qwen import run_agent

def finance_agent(task):
    return run_agent(f"You are a finance expert.\n\n{task}")