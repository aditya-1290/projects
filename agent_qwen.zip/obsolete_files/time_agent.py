from agent_qwen import run_agent

def time_agent(task):
    return run_agent(f"You are a time and timezone expert.\n\n{task}")