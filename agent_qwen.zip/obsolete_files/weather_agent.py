from agent_qwen import run_agent

def weather_agent(task):
    return run_agent(f"You are a weather expert.\n\n{task}")