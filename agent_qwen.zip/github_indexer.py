"""
github_indexer.py — Clone, parse, and index GitHub repositories into ChromaDB.
"""

import os
import json
import uuid
import tempfile
import subprocess
from pathlib import Path
from typing import List, Dict, Any, Optional, Generator
from datetime import datetime

import chromadb
from chromadb.utils import embedding_functions

from logger import log


# ---------------------------------------------------------------------------
# Language Parsers
# ---------------------------------------------------------------------------

class CodeParser:
    """Parse code files into meaningful chunks with context."""

    SUPPORTED_EXTENSIONS = {
        '.py': 'python',
        '.js': 'javascript',
        '.ts': 'typescript',
        '.jsx': 'jsx',
        '.tsx': 'tsx',
        '.java': 'java',
        '.go': 'go',
        '.rs': 'rust',
        '.c': 'c',
        '.cpp': 'cpp',
        '.h': 'c',
        '.hpp': 'cpp',
        '.cs': 'csharp',
        '.rb': 'ruby',
        '.php': 'php',
        '.swift': 'swift',
        '.kt': 'kotlin',
        '.scala': 'scala',
        '.sh': 'bash',
        '.bash': 'bash',
        '.zsh': 'bash',
        '.yaml': 'yaml',
        '.yml': 'yaml',
        '.json': 'json',
        '.xml': 'xml',
        '.html': 'html',
        '.css': 'css',
        '.scss': 'scss',
        '.sql': 'sql',
        '.md': 'markdown',
        '.txt': 'text',
    }

    def __init__(self):
        self.parsed_files = 0
        self.skipped_files = 0

    def parse_file(self, file_path: Path, repo_name: str) -> List[Dict[str, Any]]:
        """Parse a file into semantic chunks."""
        ext = file_path.suffix.lower()

        if ext not in self.SUPPORTED_EXTENSIONS:
            self.skipped_files += 1
            return []

        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()

            if len(content) == 0:
                return []

            language = self.SUPPORTED_EXTENSIONS[ext]

            # Split into logical chunks
            chunks = self._chunk_content(content, language, file_path, repo_name)
            self.parsed_files += 1

            return chunks

        except Exception as e:
            log.debug(f"[Parser] Failed to parse {file_path}: {e}")
            self.skipped_files += 1
            return []

    def _chunk_content(self, content: str, language: str, file_path: Path, repo_name: str) -> List[Dict]:
        """Split file content into semantic chunks."""
        chunks = []
        lines = content.split('\n')

        # Different chunking strategies by language
        if language in ['python', 'javascript', 'typescript', 'java', 'go', 'rust']:
            chunks = self._chunk_by_functions(lines, language, file_path, repo_name)
        elif language in ['markdown', 'text']:
            chunks = self._chunk_by_paragraphs(content, file_path, repo_name)
        else:
            chunks = self._chunk_by_size(content, file_path, repo_name, language)

        # Add file-level metadata to each chunk
        for chunk in chunks:
            chunk['metadata'].update({
                'repo': repo_name,
                'file_path': str(file_path),
                'file_name': file_path.name,
                'language': language,
                'extension': file_path.suffix,
            })

        return chunks

    def _chunk_by_functions(self, lines: List[str], language: str, file_path: Path, repo_name: str) -> List[Dict]:
        """Chunk by function/class definitions."""
        chunks = []
        current_chunk = []
        current_function = None
        chunk_start = 0

        # Patterns for function/class starts
        patterns = {
            'python': [r'^\s*def\s+', r'^\s*class\s+', r'^\s*async\s+def\s+'],
            'javascript': [r'^\s*function\s+', r'^\s*class\s+', r'^\s*const\s+\w+\s*=\s*\(', r'^\s*async\s+function'],
            'typescript': [r'^\s*function\s+', r'^\s*class\s+', r'^\s*interface\s+', r'^\s*type\s+'],
            'java': [r'^\s*(public|private|protected)\s+', r'^\s*class\s+', r'^\s*interface\s+'],
            'go': [r'^\s*func\s+', r'^\s*type\s+', r'^\s*struct\s+'],
            'rust': [r'^\s*fn\s+', r'^\s*struct\s+', r'^\s*impl\s+', r'^\s*trait\s+'],
        }

        import re
        func_patterns = patterns.get(language, [r'^\s*\w+\s+'])
        pattern = re.compile('|'.join(f'({p})' for p in func_patterns))

        for i, line in enumerate(lines):
            if pattern.match(line):
                # Save previous chunk
                if current_chunk:
                    chunk_text = '\n'.join(current_chunk)
                    chunks.append({
                        'content': chunk_text[:5000],  # Limit chunk size
                        'metadata': {
                            'chunk_type': current_function or 'code_block',
                            'start_line': chunk_start,
                            'end_line': i - 1,
                            'line_count': len(current_chunk),
                        }
                    })

                # Start new chunk
                current_chunk = [line]
                chunk_start = i
                # Extract function/class name
                current_function = line.split('(')[0].strip().split()[-1] if '(' in line else 'block'
            else:
                current_chunk.append(line)

        # Save last chunk
        if current_chunk:
            chunks.append({
                'content': '\n'.join(current_chunk)[:5000],
                'metadata': {
                    'chunk_type': current_function or 'code_block',
                    'start_line': chunk_start,
                    'end_line': len(lines) - 1,
                    'line_count': len(current_chunk),
                }
            })

        return chunks

    def _chunk_by_paragraphs(self, content: str, file_path: Path, repo_name: str) -> List[Dict]:
        """Chunk markdown/text by paragraphs."""
        chunks = []
        paragraphs = content.split('\n\n')

        current_chunk = []
        current_size = 0
        max_size = 2000

        for para in paragraphs:
            if current_size + len(para) > max_size and current_chunk:
                chunks.append({
                    'content': '\n\n'.join(current_chunk),
                    'metadata': {'chunk_type': 'paragraph_group'}
                })
                current_chunk = []
                current_size = 0

            current_chunk.append(para)
            current_size += len(para)

        if current_chunk:
            chunks.append({
                'content': '\n\n'.join(current_chunk),
                'metadata': {'chunk_type': 'paragraph_group'}
            })

        return chunks

    def _chunk_by_size(self, content: str, file_path: Path, repo_name: str, language: str) -> List[Dict]:
        """Simple size-based chunking."""
        chunk_size = 2000
        chunks = []

        for i in range(0, len(content), chunk_size):
            chunks.append({
                'content': content[i:i + chunk_size],
                'metadata': {
                    'chunk_type': 'raw',
                    'start_char': i,
                    'end_char': min(i + chunk_size, len(content)),
                }
            })

        return chunks


# ---------------------------------------------------------------------------
# GitHub Repository Manager
# ---------------------------------------------------------------------------

class GitHubRepoIndexer:
    """Clone, parse, and index GitHub repositories."""

    def __init__(self, github_token: Optional[str] = None):
        self.github_token = github_token
        self.parser = CodeParser()

        # Initialize ChromaDB collection for code
        self.client = chromadb.PersistentClient(path="./chroma_db")
        self.code_collection = self.client.get_or_create_collection(
            name="github_codebase",
            embedding_function=embedding_functions.DefaultEmbeddingFunction(),
            metadata={"description": "GitHub repository code chunks"}
        )

        # Repo metadata collection
        self.repo_collection = self.client.get_or_create_collection(
            name="github_repos",
            embedding_function=embedding_functions.DefaultEmbeddingFunction(),
            metadata={"description": "GitHub repository metadata"}
        )

    def clone_repository(self, repo_url: str, branch: str = "main") -> Optional[Path]:
        """Clone a GitHub repository to temp directory."""
        try:
            temp_dir = tempfile.mkdtemp(prefix="github_repo_")
            repo_path = Path(temp_dir) / repo_url.split('/')[-1].replace('.git', '')

            # Build clone URL with token if provided
            if self.github_token and "github.com" in repo_url:
                clone_url = repo_url.replace("https://", f"https://{self.github_token}@")
            else:
                clone_url = repo_url

            cmd = ["git", "clone", "--depth", "1", "--branch", branch, clone_url, str(repo_path)]

            result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)

            if result.returncode != 0:
                log.error(f"[GitHub] Clone failed: {result.stderr}")
                return None

            log.info(f"[GitHub] Cloned {repo_url} to {repo_path}")
            return repo_path

        except Exception as e:
            log.error(f"[GitHub] Clone error: {e}")
            return None

    def index_repository(self, repo_path: Path, repo_name: str, repo_url: str) -> Dict[str, Any]:
        """Parse and index all files in a repository."""

        log.info(f"[Indexer] Starting indexing of {repo_name}")

        all_chunks = []
        file_tree = self._build_file_tree(repo_path)

        # Walk through all files
        for file_path in repo_path.rglob("*"):
            if file_path.is_file():
                # Skip common binary and dependency directories
                skip_dirs = {'.git', 'node_modules', '__pycache__', '.venv', 'venv',
                             'target', 'build', 'dist', '.next', '.cache'}
                if any(skip in file_path.parts for skip in skip_dirs):
                    continue

                chunks = self.parser.parse_file(file_path, repo_name)
                all_chunks.extend(chunks)

        # Store in ChromaDB
        batch_size = 100
        total_stored = 0

        for i in range(0, len(all_chunks), batch_size):
            batch = all_chunks[i:i + batch_size]

            documents = [c['content'] for c in batch]
            metadatas = [c['metadata'] for c in batch]
            ids = [str(uuid.uuid4()) for _ in batch]

            try:
                self.code_collection.add(
                    documents=documents,
                    metadatas=metadatas,
                    ids=ids
                )
                total_stored += len(batch)
            except Exception as e:
                log.error(f"[Indexer] Failed to store batch: {e}")

        # Store repo metadata
        repo_metadata = {
            "repo_name": repo_name,
            "repo_url": repo_url,
            "total_files": self.parser.parsed_files,
            "skipped_files": self.parser.skipped_files,
            "total_chunks": total_stored,
            "file_tree": json.dumps(file_tree),
            "indexed_at": datetime.now().isoformat(),
            "languages": list(
                set(c['metadata']['language'] for c in all_chunks if 'language' in c.get('metadata', {}))),
        }

        self.repo_collection.add(
            documents=[f"Repository: {repo_name} — {self.parser.parsed_files} files, {total_stored} chunks"],
            metadatas=[repo_metadata],
            ids=[str(uuid.uuid4())]
        )

        log.info(f"[Indexer] Indexed {repo_name}: {self.parser.parsed_files} files, {total_stored} chunks")

        return repo_metadata

    def _build_file_tree(self, repo_path: Path, max_depth: int = 3) -> Dict[str, Any]:
        """Build a tree structure of the repository."""

        def build_tree(path: Path, current_depth: int = 0) -> Dict:
            if current_depth > max_depth:
                return {"_truncated": True}

            if path.is_file():
                return {
                    "_type": "file",
                    "name": path.name,
                    "size": path.stat().st_size,
                }

            tree = {"_type": "directory", "name": path.name, "children": {}}

            try:
                for child in sorted(path.iterdir()):
                    if child.name.startswith('.') and child.name not in ['.env.example']:
                        continue
                    tree["children"][child.name] = build_tree(child, current_depth + 1)
            except PermissionError:
                pass

            return tree

        return build_tree(repo_path)

    def search_code(self, query: str, repo_name: Optional[str] = None, n_results: int = 10) -> List[Dict]:
        """Search indexed code for relevant chunks."""

        where_filter = None
        if repo_name:
            where_filter = {"repo": repo_name}

        results = self.code_collection.query(
            query_texts=[query],
            n_results=n_results,
            where=where_filter,
        )

        if not results['documents'][0]:
            return []

        matches = []
        for doc, meta, dist in zip(results['documents'][0], results['metadatas'][0], results['distances'][0]):
            matches.append({
                'content': doc[:500],
                'metadata': meta,
                'relevance': 1 - dist,  # Convert distance to similarity
                'file': meta.get('file_path', 'unknown'),
                'lines': f"{meta.get('start_line', 0)}-{meta.get('end_line', 0)}",
            })

        return matches

    def list_indexed_repos(self) -> List[Dict]:
        """List all indexed repositories."""
        results = self.repo_collection.get()

        repos = []
        if results['metadatas']:
            for meta in results['metadatas']:
                repos.append({
                    'name': meta.get('repo_name'),
                    'url': meta.get('repo_url'),
                    'files': meta.get('total_files'),
                    'chunks': meta.get('total_chunks'),
                    'indexed_at': meta.get('indexed_at'),
                    'languages': meta.get('languages'),
                })

        return repos


# ---------------------------------------------------------------------------
# Tool Functions
# ---------------------------------------------------------------------------

def index_github_repo(repo_url: str, github_token: Optional[str] = None) -> dict:
    """
    Clone and index a GitHub repository.

    Args:
        repo_url: GitHub repository URL
        github_token: Optional GitHub personal access token
    """
    try:
        indexer = GitHubRepoIndexer(github_token)

        # Extract repo name
        repo_name = repo_url.rstrip('/').split('/')[-1].replace('.git', '')

        log.info(f"[GitHub] Indexing {repo_name} from {repo_url}")

        # Clone
        repo_path = indexer.clone_repository(repo_url)
        if not repo_path:
            return {"status": "error", "message": "Failed to clone repository"}

        # Index
        metadata = indexer.index_repository(repo_path, repo_name, repo_url)

        # Cleanup temp directory
        import shutil
        shutil.rmtree(repo_path.parent, ignore_errors=True)

        return {
            "status": "success",
            "repo_name": repo_name,
            "repo_url": repo_url,
            "files_indexed": metadata['total_files'],
            "chunks_stored": metadata['total_chunks'],
            "languages": metadata['languages'],
        }

    except Exception as e:
        log.error(f"[GitHub] Index error: {e}")
        return {"status": "error", "message": str(e)}


def search_indexed_code(query: str, repo_name: Optional[str] = None, limit: int = 10) -> dict:
    """
    Search indexed code for relevant snippets.

    Args:
        query: Search query
        repo_name: Optional specific repo to search
        limit: Number of results
    """
    try:
        indexer = GitHubRepoIndexer()
        results = indexer.search_code(query, repo_name, limit)

        return {
            "status": "success",
            "query": query,
            "repo_filter": repo_name,
            "results": results,
            "count": len(results),
        }

    except Exception as e:
        return {"status": "error", "message": str(e)}


def list_github_repos() -> dict:
    """List all indexed GitHub repositories."""
    try:
        indexer = GitHubRepoIndexer()
        repos = indexer.list_indexed_repos()

        return {
            "status": "success",
            "repositories": repos,
            "count": len(repos),
        }

    except Exception as e:
        return {"status": "error", "message": str(e)}


def index_all_user_repos(github_username: str, github_token: str) -> dict:
    """
    Index all repositories for a GitHub user.

    Args:
        github_username: GitHub username
        github_token: GitHub personal access token
    """
    try:
        import requests

        headers = {"Authorization": f"token {github_token}"}
        repos = []
        page = 1

        while True:
            url = f"https://api.github.com/users/{github_username}/repos?page={page}&per_page=100"
            response = requests.get(url, headers=headers)

            if response.status_code != 200:
                break

            page_repos = response.json()
            if not page_repos:
                break

            repos.extend(page_repos)
            page += 1

        log.info(f"[GitHub] Found {len(repos)} repositories for {github_username}")

        indexer = GitHubRepoIndexer(github_token)
        indexed = []
        failed = []

        for repo in repos:
            repo_url = repo['clone_url']
            repo_name = repo['name']

            try:
                result = index_github_repo(repo_url, github_token)
                if result.get("status") == "success":
                    indexed.append(repo_name)
                else:
                    failed.append({"name": repo_name, "error": result.get("message")})
            except Exception as e:
                failed.append({"name": repo_name, "error": str(e)})

        return {
            "status": "success",
            "username": github_username,
            "total_repos": len(repos),
            "indexed": indexed,
            "failed": failed,
        }

    except Exception as e:
        return {"status": "error", "message": str(e)}