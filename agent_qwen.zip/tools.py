"""
tools.py — All agent tools (production version)

Free-plan API chain for time:
  city → /v1/geocoding (lat/lon) → timezonefinder (offline IANA tz) → /v1/worldtime?timezone=IANA

Free-plan API chain for weather:
  city → /v1/geocoding (lat/lon) → /v1/weather?lat=&lon=

New tools added:
  get_stock_price   → /v1/stockprice?ticker=   (free, 15min delay)
  get_news          → /v1/news?topic=           (free)
  calculate         → pure Python, no API
"""

import os
import re
import subprocess
from pathlib import Path
from typing import Optional

import requests
from dotenv import load_dotenv
from timezonefinder import TimezoneFinder
# Import GitHub indexer tools
from github_indexer import (
    index_github_repo,
    search_indexed_code,
    list_github_repos,
    index_all_user_repos,
)
from logger import log

load_dotenv()

API_NINJAS_KEY = os.getenv("API_NINJAS_KEY")
EXCHANGERATE_KEY = os.getenv("EXCHANGERATE_KEY")
NEWS_DATA_API_KEY = os.getenv("NEWS_DATA_API_KEY")


# ---------------------------------------------------------------------------
# API Key Validation (Fail fast on missing keys)
# ---------------------------------------------------------------------------
def _validate_api_keys():
    """Validate all required API keys exist."""
    missing = []

    if not API_NINJAS_KEY:
        missing.append("API_NINJAS_KEY")
    if not EXCHANGERATE_KEY:
        missing.append("EXCHANGERATE_KEY")
    if not NEWS_DATA_API_KEY:
        missing.append("NEWS_DATA_API_KEY")

    if missing:
        import warnings
        warnings.warn(f"⚠️ Missing API keys: {', '.join(missing)}. Some tools will fail.")
        # Don't raise — allow graceful degradation


_validate_api_keys()

_tf = TimezoneFinder()

# ---------------------------------------------------------------------------
# Geocoding — city name → (lat, lon)  [FREE]
# ---------------------------------------------------------------------------
_geocode_cache = {}


def get_city_coords(city: str):
    city_key = city.lower().strip()
    if city_key in _geocode_cache:
        return _geocode_cache[city_key]

    # Known city → timezone overrides for accuracy
    CITY_TZ_OVERRIDES = {
        "kerala": ("Asia/Kolkata", 10.8505, 76.2711),
        "mumbai": ("Asia/Kolkata", 19.0760, 72.8777),
        "delhi": ("Asia/Kolkata", 28.6139, 77.2090),
        "bangalore": ("Asia/Kolkata", 12.9716, 77.5946),
        "chennai": ("Asia/Kolkata", 13.0827, 80.2707),
        "kolkata": ("Asia/Kolkata", 22.5726, 88.3639),
    }

    if city_key in CITY_TZ_OVERRIDES:
        tz, lat, lon = CITY_TZ_OVERRIDES[city_key]
        _geocode_cache[city_key] = (lat, lon)
        print(f"[Geocoding] ✅ '{city}' → override: lat={lat}, lon={lon}")
        return (lat, lon)

    try:
        r = requests.get(
            "https://api.api-ninjas.com/v1/geocoding",
            headers={"X-Api-Key": API_NINJAS_KEY},
            params={"city": city},
            timeout=10
        )
        r.raise_for_status()
        data = r.json()

        if not data:
            print(f"[Geocoding] ⚠ No results for '{city}'")
            return None

        # Prefer India results for Indian cities
        city_lower = city.lower()
        indian_cities = ["mumbai", "delhi", "bangalore", "kolkata", "chennai",
                         "hyderabad", "pune", "ahmedabad", "kerala", "kochi"]

        selected = data[0]  # default
        if city_lower in indian_cities or any(c in city_lower for c in indian_cities):
            for loc in data:
                if loc.get("country") == "IN":
                    selected = loc
                    break

        lat = selected.get("latitude")
        lon = selected.get("longitude")

        if lat is None or lon is None:
            return None

        print(f"[Geocoding] ✅ '{city}' → lat={lat}, lon={lon}, country={selected.get('country')}")
        _geocode_cache[city_key] = (lat, lon)
        return (lat, lon)

    except Exception as e:
        print(f"[Geocoding] ❌ '{city}': {e}")
        return None


# ---------------------------------------------------------------------------
# Timezone — offline via timezonefinder  [FREE, no API]
# pip install timezonefinder
# ---------------------------------------------------------------------------
_timezone_cache = {}


def get_city_timezone(city: str):
    city_key = city.lower().strip()
    if city_key in _timezone_cache:
        return _timezone_cache[city_key]
    coords = get_city_coords(city)
    if not coords:
        return None
    lat, lon = coords
    tz = _tf.timezone_at(lat=lat, lng=lon)
    if tz:
        print(f"[TimezoneFinder] ✅ '{city}' → {tz}")
        _timezone_cache[city_key] = tz
    else:
        print(f"[TimezoneFinder] ⚠ No tz for lat={lat}, lon={lon}")
    return tz


# ===========================================================================
# TOOL: Get Current Time
# ===========================================================================
def get_current_time(city: str) -> dict:
    try:
        tz = get_city_timezone(city)
        if not tz:
            return {"status": "error",
                    "message": f"Could not determine timezone for '{city}'. Use a city name, not a country."}

        # Use pytz + datetime directly — no API call needed at all
        import pytz
        from datetime import datetime
        timezone = pytz.timezone(tz)
        now = datetime.now(timezone)
        print(f"[Time] ✅ '{city}' ({tz}) → {now.strftime('%Y-%m-%d %H:%M:%S')}")

        return {
            "status": "success",
            "city": city.title(),
            "datetime": now.strftime("%Y-%m-%d %H:%M:%S"),
            "timezone": tz,
            "day_of_week": now.strftime("%A"),
            "hour": now.hour,
            "minute": now.minute,
            "utc_offset": now.strftime("%z"),
        }
    except Exception as e:
        print(f"[Time] ❌ {e}")
        return {"status": "error", "message": str(e)}


# ===========================================================================
# TOOL: Get Weather
# ===========================================================================
def get_weather(city: str, unit: str = "celsius") -> dict:
    try:
        coords = get_city_coords(city)
        if not coords:
            return {"status": "error", "message": f"Could not find coordinates for '{city}'. Use a city name."}
        lat, lon = coords
        r = requests.get(
            "https://api.api-ninjas.com/v1/weather",
            headers={"X-Api-Key": API_NINJAS_KEY},
            params={"lat": lat, "lon": lon}, timeout=10
        )
        r.raise_for_status()
        data = r.json()
        temp = data.get("temp")
        feels_like = data.get("feels_like")
        if unit == "fahrenheit":
            temp = round((temp * 9 / 5) + 32, 1) if temp is not None else None
            feels_like = round((feels_like * 9 / 5) + 32, 1) if feels_like is not None else None
            unit_symbol = "°F"
        else:
            unit_symbol = "°C"
        return {
            "status": "success",
            "city": city.title(),
            "temperature": temp,  # 🔥 numeric
            "temperature_unit": unit_symbol,  # keep unit separate
            "temperatures": f"{temp}{unit_symbol}",
            "feels_like": f"{feels_like}{unit_symbol}",
            "humidity": f"{data.get('humidity')}%",
            "wind_speed": f"{data.get('wind_speed')} m/s",
        }
    except Exception as e:
        return {"status": "error", "message": str(e)}


# ===========================================================================
# TOOL: Currency Converter
# ===========================================================================
def convert_currency(amount: float, from_currency: str, to_currency: str) -> dict:
    try:
        src, tgt = from_currency.upper(), to_currency.upper()
        r = requests.get(
            f"https://v6.exchangerate-api.com/v6/{EXCHANGERATE_KEY}/pair/{src}/{tgt}/{amount}",
            timeout=10
        )
        r.raise_for_status()
        data = r.json()
        if data.get("result") != "success":
            return {"status": "error", "message": data.get("error-type", "Unknown error")}
        return {
            "status": "success",
            "from": src,
            "to": tgt,
            "original_amount": amount,
            "converted_amount": round(data["conversion_result"], 4),
            "exchange_rate": data["conversion_rate"],
            "last_updated": data.get("time_last_update_utc", "N/A"),
        }
    except requests.exceptions.RequestException as e:
        return {"status": "error", "message": str(e)}


# ===========================================================================
# TOOL: Date Info
# ===========================================================================
def get_date_info(city: str) -> dict:
    try:
        tz = get_city_timezone(city)
        if not tz:
            return {"status": "error", "message": f"Could not determine timezone for '{city}'. Use a city name."}

        import pytz
        from datetime import datetime
        timezone = pytz.timezone(tz)
        now = datetime.now(timezone)
        print(f"[DateInfo] ✅ '{city}' ({tz}) → {now.strftime('%Y-%m-%d %H:%M:%S')}")

        return {
            "status": "success",
            "city": city.title(),
            "date": now.strftime("%Y-%m-%d"),
            "time": now.strftime("%H:%M:%S"),
            "day_of_week": now.strftime("%A"),
            "timezone": tz,
            "utc_offset": now.strftime("%z"),
        }
    except Exception as e:
        return {"status": "error", "message": str(e)}


# ===========================================================================
# TOOL: World Clock
# ===========================================================================
def get_world_clock(cities: list) -> dict:
    results, errors = [], []
    for city in cities:
        result = get_current_time(city)
        if result["status"] == "success":
            results.append(result)
        else:
            errors.append({"city": city, "error": result["message"]})
    return {
        "status": "success",
        "clock_count": len(results),
        "world_clock": results,
        "errors": errors if errors else None,
    }


# ===========================================================================
# TOOL: Get Stock Price  [NEW]
# Uses api-ninjas /v1/stockprice — FREE (15min delay for free plan)
# ticker: stock symbol e.g. AAPL, TSLA, GOOGL, ^DJI (Dow Jones)
# ===========================================================================
def get_stock_price(ticker: str) -> dict:
    try:
        r = requests.get(
            "https://api.api-ninjas.com/v1/stockprice",
            headers={"X-Api-Key": API_NINJAS_KEY},
            params={"ticker": ticker.upper()},
            timeout=10
        )
        r.raise_for_status()
        data = r.json()
        print(f"[StockPrice] ✅ {ticker} → {data}")

        if not data or "price" not in data:
            return {"status": "error", "message": f"No data found for ticker '{ticker}'. Check the symbol."}

        return {
            "status": "success",
            "ticker": data.get("ticker"),
            "name": data.get("name"),
            "price": data.get("price"),
            "exchange": data.get("exchange"),
            "currency": data.get("currency"),
            "volume": data.get("volume"),
            "note": "Price is delayed by ~15 minutes on the free plan.",
        }
    except Exception as e:
        print(f"[StockPrice] ❌ {e}")
        return {"status": "error", "message": str(e)}


# ===========================================================================
# TOOL: Get News  [NEW]
# Uses newsdata.io /api/1/latest — FREE
# category: e.g. "technology", "sports", "finance", "politics", "science"
# ===========================================================================
def get_news(topic: str = "technology", limit: int = 3) -> dict:
    try:
        # 🔥 ADD THIS BLOCK HERE
        VALID_NEWS_TOPICS = {
            "technology", "business", "sports",
            "politics", "science", "health", "world", "top"
        }

        topic = (topic or "").lower().strip()

        if topic not in VALID_NEWS_TOPICS:
            print(f"[News Tool Fix] Invalid topic '{topic}' → using 'technology'")
            topic = "technology"

        params = {
            "apikey": NEWS_DATA_API_KEY,
            "category": topic,
            "language": "en"
        }

        r = requests.get(
            "https://newsdata.io/api/1/latest",
            params=params,
            timeout=10
        )
        r.raise_for_status()
        data = r.json()

        articles_raw = data.get("results", [])

        if not articles_raw:
            return {"status": "error", "message": f"No news found for topic '{topic}'."}

        articles = []
        for item in articles_raw[:limit]:
            articles.append({
                "title": item.get("title"),
                "description": item.get("description"),
                "source": item.get("source_id"),
                "url": item.get("link"),
                "published": item.get("pubDate"),
            })

        return {
            "status": "success",
            "topic": topic,
            "article_count": len(articles),
            "articles": articles,
        }

    except Exception as e:
        return {"status": "error", "message": str(e)}


# ===========================================================================
# TOOL: Calculator  [NEW]
# Pure Python — no API needed. Safe eval for math expressions.
# Supports: +, -, *, /, **, %, sqrt, round, abs, and chained calculations.
# expression examples:
#   "15000 * 1.18"
#   "sqrt(144)"
#   "500 / 4 + 200"
#   "2 ** 10"
# ===========================================================================
import math

_SAFE_MATH = {
    "sqrt": math.sqrt,
    "abs": abs,
    "round": round,
    "pow": pow,
    "log": math.log,
    "log10": math.log10,
    "ceil": math.ceil,
    "floor": math.floor,
    "pi": math.pi,
    "e": math.e,
}


def calculate(expression: str) -> dict:
    try:
        # Whitelist: only allow digits, math operators, parentheses, dots,
        # spaces, and the exact letters that spell our allowed function names.
        # Anything else is stripped before eval — this is the sanitization
        # that was computed but never actually used before.
        allowed_letters = set("sqrtabsroundpowlogceilfloorpie")
        clean = re.sub(
            r"[^0-9+\-*/().%\s]",
            lambda m: m.group() if m.group() in allowed_letters else "",
            expression
        )
        clean = clean.strip()
        if not clean:
            return {"status": "error", "message": "Expression is empty after sanitization."}

        # ✅ eval the SANITIZED expression, not the raw input
        result = eval(clean, {"__builtins__": {}}, _SAFE_MATH)
        result = round(result, 10)  # avoid floating point noise
        return {
            "status": "success",
            "expression": expression,  # original input for display
            "evaluated": clean,  # what was actually eval'd (post-sanitize)
            "result": result,
            "value": result,
        }
    except ZeroDivisionError:
        return {"status": "error", "message": "Division by zero."}
    except Exception as e:
        return {"status": "error", "message": f"Could not evaluate expression: {e}"}


# ===========================================================================
# TOOL: Get Gold Price
# Uses gold-api.com — completely FREE, no API key, no rate limits
# Endpoint: GET https://api.gold-api.com/price/XAU
# Returns price per troy ounce in USD
# ===========================================================================
def get_gold_price() -> dict:
    try:
        r = requests.get(
            "https://api.gold-api.com/price/XAU",
            timeout=10
        )
        r.raise_for_status()
        data = r.json()
        print(f"[GoldPrice] ✅ → {data}")

        if not data or "price" not in data:
            return {"status": "error", "message": "No gold price data returned."}

        return {
            "status": "success",
            "commodity": "Gold",
            "symbol": "XAU",
            "price_per_troy_oz": data.get("price"),
            "currency": "USD",
            "name": data.get("name", "Gold"),
            "note": "Price per troy ounce in USD. Source: gold-api.com (free, real-time).",
        }
    except Exception as e:
        print(f"[GoldPrice] ❌ {e}")
        return {"status": "error", "message": str(e)}


# ===========================================================================
# Add web search tool
# ===========================================================================

def web_search(query: str, num_results: int = 5, time_filter: str = None) -> dict:
    """
    Web search using DuckDuckGo with date filtering.

    Args:
        query: Search query
        num_results: Number of results (default 5)
        time_filter: 'd' (day), 'w' (week), 'm' (month), 'y' (year)
    """
    try:
        # Add date context to query
        import re
        from datetime import datetime, timedelta

        # Detect time constraints in query
        time_patterns = {
            r'last\s+(\d+)\s+days?': lambda m: f"after:{int(m.group(1))}d",
            r'last\s+(\d+)\s+weeks?': lambda m: f"after:{int(m.group(1))}w",
            r'last\s+(\d+)\s+months?': lambda m: f"after:{int(m.group(1))}m",
            r'past\s+(\d+)\s+days?': lambda m: f"after:{int(m.group(1))}d",
            r'recent\s+(\d+)\s+months?': lambda m: f"after:{int(m.group(1))}m",
            r'in\s+the\s+last\s+(\d+)\s+months?': lambda m: f"after:{int(m.group(1))}m",
            r'in\s+the\s+last\s+(\d+)\s+weeks?': lambda m: f"after:{int(m.group(1))}w",
            r'this\s+year': lambda m: f"after:{datetime.now().month - 1}m",
            r'this\s+month': lambda m: f"after:30d",
            r'this\s+week': lambda m: f"after:7d",
            r'\d{4}': lambda m: f"in:{m.group(0)}",
        }

        enhanced_query = query
        for pattern, formatter in time_patterns.items():
            match = re.search(pattern, query, re.IGNORECASE)
            if match:
                date_suffix = formatter(match)
                enhanced_query = f"{query} {date_suffix}"
                log.info(f"[WebSearch] Added date filter: {date_suffix}")
                break

        # If explicit time_filter provided
        if time_filter:
            filter_map = {'d': 'day', 'w': 'week', 'm': 'month', 'y': 'year'}
            time_str = filter_map.get(time_filter, '')
            enhanced_query = f"{query} (past {time_str})"

        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }

        # Use DuckDuckGo with date context
        r = requests.post(
            "https://lite.duckduckgo.com/lite/",
            data={"q": enhanced_query},
            headers=headers,
            timeout=15
        )
        r.raise_for_status()
        html = r.text

        results = []

        # Extract results with date awareness
        link_pat = re.compile(
            r'<a[^>]+class="result-link"[^>]*href="([^"]+)"[^>]*>(.*?)</a>',
            re.DOTALL | re.IGNORECASE
        )
        snip_pat = re.compile(
            r'<td[^>]+class="result-snippet"[^>]*>(.*?)</td>',
            re.DOTALL | re.IGNORECASE
        )

        # Try to extract dates from snippets
        date_pat = re.compile(
            r'(\d{1,2}\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{4})|'
            r'(\d{4}-\d{2}-\d{2})|'
            r'((?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{1,2},\s+\d{4})',
            re.IGNORECASE
        )

        links = link_pat.findall(html)
        snippets = [re.sub(r'<.*?>', '', s).strip() for s in snip_pat.findall(html)]

        for i, (url, title) in enumerate(links[:num_results]):
            clean_title = re.sub(r'<.*?>', '', title).strip()
            if clean_title:
                snippet = snippets[i] if i < len(snippets) else ""

                # Extract date if present
                date_match = date_pat.search(snippet) or date_pat.search(clean_title)
                extracted_date = date_match.group(0) if date_match else None

                results.append({
                    "title": clean_title,
                    "url": url,
                    "snippet": snippet[:300],
                    "date": extracted_date,
                })

        # Score results by recency if time-sensitive
        if any(word in query.lower() for word in ['recent', 'latest', 'new', 'last', 'past']):
            results.sort(key=lambda x: x.get('date') is not None, reverse=True)

        print(f"[WebSearch] ✅ '{query}' → {len(results)} results (date-filtered)")

        return {
            "status": "success",
            "query": query,
            "enhanced_query": enhanced_query,
            "count": len(results),
            "results": results,
            "date_filtered": bool(time_filter or any(p in query.lower() for p in time_patterns)),
        }

    except Exception as e:
        print(f"[WebSearch] ❌ {e}")
        return {"status": "error", "message": str(e)[:200]}


# ===========================================================================
# TOOL: Unit Converter [NEW]
# Supports: length, weight, temperature, volume
# ===========================================================================

# Conversion factors to base units
LENGTH_TO_METER = {
    "mm": 0.001, "cm": 0.01, "m": 1.0, "km": 1000.0,
    "in": 0.0254, "ft": 0.3048, "yd": 0.9144, "mi": 1609.344,
}

WEIGHT_TO_KG = {
    "mg": 0.000001, "g": 0.001, "kg": 1.0, "t": 1000.0,
    "oz": 0.0283495, "lb": 0.453592, "st": 6.35029,
}

VOLUME_TO_LITER = {
    "ml": 0.001, "l": 1.0, "m3": 1000.0,
    "tsp": 0.00492892, "tbsp": 0.0147868, "fl_oz": 0.0295735,
    "cup": 0.236588, "pt": 0.473176, "qt": 0.946353, "gal": 3.78541,
}

# Unit aliases for user-friendly input
UNIT_ALIASES = {
    # Length
    "millimeter": "mm", "centimeter": "cm", "meter": "m", "kilometer": "km",
    "inch": "in", "foot": "ft", "feet": "ft", "yard": "yd", "mile": "mi",
    # Weight
    "milligram": "mg", "gram": "g", "kilogram": "kg", "tonne": "t", "ton": "t",
    "ounce": "oz", "pound": "lb", "lbs": "lb", "stone": "st",
    # Volume
    "milliliter": "ml", "litre": "l", "liter": "l",
    "teaspoon": "tsp", "tablespoon": "tbsp",
    "fluid ounce": "fl_oz", "cup": "cup", "pint": "pt", "quart": "qt", "gallon": "gal",
    # Temperature (special handling)
    "celsius": "c", "fahrenheit": "f", "kelvin": "k",
}

# Unit categories for validation
UNIT_CATEGORIES = {
    "length": set(LENGTH_TO_METER.keys()),
    "weight": set(WEIGHT_TO_KG.keys()),
    "volume": set(VOLUME_TO_LITER.keys()),
    "temperature": {"c", "f", "k"},
}


def _normalize_unit(unit: str) -> str:
    """Convert user-friendly unit names to standard codes."""
    unit_lower = unit.lower().strip()

    if unit_lower in UNIT_ALIASES:
        return UNIT_ALIASES[unit_lower]

    # Check if it's already a valid code
    for category_units in UNIT_CATEGORIES.values():
        if unit_lower in category_units:
            return unit_lower

    return unit_lower


def _get_unit_category(unit: str) -> Optional[str]:
    """Determine which category a unit belongs to."""
    unit = _normalize_unit(unit)
    for category, units in UNIT_CATEGORIES.items():
        if unit in units:
            return category
    return None


def convert_units(value: float, from_unit: str, to_unit: str) -> dict:
    """
    Convert between units of length, weight, volume, and temperature.

    Args:
        value: Numeric value to convert
        from_unit: Source unit (e.g., 'km', 'miles', 'kg', 'pounds', 'celsius')
        to_unit: Target unit

    Returns:
        Dictionary with conversion result
    """
    try:
        from_norm = _normalize_unit(from_unit)
        to_norm = _normalize_unit(to_unit)

        from_cat = _get_unit_category(from_norm)
        to_cat = _get_unit_category(to_norm)

        if not from_cat or not to_cat:
            return {
                "status": "error",
                "message": f"Unknown unit(s): from='{from_unit}', to='{to_unit}'. Supported: length, weight, volume, temperature."
            }

        if from_cat != to_cat:
            return {
                "status": "error",
                "message": f"Cannot convert between {from_cat} and {to_cat}. Units must be same category."
            }

        result = None
        formula = ""

        # Temperature requires special formulas
        if from_cat == "temperature":
            # Convert to Celsius first
            if from_norm == "c":
                celsius = value
            elif from_norm == "f":
                celsius = (value - 32) * 5 / 9
                formula = f"({value}°F - 32) × 5/9 = {celsius:.2f}°C"
            elif from_norm == "k":
                celsius = value - 273.15
                formula = f"{value}K - 273.15 = {celsius:.2f}°C"
            else:
                celsius = value

            # Convert from Celsius to target
            if to_norm == "c":
                result = celsius
            elif to_norm == "f":
                result = (celsius * 9 / 5) + 32
            elif to_norm == "k":
                result = celsius + 273.15
            else:
                result = celsius

            unit_symbols = {"c": "°C", "f": "°F", "k": "K"}
            from_symbol = unit_symbols.get(from_norm, from_norm)
            to_symbol = unit_symbols.get(to_norm, to_norm)

        else:
            # Length, weight, volume — use conversion factors
            if from_cat == "length":
                factors = LENGTH_TO_METER
            elif from_cat == "weight":
                factors = WEIGHT_TO_KG
            else:  # volume
                factors = VOLUME_TO_LITER

            # Convert to base unit then to target
            base_value = value * factors[from_norm]
            result = base_value / factors[to_norm]

            from_symbol = from_norm
            to_symbol = to_norm

        return {
            "status": "success",
            "category": from_cat,
            "from": {
                "value": value,
                "unit": from_unit,
                "normalized": from_norm,
            },
            "to": {
                "value": round(result, 6),
                "unit": to_unit,
                "normalized": to_norm,
            },
            "formatted": f"{value} {from_unit} = {round(result, 4)} {to_unit}",
        }

    except Exception as e:
        return {"status": "error", "message": str(e)}


# ===========================================================================
# CODEBASE AGENT TOOLS
# ===========================================================================

# File Operations
def read_file(path: str, start_line: int = 0, end_line: Optional[int] = None) -> dict:
    """
    Read a file from the filesystem with optional line range.

    Args:
        path: Path to the file
        start_line: Starting line number (0-indexed)
        end_line: Ending line number (exclusive, None for all)
    """
    try:
        file_path = Path(path).resolve()

        # Security: Prevent reading sensitive files
        sensitive_patterns = ['.env', '.git', 'secrets', 'password', 'private', 'key']
        path_str = str(file_path).lower()
        if any(p in path_str for p in sensitive_patterns):
            return {
                "status": "error",
                "message": "Cannot read sensitive files for security reasons."
            }

        if not file_path.exists():
            return {"status": "error", "message": f"File not found: {path}"}

        if file_path.stat().st_size > 5 * 1024 * 1024:  # 5MB limit
            return {"status": "error", "message": "File too large (>5MB)"}

        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            lines = f.readlines()

        total_lines = len(lines)

        if end_line is None:
            end_line = total_lines

        selected_lines = lines[start_line:end_line]
        content = ''.join(selected_lines)

        return {
            "status": "success",
            "path": str(file_path),
            "total_lines": total_lines,
            "start_line": start_line,
            "end_line": min(end_line, total_lines),
            "content": content[:50000],  # Limit output
            "language": file_path.suffix.lstrip('.'),
        }
    except Exception as e:
        return {"status": "error", "message": str(e)}


def write_file(path: str, content: str, append: bool = False) -> dict:
    """
    Write content to a file.

    Args:
        path: Path to the file
        content: Content to write
        append: If True, append instead of overwrite
    """
    try:
        file_path = Path(path).resolve()

        # Create parent directories if needed
        file_path.parent.mkdir(parents=True, exist_ok=True)

        mode = 'a' if append else 'w'
        with open(file_path, mode, encoding='utf-8') as f:
            f.write(content)

        return {
            "status": "success",
            "path": str(file_path),
            "written": len(content),
            "mode": "append" if append else "write",
        }
    except Exception as e:
        return {"status": "error", "message": str(e)}


def list_directory(path: str = ".", pattern: Optional[str] = None) -> dict:
    """
    List files and directories.

    Args:
        path: Directory path
        pattern: Optional glob pattern (e.g., "*.py")
    """
    try:
        dir_path = Path(path).resolve()

        if not dir_path.exists():
            return {"status": "error", "message": f"Directory not found: {path}"}

        if not dir_path.is_dir():
            return {"status": "error", "message": f"Not a directory: {path}"}

        if pattern:
            items = list(dir_path.glob(pattern))
        else:
            items = list(dir_path.iterdir())

        # Limit results
        items = items[:100]

        files = []
        dirs = []

        for item in items:
            info = {
                "name": item.name,
                "path": str(item),
                "size": item.stat().st_size if item.is_file() else 0,
                "modified": item.stat().st_mtime,
            }
            if item.is_dir():
                dirs.append(info)
            else:
                files.append(info)

        return {
            "status": "success",
            "path": str(dir_path),
            "files": sorted(files, key=lambda x: x["name"]),
            "directories": sorted(dirs, key=lambda x: x["name"]),
            "total_files": len(files),
            "total_dirs": len(dirs),
        }
    except Exception as e:
        return {"status": "error", "message": str(e)}


def search_code(directory: str, query: str, file_pattern: str = "*") -> dict:
    """
    Search for text in files within a directory.

    Args:
        directory: Directory to search in
        query: Text to search for
        file_pattern: File pattern to match (e.g., "*.py")
    """
    try:
        dir_path = Path(directory).resolve()

        if not dir_path.exists():
            return {"status": "error", "message": f"Directory not found: {directory}"}

        import fnmatch

        results = []
        files_searched = 0

        for file_path in dir_path.rglob(file_pattern):
            if file_path.is_file():
                # Skip binary and large files
                if file_path.stat().st_size > 1024 * 1024:  # Skip >1MB
                    continue

                files_searched += 1
                if files_searched > 50:  # Limit search
                    break

                try:
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        lines = f.readlines()

                    for line_num, line in enumerate(lines):
                        if query.lower() in line.lower():
                            results.append({
                                "file": str(file_path.relative_to(dir_path)),
                                "line": line_num + 1,
                                "content": line.strip()[:200],
                            })

                            if len(results) >= 50:  # Limit results
                                break
                except Exception:
                    continue

                if len(results) >= 50:
                    break

        return {
            "status": "success",
            "query": query,
            "directory": str(dir_path),
            "files_searched": files_searched,
            "matches": len(results),
            "results": results[:50],
        }
    except Exception as e:
        return {"status": "error", "message": str(e)}


def execute_command(command: str, timeout: int = 30) -> dict:
    """
    Execute a shell command (sanitized for safety).

    Args:
        command: Command to execute
        timeout: Timeout in seconds
    """
    # Security: Block dangerous commands
    dangerous_patterns = [
        'rm -rf', 'sudo', 'su', 'chmod', 'chown',
        'mkfs', 'dd', 'format', ':(){', 'wget', 'curl',
        '> /dev', '/etc/passwd', '/etc/shadow',
    ]

    command_lower = command.lower()
    for pattern in dangerous_patterns:
        if pattern in command_lower:
            return {
                "status": "error",
                "message": f"Dangerous command blocked: contains '{pattern}'"
            }

    # Only allow safe commands
    allowed_commands = ['ls', 'pwd', 'echo', 'cat', 'head', 'tail', 'grep',
                        'find', 'wc', 'date', 'which', 'python', 'python3',
                        'pip', 'git', 'node', 'npm', 'cargo', 'go', 'rustc']

    first_word = command.split()[0] if command.split() else ""
    if first_word not in allowed_commands:
        return {
            "status": "error",
            "message": f"Command not allowed: '{first_word}'. Allowed: {allowed_commands}"
        }

    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=os.getcwd(),
        )

        return {
            "status": "success",
            "command": command,
            "stdout": result.stdout[:5000],
            "stderr": result.stderr[:1000],
            "return_code": result.returncode,
        }
    except subprocess.TimeoutExpired:
        return {"status": "error", "message": f"Command timed out after {timeout}s"}
    except Exception as e:
        return {"status": "error", "message": str(e)}


def analyze_code(file_path: str) -> dict:
    """
    Analyze a Python file for structure and complexity.

    Args:
        file_path: Path to Python file
    """
    try:
        path = Path(file_path).resolve()

        if not path.exists():
            return {"status": "error", "message": f"File not found: {file_path}"}

        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()

        # Basic analysis
        lines = content.split('\n')

        # Count imports
        imports = []
        functions = []
        classes = []

        for line in lines:
            stripped = line.strip()
            if stripped.startswith('import ') or stripped.startswith('from '):
                imports.append(stripped)
            elif stripped.startswith('def '):
                func_name = stripped.split('def ')[1].split('(')[0]
                functions.append(func_name)
            elif stripped.startswith('class '):
                class_name = stripped.split('class ')[1].split('(')[0].split(':')[0]
                classes.append(class_name)

        return {
            "status": "success",
            "file": str(path),
            "total_lines": len(lines),
            "non_empty_lines": len([l for l in lines if l.strip()]),
            "imports": imports[:20],
            "import_count": len(imports),
            "functions": functions,
            "function_count": len(functions),
            "classes": classes,
            "class_count": len(classes),
        }
    except Exception as e:
        return {"status": "error", "message": str(e)}


def git_operation(repo_path: str, operation: str, *args) -> dict:
    """
    Perform git operations.

    Args:
        repo_path: Path to git repository
        operation: 'status', 'log', 'diff', 'branch', 'remote'
    """
    try:
        path = Path(repo_path).resolve()

        if not path.exists():
            return {"status": "error", "message": f"Path not found: {repo_path}"}

        allowed_ops = {
            'status': ['git', 'status', '--porcelain'],
            'log': ['git', 'log', '--oneline', '-n', '20'],
            'diff': ['git', 'diff', '--stat'],
            'branch': ['git', 'branch', '-a'],
            'remote': ['git', 'remote', '-v'],
        }

        if operation not in allowed_ops:
            return {"status": "error", "message": f"Unknown operation: {operation}"}

        cmd = allowed_ops[operation]

        result = subprocess.run(
            cmd,
            cwd=str(path),
            capture_output=True,
            text=True,
            timeout=10,
        )

        return {
            "status": "success",
            "operation": operation,
            "repo": str(path),
            "output": result.stdout[:5000],
            "error": result.stderr[:1000] if result.stderr else None,
        }
    except subprocess.TimeoutExpired:
        return {"status": "error", "message": "Operation timed out"}
    except Exception as e:
        return {"status": "error", "message": str(e)}


def search_timed_news(query: str, months_back: int = 6, limit: int = 5) -> dict:
    """
    Search for news within a specific time window.

    Args:
        query: Search query (company, topic, etc.)
        months_back: Number of months to look back (default 6)
        limit: Number of articles to return
    """
    try:
        from datetime import datetime, timedelta
        import time as time_module

        # Calculate date range
        end_date = datetime.now()
        start_date = end_date - timedelta(days=months_back * 30)

        # Format for news API
        from_date = start_date.strftime("%Y-%m-%d")
        to_date = end_date.strftime("%Y-%m-%d")

        log.info(f"[TimedNews] Searching '{query}' from {from_date} to {to_date}")

        # Try NewsData.io first
        if NEWS_DATA_API_KEY:
            params = {
                "apikey": NEWS_DATA_API_KEY,
                "q": query,
                "language": "en",
                "from_date": from_date,
                "to_date": to_date,
                "size": limit,
            }

            r = requests.get(
                "https://newsdata.io/api/1/news",
                params=params,
                timeout=15
            )

            if r.status_code == 200:
                data = r.json()
                articles = []

                for item in data.get("results", [])[:limit]:
                    articles.append({
                        "title": item.get("title"),
                        "description": item.get("description"),
                        "source": item.get("source_id"),
                        "url": item.get("link"),
                        "published": item.get("pubDate"),
                        "date": item.get("pubDate"),
                    })

                return {
                    "status": "success",
                    "query": query,
                    "time_range": f"Last {months_back} months",
                    "from_date": from_date,
                    "to_date": to_date,
                    "article_count": len(articles),
                    "articles": articles,
                }

        # Fallback: Use web search with date filters
        time_filter = 'm' if months_back <= 1 else 'y' if months_back >= 12 else None
        web_results = web_search(f"{query} news", num_results=limit, time_filter=time_filter)

        if web_results.get("status") == "success":
            # Convert web results to article format
            articles = []
            for r in web_results.get("results", []):
                articles.append({
                    "title": r.get("title"),
                    "description": r.get("snippet"),
                    "source": r.get("url", "").split('/')[2] if '/' in r.get("url", "") else "Web",
                    "url": r.get("url"),
                    "date": r.get("date"),
                })

            return {
                "status": "success",
                "query": query,
                "time_range": f"Last {months_back} months (estimated)",
                "article_count": len(articles),
                "articles": articles,
                "note": "Results from web search (date-filtered)",
            }

        return {"status": "error", "message": "No news found for the specified time range"}

    except Exception as e:
        return {"status": "error", "message": str(e)}


def get_entity_timeline(entity: str, months_back: int = 12) -> dict:
    """
    Get a timeline of major events/developments for an entity.

    Args:
        entity: Company, product, or topic name
        months_back: How far back to look
    """
    try:
        log.info(f"[Timeline] Building timeline for '{entity}' over {months_back} months")

        # Search for news and developments
        news_results = search_timed_news(f"{entity} development milestone", months_back, limit=10)

        # Search for product launches
        launch_results = search_timed_news(f"{entity} launch release announced", months_back, limit=5)

        # Search for major updates
        update_results = search_timed_news(f"{entity} update version new feature", months_back, limit=5)

        timeline_events = []

        # Combine and deduplicate
        seen_urls = set()
        all_articles = []

        for result_set in [news_results, launch_results, update_results]:
            if result_set.get("status") == "success":
                for article in result_set.get("articles", []):
                    url = article.get("url", "")
                    if url and url not in seen_urls:
                        seen_urls.add(url)
                        all_articles.append(article)

        # Sort by date (newest first)
        all_articles.sort(key=lambda x: x.get("date", ""), reverse=True)

        # Categorize events
        categories = {
            "launch": ["launch", "release", "announced", "unveiled", "introduces"],
            "update": ["update", "upgrade", "version", "feature", "improves"],
            "partnership": ["partners", "collaboration", "deal", "agreement"],
            "achievement": ["achieves", "milestone", "record", "surpasses"],
            "acquisition": ["acquires", "buys", "merger", "purchase"],
        }

        for article in all_articles:
            title_lower = article.get("title", "").lower()
            desc_lower = article.get("description", "").lower()
            text = title_lower + " " + desc_lower

            category = "general"
            for cat, keywords in categories.items():
                if any(kw in text for kw in keywords):
                    category = cat
                    break

            timeline_events.append({
                "date": article.get("date"),
                "title": article.get("title"),
                "description": article.get("description", "")[:200],
                "category": category,
                "source": article.get("source"),
                "url": article.get("url"),
            })

        return {
            "status": "success",
            "entity": entity,
            "time_period": f"Last {months_back} months",
            "event_count": len(timeline_events),
            "timeline": timeline_events[:15],
            "categories": {
                cat: len([e for e in timeline_events if e["category"] == cat])
                for cat in categories.keys()
            },
        }

    except Exception as e:
        return {"status": "error", "message": str(e)}



# Update ALL_TOOLS to include codebase tools
ALL_TOOLS = [
    get_current_time,
    get_weather,
    convert_currency,
    get_date_info,
    get_world_clock,
    get_stock_price,
    get_gold_price,
    get_news,
    calculate,
    web_search,
    convert_units,
    # CodeBase Agent Tools
    read_file,
    write_file,
    list_directory,
    search_code,
    execute_command,
    analyze_code,
    git_operation,

    # Date-aware tools
    search_timed_news,
    get_entity_timeline,

    # GitHub indexing tools
    index_github_repo,
    search_indexed_code,
    list_github_repos,
    index_all_user_repos,
]

TOOL_REGISTRY = {fn.__name__: fn for fn in ALL_TOOLS}
