"""
tool_schema.py — Complete tool schemas for all functions in tools.py
"""

TOOLS = [
    # 1. Get Current Time
    {
        "type": "function",
        "function": {
            "name": "get_current_time",
            "description": "Returns the current local time and timezone for a specified city.",
            "parameters": {
                "type": "object",
                "properties": {
                    "city": {
                        "type": "string",
                        "description": "City name only (e.g. 'London', 'Tokyo'). Do NOT pass country names."
                    }
                },
                "required": ["city"]
            }
        }
    },

    # 2. Get Weather
    {
        "type": "function",
        "function": {
            "name": "get_weather",
            "description": "Returns real-time weather conditions for a specified city.",
            "parameters": {
                "type": "object",
                "properties": {
                    "city": {
                        "type": "string",
                        "description": "City name only (e.g. 'London', 'Tokyo'). Do NOT pass country names."
                    },
                    "unit": {
                        "type": "string",
                        "enum": ["celsius", "fahrenheit"],
                        "description": "Temperature unit. Defaults to 'celsius'.",
                        "default": "celsius"
                    }
                },
                "required": ["city"]
            }
        }
    },

    # 3. Currency Converter
    {
        "type": "function",
        "function": {
            "name": "convert_currency",
            "description": "Converts an amount from one currency to another using live exchange rates.",
            "parameters": {
                "type": "object",
                "properties": {
                    "amount": {
                        "type": "number",
                        "description": "The numeric amount to convert (e.g. 100, 50.50)"
                    },
                    "from_currency": {
                        "type": "string",
                        "description": "Source currency code (e.g. 'USD', 'EUR', 'INR')"
                    },
                    "to_currency": {
                        "type": "string",
                        "description": "Target currency code (e.g. 'USD', 'EUR', 'INR')"
                    }
                },
                "required": ["amount", "from_currency", "to_currency"]
            }
        }
    },

    # 4. Date & Timezone Info
    {
        "type": "function",
        "function": {
            "name": "get_date_info",
            "description": "Returns the current date, day of the week, and timezone details for a city.",
            "parameters": {
                "type": "object",
                "properties": {
                    "city": {
                        "type": "string",
                        "description": "City name only (e.g. 'London', 'Tokyo'). Do NOT pass country names."
                    }
                },
                "required": ["city"]
            }
        }
    },

    # 5. World Clock
    {
        "type": "function",
        "function": {
            "name": "get_world_clock",
            "description": "Returns the current time for multiple cities at once.",
            "parameters": {
                "type": "object",
                "properties": {
                    "cities": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "List of city names (e.g. ['Tokyo', 'London', 'New York'])",
                        "minItems": 1
                    }
                },
                "required": ["cities"]
            }
        }
    },

    # 6. Stock Price  [NEW]
    {
        "type": "function",
        "function": {
            "name": "get_stock_price",
            "description": "Returns the current stock price for a given ticker symbol. Price is delayed ~15 minutes on the free plan.",
            "parameters": {
                "type": "object",
                "properties": {
                    "ticker": {
                        "type": "string",
                        "description": "Stock ticker symbol (e.g. 'AAPL' for Apple, 'TSLA' for Tesla, 'GOOGL' for Google, '^DJI' for Dow Jones)"
                    }
                },
                "required": ["ticker"]
            }
        }
    },

    # 7. News  [NEW]
    {
        "type": "function",
        "function": {
            "name": "get_news",
            "description": "Returns the latest news headlines for a given topic.",
            "parameters": {
                "type": "object",
                "properties": {
                    "topic": {
                        "type": "string",
                        "description": "News topic to search for (e.g. 'technology', 'finance', 'sports', 'politics', 'science', 'health')"
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Number of articles to return (default 5, max 10)",
                        "default": 3
                    }
                },
                "required": ["topic"]
            }
        }
    },

    # 8. Calculator  [NEW]
    {
        "type": "function",
        "function": {
            "name": "calculate",
            "description": "Evaluates a mathematical expression and returns the result. Supports +, -, *, /, **, %, sqrt(), abs(), round(), log(), ceil(), floor(), pi, e.",
            "parameters": {
                "type": "object",
                "properties": {
                    "expression": {
                        "type": "string",
                        "description": "Math expression to evaluate (e.g. '15000 * 1.18', 'sqrt(144)', '500 / 4 + 200', '2 ** 10')"
                    }
                },
                "required": ["expression"]
            }
        }
    },
    # 9. Gold Price
    {
        "type": "function",
        "function": {
            "name": "get_gold_price",
            "description": "Returns the current gold price per troy ounce in USD. Use this for ANY query about gold price or gold value. Do NOT use get_stock_price for gold.",
            "parameters": {
                "type": "object",
                "properties": {},
                "required": []
            }
        }
    },
    # 10. Web Search  [NEW]
    {
        "type": "function",
        "function": {
            "name": "web_search",
            "description": "Searches the internet for real-time information, news, or details about any topic or entity.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Search query (e.g. 'NVIDIA latest news', 'Apple stock updates', 'AI trends 2026')"
                    },
                    "num_results": {
                        "type": "integer",
                        "description": "Number of search results to return (default 5)",
                        "default": 5
                    }
                },
                "required": ["query"]
            }
        }
    },
    # 11. Unit Converter [NEW]
    {
        "type": "function",
        "function": {
            "name": "convert_units",
            "description": "Converts between units of length, weight, volume, and temperature. Supports: km, miles, meters, feet, inches, kg, pounds, ounces, liters, gallons, cups, celsius, fahrenheit, kelvin, and more.",
            "parameters": {
                "type": "object",
                "properties": {
                    "value": {
                        "type": "number",
                        "description": "The numeric value to convert"
                    },
                    "from_unit": {
                        "type": "string",
                        "description": "Source unit (e.g., 'km', 'miles', 'kg', 'pounds', 'celsius', 'liters')"
                    },
                    "to_unit": {
                        "type": "string",
                        "description": "Target unit (e.g., 'miles', 'km', 'lbs', 'kg', 'fahrenheit', 'gallons')"
                    }
                },
                "required": ["value", "from_unit", "to_unit"]
            }
        }
    },
    # 12. Read File [CODEBASE]
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "Read a file from the filesystem with optional line range. Security: Cannot read sensitive files (.env, .git, secrets, etc.)",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to the file to read"
                    },
                    "start_line": {
                        "type": "integer",
                        "description": "Starting line number (0-indexed, default 0)",
                        "default": 0
                    },
                    "end_line": {
                        "type": "integer",
                        "description": "Ending line number (exclusive, None for all)"
                    }
                },
                "required": ["path"]
            }
        }
    },

    # 13. Write File [CODEBASE]
    {
        "type": "function",
        "function": {
            "name": "write_file",
            "description": "Write content to a file. Creates parent directories if needed.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to the file to write"
                    },
                    "content": {
                        "type": "string",
                        "description": "Content to write to the file"
                    },
                    "append": {
                        "type": "boolean",
                        "description": "If True, append instead of overwrite (default False)",
                        "default": False
                    }
                },
                "required": ["path", "content"]
            }
        }
    },

    # 14. List Directory [CODEBASE]
    {
        "type": "function",
        "function": {
            "name": "list_directory",
            "description": "List files and directories in a given path.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Directory path to list (default '.')",
                        "default": "."
                    },
                    "pattern": {
                        "type": "string",
                        "description": "Optional glob pattern (e.g., '*.py')"
                    }
                },
                "required": []
            }
        }
    },

    # 15. Search Code [CODEBASE]
    {
        "type": "function",
        "function": {
            "name": "search_code",
            "description": "Search for text in files within a directory recursively.",
            "parameters": {
                "type": "object",
                "properties": {
                    "directory": {
                        "type": "string",
                        "description": "Directory to search in"
                    },
                    "query": {
                        "type": "string",
                        "description": "Text to search for"
                    },
                    "file_pattern": {
                        "type": "string",
                        "description": "File pattern to match (e.g., '*.py', default '*')",
                        "default": "*"
                    }
                },
                "required": ["directory", "query"]
            }
        }
    },

    # 16. Execute Command [CODEBASE]
    {
        "type": "function",
        "function": {
            "name": "execute_command",
            "description": "Execute a safe shell command. Allowed: ls, pwd, cat, grep, find, git, python, etc. Dangerous commands are blocked.",
            "parameters": {
                "type": "object",
                "properties": {
                    "command": {
                        "type": "string",
                        "description": "Command to execute"
                    },
                    "timeout": {
                        "type": "integer",
                        "description": "Timeout in seconds (default 30)",
                        "default": 30
                    }
                },
                "required": ["command"]
            }
        }
    },

    # 17. Analyze Code [CODEBASE]
    {
        "type": "function",
        "function": {
            "name": "analyze_code",
            "description": "Analyze a Python file for structure: imports, functions, classes, and line counts.",
            "parameters": {
                "type": "object",
                "properties": {
                    "file_path": {
                        "type": "string",
                        "description": "Path to Python file to analyze"
                    }
                },
                "required": ["file_path"]
            }
        }
    },

    # 18. Git Operation [CODEBASE]
    {
        "type": "function",
        "function": {
            "name": "git_operation",
            "description": "Perform git operations: status, log, diff, branch, remote.",
            "parameters": {
                "type": "object",
                "properties": {
                    "repo_path": {
                        "type": "string",
                        "description": "Path to git repository"
                    },
                    "operation": {
                        "type": "string",
                        "enum": ["status", "log", "diff", "branch", "remote"],
                        "description": "Git operation to perform"
                    }
                },
                "required": ["repo_path", "operation"]
            }
        }
    },

    # 19. Search Timed News [DATE-AWARE]
    {
        "type": "function",
        "function": {
            "name": "search_timed_news",
            "description": "Search for news within a specific time window (last N months).",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Search query (company, topic, etc.)"
                    },
                    "months_back": {
                        "type": "integer",
                        "description": "Number of months to look back (default 6)",
                        "default": 6
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Number of articles to return (default 5)",
                        "default": 5
                    }
                },
                "required": ["query"]
            }
        }
    },

    # 20. Get Entity Timeline [DATE-AWARE]
    {
        "type": "function",
        "function": {
            "name": "get_entity_timeline",
            "description": "Get a timeline of major events/developments for a company, product, or topic.",
            "parameters": {
                "type": "object",
                "properties": {
                    "entity": {
                        "type": "string",
                        "description": "Company, product, or topic name"
                    },
                    "months_back": {
                        "type": "integer",
                        "description": "How far back to look in months (default 12)",
                        "default": 12
                    }
                },
                "required": ["entity"]
            }
        }
    },

    # 21. Index GitHub Repo [GITHUB]
    {
        "type": "function",
        "function": {
            "name": "index_github_repo",
            "description": "Clone and index a GitHub repository into the vector database for code search.",
            "parameters": {
                "type": "object",
                "properties": {
                    "repo_url": {
                        "type": "string",
                        "description": "GitHub repository URL (e.g., https://github.com/user/repo)"
                    },
                    "github_token": {
                        "type": "string",
                        "description": "Optional GitHub personal access token for private repos"
                    }
                },
                "required": ["repo_url"]
            }
        }
    },

    # 22. Search Indexed Code [GITHUB]
    {
        "type": "function",
        "function": {
            "name": "search_indexed_code",
            "description": "Search indexed code from GitHub repositories for relevant snippets.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Search query"
                    },
                    "repo_name": {
                        "type": "string",
                        "description": "Optional specific repo to search"
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Number of results (default 10)",
                        "default": 10
                    }
                },
                "required": ["query"]
            }
        }
    },

    # 23. List GitHub Repos [GITHUB]
    {
        "type": "function",
        "function": {
            "name": "list_github_repos",
            "description": "List all indexed GitHub repositories in the vector database.",
            "parameters": {
                "type": "object",
                "properties": {},
                "required": []
            }
        }
    },

    # 24. Index All User Repos [GITHUB]
    {
        "type": "function",
        "function": {
            "name": "index_all_user_repos",
            "description": "Index all repositories for a GitHub user.",
            "parameters": {
                "type": "object",
                "properties": {
                    "github_username": {
                        "type": "string",
                        "description": "GitHub username"
                    },
                    "github_token": {
                        "type": "string",
                        "description": "GitHub personal access token"
                    }
                },
                "required": ["github_username", "github_token"]
            }
        }
    },
]
