"""
logger.py — Structured logging for the agent system.
Replaces all print() calls with proper log levels.

Usage:
    from logger import log
    log.info("Tool executed")
    log.warning("Planner dropped step")
    log.error("API call failed")
    log.debug("Raw response: ...")
"""

import logging
import sys
from datetime import datetime


# ---------------------------------------------------------------------------
# Formatter — clean, timestamped, colored output in terminal
# ---------------------------------------------------------------------------
class ColorFormatter(logging.Formatter):
    COLORS = {
        logging.DEBUG: "\033[36m",  # Cyan
        logging.INFO: "\033[32m",  # Green
        logging.WARNING: "\033[33m",  # Yellow
        logging.ERROR: "\033[31m",  # Red
        logging.CRITICAL: "\033[35m",  # Magenta
    }
    RESET = "\033[0m"

    def format(self, record):
        color = self.COLORS.get(record.levelno, self.RESET)
        time = datetime.now().strftime("%H:%M:%S")
        level = record.levelname.ljust(8)
        return f"{color}[{time}] [{level}] {record.getMessage()}{self.RESET}"


# ---------------------------------------------------------------------------
# File formatter — plain text, no colors (for log files)
# ---------------------------------------------------------------------------
class PlainFormatter(logging.Formatter):
    def format(self, record):
        time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        level = record.levelname.ljust(8)
        return f"[{time}] [{level}] {record.getMessage()}"


# ---------------------------------------------------------------------------
# Build the logger
# ---------------------------------------------------------------------------
def _build_logger() -> logging.Logger:
    logger = logging.getLogger("agent")
    logger.setLevel(logging.DEBUG)

    # Terminal handler — INFO and above
    console = logging.StreamHandler(sys.stdout)
    console.setLevel(logging.INFO)
    console.setFormatter(ColorFormatter())

    # File handler — DEBUG and above (full trace)
    file_handler = logging.FileHandler("agent.log", encoding="utf-8")
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(PlainFormatter())

    logger.addHandler(console)
    logger.addHandler(file_handler)

    return logger


log = _build_logger()
