# Folder Structure of the project Log Analysis Agent:

log_multi_agent/
│
├── main.py                      # Entry point (CLI runner)
├── config.py                    # Global configs (models, paths, flags)
├── requirements.txt
├── README.md
│
├── orchestrator/                # 🧠 Central brain
│   ├── orchestrator.py          # Main routing logic
│   ├── planner.py               # Task planning / step generation
│   ├── router.py                # Agent selection logic
│   ├── state.py                 # Shared state object
│   └── retry.py                 # Retry / fallback strategies
│
├── agents/                      # 🤖 All agents
│   │
│   ├── extractor/
│   │   ├── agent.py             # Extractor agent
│   │   ├── loaders/
│   │   │   ├── file_loader.py
│   │   │   ├── image_loader.py  # uses OCR
│   │   │   └── terminal_loader.py
│   │   └── permissions.py       # user approval logic
│   │
│   ├── preprocessor/
│   │   ├── agent.py
│   │   ├── cleaner.py
│   │   ├── parser.py
│   │   └── chunker.py
│   │
│   ├── classifier/
│   │   ├── agent.py
│   │   └── prompt.py
│   │
│   ├── intent/
│   │   ├── agent.py
│   │   └── prompt.py
│   │
│   ├── solver/
│   │   ├── agent.py
│   │   ├── error_analyzer.py
│   │   ├── fix_generator.py
│   │   ├── explanation_generator.py
│   │   └── prompt.py
│   │
│   ├── debugger/
│   │   ├── agent.py
│   │   ├── code_parser.py
│   │   └── patch_generator.py
│   │
│   ├── critic/
│   │   ├── agent.py
│   │   └── evaluator.py
│   │
│   └── memory/
│       ├── agent.py
│       ├── vector_store.py      # ChromaDB wrapper
│       └── retrieval.py
│
├── models/                      # 🧠 Model layer
│   ├── llm/
│   │   ├── loader.py            # llama-cpp loader
│   │   ├── qwen.py              # Qwen wrapper
│   │   └── inference.py
│   │
│   ├── ocr/
│   │   └── deepseek_ocr.py
│   │
│   └── embeddings/
│       └── embedding_model.py
│
├── tools/                       # 🔧 MCP tools
│   ├── file_tool.py
│   ├── terminal_tool.py
│   ├── ocr_tool.py
│   ├── search_tool.py
│   └── registry.py              # tool registry
│
├── mcp_server/                  # ⚡ MCP integration
│   ├── server.py
│   ├── tool_adapter.py
│   └── schemas.py
│
├── memory_store/                # 💾 persistent storage
│   ├── chroma_db/
│   └── logs/
│
├── prompts/                     # 🧾 prompt templates
│   ├── classifier.txt
│   ├── solver.txt
│   ├── debugger.txt
│   ├── critic.txt
│   └── intent.txt
│
├── utils/                       # 🧩 utilities
│   ├── logger.py
│   ├── json_utils.py
│   ├── validators.py
│   └── chunking.py
│
├── tests/                       # 🧪 testing
│   ├── test_agents.py
│   ├── test_orchestrator.py
│   └── test_tools.py
│
└── scripts/                     # ⚙️ helper scripts
    ├── download_models.py
    ├── quantize_model.sh
    └── run_server.sh

# 🧠 Log Analysis Multi-Agent System (Terminal-Based)

A **modular, CPU-friendly multi-agent system** for analyzing logs from multiple sources (text, files, images, terminal), classifying them, debugging errors, and generating intelligent solutions using locally hosted LLMs.

Built with:

* 🐍 Python
* 🧩 MCP (Model Context Protocol)
* ⚡ Local inference via llama-cpp-python
* 🧠 LLM: Qwen2.5-7B-Instruct (GGUF)
* 🖼 OCR: DeepSeek-OCR2

---

# 🚀 Features

* 📥 Multi-source log ingestion

  * Files (`.log`, `.txt`, `.json`)
  * Terminal commands
  * Image-based logs (OCR)

* 🧹 Intelligent preprocessing

  * Noise removal
  * Log structuring
  * Chunking for large inputs

* 🧠 Log classification

  * Error logs
  * Server logs
  * Application logs
  * Security logs

* 🎯 Intent understanding

  * Debugging
  * Explanation
  * Optimization

* 🛠 Multi-step reasoning solver

  * Root cause analysis
  * Fix generation
  * Human-readable explanation

* 🧑‍💻 Code debugging agent

  * Parses stack traces
  * Suggests patches

* ✅ Critic / evaluation agent

  * Validates output quality
  * Reduces hallucinations

* 💾 Memory system (optional)

  * Stores past logs & solutions
  * Enables retrieval-based reasoning

* ⚙️ Fully terminal-based

* 🔌 MCP-compatible tool system

* 🧠 Single-model optimized for CPU environments

---

# 🏗️ Architecture Overview

```text
User (CLI)
   ↓
Orchestrator
   ↓
[Extractor] → [Preprocessor] → [Classifier] → [Intent]
   ↓
[Solver] → [Debugger (if needed)]
   ↓
[Critic]
   ↓
Final Output
   ↘
   Memory (optional)
```

---

# 📦 Project Structure

```bash
log_multi_agent/
│
├── main.py
├── config.py
├── requirements.txt
├── README.md
│
├── orchestrator/
├── agents/
├── models/
├── tools/
├── mcp_server/
├── memory_store/
├── prompts/
├── utils/
├── tests/
└── scripts/
```

### Key Modules

#### 🧠 `orchestrator/`

Controls the entire pipeline:

* Task planning
* Agent routing
* State management
* Retry logic

#### 🤖 `agents/`

Each agent is modular and specialized:

* extractor
* preprocessor
* classifier
* intent
* solver
* debugger
* critic
* memory

#### 🧠 `models/`

Handles all model interactions:

* LLM loading (llama.cpp)
* OCR integration
* Embeddings

#### 🔧 `tools/`

MCP-compatible tools:

* File access
* Terminal execution
* OCR
* Search

#### ⚡ `mcp_server/`

Connects agents to tools via MCP protocol.

---

# ⚙️ Installation

## 1. Clone Repository

```bash
git clone https://github.com/your-username/log_multi_agent.git
cd log_multi_agent
```

---

## 2. Create Virtual Environment

```bash
python -m venv venv
source venv/bin/activate   # Linux/Mac
venv\Scripts\activate      # Windows
```

---

## 3. Install Dependencies

```bash
pip install -r requirements.txt
```

---

## 4. Download Models

### LLM (Required)

Download GGUF version of:

* Qwen2.5-7B-Instruct (quantized)

Place inside:

```bash
models/llm/
```

---

### OCR Model (Optional)

Download:

* DeepSeek-OCR2

Place inside:

```bash
models/ocr/
```

---

# ▶️ Usage

## Run the System

```bash
python main.py
```

---

## Example Inputs

### 1. File Input

```bash
Enter log file path: logs/error.log
```

### 2. Image Input

```bash
Enter image path: screenshots/error.png
```

### 3. Direct Input

```bash
Paste your logs here...
```

---

# 🧠 Model Strategy

⚠️ This project is optimized for **CPU (16GB RAM)**.

### ✔ Recommended Setup

| Purpose   | Model             |
| --------- | ----------------- |
| Reasoning | Qwen2.5-7B (GGUF) |
| OCR       | DeepSeek-OCR2     |

### ❗ Important Rules

* Only **one LLM loaded at a time**
* All agents share the same model
* OCR model loads **only when needed**

---

# 🧩 Agent Design

Each agent follows a simple interface:

```python
class Agent:
    def run(self, state: dict) -> dict:
        return updated_state
```

---

## 🧠 State Object

All communication happens through a shared state:

```python
state = {
    "input": "",
    "raw_logs": None,
    "clean_logs": None,
    "log_type": None,
    "intent": None,
    "solution": None,
    "evaluation": None,
    "history": []
}
```

---

# 🔌 MCP Tools

Available tools:

* `file_reader`
* `terminal_exec`
* `ocr_tool`
* `vector_search`

---

# 🧪 Testing

```bash
pytest tests/
```

---

# ⚡ Scripts

```bash
scripts/
├── download_models.py
├── quantize_model.sh
└── run_server.sh
```

---

# 🚧 Roadmap

## Phase 1

* Core pipeline (Extractor → Solver)

## Phase 2

* Debugger agent
* Critic agent

## Phase 3

* Memory system
* Optimization

## Phase 4

* Web UI (optional)

---

# ⚠️ Limitations

* CPU-only → slower inference
* Large logs must be chunked
* Not suitable for real-time streaming (yet)

---

# 💡 Future Improvements

* Streaming logs support
* Distributed agent execution
* Model fine-tuning for logs
* GUI dashboard

---

# 🤝 Contributing

Contributions are welcome!

1. Fork the repo
2. Create a feature branch
3. Submit a PR

---

# 📜 License

MIT License

---

# 🙌 Acknowledgements

* llama.cpp
* Qwen
* ChromaDB

---

# ⭐ Final Note

This project is designed to be:

* Modular
* Scalable
* CPU-efficient

Start small, expand gradually, and avoid overloading your system with unnecessary complexity.

---


Some changes based on A2A protocol messaging between agents:

Complete Redesigned Project Structure-:

log_multi_agent/
│
├── main.py                          # Entry point (CLI runner)
├── config.py                        # Global configs (models, paths, flags)
├── requirements.txt
├── README.md
├── pyproject.toml                   # ADK project config
├── .env                             # Environment variables
│
├── agentos/                         # 🧠 ADK-based agent runtime
│   ├── __init__.py
│   ├── agent_registry.py            # Central registry of all agents
│   ├── capability_registry.py       # Global capability aggregation
│   ├── communication_bus.py         # A2A message bus
│   ├── message_protocol.py          # A2A message schemas & routing
│   └── session_manager.py           # Session & context management
│
├── agents/                          # 🤖 All autonomous agents
│   │
│   ├── base_agent.py                # ADK-compliant base agent class
│   ├── agent_config.py              # Common agent configuration patterns
│   │
│   ├── extractor/
│   │   ├── __init__.py
│   │   ├── agent.py                 # ADK Agent subclass
│   │   ├── capabilities.json        # Capability contract
│   │   ├── prompts.py               # System prompts & templates
│   │   ├── tools.py                 # ADK tools registered to this agent
│   │   ├── loaders/
│   │   │   ├── __init__.py
│   │   │   ├── file_loader.py
│   │   │   ├── image_loader.py
│   │   │   └── terminal_loader.py
│   │   └── tests/
│   │       ├── __init__.py
│   │       └── test_extractor.py
│   │
│   ├── preprocessor/
│   │   ├── __init__.py
│   │   ├── agent.py
│   │   ├── capabilities.json
│   │   ├── prompts.py
│   │   ├── tools.py
│   │   ├── cleaner.py
│   │   ├── parser.py
│   │   ├── chunker.py
│   │   └── tests/
│   │       ├── __init__.py
│   │       └── test_preprocessor.py
│   │
│   ├── analyzer/                    # 🔄 MERGED: Classifier + Intent
│   │   ├── __init__.py
│   │   ├── agent.py
│   │   ├── capabilities.json
│   │   ├── prompts.py               # Combined classification + intent prompts
│   │   ├── tools.py
│   │   └── tests/
│   │       ├── __init__.py
│   │       └── test_analyzer.py
│   │
│   ├── solver/
│   │   ├── __init__.py
│   │   ├── agent.py
│   │   ├── capabilities.json
│   │   ├── prompts.py
│   │   ├── tools.py
│   │   ├── error_analyzer.py
│   │   ├── explanation_generator.py
│   │   └── tests/
│   │       ├── __init__.py
│   │       └── test_solver.py
│   │
│   ├── debugger/
│   │   ├── __init__.py
│   │   ├── agent.py
│   │   ├── capabilities.json
│   │   ├── prompts.py
│   │   ├── tools.py
│   │   ├── code_parser.py
│   │   ├── patch_generator.py
│   │   └── tests/
│   │       ├── __init__.py
│   │       └── test_debugger.py
│   │
│   ├── critic/
│   │   ├── __init__.py
│   │   ├── agent.py
│   │   ├── capabilities.json
│   │   ├── prompts.py
│   │   ├── tools.py
│   │   ├── evaluator.py
│   │   ├── safety_checker.py        # 🔒 NEW: Security validation
│   │   └── tests/
│   │       ├── __init__.py
│   │       └── test_critic.py
│   │
│   ├── memory/
│   │   ├── __init__.py
│   │   ├── agent.py
│   │   ├── capabilities.json
│   │   ├── prompts.py
│   │   ├── tools.py
│   │   ├── vector_store.py
│   │   ├── retrieval.py
│   │   └── tests/
│   │       ├── __init__.py
│   │       └── test_memory.py
│   │
│   └── orchestrator/                # 🔄 DEMOTED: Now just another agent
│       ├── __init__.py
│       ├── agent.py                 # ADK Agent for coordination
│       ├── capabilities.json
│       ├── prompts.py
│       ├── tools.py
│       ├── planner.py               # Dynamic task planning
│       ├── router.py                # A2A message routing logic
│       └── tests/
│           ├── __init__.py
│           └── test_orchestrator.py
│
├── models/                          # 🧪 Model layer (unchanged conceptually)
│   ├── __init__.py
│   ├── llm/
│   │   ├── __init__.py
│   │   ├── loader.py
│   │   ├── qwen.py
│   │   └── inference.py
│   ├── ocr/
│   │   ├── __init__.py
│   │   └── deepseek_ocr.py
│   └── embeddings/
│       ├── __init__.py
│       └── embedding_model.py
│
├── tools/                           # 🔧 MCP tools (shared across agents)
│   ├── __init__.py
│   ├── base_tool.py                 # ADK tool base class
│   ├── file_tool.py
│   ├── terminal_tool.py             # With sandboxing
│   ├── ocr_tool.py
│   ├── search_tool.py
│   ├── code_analysis_tool.py        # NEW: For debugger
│   ├── registry.py                  # Tool registry with capability mapping
│   └── sandbox.py                   # NEW: Terminal sandbox wrapper
│
├── safety/                          # 🔒 NEW: Security layer
│   ├── __init__.py
│   ├── command_whitelist.py         # Terminal command whitelist
│   ├── permission_manager.py        # User approval gates
│   ├── input_sanitizer.py           # Log input sanitization
│   └── audit_logger.py              # Security audit trail
│
├── communication/                   # 📡 A2A Protocol Implementation
│   ├── __init__.py
│   ├── a2a_protocol.py             # Agent-to-Agent message format
│   ├── message_broker.py           # Pub/sub message broker
│   ├── discovery.py                # Agent discovery service
│   └── schemas.py                  # Message type definitions
│
├── memory_store/                    # 💾 Persistent storage
│   ├── chroma_db/
│   └── logs/
│
├── prompts/                         # 🧾 Prompt templates
│   ├── analyzer.txt                 # RENAMED from classifier+intent
│   ├── solver.txt
│   ├── debugger.txt
│   ├── critic.txt
│   ├── orchestrator.txt             # NEW
│   └── safety_checker.txt           # NEW
│
├── utils/                           # 🧩 Utilities
│   ├── __init__.py
│   ├── logger.py
│   ├── json_utils.py
│   ├── validators.py
│   ├── chunking.py
│   ├── response_formatter.py        # NEW: Graceful output formatting
│   └── confidence.py                # NEW: Confidence scoring utilities
│
├── tests/                           # 🧪 Integration & E2E tests
│   ├── __init__.py
│   ├── conftest.py                  # Test fixtures
│   ├── integration/
│   │   ├── __init__.py
│   │   ├── test_a2a_communication.py
│   │   ├── test_agent_collaboration.py
│   │   └── test_edge_cases.py
│   └── e2e/
│       ├── __init__.py
│       ├── test_full_pipeline.py
│       └── test_security_scenarios.py
│
├── scripts/                         # ⚙️ Helper scripts
│   ├── download_models.py
│   ├── quantize_model.sh
│   ├── run_server.sh
│   └── init_adk_project.sh          # NEW: ADK initialization
│
└── docs/                            # 📚 Documentation
    ├── architecture.md
    ├── a2a_protocol_spec.md
    ├── agent_capabilities.md
    ├── security_model.md
    └── adk_setup_guide.md


Core Architectural Changes: Agent-to-Agent Protocol with ADK:

Architecture Diagram:-

┌─────────────────────────────────────────────────────────────────┐
│                        AGENT ECOSYSTEM                                                │
│                                                                                       │
│  ┌──────────┐    A2A     ┌──────────┐    A2A     ┌──────────┐             │
│  │ Extractor│◄──────────►│Analyzer  │◄──────────►│  Solver   │             │
│  └────┬─────┘  Messages  └────┬─────┘  Messages  └────┬─────┘             │
│       │                            │                           │                     │
│       │         ┌─────────────┼───────────────┐      │                     │
│       │         │                 │                    │       │                    │
│       │    ┌────▼─────┐  ┌────▼─────┐   ┌─────▼─┐   │                    │
│       │    │ Debugger    │  │  Critic      │   │  Memory │    │                    │
│       │    └──────────┘  └──────────┘   └───────┘    │                    │
│       │                                                         │                    │
│  ┌────▼─────────────────────────────────────┐    │                    │
│  │              Orchestrator Agent                        │    │                     │
│  │  (First contact, task decomposition, routing)          │◄──┘                    │
│  └──────────────────────────────────────────┘                          │
│                                                                                       │
│  All connected via: Communication Bus (A2A Protocol)                                  │
└─────────────────────────────────────────────────────────────────┘
