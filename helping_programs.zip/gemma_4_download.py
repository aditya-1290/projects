import os
from huggingface_hub import snapshot_download
from huggingface_hub.utils import HfHubHTTPError

def download_gemma_model():
    model_id = "google/gemma-4-E4B-it"
    local_dir = "D:/python_tasks/models/gemma-4-E4B-it"
    
    print(f"Starting download of {model_id}...")
    print(f"This model is approximately 16 GB. Download may take a while.")
    
    try:
        # Download all files
        snapshot_download(
            repo_id=model_id,
            local_dir=local_dir,
            local_dir_use_symlinks=False,
            resume_download=True,
            ignore_patterns=[".gitattributes", "*.md"],  # Skip if you don't need docs
        )
        
        print("\n✅ Download complete!")
        print(f"Files saved to: {os.path.abspath(local_dir)}")
        
        # List downloaded files
        print("\nDownloaded files:")
        for file in os.listdir(local_dir):
            size = os.path.getsize(os.path.join(local_dir, file)) / (1024**3)
            print(f"  - {file} ({size:.2f} GB)")
            
    except HfHubHTTPError as e:
        print(f"❌ Download failed: {e}")
        print("Try again or check your internet connection.")
    except KeyboardInterrupt:
        print("\n⚠️ Download interrupted. Run again to resume.")
    except Exception as e:
        print(f"❌ Unexpected error: {e}")

if __name__ == "__main__":
    download_gemma_model()
