import os
from huggingface_hub import snapshot_download

def download_deepseek_ocr2():
    """
    Downloads the DeepSeek-OCR-2 model from Hugging Face Hub.
    """
    # --- Configuration ---
    repo_id = "deepseek-ai/DeepSeek-OCR-2" # The official repository ID [citation:1]
    local_dir = "./DeepSeek-OCR-2"         # The folder where the model will be saved
    use_mirror = True                      # Set to False if you are not in a region with slow access to HF

    # --- Optional: Use a mirror for faster download speeds (e.g., in China) ---
    if use_mirror:
        # Set the environment variable to use the HF mirror
        os.environ["HF_ENDPOINT"] = "https://hf-mirror.com"
        print("INFO: Using Hugging Face mirror (hf-mirror.com) for faster download.") # [citation:8]

    print(f"Starting download of '{repo_id}'...")
    print(f"Model will be saved to: '{os.path.abspath(local_dir)}'")
    print("This may take a while depending on your network speed.")

    try:
        # --- Download the entire model snapshot ---
        snapshot_download(
            repo_id=repo_id,
            local_dir=local_dir,
            local_dir_use_symlinks=False, # Ensures actual files are copied, not symlinks [citation:10]
            resume_download=True,          # Allows resuming if the download is interrupted [citation:8]
            ignore_patterns=["*.md", ".gitattributes"], # Optional: skips downloading documentation files
        )

        print("\n" + "="*50)
        print("✅ Download completed successfully!")
        print("="*50)
        print(f"All model files are located in: {os.path.abspath(local_dir)}")

        # List the contents of the download directory
        print("\nDownloaded files and folders:")
        for item in os.listdir(local_dir):
            print(f"  - {item}")

    except Exception as e:
        print(f"\n❌ An error occurred during download: {e}")
        print("Please check your internet connection and try again.")

if __name__ == "__main__":
    download_deepseek_ocr2()
