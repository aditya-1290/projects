from huggingface_hub import hf_hub_download

# Choose the repo that hosts GGUF files
repo_id = "TheBloke/Mistral-7B-Instruct-v0.2-GGUF"

# Choose quantization (IMPORTANT)
filename = "mistral-7b-instruct-v0.2.Q4_K_M.gguf"

# Download
file_path = hf_hub_download(
    repo_id=repo_id,
    filename=filename,
    local_dir="D:/python_tasks/models/mistral_model",
    local_dir_use_symlinks=False
)

print(f"Downloaded to: {file_path}")
