#!/usr/bin/env python3
"""
Script to download Qwen/Qwen2.5-7B-Instruct model locally to D:\python_tasks\models
"""

import os
import sys
from pathlib import Path

# Your specified download directory
DOWNLOAD_DIR = Path("D:/python_tasks/models")
MODEL_SAVE_PATH = DOWNLOAD_DIR / "qwen2.5-7b-instruct"

def download_model_with_huggingface():
    """Download model using Hugging Face transformers"""
    try:
        from transformers import AutoModelForCausalLM, AutoTokenizer
        import torch
        
        model_name = "Qwen/Qwen2.5-7B-Instruct"
        
        # Create directory if it doesn't exist
        MODEL_SAVE_PATH.mkdir(parents=True, exist_ok=True)
        
        print(f"📁 Downloading model to: {MODEL_SAVE_PATH}")
        print(f"🤖 Model: {model_name}")
        print("⚠️  This model is ~14GB. Download may take some time...\n")
        
        # Download tokenizer
        print("📝 Downloading tokenizer...")
        tokenizer = AutoTokenizer.from_pretrained(
            model_name,
            trust_remote_code=True
        )
        print("✅ Tokenizer downloaded successfully!")
        
        # Download model
        print("\n🔧 Downloading model (this may take 10-30 minutes depending on your connection)...")
        model = AutoModelForCausalLM.from_pretrained(
            model_name,
            torch_dtype=torch.float16,  # Use float16 to save space
            device_map="auto",  # Automatically distribute across available devices
            trust_remote_code=True
        )
        
        print("\n✅ Model downloaded successfully!")
        
        # Save model to your specified directory
        print(f"\n💾 Saving model to: {MODEL_SAVE_PATH}")
        
        model.save_pretrained(MODEL_SAVE_PATH)
        tokenizer.save_pretrained(MODEL_SAVE_PATH)
        
        # Calculate and display model size
        total_size = sum(f.stat().st_size for f in MODEL_SAVE_PATH.rglob('*') if f.is_file())
        print(f"\n🎉 Model saved successfully to: {MODEL_SAVE_PATH}")
        print(f"📊 Model size: ~{total_size / (1024**3):.2f} GB")
        
        return MODEL_SAVE_PATH
        
    except ImportError as e:
        print("❌ Missing required libraries!")
        print("Please install the required packages:")
        print("pip install transformers torch accelerate")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Error downloading model: {e}")
        sys.exit(1)

def download_model_with_snapshot():
    """Alternative method using huggingface_hub snapshot_download"""
    try:
        from huggingface_hub import snapshot_download
        
        model_name = "Qwen/Qwen2.5-7B-Instruct"
        
        # Create directory if it doesn't exist
        MODEL_SAVE_PATH.mkdir(parents=True, exist_ok=True)
        
        print(f"📁 Downloading model to: {MODEL_SAVE_PATH}")
        print(f"🤖 Model: {model_name}")
        print("⚠️  This model is ~14GB. Download may take some time...\n")
        
        # Download entire model repository
        snapshot_download(
            repo_id=model_name,
            local_dir=MODEL_SAVE_PATH,
            local_dir_use_symlinks=False,
            resume_download=True,
            ignore_patterns=["*.h5", "*.ot", "*.msgpack"]  # Ignore some file types if present
        )
        
        # Calculate and display model size
        total_size = sum(f.stat().st_size for f in MODEL_SAVE_PATH.rglob('*') if f.is_file())
        print(f"\n🎉 Model downloaded successfully to: {MODEL_SAVE_PATH}")
        print(f"📊 Model size: ~{total_size / (1024**3):.2f} GB")
        
        return MODEL_SAVE_PATH
        
    except ImportError:
        print("❌ Missing huggingface_hub library!")
        print("Please install: pip install huggingface_hub")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Error downloading model: {e}")
        sys.exit(1)

def test_model_load(model_path):
    """Test if the model can be loaded properly"""
    try:
        from transformers import AutoModelForCausalLM, AutoTokenizer
        import torch
        
        print("\n🧪 Testing model loading...")
        
        tokenizer = AutoTokenizer.from_pretrained(model_path, trust_remote_code=True)
        model = AutoModelForCausalLM.from_pretrained(
            model_path,
            torch_dtype=torch.float16,
            device_map="auto",
            trust_remote_code=True
        )
        
        print("✅ Model loaded successfully!")
        
        # Test inference
        print("\n💬 Testing inference with a simple prompt...")
        messages = [
            {"role": "user", "content": "Hello! Who are you?"}
        ]
        
        text = tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True
        )
        
        inputs = tokenizer(text, return_tensors="pt").to(model.device)
        
        with torch.no_grad():
            outputs = model.generate(
                **inputs,
                max_new_tokens=100,
                temperature=0.7,
                do_sample=True
            )
        
        response = tokenizer.decode(outputs[0], skip_special_tokens=True)
        print(f"Response: {response}")
        print("\n✅ Model is working correctly!")
        
    except Exception as e:
        print(f"❌ Error testing model: {e}")

def check_disk_space():
    """Check available disk space on D: drive"""
    try:
        import shutil
        
        # Check space on D: drive
        d_drive_path = "D:/"
        if os.path.exists(d_drive_path):
            usage = shutil.disk_usage(d_drive_path)
            free_space_gb = usage.free / (1024**3)
            print(f"💾 Available space on D: drive: {free_space_gb:.2f} GB")
            
            if free_space_gb < 30:
                print(f"⚠️  Warning: Only {free_space_gb:.1f}GB free space available.")
                print("This model requires ~14GB + temporary download space.")
                response = input("Continue anyway? (y/n): ")
                if response.lower() != 'y':
                    print("Exiting...")
                    sys.exit(0)
            else:
                print("✅ Sufficient disk space available.")
        else:
            print("⚠️  Could not check D: drive space. Continuing anyway...")
    except Exception as e:
        print(f"⚠️  Could not check disk space: {e}")

def main():
    print("=" * 60)
    print("Qwen/Qwen2.5-7B-Instruct Model Downloader")
    print(f"Download location: {MODEL_SAVE_PATH}")
    print("=" * 60)
    
    # Check if model already exists
    if MODEL_SAVE_PATH.exists() and any(MODEL_SAVE_PATH.iterdir()):
        print(f"\n⚠️  Model directory already exists at {MODEL_SAVE_PATH}")
        response = input("Do you want to re-download/overwrite? (y/n): ")
        if response.lower() != 'y':
            print("Exiting...")
            sys.exit(0)
    
    # Check available disk space
    check_disk_space()
    
    print("\nChoose download method:")
    print("1. Using Transformers (recommended - includes tokenizer and model in one go)")
    print("2. Using HuggingFace Hub snapshot (downloads entire repository)")
    
    choice = input("\nEnter your choice (1 or 2): ").strip()
    
    if choice == "1":
        model_path = download_model_with_huggingface()
    elif choice == "2":
        model_path = download_model_with_snapshot()
    else:
        print("Invalid choice. Using method 1 as default.")
        model_path = download_model_with_huggingface()
    
    # Test the downloaded model
    test_model_load(model_path)
    
    print("\n" + "=" * 60)
    print("✨ Download complete! ✨")
    print(f"Model location: {model_path}")
    print("\nTo use the model in your code:")
    print(f"""
from transformers import AutoModelForCausalLM, AutoTokenizer

model_path = r"{model_path}"
tokenizer = AutoTokenizer.from_pretrained(model_path, trust_remote_code=True)
model = AutoModelForCausalLM.from_pretrained(model_path, trust_remote_code=True)

# For better performance on GPU:
# model = AutoModelForCausalLM.from_pretrained(
#     model_path, 
#     torch_dtype=torch.float16,
#     device_map="auto",
#     trust_remote_code=True
# )
    """)
    print("=" * 60)

if __name__ == "__main__":
    main()
