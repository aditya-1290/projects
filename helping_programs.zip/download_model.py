import os
from transformers import AutoModelForImageClassification, AutoImageProcessor

MODEL_NAME = "google/vit-base-patch16-224"
CACHE_DIR = "D:/python_tasks/models/classification_model/models"

print("Downloading model...")
print("Saving to:", os.path.abspath(CACHE_DIR))

model = AutoModelForImageClassification.from_pretrained(
    MODEL_NAME,
    cache_dir=CACHE_DIR
)

processor = AutoImageProcessor.from_pretrained(
    MODEL_NAME,
    cache_dir=CACHE_DIR
)

print("Model downloaded successfully!")


# 🔍 Verify contents
print("\nFiles in directory:")
for root, dirs, files in os.walk(CACHE_DIR):
    print(root, files)
