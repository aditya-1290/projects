import os
from huggingface_hub import snapshot_download

def download_bge_small():
    """
    Downloads the BAAI/bge-small-en-v1.5 embedding model from Hugging Face.
    """
    # --- Configuration ---
    repo_id = "BAAI/bge-small-en-v1.5"
    local_dir = "./bge-small-en-v1.5"
    
    print(f"Downloading '{repo_id}'...")
    print(f"Save location: {os.path.abspath(local_dir)}")
    print("Model size: ~133 MB (small and fast to download)\n")
    
    try:
        # Download the complete model snapshot
        snapshot_download(
            repo_id=repo_id,
            local_dir=local_dir,
            local_dir_use_symlinks=False,
            resume_download=True,
            ignore_patterns=["*.md", ".gitattributes"],  # Skip docs
        )
        
        print("\n✅ Download complete!")
        print(f"Files saved to: {os.path.abspath(local_dir)}")
        
        # Show downloaded files
        print("\nDownloaded files:")
        total_size = 0
        for file in os.listdir(local_dir):
            file_path = os.path.join(local_dir, file)
            if os.path.isfile(file_path):
                size_mb = os.path.getsize(file_path) / (1024 * 1024)
                total_size += size_mb
                print(f"  • {file} ({size_mb:.2f} MB)")
        
        print(f"\nTotal size: {total_size:.2f} MB")
        
    except Exception as e:
        print(f"\n❌ Error: {e}")

if __name__ == "__main__":
    download_bge_small()
