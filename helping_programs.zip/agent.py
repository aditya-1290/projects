import os
import requests
from dotenv import load_dotenv
from google.adk.agents.llm_agent import Agent

load_dotenv()

OPENWEATHER_KEY = os.getenv("OPENWEATHER_KEY")
EXCHANGERATE_KEY = os.getenv("EXCHANGERATE_KEY")
TIMEZONEDB_KEY = os.getenv("TIMEZONEDB_KEY")


# ---------------------------------------------------------------------------
# Tool: Get Current Time
# ---------------------------------------------------------------------------
def get_current_time(city: str) -> dict:
    """Returns the current local time and timezone for a specified city.

    Args:
        city: The name of the city.
    """
    try:
        url = "https://api.timezonedb.com/v2.1/get-time-zone"
        params = {
            "key": TIMEZONEDB_KEY,
            "format": "json",
            "by": "city",
            "city": city,
        }
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()

        if data.get("status") != "OK":
            return {"status": "error", "message": data.get("message", "Unknown error from TimeZoneDB.")}

        return {
            "status": "success",
            "city": city.title(),
            "time": data["formatted"].split(" ")[1],  # HH:MM:SS
            "date": data["formatted"].split(" ")[0],  # YYYY-MM-DD
            "timezone": data["zoneName"],
            "utc_offset": f"UTC{'+' if data['gmtOffset'] >= 0 else ''}{data['gmtOffset'] // 3600}",
        }
    except requests.exceptions.RequestException as e:
        return {"status": "error", "message": f"Request failed: {str(e)}"}


# ---------------------------------------------------------------------------
# Tool: Get Weather
# ---------------------------------------------------------------------------
def get_weather(city: str, unit: str = "celsius") -> dict:
    """Returns real-time weather conditions for a specified city.

    Args:
        city: The name of the city.
        unit: Temperature unit — 'celsius' or 'fahrenheit'. Defaults to 'celsius'.
    """
    try:
        units_param = "imperial" if unit.lower() == "fahrenheit" else "metric"
        unit_label = "°F" if units_param == "imperial" else "°C"

        url = "https://api.openweathermap.org/data/2.5/weather"
        params = {
            "q": city,
            "appid": OPENWEATHER_KEY,
            "units": units_param,
        }
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()

        return {
            "status": "success",
            "city": data["name"],
            "country": data["sys"]["country"],
            "temperature": f"{round(data['main']['temp'], 1)}{unit_label}",
            "feels_like": f"{round(data['main']['feels_like'], 1)}{unit_label}",
            "condition": data["weather"][0]["description"].title(),
            "humidity": f"{data['main']['humidity']}%",
            "wind_speed": f"{data['wind']['speed']} {'mph' if units_param == 'imperial' else 'm/s'}",
            "visibility": f"{data.get('visibility', 'N/A')} m",
        }
    except requests.exceptions.HTTPError as e:
        if e.response.status_code == 404:
            return {"status": "error", "message": f"City '{city}' not found."}
        return {"status": "error", "message": f"HTTP error: {str(e)}"}
    except requests.exceptions.RequestException as e:
        return {"status": "error", "message": f"Request failed: {str(e)}"}


# ---------------------------------------------------------------------------
# Tool: Currency Converter
# ---------------------------------------------------------------------------
def convert_currency(amount: float, from_currency: str, to_currency: str) -> dict:
    """Converts an amount from one currency to another using live exchange rates.

    Args:
        amount: The numeric amount to convert.
        from_currency: The source currency code (e.g., 'USD').
        to_currency: The target currency code (e.g., 'INR').
    """
    try:
        src = from_currency.upper()
        tgt = to_currency.upper()

        url = f"https://v6.exchangerate-api.com/v6/{EXCHANGERATE_KEY}/pair/{src}/{tgt}/{amount}"
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        data = response.json()

        if data.get("result") != "success":
            return {"status": "error", "message": data.get("error-type", "Unknown error from ExchangeRate-API.")}

        return {
            "status": "success",
            "from": src,
            "to": tgt,
            "original_amount": amount,
            "converted_amount": round(data["conversion_result"], 4),
            "exchange_rate": data["conversion_rate"],
            "last_updated": data.get("time_last_update_utc", "N/A"),
        }
    except requests.exceptions.RequestException as e:
        return {"status": "error", "message": f"Request failed: {str(e)}"}


# ---------------------------------------------------------------------------
# Tool: Date & Timezone Info
# ---------------------------------------------------------------------------
def get_date_info(city: str) -> dict:
    """Returns the current date, day of the week, week number, and timezone details for a city.

    Args:
        city: The name of the city.
    """
    try:
        url = "https://api.timezonedb.com/v2.1/get-time-zone"
        params = {
            "key": TIMEZONEDB_KEY,
            "format": "json",
            "by": "city",
            "city": city,
        }
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()

        if data.get("status") != "OK":
            return {"status": "error", "message": data.get("message", "Unknown error from TimeZoneDB.")}

        from datetime import datetime
        local_dt = datetime.strptime(data["formatted"], "%Y-%m-%d %H:%M:%S")

        return {
            "status": "success",
            "city": city.title(),
            "date": local_dt.strftime("%B %d, %Y"),
            "day_of_week": local_dt.strftime("%A"),
            "week_number": local_dt.isocalendar()[1],
            "timezone": data["zoneName"],
            "utc_offset": f"UTC{'+' if data['gmtOffset'] >= 0 else ''}{data['gmtOffset'] // 3600}",
            "is_weekend": local_dt.weekday() >= 5,
        }
    except requests.exceptions.RequestException as e:
        return {"status": "error", "message": f"Request failed: {str(e)}"}


# ---------------------------------------------------------------------------
# Tool: World Clock (multiple cities)
# ---------------------------------------------------------------------------
def get_world_clock(cities: list[str]) -> dict:
    """Returns the current time for multiple cities at once.

    Args:
        cities: A list of city names (e.g., ['Tokyo', 'London', 'New York']).
    """
    results = []
    errors = []

    for city in cities:
        result = get_current_time(city)
        if result["status"] == "success":
            results.append({
                "city": result["city"],
                "time": result["time"],
                "date": result["date"],
                "timezone": result["timezone"],
                "utc_offset": result["utc_offset"],
            })
        else:
            errors.append({"city": city, "error": result["message"]})

    return {
        "status": "success",
        "clock_count": len(results),
        "world_clock": results,
        "errors": errors if errors else None,
    }


# ---------------------------------------------------------------------------
# Agent Definition
# ---------------------------------------------------------------------------
root_agent = Agent(
    model='gemini-3-flash-preview',
    name='root_agent',
    description=(
        "A world-aware assistant that provides real-time information about time, "
        "weather, currency exchange, and date/timezone details for cities around the globe."
    ),
    instruction="""You are a knowledgeable and friendly global assistant. You help users with:

1. **Current Time** — Use `get_current_time` when a user asks what time it is in a specific city.

2. **Weather** — Use `get_weather` when a user asks about weather, temperature, or conditions in a city.
   - Default to Celsius unless the user specifies Fahrenheit.
   - Always report temperature, feels-like, condition, humidity, and wind.

3. **Currency Conversion** — Use `convert_currency` when a user wants to convert money between currencies.
   - Always confirm the currencies and amount before presenting the result.
   - Rates are live and fetched in real time.

4. **Date & Timezone Info** — Use `get_date_info` when a user asks what the date is, what day of the week it is, or wants timezone details for a city.

5. **World Clock** — Use `get_world_clock` when a user wants to compare times across multiple cities at once. Pass all city names as a list in a single call.

General guidelines:
- Always be concise and friendly.
- When displaying results, format them clearly (e.g., bold labels, organized lines).
- If a user asks a combined question (e.g., "What's the time and weather in Tokyo?"), call the relevant tools and present the results together.
- If a tool returns an error, inform the user politely and suggest they check the city name or try again.
- Never guess or make up data — always use the provided tools.
""",
    tools=[
        get_current_time,
        get_weather,
        convert_currency,
        get_date_info,
        get_world_clock,
    ],
)