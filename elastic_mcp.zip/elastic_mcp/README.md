# Standalone Elasticsearch MCP Server

This project provides:

1. Pure MCP server for Gemini CLI
2. Optional FastAPI wrapper for Postman/browser testing
3. Elastic Cloud connection using Cloud ID and API key

## Setup

```bash
python -m venv .venv