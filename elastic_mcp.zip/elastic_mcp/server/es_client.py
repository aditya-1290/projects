from functools import lru_cache
from elasticsearch import Elasticsearch
from server.config import get_settings


@lru_cache
def get_es_client() -> Elasticsearch:
    settings = get_settings()

    if not settings.elastic_api_key:
        raise ValueError("ELASTIC_API_KEY is missing in .env")

    if settings.elastic_url:
        client = Elasticsearch(
            hosts=[settings.elastic_url],
            api_key=settings.elastic_api_key,
            request_timeout=30,
            retry_on_timeout=True,
            max_retries=3,
        )
    elif settings.elastic_cloud_id:
        client = Elasticsearch(
            cloud_id=settings.elastic_cloud_id,
            api_key=settings.elastic_api_key,
            request_timeout=30,
            retry_on_timeout=True,
            max_retries=3,
        )
    else:
        raise ValueError("Either ELASTIC_URL or ELASTIC_CLOUD_ID must be set in .env")

    return client


def close_es_client() -> None:
    client = get_es_client()
    client.close()