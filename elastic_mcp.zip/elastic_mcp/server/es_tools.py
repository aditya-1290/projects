from typing import Any, Dict, List, Optional
from datetime import datetime, timedelta, timezone

from elasticsearch import Elasticsearch
from elasticsearch import ApiError, TransportError, NotFoundError

from server.config import get_settings
from server.es_client import get_es_client


def _safe_response(success: bool, data: Any = None, error: Optional[str] = None) -> Dict[str, Any]:
    return {
        "success": success,
        "data": data,
        "error": error,
    }

def _to_plain_response(response: Any) -> Any:
    """
    Converts Elasticsearch response objects into normal Python dict/list
    so FastAPI can return them as JSON.
    """
    if hasattr(response, "body"):
        return response.body

    return response

def ping_elasticsearch() -> Dict[str, Any]:
    """
    Check Elasticsearch Cloud connection.
    """
    try:
        client: Elasticsearch = get_es_client()
        is_alive = client.ping()

        info = client.info() if is_alive else {}

        return _safe_response(
            success=is_alive,
            data={
                "connected": is_alive,
                "cluster_name": info.get("cluster_name"),
                "version": info.get("version", {}).get("number"),
                "tagline": info.get("tagline"),
            },
        )
    except NotFoundError as e:
        return _safe_response(False, error=f"Not found: {str(e)}")
    except ApiError as e:
        return _safe_response(False, error=f"Elasticsearch API error: {str(e)}")
    except TransportError as e:
        return _safe_response(False, error=f"Elasticsearch transport error: {str(e)}")
    except Exception as e:
        return _safe_response(False, error=str(e))


def list_indices(pattern: str = "*") -> Dict[str, Any]:
    """
    List Elasticsearch indices matching a pattern.
    Example pattern: logs-*
    """
    try:
        client = get_es_client()

        response = client.cat.indices(
            index=pattern,
            format="json",
            h=["index", "health", "status", "docs.count", "store.size"]
        )

        indices = _to_plain_response(response)

        return _safe_response(True, data=indices)

    except NotFoundError as e:
        return _safe_response(False, error=f"Not found: {str(e)}")
    except ApiError as e:
        return _safe_response(False, error=f"Elasticsearch API error: {str(e)}")
    except TransportError as e:
        return _safe_response(False, error=f"Elasticsearch transport error: {str(e)}")
    except Exception as e:
        return _safe_response(False, error=str(e))


def get_index_mapping(index: Optional[str] = None) -> Dict[str, Any]:
    """
    Get mapping for an index.
    """
    try:
        settings = get_settings()
        client = get_es_client()

        target_index = index or settings.default_index
        response = client.indices.get_mapping(index=target_index)

        mapping = _to_plain_response(response)

        return _safe_response(True, data=mapping)

    except NotFoundError as e:
        return _safe_response(False, error=f"Not found: {str(e)}")
    except ApiError as e:
        return _safe_response(False, error=f"Elasticsearch API error: {str(e)}")
    except TransportError as e:
        return _safe_response(False, error=f"Elasticsearch transport error: {str(e)}")
    except Exception as e:
        return _safe_response(False, error=str(e))

def search_logs(
    query: str,
    index: Optional[str] = None,
    size: int = 10,
    timestamp_field: str = "@timestamp",
    start_time: Optional[str] = None,
    end_time: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Search logs by keyword with optional time range.

    start_time and end_time should be ISO format:
    2026-05-22T10:00:00Z
    """
    try:
        settings = get_settings()
        client = get_es_client()

        target_index = index or settings.default_index

        must_clauses: List[Dict[str, Any]] = []

        if query:
            must_clauses.append({
                "query_string": {
                    "query": query,
                    "default_operator": "AND"
                }
            })
        else:
            must_clauses.append({"match_all": {}})

        filter_clauses: List[Dict[str, Any]] = []

        if start_time or end_time:
            range_filter: Dict[str, Any] = {}

            if start_time:
                range_filter["gte"] = start_time

            if end_time:
                range_filter["lte"] = end_time

            filter_clauses.append({
                "range": {
                    timestamp_field: range_filter
                }
            })

        body = {
            "query": {
                "bool": {
                    "must": must_clauses,
                    "filter": filter_clauses
                }
            },
            "size": size,
            "sort": [
                {
                    timestamp_field: {
                        "order": "desc",
                        "unmapped_type": "date"
                    }
                }
            ]
        }

        response = client.search(index=target_index, body=body)

        hits = [
            {
                "_index": hit.get("_index"),
                "_id": hit.get("_id"),
                "_score": hit.get("_score"),
                "_source": hit.get("_source"),
            }
            for hit in response.get("hits", {}).get("hits", [])
        ]

        return _safe_response(
            True,
            data={
                "index": target_index,
                "query": query,
                "total": response.get("hits", {}).get("total"),
                "hits": hits,
            }
        )

    except NotFoundError as e:
        return _safe_response(False, error=f"Not found: {str(e)}")
    except ApiError as e:
        return _safe_response(False, error=f"Elasticsearch API error: {str(e)}")
    except TransportError as e:
        return _safe_response(False, error=f"Elasticsearch transport error: {str(e)}")
    except Exception as e:
        return _safe_response(False, error=str(e))


def search_logs_dsl(
    query_dsl: Dict[str, Any],
    index: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Search logs using raw Elasticsearch Query DSL.
    """
    try:
        settings = get_settings()
        client = get_es_client()

        target_index = index or settings.default_index

        response = client.search(
            index=target_index,
            body=query_dsl,
        )

        return _safe_response(True, data=_to_plain_response(response))

    except NotFoundError as e:
        return _safe_response(False, error=f"Not found: {str(e)}")
    except ApiError as e:
        return _safe_response(False, error=f"Elasticsearch API error: {str(e)}")
    except TransportError as e:
        return _safe_response(False, error=f"Elasticsearch transport error: {str(e)}")
    except Exception as e:
        return _safe_response(False, error=str(e))


def recent_errors(
    index: Optional[str] = None,
    size: int = 10,
    hours: int = 24,
    timestamp_field: str = "@timestamp",
) -> Dict[str, Any]:
    """
    Get recent ERROR logs from the last N hours.
    """
    now = datetime.now(timezone.utc)
    start = now - timedelta(hours=hours)

    return search_logs(
        query='level:ERROR OR log.level:ERROR OR severity:ERROR OR message:"ERROR"',
        index=index,
        size=size,
        timestamp_field=timestamp_field,
        start_time=start.isoformat(),
        end_time=now.isoformat(),
    )


def get_document_by_id(index: str, document_id: str) -> Dict[str, Any]:
    """
    Fetch a single document by index and document ID.
    """
    try:
        client = get_es_client()

        response = client.get(index=index, id=document_id)

        return _safe_response(
            True,
            data={
                "_index": response.get("_index"),
                "_id": response.get("_id"),
                "_source": response.get("_source"),
            }
        )

    except NotFoundError as e:
        return _safe_response(False, error=f"Not found: {str(e)}")
    except ApiError as e:
        return _safe_response(False, error=f"Elasticsearch API error: {str(e)}")
    except TransportError as e:
        return _safe_response(False, error=f"Elasticsearch transport error: {str(e)}")
    except Exception as e:
        return _safe_response(False, error=str(e))