from functools import lru_cache

from dotenv import load_dotenv
from pydantic import Field
from pydantic_settings import BaseSettings

load_dotenv()


class Settings(BaseSettings):
    es_mode: str = Field(default="cloud", alias="ES_MODE")

    elastic_url: str = Field(default="", alias="ELASTIC_URL")
    elastic_cloud_id: str = Field(default="", alias="ELASTIC_CLOUD_ID")
    elastic_api_key: str = Field(default="", alias="ELASTIC_API_KEY")

    default_index: str = Field(default="logs-*", alias="DEFAULT_INDEX")

    mcp_server_name: str = Field(
        default="elasticsearch-mcp-server",
        alias="MCP_SERVER_NAME",
    )
    mcp_host: str = Field(default="127.0.0.1", alias="MCP_HOST")
    mcp_port: int = Field(default=9000, alias="MCP_PORT")
    mcp_transport: str = Field(default="streamable-http", alias="MCP_TRANSPORT")
    mcp_path: str = Field(default="/mcp", alias="MCP_PATH")
    mcp_base_url: str = Field(
        default="http://127.0.0.1:9000/mcp",
        alias="MCP_BASE_URL",
    )

    fastapi_host: str = Field(default="127.0.0.1", alias="FASTAPI_HOST")
    fastapi_port: int = Field(default=8003, alias="FASTAPI_PORT")

    class Config:
        populate_by_name = True
        extra = "ignore"


@lru_cache
def get_settings() -> Settings:
    return Settings()