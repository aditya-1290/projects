import logging
import sys
from typing import Any, Dict, Optional

from mcp.server.fastmcp import FastMCP

from server.config import get_settings,Settings
from server.es_tools import (
    ping_elasticsearch as ping_es,
    list_indices as list_es_indices,
    get_index_mapping as fetch_index_mapping,
    search_logs as search_es_logs,
    search_logs_dsl as search_es_logs_dsl,
    recent_errors as fetch_recent_errors,
    get_document_by_id as fetch_document_by_id,
)

logging.basicConfig(
    stream=sys.stderr,
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s - %(message)s"
)

settings = get_settings()
mcp = FastMCP(
    name=settings.mcp_server_name,
    host=settings.mcp_host,
    port=settings.mcp_port,
)


@mcp.tool()
def ping_elasticsearch() -> Dict[str, Any]:
    """
    Check if the Elastic Cloud cluster is reachable.
    """
    return ping_es()


@mcp.tool()
def list_indices(pattern: str = "*") -> Dict[str, Any]:
    """
    List Elasticsearch indices matching a pattern.

    Example:
    pattern = "logs-*"
    """
    return list_es_indices(pattern=pattern)


@mcp.tool()
def get_index_mapping(index: Optional[str] = None) -> Dict[str, Any]:
    """
    Get mapping/schema for an Elasticsearch index.
    If index is not provided, DEFAULT_INDEX from .env is used.
    """
    return fetch_index_mapping(index=index)


@mcp.tool()
def search_logs(
    query: str,
    index: Optional[str] = None,
    size: int = 10,
    timestamp_field: str = "@timestamp",
    start_time: Optional[str] = None,
    end_time: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Search logs using a keyword query and optional time range.

    Example query:
    "Exception"
    "level:ERROR"
    "timeout AND service:payment"

    start_time/end_time format:
    2026-05-22T10:00:00Z
    """
    return search_es_logs(
        query=query,
        index=index,
        size=size,
        timestamp_field=timestamp_field,
        start_time=start_time,
        end_time=end_time,
    )


@mcp.tool()
def search_logs_dsl(
    query_dsl: Dict[str, Any],
    index: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Search logs using raw Elasticsearch Query DSL.
    """
    return search_es_logs_dsl(
        query_dsl=query_dsl,
        index=index,
    )


@mcp.tool()
def recent_errors(
    index: Optional[str] = None,
    size: int = 10,
    hours: int = 24,
    timestamp_field: str = "@timestamp",
) -> Dict[str, Any]:
    """
    Fetch recent error logs from the last N hours.
    """
    return fetch_recent_errors(
        index=index,
        size=size,
        hours=hours,
        timestamp_field=timestamp_field,
    )


@mcp.tool()
def get_document_by_id(index: str, document_id: str) -> Dict[str, Any]:
    """
    Get one Elasticsearch document by index and document ID.
    """
    return fetch_document_by_id(
        index=index,
        document_id=document_id,
    )


if __name__ == "__main__":
    mcp.run(transport=settings.mcp_transport)