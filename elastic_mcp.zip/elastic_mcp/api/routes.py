from typing import Any, Dict, Optional

from fastapi import APIRouter, Query, Body

from api.mcp_bridge_client import call_mcp_tool

router = APIRouter(prefix="/elastic", tags=["Elasticsearch via MCP"])


@router.get("/health")
async def health() -> Dict[str, Any]:
    return await call_mcp_tool("ping_elasticsearch")


@router.get("/indices")
async def indices(pattern: str = Query(default="*")) -> Dict[str, Any]:
    return await call_mcp_tool(
        "list_indices",
        {
            "pattern": pattern,
        },
    )


@router.get("/mapping")
async def mapping(index: Optional[str] = Query(default=None)) -> Dict[str, Any]:
    args = {}

    if index:
        args["index"] = index

    return await call_mcp_tool("get_index_mapping", args)


@router.get("/search")
async def search(
    query: str = Query(default=""),
    index: Optional[str] = Query(default=None),
    size: int = Query(default=10, ge=1, le=100),
    timestamp_field: str = Query(default="@timestamp"),
    start_time: Optional[str] = Query(default=None),
    end_time: Optional[str] = Query(default=None),
) -> Dict[str, Any]:
    args = {
        "query": query,
        "size": size,
        "timestamp_field": timestamp_field,
    }

    if index:
        args["index"] = index

    if start_time:
        args["start_time"] = start_time

    if end_time:
        args["end_time"] = end_time

    return await call_mcp_tool("search_logs", args)


@router.post("/search-dsl")
async def search_dsl(
    query_dsl: Dict[str, Any] = Body(...),
    index: Optional[str] = Query(default=None),
) -> Dict[str, Any]:
    args = {
        "query_dsl": query_dsl,
    }

    if index:
        args["index"] = index

    return await call_mcp_tool("search_logs_dsl", args)


@router.get("/recent-errors")
async def errors(
    index: Optional[str] = Query(default=None),
    size: int = Query(default=10, ge=1, le=100),
    hours: int = Query(default=24, ge=1, le=168),
    timestamp_field: str = Query(default="@timestamp"),
) -> Dict[str, Any]:
    args = {
        "size": size,
        "hours": hours,
        "timestamp_field": timestamp_field,
    }

    if index:
        args["index"] = index

    return await call_mcp_tool("recent_errors", args)


@router.get("/document/{index}/{document_id}")
async def document(index: str, document_id: str) -> Dict[str, Any]:
    return await call_mcp_tool(
        "get_document_by_id",
        {
            "index": index,
            "document_id": document_id,
        },
    )