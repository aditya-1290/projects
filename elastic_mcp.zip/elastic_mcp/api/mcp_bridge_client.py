import json
from typing import Any, Dict, Optional

from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client

from server.config import get_settings


def _extract_mcp_result(result: Any) -> Dict[str, Any]:
    """
    Converts MCP tool response into a normal FastAPI JSON response.
    Handles structuredContent if available, otherwise parses text content.
    """

    if hasattr(result, "structuredContent") and result.structuredContent is not None:
        return {
            "success": not getattr(result, "isError", False),
            "data": result.structuredContent,
            "error": None,
        }

    content_items = getattr(result, "content", [])

    parsed_items = []

    for item in content_items:
        text = getattr(item, "text", None)

        if text is None:
            parsed_items.append(str(item))
            continue

        try:
            parsed_items.append(json.loads(text))
        except json.JSONDecodeError:
            parsed_items.append(text)

    if len(parsed_items) == 1:
        data = parsed_items[0]
    else:
        data = parsed_items

    return {
        "success": not getattr(result, "isError", False),
        "data": data,
        "error": None if not getattr(result, "isError", False) else "MCP tool returned error",
    }


async def call_mcp_tool(
    tool_name: str,
    arguments: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Calls a tool on the MCP HTTP server.
    """

    settings = get_settings()
    arguments = arguments or {}

    try:
        async with streamablehttp_client(settings.mcp_base_url) as (
            read_stream,
            write_stream,
            _get_session_id,
        ):
            async with ClientSession(read_stream, write_stream) as session:
                await session.initialize()

                result = await session.call_tool(
                    name=tool_name,
                    arguments=arguments,
                )

                return _extract_mcp_result(result)

    except Exception as e:
        return {
            "success": False,
            "data": None,
            "error": f"FastAPI could not call MCP server: {str(e)}",
        }