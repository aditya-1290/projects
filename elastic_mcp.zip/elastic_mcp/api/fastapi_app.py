from fastapi import FastAPI
import uvicorn

from api.routes import router as elastic_router
from server.config import get_settings

app = FastAPI(
    title="Standalone Elasticsearch MCP Server - FastAPI Wrapper",
    description="Optional HTTP layer for testing Elasticsearch MCP tools with Postman.",
    version="1.0.0",
)

app.include_router(elastic_router)


@app.get("/")
def root():
    return {
        "message": "Elasticsearch MCP standalone FastAPI wrapper is running.",
        "docs": "/docs",
        "health": "/elastic/health",
    }


if __name__ == "__main__":
    settings = get_settings()

    uvicorn.run(
        "api.fastapi_app:app",
        host=settings.fastapi_host,
        port=settings.fastapi_port,
        reload=True,
    )