from server.es_tools import ping_elasticsearch, list_indices


def main():
    print("Testing Elastic Cloud connection...\n")

    health = ping_elasticsearch()
    print("Health:")
    print(health)

    print("\nIndices:")
    indices = list_indices("*")
    print(indices)


if __name__ == "__main__":
    main()