from datetime import datetime, timezone
from uuid import uuid4

from server.es_client import get_es_client


INDEX_NAME = "logs-sample"


def main():
    client = get_es_client()

    sample_logs = [
        {
            "@timestamp": datetime.now(timezone.utc).isoformat(),
            "level": "INFO",
            "service": "auth-service",
            "message": "User login successful",
            "trace_id": str(uuid4()),
        },
        {
            "@timestamp": datetime.now(timezone.utc).isoformat(),
            "level": "ERROR",
            "service": "payment-service",
            "message": "Payment gateway timeout error",
            "trace_id": str(uuid4()),
        },
        {
            "@timestamp": datetime.now(timezone.utc).isoformat(),
            "level": "WARNING",
            "service": "inventory-service",
            "message": "Low stock threshold reached",
            "trace_id": str(uuid4()),
        },
    ]

    for log in sample_logs:
        response = client.index(index=INDEX_NAME, document=log)
        print(f"Inserted: {response['_id']}")

    client.indices.refresh(index=INDEX_NAME)
    print(f"\nSample logs inserted into index: {INDEX_NAME}")


if __name__ == "__main__":
    main()