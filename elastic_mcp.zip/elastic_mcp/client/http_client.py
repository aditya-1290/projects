import httpx

from server.config import get_settings

settings = get_settings()
BASE_URL = f"http://{settings.fastapi_host}:{settings.fastapi_port}"


def main():
    with httpx.Client(timeout=30) as client:
        health = client.get(f"{BASE_URL}/elastic/health")
        print("Health:")
        print(health.json())

        indices = client.get(f"{BASE_URL}/elastic/indices", params={"pattern": "*"})
        print("\nIndices:")
        print(indices.json())

        search = client.get(
            f"{BASE_URL}/elastic/search",
            params={
                "query": "ERROR",
                "size": 5,
            },
        )
        print("\nSearch:")
        print(search.json())


if __name__ == "__main__":
    main()