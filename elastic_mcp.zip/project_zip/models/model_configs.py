"""
Model Configuration Registry

Defines all models used in the system with their configurations.
"""

from dataclasses import dataclass, field
from typing import Dict, Any, Optional
from pathlib import Path


@dataclass
class ModelConfig:
    """Configuration for a single model"""
    name: str  # Display name
    path: str  # File path to model
    model_type: str  # "llm", "ocr", "embedding"
    size_gb: float  # Approximate memory footprint
    context_size: int  # Max context window in tokens
    quantization: str = "none"  # Quantization format
    n_threads: int = 8  # CPU threads for inference
    n_batch: int = 512  # Batch size
    temperature: float = 0.1  # Generation temperature
    top_p: float = 0.9  # Nucleus sampling
    top_k: int = 40  # Top-k sampling
    repeat_penalty: float = 1.1  # Repeat penalty
    max_tokens: int = 2048  # Max tokens to generate
    priority: int = 1  # 1=always_loaded, 2=on_demand
    load_on_startup: bool = False
    description: str = ""
    extra_params: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict:
        return {
            "name": self.name,
            "path": self.path,
            "model_type": self.model_type,
            "size_gb": self.size_gb,
            "context_size": self.context_size,
            "quantization": self.quantization,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            "priority": self.priority,
            "load_on_startup": self.load_on_startup,
            "description": self.description
        }


# ============================================
# Model Registry
# ============================================

MODELS: Dict[str, ModelConfig] = {
    "gemma": ModelConfig(
        name="gemma-4-e4b-it",
        path="D:/Models/gemma-4-E4B-it-Q5_K_M.gguf",
        model_type="llm",
        size_gb=3.0,
        context_size=8192,
        quantization="Q5_K_M",
        n_threads=8,
        n_batch=512,
        temperature=0.1,
        top_p=0.9,
        top_k=40,
        repeat_penalty=1.1,
        max_tokens=2048,
        priority=1,
        load_on_startup=True,
        description="Primary reasoning model for analysis, solving, debugging"
    ),

    "qwen_small": ModelConfig(
        name="qwen2.5-3b-it",
        path="D:/Models/qwen2.5-3b-instruct-Q4_K_M.gguf",
        model_type="llm",
        size_gb=2.0,
        context_size=4096,
        quantization="Q4_K_M",
        n_threads=8,
        n_batch=512,
        temperature=0.0,
        top_p=0.9,
        top_k=40,
        repeat_penalty=1.1,
        max_tokens=4096,
        priority=1,
        load_on_startup=True,
        description="Lightweight model for preprocessing, cleaning, parsing"
    ),

    "deepseek_ocr": ModelConfig(
        name="deepseek-ocr2",
        path="D:/Models/DeepSeek-OCR-2",
        model_type="ocr",
        size_gb=10.0,
        context_size=4096,
        quantization="none",
        temperature=0.0,
        max_tokens=1024,
        priority=2,
        load_on_startup=True,
        description="OCR model for image-to-text extraction"
    ),

    "embedding": ModelConfig(
        name="bge-small-en",
        path="D:/Models/bge-small-en-v1.5",
        model_type="embedding",
        size_gb=0.5,
        context_size=512,
        quantization="none",
        priority=1,
        load_on_startup=True,
        description="Embedding model for memory retrieval (BGE-Small-EN)"
    )
}

# ============================================
# Agent-to-Model Mapping
# ============================================

AGENT_MODEL_MAP = {
    "extractor": None,  # Uses custom parsers (no LLM)
    "extractor_ocr": "deepseek_ocr",
    "preprocessor": "qwen_small",
    "analyzer": "gemma",
    "solver": "gemma",
    "debugger": "gemma",
    "critic": "gemma",
    "memory": "qwen_small",  # For retrieval queries
    "memory_embedding": "embedding",  # For generating embeddings
    "orchestrator": "gemma"
}


# ============================================
# Helper Functions
# ============================================

def get_model_config(model_name: str) -> Optional[ModelConfig]:
    """Get model configuration by name"""
    return MODELS.get(model_name)


def get_agent_model(agent_name: str) -> Optional[ModelConfig]:
    """Get the model assigned to an agent"""
    model_name = AGENT_MODEL_MAP.get(agent_name)
    if model_name:
        return MODELS.get(model_name)
    return None


def list_models() -> Dict[str, str]:
    """List all registered models with descriptions"""
    return {name: config.description for name, config in MODELS.items()}


def list_always_loaded_models() -> list:
    """List models that should be loaded at startup"""
    return [name for name, config in MODELS.items() if config.load_on_startup]


def list_on_demand_models() -> list:
    """List models loaded only when needed"""
    return [name for name, config in MODELS.items() if not config.load_on_startup]


def total_memory_footprint() -> float:
    """Calculate total memory if all always-loaded models are loaded"""
    return sum(
        config.size_gb
        for config in MODELS.values()
        if config.load_on_startup
    )


def peak_memory_footprint() -> float:
    """Calculate peak memory with all always-loaded + largest on-demand"""
    always_loaded = total_memory_footprint()
    on_demand_max = max(
        (config.size_gb for config in MODELS.values() if not config.load_on_startup),
        default=0
    )
    return always_loaded + on_demand_max


# ============================================
# Print Model Summary (for CLI)
# ============================================

def print_model_summary():
    """Print a summary of all configured models"""
    print("\n" + "=" * 60)
    print("MODEL CONFIGURATION SUMMARY")
    print("=" * 60)

    for name, config in MODELS.items():
        load_status = "ALWAYS" if config.load_on_startup else "ON-DEMAND"
        print(f"\n📦 {config.name}")
        print(f"   Type: {config.model_type}")
        print(f"   Size: {config.size_gb}GB")
        print(f"   Context: {config.context_size} tokens")
        print(f"   Quantization: {config.quantization}")
        print(f"   Loading: {load_status}")
        print(f"   Priority: {config.priority}")
        print(f"   {config.description}")

    print("\n" + "-" * 60)
    print(f"📊 Always Loaded Memory: {total_memory_footprint():.1f}GB")
    print(f"📊 Peak Memory (with largest on-demand): {peak_memory_footprint():.1f}GB")
    print("=" * 60 + "\n")


if __name__ == "__main__":
    print_model_summary()