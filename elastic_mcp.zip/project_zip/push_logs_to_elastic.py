# push_logs_to_elastic.py
# Place in: D:\ADK\Final\project_zip\push_logs_to_elastic.py
# Run:      python push_logs_to_elastic.py

import os, json, argparse, httpx
from pathlib import Path
from datetime import datetime, timezone
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

ES_URL = (
    os.getenv("ELASTICSEARCH_URL") or
    os.getenv("ELASTIC_URL") or ""
).strip().rstrip("/")

ES_API_KEY  = os.getenv("ES_API_KEY", "").strip()
FASTAPI_URL = os.getenv("LOG_AGENT_API_BASE", "http://127.0.0.1:8002")

APP_JSON_PATH = BASE_DIR / "memory_store" / "logs" / "app.json"
AUDIT_DIR     = BASE_DIR / "memory_store" / "audit"


def make_client() -> httpx.Client:
    return httpx.Client(
        base_url=ES_URL,
        headers={
            "Authorization": f"ApiKey {ES_API_KEY}",
            "Content-Type":  "application/json",
        },
        verify=True,
        timeout=30.0,
    )


def verify_connection(client: httpx.Client) -> bool:
    # Serverless does not support /_cluster/health (returns 410)
    # Use /_cat/indices instead — works on both Serverless and Hosted
    for path in ["/_cat/indices?format=json", "/_cat/indices"]:
        try:
            resp = client.get(path)
            if resp.status_code in (200, 404):
                # 404 just means no indices yet — connection itself is fine
                print(f"  Connected! (HTTP {resp.status_code} on {path})")
                return True
            if resp.status_code == 401:
                print(f"  HTTP 401 Unauthorized — API key is wrong or expired")
                return False
        except Exception as e:
            print(f"  Error on {path}: {e}")

    # Last resort — try a dummy search, a 404/400 still means we reached the server
    try:
        resp = client.post(
            "/_search",
            content=json.dumps({"query": {"match_all": {}}, "size": 0}),
        )
        if resp.status_code in (200, 400, 404):
            print(f"  Connected! (HTTP {resp.status_code} on /_search)")
            return True
    except Exception as e:
        print(f"  Search probe failed: {e}")

    return False


def bulk_push(client: httpx.Client, index: str, docs: list) -> int:
    if not docs:
        return 0
    lines = []
    for doc in docs:
        if "@timestamp" not in doc:
            doc["@timestamp"] = doc.get("timestamp") or datetime.now(timezone.utc).isoformat()
        lines.append(json.dumps({"index": {"_index": index}}))
        lines.append(json.dumps(doc, default=str))
    body = "\n".join(lines) + "\n"
    resp = client.post(
        "/_bulk",
        content=body,
        headers={"Content-Type": "application/x-ndjson"},
    )
    if resp.status_code not in (200, 201):
        print(f"  [ERROR] Bulk HTTP {resp.status_code}: {resp.text[:300]}")
        return 0
    items  = resp.json().get("items", [])
    ok     = sum(1 for i in items if not i.get("index", {}).get("error"))
    errors = [i["index"]["error"] for i in items if i.get("index", {}).get("error")]
    if errors:
        print(f"  [WARN] {len(errors)} docs failed. Sample: {errors[0]}")
    return ok


def push_app_json(client):
    if not APP_JSON_PATH.exists():
        print(f"  [SKIP] {APP_JSON_PATH} not found")
        return 0
    with open(APP_JSON_PATH, "r", encoding="utf-8-sig") as f:
        data = json.load(f)
    logs = data.get("logs", []) if isinstance(data, dict) else (data if isinstance(data, list) else [])
    if not logs:
        print("  [SKIP] app.json is empty")
        return 0
    n = bulk_push(client, "logs-app", [dict(l) for l in logs])
    print(f"  [OK] app.json  -->  logs-app : {n} docs")
    return n


def push_audit_logs(client):
    files = sorted(AUDIT_DIR.glob("pipeline_*.json"))
    if not files:
        print(f"  [SKIP] No pipeline_*.json files in {AUDIT_DIR}")
        print(f"         Run a query through adk_server.py first to generate them")
        return 0
    total = 0
    for f in files:
        docs = []
        with open(f, "r", encoding="utf-8-sig") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    docs.append(json.loads(line))
                except json.JSONDecodeError:
                    pass
        if not docs:
            continue
        n = bulk_push(client, "logs-pipeline", docs)
        print(f"  [OK] {f.name}  -->  logs-pipeline : {n} docs")
        total += n
    return total


def push_chromadb(client):
    docs, seen = [], set()
    for q in ["error traceback", "pipeline result", "root cause"]:
        try:
            r = httpx.post(
                f"{FASTAPI_URL}/memory/search",
                json={"query": q, "limit": 20, "collection": "log_analyses"},
                timeout=20,
            )
            if r.status_code != 200:
                continue
            items = r.json().get("response") or r.json().get("results") or []
            if isinstance(items, str):
                try: items = json.loads(items)
                except: continue
            for item in (items if isinstance(items, list) else []):
                d = item if isinstance(item, dict) else {"content": str(item)}
                k = d.get("id", str(item))
                if k not in seen:
                    seen.add(k)
                    docs.append(d)
        except httpx.ConnectError:
            print(f"  [SKIP] FastAPI not running at {FASTAPI_URL}")
            return 0
        except Exception as e:
            print(f"  [WARN] {e}")
    if not docs:
        print("  [SKIP] ChromaDB empty or FastAPI not running")
        return 0
    n = bulk_push(client, "logs-chromadb", docs)
    print(f"  [OK] ChromaDB  -->  logs-chromadb : {n} docs")
    return n


def main(source):
    print()
    print("=" * 54)
    print("  push_logs_to_elastic.py")
    print("=" * 54)
    print(f"  .env    : {BASE_DIR / '.env'}")
    print(f"  URL     : {ES_URL or 'NOT SET'}")
    print(f"  API Key : {'[set]' if ES_API_KEY else 'NOT SET'}")
    print()

    if not ES_URL or not ES_API_KEY:
        print("ERROR: Missing credentials in .env")
        print("  Need: ELASTIC_URL and ES_API_KEY")
        return

    client = make_client()
    print("Connecting to Elastic Cloud...")

    if not verify_connection(client):
        print()
        print("Could not connect. Try:")
        print("  1. Project paused? -> cloud.elastic.co -> Resume")
        print("  2. API key wrong?  -> Kibana -> Stack Management -> API Keys -> new key")
        client.close()
        return

    print()
    total = 0

    if source in ("all", "json"):
        print("-- app.json --")
        total += push_app_json(client)

    if source in ("all", "audit"):
        print("\n-- pipeline audit logs --")
        total += push_audit_logs(client)

    if source in ("all", "chromadb"):
        print("\n-- ChromaDB (needs FastAPI running) --")
        total += push_chromadb(client)

    client.close()
    print()
    print("=" * 54)
    print(f"  DONE: {total} documents pushed to Elastic Cloud")
    print("=" * 54)

    if total > 0:
        print()
        print("Now create the Kibana data view:")
        print("  1. cloud.elastic.co -> your project -> Open Kibana")
        print("  2. Left menu -> Discover")
        print("  3. Click 'Create data view'")
        print("  4. Index pattern : logs-*")
        print("  5. Timestamp     : @timestamp")
        print("  6. Save data view to Kibana")
        print("  -> Logs visible!")
    else:
        print()
        print("0 docs pushed. Most likely: no audit log files exist yet.")
        print("Fix:")
        print("  Terminal 1: python adk_server.py --port 8002")
        print("  Terminal 2: python test_mcp_client.py")
        print("  Then run:   python push_logs_to_elastic.py")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", choices=["all","json","audit","chromadb"], default="all")
    main(parser.parse_args().source)