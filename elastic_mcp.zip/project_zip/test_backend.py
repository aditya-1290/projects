# test_backend_run.py

import requests
from pathlib import Path

API_BASE = "http://127.0.0.1:8002"

file_path = r"D:\ADK\Log_Analysis_System\memory_store\logs\log_multi_agent_log.txt"

p = Path(file_path)

print("Checking file path...")
print("Exists:", p.exists())
print("Is file:", p.is_file())
print("Path:", p)

if not p.exists():
    print("File does not exist. Fix the path first.")
    raise SystemExit

print("\nCalling backend /run...")

response = requests.post(
    f"{API_BASE}/run",
    json={
        "query": file_path,
        "session_id": "pycharm-test-session",
    },
    timeout=1200,
)

print("Status code:", response.status_code)
print("Response text:")
print(response.text)

try:
    data = response.json()
    print("\nParsed response:")
    print(data.get("response"))
except Exception as e:
    print("Could not parse JSON:", e)