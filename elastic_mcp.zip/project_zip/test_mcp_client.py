import asyncio
import logging
import sys
from pathlib import Path

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


# =========================================================
# LOGGER CONFIG
# =========================================================

LOG_DIR = Path("logs")
LOG_DIR.mkdir(exist_ok=True)

logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    handlers=[
        logging.FileHandler(LOG_DIR / "mcp_client.log", encoding="utf-8"),
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger("mcp_client")


# =========================================================
# MAIN
# =========================================================

async def main():

    logger.info("========================================")
    logger.info("STARTING MCP CLIENT")
    logger.info("========================================")

    try:

        # -------------------------------------------------
        # Project paths
        # -------------------------------------------------

        project_root = Path(__file__).resolve().parent
        logger.info(f"Project root: {project_root}")

        # CHANGE THIS IF FILE IS INSIDE mcp_tools/
        server_file = project_root / "mcp_proxy.py"

        logger.info(f"MCP server file: {server_file}")

        # -------------------------------------------------
        # Validation
        # -------------------------------------------------

        if not project_root.exists():
            logger.error("Project root does not exist")
            return

        if not server_file.exists():
            logger.error(f"MCP server file not found: {server_file}")
            return

        logger.info("Path validation successful")

        # -------------------------------------------------
        # MCP Server Parameters
        # -------------------------------------------------

        params = StdioServerParameters(
            command="python",
            args=[str(server_file)],
            cwd=str(project_root),
        )

        logger.info("Created MCP stdio parameters")
        logger.debug(f"Command: python")
        logger.debug(f"Args: {[str(server_file)]}")
        logger.debug(f"CWD: {str(project_root)}")

        # -------------------------------------------------
        # Connect to MCP Server
        # -------------------------------------------------

        logger.info("Connecting to MCP server...")
        async with stdio_client(params) as (read, write):
            logger.info("STDIO client connected successfully")
            async with ClientSession(read, write) as session:
                logger.info("ClientSession created")

                # -------------------------------------------------
                # Initialize Session
                # -------------------------------------------------

                logger.info("Initializing MCP session...")
                await session.initialize()
                logger.info("MCP session initialized successfully")

                # -------------------------------------------------
                # List Tools
                # -------------------------------------------------
                logger.info("Fetching available tools...")
                tools = await session.list_tools()
                logger.info(f"Total tools received: {len(tools.tools)}")

                print("\nAvailable tools:")
                print("-" * 40)

                for tool in tools.tools:
                    logger.info(f"Tool found: {tool.name}")
                    print(f"• {tool.name}")

                # -------------------------------------------------
                # Test Elasticsearch MCP Tools
                # -------------------------------------------------

                logger.info("Calling ping_elasticsearch tool...")

                ping_result = await session.call_tool(
                    "ping_elasticsearch",
                    {}
                )

                logger.info("ping_elasticsearch completed successfully")

                print("\nPing Result:")
                print("-" * 40)
                print(ping_result)

                # -------------------------------------------------
                # List Elasticsearch Indices
                # -------------------------------------------------

                logger.info("Calling list_elasticsearch_indices tool...")

                indices_result = await session.call_tool(
                    "list_elasticsearch_indices",
                    {}
                )

                logger.info("list_elasticsearch_indices completed successfully")

                print("\nElasticsearch Indices:")
                print("-" * 40)
                print(indices_result)

                # -------------------------------------------------
                # Search Elasticsearch Logs
                # -------------------------------------------------

                logger.info("Calling search_elasticsearch_logs tool...")

                search_result = await session.call_tool(
                    "search_elasticsearch_logs",
                    {
                        "query": "error OR exception OR traceback",
                        "index": "logs-*",
                        "size": 5
                    }
                )

                logger.info("search_elasticsearch_logs completed successfully")

                print("\nSearch Logs Result:")
                print("-" * 40)
                print(search_result)

                logger.info("Test completed successfully")

    except Exception as e:

        logger.exception("MCP CLIENT FAILED")

        print("\nERROR OCCURRED")
        print("-" * 40)
        print(str(e))

    finally:

        logger.info("========================================")
        logger.info("MCP CLIENT STOPPED")
        logger.info("========================================")


# =========================================================
# ENTRYPOINT
# =========================================================

if __name__ == "__main__":
    asyncio.run(main())