"""
Audit Logger — Structured JSON logging for the multi-agent system.

AUTO-PUSH TO ELASTIC CLOUD:
    Every event written to disk is also pushed to Elastic Cloud in the
    background (fire-and-forget daemon thread). No blocking, no data loss
    if Elastic is down — the event is always written to disk first.

    Index routing:
        query_start / query_end     → logs-queries
        pipeline_stage_*            → logs-pipeline
        message_request/response    → logs-messages
        system_error                → logs-errors
        (everything else)           → logs-audit

"""

import os
import json
import uuid
import threading
from datetime import datetime, timezone
from typing import Dict, Any, Optional


# ═══════════════════════════════════════════════════════════════════════════════
# Index routing table
# ═══════════════════════════════════════════════════════════════════════════════

_INDEX_ROUTES: Dict[str, str] = {
    "query_start":      "logs-queries",
    "query_end":        "logs-queries",
    "pipeline_stage_":  "logs-pipeline",   # prefix match
    "message_request":  "logs-messages",
    "message_response": "logs-messages",
    "message_error":    "logs-messages",
    "system_error":     "logs-errors",
}

_DEFAULT_INDEX = "logs-audit"


def _route_index(event_type: str) -> str:
    """Pick the correct Elastic index for an event_type."""
    for prefix, index in _INDEX_ROUTES.items():
        if event_type.startswith(prefix):
            return index
    return _DEFAULT_INDEX


# ═══════════════════════════════════════════════════════════════════════════════
# Elastic background push
# ═══════════════════════════════════════════════════════════════════════════════

def _push_to_elastic_sync(event: Dict[str, Any]):
    """
    Push one event to Elastic Cloud using the synchronous client.
    Runs in a daemon thread — never blocks the caller.
    Fails silently so the audit logger is never affected.

    Auth priority:
        1. ELASTIC_URL  + ES_API_KEY        (new — direct HTTPS URL)
        2. ELASTICSEARCH_CLOUD_ID + ES_API_KEY  (legacy — cloud_id)
    """
    elastic_url = os.getenv("ELASTIC_URL")
    cloud_id    = os.getenv("ELASTICSEARCH_CLOUD_ID")
    api_key     = os.getenv("ES_API_KEY") or os.getenv("ELASTICSEARCH_API_KEY")

    # Need at least one connection method and an API key
    if not api_key or (not elastic_url and not cloud_id):
        return  # Elastic not configured — skip silently

    try:
        from elasticsearch import Elasticsearch

        if elastic_url:
            es = Elasticsearch(hosts=[elastic_url], api_key=api_key, verify_certs=True)
        else:
            es = Elasticsearch(cloud_id=cloud_id, api_key=api_key, verify_certs=True)

        index = _route_index(event.get("event_type", ""))

        # @timestamp is required by Elastic data streams
        doc = dict(event)
        if "@timestamp" not in doc:
            doc["@timestamp"] = doc.get("timestamp") or datetime.now(timezone.utc).isoformat()

        es.index(index=index, document=doc)
        es.close()

    except Exception:
        pass  # Never crash the audit logger because Elastic is down


def _push_in_background(event: Dict[str, Any]):
    """Spawn a daemon thread to push the event to Elastic."""
    threading.Thread(
        target=_push_to_elastic_sync,
        args=(event,),
        daemon=True,
        name="elastic-push",
    ).start()


# ═══════════════════════════════════════════════════════════════════════════════
# AuditLogger
# ═══════════════════════════════════════════════════════════════════════════════

class AuditLogger:
    """
    Thread-safe structured JSON event logger with daily file rotation
    and automatic background push to Elastic Cloud.

    Every call to log_event():
      1. Writes to disk immediately (guaranteed, even if Elastic is down)
      2. Pushes to Elastic Cloud in a background daemon thread (fire-and-forget)
    """

    def __init__(self, audit_dir: str = "memory_store/audit"):
        self.audit_dir = os.path.abspath(audit_dir)
        self._lock = threading.Lock()
        self._current_date: Optional[str] = None
        self._file_path: Optional[str] = None
        os.makedirs(self.audit_dir, exist_ok=True)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def log_event(self, event: Dict[str, Any]):
        """
        Log a structured event to the daily audit file AND push to Elastic.

        Disk write is synchronous and guaranteed.
        Elastic push is background fire-and-forget.
        """
        if "event_id" not in event:
            event["event_id"] = str(uuid.uuid4())
        if "timestamp" not in event:
            event["timestamp"] = datetime.utcnow().isoformat() + "Z"

        # 1. Write to disk first — always
        today = datetime.utcnow().strftime("%Y-%m-%d")
        if today != self._current_date:
            self._rotate(today)

        with self._lock:
            try:
                with open(self._file_path, "a", encoding="utf-8") as f:
                    f.write(json.dumps(event, ensure_ascii=False) + "\n")
            except Exception as e:
                print(f"[AUDIT] Failed to write event: {e}")

        # 2. Push to Elastic Cloud in background — never blocks
        _push_in_background(event)

    def log_message(
            self,
            message_type: str,
            sender_id: str,
            sender_type: str,
            receiver_id: Optional[str],
            receiver_type: Optional[str],
            message_id: str,
            correlation_id: Optional[str],
            confidence: float,
            task_action: Optional[str] = None,
            error_message: Optional[str] = None,
            response_summary: Optional[Dict] = None,
            query_id: Optional[str] = None,
            pipeline_stage: Optional[str] = None,
            ttl: int = 10,
    ):
        """Log a message passing through the communication bus."""
        event = {
            "event_type": f"message_{message_type.lower()}",
            "sender":   {"agent_id": sender_id,   "agent_type": sender_type},
            "receiver": {"agent_id": receiver_id or "broadcast",
                         "agent_type": receiver_type or "ALL"},
            "message": {
                "message_id":       message_id,
                "correlation_id":   correlation_id,
                "message_type":     message_type,
                "task_action":      task_action,
                "confidence":       confidence,
                "error":            error_message,
                "response_summary": response_summary,
                "ttl_remaining":    ttl,
            },
        }
        if query_id:
            event["pipeline_context"] = {
                "query_id": query_id,
                "pipeline_stage": pipeline_stage,
            }
        self.log_event(event)

    def log_pipeline_stage(
            self,
            stage: str,
            status: str,
            agent_type: str,
            confidence: float,
            duration_ms: Optional[float] = None,
            query_id: Optional[str] = None,
            query_preview: Optional[str] = None,
            input_type: Optional[str] = None,
            stage_number: Optional[str] = None,
            retry_attempt: int = 0,
            error: Optional[str] = None,
            summary: Optional[Dict] = None,
    ):
        """Log a pipeline stage completion."""
        event = {
            "event_type":    f"pipeline_stage_{status}",
            "pipeline_stage": stage,
            "stage_number":   stage_number,
            "status":         status,
            "agent_type":     agent_type,
            "confidence":     confidence,
            "retry_attempt":  retry_attempt,
            "error":          error,
            "summary":        summary,
        }
        if duration_ms is not None:
            event["performance"] = {"duration_ms": round(duration_ms, 2)}
        if query_id:
            event["pipeline_context"] = {
                "query_id":      query_id,
                "query_preview": query_preview[:80] if query_preview else None,
                "input_type":    input_type,
            }
        self.log_event(event)

    def log_query_start(
            self,
            query_id: str,
            query_text: str,
            input_type: str,
            input_format: str,
            detection_layer: int,
            detection_confidence: str,
            chars: int,
            lines: int,
    ):
        """Log the start of a new user query session."""
        self.log_event({
            "event_type": "query_start",
            "pipeline_context": {
                "query_id":            query_id,
                "query_preview":       query_text[:200],
                "input_type":          input_type,
                "input_format":        input_format,
                "detection_layer":     detection_layer,
                "detection_confidence": detection_confidence,
                "chars":               chars,
                "lines":               lines,
            },
        })

    def log_query_end(
            self,
            query_id: str,
            total_duration_ms: float,
            pipeline_completed: bool,
            final_confidence: Optional[float] = None,
            error: Optional[str] = None,
    ):
        """Log the end of a query session."""
        self.log_event({
            "event_type": "query_end",
            "pipeline_context": {"query_id": query_id},
            "performance": {"total_duration_ms": round(total_duration_ms, 2)},
            "pipeline_completed": pipeline_completed,
            "final_confidence":   final_confidence,
            "error":              error,
        })

    def log_error(
            self,
            error_type: str,
            error_message: str,
            agent_type: Optional[str] = None,
            query_id: Optional[str] = None,
            context: Optional[Dict] = None,
    ):
        """Log a system error or exception."""
        self.log_event({
            "event_type": "system_error",
            "error": {"type": error_type, "message": error_message},
            "agent_type": agent_type,
            "pipeline_context": {"query_id": query_id} if query_id else None,
            "context": context,
        })

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _rotate(self, today: str):
        """Rotate to a new daily log file."""
        self._current_date = today
        self._file_path = os.path.join(self.audit_dir, f"pipeline_{today}.json")

        if not os.path.exists(self._file_path):
            with open(self._file_path, "w", encoding="utf-8") as f:
                f.write(json.dumps({
                    "audit_log_start": today,
                    "created_at":      datetime.utcnow().isoformat() + "Z",
                    "format":          "json_lines",
                    "description":     "One JSON object per line. Each line is a complete event."
                }) + "\n")

    def get_stats(self) -> Dict:
        """Get audit logger statistics."""
        total_size = 0
        file_count = 0
        if os.path.exists(self.audit_dir):
            for f in os.listdir(self.audit_dir):
                if f.endswith(".json"):
                    total_size += os.path.getsize(os.path.join(self.audit_dir, f))
                    file_count += 1
        return {
            "audit_dir":        self.audit_dir,
            "current_file":     self._file_path,
            "total_files":      file_count,
            "total_size_bytes": total_size,
            "total_size_mb":    round(total_size / (1024 * 1024), 2),
        }


# ═══════════════════════════════════════════════════════════════════════════════
# Singleton
# ═══════════════════════════════════════════════════════════════════════════════

_audit_logger: Optional[AuditLogger] = None


def get_audit_logger(audit_dir: str = "memory_store/audit") -> AuditLogger:
    """Get or create the global audit logger instance."""
    global _audit_logger
    if _audit_logger is None:
        _audit_logger = AuditLogger(audit_dir)
    return _audit_logger