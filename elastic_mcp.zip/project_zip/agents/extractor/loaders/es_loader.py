"""
Elasticsearch Loader — Pulls logs directly from Elasticsearch clusters.

Supports:
  - Index pattern matching (e.g., "logs-*", "prod-2024-*")
  - Time range queries
  - Lucene query strings AND structured Query DSL
  - Field selection for relevant log fields
  - Automatic timestamp detection and sorting
  - Size limits with sampling for large result sets

Security:
  - Read-only (only _search endpoint, no writes)
  - Connection via environment variables or direct config
  - SSL/TLS support with certificate verification
"""

import os
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any

from elasticsearch import AsyncElasticsearch


class ElasticsearchLoader:
    """
    Pulls log entries from an Elasticsearch cluster.

    Usage:
        loader = ElasticsearchLoader(hosts=["http://localhost:9200"])
        logs = await loader.search(
            index="logs-*",
            query={"match": {"level": "ERROR"}},
            time_range=("now-1h", "now"),
            size=100
        )
    """

    # Default fields to return from ES (avoids returning massive _source blobs)
    DEFAULT_FIELDS = [
        "@timestamp", "timestamp", "level", "severity", "message",
        "logger", "service", "host", "pod", "container",
        "trace_id", "span_id", "error", "exception", "stack_trace"
    ]

    def __init__(
            self,
            hosts: List[str] = None,
            cloud_id: str = None,
            elastic_url = None,
            api_key: str = None,
            username: str = None,
            password: str = None,
            verify_certs: bool = True,
            timeout: int = 30,
            max_size: int = 5000,
    ):
        """
        Initialize the Elasticsearch loader.

        Args:
            hosts: List of ES hosts (e.g., ["http://localhost:9200"])
                   Default: from ELASTICSEARCH_HOSTS env var or ["http://localhost:9200"]
            cloud_id: Elastic Cloud ID (overrides hosts)
            api_key: API key for authentication (from ELASTICSEARCH_API_KEY env var)
            username: Username for basic auth (from ELASTICSEARCH_USER env var)
            password: Password for basic auth (from ELASTICSEARCH_PASSWORD env var)
            verify_certs: Verify SSL certificates
            timeout: Request timeout in seconds
            max_size: Maximum number of log entries to return
        """
        self.api_key = api_key or os.getenv("ELASTICSEARCH_API_KEY")
        self.username = username or os.getenv("ELASTICSEARCH_USER", "elastic")
        self.password = password or os.getenv("ELASTICSEARCH_PASSWORD")

        self.elastic_url = elastic_url or os.getenv("ELASTIC_URL")
        self.hosts = hosts or self._env_list("ELASTICSEARCH_HOSTS", ["http://localhost:9200"])
        self.cloud_id = cloud_id or os.getenv("ELASTICSEARCH_CLOUD_ID")

        self.verify_certs = verify_certs
        self.timeout = timeout
        self.max_size = max_size
        self._client = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def search(
            self,
            index: str = "logs-*",
            query: Optional[Dict] = None,
            query_string: Optional[str] = None,
            time_range: Optional[tuple] = None,
            time_field: str = "@timestamp",
            fields: Optional[List[str]] = None,
            size: int = 100,
            sort: str = "desc",
    ) -> str:
        """
        Search Elasticsearch and return formatted log entries.

        Args:
            index: Index pattern (e.g., "logs-*", "prod-2024-01-*")
            query: Elasticsearch Query DSL dict (e.g., {"match": {"level": "ERROR"}})
            query_string: Lucene query string (e.g., "level:ERROR AND service:auth")
            time_range: (start, end) tuple. Use "now-1h" format or ISO timestamps.
            time_field: Timestamp field name
            fields: Fields to return (default: DEFAULT_FIELDS)
            size: Max results (capped at self.max_size)
            sort: Sort order ("asc" or "desc")

        Returns:
            Formatted log entries as a string, ready for preprocessing
        """
        if not self._client:
            self._client = self._create_client()

        # Build the ES search body
        body = self._build_search_body(
            query=query,
            query_string=query_string,
            time_range=time_range,
            time_field=time_field,
            fields=fields or self.DEFAULT_FIELDS,
            size=min(size, self.max_size),
            sort=sort,
        )

        try:
            from elasticsearch import AsyncElasticsearch

            if isinstance(self._client, AsyncElasticsearch):
                response = await self._client.search(
                    index=index,
                    body=body,
                    request_timeout=self.timeout
                )
            else:
                # Sync fallback
                response = self._client.search(
                    index=index,
                    body=body,
                    request_timeout=self.timeout
                )

            return self._format_response(response)

        except Exception as e:
            error_msg = str(e)
            if "index_not_found" in error_msg:
                raise ValueError(f"Elasticsearch index not found: {index}")
            elif "ConnectionError" in str(type(e).__name__):
                raise ConnectionError(
                    f"Cannot connect to Elasticsearch at {self.hosts}. "
                    "Check that ES is running and accessible."
                )
            raise RuntimeError(f"Elasticsearch search failed: {e}")

    async def get_recent_errors(self,index: str = "logs-*",
            hours: int = 24,size: int = 100,) -> str:
        """Fetch recent error-level log entries."""
        return await self.search(
            index=index,
            query={
                "bool": {
                    "should": [
                        {"match": {"level": "ERROR"}},
                        {"match": {"severity": "ERROR"}},
                        {"match": {"level": "CRITICAL"}},
                        {"match": {"severity": "CRITICAL"}},
                    ],
                    "minimum_should_match": 1,
                }
            },
            time_range=(f"now-{hours}h", "now"),
            size=size,
        )

    async def get_log_stats(self, index: str = "logs-*") -> Dict:
        """Get basic statistics about the log index."""
        if not self._client:
            self._client = self._create_client()

        try:
            from elasticsearch import AsyncElasticsearch
            if isinstance(self._client, AsyncElasticsearch):
                result = await self._client.count(index=index)
            else:
                result = self._client.count(index=index)
            return {"index": index, "total_documents": result.get("count", 0)}
        except Exception as e:
            return {"index": index, "error": str(e)}

    async def close(self):
        """Close the Elasticsearch client."""
        if self._client:
            from elasticsearch import AsyncElasticsearch
            if isinstance(self._client, AsyncElasticsearch):
                await self._client.close()
            else:
                self._client.close()
            self._client = None

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _create_client(self):
        """Create Elasticsearch client with appropriate auth."""
        try:
            from elasticsearch import Elasticsearch
        except ImportError:
            raise ImportError(
                "elasticsearch package is required. Install with: pip install elasticsearch"
            )

        auth_kwargs = {}
        if self.api_key:
            auth_kwargs["api_key"] = self.api_key
        elif self.username and self.password:
            auth_kwargs["basic_auth"] = (self.username, self.password)

        if self.elastic_url:
            return AsyncElasticsearch(
                hosts=[self.elastic_url],
                verify_certs=self.verify_certs,
                request_timeout=self.timeout,
                **auth_kwargs,
            )

        elif self.cloud_id:
            return AsyncElasticsearch(
                cloud_id=self.cloud_id,
                verify_certs=self.verify_certs,
                request_timeout=self.timeout,
                **auth_kwargs,
            )

        else:
            return AsyncElasticsearch(
                hosts=self.hosts,
                verify_certs=self.verify_certs,
                request_timeout=self.timeout,
                **auth_kwargs,
            )

    def _build_search_body(
            self,
            query: Optional[Dict],
            query_string: Optional[str],
            time_range: Optional[tuple],
            time_field: str,
            fields: List[str],
            size: int,
            sort: str,
    ) -> Dict:
        """Build the Elasticsearch search request body."""
        filters = []

        if time_range:
            start, end = time_range
            filters.append({
                "range": {
                    time_field: {
                        "gte": start,
                        "lte": end,
                        "format": "strict_date_optional_time||epoch_millis",
                    }
                }
            })

        if query_string:
            must = [{"query_string": {"query": query_string, "default_field": "*"}}]
        elif query:
            must = [query]
        else:
            must = [{"match_all": {}}]

        body: Dict[str, Any] = {
            "size": size,
            "sort": [{time_field: {"order": sort, "unmapped_type": "date"}}],
            "query": {
                "bool": {
                    "must": must,
                    "filter": filters,
                }
            },
            "_source": fields,
        }

        return body

    def _format_results(self, result: Dict) -> str:
        """Format Elasticsearch results as a readable string."""
        hits = result.get("hits", {}).get("hits", [])
        total = result.get("hits", {}).get("total", {})
        total_count = total.get("value", len(hits)) if isinstance(total, dict) else total

        if not hits:
            return f"No log entries found. (Total matching: {total_count})"

        lines = [f"Found {total_count} matching logs, showing {len(hits)}:\n"]
        for i, hit in enumerate(hits, 1):
            source = hit.get("_source", {})
            ts = source.get("@timestamp") or source.get("timestamp", "unknown time")
            level = source.get("level") or source.get("severity", "INFO")
            message = source.get("message", json.dumps(source, default=str)[:200])
            lines.append(f"[{i}] {ts} | {level} | {message}")

            # Append exception / stack trace if present
            if source.get("exception"):
                lines.append(f"    Exception: {source['exception']}")
            if source.get("stack_trace"):
                lines.append(f"    Stack: {str(source['stack_trace'])[:300]}")

        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Utility
    # ------------------------------------------------------------------

    @staticmethod
    def _env_list(env_var: str, default: List[str]) -> List[str]:
        """Parse a comma-separated env var into a list."""
        value = os.getenv(env_var)
        if not value:
            return default
        return [h.strip() for h in value.split(",") if h.strip()]

    def is_available(self) -> bool:
        """Check if Elasticsearch is configured and reachable."""
        try:
            if not self._client:
                self._client = self._create_client()
            return self._client.ping()
        except Exception:
            return False
