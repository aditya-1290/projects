# agents/extractor/loaders/image_loader.py

import os
from pathlib import Path
from typing import Dict, Any

from models.ocr.deepseek_ocr import DeepSeekOCR


SUPPORTED_FORMATS = {
    ".jpg",".jpeg",".png",".bmp",
    ".webp",".tiff",".tif",
}


class ImageLoader:
    def __init__(self):
        self.model_path = os.getenv(
            "DEEPSEEK_OCR_MODEL_PATH",
            r"D:\Models\DeepSeek-OCR-2"
        )
        self.ocr = DeepSeekOCR(self.model_path)

    async def load(self, image_path: str) -> Dict[str, Any]:
        path = Path(image_path)

        if not path.exists():
            return {
                "raw_logs": "",
                "source": "image",
                "format_detected": "image",
                "warning": f"Image file not found: {image_path}",
            }

        if not path.is_file():
            return {
                "raw_logs": "",
                "source": "image",
                "format_detected": "image",
                "warning": f"Path is not a file: {image_path}",
            }

        ext = path.suffix.lower()

        if ext not in SUPPORTED_FORMATS:
            return {
                "raw_logs": "",
                "source": "image",
                "format_detected": "image",
                "warning": f"Unsupported image format: {ext}. Supported formats: {sorted(SUPPORTED_FORMATS)}",
            }

        try:
            text = await self.ocr.extract_text(str(path))

            if not text or not text.strip():
                return {
                    "raw_logs": "",
                    "source": "image",
                    "format_detected": "ocr_text",
                    "image_path": str(path),
                    "warning": "OCR completed but no text was extracted from the image.",
                }

            return {
                "raw_logs": text,
                "source": "image",
                "format_detected": "ocr_text",
                "image_path": str(path),
                "confidence": 0.85,
            }

        except Exception as e:
            return {
                "raw_logs": "",
                "source": "image",
                "format_detected": "image",
                "image_path": str(path),
                "warning": f"Image OCR failed: {e}",
            }

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def extract(self, image_path: str, ocr_model=None) -> str:

        image_path = os.path.abspath(image_path)

        if not os.path.exists(image_path):
            raise FileNotFoundError(f"Image not found: {image_path}")

        ext = os.path.splitext(image_path)[1].lower()
        if ext not in SUPPORTED_FORMATS:
            raise ValueError(
                f"Unsupported image format '{ext}'. "
                f"Supported: {', '.join(sorted(SUPPORTED_FORMATS))}"
            )

        text = await self._try_all_methods(image_path, ocr_model)

        if not text or not text.strip():
            raise ValueError(
                f"No text could be extracted from '{os.path.basename(image_path)}'. "
                "The image may be blank, purely graphical, or too low-resolution."
            )

        return text.strip()

    # ------------------------------------------------------------------
    # Internal: OCR strategy chain
    # ------------------------------------------------------------------

    async def _try_all_methods(self, path: str, ocr_model) -> str:
        # 1. External model (highest quality — e.g. DeepSeek)
        if ocr_model:
            try:
                result = await ocr_model.extract_text(path)
                if result and result.strip():
                    return result
            except Exception as exc:
                print(f"[ImageLoader] External OCR model failed: {exc}")

        # 2. pytesseract with pre-processing
        text = await self._tesseract_ocr(path)
        if text and text.strip():
            return text

        # 3. Mock OCR — call its extract_text if available
        if ocr_model:
            try:
                result = await ocr_model.extract_text(path)
                if result and result.strip():
                    return result
            except Exception:
                pass

        # 4. Last resort fallback
        print(f"[ImageLoader] Warning: falling back to mock OCR for '{os.path.basename(path)}'")
        return f"[MOCK OCR] Placeholder text for: {os.path.basename(path)}\nInstall transformers + torch for real OCR."
    

    async def _tesseract_ocr(self, path: str) -> str:
        """Run pytesseract with image pre-processing."""
        try:
            import pytesseract
            from PIL import Image, ImageEnhance, ImageFilter

            img = Image.open(path)

            # Pre-processing pipeline
            img = self._preprocess(img)

            config = f"--dpi {self.dpi} --oem 3 --psm 6"
            text = pytesseract.image_to_string(img, lang=self.lang, config=config)
            return text

        except ImportError as exc:
            missing = str(exc).split("'")[1] if "'" in str(exc) else str(exc)
            print(f"[ImageLoader] pytesseract/Pillow not installed ({missing}); skipping.")
            return ""
        except Exception as exc:
            print(f"[ImageLoader] pytesseract failed: {exc}")
            return ""

    # ------------------------------------------------------------------
    # Image pre-processing
    # ------------------------------------------------------------------

    def _preprocess(self, img):
        """Convert to grayscale and boost contrast for better OCR."""
        try:
            from PIL import Image, ImageEnhance, ImageFilter

            # Convert to RGB first (handles palette / RGBA images)
            if img.mode not in ("RGB", "L"):
                img = img.convert("RGB")

            # Grayscale
            img = img.convert("L")

            # Upscale small images so tesseract has enough resolution
            w, h = img.size
            if max(w, h) < 1000:
                scale = 1000 / max(w, h)
                img = img.resize((int(w * scale), int(h * scale)), Image.LANCZOS)

            # Contrast enhancement
            enhancer = ImageEnhance.Contrast(img)
            img = enhancer.enhance(2.0)

            # Slight sharpen
            img = img.filter(ImageFilter.SHARPEN)

            return img
        except Exception:
            return img  # Return original if pre-processing fails

    # ------------------------------------------------------------------
    # Utility
    # ------------------------------------------------------------------

    def is_supported(self, path: str) -> bool:
        ext = os.path.splitext(path)[1].lower()
        return ext in SUPPORTED_FORMATS

    async def to_base64(self, image_path: str) -> str:
        """Return a base64-encoded version of the image (for API calls)."""
        with open(image_path, "rb") as f:
            return base64.b64encode(f.read()).decode("utf-8")
