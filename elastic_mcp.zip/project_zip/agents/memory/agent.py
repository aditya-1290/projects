"""
Memory Agent

Uses ChromaDB for vector storage of past log analyses.
Enables retrieval-based reasoning for similar errors.
"""

from typing import Dict, Any, List, Optional

from agents.base_agent import BaseAgent, A2AMessage, MessageType


class MemoryAgent(BaseAgent):
    """Stores and retrieves past log analyses"""

    def __init__(self):
        super().__init__("memory_v1", "agents/memory/capabilities.json")
        self.vector_store = None
        self.retrieval = None

    async def initialize(self):
        """Initialize vector store and retrieval systems"""
        from agents.memory.vector_store import VectorStore
        from agents.memory.retrieval import LogRetrieval

        self.vector_store = VectorStore()
        self.retrieval = LogRetrieval(self.vector_store)
        await self.vector_store.initialize()
        self.log("Memory system initialized")

    # ═══════════════════════════════════════════════════════════════════════════
    # ADK Integration
    # ═══════════════════════════════════════════════════════════════════════════

    def _get_model_requirements(self) -> list:
        return ["qwen2.5-3b-it"]

    def _resolve_adk_model(self) -> str:
        return "qwen2.5-3b-it"

    def _get_adk_tools(self) -> list:
        """Register vector search as an ADK tool."""
        return [
                {
                    "name": "search_similar_cases",
                    "description": "Search for past log analyses similar to the current case",
                    "parameters": {
                        "query": {"type": "string", "description": "Search query text"},
                        "limit": {"type": "integer", "description": "Max results", "default": 5}
                    }
                },
                {
                    "name": "store_analysis",
                    "description": "Store a completed log analysis for future retrieval",
                    "parameters": {
                        "log_content": {"type": "string", "description": "Original log text"},
                        "analysis": {"type": "object", "description": "Analysis results"},
                        "log_type": {"type": "string", "description": "Detected log type"}
                    }
                }
            ]

    def _build_adk_instruction(self) -> str:
        """Build the memory agent's ADK instruction."""
        return """You are the Memory Agent for a log analysis system.

    Your job is to store and retrieve past log analyses to provide context
    for new investigations.

    When retrieving:
    - Find semantically similar past cases
    - Rank by relevance (error type match > service match > recency)
    - Format cases for injection into the solver's context
    - Include what worked and what didn't

    When storing:
    - Index by error pattern, service, and log type
    - Track fix effectiveness over time
    - Deduplicate identical analyses
    - Generate embeddings for semantic search

    Tools available:
    - search_similar_cases: Find past analyses matching a query
    - store_analysis: Save a completed analysis with metadata
    """

    async def process(self, message: A2AMessage) -> A2AMessage:
        """Process memory operations"""
        if not self.vector_store:
            await self.initialize()

        task = message.task or {}
        action = task.get("action", "retrieve")

        if action in ("store", "store_log_analysis"):  # ← Accept both
            return await self._handle_store(message)
        elif action in ("retrieve", "retrieve_similar_cases"):
            return await self._handle_retrieve(message)
        elif action in ("search", "search_by_error_pattern"):
            return await self._handle_search(message)
        else:
            return await self._handle_retrieve(message)

    async def _handle_store(self, message: A2AMessage) -> A2AMessage:
        task = message.task or {}
        context = message.context or {}

        log_content = (
                context.get("clean_logs") or
                context.get("raw_logs") or
                task.get("log_content") or
                task.get("query") or
                ""
        )
        analysis = (
                context.get("solution") or
                task.get("analysis") or
                task.get("results") or
                {}
        )
        log_type = context.get("log_type", task.get("log_type", "unknown"))

        # If nothing to store, just return success silently (fire-and-forget)
        if not log_content and not analysis:
            return A2AMessage(
                message_type=MessageType.RESPONSE,
                sender_id=self.agent_id,
                sender_type="memory",
                target_id=message.sender_id,
                correlation_id=message.message_id,
                response={"stored": False, "reason": "No content to store"},
                confidence=0.5
            )

        document_id = await self.vector_store.store_analysis(
            log_content=log_content,
            analysis=analysis,
            log_type=log_type,
            metadata={
                "timestamp": __import__('datetime').datetime.now().isoformat(),
                "log_type": log_type
            }
        )

        self.log(f"Stored analysis: {document_id}")
        return A2AMessage(
            message_type=MessageType.RESPONSE,
            sender_id=self.agent_id,
            sender_type="memory",
            target_id=message.sender_id,
            correlation_id=message.message_id,
            response={"stored": True, "document_id": document_id},
            confidence=1.0
        )

    async def _handle_retrieve(self, message: A2AMessage) -> A2AMessage:
        """Retrieve similar past analyses"""
        task = message.task or {}
        context = message.context or {}

        query = (
                task.get("query") or
                context.get("clean_logs") or
                context.get("raw_logs") or
                context.get("query") or
                ""
        )
        limit = task.get("limit", 5)

        if not query:
            return A2AMessage(
                message_type=MessageType.ERROR,
                sender_id=self.agent_id,
                sender_type="memory",
                target_id=message.sender_id,
                error="No query provided for retrieval"
            )

        results = await self.retrieval.find_similar(query, limit=limit)

        return A2AMessage(
            message_type=MessageType.RESPONSE,
            sender_id=self.agent_id,
            sender_type="memory",
            target_id=message.sender_id,
            correlation_id=message.message_id,
            response={
                "results": results,
                "count": len(results),
                "query": query[:200]
            },
            confidence=0.8 if results else 0.3
        )

    async def _handle_search(self, message: A2AMessage) -> A2AMessage:
        """Search by error pattern"""
        task = message.task or {}

        error_pattern = task.get("error_pattern", "")
        log_type = task.get("log_type", "")

        results = await self.retrieval.search_by_pattern(
            error_pattern=error_pattern,
            log_type=log_type
        )

        return A2AMessage(
            message_type=MessageType.RESPONSE,
            sender_id=self.agent_id,
            sender_type="memory",
            target_id=message.sender_id,
            correlation_id=message.message_id,
            response={
                "results": results,
                "count": len(results)
            },
            confidence=0.7
        )