"""
Base Agent Class for Log Analysis Multi-Agent System

All agents inherit from this class. It provides:
- Capability contract management
- A2A message handling
- Model access
- Self-awareness (can_handle checks)
- ADK integration bridge (Google Agent Development Kit)
"""

import json
import uuid
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field
from enum import Enum
from abc import ABC, abstractmethod
from datetime import datetime

# ═══════════════════════════════════════════════════════════════════════════════
# SINGLE SOURCE OF TRUTH: Import A2A types from communication/a2a_protocol.py
# All agents and the communication bus use these exact same classes.
# ═══════════════════════════════════════════════════════════════════════════════
from communication.a2a_protocol import (
    A2AMessage,
    MessageType,
    MessagePriority,
    DeliveryStatus,
    CapabilityQuery,
    CapabilityResponse,
    ErrorCodes
)


# ═══════════════════════════════════════════════════════════════════════════════
# Agent State Enum (only defined here — not in a2a_protocol)
# ═══════════════════════════════════════════════════════════════════════════════

class AgentState(Enum):
    IDLE = "idle"
    PROCESSING = "processing"
    WAITING_FOR_HUMAN = "waiting_for_human"
    WAITING_FOR_AGENT = "waiting_for_agent"
    ERROR = "error"


# ═══════════════════════════════════════════════════════════════════════════════
# Capability Contract (agent-specific, not in a2a_protocol)
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class CapabilityContract:
    """Machine-readable capability declaration for each agent"""
    agent_name: str
    agent_id: str
    domain: str
    capabilities: List[str]
    limitations: List[str]
    preconditions: List[str]
    required_tools: List[str] = field(default_factory=list)
    fallback_agents: List[str] = field(default_factory=list)
    confidence_threshold: float = 0.5
    max_iterations: int = 3
    out_of_scope_message: str = "This task is outside my capabilities."

    @classmethod
    def from_json(cls, path: str) -> "CapabilityContract":
        """Load capability contract from JSON file"""
        with open(path, 'r') as f:
            data = json.load(f)
        return cls(**data)

    def to_dict(self) -> Dict:
        """Convert to dictionary for serialization"""
        return {
            "agent_name": self.agent_name,
            "agent_id": self.agent_id,
            "domain": self.domain,
            "capabilities": self.capabilities,
            "limitations": self.limitations,
            "preconditions": self.preconditions,
            "required_tools": self.required_tools,
            "fallback_agents": self.fallback_agents,
            "confidence_threshold": self.confidence_threshold,
            "max_iterations": self.max_iterations,
            "out_of_scope_message": self.out_of_scope_message
        }


# ═══════════════════════════════════════════════════════════════════════════════
# ADK Agent Card (standardized discovery metadata)
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class ADKAgentCard:
    """ADK-compatible agent discovery card.

    Provides standardized metadata for agent discovery, tool registration,
    and schema validation in ADK environments.
    """
    name: str
    description: str
    version: str = "1.0.0"
    capabilities: List[str] = field(default_factory=list)
    input_schema: Dict = field(default_factory=dict)
    output_schema: Dict = field(default_factory=dict)
    model_requirements: List[str] = field(default_factory=list)
    tools: List[Dict] = field(default_factory=list)
    agent_type: str = "custom"  # "llm", "tool", "orchestrator", "custom"

    def to_dict(self) -> Dict:
        return {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "capabilities": self.capabilities,
            "input_schema": self.input_schema,
            "output_schema": self.output_schema,
            "model_requirements": self.model_requirements,
            "tools": self.tools,
            "agent_type": self.agent_type
        }


# ═══════════════════════════════════════════════════════════════════════════════
# Agent Response (structured return from agent processing)
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class AgentResponse:
    """Structured response from agent processing"""
    success: bool
    data: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None
    confidence: float = 1.0
    caveats: List[str] = field(default_factory=list)
    requires_human: bool = False
    human_question: Optional[str] = None
    next_agent_suggestion: Optional[str] = None
    state_changes: Dict[str, Any] = field(default_factory=dict)


# ═══════════════════════════════════════════════════════════════════════════════
# Base Agent Class
# ═══════════════════════════════════════════════════════════════════════════════

class BaseAgent(ABC):
    """
    Base class for all agents in the Log Analysis Multi-Agent System.

    Every agent:
    - Has a capability contract defining what it can/cannot do
    - Communicates via A2A messages through the communication bus
    - Can access models through the model manager
    - Self-evaluates whether it can handle incoming tasks
    - Can create an ADK-compatible wrapper for external integration
    """

    def __init__(self, agent_id: str, capability_path: str):
        """
        Initialize the agent.

        Args:
            agent_id: Unique identifier for this agent instance
            capability_path: Path to the capabilities.json file
        """
        self.agent_id = agent_id
        self.capability = CapabilityContract.from_json(capability_path)
        self.state = AgentState.IDLE
        self.comm_bus = None  # Set by CommunicationBus during registration
        self.model_manager = None  # Set during system initialization
        self.processing_history: List[Dict] = []
        self.current_task: Optional[Dict] = None
        self._adk_agent = None  # Cached ADK agent instance

    # ═══════════════════════════════════════════════════════════════════════════
    # Core Methods (Override in subclasses)
    # ═══════════════════════════════════════════════════════════════════════════

    @abstractmethod
    async def process(self, message: A2AMessage) -> A2AMessage:
        """
        Process an incoming A2A message.

        MUST be implemented by every agent subclass.

        Args:
            message: The A2A message to process

        Returns:
            A2AMessage with the response
        """
        pass

    # ═══════════════════════════════════════════════════════════════════════════
    # ADK Integration
    # ═══════════════════════════════════════════════════════════════════════════

    @property
    def adk_card(self) -> ADKAgentCard:
        """
        Get the ADK-compatible agent card for this agent.

        Override in subclasses to provide agent-specific schemas and tools.
        """
        return ADKAgentCard(
            name=self.capability.agent_name,
            description=f"{self.capability.agent_name} agent for {self.capability.domain}",
            capabilities=self.capability.capabilities,
            input_schema={
                "type": "object",
                "properties": {
                    "task": {"type": "object", "description": "Task to execute"},
                    "context": {"type": "object", "description": "Context from previous agents"}
                }
            },
            output_schema={
                "type": "object",
                "properties": {
                    "response": {"type": "object", "description": "Agent response data"},
                    "confidence": {"type": "number", "description": "Confidence score 0.0-1.0"}
                }
            },
            model_requirements=self._get_model_requirements(),
            tools=self._get_adk_tools(),
        )

    def _get_model_requirements(self) -> List[str]:
        """Get the list of models this agent requires. Override in subclasses."""
        return []

    def _get_adk_tools(self) -> List[Dict]:
        """Get the list of ADK-compatible tools this agent provides. Override in subclasses."""
        return []

    def create_adk_agent(self, model: str = None, instruction: str = None):
        """
        Create an ADK LlmAgent wrapping this agent's processing logic.

        This is the bridge method that makes any BaseAgent compatible with
        Google ADK without modifying the existing communication bus architecture.

        Args:
            model: Model name for ADK (defaults to agent's primary model)
            instruction: System instruction prompt (defaults to agent's description)

        Returns:
            An ADK LlmAgent instance ready for registration with ADK runner
        """
        try:
            from google.adk.agents import LlmAgent
        except ImportError:
            raise ImportError(
                "google-adk is required for ADK integration. "
                "Install with: pip install google-adk"
            )

        if self._adk_agent is not None:
            return self._adk_agent

        card = self.adk_card

        # Build the ADK agent
        self._adk_agent = LlmAgent(
            name=card.name,
            description=card.description,
            model=model or self._resolve_adk_model(),
            instruction=instruction or self._build_adk_instruction(),
            tools=self._build_adk_tools(),
            output_schema=card.output_schema,
            before_agent_callback=self._adk_before_callback,
            after_agent_callback=self._adk_after_callback,
        )

        return self._adk_agent

    def _resolve_adk_model(self) -> str:
        """
        Resolve which model to use for ADK.
        Maps the agent's model manager models to ADK-compatible model strings.
        """
        # Default mapping based on agent type
        model_map = {
            "solver": "gemma-4-e4b-it",
            "analyzer": "gemma-4-e4b-it",
            "debugger": "gemma-4-e4b-it",
            "critic": "gemma-4-e4b-it",
            "orchestrator": "gemma-4-e4b-it",
            "preprocessor": "qwen2.5-3b-it",
            "memory": "qwen2.5-3b-it",
            "extractor": "deepseek-ocr2",
        }
        return model_map.get(self.capability.agent_name, "gemma-4-e4b-it")

    def _build_adk_instruction(self) -> str:
        """
        Build the ADK instruction (system prompt) from the agent's skill prompts.
        Override in subclasses to provide specific skill prompts.
        """
        return (
            f"You are the {self.capability.agent_name} agent.\n"
            f"Domain: {self.capability.domain}\n"
            f"Capabilities: {', '.join(self.capability.capabilities)}\n"
            f"Limitations: {', '.join(self.capability.limitations)}\n"
        )

    def _build_adk_tools(self) -> List:
        """
        Build ADK-compatible tool instances from the agent's tool configurations.
        Override in subclasses to provide actual tool instances.
        """
        tools = []
        card_tools = self._get_adk_tools()

        for tool_config in card_tools:
            tool = self._create_adk_tool_from_config(tool_config)
            if tool:
                tools.append(tool)

        return tools

    def _create_adk_tool_from_config(self, config: Dict) -> Optional[Any]:
        """
        Create an ADK tool from configuration dict.
        Override in subclasses for custom tool creation.
        """
        # This is a hook for subclasses to create actual ADK tools
        return None

    async def _adk_before_callback(self, context, request=None) -> Optional[Any]:
        """
        ADK callback: Called before the agent processes a request.
        Updates agent state and logs the incoming request.
        """
        self.state = AgentState.PROCESSING
        self.log(f"ADK request received", "DEBUG")
        return None  # Return None to proceed normally

    async def _adk_after_callback(self, context, response) -> Optional[Any]:
        """
        ADK callback: Called after the agent generates a response.
        Updates agent state and stores processing history.
        """
        if self.state != AgentState.ERROR:
            self.state = AgentState.IDLE

        self.processing_history.append({
            "timestamp": datetime.now().isoformat(),
            "context": str(context)[:500],
            "response": str(response)[:500]
        })

        self.log(f"ADK response generated", "DEBUG")
        return None  # Return None to use the original response

    async def process_stream(self, message: A2AMessage):
        """
        Process a message with streaming support.

        Override in subclasses for streaming responses.
        Default: yields the final result from process().
        """
        result = await self.process(message)
        yield result

    # ═══════════════════════════════════════════════════════════════════════════
    # Message Handling
    # ═══════════════════════════════════════════════════════════════════════════

    async def receive_message(self, message: A2AMessage) -> Optional[A2AMessage]:
        """
        Called by the communication bus when a message arrives for this agent.

        Performs pre-processing checks before calling process().
        """
        # Check TTL
        if message.ttl <= 0:
            return self._create_error_response(
                message, "Message TTL expired"
            )

        # Decrement TTL
        message.ttl -= 1
        message.route_history.append(self.agent_id)

        # Check if we can handle this
        if message.task and not self.can_handle(message.task):
            return self._create_cannot_handle_response(message)

        # Update state
        self.state = AgentState.PROCESSING
        self.current_task = message.task

        try:
            # Process the message
            response = await self.process(message)
            self.processing_history.append({
                "task": message.task,
                "response": response.to_dict(),
                "timestamp": datetime.now().isoformat()
            })
            return response

        except Exception as e:
            self.state = AgentState.ERROR
            return self._create_error_response(message, str(e))

        finally:
            if self.state != AgentState.ERROR:
                self.state = AgentState.IDLE
            self.current_task = None

    async def send_message(self, message: A2AMessage):
        """
        Send a message via the communication bus.

        Args:
            message: The A2A message to send
        """
        if self.comm_bus:
            message.sender_id = self.agent_id
            message.sender_type = self.capability.agent_name
            await self.comm_bus.send_message(message)
        else:
            raise RuntimeError(
                f"Agent {self.agent_id} is not connected to a communication bus"
            )

    # ═══════════════════════════════════════════════════════════════════════════
    # Self-Awareness Methods
    # ═══════════════════════════════════════════════════════════════════════════

    def _can_handle_action(self, action: str) -> bool:
        """
        Map high-level action to this agent's capabilities.
        Each agent decides what actions it supports.
        """
        action_map = {
            "extract": [
                "extract_from_text_file",
                "extract_from_log_file",
                "extract_from_json",
                "extract_from_csv",
                "extract_from_xml",
                "extract_from_image",
                "extract_from_terminal",
                "extract_from_syslog",
                "extract_from_apache_log",
                "extract_from_pasted_text"
            ],
            "preprocess": [
                "clean_logs",
                "parse_logs",
                "chunk_large_inputs"
            ],
            "analyze": [
                "classify_logs",
                "detect_intent"
            ],
            "solve": [
                "root_cause_analysis",
                "generate_fix_suggestions"
            ],
            "debug": [
                "parse_stack_trace",
                "generate_code_patch"
            ],
            "validate": [
                "validate_solution_quality"
            ]
        }

        required_caps = action_map.get(action, [])
        return any(cap in self.capability.capabilities for cap in required_caps)

    def can_handle(self, task: Dict) -> bool:
        """
        Self-awareness check: Can this agent handle the given task?
        Returns True if agent can handle, False otherwise.
        """
        return True

    def _evaluate_precondition(self, condition: str, context: Dict) -> bool:
        """
        Evaluate a precondition against the current context.
        """
        if condition.startswith("state."):
            key = condition.replace("state.", "")
            return bool(context.get(key))

        if condition.startswith("context."):
            key = condition.replace("context.", "")
            return bool(context.get(key))

        if condition == "clean_logs_present":
            return bool(context.get("clean_logs"))

        if condition == "raw_logs_present":
            return bool(context.get("raw_logs"))

        if condition == "log_analysis_complete":
            return bool(context.get("analysis"))

        if condition == "solution_generated":
            return bool(context.get("solution"))

        if condition == "original_logs_available":
            return bool(context.get("raw_logs") or context.get("clean_logs"))

        return bool(context.get(condition))

    def what_can_you_do(self) -> str:
        """Return a human-readable capability description"""
        can = ", ".join(self.capability.capabilities)
        cannot = ", ".join(self.capability.limitations)

        return f"""
🤖 Agent: {self.capability.agent_name} ({self.agent_id})
📋 Domain: {self.capability.domain}

✅ I CAN:
   {can}

❌ I CANNOT:
   {cannot}

📎 Required Tools: {", ".join(self.capability.required_tools) if self.capability.required_tools else 'None'}
🔄 Fallback Agents: {", ".join(self.capability.fallback_agents)}
"""

    # ═══════════════════════════════════════════════════════════════════════════
    # Model Access
    # ═══════════════════════════════════════════════════════════════════════════

    async def get_model(self, model_name: str):
        """
        Get a model instance from the model manager.

        Args:
            model_name: One of 'gemma', 'qwen_small', 'deepseek_ocr', 'embedding'

        Returns:
            Model instance for inference
        """
        if self.model_manager:
            return await self.model_manager.get_model(model_name)
        else:
            raise RuntimeError(
                f"Agent {self.agent_id} has no model manager configured"
            )

    async def release_model(self, model_name: str):
        """Release a model back to the pool"""
        if self.model_manager:
            await self.model_manager.release_model(model_name)

    # ═══════════════════════════════════════════════════════════════════════════
    # Helper Methods
    # ═══════════════════════════════════════════════════════════════════════════

    def _create_error_response(self, original_message: A2AMessage, error: str) -> A2AMessage:
        """Create an error response message"""
        return A2AMessage(
            message_type=MessageType.ERROR,
            sender_id=self.agent_id,
            sender_type=self.capability.agent_name,
            target_id=original_message.sender_id,
            correlation_id=original_message.message_id,
            error=error,
            context={"original_task": original_message.task}
        )

    def _create_cannot_handle_response(self, message: A2AMessage) -> A2AMessage:
        """Create response for tasks this agent cannot handle"""
        return A2AMessage(
            message_type=MessageType.RESPONSE,
            sender_id=self.agent_id,
            sender_type=self.capability.agent_name,
            target_id=message.sender_id,
            correlation_id=message.message_id,
            response={
                "can_handle": False,
                "reason": self.capability.out_of_scope_message,
                "suggested_agents": self.capability.fallback_agents,
                "my_capabilities": self.capability.capabilities
            },
            confidence=0.0
        )

    def _create_human_request(self, question: str) -> A2AMessage:
        """Create a message requesting human input"""
        self.state = AgentState.WAITING_FOR_HUMAN
        return A2AMessage(
            message_type=MessageType.HUMAN_INPUT_REQUEST,
            sender_id=self.agent_id,
            sender_type=self.capability.agent_name,
            requires_human=True,
            human_question=question
        )

    def log(self, message: str, level: str = "INFO"):
        """Simple logging helper"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        print(f"[{timestamp}] [{self.capability.agent_name}] [{level}] {message}")

    async def _generate_with_tracking(self, model, prompt: str, max_tokens: int, action_name: str):
        """
        Generate LLM response and track token usage.
        Wraps model.generate() with audit logging and OTEL tracing.
        Returns a GenerateResult with .text and .usage attributes.
        """
        try:
            from utils.tracing import trace_llm_call
            model_name = getattr(model, "name", "unknown")
            with trace_llm_call(model_name, len(prompt)) as llm_span:
                response = await model.generate(prompt, max_tokens=max_tokens)
                llm_span.set_attribute("llm.max_tokens", max_tokens)
                llm_span.set_attribute("agent.action", action_name)
        except Exception:
            # tracing unavailable — just generate
            response = await model.generate(prompt, max_tokens=max_tokens)

        # Extract token counts from GenerateResult.usage if available
        if hasattr(response, "usage") and response.usage:
            usage = response.usage
            input_tokens = usage.get("prompt_tokens", 0)
            output_tokens = usage.get("completion_tokens", 0)
            total_tokens = usage.get("total_tokens", input_tokens + output_tokens)
            token_source = "exact"
        else:
            try:
                response_text = response.text if hasattr(response, "text") else str(response)
            except Exception:
                response_text = ""
            input_tokens = len(prompt) // 4
            output_tokens = len(response_text) // 4 if response_text else max_tokens // 2
            total_tokens = input_tokens + output_tokens
            token_source = "estimated"

        self.log_agent_event("llm_call", {
            "action": action_name,
            "model": getattr(model, "name", "unknown"),
            "max_tokens_limit": max_tokens,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "total_tokens": total_tokens,
            "token_source": token_source,
        })

        return response

    def log_agent_event(self, event_type: str, details: Dict = None):
        """Log an agent processing event with token counts to the audit logger."""
        try:
            from utils.audit_logger import get_audit_logger
            audit = get_audit_logger()
            event = {
                "event_type": f"agent_{event_type}",
                "agent_id": self.agent_id,
                "agent_type": self.capability.agent_name,
            }
            if details:
                event.update(details)
            audit.log_event(event)
        except Exception:
            pass