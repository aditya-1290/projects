"""Preprocessor Tools — Clean, parse, normalize, and filter logs."""
import os
import httpx
from google.adk.tools import ToolContext

API_BASE = os.getenv("LOG_AGENT_API_BASE", "http://127.0.0.1:8002")


async def _post_run(query: str, timeout: int = 1200) -> str:
    """Call /run on the FastAPI backend and return the response string."""
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.post(
                f"{API_BASE}/run",
                json={"query": query},
            )

        if response.status_code != 200:
            return f"Backend returned HTTP {response.status_code}: {response.text}"

        data = response.json()
        # FIX: _post_run returns a str — callers must NOT call .get() on the result
        return data.get("response") or str(data)

    except Exception as e:
        return f"Tool failed: {type(e).__name__}: {e}"


async def preprocess_logs(raw_logs: str, tool_context: ToolContext) -> str:
    """
    Clean, parse, normalize, and chunk raw log entries.
    Returns structured, clean logs ready for analysis.
    """
    tool_context.state["status"] = "preprocessing"
    # FIX: was calling undefined _post(); now correctly calls _post_run() which returns str
    return await _post_run(raw_logs)


async def filter_logs(
        clean_logs: str,
        level: str = None,
        service: str = None,
        time_range_start: str = None,
        time_range_end: str = None,
        tool_context: ToolContext = None,
) -> str:
    """
    Filter preprocessed logs by severity level, service name, or time range.

    Args:
        clean_logs: Preprocessed log content
        level: Filter by severity (ERROR, WARN, INFO, DEBUG)
        service: Filter by service name
        time_range_start: Start time (ISO format)
        time_range_end: End time (ISO format)
    """
    if tool_context:
        tool_context.state["status"] = "filtering"

    filters = []
    if level:
        filters.append(f"level:{level}")
    if service:
        filters.append(f"service:{service}")
    if time_range_start:
        filters.append(f"from:{time_range_start}")
    if time_range_end:
        filters.append(f"to:{time_range_end}")

    query = f"filter logs: {', '.join(filters)}\n\n{clean_logs[:5000]}"
    # FIX: was calling undefined _post(); now correctly calls _post_run() which returns str
    return await _post_run(query)