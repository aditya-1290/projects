# agents/adk/tools/pipeline_tool.py

import os
import httpx
from google.adk.tools import ToolContext

API_BASE = os.getenv("LOG_AGENT_API_BASE", "http://127.0.0.1:8002")


async def _call_backend_run(query: str, tool_context: ToolContext, timeout: int = 1200) -> str:
    """
    Internal helper used by all ADK tools.
    Every tool calls /run so the real orchestrator decides the pipeline.
    """

    tool_context.state["backend_api_base"] = API_BASE
    tool_context.state["last_query_preview"] = str(query)[:300]

    print("[ADK TOOL] Backend call started", flush=True)
    print(f"[ADK TOOL] API: {API_BASE}/run", flush=True)
    print(f"[ADK TOOL] Query: {str(query)[:300]}", flush=True)

    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.post(
                f"{API_BASE}/run",
                json={"query": query},
            )

        tool_context.state["last_backend_status"] = response.status_code

        if response.status_code != 200:
            error_text = response.text
            tool_context.state["last_error"] = error_text
            return f"Backend returned HTTP {response.status_code}: {error_text}"

        data = response.json()
        result = data.get("response") or str(data)

        tool_context.state["last_tool_success"] = True
        tool_context.state["last_response_preview"] = str(result)[:500]

        return result

    except httpx.ConnectError:
        error = (
            f"Could not connect to backend at {API_BASE}. "
            "Start adk_server.py first and verify LOG_AGENT_API_BASE."
        )
        tool_context.state["last_tool_success"] = False
        tool_context.state["last_error"] = error
        return error

    except httpx.TimeoutException:
        error = "Backend timed out while running the log analysis pipeline."
        tool_context.state["last_tool_success"] = False
        tool_context.state["last_error"] = error
        return error

    except Exception as e:
        error = f"Tool failed: {type(e).__name__}: {e}"
        tool_context.state["last_tool_success"] = False
        tool_context.state["last_error"] = error
        return error


async def full_pipeline(query: str, tool_context: ToolContext) -> str:
    """
    Run the complete log analysis pipeline.

    Args:
        query: Log text, file path, image path, terminal output, or question.
    """

    # FIX: tool_context is now a proper parameter, not used from thin air
    tool_context.state["selected_tool"] = "full_pipeline"

    print("[ADK TOOL] full_pipeline called", flush=True)
    print(f"[ADK TOOL] query={str(query)[:200]}", flush=True)

    return await _call_backend_run(query, tool_context)
    # FIX: Removed unreachable dead code that was after the return statement