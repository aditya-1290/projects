# agents/adk/tools/extractor_tools.py

from google.adk.tools import ToolContext
from agents.adk.tools.pipeline_tool import _call_backend_run


async def extract_file(path: str, tool_context: ToolContext) -> str:
    """
    Extract and analyze logs from a local file path.

    This tool does not manually parse the file.
    It sends the path to the full backend pipeline.
    The backend orchestrator routes it to the extractor agent.

    Args:
        path: Local file path, for example D:\\logs\\error.txt
    """

    tool_context.state["selected_tool"] = "extract_file"
    tool_context.state["file_path"] = path
    print("[ADK TOOL] extract_file called")
    return await _call_backend_run(path, tool_context)


async def extract_text(content: str, tool_context: ToolContext) -> str:
    """
    Extract and analyze pasted log text.

    Args:
        content: Raw log text.
    """

    tool_context.state["selected_tool"] = "extract_text"
    return await _call_backend_run(content, tool_context)


async def ocr_image(path: str, tool_context: ToolContext) -> str:
    """
    Extract and analyze logs from an image path using the backend pipeline.
    The backend extractor will call ImageLoader and DeepSeek OCR.

    Args:
        path: Local image path.
    """

    tool_context.state["selected_tool"] = "ocr_image"
    tool_context.state["image_path"] = path
    print("[ADK TOOL] ocr_image called")
    return await _call_backend_run(path, tool_context)


async def run_terminal(command: str, tool_context: ToolContext) -> str:
    """
    Analyze terminal command output through the backend pipeline.

    Args:
        command: Terminal command.
    """

    tool_context.state["selected_tool"] = "run_terminal"
    return await _call_backend_run(f"command:{command}", tool_context)