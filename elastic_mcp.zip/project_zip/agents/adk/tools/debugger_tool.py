"""Debugger Tools — Stack trace parsing and code patch generation."""
import os
import httpx
from google.adk.tools import ToolContext

API_BASE = os.getenv("LOG_AGENT_API_BASE", "http://127.0.0.1:8002")


async def _post_run(query: str, timeout: int = 1200) -> str:
    """Call /run on the FastAPI backend and return the response string."""
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.post(
                f"{API_BASE}/run",
                json={"query": query},
            )

        if response.status_code != 200:
            return f"Backend returned HTTP {response.status_code}: {response.text}"

        data = response.json()
        # FIX: _post_run returns a str — callers must NOT call .get() on the result
        return data.get("response") or str(data)

    except Exception as e:
        return f"Tool failed: {type(e).__name__}: {e}"


async def debug_trace(
        stack_trace: str,
        language: str = "auto",
        tool_context: ToolContext = None,
) -> str:
    """
    Parse a stack trace and generate code patches with language-specific analysis.

    Args:
        stack_trace: Full stack trace text to analyze
        language: Programming language (python, java, javascript, typescript, go, auto)
    """
    if tool_context:
        tool_context.state["status"] = "debugging"

    query = f"debug this {language} stack trace:\n\n{stack_trace[:5000]}"
    # FIX: was calling undefined _post(); now correctly calls _post_run() which returns str
    return await _post_run(query)