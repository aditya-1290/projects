from agents.adk.tools.pipeline_tool import full_pipeline
from agents.adk.tools.extractor_tools import (
    extract_file,
    extract_text,
    ocr_image,
    run_terminal,
)
from agents.adk.tools.memory_tool import (
    search_memory,
    store_analysis,
    trend_analysis,
)

ALL_TOOLS = [
    full_pipeline,
    extract_file,
    extract_text,
    ocr_image,
    run_terminal,
    search_memory,
    store_analysis,
    trend_analysis,
]