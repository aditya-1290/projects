"""Analyzer Tools — Classify logs, detect intent, assess severity."""
import os
import httpx
from google.adk.tools import ToolContext

API_BASE = os.getenv("LOG_AGENT_API_BASE", "http://127.0.0.1:8002")


async def _post_run(query: str, timeout: int = 1200) -> str:
    """Call /run on the FastAPI backend and return the response string."""
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.post(
                f"{API_BASE}/run",
                json={"query": query},
            )

        if response.status_code != 200:
            return f"Backend returned HTTP {response.status_code}: {response.text}"

        data = response.json()
        # FIX: _post_run returns a str — callers must NOT call .get() on the result
        return data.get("response") or str(data)

    except Exception as e:
        return f"Tool failed: {type(e).__name__}: {e}"


async def analyze_logs(clean_logs: str, tool_context: ToolContext) -> str:
    """
    Classify log type, detect user intent, assess severity, and identify patterns.

    Returns:
        Analysis including log_type, severity, intent, patterns, and affected components.
    """
    tool_context.state["status"] = "analyzing"
    return await _post_run(clean_logs)