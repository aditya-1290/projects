"""Solver Tools — Root cause analysis, fix generation, explanations, summaries."""
import os
import httpx
from google.adk.tools import ToolContext

API_BASE = os.getenv("LOG_AGENT_API_BASE", "http://127.0.0.1:8002")


async def _post_run(query: str, timeout: int = 1200) -> str:
    """Call /run on the FastAPI backend and return the response string."""
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.post(
                f"{API_BASE}/run",
                json={"query": query},
            )

        if response.status_code != 200:
            return f"Backend returned HTTP {response.status_code}: {response.text}"

        data = response.json()
        # FIX: _post_run returns a str — callers must NOT call .get() on the result
        return data.get("response") or str(data)

    except Exception as e:
        return f"Tool failed: {type(e).__name__}: {e}"


async def solve_error(
        clean_logs: str,
        log_type: str = "unknown",
        intent: str = "debugging",
        tool_context: ToolContext = None,
) -> str:
    """
    Find root cause and generate fix suggestions for log errors.

    Args:
        clean_logs: Preprocessed log content
        log_type: Detected log type for context
        intent: User intent (debugging, explanation, optimization, security_audit, health_check)
    """
    if tool_context:
        tool_context.state["status"] = "solving"

    query = f"solve this error (type: {log_type}, intent: {intent}):\n\n{clean_logs[:5000]}"
    # FIX: was calling undefined _post(); now correctly calls _post_run() which returns str
    return await _post_run(query)


async def explain_error(clean_logs: str, tool_context: ToolContext) -> str:
    """
    Explain what log entries mean in plain, easy-to-understand language.
    """
    tool_context.state["status"] = "explaining"
    query = f"explain this error in simple terms:\n\n{clean_logs[:5000]}"
    # FIX: was calling undefined _post(); now correctly calls _post_run() which returns str
    return await _post_run(query)


async def summarize_logs(clean_logs: str, tool_context: ToolContext) -> str:
    """
    Generate a concise summary of log entries.
    Returns overview with severity breakdown, top errors, and affected services.
    """
    tool_context.state["status"] = "summarizing"
    query = f"summarize these logs:\n\n{clean_logs[:5000]}"
    # FIX: was calling undefined _post(); now correctly calls _post_run() which returns str
    return await _post_run(query)