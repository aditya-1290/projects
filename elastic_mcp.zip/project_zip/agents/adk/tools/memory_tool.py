"""
Memory Tools — ChromaDB memory integration for ADK.

These tools allow the ADK agent to:
1. Search past log analyses from ChromaDB.
2. Store completed log analysis results.
3. Run simple trend-style memory searches.

Flow:
ADK Tool
    ↓
FastAPI endpoint
    ↓
Memory Agent
    ↓
ChromaDB
"""

import os
import json
from typing import Any, Dict, Optional

import httpx
from google.adk.tools import ToolContext


API_BASE = os.getenv("LOG_AGENT_API_BASE", "http://127.0.0.1:8002")


def _safe_json_text(data: Any) -> str:
    """Convert any Python object into readable JSON text."""
    try:
        return json.dumps(data, indent=2, default=str)
    except Exception:
        return str(data)


async def search_memory(
    query: str,
    tool_context: ToolContext,
    limit: int = 5,
    collection: str = "log_analyses",
) -> str:
    """
    Search for past log analyses similar to the current issue.

    Use this when the user asks:
    - previous similar issue
    - past error
    - search memory
    - ChromaDB logs
    - similar traceback
    - old root cause
    """

    # FIX: tool_context is now a proper parameter, safe to use
    tool_context.state["status"] = "searching_memory"
    tool_context.state["memory_query"] = query

    if not query or not query.strip():
        return "Memory search failed: query cannot be empty."

    try:
        async with httpx.AsyncClient(timeout=60.0) as client:
            response = await client.post(
                f"{API_BASE}/memory/search",
                json={
                    "query": query,
                    "limit": limit,
                    "size": limit,
                    "collection": collection,
                },
            )

        if response.status_code != 200:
            return (
                f"Memory search failed HTTP {response.status_code}:\n"
                f"{response.text[:1000]}"
            )

        data = response.json()

        return _safe_json_text(
            {
                "success": True,
                "source": "chromadb",
                "query": query,
                "collection": collection,
                "limit": limit,
                "results": data,
            }
        )

    except httpx.ConnectError:
        return (
            f"Memory search failed: cannot connect to FastAPI server at {API_BASE}. "
            "Run: python adk_server.py"
        )

    except Exception as e:
        return f"Memory search failed: {type(e).__name__}: {str(e)}"


async def store_analysis(
    log_content: str,
    tool_context: ToolContext,
    analysis: Any = "",
    log_type: str = "unknown",
    metadata: Optional[Dict[str, Any]] = None,
    collection: str = "log_analyses",
) -> str:
    """
    Store completed log analysis in ChromaDB.

    Use this after:
    - extracting logs
    - analyzing root cause
    - generating fix suggestions
    - validating solution
    """

    # FIX: tool_context is now a proper parameter
    tool_context.state["status"] = "storing_memory"
    tool_context.state["memory_collection"] = collection

    if not log_content or not str(log_content).strip():
        return "Memory store failed: log_content cannot be empty."

    if metadata is None:
        metadata = {}

    try:
        async with httpx.AsyncClient(timeout=60.0) as client:
            response = await client.post(
                f"{API_BASE}/memory/store",
                json={
                    "log_content": log_content,
                    "analysis": analysis,
                    "log_type": log_type,
                    "metadata": metadata,
                    "collection": collection,
                },
            )

        if response.status_code != 200:
            return (
                f"Memory store failed HTTP {response.status_code}:\n"
                f"{response.text[:1000]}"
            )

        data = response.json()

        return _safe_json_text(
            {
                "success": True,
                "source": "chromadb",
                "collection": collection,
                "log_type": log_type,
                "result": data,
            }
        )

    except httpx.ConnectError:
        return (
            f"Memory store failed: cannot connect to FastAPI server at {API_BASE}. "
            "Run: python adk_server.py"
        )

    except Exception as e:
        return f"Memory store failed: {type(e).__name__}: {str(e)}"


async def retrieve_similar_cases(
    query: str,
    tool_context: ToolContext,
    log_type: str = "unknown",
    limit: int = 3,
    collection: str = "log_analyses",
) -> str:
    """
    Retrieve similar historical cases from ChromaDB.

    This is similar to search_memory but optimized for log analysis context.
    """

    # FIX: tool_context passed as proper parameter now
    tool_context.state["status"] = "retrieving_similar_cases"
    tool_context.state["log_type"] = log_type

    enhanced_query = query

    if log_type and log_type != "unknown":
        enhanced_query = f"{query}\nLog type: {log_type}"

    return await search_memory(
        query=enhanced_query,
        tool_context=tool_context,
        limit=limit,
        collection=collection,
    )


async def trend_analysis(
    tool_context: ToolContext,
    error_type: str = "",
    log_type: str = "unknown",
    time_range_start: str = "",
    time_range_end: str = "",
    collection: str = "log_analyses",
) -> str:
    """
    Search memory for repeated error patterns and possible trends.

    This does not perform full statistical analytics yet.
    It retrieves relevant stored cases that can be summarized by the ADK agent.
    """

    # FIX: tool_context added as proper parameter
    tool_context.state["status"] = "analyzing_memory_trends"

    query_parts = ["trend analysis for stored log errors"]

    if error_type:
        query_parts.append(f"error type: {error_type}")

    if log_type and log_type != "unknown":
        query_parts.append(f"log type: {log_type}")

    if time_range_start:
        query_parts.append(f"from: {time_range_start}")

    if time_range_end:
        query_parts.append(f"to: {time_range_end}")

    query = " | ".join(query_parts)

    return await search_memory(
        query=query,
        tool_context=tool_context,
        limit=10,
        collection=collection,
    )