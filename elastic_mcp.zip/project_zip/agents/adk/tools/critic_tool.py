"""Critic Tools — Validate solution quality and safety."""
import os
import httpx
from google.adk.tools import ToolContext

API_BASE = os.getenv("LOG_AGENT_API_BASE", "http://127.0.0.1:8002")


async def _post_run(query: str, timeout: int = 1200) -> str:
    """Call /run on the FastAPI backend and return the response string."""
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.post(
                f"{API_BASE}/run",
                json={"query": query},
            )

        if response.status_code != 200:
            return f"Backend returned HTTP {response.status_code}: {response.text}"

        data = response.json()
        # FIX: _post_run returns a str — callers must NOT call .get() on the result
        return data.get("response") or str(data)

    except Exception as e:
        return f"Tool failed: {type(e).__name__}: {e}"


async def validate_solution(
        solution: str,
        original_logs: str = "",
        tool_context: ToolContext = None,
) -> str:
    """
    Validate a proposed solution for factual consistency, logical coherence,
    completeness, safety, and hallucinations.

    Args:
        solution: The proposed solution to validate
        original_logs: Original log content for evidence checking
    """
    if tool_context:
        tool_context.state["status"] = "validating"

    query = f"validate this solution:\n\n{solution[:3000]}\n\nOriginal logs:\n{original_logs[:3000]}"
    # FIX: was calling undefined _post(); now correctly calls _post_run() which returns str
    return await _post_run(query)