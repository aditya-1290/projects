"""
ADK Root Agent
"""

# ═══════════════════════════════════════════════════════════
# PATCH: Fix LiteLLMClient serialization bug in ADK 1.31.1
# ═══════════════════════════════════════════════════════════

import pydantic

_original_dump = pydantic.TypeAdapter.dump_json

def _patched_dump(self, obj, **kwargs):
    from google.adk.models.lite_llm import LiteLLMClient as LLC

    def _fix(v):
        if isinstance(v, LLC):
            return str(v)
        if isinstance(v, dict):
            return {kk: _fix(vv) for kk, vv in v.items()}
        if isinstance(v, list):
            return [_fix(vv) for vv in v]
        return v

    return _original_dump(self, _fix(obj), **kwargs)


pydantic.TypeAdapter.dump_json = _patched_dump
print("[ADK PATCH] Pydantic serialization patched for LiteLLMClient")


# ═══════════════════════════════════════════════════════════
# Imports
# ═══════════════════════════════════════════════════════════

import inspect
import os

from google.adk.agents import LlmAgent, Agent, BaseAgent, LoopAgent, SequentialAgent, ParallelAgent
from google.adk.models.lite_llm import LiteLlm
from google.adk.tools import BaseTool, ToolContext

from agents.adk.instructions import ORCHESTRATOR_INSTRUCTION

from agents.adk.tools.pipeline_tool import full_pipeline
from agents.adk.tools.extractor_tools import (
    extract_file,
    extract_text,
    ocr_image,
    run_terminal,
)
from agents.adk.tools.preprocessor_tool import (
    preprocess_logs,
    filter_logs,
)
from agents.adk.tools.analyzer_tool import analyze_logs
from agents.adk.tools.solver_tool import (
    solve_error,
    explain_error,
    summarize_logs,
)
from agents.adk.tools.debugger_tool import debug_trace
from agents.adk.tools.critic_tool import validate_solution
from agents.adk.tools.memory_tool import (
    search_memory,
    store_analysis,
    trend_analysis,
)


# ═══════════════════════════════════════════════════════════
# Tool Wrapper
# ═══════════════════════════════════════════════════════════

def make_tool(fn):
    sig = inspect.signature(fn)

    user_params = [
        name
        for name in sig.parameters.keys()
        if name != "tool_context"
    ]

    accepts_tool_context = "tool_context" in sig.parameters

    class SimpleTool(BaseTool):
        def __init__(self, func):
            super().__init__(
                name=func.__name__,
                description=func.__doc__ or "",
            )
            self._func = func
            self._user_params = user_params
            self._accepts_tool_context = accepts_tool_context

        async def run_async(self, *, args: dict, tool_context: ToolContext) -> str:
            filtered = {
                key: value
                for key, value in args.items()
                if key in self._user_params
            }

            if self._accepts_tool_context:
                result = self._func(
                    tool_context=tool_context,
                    **filtered,
                )
            else:
                result = self._func(**filtered)

            if inspect.isawaitable(result):
                result = await result

            return str(result)

    return SimpleTool(fn)


# ═══════════════════════════════════════════════════════════
# Tools
# FIX: All tools that the orchestrator instruction mentions are now
#      imported and registered here. Previously only a subset were
#      registered, so the agent would hallucinate calling tools that
#      didn't exist at runtime.
# ═══════════════════════════════════════════════════════════

TOOLS = [
    # Full pipeline (primary entry-point)
    make_tool(full_pipeline),

    # Extraction
    make_tool(extract_file),
    make_tool(extract_text),
    make_tool(ocr_image),
    make_tool(run_terminal),

    # Preprocessing
    make_tool(preprocess_logs),
    make_tool(filter_logs),

    # Analysis
    make_tool(analyze_logs),

    # Solving
    make_tool(solve_error),
    make_tool(explain_error),
    make_tool(summarize_logs),

    # Debugging
    make_tool(debug_trace),

    # Validation
    make_tool(validate_solution),

    # Memory
    make_tool(search_memory),
    make_tool(store_analysis),
    make_tool(trend_analysis),
]


# ═══════════════════════════════════════════════════════════
# Root Agent
# ═══════════════════════════════════════════════════════════

root_agent = LlmAgent(
    name="log_analysis_orchestrator",
    description=(
        "Multi-agent log analysis system for analyzing logs from pasted text, "
        "files, terminal output, Elastic Cloud, JSON logs, and ChromaDB memory."
    ),
    model=LiteLlm(
        model=os.getenv("ADK_MODEL", "openai/qwen2.5-3b-instruct"),
        api_base=os.getenv("ADK_MODEL_API_BASE", "http://127.0.0.1:8083/v1"),
        api_key=os.getenv("ADK_MODEL_API_KEY", "not-needed"),
    ),
    instruction=ORCHESTRATOR_INSTRUCTION,
    tools=TOOLS,
)


APP_NAME = "log_analysis_final"
USER_ID = "ui_user"

session_service = InMemorySessionService()

runner = Runner(
    agent=root_agent,
    app_name=APP_NAME,
    session_service=session_service,
)


async def run_root_agent(query: str, session_id: str) -> str:
    try:
        await session_service.create_session(
            app_name=APP_NAME,
            user_id=USER_ID,
            session_id=session_id,
        )
    except Exception:
        pass

    message = f"""
SESSION_ID: {session_id}

USER_QUERY:
{query}
"""

    content = types.Content(
        role="user",
        parts=[types.Part(text=message)]
    )

    final_text = ""

    async for event in runner.run_async(
        user_id=USER_ID,
        session_id=session_id,
        new_message=content,
    ):
        if event.is_final_response():
            if event.content and event.content.parts:
                final_text = event.content.parts[0].text

    return final_text or "No response from root agent."
