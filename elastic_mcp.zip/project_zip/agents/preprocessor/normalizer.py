"""
Log Normalizer - Normalizes timestamps, IPs, levels, and guarantees
a downstream-safe text content field.

Important:
    Analyzer and solver agents require clean_logs/content to be non-empty.
    This normalizer always returns:
        - content
        - clean_logs
        - entries
        - normalization_stats
"""

import re
import json
from typing import Dict, List, Any, Optional
from datetime import datetime


class LogNormalizer:
    """Normalizes log entries for consistent processing."""

    IP_PATTERN = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")

    UUID_PATTERN = re.compile(
        r"\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b",
        re.IGNORECASE,
    )

    TIMESTAMP_FORMATS = [
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d %H:%M:%S.%f",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%dT%H:%M:%S.%f",
        "%Y/%m/%d %H:%M:%S",
        "%d/%b/%Y:%H:%M:%S %z",
        "%b %d %H:%M:%S",
        "%d-%m-%Y %H:%M:%S",
    ]

    async def normalize(self, parsed_logs: Dict) -> Dict:
        """
        Normalize parsed logs.

        This method is defensive:
        - handles entries list
        - handles raw string content
        - handles parsed JSON dict/list
        - guarantees content and clean_logs are not lost
        """

        if not isinstance(parsed_logs, dict):
            text = self._safe_to_text(parsed_logs)
            return {
                "entries": [],
                "content": text,
                "clean_logs": text,
                "normalized": True,
                "format_detected": "text",
                "normalization_stats": {
                    "timestamps_normalized": 0,
                    "ips_normalized": 0,
                    "levels_normalized": 0,
                },
            }

        entries = parsed_logs.get("entries") or []

        original_content = (
            parsed_logs.get("content")
            or parsed_logs.get("clean_logs")
            or parsed_logs.get("raw_logs")
            or parsed_logs.get("text")
            or ""
        )

        # If parser stored JSON data under another key, preserve it as text.
        json_like_data = (
            parsed_logs.get("data")
            or parsed_logs.get("records")
            or parsed_logs.get("logs")
            or parsed_logs.get("events")
            or None
        )

        normalized_entries = []
        stats = {
            "timestamps_normalized": 0,
            "ips_normalized": 0,
            "levels_normalized": 0,
        }

        for entry in entries:
            if not isinstance(entry, dict):
                normalized_entries.append({"message": str(entry)})
                continue

            normalized = entry.copy()

            # Normalize timestamp
            if entry.get("timestamp"):
                normalized["timestamp_iso"] = self._normalize_timestamp(
                    str(entry["timestamp"])
                )
                if normalized["timestamp_iso"]:
                    stats["timestamps_normalized"] += 1

            # Normalize IP addresses in message
            message = str(entry.get("message") or entry.get("msg") or "")
            if message:
                ips = self.IP_PATTERN.findall(message)
                if ips:
                    normalized["ip_addresses"] = ips
                    normalized["has_local_ip"] = any(
                        ip.startswith(
                            (
                                "10.","172.16.","172.17.","172.18.","172.19.",
                                "172.20.","172.21.","172.22.","172.23.",
                                "172.24.","172.25.","172.26.","172.27.",
                                "172.28.","172.29.","172.30.","172.31.",
                                "192.168.","127.",
                            )
                        )
                        for ip in ips
                    )
                    stats["ips_normalized"] += 1

                uuids = self.UUID_PATTERN.findall(message)
                if uuids:
                    normalized["uuids"] = uuids

            # Normalize log level
            level = entry.get("level") or entry.get("severity")
            if level:
                normalized["level_normalized"] = self._normalize_level(str(level))
                stats["levels_normalized"] += 1

            normalized_entries.append(normalized)

        # Build final text content safely.
        content = ""

        if normalized_entries:
            content = self._entries_to_text(normalized_entries)

        if not content.strip() and original_content:
            content = self._safe_to_text(original_content)

        if not content.strip() and json_like_data is not None:
            content = self._json_to_log_text(json_like_data)

        if not content.strip():
            content = self._json_to_log_text(parsed_logs)

        result = parsed_logs.copy()
        result["entries"] = normalized_entries
        result["content"] = content
        result["clean_logs"] = content
        result["normalization_stats"] = stats
        result["normalized"] = True

        if "format_detected" not in result:
            result["format_detected"] = parsed_logs.get("format", "text")

        return result

    def _entries_to_text(self, entries: List[Dict[str, Any]]) -> str:
        """Convert normalized entries back to readable log text."""
        lines = []

        for entry in entries:
            if not isinstance(entry, dict):
                lines.append(str(entry))
                continue

            timestamp = (
                entry.get("timestamp_iso")
                or entry.get("timestamp")
                or entry.get("@timestamp")
                or entry.get("time")
                or ""
            )

            level = (
                entry.get("level_normalized")
                or entry.get("level")
                or entry.get("severity")
                or ""
            )

            service = (
                entry.get("service")
                or entry.get("component")
                or entry.get("logger")
                or entry.get("module")
                or ""
            )

            message = (
                entry.get("message")
                or entry.get("msg")
                or entry.get("error")
                or entry.get("event")
                or entry.get("description")
                or ""
            )

            if not message:
                message = json.dumps(entry, ensure_ascii=False)

            line = " ".join(
                str(part).strip()
                for part in [timestamp, level, service, message]
                if str(part).strip()
            )

            lines.append(line)

        return "\n".join(line for line in lines if line.strip())

    def _json_to_log_text(self, data: Any) -> str:
        """Convert JSON-like data into readable log text."""
        if data is None:
            return ""

        if isinstance(data, str):
            return data

        if isinstance(data, list):
            lines = []
            for item in data:
                if isinstance(item, dict):
                    timestamp = (
                        item.get("timestamp")
                        or item.get("@timestamp")
                        or item.get("time")
                        or item.get("created_at")
                        or ""
                    )
                    level = (
                        item.get("level")
                        or item.get("severity")
                        or item.get("status")
                        or ""
                    )
                    message = (
                        item.get("message")
                        or item.get("msg")
                        or item.get("error")
                        or item.get("event")
                        or item.get("description")
                        or json.dumps(item, ensure_ascii=False)
                    )

                    lines.append(
                        " ".join(
                            str(part).strip()
                            for part in [timestamp, level, message]
                            if str(part).strip()
                        )
                    )
                else:
                    lines.append(str(item))

            return "\n".join(line for line in lines if line.strip())

        if isinstance(data, dict):
            for key in [
                "logs","events","items",
                "records","data","entries","results",
            ]:
                if key in data:
                    text = self._json_to_log_text(data[key])
                    if text.strip():
                        return text

            return json.dumps(data, indent=2, ensure_ascii=False)

        return str(data)

    def _safe_to_text(self, value: Any) -> str:
        """Safely convert any value to text."""
        if value is None:
            return ""

        if isinstance(value, str):
            return value

        try:
            return json.dumps(value, indent=2, ensure_ascii=False)
        except Exception:
            return str(value)

    def _normalize_timestamp(self, timestamp: str) -> Optional[str]:
        """Convert timestamp to ISO 8601 format."""
        if not timestamp:
            return None

        timestamp = timestamp.strip()

        for fmt in self.TIMESTAMP_FORMATS:
            try:
                dt = datetime.strptime(timestamp, fmt)
                return dt.isoformat()
            except ValueError:
                continue

        try:
            ts_clean = re.sub(r"\s*[A-Z]{3,4}$", "", timestamp)
            for fmt in self.TIMESTAMP_FORMATS:
                try:
                    dt = datetime.strptime(ts_clean.strip(), fmt)
                    return dt.isoformat()
                except ValueError:
                    continue
        except Exception:
            pass

        return None

    def _normalize_level(self, level: str) -> str:
        """Normalize log level to standard format."""
        level_upper = level.upper().strip()

        level_map = {
            "DEBUG": "DEBUG",
            "INFO": "INFO",
            "INFORMATION": "INFO",
            "WARN": "WARNING",
            "WARNING": "WARNING",
            "ERROR": "ERROR",
            "ERR": "ERROR",
            "CRIT": "CRITICAL",
            "CRITICAL": "CRITICAL",
            "FATAL": "FATAL",
            "TRACE": "TRACE",
            "NOTICE": "NOTICE",
            "EMERG": "EMERGENCY",
            "EMERGENCY": "EMERGENCY",
            "ALERT": "ALERT",
        }

        return level_map.get(level_upper, level_upper)