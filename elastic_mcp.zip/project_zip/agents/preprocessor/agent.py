"""
Preprocessor Agent

Uses Qwen2.5-3B for intelligent log cleaning, parsing, normalization,
and safe chunking.

This is the second step in the pipeline after extraction.

Important:
    This version is defensive for large logs and JSON logs.
    It guarantees clean_logs is not lost after parsing/normalization.
"""

from typing import Dict, Any, List

from agents.base_agent import BaseAgent, A2AMessage, MessageType


MAX_ANALYZER_CHARS = 30000
CHUNK_SIZE_CHARS = 12000


class PreprocessorAgent(BaseAgent):
    """Cleans, parses, normalizes, and chunks raw logs."""

    def __init__(self):
        super().__init__("preprocessor_v1", "agents/preprocessor/capabilities.json")

    # ═══════════════════════════════════════════════════════════════════════════
    # ADK Integration — Tool Registration
    # ═══════════════════════════════════════════════════════════════════════════

    def _get_model_requirements(self) -> list:
        return ["qwen2.5-3b-it"]

    def _resolve_adk_model(self) -> str:
        return "qwen2.5-3b-it"

    def _get_adk_tools(self) -> list:
        """Register log cleaning, parsing, and normalization as ADK tools."""
        return [
            {
                "name": "clean_and_structure_logs",
                "description": (
                    "Clean raw logs by removing noise, parsing into structured "
                    "format, normalizing timestamps and IPs, and chunking if needed."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "raw_logs": {
                            "type": "string",
                            "description": "Raw log content to preprocess",
                        },
                        "options": {
                            "type": "object",
                            "description": "Processing options",
                            "properties": {
                                "clean": {"type": "boolean", "default": True},
                                "parse": {"type": "boolean", "default": True},
                                "normalize": {"type": "boolean", "default": True},
                                "chunk": {"type": "boolean", "default": True},
                            },
                        },
                    },
                    "required": ["raw_logs"],
                },
            },
            {
                "name": "detect_log_format",
                "description": (
                    "Auto-detect the log format from content. "
                    "Returns format name and confidence."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "content": {
                            "type": "string",
                            "description": "Log content sample to analyze",
                        }
                    },
                    "required": ["content"],
                },
            },
        ]

    def _build_adk_instruction(self) -> str:
        """Build the preprocessor's ADK instruction."""
        return """You are the Preprocessor Agent for a log analysis system.

Your job is to prepare raw logs for analysis by other agents.

TOOLS AVAILABLE:
- clean_and_structure_logs: Full preprocessing pipeline
- detect_log_format: Identify the log format from content

PROCESSING STEPS:
1. CLEAN: Remove noise but preserve errors and stack traces.
2. PARSE: Structure unstructured logs.
3. NORMALIZE: Standardize timestamps, IPs, levels, and fields.
4. CHUNK: Split large logs into safe chunks.

Always preserve:
- Exact error messages
- Stack traces
- Original timestamps
- Service/component names
- Severity levels
"""

    async def process(self, message: A2AMessage) -> A2AMessage:
        """
        Process raw logs through the preprocessing pipeline:
        1. Clean noise
        2. Parse structure
        3. Normalize
        4. Chunk safely
        """
        task = message.task or {}
        context = message.context or {}

        raw_logs = self._extract_raw_logs(task, context)

        if not raw_logs or not str(raw_logs).strip():
            self.log("No raw logs provided - returning empty result")
            return A2AMessage(
                message_type=MessageType.RESPONSE,
                sender_id=self.agent_id,
                sender_type="preprocessor",
                target_id=message.sender_id,
                correlation_id=message.message_id,
                response={
                    "raw_logs": "",
                    "clean_logs": "",
                    "normalized_logs": "",
                    "chunks": [],
                    "is_chunked": False,
                    "chunk_count": 0,
                    "warning": "No logs to preprocess - extraction may have failed",
                },
                confidence=0.0,
                caveats=["Extraction step did not provide any logs to process"],
            )

        raw_logs = str(raw_logs)
        self.log(f"Preprocessing {len(raw_logs)} characters of logs")

        try:
            # Step 1: Clean
            self.log("Step 1/4: Cleaning logs...")
            cleaned_logs = await self._clean(raw_logs)

            cleaned_logs = self._ensure_text(cleaned_logs)

            # Emergency fallback after cleaning
            if not cleaned_logs.strip() and raw_logs.strip():
                self.log(
                    "Cleaner returned empty output; falling back to raw logs",
                    "WARNING",
                )
                cleaned_logs = raw_logs

            # Step 2: Parse
            self.log("Step 2/4: Parsing structure...")
            parsed_logs = await self._parse(cleaned_logs)

            if not isinstance(parsed_logs, dict):
                parsed_logs = {
                    "content": cleaned_logs,
                    "entries": [],
                    "format_detected": "text",
                }

            # Preserve content for normalizer/chunker
            parsed_logs.setdefault("content", cleaned_logs)
            parsed_logs.setdefault("clean_logs", cleaned_logs)
            parsed_logs.setdefault("raw_logs", raw_logs)

            # Step 3: Normalize
            self.log("Step 3/4: Normalizing...")
            normalized_logs = await self._normalize(parsed_logs)

            if not isinstance(normalized_logs, dict):
                normalized_logs = {
                    "content": self._ensure_text(normalized_logs),
                    "clean_logs": self._ensure_text(normalized_logs),
                    "raw_logs": raw_logs,
                }

            # Guarantee text exists after normalization
            final_content = (
                normalized_logs.get("content")
                or normalized_logs.get("clean_logs")
                or normalized_logs.get("normalized_logs")
                or cleaned_logs
                or raw_logs
                or ""
            )

            final_content = self._ensure_text(final_content)

            if not final_content.strip() and raw_logs.strip():
                self.log(
                    "Normalizer returned empty content; falling back to raw logs",
                    "WARNING",
                )
                final_content = raw_logs

            normalized_logs["content"] = final_content
            normalized_logs["clean_logs"] = final_content
            normalized_logs["raw_logs"] = raw_logs

            # Step 4: Chunk if needed
            self.log("Step 4/4: Checking if chunking needed...")
            result = await self._chunk_if_needed(normalized_logs)

            result_content = (
                result.get("content")
                or result.get("clean_logs")
                or final_content
                or raw_logs
                or ""
            )
            result_content = self._ensure_text(result_content)

            chunks = result.get("chunks") or []

            # Emergency fallback after chunking
            if not chunks and result_content.strip():
                chunks = self._safe_chunk_logs(result_content, CHUNK_SIZE_CHARS)

            if not chunks and raw_logs.strip():
                result_content = raw_logs
                chunks = self._safe_chunk_logs(raw_logs, CHUNK_SIZE_CHARS)

            chunks = [chunk for chunk in chunks if str(chunk).strip()]

            total_length = sum(len(str(chunk)) for chunk in chunks)

            # If chunker returned empty chunks but content exists
            if total_length == 0 and result_content.strip():
                chunks = self._safe_chunk_logs(result_content, CHUNK_SIZE_CHARS)
                total_length = sum(len(str(chunk)) for chunk in chunks)

            # Analyzer-safe content
            analysis_content = result_content
            truncated_for_analysis = False

            if len(analysis_content) > MAX_ANALYZER_CHARS:
                analysis_content = analysis_content[:MAX_ANALYZER_CHARS]
                truncated_for_analysis = True

            self.log(
                f"Preprocessing complete: {len(chunks)} chunks, "
                f"{total_length} chars total"
            )

            return A2AMessage(
                message_type=MessageType.RESPONSE,
                sender_id=self.agent_id,
                sender_type="preprocessor",
                target_id=message.sender_id,
                correlation_id=message.message_id,
                response={
                    "raw_logs": raw_logs,
                    "clean_logs": analysis_content,
                    "normalized_logs": result_content,
                    "full_clean_logs": result_content,
                    "chunks": chunks,
                    "is_chunked": len(chunks) > 1,
                    "chunk_count": len(chunks),
                    "original_length": len(raw_logs),
                    "cleaned_length": len(result_content),
                    "total_length": total_length,
                    "full_log_chars": len(result_content),
                    "truncated_for_analysis": truncated_for_analysis,
                    "format_detected": (
                        result.get("format")
                        or normalized_logs.get("format_detected")
                        or normalized_logs.get("format")
                        or "text"
                    ),
                    "noise_removed_lines": result.get("noise_removed", 0),
                    "preprocessor_warning": (
                        "Log content was truncated for analyzer context window"
                        if truncated_for_analysis
                        else ""
                    ),
                },
                confidence=0.9 if analysis_content.strip() else 0.0,
                context=message.context,
            )

        except Exception as e:
            self.log(f"Error: {e}", "ERROR")

            # Last-resort fallback: do not kill the whole pipeline if raw logs exist.
            if raw_logs.strip():
                chunks = self._safe_chunk_logs(raw_logs, CHUNK_SIZE_CHARS)
                analysis_content = raw_logs[:MAX_ANALYZER_CHARS]

                return A2AMessage(
                    message_type=MessageType.RESPONSE,
                    sender_id=self.agent_id,
                    sender_type="preprocessor",
                    target_id=message.sender_id,
                    correlation_id=message.message_id,
                    response={
                        "raw_logs": raw_logs,
                        "clean_logs": analysis_content,
                        "normalized_logs": raw_logs,
                        "full_clean_logs": raw_logs,
                        "chunks": chunks,
                        "is_chunked": len(chunks) > 1,
                        "chunk_count": len(chunks),
                        "original_length": len(raw_logs),
                        "cleaned_length": len(raw_logs),
                        "total_length": len(raw_logs),
                        "format_detected": "text",
                        "warning": f"Preprocessing partially failed, raw fallback used: {str(e)}",
                    },
                    confidence=0.5,
                    caveats=["Preprocessor fallback used raw logs due to error"],
                )

            return A2AMessage(
                message_type=MessageType.ERROR,
                sender_id=self.agent_id,
                sender_type="preprocessor",
                target_id=message.sender_id,
                correlation_id=message.message_id,
                error=f"Preprocessing failed: {str(e)}",
            )

    def _extract_raw_logs(self, task: Dict[str, Any], context: Dict[str, Any]) -> str:
        """Extract raw logs from task/context using multiple fallback keys."""
        previous_results = context.get("previous_results", {}) or {}

        subtask_0_response = (
            previous_results.get("subtask_0", {}).get("response", {})
            if isinstance(previous_results, dict)
            else {}
        )

        raw_logs = (
            task.get("raw_logs")
            or task.get("content")
            or task.get("logs")
            or context.get("raw_logs")
            or context.get("clean_logs")
            or context.get("content")
            or context.get("logs")
            or subtask_0_response.get("raw_logs")
            or subtask_0_response.get("content")
            or subtask_0_response.get("clean_logs")
            or ""
        )

        return self._ensure_text(raw_logs)

    def _ensure_text(self, value: Any) -> str:
        """Convert returned values into text safely."""
        if value is None:
            return ""

        if isinstance(value, str):
            return value

        if isinstance(value, list):
            return "\n".join(str(item) for item in value)

        if isinstance(value, dict):
            import json

            for key in [
                "content",
                "clean_logs",
                "raw_logs",
                "message",
                "text",
                "logs",
                "entries",
            ]:
                if key in value and value[key]:
                    inner = value[key]
                    if isinstance(inner, str):
                        return inner
                    try:
                        return json.dumps(inner, indent=2, ensure_ascii=False)
                    except Exception:
                        return str(inner)

            try:
                return json.dumps(value, indent=2, ensure_ascii=False)
            except Exception:
                return str(value)

        return str(value)

    def _safe_chunk_logs(self, text: str, max_chars: int = CHUNK_SIZE_CHARS) -> List[str]:
        """Chunk logs without creating empty chunks."""
        text = text or ""

        if not text.strip():
            return []

        chunks = []
        current = []
        current_size = 0

        for line in text.splitlines():
            line = str(line)
            line_size = len(line) + 1

            if current_size + line_size > max_chars and current:
                chunk = "\n".join(current).strip()
                if chunk:
                    chunks.append(chunk)
                current = []
                current_size = 0

            current.append(line)
            current_size += line_size

        if current:
            chunk = "\n".join(current).strip()
            if chunk:
                chunks.append(chunk)

        return chunks

    async def _clean(self, raw_logs: str) -> str:
        """Remove noise from raw logs."""
        from agents.preprocessor.cleaner import LogCleaner

        cleaner = LogCleaner()

        # For large logs, avoid LLM cleaning. Regex-only is safer and faster.
        if len(raw_logs) > 50000:
            return await cleaner.clean(raw_logs, model=None)

        if len(raw_logs) < 500:
            return await cleaner.clean(raw_logs, model=None)

        try:
            model = await self.get_model("qwen_small")
            return await cleaner.clean(raw_logs, model=model)
        except Exception:
            return await cleaner.clean(raw_logs, model=None)

    async def _parse(self, cleaned_logs: str) -> Dict:
        """Parse cleaned logs into structured format."""
        from agents.preprocessor.parser import LogParser

        parser = LogParser()

        # For large logs, avoid LLM parsing. Regex/parser-only is safer.
        if len(cleaned_logs) > 50000:
            return await parser.parse(cleaned_logs, model=None)

        if len(cleaned_logs) < 500:
            return await parser.parse(cleaned_logs, model=None)

        try:
            model = await self.get_model("qwen_small")
            return await parser.parse(cleaned_logs, model=model)
        except Exception:
            return await parser.parse(cleaned_logs, model=None)

    async def _normalize(self, parsed_logs: Dict) -> Dict:
        """Normalize timestamps, IPs, and other fields."""
        from agents.preprocessor.normalizer import LogNormalizer

        normalizer = LogNormalizer()
        return await normalizer.normalize(parsed_logs)

    async def _chunk_if_needed(self, normalized_logs: Dict) -> Dict:
        """
        Chunk large logs for processing.

        This method first tries your existing LogChunker.
        If LogChunker returns empty content/chunks, it falls back to safe chunking.
        """
        from agents.preprocessor.chunker import LogChunker

        chunker = LogChunker()

        content = (
            normalized_logs.get("content")
            or normalized_logs.get("clean_logs")
            or normalized_logs.get("raw_logs")
            or ""
        )

        content = self._ensure_text(content)

        if not content.strip():
            return {
                "content": "",
                "clean_logs": "",
                "chunks": [],
                "is_chunked": False,
                "chunk_count": 0,
                "total_length": 0,
                "format": normalized_logs.get("format_detected", "text"),
                "noise_removed": normalized_logs.get("noise_removed", 0),
            }

        normalized_logs["content"] = content
        normalized_logs["clean_logs"] = content

        try:
            # Avoid LLM chunking for large logs.
            if len(content) > 50000:
                raise RuntimeError("Large log detected; using safe regex chunking")

            model = None
            if len(content) >= 500:
                try:
                    model = await self.get_model("qwen_small")
                except Exception:
                    model = None

            result = await chunker.chunk(normalized_logs, model=model)

            if isinstance(result, dict):
                result_content = (
                    result.get("content")
                    or result.get("clean_logs")
                    or content
                )

                chunks = result.get("chunks") or []

                if not chunks and result_content.strip():
                    chunks = self._safe_chunk_logs(result_content, CHUNK_SIZE_CHARS)

                chunks = [str(chunk) for chunk in chunks if str(chunk).strip()]

                if not result_content.strip() and content.strip():
                    result_content = content

                total_length = sum(len(chunk) for chunk in chunks)

                if total_length == 0 and result_content.strip():
                    chunks = self._safe_chunk_logs(result_content, CHUNK_SIZE_CHARS)
                    total_length = sum(len(chunk) for chunk in chunks)

                result["content"] = result_content
                result["clean_logs"] = result_content
                result["chunks"] = chunks
                result["is_chunked"] = len(chunks) > 1
                result["chunk_count"] = len(chunks)
                result["total_length"] = total_length
                result.setdefault("format", normalized_logs.get("format_detected", "text"))

                return result

        except Exception as e:
            self.log(f"Chunker fallback triggered: {e}", "DEBUG")

        chunks = self._safe_chunk_logs(content, CHUNK_SIZE_CHARS)

        return {
            "content": content,
            "clean_logs": content,
            "chunks": chunks,
            "is_chunked": len(chunks) > 1,
            "chunk_count": len(chunks),
            "total_length": sum(len(chunk) for chunk in chunks),
            "format": normalized_logs.get("format_detected", "text"),
            "noise_removed": normalized_logs.get("noise_removed", 0),
        }