"""
Orchestrator Agent

The first point of contact for users. Decomposes queries, discovers
capable agents, coordinates the pipeline, and aggregates results.

Uses Gemma-4-E4B for intelligent task decomposition.

IMPORTANT: This agent NEVER imports other agents directly.
All communication happens through the Communication Bus via A2A messages.
"""

import asyncio
from typing import Dict, List, Any, Optional
from datetime import datetime
import os
import re

from agentos.mcp_tool_client import MCPToolClient

from agents.orchestrator.approval_gate import ApprovalGate
from utils.tracing import trace_pipeline_stage
from agents.orchestrator.input_detector import detect_input
from agents.base_agent import BaseAgent, A2AMessage, MessageType, AgentState
from agents.orchestrator.prompts import (
            SKILL_TASK_DECOMPOSITION,
            SKILL_AGENT_SELECTION,
            SKILL_PIPELINE_PLANNING,
            SKILL_EDGE_CASE_DETECTION,
            SKILL_SCOPE_VALIDATION,
            SKILL_RESULT_AGGREGATION,
        )

from pydantic import BaseModel, Field

CONFIDENCE_APPROVAL_THRESHOLD = 0.70

class OrchestratorOutput(BaseModel):
    response: str = Field(description="Final log analysis response")
    pipeline_stages: list[str] = Field(default_factory=list, description="Pipeline stages completed")
    confidence: float = Field(default=0.0, description="Overall confidence score between 0 and 1")

def _merge_results(results):
    """
    Flatten previous agent outputs into context
    """
    merged = {}

    for key, step in results.items():   # ✅ FIX HERE
        if not step or not isinstance(step, dict):
            continue

        response = step.get("response", {})
        if isinstance(response, dict):
            merged.update(response)

    return merged


class OrchestratorAgent(BaseAgent):
    """
    ADK-powered Central coordinator for the multi-agent system.

    ALL inter-agent communication goes through the Communication Bus.
    This agent discovers other agents by querying the bus, not by importing them.

    ADK Integration:
    - Exposes as an ADK LlmAgent with sub-agents for solver, debugger, critic
    - Supports streaming responses
    - Maintains session state across multi-turn conversations
    """

    def __init__(self):
        super().__init__("orchestrator_v1", "agents/orchestrator/capabilities.json")
        self.planner = None
        self.router = None
        self.execution_history: List[Dict] = []
        self._adk_agent = None
        self._adk_sub_agents = {}
        self._session_store: Dict[str, List[Dict]] = {}  # NEW: session state
        self._current_session_id: Optional[str] = None
        self._pending_approvals: Dict[str, Dict[str, Any]] = {}
        self.approval_gate = ApprovalGate(auto_approve_threshold=0.95)
        self.mcp_client = MCPToolClient()

    async def initialize(self):
        """Initialize planner and router - no agent imports needed"""
        from agents.orchestrator.planner import TaskPlanner
        from agents.orchestrator.router import AgentRouter

        self.planner = TaskPlanner()
        self.router = AgentRouter(self.comm_bus)
        self.log("Orchestrator initialized")

    # �══════════════════════════════════════════════════════════════════════════
    # ADK Integration — Full LlmAgent Conversion
    # ═══════════════════════════════════════════════════════════════════════════

    @property
    def adk_card(self) -> "ADKAgentCard":
        """ADK agent card for the orchestrator."""
        from agents.base_agent import ADKAgentCard
        # from agents.orchestrator.prompts import SKILL_TASK_DECOMPOSITION

        return ADKAgentCard(
            name=self.capability.agent_name,
            description="Orchestrates multi-agent log analysis pipeline",
            capabilities=self.capability.capabilities,
            input_schema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Log entries, file path, or question to analyze"
                    }
                },
                "required": ["query"]
            },
            output_schema={
                "type": "object",
                "properties": {
                    "response": {"type": "string", "description": "Analysis results"},
                    "pipeline_stages": {"type": "array", "description": "Stages completed"},
                    "confidence": {"type": "number", "description": "Overall confidence"}
                }
            },
            model_requirements=["gemma-4-e4b-it"],
            agent_type="orchestrator",
        )

    def _get_model_requirements(self) -> List[str]:
        return ["gemma-4-e4b-it"]

    def _resolve_adk_model(self) -> str:
        return "gemma-4-e4b-it"

    def _build_adk_instruction(self) -> str:
        """Build comprehensive ADK instruction from skill prompts."""

        return f"""
    You are the Orchestrator Agent for a log analysis multi-agent system.

    Your responsibilities:
    1. Detect the type of log input: file path, pasted text, terminal command, image, ElasticSearch query, JSON log query, or ChromaDB memory query.
    2. Decompose complex queries into subtasks.
    3. Route tasks to the appropriate specialized agents.
    4. Aggregate results into a clear final response.
    5. Use MCP-backed retrieval when logs need to be searched from Elastic Cloud, local JSON logs, or ChromaDB.

    Casual conversation rule:
    - If the user says hello, hi, hey, thanks, or asks a casual greeting, respond normally.
    - Do not call tools for casual greetings.

    MCP log retrieval rules:
    - Use elastic:<query> when the user asks for Elastic Cloud logs.
    - Use json:<query> when the user asks for local JSON logs.
    - Use chromadb:<query> or memory:<query> when the user asks for previous/similar/past issues.
    - Use mcp:<query> when the user asks for recent/latest logs and the source is unclear.

    Examples:
    User: show latest errors from elastic
    Use: elastic:error OR exception OR traceback

    User: find similar previous timeout issue
    Use: chromadb:similar previous timeout issue

    User: check local json logs for database error
    Use: json:database error

    User: analyze latest logs
    Use: mcp:latest logs error exception

    Pipeline stages you can delegate:
    - extract: Extract logs from files, images, terminal output, pasted text, Elastic Cloud, JSON, or ChromaDB.
    - preprocess: Clean, parse, normalize, and chunk raw logs.
    - analyze: Classify log type, detect user intent, assess severity.
    - solve: Perform root cause analysis and generate fix suggestions.
    - debug: Parse stack traces and generate code patches.
    - validate: Check solution quality, factual consistency, and safety.

    Available agents:
    - extractor: Handles file I/O, image OCR, terminal commands, and raw log extraction.
    - preprocessor: Cleans and structures raw logs.
    - analyzer: Classifies logs and detects patterns.
    - solver: Root cause analysis and fix generation.
    - debugger: Code-level debugging and patch generation.
    - critic: Validates solutions and detects hallucinations.
    - memory: Stores and retrieves past analyses using ChromaDB.

    Task decomposition guide:
    {SKILL_TASK_DECOMPOSITION}

    Agent selection guide:
    {SKILL_AGENT_SELECTION}

    Pipeline planning guide:
    {SKILL_PIPELINE_PLANNING}

    Edge case guide:
    {SKILL_EDGE_CASE_DETECTION}

    Scope validation guide:
    {SKILL_SCOPE_VALIDATION}

    Result aggregation guide:
    {SKILL_RESULT_AGGREGATION}

    Always respond using this structure:
    - What was detected
    - Which stages/agents were used
    - Root cause or key finding
    - Recommended fix or next step
    - Confidence score
    """

    def create_adk_agent(self, model: str = None, instruction: str = None):
        """
        Create the ADK LlmAgent for the orchestrator with sub-agents.

        This creates a fully functional ADK agent that can:
        - Accept user queries
        - Delegate to solver, debugger, critic as sub-agents
        - Stream responses
        - Maintain session state
        """
        try:
            from google.adk.agents import LlmAgent
        except ImportError:
            raise ImportError(
                "google-adk is required for ADK integration. "
                "Install with: pip install google-adk"
            )

        if self._adk_agent is not None:
            return self._adk_agent

        # Build sub-agents (solver, debugger, critic)
        sub_agents = self._build_adk_sub_agents()

        # Build the ADK orchestrator
        from google.genai.types import GenerationConfig  # new import

        self._adk_agent = LlmAgent(
            name=self.capability.agent_name,
            description="Orchestrates multi-agent log analysis with specialized sub-agents",
            model=model or self._resolve_adk_model(),
            instruction=instruction or self._build_adk_instruction(),
            sub_agents=sub_agents,
            output_schema=self.adk_card.output_schema,
            before_agent_callback=self._adk_before_callback,
            after_agent_callback=self._adk_after_callback,
            generation_config=GenerationConfig(
                temperature=0.7,
                max_output_tokens=16384,  # <-- allow full reports
            ),
        )

        self.log("ADK orchestrator agent created with sub-agents: " +
                 ", ".join(a.name for a in sub_agents))

        return self._adk_agent

    def _build_adk_sub_agents(self) -> List:
        """
        Build ADK sub-agents from the bus-registered agents.

        This dynamically discovers agents from the communication bus
        and wraps them as ADK LlmAgents.
        """
        sub_agents = []

        # The sub-agents we want to expose via ADK
        adk_agent_types = ["solver", "debugger", "critic", "memory"]

        if self.comm_bus:
            for agent_type in adk_agent_types:
                try:
                    agent = self._get_bus_agent(agent_type)
                    if agent:
                        adk_sub = agent.create_adk_agent()
                        if adk_sub:
                            sub_agents.append(adk_sub)
                            self._adk_sub_agents[agent_type] = adk_sub
                            self.log(f"  ↳ Registered ADK sub-agent: {agent_type}")
                except Exception as e:
                    self.log(f"  ↳ Could not create ADK sub-agent for {agent_type}: {e}")

        return sub_agents

    def _get_bus_agent(self, agent_type: str) -> Optional[BaseAgent]:
        """Get a registered agent from the communication bus by ID or capability name."""
        if not self.comm_bus:
            return None

        target = str(agent_type or "").lower().strip()

        for agent_id, agent in self.comm_bus.agents.items():
            if str(agent_id).lower().strip() == target:
                return agent

            capability = getattr(agent, "capability", None)
            capability_name = str(getattr(capability, "agent_name", "") or "").lower().strip()

            if capability_name == target:
                return agent

            if target in capability_name:
                return agent

        return None

    # ═══════════════════════════════════════════════════════════════════════════
    # ADK Callbacks
    # ═══════════════════════════════════════════════════════════════════════════

    async def _adk_before_callback(self, context, request=None) -> Optional[Any]:
        """ADK callback: before processing."""
        self.state = AgentState.PROCESSING
        self.log(f"ADK orchestrator processing request", "DEBUG")
        return None

    async def _adk_after_callback(self, context, response) -> Optional[Any]:
        """ADK callback: after processing — store in memory."""
        if self.state != AgentState.ERROR:
            self.state = AgentState.IDLE

        # Store interaction in memory
        try:
            await self._store_in_memory(
                query=str(context)[:250000],
                results={"adk_response": str(response)[:1000000]}
            )
        except Exception:
            pass

        return None

# Session Management for adk session state

    def _get_session_context(self, session_id: str, max_turns: int = 5) -> str:
        """Build conversation context from previous turns in this session."""
        if session_id not in self._session_store:
            return ""

        history = self._session_store[session_id][-max_turns:]
        if not history:
            return ""

        context = "\n=== PREVIOUS CONVERSATION ===\n"
        for i, turn in enumerate(history):
            context += f"\nTurn {i + 1}:\n"
            context += f"  Query: {turn.get('query', '')[:200]}\n"
            if turn.get('root_cause'):
                context += f"  Root Cause: {turn['root_cause']}\n"
            if turn.get('fix'):
                context += f"  Fix: {turn['fix']}\n"
            if turn.get('log_type'):
                context += f"  Log Type: {turn['log_type']}\n"
        context += "\n=== END PREVIOUS CONVERSATION ===\n"

        return context

    def _store_in_session(self, session_id: str, query: str, results: Dict):
        """Store the current analysis in session history."""
        if session_id not in self._session_store:
            self._session_store[session_id] = []

        # Extract key info from results
        solver_result = results.get("subtask_3", {}).get("response", {})

        self._session_store[session_id].append({
            "query": query,
            "timestamp": datetime.now().isoformat(),
            "root_cause": str(solver_result.get("root_cause", {}).get("primary_cause", "")),
            "fix": str(solver_result.get("fix_suggestion", {}).get("code_fix", {}).get("change_description", "")),
            "log_type": str(solver_result.get("log_type", "")),
            "confidence": results.get("subtask_3", {}).get("confidence", 0),
        })

        # Keep only last 10 turns
        if len(self._session_store[session_id]) > 10:
            self._session_store[session_id] = self._session_store[session_id][-10:]

    # ── Query classification via LLM ──────────────────────────────────────────
    # Result cache: maps query → {"type": "new"|"followup"|"aggregate", "ts": ...}
    _query_type_cache: Dict[str, Dict] = {}

    _QUERY_CLASSIFIER_PROMPT = """You are a query intent classifier for a log analysis assistant.

Given a USER QUERY and whether there is PRIOR CONVERSATION CONTEXT, classify the query
into exactly ONE of these three types:

  new        — A fresh log analysis request (new file, new logs, new error pasted in)
  followup   — Refers to or builds on what was already discussed/analysed in this session
               Examples: "what caused it?", "how do I fix that?", "explain more",
               "summarise what you found", "what was the root cause?", "any other issues?"
  aggregate  — Asks for counts, totals, or stats across the entire chat session
               Examples: "how many errors in this chat?", "total warnings?",
               "how often did timeouts appear?", "count all exceptions"

Respond with ONLY one word: new, followup, or aggregate. No explanation.

PRIOR CONTEXT EXISTS: {has_context}
USER QUERY: {query}
TYPE:"""

    async def _classify_query(self, query: str, session_id: str) -> str:
        """
        Use Gemma to classify the query as 'new', 'followup', or 'aggregate'.
        Falls back to a fast regex check if the model is unavailable.
        Result is cached per (session_id, query) to avoid duplicate model calls.
        """
        cache_key = f"{session_id}:{query}"
        cached = self._query_type_cache.get(cache_key)
        if cached:
            return cached["type"]

        has_context = bool(self._session_store.get(session_id))

        # Try LLM classification first
        try:
            model = await self.get_model("gemma")
            prompt = self._QUERY_CLASSIFIER_PROMPT.format(
                has_context="YES" if has_context else "NO",
                query=query[:30000],
            )
            result = await self._generate_with_tracking(
                model, prompt, max_tokens=5, action_name="classify_query"
            )
            # GenerateResult → .text; or plain str
            raw = (result.text if hasattr(result, "text") else str(result)).strip().lower()
            # Accept only valid labels; anything else → regex fallback
            if raw in ("new", "followup", "aggregate"):
                qtype = raw
                self.log(f"[classify_query] LLM → {qtype!r}", "DEBUG")
                self._query_type_cache[cache_key] = {"type": qtype}
                return qtype
            self.log(f"[classify_query] unexpected LLM output {raw!r}, falling back", "DEBUG")
        except Exception as e:
            self.log(f"[classify_query] model unavailable ({e}), using regex fallback", "DEBUG")

        # ── Regex fallback (runs only when model is unavailable) ───────────────
        q = query.lower()
        count_words = ["how many", "count", "total", "number of", "how often", "frequency"]
        scope_words = ["error", "warning", "critical", "exception", "fail", "log", "issue",
                       "entire chat", "this session", "this chat", "all turns", "across all"]
        if any(c in q for c in count_words) and any(s in q for s in scope_words):
            qtype = "aggregate"
        elif has_context and any(w in q for w in [
            "what was", "what caused", "fix", "explain", "why did",
            "more", "else", "summarize", "summary", "tl;dr", "tldr",
            "root cause", "breakdown", "elaborate",
        ]):
            qtype = "followup"
        else:
            qtype = "new"

        self.log(f"[classify_query] regex → {qtype!r}", "DEBUG")
        self._query_type_cache[cache_key] = {"type": qtype}
        return qtype

    def _is_followup_query(self, query: str) -> bool:
        """Synchronous shim kept for compatibility — real classification is async via _classify_query."""
        q = query.lower()
        return any(w in q for w in [
            "what was", "what caused", "fix", "explain", "why did",
            "more", "else", "summarize", "summary", "tl;dr", "tldr",
            "root cause", "breakdown", "elaborate", "how many", "count",
            "total", "number of", "entire chat", "in this session",
        ])

    def _is_aggregate_query(self, query: str) -> bool:
        """Synchronous shim kept for compatibility."""
        q = query.lower()
        count_words = ["how many", "count", "total", "number of", "how often", "frequency"]
        scope_words = ["error", "warning", "critical", "exception", "fail", "log", "issue",
                       "entire chat", "this session", "this chat", "all turns", "across all"]
        return any(c in q for c in count_words) and any(s in q for s in scope_words)

    def _answer_from_session(self, query: str, last_turn: Dict) -> str:
        """Answer a follow-up question directly from session context."""
        query_lower = query.lower()

        # ── Aggregate / count questions across all session turns ──────────────
        if self._is_aggregate_query(query):
            return self._answer_aggregate_query(query, query_lower)

        # ── Single-turn follow-ups ─────────────────────────────────────────────
        if "root cause" in query_lower:
            return f"The root cause was: {last_turn.get('root_cause', 'not recorded')}"

        if "fix" in query_lower or "how to fix" in query_lower:
            return f"The suggested fix was: {last_turn.get('fix', 'not recorded')}"

        if "log type" in query_lower:
            return f"The log type was: {last_turn.get('log_type', 'unknown')}"

        if "confidence" in query_lower:
            return f"The confidence score was: {last_turn.get('confidence', 0):.0%}"

        # Generic follow-up — return summary
        return f"""From our previous analysis:
    • Root Cause: {last_turn.get('root_cause', 'N/A')}
    • Fix: {last_turn.get('fix', 'N/A')}
    • Log Type: {last_turn.get('log_type', 'N/A')}
    • Confidence: {last_turn.get('confidence', 0):.0%}"""

    def _answer_aggregate_query(self, query: str, query_lower: str) -> str:
        """
        Count errors / warnings / issues across ALL turns stored in the
        current session (_session_store) AND all ChromaDB session messages.
        Called when the user asks something like:
          'how many errors are in this chat?'
          'total warnings across all logs?'
          'how many times did a critical error appear?'
        """
        session_id = self._current_session_id
        all_turns  = self._session_store.get(session_id, [])

        # Gather all text we have from this session
        all_text_parts = []

        # 1. In-memory session turns (root causes + fixes stored per turn)
        for turn in all_turns:
            for field in ("root_cause", "fix", "log_type", "query"):
                val = turn.get(field, "")
                if val:
                    all_text_parts.append(str(val))

        # 2. ChromaDB messages for this session (full User+AI text)
        try:
            import chromadb, os, json
            db_path = os.getenv("CHROMA_DB_PATH", "memory_store/chroma_db")
            client = chromadb.PersistentClient(
                path=db_path,
                settings=chromadb.Settings(anonymized_telemetry=False)
            )
            col  = client.get_or_create_collection("log_analyses")
            data = col.get(ids=[session_id], include=["documents", "metadatas"])
            if data.get("ids"):
                doc  = data["documents"][0] or ""
                meta = data["metadatas"][0] or {}
                all_text_parts.append(doc)
                # Also unpack messages list
                raw_msgs = meta.get("messages", "[]")
                try:
                    msgs = json.loads(raw_msgs) if isinstance(raw_msgs, str) else raw_msgs
                    for m in msgs:
                        all_text_parts.append(str(m.get("query", "")))
                        all_text_parts.append(str(m.get("response", "")))
                except Exception:
                    pass
        except Exception:
            pass

        full_text  = "".join(all_text_parts).lower()
        num_turns  = len(all_turns)

        # ── Count occurrences ─────────────────────────────────────────────────
        import re

        error_kw    = ["error", "exception", "traceback", "failed", "failure",
                       "err:", "critical", "fatal", "[error]"]
        warning_kw  = ["warning", "warn", "[warn]", "deprecated"]
        critical_kw = ["critical", "fatal", "panic", "crash", "outofmemory"]

        def _count_kws(text, keywords):
            total = 0
            for kw in keywords:
                total += len(re.findall(re.escape(kw), text))
            return total

        error_count    = _count_kws(full_text, error_kw)
        warning_count  = _count_kws(full_text, warning_kw)
        critical_count = _count_kws(full_text, critical_kw)

        # Build response based on what the user specifically asked
        if any(w in query_lower for w in ["error"]):
            specific = f"**Errors / exceptions found across this session: {error_count}**"
        elif any(w in query_lower for w in ["warning", "warn"]):
            specific = f"**Warnings found across this session: {warning_count}**"
        elif any(w in query_lower for w in ["critical", "fatal"]):
            specific = f"**Critical / fatal events found: {critical_count}**"
        else:
            specific = (
                f"**Errors / exceptions: {error_count}**  \n"
                f"**Warnings: {warning_count}**  \n"
                f"**Critical / fatal: {critical_count}**"
            )

        summary_lines = []
        for i, turn in enumerate(all_turns, 1):
            rc = turn.get("root_cause", "")
            lt = turn.get("log_type", "")
            q  = turn.get("query", "")[:60]
            if rc or lt:
                summary_lines.append(f"  Turn {i} ({lt or 'unknown type'}): {rc[:80] or q}")

        turns_summary = (
            ("\n\nPer-turn breakdown:\n" + "\n".join(summary_lines))
            if summary_lines else ""
        )

        return (
            f"## Session Log Summary\n\n"
            f"Analysed **{num_turns} turn(s)** in this chat session.\n\n"
            f"{specific}"
            f"{turns_summary}\n\n"
            f"> Note: counts are based on the log content analysed in this session. "
            f"For a precise count from Elasticsearch, use: `elastic:error` as your query."
        )

    async def receive_message(self, message: A2AMessage) -> Optional[A2AMessage]:
        """
        Override to resolve pending futures when responses arrive.
        This is the CRITICAL fix — without this, _send_and_wait always times out.
        """
        # Check if this is a response to a pending request we're waiting for
        if hasattr(self, '_pending_responses') and message.correlation_id:
            future = self._pending_responses.get(message.correlation_id)
            if future and not future.done():
                future.set_result(message)
                self.log(
                    f"Resolved pending future for {message.correlation_id[:8]}... "
                    f"(type={message.message_type.value}, conf={message.confidence:.2f})",
                    "DEBUG"
                )
                return None  # Don't process further — the waiter in _send_and_wait handles it

        # For ERROR messages without a matching future, log and drop to avoid loops
        if message.message_type == MessageType.ERROR and not (
                hasattr(self, '_pending_responses') and
                message.correlation_id in self._pending_responses
        ):
            self.log(f"Dropping orphaned ERROR: {message.error}", "WARNING")
            return None

        # NEW: Drop RESPONSE's without matching future (fire-and-forget like memory store)
        if message.message_type == MessageType.RESPONSE and not (
            hasattr(self, '_pending_responses') and
            message.correlation_id in self._pending_responses
        ):
            self.log(f"Dropping unsolicited RESPONSE from {message.sender_type}", "DEBUG")
            return None

        # Otherwise, let BaseAgent handle it normally
        return await super().receive_message(message)

    async def _retrieve_similar_cases(self, query: str, clean_logs: str, log_type: str) -> Optional[str]:
        """
        Query memory agent for similar past cases and return formatted context.
        Returns None if retrieval fails or no similar cases found.
        """

        # Skip if no meaningful content to search with
        if not clean_logs or len(clean_logs.strip()) < 20:
            return None

        try:
            # Send retrieval request to memory agent
            retrieve_msg = A2AMessage.create_request(
                sender_id=self.agent_id,
                sender_type="orchestrator",
                target_type="memory",
                task={
                    "action": "retrieve_similar_cases",
                    "query": query,
                    "log_type": log_type,
                    "limit": 3
                },
                context={
                    "clean_logs": clean_logs,
                    "log_type": log_type
                }
            )

            result = await self._send_and_wait(retrieve_msg, timeout=600.0)

            if result and result.message_type == MessageType.RESPONSE:
                response = result.response or {}
                past_cases = response.get("results", [])

                if past_cases and len(past_cases) > 0:
                    self.log(f"Retrieved {len(past_cases)} similar past cases from memory")

                    # Format as context for solver
                    context = "\n=== SIMILAR PAST CASES (for reference) ===\n"
                    for i, case in enumerate(past_cases[:3]):
                        similarity = case.get("similarity", 0.0)
                        metadata = case.get("metadata", {})
                        content = case.get("content", "")[:500]

                        context += f"\nPast Case #{i + 1} (similarity: {similarity:.0%}):\n"
                        context += f"  Root Cause: {metadata.get('root_cause', 'N/A')}\n"
                        context += f"  Severity: {metadata.get('severity', 'unknown')}\n"
                        context += f"  Log Type: {metadata.get('log_type', 'unknown')}\n"
                        if content:
                            context += f"  Excerpt: {content[:200]}...\n"

                    context += "\nNOTE: These are past cases for reference only. The current error may have a different root cause.\n"
                    context += "=== END PAST CASES ===\n"

                    return context

            return None

        except Exception as e:
            self.log(f"Memory retrieval failed (non-critical): {e}", "DEBUG")
            return None

    def _select_orchestrator_skill(self, stage: str, retry_count: int = 0):
        """
        Select the best orchestrator skill based on pipeline stage.
        Returns (prompt_template, skill_name).

        Safe version: does not crash if optional skill constants are missing.
        """

        optional_skills = {
            "loop_detection": globals().get(
                "SKILL_LOOP_DETECTION",
                "Detect repeated retries and stop loops safely."
            ),
            "human_input": globals().get(
                "SKILL_HUMAN_INPUT_REQUEST",
                "Ask the user for missing input through web/API, not terminal input."
            ),
            "fallback": globals().get(
                "SKILL_FALLBACK_STRATEGY",
                "Use a safe fallback when an agent/model/tool fails."
            ),
            "format": globals().get(
                "SKILL_OUTPUT_FORMATTING",
                "Format the final output clearly and professionally."
            ),
        }

        if retry_count > 3:
            return optional_skills["loop_detection"], "loop_detection"

        skill_map = {
            "decompose": (SKILL_TASK_DECOMPOSITION, "task_decomposition"),
            "plan": (SKILL_PIPELINE_PLANNING, "pipeline_planning"),
            "select": (SKILL_AGENT_SELECTION, "agent_selection"),
            "edge_case": (SKILL_EDGE_CASE_DETECTION, "edge_case_detection"),
            "validate_scope": (SKILL_SCOPE_VALIDATION, "scope_validation"),
            "aggregate": (SKILL_RESULT_AGGREGATION, "result_aggregation"),
            "human_input": (optional_skills["human_input"], "human_input_request"),
            "fallback": (optional_skills["fallback"], "fallback_strategy"),
            "format": (optional_skills["format"], "output_formatting"),
        }

        return skill_map.get(stage, (SKILL_TASK_DECOMPOSITION, "task_decomposition"))

    async def handle_user_query(self, query: str, session_id: str = None) -> str:
        """Main entry point for user queries - NO agent imports"""
        import time
        import uuid

        # Use existing or new session
        if session_id is None:
            session_id = self._current_session_id or str(uuid.uuid4())
        self._current_session_id = session_id

        approval_reply = query.lower().strip()

        if approval_reply in ["yes", "yes approve", "approve", "approve this fix"]:
            return await self._handle_web_approval_reply("yes")

        if approval_reply in ["no", "reject", "no reject", "do not apply"]:
            return await self._handle_web_approval_reply("no")

        if approval_reply in ["show diff", "diff", "show changes"]:
            return await self._handle_web_approval_reply("show diff")

        # input_info = detect_input(query)
        # print(f"\n⏳ {input_info['display_message']}")

        # ── Classify query intent via LLM (Gemma) ───────────────────────────────
        # Returns: "new" | "followup" | "aggregate"
        query_type = await self._classify_query(query, session_id)
        self.log(f"[handle_user_query] query_type={query_type!r}", "DEBUG")

        last_turn = (
            self._session_store[session_id][-1]
            if self._session_store.get(session_id)
            else {}
        )

        if query_type == "followup":
            if last_turn.get("root_cause"):
                return self._answer_from_session(query, last_turn)
                # query = session_context + "\nCurrent question: " + query
                # self.log("Injected session context into follow-up query", "DEBUG")

        if query_type == "aggregate":
            return self._answer_aggregate_query(query, query.lower())

        # ── Detect summarization (still useful as a plan hint) ────────────────
        if any(word in query.lower() for word in ["summarize", "summary", "tl;dr", "tldr", "overview"]):
            # Force intent to summarization
            # query_type = "summarize"
            self.log("Summarization requested", "DEBUG")
            # The solver will pick up this flag from the plan context

        # NEW: Detect input type first, before any processing
        input_info = detect_input(query)
        print(f"\n⏳ {input_info['display_message']}")

        # NEW: Handle NL queries by searching session + memory
        if input_info.get("input_type") == "nl_query":
            # First check if there's a recent session with logs
            if self._session_store.get(session_id):
                last_turn = self._session_store[session_id][-1]
                if last_turn.get("root_cause"):
                    # Answer from session context
                    return self._answer_from_session(query, last_turn)

            # If no session, check memory for past analyses
            try:
                memory_context = await self._retrieve_similar_cases(
                    query=query,
                    clean_logs=query,
                    log_type="unknown"
                )
                if memory_context:
                    # Run analysis on retrieved memory context
                    plan = await self.planner.decompose(query, None)
                    plan["original_query"] = memory_context + "\n\nUser question: " + query
                    results = await self._execute_plan(plan)
                    final = await self._aggregate_results(results, query)
                    return final
            except Exception:
                pass

            return "I couldn't find any logs to answer your question. Please provide logs or a file path first."

        # Generate unique query session ID
        query_id = str(uuid.uuid4())
        query_start_time = time.time()

        # Start OTEL trace for this query
        from utils.tracing import trace_query
        query_span = trace_query(query_id, query[:100])

        self.log(f"Processing query: {query[:100]}...")
        self.log(
            f"Detected: {input_info['input_type']}/{input_info['format']} (layer {input_info['detection_layer']}, confidence: {input_info['confidence']})",
            "INFO")

        # Log query start to audit
        try:
            from utils.audit_logger import get_audit_logger
            audit = get_audit_logger()
            audit.start_session(
                query_id=query_id,
                query_text=query,
                input_type=input_info["input_type"],
                input_format=input_info.get("format", "unknown"),
                chars=input_info.get("chars", len(query)),
                lines=input_info.get("lines", query.count('\n') + 1),
            )
        except Exception:
            audit = None

        try:
            # Step 1: Check if in scope
            if not await self._is_in_scope(query):
                return self._get_capability_summary()

            # Step 2: Decompose query
            self.log("Decomposing query...")
            model = None
            try:
                model = await self.get_model("gemma")
            except Exception:
                pass
            plan = await self.planner.decompose(query, model)

            # Inject query_id and input_info into plan for downstream logging
            plan["query_id"] = query_id
            plan["detected_input"] = input_info

            # Step 3: Execute plan via Communication Bus
            self.log(f"Executing plan with {len(plan['subtasks'])} subtasks")
            skill_prompt, skill_name = self._select_orchestrator_skill("plan")
            self.log(f"Orchestrator using skill: {skill_name}", "INFO")
            results = await self._execute_plan(plan)

            # Step 4: Aggregate results
            self.log("Aggregating results...")
            final_response = await self._aggregate_results(results, query)

            # Step 5: Store in memory via Communication Bus
            await self._store_in_memory(query, results)
            self._store_in_session(session_id, query, results)

            # Log query end to audit
            if audit:
                final_confidence = results.get("subtask_4", {}).get("confidence", 0.0)
                audit.end_session(
                    query_id=query_id,
                    status="completed",
                    final_confidence=final_confidence,
                )
                audit.log_token_summary(query_id)

            return final_response

        except Exception as e:
            self.log(f"Error: {e}", "ERROR")
            # Log failure to audit
            if audit:
                total_duration_ms = (time.time() - query_start_time) * 1000
                audit.end_session(
                    query_id=query_id,
                    status="error",
                    error=str(e),
                )
                audit.log_token_summary(query_id)
            return f"I encountered an error: {str(e)}\n\nPlease try again."

    async def process(self, message: A2AMessage) -> A2AMessage:
        """Process incoming messages"""
        if not self.planner:
            await self.initialize()

        task = message.task or {}
        action = task.get("action", "handle_query")

        if action == "handle_query":
            return await self._handle_user_query(message)
        elif action == "aggregate_results":
            return await self._handle_aggregation(message)
        else:
            return await self._handle_user_query(message)

    async def _is_in_scope(self, query: str) -> bool:
        """Check if query is within system capabilities"""
        query_lower = query.lower()

        # NEW: Terminal commands are always in scope
        if query_lower.startswith("command:") or query_lower.startswith("cmd:"):
            return True

        # Clearly out-of-scope
        out_of_scope = [
            'weather', 'news', 'sport', 'recipe', 'cook',
            'movie', 'song', 'game', 'play', 'joke', 'what is your name',
            'who are you', 'how old are you',
            'how are you',     # ← ADD
            'how do you do',   # ← ADD
        ]

        for keyword in out_of_scope:
            if keyword in query_lower:
                return False

        # Log-related keywords
        log_keywords = [
            'log', 'error', 'debug', 'fix', 'crash', 'exception',
            'stack trace', 'analyze', 'issue', 'problem', 'failed',
            'failure', 'warning', 'critical', 'trace', 'fatal',
            'null', 'timeout', 'refused', 'denied', 'not found',
            'permission', 'memory', 'disk', 'network', 'database'
        ]

        for keyword in log_keywords:
            if keyword in query_lower:
                return True

        # Python error patterns
        python_errors = [
            'traceback', 'nameerror', 'typeerror', 'valueerror',
            'keyerror', 'indexerror', 'attributeerror', 'importerror',
            'modulenotfounderror', 'syntaxerror', 'indentationerror',
            'filenotfounderror', 'permissionerror', 'connectionerror',
            'timeouterror', 'runtimeerror', 'notimplementederror'
        ]

        for error in python_errors:
            if error in query_lower:
                return True

        # Contains file paths
        if any(ext in query_lower for ext in ['.py', '.log', '.txt', '.json', '.xml', '.csv']):
            return True

        # Contains line numbers (common in stack traces)
        if 'line' in query_lower and any(char.isdigit() for char in query):
            return True

        # Contains error patterns like "Error:" or "Exception:"
        if 'error:' in query_lower or 'exception:' in query_lower:
            return True

        # Has timestamp patterns
        import re
        if re.search(r'\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}', query):
            return True

        # Default: check if it looks like a technical question
        technical_words = ['what', 'why', 'how', 'fix', 'help', 'check', 'find', 'cause']
        return any(word in query_lower for word in technical_words)

    async def _retry_with_feedback(self, plan, results, retry_count=0, max_retries=3):
        """
        Multi-step reasoning: if critic confidence is low, retry solver
        with constructive feedback.
        """
        if retry_count >= max_retries:
            self.log(f"Max retries ({max_retries}) reached, proceeding with current results")
            return results

        # Get critic's result
        critic_key = "subtask_4"  # validate is subtask 5 (index 4)
        critic_result = results.get(critic_key, {})

        if not critic_result or critic_result.get("status") != "completed":
            return results

        critic_response = critic_result.get("response", {})

        # Check if retry is needed
        needs_retry = (
                not critic_response.get("validation_passed", True) or
                critic_result.get("confidence", 1.0) < 0.5
        )

        if not needs_retry:
            self.log(f"Critic confidence {critic_result.get('confidence', 0):.2f} — no retry needed")
            return results

        retry_feedback = critic_response.get("retry_feedback", "")
        if not retry_feedback:
            return results

        self.log(
            f"Critic confidence {critic_result.get('confidence', 0):.2f} — retrying solver with feedback (attempt {retry_count + 1}/{max_retries})")

        # Get solver's original task and add feedback
        solver_key = "subtask_3"  # solve is subtask 4 (index 3)
        original_solver_result = results.get(solver_key, {})

        # Build retry subtask
        retry_subtask = {
            "action": "solve",
            "retry_count": retry_count + 1,
            "retry_feedback": retry_feedback,
            "previous_attempt": original_solver_result.get("response", {}),
            "intent": plan.get("subtasks", [{}])[3].get("intent", "debugging")
        }

        # Send retry to solver
        request = A2AMessage.create_request(
            sender_id=self.agent_id,
            sender_type="orchestrator",
            target_type="solver",
            task=retry_subtask,
            context={
                "query": plan.get("original_query", ""),
                "clean_logs": results.get("subtask_2", {}).get("response", {}).get("clean_logs", ""),
                "log_type": results.get("subtask_2", {}).get("response", {}).get("log_type", "unknown"),
                "retry_feedback": retry_feedback
            }
        )

        retry_result = await self._send_and_wait(request, timeout=600.0)

        if retry_result and retry_result.message_type != MessageType.ERROR:
            # Update solver result
            results["subtask_3"] = {
                "status": "completed",
                "agent_type": "solver",
                "response": retry_result.response if retry_result.response else {},
                "confidence": retry_result.confidence,
                "retry_attempt": retry_count + 1
            }

            # Re-validate
            validate_subtask = {
                "action": "validate",
                "solution": retry_result.response if retry_result.response else {},
                "original_logs": results.get("subtask_0", {}).get("response", {}).get("raw_logs", "")
            }

            validate_request = A2AMessage.create_request(
                sender_id=self.agent_id,
                sender_type="orchestrator",
                target_type="critic",
                task=validate_subtask,
                context={"query": plan.get("original_query", "")}
            )

            validate_result = await self._send_and_wait(validate_request, timeout=600.0)

            if validate_result and validate_result.message_type != MessageType.ERROR:
                results["subtask_4"] = {
                    "status": "completed",
                    "agent_type": "critic",
                    "response": validate_result.response if validate_result.response else {},
                    "confidence": validate_result.confidence
                }

                # Recursive retry if still low confidence
                return await self._retry_with_feedback(plan, results, retry_count + 1, max_retries)

        return results

    async def _cross_agent_debate(self, plan, results, merged_context):
        """
        Run solver and debugger in parallel, let critic pick the winner.
        Only triggers when the pipeline has both solve AND debug stages.
        """
        # subtasks = plan.get("subtasks", [])
        # has_debug = any(s.get("action") == "debug" for s in subtasks)
        #
        # if not has_debug:
        #     return None  # No debug stage, skip debate

        self.log("Starting cross-agent debate: solver vs debugger")

        # Prepare context for both agents
        query = plan.get("original_query", "")
        clean_logs = merged_context.get("clean_logs", "")
        log_type = merged_context.get("log_type", "unknown")

        # Build solver request
        solver_task = {
            "action": "solve",
            "intent": "debugging"
        }
        solver_context = {
            "query": query,
            "clean_logs": clean_logs,
            "log_type": log_type,
        }

        # Build debugger request
        debugger_task = {
            "action": "debug",
        }
        debugger_context = {
            "query": query,
            "clean_logs": clean_logs,
            "stack_trace": merged_context.get("raw_logs", clean_logs),
        }

        # Send to both in parallel
        solver_request = A2AMessage.create_request(
            sender_id=self.agent_id,
            sender_type="orchestrator",
            target_type="solver",
            task=solver_task,
            context=solver_context
        )

        debugger_request = A2AMessage.create_request(
            sender_id=self.agent_id,
            sender_type="orchestrator",
            target_type="debugger",
            task=debugger_task,
            context=debugger_context
        )

        # Fire both simultaneously
        # import asyncio
        # solver_future = self._send_and_wait(solver_request, timeout=60.0)
        # debugger_future = self._send_and_wait(debugger_request, timeout=60.0)
        #
        # solver_result, debugger_result = await asyncio.gather(
        #     solver_future, debugger_future, return_exceptions=True
        # )

        # Fire sequentially to avoid GGML concurrency crash
        solver_result = await self._send_and_wait(solver_request, timeout=600.0)
        debugger_result = await self._send_and_wait(debugger_request, timeout=600.0)

        # ADD THESE DEBUG LINES:
        if isinstance(solver_result, Exception):
            self.log(f"Debate: Solver failed with exception: {solver_result}", "DEBUG")
        elif not solver_result:
            self.log("Debate: Solver returned None", "DEBUG")
        else:
            self.log(
                f"Debate: Solver returned type={solver_result.message_type.value}, conf={solver_result.confidence:.2f}",
                "DEBUG")

        if isinstance(debugger_result, Exception):
            self.log(f"Debate: Debugger failed with exception: {debugger_result}", "DEBUG")
        elif not debugger_result:
            self.log("Debate: Debugger returned None", "DEBUG")
        else:
            self.log(
                f"Debate: Debugger returned type={debugger_result.message_type.value}, conf={debugger_result.confidence:.2f}",
                "DEBUG")

        # Ask critic to compare
        critic_task = {
            "action": "validate",
            "solution": {
                "solver": solver_result.response if solver_result.response else {},
                "debugger": debugger_result.response if debugger_result.response else {},
            },
            "original_logs": clean_logs,
        }

        critic_request = A2AMessage.create_request(
            sender_id=self.agent_id,
            sender_type="orchestrator",
            target_type="critic",
            task=critic_task,
            context={"query": query, "debate_mode": True}
        )

        critic_result = await self._send_and_wait(critic_request, timeout=600.0)

        if critic_result and critic_result.message_type != MessageType.ERROR:
            critic_response = critic_result.response or {}
            winner = critic_response.get("winner", "solver")

            self.log(f"Cross-agent debate complete — winner: {winner}")

            # Return the winner's result to be used as the solve output
            if winner == "debugger" and debugger_result.response:
                debug_response = debugger_result.response
                return {
                    "status": "completed",
                    "agent_type": "debugger",
                    "response": {
                        "root_cause": debug_response.get("parsed_trace", {}),
                        "fix_suggestion": debug_response.get("patch", {}),
                        "explanation": debug_response.get("patch", {}).get("fix_description", ""),
                        "log_type": merged_context.get("log_type", "unknown"),
                        "debate_winner": "debugger",
                    },
                    "confidence": debugger_result.confidence,
                }
            else:
                # Default: use solver result
                solver_response = solver_result.response if solver_result.response else {}
                return {
                    "status": "completed",
                    "agent_type": "solver",
                    "response": solver_response,
                    "confidence": solver_result.confidence,
                }

        # If critic failed, fall back to solver
        if solver_result and solver_result.response:
            return {
                "status": "completed",
                "agent_type": "solver",
                "response": solver_result.response,
                "confidence": solver_result.confidence,
            }

        return None        # Debate inconclusive — use solver as default

    def _has_stack_trace(self, text: str) -> bool:
        """Check if log content contains a stack trace worth debugging."""
        if not text:
            return False

        # Python traceback
        if "Traceback (most recent call last)" in text:
            return True
        if 'File "' in text and 'line ' in text:
            return True

        # Java stack trace
        if "Exception in thread" in text:
            return True
        if "at com." in text or "at org." in text:
            return True

        # JavaScript/Node.js
        if "at " in text and (".js:" in text or ".ts:" in text):
            return True

        # Go panic
        if "panic:" in text and ".go:" in text:
            return True

        # Generic error with file:line references
        if re.search(r'\w+\.\w+:\d+', text):
            return True

        return False

    async def _retrieve_logs_from_mcp(self, query: str, source: str = "auto", size: int = 10) -> Dict[str, Any]:
        """
        Retrieve logs using MCP from ElasticSearch, JSON, or ChromaDB.
        """
        try:
            result_text = await self.mcp_client.retrieve_logs_auto(
                query=query,
                source=source,
                size=size,
            )

            if not result_text:
                return {
                    "raw_logs": "",
                    "source": "mcp",
                    "warning": "No logs returned from MCP"
                }

            return {
                "raw_logs": result_text,
                "source": "mcp",
                "retrieval_source": source,
                "format_detected": "json",
            }

        except Exception as e:
            self.log(f"MCP retrieval failed: {e}", "WARNING")
            return {
                "raw_logs": "",
                "source": "mcp",
                "warning": str(e),
            }

    async def _handle_confidence_based_approval(
            self,
            debate_result: Dict[str, Any],
            plan: Dict[str, Any],
            root_cause: str,
            fix_description: str,
            code_before: str = "",
            code_after: str = "",
            file_path: str = "",
            risk_level: str = "medium",
    ) -> Dict[str, Any]:
        """
        Ask approval only when confidence is >= 70%.
        If confidence is below 70%, block approval and return safe recommendation.
        """

        confidence = debate_result.get("confidence", 0.0)

        try:
            confidence = float(confidence)
        except Exception:
            confidence = 0.0

        # Normalize 70 -> 0.70 if some agent returns percentage format
        if confidence > 1:
            confidence = confidence / 100

        debate_result["confidence"] = confidence

        if confidence < CONFIDENCE_APPROVAL_THRESHOLD:
            debate_result["approval_required"] = False
            debate_result["approved"] = False
            debate_result["approval_blocked"] = True
            debate_result["status"] = "needs_improvement"
            debate_result["approval_block_reason"] = (
                f"Confidence score is {confidence * 100:.0f}%, "
                f"which is below the required {CONFIDENCE_APPROVAL_THRESHOLD * 100:.0f}% threshold."
            )
            debate_result["recommendation"] = (
                "The suggested fix was not sent for approval because confidence is too low. "
                "Run another solver/debugger pass, improve the evidence, or send it for manual review."
            )

            self.log(
                f"Approval blocked because confidence {confidence:.2f} is below "
                f"{CONFIDENCE_APPROVAL_THRESHOLD:.2f}",
                "WARNING",
            )

            return debate_result

        approval_request = self.approval_gate.create_request(
            query=plan.get("original_query", ""),
            root_cause=root_cause or "Unknown",
            fix_description=fix_description or "Fix suggested by solver/debugger",
            code_before=code_before or "",
            code_after=code_after or "",
            file_path=file_path or "",
            risk_level=risk_level,
            confidence=confidence,
        )

        # Web/API mode: never ask terminal input
        if os.getenv("ADK_WEB_MODE", "false").lower() == "true":
            self._pending_approvals[approval_request.request_id] = {
                "request": approval_request,
                "query": plan.get("original_query", ""),
                "result": debate_result,
                "created_at": datetime.now().isoformat(),
            }

            debate_result["approval_required"] = True
            debate_result["approval_id"] = approval_request.request_id
            debate_result["approval_message"] = (
                "Approval required before applying this fix.\n\n"
                f"Request ID: {approval_request.request_id}\n"
                f"Risk Level: {approval_request.risk_level}\n"
                f"Confidence: {confidence * 100:.0f}%\n\n"
                f"Root Cause:\n{approval_request.root_cause}\n\n"
                f"Suggested Fix:\n{approval_request.fix_description}\n\n"
                "Reply with one of the following:\n"
                "- yes, approve this fix\n"
                "- no, reject this fix\n"
                "- show diff"
            )

            self.log(
                "Confidence passed threshold — returning approval request to web/API",
                "INFO",
            )

        else:
            approved = await self.approval_gate.request_approval(approval_request)
            debate_result["approved"] = approved
            debate_result["approval_id"] = approval_request.request_id

        return debate_result

    async def _execute_plan(self, plan: Dict) -> Dict:
        """Execute plan by sending A2A messages - skip if previous step failed critically"""
        import os
        import time

        subtasks = plan.get("subtasks", [])
        results = {}
        pipeline_broken = False
        # Default skill name used in result dicts — updated per subtask below
        orchestrator_skill_name = "pipeline_planning"

        # Get audit context from plan
        query_id = plan.get("query_id", "unknown")
        input_info = plan.get("detected_input", {})

        try:
            from utils.audit_logger import get_audit_logger
            audit = get_audit_logger()
        except Exception:
            audit = None

        # Initialize merged_context
        merged_context = _merge_results(results)
        merged_context["query"] = plan.get("original_query", "")

        for i, subtask in enumerate(subtasks):
            action = subtask.get("action", "unknown")
            stage_start_time = time.time()

            merged_context = _merge_results(results)
            merged_context["query"] = plan.get("original_query", "")

            # Skip if pipeline is broken
            if pipeline_broken:
                self.log(f"Skipping subtask {i + 1}: {action} (pipeline broken)")
                results[f"subtask_{i}"] = {
                    "status": "skipped",
                    "reason": "Previous critical step failed",
                    "orchestrator_skill": orchestrator_skill_name
                }
                # Log skipped stage
                if audit:
                    audit.log_pipeline_stage(
                        query_id=query_id,
                        stage=action,
                        status="skipped",
                        agent_type="none",
                        confidence=0.0,
                        query_preview=plan.get("original_query", ""),
                        input_type=input_info.get("input_type"),
                        stage_number=f"{i + 1}/{len(subtasks)}",
                    )
                continue

            if action == "extract" and plan.get("query_type") == "nl_query":
                results[f"subtask_{i}"] = {
                    "status": "skipped",
                    "reason": "No logs provided for NL query",
                    "orchestrator_skill": orchestrator_skill_name,
                }
                continue

            # ---- Fix extract subtask ----
            if action == "extract":
                import os

                original_query = plan.get("original_query", "")

                # NEW: Strip summarization prefixes before resolving path
                for prefix in ["summarize ", "summarize this file_path: ", "summarize file_path: ", "summary ",
                               "overview "]:
                    if original_query.lower().startswith(prefix):
                        original_query = original_query[len(prefix):]
                        break

                # NEW: MCP retrieval for ElasticSearch / JSON / ChromaDB
                if (
                        original_query.lower().startswith("mcp:")
                        or original_query.lower().startswith("elastic:")
                        or original_query.lower().startswith("elasticsearch:")
                        or original_query.lower().startswith("json:")
                        or original_query.lower().startswith("chromadb:")
                        or original_query.lower().startswith("memory:")
                ):
                    source = "auto"
                    query_part = original_query

                    if ":" in original_query:
                        prefix, query_part = original_query.split(":", 1)
                        prefix = prefix.lower().strip()
                        query_part = query_part.strip()

                        if prefix in ["elastic", "elasticsearch"]:
                            source = "elastic"
                        elif prefix == "json":
                            source = "json"
                        elif prefix in ["chromadb", "memory"]:
                            source = "chromadb"
                        else:
                            source = "auto"

                    mcp_logs = await self._retrieve_logs_from_mcp(
                        query=query_part,
                        source=source,
                        size=10,
                    )

                    results[f"subtask_{i}"] = {
                        "status": "completed",
                        "agent_type": "mcp_proxy",
                        "response": mcp_logs,
                        "confidence": 0.90,
                    }

                    self.log(f"MCP retrieval completed using source={source}", "INFO")
                    continue

                # NEW: Detect terminal command prefix
                elif original_query.lower().startswith("command:") or original_query.lower().startswith("cmd:"):
                    command = original_query.split(":", 1)[1].strip()
                    if command:
                        subtask["command"] = command
                        subtask["source_type"] = "terminal"
                        subtask["content"] = None
                        subtask["file_path"] = ""
                        self.log(f"Detected terminal command: {command}", "DEBUG")

                # If query looks like a file path, resolve it directly
                elif original_query and not subtask.get("file_path"):
                    cleaned_query = original_query.strip().strip('"').strip("'")

                    # Remove common natural-language prefixes
                    prefixes = [
                        "analyze this image:",
                        "analyze image:",
                        "extract text from:",
                        "ocr this:",
                        "image:",
                        "file_path:",
                        "path:",
                    ]

                    for prefix in prefixes:
                        if cleaned_query.lower().startswith(prefix):
                            cleaned_query = cleaned_query[len(prefix):].strip().strip('"').strip("'")
                            break

                    supported_files = [
                        ".log", ".txt", ".json", ".csv", ".xml",
                        ".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tiff"
                    ]

                    if any(cleaned_query.lower().endswith(ext) for ext in supported_files):
                        abs_path = os.path.abspath(cleaned_query)
                        subtask["file_path"] = abs_path
                        subtask["content"] = None

                        if any(cleaned_query.lower().endswith(ext) for ext in
                               [".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tiff"]):
                            subtask["source_type"] = "image"
                        else:
                            subtask["source_type"] = "file"

                        self.log(f"Resolved file path: {abs_path}", "DEBUG")

                # If still no file_path, check options and plan
                if not subtask.get("file_path") and not subtask.get("command"):
                    file_path = subtask.get("options", {}).get("path") or plan.get("file_path")
                    if file_path:
                        if not os.path.isabs(file_path):
                            file_path = os.path.abspath(file_path)
                        subtask["file_path"] = file_path
                        subtask["content"] = None

                # Last resort: use query as pasted text
                if not subtask.get("content") and not subtask.get("file_path") and not subtask.get("command"):
                    subtask["content"] = original_query
            # ---------------------------------

            # ---- Inject memory context before solve ----
            if action == "solve":
                # 1. Memory retrieval (always)
                memory_context = await self._retrieve_similar_cases(
                    query=plan.get("original_query", ""),
                    clean_logs=merged_context.get("clean_logs", ""),
                    log_type=merged_context.get("log_type", "unknown")
                )
                if memory_context:
                    subtask["memory_context"] = memory_context
                    self.log("Injected memory context into solve task", "DEBUG")

                # 2. Cross-agent debate (only when stack trace detected)
                raw_logs = merged_context.get("raw_logs", "") or merged_context.get("clean_logs", "")
                if self._has_stack_trace(raw_logs):
                    self.log("Stack trace detected — starting cross-agent debate", "DEBUG")
                    debate_result = await self._cross_agent_debate(plan, results, merged_context)
                    if debate_result:
                        # Check if ANY agent generated a fix worth approving
                        response = debate_result.get("response", {})
                        fix_suggestion = response.get("fix_suggestion", {})

                        if fix_suggestion:
                            # Get fix details from solver response
                            code_fix = fix_suggestion.get("code_fix", {})
                            root_cause_data = response.get("root_cause", {})

                            # FIX: Only trigger approval gate when there is actual code to patch.
                            # change_description alone is not enough — code_before AND code_after
                            # must be non-empty, otherwise it's just a text recommendation, not a patch.
                            has_actual_code_patch = (
                                bool(code_fix.get("code_before", "").strip()) and
                                bool(code_fix.get("code_after", "").strip())
                            )
                            if code_fix.get("change_description") and has_actual_code_patch:
                                try:
                                    debate_result = await self._handle_confidence_based_approval(
                                        debate_result=debate_result,
                                        plan=plan,
                                        root_cause=str(root_cause_data.get("primary_cause", "Unknown")),
                                        fix_description=code_fix.get("change_description", "Fix suggested by solver"),
                                        code_before=code_fix.get("code_before", ""),
                                        code_after=code_fix.get("code_after", ""),
                                        file_path=code_fix.get("file", ""),
                                        risk_level=fix_suggestion.get("risk_level", "medium"),
                                    )
                                except Exception as e:
                                    self.log(f"Approval gate error: {e}", "WARNING")

                                    if os.getenv("ADK_WEB_MODE", "false").lower() == "true":
                                        approved = None
                                        # approval_request may not exist if _handle_confidence_based_approval
                                        # raised before creating it — skip approval block safely
                                        if not locals().get("approval_request"):
                                            pass
                                        else:
                                          self._pending_approvals[approval_request.request_id] = {
                                            "request": approval_request,
                                            "query": plan.get("original_query", ""),
                                            "result": debate_result,
                                            "created_at": datetime.now().isoformat(),
                                        }

                                        debate_result["approval_required"] = True
                                        debate_result["approval_id"] = approval_request.request_id
                                        debate_result["approval_message"] = (
                                            "Approval required before applying this fix.\n\n"
                                            f"Request ID: {approval_request.request_id}\n"
                                            f"Risk Level: {approval_request.risk_level}\n"
                                            f"Confidence: {approval_request.confidence:.0%}\n\n"
                                            f"Root Cause:\n{approval_request.root_cause}\n\n"
                                            f"Suggested Fix:\n{approval_request.fix_description}\n\n"
                                            "Reply with one of the following:\n"
                                            "- yes, approve this fix\n"
                                            "- no, reject this fix\n"
                                            "- show diff"
                                        )

                                        self.log(
                                            "ADK Web mode — returning approval request to web instead of terminal input",
                                            "INFO")

                                    else:
                                        if os.getenv("ADK_WEB_MODE", "false").lower() == "true":
                                            self._pending_approvals[approval_request.request_id] = {
                                                "request": approval_request,
                                                "query": plan.get("original_query", ""),
                                                "result": debate_result,
                                                "created_at": datetime.now().isoformat(),
                                            }

                                            debate_result["approval_required"] = True
                                            debate_result["approval_id"] = approval_request.request_id
                                            debate_result["approval_message"] = (
                                                "Approval required before applying this fix.\n\n"
                                                f"Request ID: {approval_request.request_id}\n"
                                                f"Risk Level: {approval_request.risk_level}\n"
                                                f"Confidence: {approval_request.confidence:.0%}\n\n"
                                                f"Root Cause:\n{approval_request.root_cause}\n\n"
                                                f"Suggested Fix:\n{approval_request.fix_description}\n\n"
                                                "Reply with one of the following:\n"
                                                "- yes, approve this fix\n"
                                                "- no, reject this fix\n"
                                                "- show diff"
                                            )

                                            self.log(
                                                "ADK Web mode — returning approval request to web instead of terminal input",
                                                "INFO",
                                            )

                                        else:
                                            approved = await self.approval_gate.request_approval(approval_request)
                                            debate_result["approved"] = approved
                                            debate_result["approval_id"] = approval_request.request_id
                                except Exception as e:
                                    self.log(f"Approval gate error: {e}", "WARNING")

                        # Check for fix that needs approval BEFORE storing result
                        response = debate_result.get("response", {})
                        fix_suggestion = response.get("fix_suggestion", {})

                        # self.log(
                        #     f"DEBUG fix_suggestion keys: {list(fix_suggestion.keys()) if isinstance(fix_suggestion, dict) else type(fix_suggestion)}",
                        #     "DEBUG")
                        # self.log(f"DEBUG fix_suggestion: {str(fix_suggestion)[:300]}", "DEBUG")

                        # Check for actionable fix needing approval
                        response = debate_result.get("response", {})
                        fix_suggestion = response.get("fix_suggestion", {})

                        if fix_suggestion:
                            # Try code_changes first, then immediate_actions
                            code_changes = fix_suggestion.get("code_changes", [])
                            immediate_actions = fix_suggestion.get("immediate_actions", [])
                            root_cause_data = response.get("root_cause", {})

                            has_code_fix = code_changes and len(code_changes) > 0
                            has_action = immediate_actions and len(immediate_actions) > 0

                            if has_code_fix or has_action:
                                try:
                                    # Build fix description from whichever is available
                                    if has_code_fix:
                                        fix_desc = code_changes[0] if isinstance(code_changes[0], str) else \
                                        code_changes[0].get("description", str(code_changes[0]))
                                    else:
                                        fix_desc = immediate_actions[0]

                                    debate_result = await self._handle_confidence_based_approval(
                                        debate_result=debate_result,
                                        plan=plan,
                                        root_cause=str(root_cause_data.get("primary_cause", "Unknown")),
                                        fix_description=str(fix_desc),
                                        code_before="",
                                        code_after="",
                                        file_path="",
                                        risk_level=fix_suggestion.get("risk_level", "medium"),
                                    )
                                except Exception as e:
                                    self.log(f"Approval gate error: {e}", "WARNING")

                        results[f"subtask_{i}"] = debate_result
                        self.log(
                            f"Cross-agent debate: using {debate_result.get('agent_type', 'solver')} (winner: {debate_result.get('debate_winner', 'solver')})",
                            "INFO")
                        continue
                    # if debate_result:
                    #     # After debugger result in cross-agent debate
                    #     if debate_result.get("response", {}).get("patch"):  # Any patch available?
                    #         patch = debate_result.get("response", {}).get("patch", {})
                    #         if patch and patch.get("code_after"):
                    #             approval_request = self.approval_gate.create_request(
                    #                 query=plan.get("original_query", ""),
                    #                 root_cause=str(
                    #                     debate_result.get("response", {}).get("parsed_trace", {}).get("error_message", "")),
                    #                 fix_description=patch.get("fix_description", ""),
                    #                 code_before=patch.get("code_before", ""),
                    #                 code_after=patch.get("code_after", ""),
                    #                 file_path=patch.get("file", ""),
                    #                 confidence=debate_result.get("confidence", 0),
                    #             )
                    #
                    #             approved = await self.approval_gate.request_approval(approval_request)
                    #             debate_result["approved"] = approved
                    #             debate_result["approval_id"] = approval_request.request_id
                    #         continue  # Skip normal solver — debate already produced result
                    else:
                        self.log("Debate inconclusive — proceeding with normal solver", "DEBUG")
                else:
                    self.log("No stack trace detected — using solver only", "DEBUG")

            # ---------------------------------------------

            # Update skill name for this subtask so result dicts are accurate
            _, orchestrator_skill_name = self._select_orchestrator_skill(action)

            self.log(f"Subtask {i + 1}/{len(subtasks)}: {action}")

            target_type = self.router.get_agent_type_for_action(action)

            if not target_type:
                self.log(f"No agent type for: {action}", "WARNING")
                results[f"subtask_{i}"] = {"status": "failed", "error": "No capable agent", "orchestrator_skill": orchestrator_skill_name}
                if audit:
                    audit.log_pipeline_stage(
                        stage=action,
                        status="failed",
                        agent_type="none",
                        confidence=0.0,
                        query_id=query_id,
                        query_preview=plan.get("original_query", ""),
                        input_type=input_info.get("input_type"),
                        stage_number=f"{i + 1}/{len(subtasks)}",
                        error="No capable agent found",
                    )
                if action in ["extract", "preprocess"]:
                    pipeline_broken = True
                continue

            # Merge all previous results into context for downstream agents
            merged_context = _merge_results(results)
            merged_context["query"] = plan.get("original_query", "")

            request = A2AMessage.create_request(
                sender_id=self.agent_id,
                sender_type="orchestrator",
                target_type=target_type,
                task={**subtask, "context": merged_context},
                context=merged_context
            )

            with trace_pipeline_stage(action, f"{i + 1}/{len(subtasks)}") as stage_span:
                stage_span.set_attribute("agent.type", target_type)

            # Progress heartbeat — prints every 30 s so terminal looks alive during long model calls
            async def _heartbeat(action, target):
                import asyncio
                elapsed = 0
                while True:
                    await asyncio.sleep(30)
                    elapsed += 30
                    print(f"[{datetime.now().strftime('%H:%M:%S')}] [orchestrator] [INFO] "
                          f"Still waiting for {target} ({action}) — {elapsed}s elapsed...")
            hb_task = asyncio.create_task(_heartbeat(action, target_type))
            try:
                result = await self._send_and_wait(request, timeout=600.0)
            finally:
                hb_task.cancel()
            duration_ms = (time.time() - stage_start_time) * 1000

            if result:
                if result.message_type == MessageType.ERROR:
                    results[f"subtask_{i}"] = {
                        "status": "completed_with_error",
                        "response": {"raw_logs": "", "warning": getattr(result, 'error', str(result))},
                        "confidence": 0.0,
                        "orchestrator_skill": orchestrator_skill_name,
                    }
                    self.log(f"Subtask {action} returned ERROR: {getattr(result, 'error', 'unknown')}", "WARNING")
                    # Log error stage
                    if audit:
                        audit.log_pipeline_stage(
                            stage=action,
                            status="completed_with_error",
                            agent_type=target_type,
                            confidence=0.0,
                            duration_ms=duration_ms,
                            query_id=query_id,
                            query_preview=plan.get("original_query", ""),
                            input_type=input_info.get("input_type"),
                            stage_number=f"{i + 1}/{len(subtasks)}",
                            error=getattr(result, 'error', str(result)),
                        )
                else:
                    results[f"subtask_{i}"] = {
                        "status": "completed",
                        "agent_type": target_type,
                        "response": result.response if result.response else {"raw_logs": ""},
                        "confidence": result.confidence
                    }
                    # Log completed stage
                    if audit:
                        response_summary = {}
                        if result.response:
                            resp = result.response
                            response_summary = {
                                "has_raw_logs": bool(resp.get("raw_logs")),
                                "log_length": len(resp.get("raw_logs", "")),
                                "has_clean_logs": bool(resp.get("clean_logs")),
                                "log_type": resp.get("log_type"),
                                "format_detected": resp.get("format_detected"),
                            }
                        audit.log_pipeline_stage(
                            stage=action,
                            status="completed",
                            agent_type=target_type,
                            confidence=result.confidence,
                            duration_ms=duration_ms,
                            query_id=query_id,
                            query_preview=plan.get("original_query", ""),
                            input_type=input_info.get("input_type"),
                            stage_number=f"{i + 1}/{len(subtasks)}",
                            summary=response_summary,
                        )

                    if not result.response or not result.response.get("raw_logs"):
                        if result.confidence < 0.3:
                            self.log(f"Low confidence ({result.confidence}) and empty data — breaking pipeline",
                                     "WARNING")
                            pipeline_broken = True
            else:
                results[f"subtask_{i}"] = {
                    "status": "failed",
                    "error": "No response from agent",
                    "orchestrator_skill": orchestrator_skill_name,
                }
                if audit:
                    audit.log_pipeline_stage(
                        stage=action,
                        status="failed",
                        agent_type=target_type,
                        confidence=0.0,
                        duration_ms=duration_ms,
                        query_id=query_id,
                        query_preview=plan.get("original_query", ""),
                        input_type=input_info.get("input_type"),
                        stage_number=f"{i + 1}/{len(subtasks)}",
                        error="No response from agent",
                    )
                if action in ["extract", "preprocess"]:
                    pipeline_broken = True

            # Update merged_context after each subtask
            merged_context = _merge_results(results)
            merged_context["query"] = plan.get("original_query", "")

        # Multi-step reasoning: retry solve if critic confidence is low
        if not pipeline_broken:
            results = await self._retry_with_feedback(plan, results)

        return results

    async def _handle_web_approval_reply(self, decision: str) -> str:
        """
        Handle approval responses from ADK Web instead of terminal input.
        """

        if not getattr(self, "_pending_approvals", None):
            return "There is no pending approval request right now."

        # Get latest pending approval
        approval_id = list(self._pending_approvals.keys())[-1]
        item = self._pending_approvals.get(approval_id)

        if not item:
            return "Approval request was not found."

        approval_request = item["request"]

        if decision == "show diff":
            return (
                "Suggested change details:\n\n"
                f"Request ID: {approval_id}\n"
                f"File: {getattr(approval_request, 'file_path', 'N/A')}\n\n"
                f"Code Before:\n{getattr(approval_request, 'code_before', '') or 'N/A'}\n\n"
                f"Code After:\n{getattr(approval_request, 'code_after', '') or 'N/A'}\n\n"
                "Reply 'yes' to approve or 'no' to reject."
            )

        if decision == "yes":
            self._pending_approvals.pop(approval_id, None)

            return (
                "Approval received from ADK Web.\n\n"
                f"Request ID: {approval_id}\n"
                "The fix has been approved. "
                "Since this system is running in safe web mode, no file changes were automatically applied. "
                "Please review and apply the suggested fix manually."
            )

        if decision == "no":
            self._pending_approvals.pop(approval_id, None)

            return (
                "Fix rejected.\n\n"
                f"Request ID: {approval_id}\n"
                "No changes were applied."
            )

        return "Invalid approval response. Please reply with yes, no, or show diff."

    async def _send_and_wait(
        self, message: A2AMessage, timeout: float = 60.0
    ) -> Optional[A2AMessage]:
        """Send message via bus and wait for response"""
        response_future = asyncio.Future()

        if not hasattr(self, '_pending_responses'):
            self._pending_responses = {}
        self._pending_responses[message.message_id] = response_future

        # Send through Communication Bus (not direct call)
        await self.send_message(message)

        try:
            response = await asyncio.wait_for(response_future, timeout=timeout)
            return response
        except asyncio.TimeoutError:
            return None
        finally:
            self._pending_responses.pop(message.message_id, None)

    async def _aggregate_results(self, results: Dict, query: str) -> str:
        """Aggregate results from multiple agents"""
        summary_parts = []

        for key, result in results.items():
            try:
                if result.get("status") in ["completed", "needs_improvement"]:
                    if result.get("approval_blocked"):
                        summary_parts.append(
                            "Approval was not requested because the confidence score is below the required threshold.\n\n"
                            f"Confidence: {result.get('confidence', 0) * 100:.0f}%\n"
                            f"Reason: {result.get('approval_block_reason')}\n\n"
                            f"Recommendation: {result.get('recommendation')}"
                        )
                        continue

                    if result.get("approval_required"):
                        # FIX: include the actual analysis content first, then the approval prompt.
                        # The old code used `continue` which skipped all analysis content.
                        response_data = result.get("response", {})
                        if isinstance(response_data, dict):
                            root_cause = response_data.get("root_cause", {})
                            if isinstance(root_cause, dict):
                                summary_parts.append(f"Root Cause: {root_cause.get('primary_cause', 'N/A')}")
                                summary_parts.append(f"Severity: {root_cause.get('severity', 'N/A')}")
                                evidence = root_cause.get('evidence', [])
                                if evidence:
                                    summary_parts.append("Evidence:\n" + "\n".join(f"  - {e}" for e in evidence[:5]))
                            fix = response_data.get("fix_suggestion", {})
                            if isinstance(fix, dict):
                                summary_parts.append(f"Suggested Fix: {fix.get('change_description', 'N/A')}")
                                steps = fix.get("implementation_steps", [])
                                if steps:
                                    summary_parts.append("Steps:\n" + "\n".join(f"  {i+1}. {s}" for i, s in enumerate(steps[:5])))
                            explanation = response_data.get("explanation", "")
                            if explanation:
                                summary_parts.append(f"Explanation: {str(explanation)[:2000]}")
                        # Append approval prompt after the analysis content
                        summary_parts.append("\n" + result.get("approval_message", "Approval required."))
                        continue
                    response = result.get("response", {})
                    if isinstance(response, dict):
                        if "root_cause" in response:
                            root_cause = response["root_cause"]
                            if isinstance(root_cause, dict):
                                summary_parts.append(
                                    f"Root Cause: {root_cause.get('primary_cause', 'N/A')}"
                                )
                            elif isinstance(root_cause, str):
                                summary_parts.append(f"Root Cause: {root_cause[:2000000]}")
                        if "fix_suggestion" in response:
                            fix = response["fix_suggestion"]
                            if isinstance(fix, dict):
                                actions = fix.get('immediate_actions', [])
                                if actions:
                                    summary_parts.append(f"Fix: {actions[0]}")
                            elif isinstance(fix, str):
                                summary_parts.append(f"Fix: {fix[:2000000]}")
                        if "explanation" in response:
                            explanation = response["explanation"]
                            if isinstance(explanation, str):
                                summary_parts.append(str(explanation[:4000000]))
                        if "log_type" in response:
                            summary_parts.append(f"Type: {response['log_type']}")
                        if "severity" in response:
                            summary_parts.append(f"Severity: {response['severity']}")
                        if "summary" in response:
                            summary_parts.append(str(response["summary"])[:500000])
                    elif isinstance(response, str):
                        summary_parts.append(response[:500000])
                elif result.get("status") == "completed_with_error":
                    summary_parts.append(
                        f"Step completed with warning: {result.get('response', {}).get('warning', 'Unknown warning')}")
                elif result.get("status") == "skipped":
                    summary_parts.append(f"Step skipped: {result.get('reason', 'Previous step failed')}")
                else:
                    summary_parts.append(f"Step incomplete: {result.get('error', 'Unknown')}")
            except Exception as e:
                summary_parts.append(f"Error processing result {key}: {e}")

        # Try LLM aggregation if model available
        try:
            model = await self.get_model("gemma")
            if model and summary_parts:
                # Feed ALL summary parts (up to ~12000 chars) for complete context
                all_results = chr(10).join(summary_parts)
                if len(all_results) > 1200000:
                    all_results = all_results[:1200000] + "\n... (results truncated for length)"

                prompt = f"""Create a comprehensive, well-structured response from these analysis results.
        Include all key findings, root cause, fix suggestions, and actionable insights.

                            Query: {query}
                            Results: {all_results}

                            Response:"""
                final = await self._generate_with_tracking(model, prompt, max_tokens=2048, action_name="aggregate_results")
                final_text = final.text if hasattr(final, "text") else str(final)
                if final_text and len(final_text) > 50:
                    return final_text
        except Exception:
            pass

        return '\n\n'.join(summary_parts) if summary_parts else "Analysis complete."

    async def _store_in_memory(self, query: str, results: Dict):
        """
        Store completed analysis in ChromaDB via Memory Agent.
        Sends actual logs + analysis, not only the user query.
        """
        try:
            merged = _merge_results(results)

            clean_logs = (
                    merged.get("clean_logs")
                    or merged.get("raw_logs")
                    or merged.get("logs")
                    or query
                    or ""
            )

            log_type = (
                    merged.get("log_type")
                    or merged.get("format_detected")
                    or "unknown"
            )

            analysis_payload = {
                "query": query,
                "results": results,
                "merged_context": merged,
            }

            store_msg = A2AMessage.create_request(
                sender_id=self.agent_id,
                sender_type="orchestrator",
                target_type="memory",
                task={
                    "action": "store_log_analysis",
                    "query": query,
                    "log_content": clean_logs,
                    "analysis": analysis_payload,
                    "results": results,
                    "log_type": log_type,
                },
                context={
                    "clean_logs": clean_logs,
                    "raw_logs": merged.get("raw_logs", ""),
                    "log_type": log_type,
                    "solution": analysis_payload,
                },
            )

            await self.send_message(store_msg)
            self.log("Sent analysis to memory agent for ChromaDB storage", "DEBUG")

        except Exception as e:
            self.log(f"Memory store failed: {e}", "WARNING")

    async def _request_human_input(self, question: str) -> str:
        """
        Request input from human user.
        In ADK Web mode, never use terminal input().
        """
        if os.getenv("ADK_WEB_MODE", "false").lower() == "true":
            return (
                    "WEB_APPROVAL_REQUIRED: "
                    + question
                    + "\n\nPlease reply in ADK Web with: yes, no, or show diff."
            )

        print(f"\n🤔 {question}")
        return input("> ")

    def _get_capability_summary(self) -> str:
        """Get system capability summary"""
        return """
                🤖 I'm a specialized log analysis assistant. I can help with:
                
                📥 LOG EXTRACTION - Files, images (OCR), terminal output
                🧹 LOG PREPROCESSING - Clean, parse, structure logs
                🔍 LOG ANALYSIS - Classify errors, detect intent
                🔧 PROBLEM SOLVING - Root cause analysis, fix suggestions
                🛡️ VALIDATION - Quality checks, safety audits
                💾 MEMORY - Store and retrieve past analyses
                
                How can I help with your logs today?
                """