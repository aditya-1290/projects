"""
Approval Gate — Human-in-the-loop for auto-remediation.

Before any code patch is applied, the system requests explicit
approval from the user/admin. No fix is ever applied automatically.

Approval methods:
  - CLI prompt (for terminal usage)
  - Webhook callback (for Slack/Teams/Discord)
  - API endpoint (for custom frontends)
  - Auto-approve for low-risk fixes (configurable)
"""

import json
from typing import Dict, Optional, Callable
from enum import Enum
from datetime import datetime


class ApprovalStatus(Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    EXPIRED = "expired"
    AUTO_APPROVED = "auto_approved"


class ApprovalRequest:
    """A request for human approval before applying a fix."""

    def __init__(
        self,
        request_id: str,
        query: str,
        root_cause: str,
        fix_description: str,
        code_before: str = "",
        code_after: str = "",
        file_path: str = "",
        risk_level: str = "medium",
        confidence: float = 0.0,
        auto_approve_threshold: float = 0.95,
    ):
        self.request_id = request_id
        self.query = query[:200]
        self.root_cause = root_cause
        self.fix_description = fix_description
        self.code_before = code_before
        self.code_after = code_after
        self.file_path = file_path
        self.risk_level = risk_level
        self.confidence = confidence
        self.auto_approve_threshold = auto_approve_threshold
        self.status = ApprovalStatus.PENDING
        self.created_at = datetime.utcnow().isoformat()
        self.approved_at = None
        self.approved_by = None

    def should_auto_approve(self) -> bool:
        """Auto-approve if confidence is very high and risk is low."""
        return (
            self.confidence >= self.auto_approve_threshold
            and self.risk_level == "low"
        )

    def to_dict(self) -> Dict:
        return {
            "request_id": self.request_id,
            "query": self.query,
            "root_cause": self.root_cause,
            "fix_description": self.fix_description,
            "code_before": self.code_before,
            "code_after": self.code_after,
            "file_path": self.file_path,
            "risk_level": self.risk_level,
            "confidence": self.confidence,
            "status": self.status.value,
            "created_at": self.created_at,
            "approved_at": self.approved_at,
        }


class ApprovalGate:
    """
    Manages the approval workflow for code patches.

    Usage:
        gate = ApprovalGate()

        # Create approval request
        request = gate.create_request(
            query="logs/error.log",
            root_cause="NullPointerException in auth.py",
            fix_description="Add null check before DB call",
            code_before="result = db.query()",
            code_after="if db is None: return\nresult = db.query()",
            risk_level="low",
            confidence=0.92
        )

        # Request approval from user
        approved = await gate.request_approval(request)

        if approved:
            gate.apply_fix(request)
    """

    def __init__(self, auto_approve_threshold: float = 0.95):
        self.auto_approve_threshold = auto_approve_threshold
        self.pending_requests: Dict[str, ApprovalRequest] = {}
        self.approval_history: list = []
        self._webhook_url: Optional[str] = None
        self._approval_callback: Optional[Callable] = None

    def set_webhook(self, url: str):
        """Set a webhook URL for Slack/Teams notifications."""
        self._webhook_url = url

    def set_callback(self, callback: Callable):
        """Set a custom approval callback function."""
        self._approval_callback = callback

    def create_request(
        self,
        query: str,
        root_cause: str,
        fix_description: str,
        code_before: str = "",
        code_after: str = "",
        file_path: str = "",
        risk_level: str = "medium",
        confidence: float = 0.0,
    ) -> ApprovalRequest:
        """Create a new approval request."""
        import uuid

        request = ApprovalRequest(
            request_id=str(uuid.uuid4())[:8],
            query=query,
            root_cause=root_cause,
            fix_description=fix_description,
            code_before=code_before,
            code_after=code_after,
            file_path=file_path,
            risk_level=self._assess_risk(code_before, code_after),
            confidence=confidence,
            auto_approve_threshold=self.auto_approve_threshold,
        )

        self.pending_requests[request.request_id] = request
        return request

    async def request_approval(self, request: ApprovalRequest) -> bool:
        """
        Request approval from the user.

        Returns True if approved, False if rejected.
        """
        # Check auto-approve
        if request.should_auto_approve():
            request.status = ApprovalStatus.AUTO_APPROVED
            request.approved_at = datetime.utcnow().isoformat()
            request.approved_by = "auto"
            self.approval_history.append(request.to_dict())
            print(f"[APPROVAL] Auto-approved: {request.fix_description[:80]}")
            return True

        # Try webhook first
        if self._webhook_url:
            sent = await self._send_webhook(request)
            if sent:
                # In production, webhook would wait for response
                # For now, fall through to CLI
                pass

        # Try callback
        if self._approval_callback:
            return await self._approval_callback(request)

        # Default: CLI prompt
        return self._cli_approval(request)

    def _cli_approval(self, request: ApprovalRequest) -> bool:
        """Request approval via CLI prompt."""
        print(f"""
╔══════════════════════════════════════════════════════════════╗
║                   APPROVAL REQUIRED                         ║
╠══════════════════════════════════════════════════════════════╣
║ Request ID: {request.request_id}
║ Risk Level:  {request.risk_level.upper()}
║ Confidence:  {request.confidence:.0%}
╠══════════════════════════════════════════════════════════════╣
║ Root Cause: {request.root_cause[:80]}
║ Fix:        {request.fix_description[:80]}
╠══════════════════════════════════════════════════════════════╣
║ Code Before: {request.code_before[:60]}
║ Code After:  {request.code_after[:60]}
║ File:        {request.file_path or 'N/A'}
╚══════════════════════════════════════════════════════════════╝
""")

        while True:
            choice = input("Apply this fix? (yes/no/show diff): ").strip().lower()

            if choice in ("yes", "y"):
                request.status = ApprovalStatus.APPROVED
                request.approved_at = datetime.utcnow().isoformat()
                request.approved_by = "cli_user"
                self.approval_history.append(request.to_dict())
                return True

            elif choice in ("no", "n"):
                request.status = ApprovalStatus.REJECTED
                self.approval_history.append(request.to_dict())
                print("[APPROVAL] Fix rejected by user.")
                return False

            elif choice in ("show diff", "diff", "d"):
                self._show_diff(request)

            else:
                print("Please answer: yes, no, or show diff")

    def _show_diff(self, request: ApprovalRequest):
        """Display the code diff."""
        print("\n" + "-" * 50)
        print("--- BEFORE")
        print(request.code_before or "(no code provided)")
        print("+++ AFTER")
        print(request.code_after or "(no code provided)")
        print("-" * 50 + "\n")

    async def _send_webhook(self, request: ApprovalRequest) -> bool:
        """Send approval request to webhook (Slack/Teams)."""
        try:
            import httpx

            payload = {
                "text": f"🔔 *Approval Required* — {request.risk_level.upper()} risk\n"
                        f"*Request ID:* {request.request_id}\n"
                        f"*Root Cause:* {request.root_cause}\n"
                        f"*Fix:* {request.fix_description}\n"
                        f"*Confidence:* {request.confidence:.0%}\n"
                        f"*File:* {request.file_path or 'N/A'}",
                "attachments": [
                    {
                        "text": f"```{request.code_before}``` → ```{request.code_after}```",
                        "fallback": "Code diff available in CLI",
                        "color": "warning"
                    }
                ]
            }

            async with httpx.AsyncClient() as client:
                await client.post(self._webhook_url, json=payload, timeout=10)
            return True
        except Exception:
            return False

    def _assess_risk(self, code_before: str, code_after: str) -> str:
        """Auto-assess risk level of a code change."""
        low_risk_indicators = [
            "print(", "log.", "logger.", "logging.",
            "comment", "#", "TODO", "FIXME",
        ]
        high_risk_indicators = [
            "rm ", "delete", "DROP ", "TRUNCATE",
            "sudo", "chmod", "chown", "kill",
            "rmtree", "os.remove", "shutil.rmtree",
        ]

        combined = (code_before + code_after).lower()

        if any(ind.lower() in combined for ind in high_risk_indicators):
            return "high"

        if any(ind.lower() in combined for ind in low_risk_indicators):
            return "low"

        return "medium"

    def get_pending(self) -> list:
        """Get all pending approval requests."""
        return [
            r.to_dict() for r in self.pending_requests.values()
            if r.status == ApprovalStatus.PENDING
        ]

    def get_history(self, limit: int = 10) -> list:
        """Get approval history."""
        return self.approval_history[-limit:]
