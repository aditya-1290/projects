from pathlib import Path
from typing import Any, Dict, List
import uuid
import uvicorn

import requests
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles

BASE_DIR = Path(__file__).resolve().parent

ADK_BACKEND_URL = "http://127.0.0.1:8002"

app = FastAPI(title="ADK Log Analyzer UI")

app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))


def get_backend_history() -> List[Dict[str, Any]]:
    try:
        res = requests.get(f"{ADK_BACKEND_URL}/history-json", timeout=10)
        res.raise_for_status()
        return res.json().get("history", [])
    except Exception as exc:
        print("[UI] Failed to load backend history", exc)
        return []

def find_session(history: List[Dict[str, Any]], session_id: str) -> Dict[str, Any] | None:
    for item in history:
        if item.get("session_id") == session_id:
            return item
    return None

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    session_id = str(uuid.uuid4())

    return templates.TemplateResponse(
        "index.html",
        {
            "request": request,
            "query": "",
            "result": None,
            "error": None,
            "session_id": session_id,
            "history": get_backend_history(),
            "messages": [],
        },
    )


@app.get("/c/{session_id}", response_class=HTMLResponse)
async def load_session(request: Request, session_id: str):
    history = get_backend_history()
    selected = find_session(history, session_id)
    messages = selected.get("messages", []) if selected else []

    return templates.TemplateResponse(
        "index.html",
        {
            "request": request,
            "query": selected.get("query", "") if selected else "",
            "result": selected.get("response", "") if selected else None,
            "error": None,
            "session_id": session_id,
            "history": history,
            "messages": messages,
        },
    )


@app.post("/run")
async def proxy_run(request: Request):
    body = await request.json()
    query = body.get("query", "")
    session_id = body.get("session_id") or str(uuid.uuid4())

    try:
        res = requests.post(f"{ADK_BACKEND_URL}/run",
            json={"query": query, "session_id": session_id}, timeout=3000)
        data = res.json()
        return JSONResponse(data, status_code=res.status_code)

    except Exception as e:
            return JSONResponse({
                "response": f"ADK backend call failed: {e}",
                "session_id": session_id},
                status_code=500
            )


@app.get("/history-json")
async def proxy_history_json():
    try:
        res = requests.get(f"{ADK_BACKEND_URL}/history-json", timeout=10)
        res.raise_for_status()
        return res.json()
    except Exception as exc:
        return {"history": [], "error": str(exc)}


@app.delete("/history/{session_id}")
async def proxy_delete_history(session_id: str):
    try:
        res = requests.delete(f"{ADK_BACKEND_URL}/history/{session_id}", timeout=10)
        return JSONResponse(res.json(), status_code=res.status_code)
    except Exception as exc:
        return JSONResponse({"status": "error", "message": str(exc)}, status_code=500)


@app.post("/history/{session_id}/rename")
async def proxy_rename_history(session_id: str, request: Request):

    try:
        body = await request.json()
        title = str(body.get("title", "")).strip()

        if not title:
            return JSONResponse(
                {"status": "error", "message": "Title is required"},
                status_code=400,
            )

        print(f"[UI] Rename request: session_id={session_id}, title={title}")

        res = requests.post(
            f"{ADK_BACKEND_URL}/history/{session_id}/rename",
            json={"title": title},
            timeout=10,
        )

        try:
            data = res.json()
        except Exception:
            data = {
                "status": "error",
                "message": res.text,
            }

        print(f"[UI] Backend rename response: {data}")

        return JSONResponse(data, status_code=res.status_code)

    except Exception as exc:
        print("[UI] Rename failed:", exc)
        return JSONResponse(
            {"status": "error", "message": str(exc)},
            status_code=500,
        )

@app.get("/health")
async def ui_health():
    try:
        res = requests.get(f"{ADK_BACKEND_URL}/health")
        return {"ui": "healthy", "backend": res.json()}
    except Exception as exc:
        return {"ui": "healthy", "backend_error": str(exc)}


if __name__ == "__main__":
    uvicorn.run(
        "adk_template_server:app",
        host="127.0.0.1",
        port=8004,
        reload=True
    )