# mcp_tools/elasticsearch_cloud_mcp_server.py

import os
import json
import asyncio
from dotenv import load_dotenv
from elasticsearch import AsyncElasticsearch
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

load_dotenv()

app = Server("elastic-cloud-log-mcp")

ES_INDEX = os.getenv("ELASTICSEARCH_INDEX", "logs-*")

client = AsyncElasticsearch(
    cloud_id=os.getenv("ELASTICSEARCH_CLOUD_ID"),
    api_key=os.getenv("ES_API_KEY"),
    verify_certs=os.getenv("ELASTICSEARCH_VERIFY_CERTS", "true").lower() == "true",
)


@app.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="ping_elasticsearch",
            description="Check whether Elastic Cloud Elasticsearch is connected.",
            inputSchema={"type": "object", "properties": {}},
        ),
        Tool(
            name="list_indices",
            description="List Elasticsearch indices.",
            inputSchema={
                "type": "object",
                "properties": {
                    "pattern": {"type": "string", "default": "*"}
                },
            },
        ),
        Tool(
            name="search_logs",
            description="Search logs from Elastic Cloud using a keyword query.",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {"type": "string"},
                    "index": {"type": "string", "default": ES_INDEX},
                    "size": {"type": "integer", "default": 20},
                },
                "required": ["query"],
            },
        ),
        Tool(
            name="recent_errors",
            description="Fetch recent error logs from Elastic Cloud.",
            inputSchema={
                "type": "object",
                "properties": {
                    "index": {"type": "string", "default": ES_INDEX},
                    "size": {"type": "integer", "default": 20},
                },
            },
        ),
        Tool(
            name="search_logs_dsl",
            description="Search logs using raw Elasticsearch Query DSL.",
            inputSchema={
                "type": "object",
                "properties": {
                    "index": {"type": "string", "default": ES_INDEX},
                    "dsl": {"type": "object"},
                },
                "required": ["dsl"],
            },
        ),
        Tool(
            name="get_index_mapping",
            description="Get Elasticsearch index mapping.",
            inputSchema={
                "type": "object",
                "properties": {
                    "index": {"type": "string"}
                },
                "required": ["index"],
            },
        ),
    ]


@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    try:
        if name == "ping_elasticsearch":
            info = await client.info()
            return [TextContent(type="text", text=json.dumps({
                "success": True,
                "cluster_name": info.get("cluster_name"),
                "version": info.get("version", {}).get("number"),
                "source": "elastic_cloud"
            }, indent=2))]

        if name == "list_indices":
            pattern = arguments.get("pattern", "*")
            result = await client.cat.indices(index=pattern, format="json")
            return [TextContent(type="text", text=json.dumps(result.body, indent=2))]

        if name == "search_logs":
            query = arguments["query"]
            index = arguments.get("index", ES_INDEX)
            size = arguments.get("size", 20)

            body = {
                "size": size,
                "sort": [{"@timestamp": {"order": "desc", "unmapped_type": "date"}}],
                "query": {
                    "query_string": {
                        "query": query,
                        "default_field": "*"
                    }
                }
            }

            result = await client.search(index=index, body=body)
            hits = result.get("hits", {}).get("hits", [])

            logs = [
                {
                    "index": hit.get("_index"),
                    "score": hit.get("_score"),
                    "source": hit.get("_source", {})
                }
                for hit in hits
            ]

            return [TextContent(type="text", text=json.dumps({
                "count": len(logs),
                "logs": logs
            }, indent=2, default=str))]

        if name == "recent_errors":
            index = arguments.get("index", ES_INDEX)
            size = arguments.get("size", 20)

            body = {
                "size": size,
                "sort": [{"@timestamp": {"order": "desc", "unmapped_type": "date"}}],
                "query": {
                    "bool": {
                        "should": [
                            {"match": {"level": "ERROR"}},
                            {"match": {"severity": "ERROR"}},
                            {"match": {"message": "error"}},
                            {"match": {"message": "exception"}},
                            {"exists": {"field": "exception"}},
                            {"exists": {"field": "stack_trace"}}
                        ],
                        "minimum_should_match": 1
                    }
                }
            }

            result = await client.search(index=index, body=body)
            hits = result.get("hits", {}).get("hits", [])

            return [TextContent(type="text", text=json.dumps({
                "count": len(hits),
                "logs": [hit.get("_source", {}) for hit in hits]
            }, indent=2, default=str))]

        if name == "search_logs_dsl":
            index = arguments.get("index", ES_INDEX)
            dsl = arguments["dsl"]

            result = await client.search(index=index, body=dsl)
            return [TextContent(type="text", text=json.dumps(result.body, indent=2, default=str))]

        if name == "get_index_mapping":
            index = arguments["index"]
            mapping = await client.indices.get_mapping(index=index)
            return [TextContent(type="text", text=json.dumps(mapping.body, indent=2, default=str))]

        return [TextContent(type="text", text=f"Unknown tool: {name}")]

    except Exception as e:
        return [TextContent(type="text", text=f"Elasticsearch MCP error: {str(e)}")]


async def main():
    async with stdio_server() as streams:
        read_stream, write_stream = streams
        await app.run(read_stream, write_stream, app.create_initialization_options())


if __name__ == "__main__":
    asyncio.run(main())