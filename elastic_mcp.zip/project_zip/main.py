#!/usr/bin/env python3
"""
Log Analysis Multi-Agent System - Entry Point

TRULY DECENTRALIZED:
- Agents communicate ONLY through the Communication Bus
- No agent ever imports another agent directly
- Agents are discovered at runtime, not import time
- Missing agents are handled gracefully
- The system works with whatever agents are available
"""

import asyncio
import sys
import os
from pathlib import Path
from utils.tracing import setup_tracing

sys.path.insert(0, str(Path(__file__).parent))

from config import *
from utils.response_formatter import ResponseFormatter


class SystemBootstrap:
    """
    Bootstraps the system.

    THIS IS THE ONLY FILE THAT IMPORTS AGENT CLASSES.
    Individual agents NEVER import each other.

    Missing agents (being built by other team members) are handled gracefully.
    """

    # Define all expected agents with their import paths
    # This is a REGISTRY, not a dependency
    AGENT_REGISTRY = [
        {
            "name": "extractor",
            "module": "agents.extractor.agent",
            "class": "ExtractorAgent",
            "built_by": "Person C",
            "required": True
        },
        {
            "name": "preprocessor",
            "module": "agents.preprocessor.agent",
            "class": "PreprocessorAgent",
            "built_by": "You",
            "required": True
        },
        {
            "name": "analyzer",
            "module": "agents.analyzer.agent",
            "class": "AnalyzerAgent",
            "built_by": "Person B",
            "required": True  # Can work without it
        },
        {
            "name": "solver",
            "module": "agents.solver.agent",
            "class": "SolverAgent",
            "built_by": "You",
            "required": True
        },
        {
            "name": "debugger",
            "module": "agents.debugger.agent",
            "class": "DebuggerAgent",
            "built_by": "Person B",
            "required": True  # Can work without it
        },
        {
            "name": "critic",
            "module": "agents.critic.agent",
            "class": "CriticAgent",
            "built_by": "You",
            "required": True
        },
        {
            "name": "memory",
            "module": "agents.memory.agent",
            "class": "MemoryAgent",
            "built_by": "You",
            "required": True
        },
        {
            "name": "orchestrator",
            "module": "agents.orchestrator.agent",
            "class": "OrchestratorAgent",
            "built_by": "You",
            "required": True
        }
    ]

    @classmethod
    async def create_all_agents(cls, model_manager, communication_bus):
        """
        Dynamically load and register all available agents.

        Agents that are not yet built (by other team members)
        are skipped gracefully with a clear message.
        """
        agents = []
        orchestrator = None
        loaded_count = 0
        missing_count = 0

        print("\n📦 Loading agents...\n")

        for agent_info in cls.AGENT_REGISTRY:
            agent_name = agent_info["name"]
            module_path = agent_info["module"]
            class_name = agent_info["class"]
            built_by = agent_info["built_by"]
            required = agent_info["required"]

            try:
                # Dynamically import the agent module
                import importlib
                module = importlib.import_module(module_path)
                agent_class = getattr(module, class_name)

                # Create instance
                agent = agent_class()
                agent.model_manager = model_manager

                # Register with communication bus
                await communication_bus.register_agent(agent)
                agents.append(agent)
                loaded_count += 1

                # Track orchestrator
                if agent_name == "orchestrator":
                    orchestrator = agent

                status = "✅" if required else "🟡"
                print(f"   {status} {agent_name:<15} ({agent.capability.agent_name})")

            except ImportError as e:
                missing_count += 1
                if required:
                    print(f"   ❌ {agent_name:<15} NOT FOUND [{built_by}] - REQUIRED!")
                    print(f"      Module: {module_path}")
                    print(f"      Error: {e}")
                else:
                    print(f"   ⚠️  {agent_name:<15} not available [{built_by}] - optional")

            except Exception as e:
                missing_count += 1
                if required:
                    print(f"   ❌ {agent_name:<15} FAILED TO LOAD [{built_by}]")
                    print(f"      Error: {e}")
                else:
                    print(f"   ⚠️  {agent_name:<15} failed [{built_by}] - optional")

        print(f"\n   Loaded: {loaded_count} | Missing: {missing_count}")

        # Check critical agents
        if not orchestrator:
            raise RuntimeError(
                "❌ CRITICAL: Orchestrator agent failed to load!\n"
                "   The system cannot run without the orchestrator."
            )

        # Check required agents
        required_missing = []
        for agent_info in cls.AGENT_REGISTRY:
            if agent_info["required"]:
                agent_name = agent_info["name"]
                if not any(a.agent_id.startswith(agent_name) for a in agents):
                    required_missing.append(agent_name)

        if required_missing:
            print(f"\n⚠️  WARNING: Required agents missing: {', '.join(required_missing)}")
            print("   The system will run but some functionality will be unavailable.")

        return agents, orchestrator


class LogAnalysisCLI:
    """CLI interface for the log analysis system"""

    def __init__(self, model_manager, communication_bus, orchestrator):
        self.model_manager = model_manager
        self.bus = communication_bus
        self.orchestrator = orchestrator

    async def run(self):
        """Main CLI loop"""
        print("\n" + "=" * 60)
        print("✅ SYSTEM READY")
        print("=" * 60)

        # Check which agents are available
        bus_status = await self.bus.get_status()
        agent_names = [a.get("type", "unknown") for a in bus_status.get("agents", [])]

        print(f"""
    📊 ACTIVE AGENTS: {len(agent_names)}
       {', '.join(agent_names)}

    💡 QUICK START:
       • Paste log entries to analyze (type 'END' on a new line to finish)
       • Type a single line for questions
       • Provide a file path: logs/error.log
       • Type 'help' for full command list
       • Type 'status' for system status
       • Type 'quit' to exit

    💡 MULTI-LINE INPUT:
       Start typing/pasting your logs.
       Type 'END' (uppercase) on a new line when done.
       Or type '---' (triple dash) to finish.
    """)

        while True:
            try:
                # Check if input might be multi-line
                first_line = input(CLI_PROMPT).strip()

                if not first_line:
                    continue

                # Commands
                if first_line.lower() == 'quit':
                    break
                elif first_line.lower() == 'help':
                    self._print_help()
                    continue
                elif first_line.lower() == 'status':
                    await self._print_status()
                    continue
                elif first_line.lower() == 'agents':
                    await self._print_agents()
                    continue
                elif first_line.lower() == 'clear':
                    os.system('clear' if os.name != 'nt' else 'cls')
                    continue

                # Check if this is a multi-line input
                # Detect if first line looks like a log entry
                is_multiline = self._looks_like_log(first_line)

                if is_multiline:
                    user_input = self._read_multi_line(first_line)
                else:
                    user_input = first_line

                # Process query through orchestrator
                print(f"\n⏳ Processing {len(user_input)} characters...\n")

                response = await self.orchestrator.handle_user_query(user_input)

                print(f"{response}\n")
                print("-" * 60)

            except KeyboardInterrupt:
                print("\n\nShutting down...")
                break
            except Exception as e:
                print(f"\n❌ Error: {e}\n")

    def _looks_like_log(self, first_line: str) -> bool:
        """
        Detect if the input looks like a log entry (multi-line expected).
        """
        import re

        indicators = [
            # Timestamps
            r'\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}',
            r'\d{2}/\d{2}/\d{4}\s+\d{2}:\d{2}:\d{2}',
            r'\w{3}\s+\d+\s+\d{2}:\d{2}:\d{2}',
            # Log levels
            r'\b(ERROR|WARN|INFO|DEBUG|FATAL|CRITICAL|TRACE)\b',
            # Stack traces
            r'Traceback\s+\(most\s+recent',
            r'^\s+File\s+"',
            r'^\s+\^+$',
            # Error patterns
            r'\w+Error:',
            r'\w+Exception:',
            r'Caused by:',
            # Bracketed content
            r'^\[.*\]\s+\w+',
        ]

        for pattern in indicators:
            if re.search(pattern, first_line, re.IGNORECASE):
                return True

        return False

    def _read_multi_line(self, first_line: str) -> str:
        """
        Read multiple lines of input.
        Terminates on 'END', '---', or empty line after log content.
        """
        lines = [first_line]
        print("   (Paste your logs. Type 'END' or '---' on a new line to finish)")

        empty_line_count = 0
        max_empty_lines = 1  # Allow 1 empty line before auto-finishing

        while True:
            try:
                line = input()

                # Check for termination markers
                if line.strip().upper() == 'END':
                    break
                if line.strip() == '---':
                    break

                # Auto-detect end of log paste
                if line.strip() == '':
                    empty_line_count += 1
                    if empty_line_count > max_empty_lines:
                        break
                    lines.append(line)
                else:
                    empty_line_count = 0
                    lines.append(line)

            except EOFError:
                break
            except KeyboardInterrupt:
                break

        return '\n'.join(lines)

    def _print_help(self):
        """Print help"""
        print("""
📚 COMMANDS
═══════════════════════════════════════

📝 LOG ANALYSIS:
   Paste logs directly or provide a file path.

   Examples:
   > logs/application_error.log
   > [2024-01-15 14:32:11] ERROR database: Connection refused
   > What caused this NullPointerException?
   > Explain this error in simple terms

🖼️  IMAGE ANALYSIS:
   > screenshots/error.png

🖥️  SYSTEM COMMANDS:
   help    - This menu
   status  - System status  
   agents  - List active agents
   clear   - Clear screen
   quit    - Exit

💡 The system automatically:
   1. Extracts logs from your input
   2. Preprocesses and cleans them
   3. Classifies the error type
   4. Finds the root cause
   5. Suggests fixes
   6. Validates the solution
""")

    async def _print_status(self):
        """Print system status"""
        model_status = self.model_manager.get_status()
        bus_status = await self.bus.get_status()

        print(f"""
📊 SYSTEM STATUS
═══════════════════════════════════════

🧠 MODELS:
   Memory: {model_status.get('current_usage_gb', 'N/A')}GB / {model_status.get('max_memory_gb', 'N/A')}GB
   Loaded: {model_status.get('total_loads', 'N/A')}

🤖 AGENTS:
   Registered: {bus_status.get('registered_agents', 0)}

📬 MESSAGES:
   Sent: {bus_status.get('stats', {}).get('messages_sent', 0)}
   Delivered: {bus_status.get('stats', {}).get('messages_delivered', 0)}
""")

    async def _print_agents(self):
        """Print registered agents"""
        bus_status = await self.bus.get_status()
        agents = bus_status.get('agents', [])

        print("\n🤖 REGISTERED AGENTS")
        print("═" * 40)

        for agent in agents:
            state_emoji = {
                "idle": "🟢",
                "processing": "🔄",
                "error": "🔴"
            }.get(agent.get('state', ''), '⚪')

            print(f"\n{state_emoji} {agent.get('type', 'unknown')} ({agent.get('id', 'no-id')})")

            caps = agent.get('capabilities', [])
            if caps:
                print(f"   {', '.join(caps[:4])}")
                if len(caps) > 4:
                    print(f"   ... and {len(caps) - 4} more")
        print()


async def main():
    """Main entry point"""
    print("""
╔══════════════════════════════════════════════════════════════╗
║               LOG ANALYSIS MULTI-AGENT SYSTEM                ║
║           Decentralized • A2A Protocol • Multi-Model         ║
╚══════════════════════════════════════════════════════════════╝
""")
    # In main(), right after the banner:
    setup_tracing("log-analysis-multi-agent")

    try:
        # 1. Initialize Model Manager
        print("[1/4] Initializing Model Manager...")
        from models.manager import ModelManager
        model_manager = ModelManager(max_memory_gb=MAX_MEMORY_GB)
        await model_manager.initialize()

        # 2. Initialize Communication Bus
        print("\n[2/4] Initializing Communication Bus...")
        from agentos.communication_bus import CommunicationBus
        bus = CommunicationBus()

        # 3. Dynamically load all available agents
        print("\n[3/4] Loading agents (missing agents will be skipped)...")
        agents, orchestrator = await SystemBootstrap.create_all_agents(
            model_manager, bus
        )

        # 4. Start the bus
        print("\n[4/4] Starting communication bus...")
        await bus.start()

        # Initialize orchestrator
        if orchestrator:
            await orchestrator.initialize()

        # Run CLI
        cli = LogAnalysisCLI(model_manager, bus, orchestrator)
        await cli.run()

    except Exception as e:
        print(f"\n❌ FATAL ERROR: {e}")
        import traceback
        traceback.print_exc()
    finally:
        if 'bus' in locals():
            await bus.stop()
        print("\n👋 Goodbye!\n")


if __name__ == "__main__":
    asyncio.run(main())
