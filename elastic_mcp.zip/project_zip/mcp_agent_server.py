"""
MCP Agent Server — Standalone MCP server that loads all 8 agents directly.

Use this when you want to run the full multi-agent system in a separate
terminal as an MCP server (e.g. for Claude Desktop, Cursor, or any MCP host),
WITHOUT needing adk_server.py or mcp_proxy.py running at all.

This is the self-contained alternative to mcp_proxy.py.
mcp_proxy.py requires adk_server.py to already be running — this does not.

Usage:
    python mcp_agent_server.py

MCP Tools exposed:
    orchestrator_analyze   — Full pipeline (extract→preprocess→analyze→solve→validate)
    extractor_extract      — Extract logs from file, image, terminal, text, or ES
    preprocessor_process   — Clean, parse, and normalise raw logs
    analyzer_analyze       — Classify log type, detect intent, assess severity
    solver_solve           — Root cause analysis + fix generation
    debugger_debug         — Stack trace parsing + code patch generation
    critic_validate        — Validate solution quality and safety
    memory_search          — Store/retrieve past analyses from ChromaDB
"""

import os
import sys
import asyncio
import json
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
# Redirect stdout to stderr so MCP stdio transport is not polluted by prints
sys.stdout = sys.stderr

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

# ═══════════════════════════════════════════════════════════════════════════════
# Lazy system initialisation (loads once on first tool call)
# ═══════════════════════════════════════════════════════════════════════════════

_system = None
_init_lock = asyncio.Lock()


async def _get_system():
    """Initialise the agent system once and cache it."""
    global _system
    if _system is not None:
        return _system

    async with _init_lock:
        if _system is not None:
            return _system

        from models.manager import ModelManager
        from agentos.communication_bus import CommunicationBus
        from main import SystemBootstrap

        print("[MCP Agent Server] Loading agents...", file=sys.stderr)

        # Skip OCR and embedding at startup to load faster
        from models.model_configs import MODELS
        _ocr_flag = MODELS["deepseek_ocr"].load_on_startup
        _emb_flag  = MODELS["embedding"].load_on_startup
        MODELS["deepseek_ocr"].load_on_startup = False
        MODELS["embedding"].load_on_startup    = False

        from config import MAX_MEMORY_GB
        model_manager = ModelManager(max_memory_gb=MAX_MEMORY_GB)
        await model_manager.initialize()

        MODELS["deepseek_ocr"].load_on_startup = _ocr_flag
        MODELS["embedding"].load_on_startup    = _emb_flag

        bus = CommunicationBus()
        agents, orchestrator = await SystemBootstrap.create_all_agents(model_manager, bus)
        await bus.start()

        if orchestrator:
            await orchestrator.initialize()

        _system = {
            "bus":          bus,
            "agents":       agents,
            "orchestrator": orchestrator,
        }

        print(f"[MCP Agent Server] Ready — {len(agents)} agents loaded", file=sys.stderr)
        return _system


def _get_agent(agent_type: str):
    """Return a specific agent from the bus by its agent_name."""
    if _system is None:
        return None
    for agent in _system["bus"].agents.values():
        if agent.capability.agent_name == agent_type:
            return agent
    return None


def _make_msg(agent, action: str, extra: dict):
    """Build an A2AMessage for a given agent."""
    from agents.base_agent import A2AMessage, MessageType
    return A2AMessage(
        message_type=MessageType.REQUEST,
        sender_id="mcp_agent_server",
        sender_type="external",
        target_id=agent.agent_id,
        task={"action": action, **extra},
    )


# ═══════════════════════════════════════════════════════════════════════════════
# MCP Server definition
# ═══════════════════════════════════════════════════════════════════════════════

app = Server("log-analysis-agent-server")


@app.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="orchestrator_analyze",
            description=(
                "Run the complete log analysis pipeline. Provide a log file path, "
                "pasted log content, terminal command, image path, or a plain question. "
                "Returns root cause, fix steps, and confidence score."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": (
                            "Log entries, file path, terminal command (command:…), "
                            "image path, or ES query (elastic:… / json:… / chromadb:…)"
                        )
                    },
                    "session_id": {
                        "type": "string",
                        "description": "Optional session ID for multi-turn conversations"
                    }
                },
                "required": ["query"]
            }
        ),
        Tool(
            name="extractor_extract",
            description="Extract log content from a file, image, terminal command, pasted text, or Elasticsearch.",
            inputSchema={
                "type": "object",
                "properties": {
                    "source_type": {
                        "type": "string",
                        "enum": ["auto", "file", "image", "terminal", "text", "elasticsearch"],
                        "description": "Source type to extract from"
                    },
                    "file_path":  {"type": "string", "description": "Path to file or image"},
                    "command":    {"type": "string", "description": "Terminal command to run"},
                    "content":    {"type": "string", "description": "Pasted log text"},
                    "es_query":   {"type": "string", "description": "Elasticsearch Lucene query"}
                }
            }
        ),
        Tool(
            name="preprocessor_process",
            description="Clean, parse, normalise, and chunk raw log entries.",
            inputSchema={
                "type": "object",
                "properties": {
                    "raw_logs": {"type": "string", "description": "Raw log content to preprocess"}
                },
                "required": ["raw_logs"]
            }
        ),
        Tool(
            name="analyzer_analyze",
            description="Classify log type, detect user intent, assess severity, and identify patterns.",
            inputSchema={
                "type": "object",
                "properties": {
                    "clean_logs": {"type": "string", "description": "Preprocessed log content"}
                },
                "required": ["clean_logs"]
            }
        ),
        Tool(
            name="solver_solve",
            description="Find root cause, generate actionable fix steps, and explain the error.",
            inputSchema={
                "type": "object",
                "properties": {
                    "clean_logs": {"type": "string", "description": "Preprocessed log content"},
                    "log_type":   {"type": "string", "description": "Detected log type"},
                    "intent": {
                        "type": "string",
                        "enum": ["debugging", "explanation", "optimization", "security_audit", "health_check"]
                    }
                },
                "required": ["clean_logs"]
            }
        ),
        Tool(
            name="debugger_debug",
            description="Parse a stack trace and generate a code patch with language-specific analysis.",
            inputSchema={
                "type": "object",
                "properties": {
                    "stack_trace": {"type": "string", "description": "Stack trace text"},
                    "source_code": {"type": "string", "description": "Optional source code for context"},
                    "language": {
                        "type": "string",
                        "enum": ["python", "java", "javascript", "typescript", "go", "auto"]
                    }
                },
                "required": ["stack_trace"]
            }
        ),
        Tool(
            name="critic_validate",
            description="Validate a proposed solution for correctness, completeness, and safety.",
            inputSchema={
                "type": "object",
                "properties": {
                    "solution": {
                        "type": "object",
                        "description": "Solution dict with root_cause, fix_suggestion, explanation"
                    },
                    "original_logs": {"type": "string", "description": "Original log content"}
                },
                "required": ["solution"]
            }
        ),
        Tool(
            name="memory_search",
            description="Store or retrieve past log analyses from ChromaDB vector memory.",
            inputSchema={
                "type": "object",
                "properties": {
                    "action": {
                        "type": "string",
                        "enum": ["retrieve", "store", "search"],
                        "description": "retrieve = find similar past cases, store = save new, search = pattern search"
                    },
                    "query":       {"type": "string", "description": "Search query or error text"},
                    "log_content": {"type": "string", "description": "Log content to store"},
                    "analysis":    {"type": "object", "description": "Analysis results to store"},
                    "log_type":    {"type": "string", "description": "Detected log type"},
                    "limit":       {"type": "integer", "description": "Max results", "default": 5}
                },
                "required": ["action"]
            }
        ),
    ]


@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    """Route each MCP tool call to the correct agent."""

    def _err(msg: str) -> list[TextContent]:
        return [TextContent(type="text", text=f"❌ {msg}")]

    def _ok(data) -> list[TextContent]:
        text = data if isinstance(data, str) else json.dumps(data, indent=2, default=str)
        return [TextContent(type="text", text=text)]

    try:
        sys = await _get_system()
    except Exception as e:
        return _err(f"System failed to initialise: {e}")

    try:
        # ── Orchestrator ──────────────────────────────────────────────────────
        if name == "orchestrator_analyze":
            query = arguments.get("query", "").strip()
            if not query:
                return _err("No query provided.")
            result = await sys["orchestrator"].handle_user_query(query)
            return _ok(result)

        # ── Extractor ─────────────────────────────────────────────────────────
        elif name == "extractor_extract":
            agent = _get_agent("extractor")
            if not agent:
                return _err("Extractor agent not found.")
            task = {k: v for k, v in arguments.items() if v}
            resp = await agent.process(_make_msg(agent, "extract", task))
            return _ok(resp.response)

        # ── Preprocessor ──────────────────────────────────────────────────────
        elif name == "preprocessor_process":
            agent = _get_agent("preprocessor")
            if not agent:
                return _err("Preprocessor agent not found.")
            resp = await agent.process(_make_msg(agent, "preprocess", {
                "raw_logs": arguments.get("raw_logs", "")
            }))
            return _ok(resp.response)

        # ── Analyzer ──────────────────────────────────────────────────────────
        elif name == "analyzer_analyze":
            agent = _get_agent("analyzer")
            if not agent:
                return _err("Analyzer agent not found.")
            resp = await agent.process(_make_msg(agent, "analyze", {
                "clean_logs": arguments.get("clean_logs", "")
            }))
            return _ok(resp.response)

        # ── Solver ────────────────────────────────────────────────────────────
        elif name == "solver_solve":
            agent = _get_agent("solver")
            if not agent:
                return _err("Solver agent not found.")
            resp = await agent.process(_make_msg(agent, "solve", {
                "clean_logs": arguments.get("clean_logs", ""),
                "log_type":   arguments.get("log_type", "unknown"),
                "intent":     arguments.get("intent", "debugging"),
            }))
            return _ok(resp.response)

        # ── Debugger ──────────────────────────────────────────────────────────
        elif name == "debugger_debug":
            agent = _get_agent("debugger")
            if not agent:
                return _err("Debugger agent not found.")
            resp = await agent.process(_make_msg(agent, "debug", {
                "stack_trace": arguments.get("stack_trace", ""),
                "source_code": arguments.get("source_code", ""),
                "language":    arguments.get("language", "auto"),
            }))
            return _ok(resp.response)

        # ── Critic ────────────────────────────────────────────────────────────
        elif name == "critic_validate":
            agent = _get_agent("critic")
            if not agent:
                return _err("Critic agent not found.")
            resp = await agent.process(_make_msg(agent, "validate", {
                "solution":      arguments.get("solution", {}),
                "original_logs": arguments.get("original_logs", ""),
            }))
            return _ok(resp.response)

        # ── Memory ────────────────────────────────────────────────────────────
        elif name == "memory_search":
            agent = _get_agent("memory")
            if not agent:
                return _err("Memory agent not found.")
            resp = await agent.process(_make_msg(agent, arguments.get("action", "retrieve"), {
                "query":       arguments.get("query", ""),
                "log_content": arguments.get("log_content", ""),
                "analysis":    arguments.get("analysis", {}),
                "log_type":    arguments.get("log_type", "unknown"),
                "limit":       arguments.get("limit", 5),
            }))
            return _ok(resp.response)

        return _err(f"Unknown tool: {name}")

    except Exception as e:
        import traceback
        return _err(f"{name} failed: {e}\n{traceback.format_exc()}")


# ═══════════════════════════════════════════════════════════════════════════════
# Entry point
# ═══════════════════════════════════════════════════════════════════════════════

async def main():
    async with stdio_server() as (read_stream, write_stream):
        await app.run(read_stream, write_stream, app.create_initialization_options())


if __name__ == "__main__":
    print("[MCP Agent Server] Starting...", file=sys.stderr)
    asyncio.run(main())