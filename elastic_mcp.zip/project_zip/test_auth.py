# test_auth.py — verify Elastic Cloud Serverless connection

import os
from pathlib import Path
from dotenv import load_dotenv
from elasticsearch import Elasticsearch

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

# FIX: Serverless uses ELASTIC_URL, not ELASTICSEARCH_CLOUD_ID
es_url  = os.getenv("ELASTIC_URL")
api_key = os.getenv("ES_API_KEY")

if not es_url:
    print("FAILED: ELASTIC_URL is not set in .env")
    exit(1)

if not api_key:
    print("FAILED: ES_API_KEY is not set in .env")
    exit(1)

client = Elasticsearch(
    hosts=[es_url],
    api_key=api_key,
)

try:
    info = client.info()
    print("SUCCESS: Connected to Elasticsearch Serverless")
    print(f"  Cluster : {info.get('cluster_name')}")
    print(f"  Version : {info.get('version', {}).get('number')}")
except Exception as e:
    print(f"FAILED: {e}")