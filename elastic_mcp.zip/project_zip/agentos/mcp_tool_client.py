import asyncio
from pathlib import Path

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


class MCPToolClient:
    def __init__(self):
        self.project_root = Path(__file__).resolve().parent.parent
        self.server_file = self.project_root / "mcp_proxy.py"

    async def call_tool(self, tool_name: str, arguments: dict):
        params = StdioServerParameters(
            command="python",
            args=[str(self.server_file)],
            cwd=str(self.project_root),
        )

        async with stdio_client(params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()

                result = await session.call_tool(tool_name, arguments)

                if result.content:
                    return result.content[0].text

                return None

    async def retrieve_logs_auto(self, query: str, source: str = "auto", size: int = 10):
        return await self.call_tool(
            "retrieve_logs_auto",
            {
                "query": query,
                "source": source,
                "size": size,
            },
        )

    async def search_elasticsearch_logs(self, query: str, size: int = 10):
        return await self.call_tool(
            "search_elasticsearch_logs",
            {
                "query": query,
                "size": size,
            },
        )

    async def search_json_logs(self, query: str, size: int = 10):
        return await self.call_tool(
            "search_json_logs",
            {
                "query": query,
                "size": size,
            },
        )

    async def search_chromadb_logs(self, query: str, size: int = 10):
        return await self.call_tool(
            "search_chromadb_logs",
            {
                "query": query,
                "size": size,
            },
        )