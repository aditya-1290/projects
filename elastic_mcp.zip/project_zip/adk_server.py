"""
ADK Server — FastAPI server exposing the Log Analysis Multi-Agent System
as Google ADK-compatible endpoints.

Usage:
    python adk_server.py
    python adk_server.py --port 8080 --host 0.0.0.0

Endpoints:
    POST /run          — Run a query and get the full response
    POST /run_stream   — Run a query and stream the response
    GET  /agents       — List all registered agents with their ADK cards
    GET  /history      — Shows all history
    GET  /tools        — List all available tools
    GET  /health       — Health check
"""

import asyncio
import sys
import os
import argparse
from pathlib import Path
from datetime import datetime
import json

from agents.base_agent import A2AMessage, MessageType

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import StreamingResponse, JSONResponse, HTMLResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from typing import Optional, Dict, Any, List
import uvicorn
import chromadb
import uuid


BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))


# ✅ connect to your existing DB
CHROMA_DB_PATH = os.getenv("CHROMA_DB_PATH", "memory_store/chroma_db")

chroma_client = chromadb.PersistentClient(
    path=CHROMA_DB_PATH,
    settings=chromadb.Settings(anonymized_telemetry=False)
)

# ── ChromaDB helper functions (added from partner's work) ──────────────────

def make_context_text(text: str, max_len: int = 45) -> str:
    clean = str(text or "").strip().replace("\n", " ")
    clean = " ".join(clean.split())
    return clean[:max_len] + "..." if len(clean) > max_len else clean


def _safe_json_loads(value, default):
    if isinstance(value, (list, dict)):
        return value
    try:
        return json.loads(value or "")
    except Exception:
        return default


def get_chroma_history(limit: int = 10) -> List[Dict[str, Any]]:
    """Return one item per session with full messages list."""
    try:
        collection = chroma_client.get_or_create_collection("log_analyses")
        data = collection.get(include=["documents", "metadatas"])

        history: List[Dict[str, Any]] = []
        ids = data.get("ids", [])
        documents = data.get("documents", [])
        metadatas = data.get("metadatas", [])

        for index, item_id in enumerate(ids):
            metadata = metadatas[index] or {}
            document = documents[index] or ""
            session_id = metadata.get("session_id") or item_id
            messages = _safe_json_loads(metadata.get("messages", "[]"), [])

            if not messages and not metadata.get("response") and not document:
                continue

            context_text = metadata.get("context_text") or ""
            if not context_text:
                if messages:
                    context_text = make_context_text(messages[0].get("query", "New Chat"))
                else:
                    context_text = make_context_text(document or "New Chat")

            history.append({
                "id": item_id,
                "session_id": session_id,
                "query": metadata.get("query", ""),
                "response": metadata.get("response", ""),
                "context_text": context_text,
                "messages": messages,
                "created_at": metadata.get("created_at", ""),
                "updated_at": metadata.get("updated_at", metadata.get("created_at", "")),
            })

        history.sort(key=lambda x: x.get("updated_at") or x.get("created_at") or "", reverse=True)
        return history[:limit]

    except Exception as exc:
        print("[HISTORY] Failed to load ChromaDB history:", exc)
        return []


def save_ai_response_to_chromadb(query: str, response: str, session_id: str) -> None:
    """Save every user/AI turn under the same session id (upsert pattern)."""
    try:
        collection = chroma_client.get_or_create_collection("log_analyses")
        query = str(query or "").strip()
        response = str(response or "").strip()
        now = datetime.now().isoformat(timespec="seconds")

        existing = collection.get(ids=[session_id], include=["documents", "metadatas"])
        new_message = {"query": query, "response": response, "created_at": now}

        if existing.get("ids"):
            old_metadata = existing["metadatas"][0] or {}
            old_document = existing["documents"][0] or ""
            messages = _safe_json_loads(old_metadata.get("messages", "[]"), [])
            messages.append(new_message)
            full_text = f"{old_document}\n\nUser: {query}\nAI: {response}".strip()
            first_query = messages[0].get("query", query) if messages else query

            collection.update(
                ids=[session_id],
                documents=[full_text],
                metadatas=[{
                    "session_id":   session_id,
                    "query":        query,
                    "response":     response,
                    "context_text": make_context_text(first_query),
                    "messages":     json.dumps(messages, ensure_ascii=False),
                    "created_at":   old_metadata.get("created_at", now),
                    "updated_at":   now,
                }],
            )
        else:
            messages  = [new_message]
            full_text = f"User: {query}\nAI: {response}"
            collection.add(
                ids=[session_id],
                documents=[full_text],
                metadatas=[
                    {
                        "session_id": session_id,
                        "query": query,
                        "response": response,
                        "context_text": make_context_text(response, max_len=40),
                        "messages": json.dumps(messages, ensure_ascii=False),
                        "created_at": now,
                        "updated_at": now,
                    }
                ],
            )
            print("[ChromaDB] Created session:", session_id)

    except Exception as exc:
        print("[ChromaDB] Save error:", exc)

# ═══════════════════════════════════════════════════════════════════════════════
# Request / Response Models
# ═══════════════════════════════════════════════════════════════════════════════

class RunRequest(BaseModel):
    query: str = Field(..., description="Log entries, file path, or question to analyze")
    session_id: Optional[str] = Field(None, description="Session ID for multi-turn conversations")


class RunResponse(BaseModel):
    response: str = Field(..., description="Analysis results")
    session_id: str = Field(..., description="Session ID for follow-up queries")
    pipeline_stages: List[str] = Field(default_factory=list, description="Stages completed")
    confidence: float = Field(0.0, description="Overall confidence 0.0-1.0")
    agent_used: str = Field("orchestrator", description="Primary agent that handled the query")
    timestamp: str = Field(default_factory=lambda: datetime.utcnow().isoformat())


class AgentCardResponse(BaseModel):
    name: str
    description: str
    capabilities: List[str]
    tools: List[Dict]
    model_requirements: List[str]


class HealthResponse(BaseModel):
    status: str = "healthy"
    agents_loaded: int = 0
    models_loaded: int = 0
    uptime_seconds: float = 0.0


# ═══════════════════════════════════════════════════════════════════════════════
# FastAPI Application
# ═══════════════════════════════════════════════════════════════════════════════

# ── Lifespan — clean startup and graceful shutdown ────────────────────────────
from contextlib import asynccontextmanager

@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Replaces @app.on_event("startup") and @app.on_event("shutdown").
    Everything before `yield` runs on startup.
    Everything after `yield` runs on shutdown — even when Ctrl+C is pressed.
    Each cleanup step is individually wrapped so one failure never blocks the rest.
    """
    global orchestrator, model_manager, communication_bus, startup_time

    # ── STARTUP ───────────────────────────────────────────────────────────────
    print("[ADK Server] Initializing...")

    from config import MAX_MEMORY_GB
    from models.manager import ModelManager
    from agentos.communication_bus import CommunicationBus
    from main import SystemBootstrap

    # 1. Model Manager
    print("[ADK Server] Loading models...")
    model_manager = ModelManager(max_memory_gb=MAX_MEMORY_GB)
    await model_manager.initialize()

    # 2. Communication Bus
    print("[ADK Server] Starting communication bus...")
    communication_bus = CommunicationBus()
    await communication_bus.start()

    # 3. Load all agents
    print("[ADK Server] Loading agents...")
    agents, orchestrator = await SystemBootstrap.create_all_agents(
        model_manager, communication_bus
    )

    # 4. Initialize orchestrator
    if orchestrator:
        await orchestrator.initialize()

    startup_time = datetime.utcnow()
    print(f"[ADK Server] Ready — {len(agents)} agents loaded")
    print(f"[ADK Server] Endpoints: /run, /run_stream, /agents, /tools, /health")

    # ── HAND CONTROL TO FASTAPI ───────────────────────────────────────────────
    yield

    # ── SHUTDOWN (runs on Ctrl+C or any signal) ───────────────────────────────
    print("\n[ADK Server] Shutting down gracefully...")

    # 1. Stop accepting new requests — already handled by uvicorn before lifespan exits

    # 2. Stop communication bus + drain agent message queues
    try:
        if communication_bus:
            await communication_bus.stop()
            print("[ADK Server] Communication bus stopped")
    except Exception as e:
        print(f"[ADK Server] Communication bus stop warning: {e}")

    # 3. Cancel any pending orchestrator tasks
    try:
        if orchestrator and hasattr(orchestrator, "_pending_tasks"):
            for task in list(orchestrator._pending_tasks.values()):
                if not task.done():
                    task.cancel()
            print("[ADK Server] Orchestrator tasks cancelled")
    except Exception as e:
        print(f"[ADK Server] Orchestrator cleanup warning: {e}")

    # 4. Unload models (releases llama.cpp memory and file handles)
    try:
        if model_manager and hasattr(model_manager, "unload_all"):
            await model_manager.unload_all()
            print("[ADK Server] Models unloaded")
        elif model_manager and hasattr(model_manager, "_models"):
            for name, model in list(model_manager._models.items()):
                try:
                    if hasattr(model, "close"):
                        model.close()
                    elif hasattr(model, "unload"):
                        model.unload()
                except Exception:
                    pass
            print("[ADK Server] Models released")
    except Exception as e:
        print(f"[ADK Server] Model unload warning: {e}")

    # 5. Cancel any remaining asyncio tasks spawned by the app
    try:
        tasks = [t for t in asyncio.all_tasks() if t is not asyncio.current_task()]
        if tasks:
            for task in tasks:
                task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
            print(f"[ADK Server] {len(tasks)} background task(s) cancelled")
    except Exception as e:
        print(f"[ADK Server] Task cleanup warning: {e}")

    print("[ADK Server] Shutdown complete ✓")


app = FastAPI(
    title="Log Analysis Multi-Agent System",
    description="ADK-compatible API for log analysis with specialized agents",
    version="2.0.0",
    lifespan=lifespan,
)

BASE_DIR = Path(__file__).resolve().parent
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

# Global references (set during startup)
orchestrator = None
model_manager = None
communication_bus = None
agents={}
startup_time = None




@app.get("/", response_class=HTMLResponse)
async def dashboard(request: Request, session_id: str = ""):
    """Render the HTML dashboard for log analysis."""
    return templates.TemplateResponse(
        "index.html",
        {
            "request": request,
            "query": "",
            "result": None,
            "error": None,
            "session_id": session_id,
            "history": get_chroma_history(limit=10)
        },
    )


# @app.post("/ui/analyze", response_class=HTMLResponse)
# async def analyze_from_ui(request: Request):
    """Handle analysis submitted from the HTML form."""
    global orchestrator

    form = await request.form()
    query = str(form.get("query", "")).strip()
    session_id = str(form.get("session_id", "")).strip()

    context = {
        "request": request,
        "query": query,
        "result": None,
        "error": None,
        "session_id": session_id,
        "history": get_chroma_history(limit=10)
    }

    if not query:
        context["error"] = "Please enter a log, file path, or question before running analysis."
        return templates.TemplateResponse("index.html", context)

    if not orchestrator:
        context["error"] = "System is still initializing. Please check /health or restart the server."
        return templates.TemplateResponse("index.html", context)

    try:
        response = await orchestrator.handle_user_query(query)

        save_ai_response_to_chromadb(query, response, session_id)

        context["result"] = response
        context["history"] = get_chroma_history(limit=10)
        if not session_id:
            session_id = str(uuid.uuid4())
        context_text = make_context_text(response)
         # SAVE
        collection = chroma_client.get_collection("log_analyses")
        collection.add(
            ids=[str(uuid.uuid4())],
            documents=[response],
            metadatas=[{
                "query": query,
                "response": response,
                "context_text": context_text,
                "created_at": str(datetime.now()),
                "session_id": session_id
            }]
        )

        context["session_id"] = session_id
        context["history"] = get_chroma_history(limit=10)

    except Exception as exc:
        context["error"] = f"Analysis failed: {exc}"
        context["history"] = get_chroma_history(limit=10)

    return templates.TemplateResponse("index.html", context)

# ═══════════════════════════════════════════════════════════════════════════════
# Startup
# ═══════════════════════════════════════════════════════════════════════════════

# FOR CLI
# @app.on_event("startup")
# async def startup():
#     """Initialize the multi-agent system for ADK Web."""
#     global orchestrator, model_manager, communication_bus, agents, startup_time
#
#     os.environ["ADK_WEB_MODE"] = "true"
#
#     print("[ADK Server] Initializing...")
#
#     from config import MAX_MEMORY_GB
#     from models.manager import ModelManager
#     from agentos.communication_bus import CommunicationBus
#     from main import SystemBootstrap
#
#     # 1. Model Manager
#     print("[ADK Server] Loading models...")
#     model_manager = ModelManager(max_memory_gb=MAX_MEMORY_GB)
#     await model_manager.initialize()
#
#     # 2. Communication Bus
#     print("[ADK Server] Starting communication bus...")
#     communication_bus = CommunicationBus()
#     await communication_bus.start()
#
#     # 3. Load all agents
#     print("[ADK Server] Loading agents...")
#     agents, orchestrator = await SystemBootstrap.create_all_agents(
#         model_manager,
#         communication_bus,
#     )
#
#     if orchestrator:
#         await orchestrator.initialize()
#
#     startup_time = datetime.utcnow()
#
#     print(f"[ADK Server] Ready — {len(agents)} agents loaded")
#     print("[ADK Server] ADK_WEB_MODE=true")
#     print("[ADK Server] Endpoints: /run, /run_stream, /agents, /tools, /health")

# ═══════════════════════════════════════════════════════════════════════════════
# Agent Helper
# ═══════════════════════════════════════════════════════════════════════════════

def _get_agent(agent_type: str):
    """
    Get a specific agent by ID or capability name.
    """
    global agents, communication_bus
    # 1. First check global agents dictionary
    if isinstance(agents, dict):
        if agent_type in agents:
            return agents[agent_type]
        for agent_id, agent in agents.items():
            capability = getattr(agent, "capability", None)
            capability_name = getattr(capability, "agent_name", None)
            if capability_name == agent_type:
                return agent

    # 2. Fallback: check communication bus agents
    if communication_bus and hasattr(communication_bus, "agents"):
        if agent_type in communication_bus.agents:
            return communication_bus.agents[agent_type]
        for agent_id, agent in communication_bus.agents.items():
            capability = getattr(agent, "capability", None)
            capability_name = getattr(capability, "agent_name", None)
            if capability_name == agent_type:
                return agent
    return None

async def _run_agent(agent_type: str, action: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    agent = _get_agent(agent_type)
    if not agent:
        raise HTTPException(status_code=503, detail=f"{agent_type} agent not available")

    msg = A2AMessage(
        message_type=MessageType.REQUEST,
        sender_id="adk_server",
        sender_type="external",
        target_id=agent.agent_id,
        task={"action": action, **payload},
    )
    response = await agent.process(msg)
    return {"response": json.dumps(response.response, default=str)}


def _get_es_client():
    """Get Elasticsearch client for Serverless (uses ELASTICSEARCH_URL)."""
    from elasticsearch import AsyncElasticsearch
    es_url   = os.getenv("ELASTICSEARCH_URL") or os.getenv("ELASTIC_URL", "")
    es_key   = os.getenv("ES_API_KEY", "")
    if not es_url or not es_key:
        raise HTTPException(status_code=503, detail="Elasticsearch not configured in .env")
    return AsyncElasticsearch(hosts=[es_url], api_key=es_key, verify_certs=True)

def _agent_response_to_dict(response):
    """
    Convert A2AMessage response into clean JSON.
    Do not return json.dumps(...) because ADK tools need real JSON/dict.
    """
    if response is None:
        return {
            "success": False,
            "error": "Agent returned no response",
            "response": None,
            "confidence": 0.0,
        }
    success = response.message_type == MessageType.RESPONSE
    return {
        "success": success,
        "response": response.response,
        "error": response.error,
        "confidence": getattr(response, "confidence", 0.0) or 0.0,
        "sender_id": getattr(response, "sender_id", None),
        "message_type": getattr(response.message_type, "value", str(response.message_type)),
    }

# ═══════════════════════════════════════════════════════════════════════════════
# Endpoints
# ═══════════════════════════════════════════════════════════════════════════════

@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint."""
    global orchestrator, model_manager, communication_bus, startup_time

    if not orchestrator:
        raise HTTPException(status_code=503, detail="System not initialized")

    model_status = model_manager.get_status() if model_manager else {}
    bus_status = await communication_bus.get_status() if communication_bus else {}

    uptime = (datetime.utcnow() - startup_time).total_seconds() if startup_time else 0

    return HealthResponse(
        status="healthy",
        agents_loaded=bus_status.get("registered_agents", 0),
        models_loaded=model_status.get("total_loads", 0),
        uptime_seconds=uptime
    )


@app.get("/agents", response_model=List[AgentCardResponse])
async def list_agents():
    """List all registered agents with their ADK cards."""
    global communication_bus

    if not communication_bus:
        raise HTTPException(status_code=503, detail="Communication bus not initialized")

    bus_status = await communication_bus.get_status()
    agents = []

    for agent_info in bus_status.get("agents", []):
        agent_id = agent_info.get("id")
        agent = communication_bus.agents.get(agent_id)
        if not agent:
            continue

        if agent:
            card = agent.adk_card
            agents.append(AgentCardResponse(
                name=card.name,
                description=card.description,
                capabilities=card.capabilities,
                tools=card.tools,
                model_requirements=card.model_requirements
            ))

    return agents


@app.get("/tools")
async def list_tools():
    """List all available tools across all agents."""
    global communication_bus

    if not communication_bus:
        raise HTTPException(status_code=503, detail="Communication bus not initialized")

    all_tools = []

    for agent_id, agent in communication_bus.agents.items():
        card = agent.adk_card
        for tool in card.tools:
            tool["provided_by"] = card.name
            all_tools.append(tool)

    return {"tools": all_tools, "count": len(all_tools)}

# FOR CLI
# @app.post("/run", response_model=RunResponse)
# async def run_query(request: RunRequest):
#     """
#     Run a log analysis query and return the full response.
#
#     Accepts:
#     - Pasted log entries
#     - File paths (e.g., "logs/error.log")
#     - Terminal commands (e.g., "command:dir")
#     - Image paths (e.g., "screenshots/error.png")
#     - Questions about errors
#     """
#     global orchestrator
#
#     if not orchestrator:
#         raise HTTPException(status_code=503, detail="Orchestrator not initialized")
#
#     try:
#         response = await orchestrator.handle_user_query(request.query)
#
#         # Extract confidence from the orchestrator's last execution
#         confidence = 0.8  # Default
#         pipeline_stages = ["extract", "preprocess", "analyze", "solve", "validate"]
#
#         if orchestrator.execution_history:
#             last = orchestrator.execution_history[-1]
#             if isinstance(last, dict):
#                 confidence = last.get("confidence", 0.8)
#
#         return RunResponse(
#             response=response,
#             session_id=request.session_id or "default",
#             pipeline_stages=pipeline_stages,
#             confidence=confidence
#         )
#
#     except Exception as e:
#         import traceback
#         error_details = traceback.format_exc()
#         print("[ADK Server] /run failed:")
#         print(error_details)
#
#         raise HTTPException(
#             status_code=500,
#             detail={
#                 "message": f"Analysis failed: {str(e)}",
#                 "type": type(e).__name__,
#             },
#         )


@app.get("/history-json")
async def history_json():
    """Return chat history from ChromaDB as JSON. Used by the frontend."""
    return {"history": get_chroma_history(limit=50)}

# FOR FASTAPI
@app.post("/run", response_model=RunResponse)
async def run_query(request: RunRequest):
    """
    Run the complete log analysis pipeline.
    """

    global orchestrator

    if not orchestrator:
        raise HTTPException(status_code=503, detail="Orchestrator not initialized")

    try:
        session_id = request.session_id or str(uuid.uuid4())
        response = await orchestrator.handle_user_query(query=request.query, session_id=session_id)

        # New line added for data saved in db
        save_ai_response_to_chromadb(
            query=request.query,
            response=str(response),
            session_id=session_id
        )
        # End new line

        # Extract confidence from the orchestrator's last execution
        confidence = 0.8  # Default
        pipeline_stages = ["extract", "preprocess", "analyze", "solve", "validate"]

        if orchestrator.execution_history:
            last = orchestrator.execution_history[-1]
            if isinstance(last, dict):
                confidence = last.get("confidence", 0.8)

        return RunResponse(
            response=response,
            session_id=session_id,
            pipeline_stages=pipeline_stages,
            confidence=confidence
        )

    except Exception as e:
        import traceback
        print("[FastAPI] /run failed:")
        print(traceback.format_exc())

        raise HTTPException(
            status_code=500,
            detail={
                "message": f"Analysis failed: {str(e)}",
                "type": type(e).__name__,
            },
        )

@app.post("/run_stream")
async def run_query_stream(request: RunRequest):
    """
    Run a log analysis query and stream the response as it's generated.

    This uses Server-Sent Events (SSE) for real-time streaming.
    """
    global orchestrator

    if not orchestrator:
        raise HTTPException(status_code=503, detail="Orchestrator not initialized")

    async def generate():
        """Stream the response."""
        try:
            # Send start event
            yield f"data: {json.dumps({'type': 'start', 'query': request.query[:100]})}\n\n"

            # Run the analysis
            response = await orchestrator.handle_user_query(request.query)

            # Stream the response in chunks
            chunks = response.split('\n')
            for chunk in chunks:
                if chunk.strip():
                    yield f"data: {json.dumps({'type': 'content', 'text': chunk})}\n\n"
                    await asyncio.sleep(0.1)  # Small delay for streaming effect

            # Send end event
            yield f"data: {json.dumps({'type': 'end', 'status': 'complete'})}\n\n"

        except Exception as e:
            yield f"data: {json.dumps({'type': 'error', 'message': str(e)})}\n\n"

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no"
        }
    )

@app.post("/agent/extractor")
async def extractor_endpoint(request: dict):
    """Extract logs from files, images, terminal, or text."""
    agent = _get_agent("extractor")

    if agent is None:
        raise HTTPException(status_code=404, detail="Extractor agent not found")

    msg = A2AMessage(
        message_type=MessageType.REQUEST,
        sender_id="adk_server",
        sender_type="external",
        target_id=agent.agent_id,
        task={
            "action": "extract",
            "input": request.get("input")
                     or request.get("query")
                     or request.get("text")
                     or request.get("content")
                     or request.get("path")
                     or request,
        },
    )
    response = await agent.process(msg)
    return _agent_response_to_dict(response)

@app.post("/agent/preprocessor")
async def preprocessor_endpoint(request: dict):
    """Clean and structure raw logs."""
    agent = _get_agent("preprocessor")

    if agent is None:
        raise HTTPException(status_code=404, detail="Preprocessor agent not found")

    raw_logs = (
        request.get("raw_logs")
        or request.get("raw_content")
        or request.get("logs")
        or request.get("input")
        or request.get("query")
        or request.get("text")
        or request
    )

    msg = A2AMessage(
        message_type=MessageType.REQUEST,
        sender_id="adk_server",
        sender_type="external",
        target_id=agent.agent_id,
        task={
            "action": "preprocess",
            "input": raw_logs,
            "raw_logs": raw_logs,
            "raw_content": raw_logs,
        },
    )
    response = await agent.process(msg)
    return _agent_response_to_dict(response)

@app.post("/agent/analyzer")
async def analyzer_endpoint(request: dict):
    """Classify logs, detect intent, assess severity."""
    agent = _get_agent("analyzer")

    if agent is None:
        raise HTTPException(status_code=404, detail="Analyzer agent not found")

    clean_logs = (
        request.get("clean_logs")
        or request.get("logs")
        or request.get("raw_content")
        or request.get("input")
        or request.get("query")
        or request.get("text")
        or request
    )

    msg = A2AMessage(
        message_type=MessageType.REQUEST,
        sender_id="adk_server",
        sender_type="external",
        target_id=agent.agent_id,
        task={
            "action": "analyze",
            "input": clean_logs,
            "clean_logs": clean_logs,
            "logs": clean_logs,
        },
    )

    response = await agent.process(msg)
    return _agent_response_to_dict(response)

@app.post("/agent/solver")
async def solver_endpoint(request: dict):
    """Root cause analysis and fix generation."""
    agent = _get_agent("solver")

    if agent is None:
        raise HTTPException(status_code=404, detail="Solver agent not found")

    msg = A2AMessage(
        message_type=MessageType.REQUEST,
        sender_id="adk_server",
        sender_type="external",
        target_id=agent.agent_id,
        task={
            "action": "solve",
            "input": request,
            "analysis": request.get("analysis", request),
            "clean_logs": request.get("clean_logs") or request.get("logs") or request.get("input") or "",
        },
    )
    response = await agent.process(msg)
    return _agent_response_to_dict(response)

@app.post("/agent/debugger")
async def debugger_endpoint(request: dict):
    """Parse stack traces and generate patches."""
    agent = _get_agent("debugger")

    if agent is None:
        raise HTTPException(status_code=404, detail="Debugger agent not found")

    msg = A2AMessage(
        message_type=MessageType.REQUEST,
        sender_id="adk_server",
        sender_type="external",
        target_id=agent.agent_id,
        task={
            "action": "debug",
            "input": request.get("input") or request.get("query") or request.get("traceback") or request,
            "traceback": request.get("traceback") or request.get("input") or request.get("query") or "",
        },
    )
    response = await agent.process(msg)
    return _agent_response_to_dict(response)

@app.post("/agent/critic")
async def critic_endpoint(request: dict):
    """Validate solution quality."""
    agent = _get_agent("critic")

    if agent is None:
        raise HTTPException(status_code=404, detail="Critic agent not found")

    msg = A2AMessage(
        message_type=MessageType.REQUEST,
        sender_id="adk_server",
        sender_type="external",
        target_id=agent.agent_id,
        task={
            "action": "validate",
            "input": request,
            "solution": request.get("solution") or request.get("response") or request.get("input") or request,
        },
    )
    response = await agent.process(msg)
    return _agent_response_to_dict(response)

@app.post("/agent/memory")
async def memory_endpoint(request: dict):
    """Search and store past analyses."""
    agent = _get_agent("memory")

    if agent is None:
        raise HTTPException(status_code=404, detail="Memory agent not found")

    msg = A2AMessage(
        message_type=MessageType.REQUEST,
        sender_id="adk_server",
        sender_type="external",
        target_id=agent.agent_id,
        task={
            "action": request.get("action", "retrieve"),
            "input": request.get("input") or request.get("query") or request,
            **request,
        },
    )
    response = await agent.process(msg)
    return _agent_response_to_dict(response)

@app.delete("/history/{session_id}")
async def delete_history(session_id: str):
    try:
        collection = chroma_client.get_or_create_collection("log_analyses")
        collection.delete(ids=[session_id])
        return {"status": "deleted", "session_id": session_id}
    except Exception as e:
        return {"status": "error", "message": str(e)}


@app.post("/history/{session_id}/rename")
async def rename_history(session_id: str, request: Request):
    """
    Rename a ChromaDB conversation/session by updating context_text.
    """
    try:
        body = await request.json()
        new_title = str(body.get("title", "")).strip()

        if not new_title:
            raise HTTPException(status_code=400, detail="Title is required")

        collection = chroma_client.get_or_create_collection("log_analyses")

        existing = collection.get(
            ids=[session_id],
            include=["documents", "metadatas"],
        )

        if not existing.get("ids"):
            raise HTTPException(
                status_code=404,
                detail=f"Session not found: {session_id}",
            )

        old_metadata = existing["metadatas"][0] or {}
        old_document = existing["documents"][0] or ""

        now = datetime.now().isoformat(timespec="seconds")

        updated_metadata = {
            **old_metadata,
            "session_id": session_id,
            "context_text": make_context_text(new_title, max_len=40),
            "custom_title": new_title,
            "updated_at": now,
        }

        collection.update(
            ids=[session_id],
            documents=[old_document],
            metadatas=[updated_metadata],
        )

        print(f"[HISTORY] Renamed session {session_id} → {new_title}")

        return {
            "status": "renamed",
            "session_id": session_id,
            "title": new_title,
            "context_text": updated_metadata["context_text"],
        }

    except HTTPException:
        raise

    except Exception as e:
        print("[HISTORY] Rename error:", e)
        raise HTTPException(
            status_code=500,
            detail=f"Rename failed: {str(e)}",
        )


@app.post("/memory/search")
async def memory_search_endpoint(request: dict):
    """
    Search ChromaDB memory.
    Used by MCP proxy: search_chromadb_logs and retrieve_logs_auto.
    """
    agent = _get_agent("memory")

    if agent is None:
        raise HTTPException(status_code=404, detail="Memory agent not found")

    query = request.get("query", "")
    limit = request.get("size") or request.get("limit") or 5
    collection = request.get("collection", "log_analyses")

    msg = A2AMessage(
        message_type=MessageType.REQUEST,
        sender_id="adk_server",
        sender_type="external",
        target_id=agent.agent_id,
        task={
            "action": "retrieve_similar_cases",
            "query": query,
            "limit": limit,
            "collection": collection,
        },
        context={
            "query": query,
        },
    )

    response = await agent.process(msg)
    return _agent_response_to_dict(response)


@app.post("/memory/store")
async def memory_store_endpoint(request: dict):
    """
    Store analysis into ChromaDB memory.
    """
    agent = _get_agent("memory")

    if agent is None:
        raise HTTPException(status_code=404, detail="Memory agent not found")

    log_content = (
        request.get("log_content")
        or request.get("clean_logs")
        or request.get("raw_logs")
        or request.get("logs")
        or ""
    )

    analysis = request.get("analysis") or request.get("results") or {}
    log_type = request.get("log_type", "unknown")

    msg = A2AMessage(
        message_type=MessageType.REQUEST,
        sender_id="adk_server",
        sender_type="external",
        target_id=agent.agent_id,
        task={
            "action": "store_log_analysis",
            "log_content": log_content,
            "analysis": analysis,
            "log_type": log_type,
        },
        context={
            "clean_logs": log_content,
            "log_type": log_type,
            "solution": analysis,
        },
    )

    response = await agent.process(msg)
    return _agent_response_to_dict(response)

@app.get("/elastic/health")
async def elastic_health():
    """Check Elastic Cloud connectivity."""
    es = _get_es_client()
    try:
        indices = await  es.cat.indices(index="*", format="json")
        return {
            "connected": True,
            "index_count": len(indices.body),
            "source": "elastic_cloud_serverless",
        }
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"Elastic Unreachable: {str(e)}")
    finally:
        await es.close()

@app.post("/elastic/search")
async def elastic_search(request: dict):
    """Search Elastic Cloud logs."""
    es = _get_es_client()
    index = request.get("index", os.getenv("ES_INDEX_PATTERN", "logs-*"))
    query = request.get("query", "*")
    size = request.get("size", 10)

    result = await es.search(
        index=index,
        size=size,
        query={"query_string": {"query": query, "default_field": "*"}},
        sort=[{"@timestamp": {"order": "desc", "unmapped_type": "date"}}],
    )
    hits = result.get("hits", {}).get("hits", [])
    return {
        "count": len(hits),
        "logs": [h.get("_source", {}) for h in hits],
    }

# ═══════════════════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="ADK Server for Log Analysis Multi-Agent System")
    parser.add_argument("--host", default="127.0.0.1", help="Host to bind to")
    parser.add_argument("--port", type=int, default=8000, help="Port to listen on")
    parser.add_argument("--reload", action="store_true", help="Enable auto-reload")

    args = parser.parse_args()

    print(f"""
╔══════════════════════════════════════════════════════════════╗
║       LOG ANALYSIS MULTI-AGENT SYSTEM — ADK Server           ║
╚══════════════════════════════════════════════════════════════╝

Starting server at http://{args.host}:{args.port}

Endpoints:
  GET  /health      — Health check
  GET  /agents      — List registered agents
  GET  /tools       — List available tools
  GET  /history     — Shows all history 
  POST /run         — Run analysis
  POST /run_stream  — Stream analysis results

Docs: http://{args.host}:{args.port}/docs
""")

    try:
        uvicorn.run(
            "adk_server:app",
            host=args.host,
            port=args.port,
            reload=args.reload,
            # Give in-flight requests up to 10 s to finish before killing them
            timeout_graceful_shutdown=10,
        )
    except KeyboardInterrupt:
        # Ctrl+C already handled cleanly by the lifespan shutdown block above.
        # This suppresses the ugly traceback that uvicorn would otherwise print.
        print("\n[ADK Server] Interrupted — bye!")