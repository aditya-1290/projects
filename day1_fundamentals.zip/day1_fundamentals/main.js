import { getActiveUsers, getFullNames, getTotalAge, totalActiveAge } from './userProcessing.js';

console.log('-------User Processing-------');
console.log('Active Users:', getActiveUsers());
console.log('Full Names: ', getFullNames());
console.log('Total Age:', getTotalAge());
console.log('Total age of active users:', totalActiveAge());
