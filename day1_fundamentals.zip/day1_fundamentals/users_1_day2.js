export const User = [
    { id: 1, firstName: "John", lastName: "Doe", age: 25, isActive: true },
    { id: 2, firstName: "Jane", lastName: "Smith", age: 32, isActive: false },
    { id: 3, firstName: "Bob", lastName: "Johnson", age: 40, isActive: true },
    { id: 4, firstName: "Alice", lastName: "Brown", age: 19, isActive: true }
];
