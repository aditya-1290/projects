export const users = [
    {id: 1, firstName: 'Harsh', lastName: 'Pandey', age: 25, active: true},
    {id: 2, firstName: 'Kapil', lastName: 'Lokhande', age: 30, active: false},
    {id: 3, firstName: 'Bhushan', lastName: 'Pawar', age: 22, active: true},
    {id: 1, firstName: 'Naruto', lastName: 'Uzumaki', age: 28, active: true},
    {id: 1, firstName: 'Ichigo', lastName: 'Kurasaki', age: 35, active: false},
    {id: 1, firstName: 'Luffy', lastName: 'Monkey D.', age: 27, active: true},
    {id: 1, firstName: 'Gojo', lastName: 'Satoru', age: 31, active: false},
    {id: 1, firstName: 'Mahoraga', lastName: 'Geto', age: 29, active: true},
    {id: 1, firstName: 'Kushal', lastName: 'Parab', age: 24, active: true},
    {id: 1, firstName: 'Harsh', lastName: 'Beniwal', age: 33, active: false},
];

export default users;
