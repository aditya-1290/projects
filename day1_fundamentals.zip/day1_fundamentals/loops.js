// 1. for...of (The Array Walker)
// When you have an array and you just want to grab every single item one by one without caring about 
// index numbers (i), use for...of. It reads like plain English: "For every item of this array, do something."
// const x = @;
const tools = ["Git", "VS Code", "Terminal"];

for (const tool of tools) {
    console.log(`Using ${tool}`);
}

// Output:
// Using Git
// Using VS Code
// Using Terminal

// 2. for...in (The Object Inspector)
// Objects don't have sequential indexes, so a normal loop or for...of will completely fail on them. 
// To loop through the keys (properties) of an object, we use for...in. Think of the "in" as looking "inside" an object's properties.
const laptop = {brand: "Apple", model: "M3 Pro", ram: "18GB"};

for (const key in laptop) {
    console.log(`${key}: ${laptop[key]}`);
}
// Prints:
// brand: Apple
// model: M3 Pro
// ram: 18GB
