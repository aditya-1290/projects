//Simulating an API endpoint that takes 2 seconds to respond
const fetchWeatherFromServer = () => {
    return new Promise((resolve, reject) => {
        const networkSuccess = true; // Change to false to test the error block!

        setTimeout(() => {
            if (networkSuccess) {
                resolve({ city: "Mumbai", temp: "31 degree celcius", condition: "Sunny" });
            } else {
                reject("Server timeout. Could not reach weather service.");
            }
        }, 2000);  // 2-second delay
    });
};

// Consuming the Data: The async/await Way
// Now, instead of messy .then() chains, we create an async function to read this data line-by-line.
const displayWeatherReport = async () => {
    console.log("1. USer clicked 'Check Weather'. Requesting data...");

    try {
        // The magic happens here: JavaScript pauses on this line until the 2 seconds are up!
        // Once the promise resolves, the wether data is dropped into the 'data' variable.

        const data = await fetchWeatherFromServer();

        console.log(`2. Weather data recieved successfully!`);
        console.log(`Current weather in ${data.city}: ${data.temp} and ${data.condition}.`);
    } catch (error) {
        // if neteorksuccess was false, execution would skip everything else and jump directly here.
        console.error(" Error handles gracefully:", error);
    } finally {
        console.log("3. Weather operation complete. Hiding loading spinner.");
    }
};

// Execute our async function
displayWeatherReport();
