function testVar() {
    if (true) {
        var x = 20;
    }
    console.log(x); // 20 - leaks out of the if-block!
}
testVar()

// bugs in loops using var keyword to define a variable 
for (var i = 0; i < 3; i++) {
    setTimeout(() => console.log(i), 0);
}
// output: 3, 3, 3  -- not 0, 1, 2 as i had expected.