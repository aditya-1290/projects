// Syntax
// condition ? valueIfTrue : valueIfFalse

// if/else version
let status;
if (age>= 18) {
    status = "adult";
} else {
    status = "minor";
}

// ternary version - same login, one line 
const status = age >= 18 ? "adult" : "minor";

// Why It's Useful
// It's an expression, not a statement — meaning it produces a value directly, 
// so you can use it inline: in a variable assignment, inside JSX (which you'll hit 
// constantly in React), inside a template literal, as a function argument, etc.

const message = `You are ${age >= 18 ? "an adult": "a minor"}`;

console.log(isLoggedIn ? "Welcome back" : "Please log in");

const fee = isMember ? 0 : 25;

// Regular if/else is a statement — it controls flow but 
// doesn't itself produce a value you can drop into an 
// expression. That's the core reason ternaries exist.

//  Chaining: ternary operators can be chained for multiple conditions
const grade = score >= 90 ? "A"
            : score >= 80 ? "B"
            : score >= 70 ? "C"
            : "F";


// This works, but once you have more than 2 branches, 
// a proper if/else chain or a switch is usually clearer. 
// Rule of thumb: ternaries are great for a single true/false 
// decision producing a value — not for complex branching logic