// calculator.js

// Named exports (arrow functions)

export const add = (a, b) => a + b;
export const subtract = (a, b) => a - b;
export const multiply = (a, b) => a * b;
export const divide = (a, b) => {
    if (b===0) {
        throw new Error('Division by zero is not allowed.');
    }
    return a/b;
};
// Look at this beauty: Single line, strict equality, implicit return via ternary
export const divide1 = (a, b) => b === 0 ? "Warning: Division by zero!" : a / b;

// Default export (an object bundling all th functions)
const calculator = { add, subtract, multiply, divide, divide1};
export default calculator;    

