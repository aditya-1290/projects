// Simulate APi fetch (you could use real fetch, but we'll use a wrapper that returns a Promise)
const fetchUSer = (id) => {
    return new Promise((resolve, reject)=>{
        setTimeout(() => {
            // Simulate fetching from endpoint
            if (id <= 0) {
                reject(new Error('Invalid user ID'));
                return;
            }
            //mock data
            resolve({id, name: 'John Wick', email: 'johnwick@gmail.com' });
        }, 1000);
    });
};

const fetchPosts = (userId) => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (!userId) {
                reject(new Error('User ID is required'));
                return;
            }
            resolve([
                {id: 1, title: 'Post 1', body: '...'},
                {id: 2, title: 'Post 2', body: '...' }
            ]);
        }, 1000);
    });
};

// Promise Chaining
export const fetchUserAndPostWithPromises = (userId) => {
    let currentUser;
    console.log('--- Promise Chain ---');
    return fetchUSer(userId) 
    .then(user => {
        currentUser = user;
        console.log('User fetched:', user);
        return fetchPosts(user.id);  //return with next promise
    })
    .then(posts => {
        console.log('Posts fetched:', posts);
        return { user: currentUser, posts }; // We need the user too; we can store it in an outer variable or restructure
    })
    .catch(error => {
        console.error('Promise error:', error.message);
        throw error; // rethrow for caller
    })
    .finally(() => {
        console.log('Promise chain fiinished.');
    });
};


export const fetchUseAndPostsWithAsync = async (userId) => {
    console.log('--- Async/Await ---');
    try {
        const user = await fetchUSer(userId);
        console.log('User fetched:', user);
        const posts = await fetchPosts(user.id);
        console.log('Posts fetched:', posts);
        return { user, posts };
    } catch (error) {
        console.error('Async error:', error.message);
        throw error; // rethrow so caller can handle
    } finally {
        console.log('Async function finished.');
    }
};