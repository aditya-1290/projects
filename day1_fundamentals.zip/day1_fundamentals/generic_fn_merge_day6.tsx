// Genericmerge returnning intersection type T & U
export function merge<T extends object, U extends object>(obj1: T, obj2: U): T & U {
    return { ...obj1, ...obj2};
}

// Partial utility type for optional updates
export interface UserProfile {
    id: number;
    name: string;
    email: string;
    role: string;
}

export function updateUser(
    currentProfile: UserProfile, 
    updates: Partial<UserProfile>
): UserProfile {
    return { ...currentProfile, ...updates };
}

// Example usage
const base = { id: 101, name: "Alex" };
const extra = { role: "Admin", active: true };
const mergedUser = merge(base, extra); // Type inferred as { id: number, name: string } & { role: string, active: boolean }

const updated = updateUser(
    { id: 1, name: "Sam", email: "sam@dev.com", role: "Dev" },
    { email: "sam.new@dev.com" } // Partial update
);
