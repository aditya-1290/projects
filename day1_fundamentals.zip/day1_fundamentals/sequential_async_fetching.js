const fetchUser = () => Promise.resolve({userId: 42, username: "dev_trainee" });
const fetchCart = (userId) => Promise.resolve({ownerId: userId, items: ["Laptop", "Mouse"] });

export const loadDataWithThen = () => {
    console.log("Starting the Promise Chain...");

    fetchUser()
        .then(user => {
            console.log(`User found: ${user.username} (ID: ${user.userId})`);
            // We return this promise so the next .then() waits for it
            return fetchCart(user.userId);
        })
        .then(cart => {
            // this runs only after fetchcart resolves
            console.log(`Cart Loaded! Items; ${cart.items.join(", ")}`);
        })
        .catch(error => {
            console.error("An error occurred in the chain:", error);
        });
};

loadDataWithThen();

export const loadDataWithAsync = async () => {
    console.log("Starting Async/Await...");

    try{
        // Line 1 pauses until user data comes back
        const user = await fetchUser();
        console.log(`User found: ${user.username} (ID: ${user.userId})`);

        // Line 2 pauses until that specific user's cart comes back
        const cart = await fetchCart(user.userId);
        console.log(`Cart loaded! Items: ${cart.items.join(", ")}`);
    } catch (error) {
        // Captures errors from Both fetchUser and fetchCart in one central place
        console.error("An error ocurred during async execution:", error);
    }
};

loadDataWithAsync();