import { fetchUseAndPostsWithAsync, fetchUserAndPostWithPromises } from "./async.js";

// Test with valid ID
fetchUserAndPostWithPromises(1)
    .then(result => console.log('Final result (Promise):', result))
    .catch(err => console.error('Unhandled:', err));

// Using async (wrap in an async IIFE because top -level await s suported in modules but we can do it)
(async () => {
    try {
        const result = await fetchUseAndPostsWithAsync(1);
        console.log('Final result (Async):', result);
    } catch (err) {
        console.error('unhandled:', err);
    }
})();

//  Real API Integration
const fetchUser = async (id) => {
  const response = await fetch(`https://jsonplaceholder.typicode.com/users/${id}`);
  if (!response.ok) throw new Error(`Failed to fetch user: ${response.status}`);
  return response.json();
};

const fetchPosts = async (userId) => {
  const response = await fetch(`https://jsonplaceholder.typicode.com/posts?userId=${userId}`);
  if (!response.ok) throw new Error(`Failed to fetch posts: ${response.status}`);
  return response.json();
};
