// the arrays should be immutable: not like the old js where it could be modified directly using .push() method
const fruits = ["apple", "banana"];
fruits.push("orange"); // Modifies the original array directly (Mutation)

// There are three methods that are: .filter(), .reduce(), .map()
// .filter() method looks at every item in an array, runs a true/false test on 
// it, and spits out a new array containing only the items that passed the test.
const scores = [45, 80, 92, 60];
// Only keep scores that are 70 or higher  
const passingScores = scores.filter(score => score >= 70);

console.log(passingScores);  // [80, 92]
console.log(scores);         // [45, 80, 92, 60]  (Original array is untouched!)

//.map() method takes an array, applies a transformation function to every single item, 
// and returns a new array of the exact same length, but with the modified data.
const numbers = [1, 2, 3];
// Double every number
const doubled = numbers.map(num => num * 2);

console.log(doubled); // [2, 4, 6]

// .reduce() method s the most intimidating method for beginners, but it's 
// incredibly powerful. It takes an entire array and blends it down into a 
// single value (like a total sum, a single string, or a combined object).
// It takes a callback function with two main ingredients:
// accumulator (the running total / the blender jar)
// currentItem (the current piece of fruit being thrown into the blender)
// It also takes an initial value for the accumulator as its second argument
const expenses = [10, 20, 30];

// 0 is the starting point (initial accumulator value)
const totalCost = expenses.reduce((accumulator, currentExpense) => {
    return accumulator + currentExpense;
}, 0);

console.log(totalCost); // 60
