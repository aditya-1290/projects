import users from './users_1.js';

// 1. Filter active users (Corrected property to isActive + implicit return)
export const getActiveUsers = () => users.filter(user => user.isActive);

// 2. Map to full names
export const getFullNames = () => users.map(user => `${user.firstName} ${user.lastName}`);

// 3. Reduce to calculate total age of ALL users
export const getTotalAge = () => users.reduce((total, user) => total + user.age, 0);

// 4. Chained pipeline: Total age of ONLY active users
export const totalActiveAge = () => users
    .filter(user => user.isActive)
    .reduce((sum, user) => sum + user.age, 0);

// Optional: Pipeline verification
export const processUsers = () => {
    console.log('Active Users:', getActiveUsers());
    console.log("Full Names:", getFullNames());
    console.log("Total Active Age:", totalActiveAge());
};