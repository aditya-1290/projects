//Challenge 1: The Leaky Settings (Day 1 Focus)
// A junior developer wrote a theme switcher function, but users are complaining that their 
// settings are breaking. Identify why this variable is acting weirdly, and refactor it into an optimized, 
// modern ES6 arrow function with a ternary operator.
function setPreferences(isDarkMode) {
    if (isDarkMode) {
        var theme = "midnight";
    } else {
        var theme = "daylight";
    }
    // Why can we see 'theme' out here? Fix this entire block!
    return "Theme set to: " + theme; // because the 'var' keyword is function scoped so after it's declaration  it can be accesses anywhere in the function without any errors
}

setPreferences();

function setPreferencesLet(isDarkMode) {
    if (isDarkMode) {
        let theme = "midnight";
    } else {
        let theme = "daylight";
    }
    // Why can we see 'theme' out here? Fix this entire block!
    // return "Theme set to: " + theme; // we get this error if we try to access it now out of te block:ReferenceError: theme is not defined
}

setPreferencesLet();

// export  const setPreferencesTheme = theme => isDarkMode() ? "midnight" : "daylight";
export const setPreferencesternary = (isDarkMode) => 
    `Theme set to: ${isDarkMode ? "midnight" : "daylight"}`;


// Challenge 2: The E-Commerce Filter (Day 2 Focus)
// You are handed a list of products. Using modern immutable array methods, write a clean sequence or chain to:
// Filter out products that are out of stock (inStock: false).
// Map the remaining products to an array of string descriptions that read: "Product Name - $Price" (e.g., "Keyboard - $50").
const inventory = [
    { name: "Keyboard", price: 50, inStock: true },
    { name: "Monitor", price: 300, inStock: false },
    { name: "Mouse", price: 25, inStock: true }
];

export const productInStock = () => {
    return inventory.filter(item => item.inStock);
};

export const productDescriptions = () => {
    return inventory.map(prodDescriptions => `"${prodDescriptions.name} - $${prodDescriptions.price}"`);
};

export const getAvailableProductDescriptions = () => {
    return inventory
        .filter(item => item.inStock) // Step 1: Drops the Monitor
        .map(item => `${item.name} - $${item.price}`); // Step 2: Maps only Keyboard & Mouse
};

export const processInventory = () => {
    console.log("products out of stock:", productInStock());
    console.log("mapped description of the products in the inventory:", productDescriptions());
};

processInventory();

console.log(getAvailableProductDescriptions());
console.log(productDescriptions());

// Challenge 3: The Parallel Scanner (Day 3 Focus)
// Look at this for...of loop. It iterates over a list of server IDs and fetches data for each one. 
// Because it uses await inside the loop, it waits for Server 1 to finish completely before it even starts 
// scanning Server 2. This is called a sequential bottleneck.
// Simulates a 1-second network scan
const scanServer = (id) => new Promise(res => setTimeout(() => res(`Data from ${id}`), 1000));

const slowScanner = async () => {
    const serverIds = ["srv-01", "srv-02", "srv-03"];
    
    for (const id of serverIds) {
        const result = await scanServer(id); // Takes 1 second PER server (3 seconds total!)
        console.log(result);
    }
};

// the thing thing we are something very tedious task by taking the id of first server and then executing it and then taking the id of 
// of second server and executing it and so on until we finish our task right so if we have not just 3 servers but more like hundred or something then it is going make the application incredibly slow what we can do is to 
// take in the id of all the server at same time and send request to them and when we get results from them, we execute them by first some first serve so we worn't have to wait for the frist to be finished only then the next process can happen we can jsut change our approa ch instead of sending requests one by one. this is what iis think i don't know whether i am right or wrong??

const scanServer = (id) => new Promise(res => setTimeout(() => res(`Data from ${id}`), 1000));

const fastScanner = async () => {
    const serverIds = ["srv-01", "srv-02", "srv-03"];
    
    // 1. Kick off ALL scans immediately at the same time.
    // .map() creates an array of PENDING promises running concurrently in the background.
    const scanPromises = serverIds.map(id => scanServer(id)); 
    
    try {
        // 2. Pause here until EVERY single promise in the array crosses the finish line.
        const results = await Promise.all(scanPromises);
        
        // 3. Log the final array of results
        console.log("All data collected:", results); 
        
    } catch (error) {
        // If even ONE server fails, Promise.all instantly rejects so you can handle it
        console.error("One of the server scans failed!", error);
    }
};

fastScanner(); // This script executes completely in exactly 1 second!
