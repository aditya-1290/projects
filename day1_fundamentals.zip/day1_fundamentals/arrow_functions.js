// Regular function
// function add(a, b) {
//     return a + b;
// }

// Arrow function - same thing
// const add = (c, d) => {
//     return c + d;
// };

// Arrow function - implicit return (no braces, no `return` keyword)
const add = (e, f) => e + f;

console.log(add(2,3)); // 5

// Rules for shrinking the syntax:

// One parameter → parentheses are optional: x => x * 2
// Zero parameters → parentheses required: () => 42
// One-line body → no {}, no return, the expression's value is returned automatically (called implicit return)
// Multi-line body → needs {} and an explicit return

const square = x => x * x;                 // implicit return
const greet = name => `Hello, ${name}`;    // implicit return + template literal

const complexCalc = (g, h) => {
    const sum = g + h;
    const doubled = sum * 2;
    return doubled;                          // explicit return needed 
};

// Common gotcha — returning an object literal implicitly needs 
// parentheses, because {} looks like a function body to the parse
// const makeUser = name => { name: name}; // WRONG - parse as a function return undefined.
const makeUser = name => ({ name: name}); // correct - parentheses tell JS that this is an object

// uses of 'this' keyword
const person = {
    name: "Aditya",
    regularGReet: function () {
        console.log(this.name); // "Aditya" - `this` = the object calling it
    },
    // arrowGreet: () => {
    //     console.log(this.name); // undefined - `this` here is NOT 'person`,
    // }                           // it's whatever `this` was outside the object
};

person.regularGReet(); // "Aditya"
// person.arrowGreet(); // undefined

// Quick Rule of Thumb

// Short, simple callbacks (map/filter/reduce callbacks, event handlers, promise chains) → arrow functions
// Object methods where you need this to refer to the object itself → regular functions
// Class methods → regular function syntax (or arrow if you specifically need this binding, like the Timer example)

// class Timer {
//   constructor() {
//     this.seconds = 0;
//   }
//   start() {
//     setInterval(function () {
//       this.seconds++; // BROKEN — `this` here is NOT the Timer instance
//       console.log(this.seconds); // NaN or error
//     }, 1000);
//   }
// }


class Timer {
  constructor() {
    this.seconds = 0;
  }
  start() {
    setInterval(() => {
      this.seconds++; // WORKS — arrow function inherits `this` from `start()`,
      console.log(this.seconds); // which correctly refers to the Timer instance
    }, 1000);
  }
}