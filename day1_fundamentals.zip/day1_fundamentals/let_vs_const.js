let count = 5;
count = 10; //works fine with let keyword -> reassignment of variables

const name = "Kapil";
name = "hell"; // TypeError: Assignment to constant variable

// Important nuance: const doesn't make 
// objects/arrays immutable — it just locks the 
// variable name to that reference.

const user = { name : "Aditya" };
user.name = "Rishi"; // works fine - mutating the objects contents
user = { name: "King" }; // TypeError - reassigning the binding itself

// const = "can't reassign the variable," not "the value is frozen."


// .map() is an array method that takes every element in an array, runs a function on each one, and returns a 
// new array with the results — same length, transformed values.
const arr = []
for (var i = 0; i < 3; i++) {
    arr.push(() => i);
}
console.log(arr.map(fn => fn()));
// output - arr = [3, 3, 3]

const arr2 = []
for (let j = 0; j < 3; j++) {
    arr2.push(() => j);
}
console.log(arr2.map(fn => fn()));
// output - arr2=[0, 1, 2]
