function testLet() {
    if (true) {
        let x = 20;
    }
    console.log(x); // ReferenceError: x is not defined.
}

// loops work well as we should expect them to behave using the let keyword
for (let i = 0; i < 3; i++) {
    setTimeout(() => console.log(i), 0);
}  // output: 0, 1, 2 - as i had expected the output was same.
