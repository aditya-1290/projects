//1. Reading & Writing Properties (The Basics)
// An object is just a collection of key-value pairs. Think of it like a dictionary. 
// There are two ways to access or change these pairs.
// Dot Notation vs. Bracket Notation
// Dot Notation (obj.key): Your default choice. Clean and easy to read.
// Bracket Notation (obj["key"]): Use this when the key name is stored in a variable, or has spaces/special characters.

const user = {
    name: "Alex",
    "job title": "Developer" // key with a space
};

// 1. Dot Notation
console.log(user.name); // Alex

// 2. Bracket notation (required for spaces)
console.log(user["job title"]); // "Developer"

// 3. Bracket Notation with a dynamic variable
const propertyToLookUp = "name";
console.log(user[propertyToLookUp]);  // "Alex"

// 2. Immutable Object Manipulation (The Spread Operator)
// Yesterday, I pounded the table about immutability (not changing original data). 
// If you want to change a user's age or add a new property, you could do user.age = 30. 
// But that mutates the original object.

// Instead, we use the Spread Operator (...) to clone the old object and apply changes at the same time.
const product = { id: 101, title: "Laptop", price: 999 };

// Create a NEW object, copy everything, override the price, add a stock property
const updatedProduct = {
    ...product,
    price: 899,       // overrides the original price
    inStock: true     // Adds a brand new property
};

console.log(product);              // { id: 101, title:"Laptop", price:999 }  (Safe and untouched)
console.log(updatedProduct);       // {id: 101, title:"Laptop", price: 899, inStock: true }

// 3. Object Destructuring (Extracting Data Elegantly)
// Back in the day, if you wanted to pull three properties out of an object, you had to write 
// three lines of code. Modern JavaScript gives us Destructuring, which lets us unpack properties directly into variables in a single line.
const employee = {
    id: 5,
    fullName: "Sarah Connor",
    role: "Engineer",
    salary: 120000
};

// Instead of: const role = employee.role; const salary = employee.salary;
// We do this:
const { role, salary, fullName: name } = employee;

console.log(role);   // "Engineer"
console.log(salary); // 120000
console.log(name);   // "Sarah Connor" (We even renamed fullName to just 'name'!)

// What if you want to delete a property like salary before sending this data to the frontend, without using the 
// destructive delete employee.salary command? You can combine destructuring with the rest operator!
// Pull salary out into its own variable, and gather everything REST of the properties into 'publicData'
const { salary: hiddenSalary, ...publicData } = employee;

console.log(publicData); // { id: 5, fullName: "Sarah Connor", role: "Engineer" }
// Magic! 'publicData' is a clean object with no salary attached, and the original employee object is unharmed.

// 4. The Global Object Power Tools
// Sometimes you don't know what keys are inside an object, or you want to loop through an object like it's an array. 
// JavaScript gives us three built-in methods to convert objects into loops-friendly arrays:
const inventory = { apples: 5, bananas: 12, oranges: 8 };

// 1. Object.keys() -> Gives an array of just the keys
console.log(Object.keys(inventory));   // ["apples", "bananas", "oranges"]

// 2. Object.values() -> Gives an array of just the values
console.log(Object.values(inventory)); // [5, 12, 8]

// 3. Object.entries() -> Gives an array of [key, value] pairs
console.log(Object.entries(inventory));
// [ ["apples", 5], ["bananas", 12], ["oranges", 8] ]


const user = { theme: "dark" };

const userLight = { ...user, theme: "light" };

console.log(userLight);
