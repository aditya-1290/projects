// Your Assignment
// Write a function called createSecureCart().
// Private Memory Vault (Closure): Inside it, declare a private array variable called items = []. (Do not expose this array on the returned object).
// Exposed Methods: Return an object containing exactly three operations:
// addItem(product): Pushes a product object { name: string, price: number } into the private array.
// getCartTotal(): Uses the modern .reduce() array method to return the sum total of all item prices currently inside the private array.
// applyDiscount(discountCalculator): This method will take a callback function as an argument. Inside applyDiscount, you must execute that callback function explicitly bound (.call or .apply) to an object containing { total: currentTotal }.
const createSecureCart = () => {
    let items = [];

    return addItem = () => {
        items = [{name: "Phone", price: 10000}, {name: "Laptop", price: 50000}]
    }
}
