// default binding of this keyword
function showThis() {
    console.log(this);
}
showThis(); // In browser: window, in Node: global (or undefined in strict mode)

// Implicit binding
const user = {
    name: 'Alice',
    greet () {
        console.log(`Hello, ${this.name}`);
    }
};
user.greet(); // this = user, prints "Hello, Alice"

// const greetFn = user.greet;
// greetFn(); // this is undefined (strict) or global; error or undefined name

// Explicit binding: call, apply, bind\
function introduce(greeting, punctuation) {
    console.log(`${greeting}, I'm ${this.name}${punctuation}`);
}
const person = { name = 'Bob' };

introduce.call(person, 'Hi', '!');  // Hi, I'm Bob!
introduce.apply(person, ['Hello', '.']);  // Hello, I'm Bob.

const boundIntroduce = introduce.bind(person, 'Hey');
boundIntroduce('!!'); // Hey, I'm Bob!!
