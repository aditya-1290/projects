// app.js
import {add, subtract, multiply, divide, divide1 } from './calculator.js';
import calculator from './calculator.js';

// using named imports
console.log(`2 + 7 = ${add(2, 7)}`);
console.log(`4 - 9 = ${subtract(4, 9)}`);
console.log(`3 * 4 = ${multiply(3, 4)}`);
// console.log(`2 / 0 = ${divide(2, 0)}`);
console.log(`20 / 4 = ${divide(20, 4)}`);
console.log(`20 / 4 = ${divide(25, 4)}`);

// Using default import (object)
console.log(`Using default: 11 + 1 = ${calculator.add(11, 1)}`);

// Erro handling example
try {
    console.log(divide(10, 0));
} catch (error){
    console.error('Error:', error.message);
};
