// A funciton that simulates the fetching data and returns a Promise
const fetchProduct = () => {
    return new Promise((resolve, reject) => {
        let success = true;
        setTimeout(() => {
            if (success) resolve({id: 1, name: "Sneakers" });
            else reject("Failed to eftch product data.");
        }, 1000);
    });
};

// Consuming the promise
fetchProduct()
    .then(product => console.log("Success:", product))   // Runs if the resolve() function is called
    .catch(error => console.error("Error:", error))      // Runs if the reject() funciton is called
    .finally(() => console.log("Operation Finished."));  // ALways runs

// The Rules of async/await:
// You can only use the await keyword inside a function marked with the async keyword.
// await pauses the function execution until the promise settles (either resolves or rejects).
// To handle errors, you wrap your code in a traditional try...catch block.
const displayProductData = async () => {
    try {
        // Pause right here until fetchProduct finishes, then assign the result to product
        const product = await fetchProduct();
        console.log("Async/Await Success:", product);
    } catch (error) {
        // if fetchProduct rejects, execution instantly jumps down here
        console.error("Async/Await Error caught: ", error);
    }
};

displayProductData();
