// Vehicle base class
class Vehicle {
    constructor(make, model) {
        this.make = make;
        this.model = model;
    }

    getDetails() {
        return `${this.make} ${this.model}`;
    }
}

// Car subclass extending Vehicle
class Car extends Vehicle {
    constructor(make, model, doors) {
        super(make, model);
        this.doors = doors;
        
        // Explicitly binding 'this' context for standalone method invocation
        this.getDetails = this.getDetails.bind(this);
    }

    getDetails() {
        return `${super.getDetails()} with ${this.doors} doors`;
    }
}

// Verification of bound context
const myCar = new Car("Toyota", "Camry", 4);
const unboundDetailsGetter = myCar.getDetails;

// Works without losing 'this' context because of explicit constructor binding
console.log(unboundDetailsGetter()); // "Toyota Camry with 4 doors"
