import users from './users.js';

// 1. Filter active users
export const getActiveUsers = () => {
    return users.filter(user => user.active);
};

// 2. Map to full names
export const getFullNames = () => {
    // map creates a new array with transformed elements
    return users.map(user => `${user.firstName} ${user.lastName}`);
};

// 3. Reduce to calculate the total age 
export const getTotalAge = () => {
    // reduce with the initial value 0 to avoid type issues
    return users.reduce((total, user) => total + user.age, 0);
};

// 4. chaining the filter and reduce functions to get age of active users
export const totalActiveAge = () => {
    let activeusersage = users
        .filter(user => user.active)
        .reduce((sum, user) => sum + user.age, 0);
    return activeusersage;
};

//Optional: cobine all in a pipeline and log
export const processUsers = () => {
    console.log('Active Users:', getActiveUsers());
    console.log("Full Names:", getFullNames());
    console.log("Total Age:", getTotalAge());
};