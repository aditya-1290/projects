export interface User {
    id: number;
    fullName: string;
    age: number;
    isActive: boolean;
}

// Custom Type Guard
export function isUser(obj: unknown): obj is User {
    return (
        typeof obj === "object" &&
        obj !== null &&
        "id" in obj &&
        "fullName" in obj &&
        "age" in obj &&
        "isActive" in obj
    );
}

// Strictly Typed Array Methods
const rawData: unknown[] = [
    { id: 1, fullName: "Alice Smith", age: 28, isActive: true },
    { id: 2, fullName: "Bob Jones", age: 34, isActive: false },
    "invalid_data_string"
];

// 1. Narrowing using custom type guard
const users: User[] = rawData.filter(isUser);

// 2. Filter with explicit callback signature
const activeUsers: User[] = users.filter((user: User): boolean => user.isActive);

// 3. Map with explicit callback signature
const fullNames: string[] = users.map((user: User): string => user.fullName);

// 4. Reduce with explicit accumulator and current item signatures
const totalAge: number = users.reduce((acc: number, user: User): number => acc + user.age, 0);
