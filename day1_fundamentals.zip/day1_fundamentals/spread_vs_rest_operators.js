// The Spread Operator (Unpacking a box)
// Spread takes an existing array or object and unpacks its 
// items into a new environment. This is your go-to tool for immutable data updates.
// Copying and adding to arrays
const oldItems = ["shoes", "shirt"];
const newItems = [...oldItems, "hat"]; // Unpacks old items and appends "hat"
console.log(newItems); // ["shoes", "shirt", "hat"]

// Copying and updating objects
const user = { name: "Alice", role: "User" };
const updatedUser = { ...user, role: "Admin" }; // Copies user, overrides role
console.log(updatedUser); // { name: "Alice", role: "Admin" }

// The Rest Operator (Packing items into a box)
// Rest does the opposite. It gathers multiple scattered elements 
// and packs them into a neat array box. It’s usually found in function parameters.
// Gather all arguments into an array called "allNumbers"
const sumEverything = (...allNumbers) => {
    return allNumbers.reduce((total, num) => total + num, 0);
};

console.log(sumEverything(1, 2, 3, 4)); // 10

