// 1. THE HOISTING & TDZ DEMO

console.log("--- Hoisting Demo ---");
console.log(ghost); // Prints: undefined (It exists in memory, but has no value yet)
// console.log(trapped); // ❌ UNCOMMENTING THIS WILL CRASH THE SCRIPT! Throws ReferenceError (TDZ)

var ghost = "Boo! I'm here.";
let trapped = "Finally initialized!";

console.log(ghost);   // Prints: "Boo! I'm here."
console.log(trapped); // Prints: "Finally initialized!"

// 2. THE LOOP LEAK DEMO

console.log("\n--- Loop Leak Demo ---");

for (var i = 0; i < 3; i++) {
    var leak = "I am a leaked variable from inside the loop!";
    let secure = "I am locked in this loop block.";
}

// Outside the loop now:
console.log("Counter 'i' value:", i);       // Prints: 3 (The counter leaked out!)
console.log("Can I see 'leak'?:", leak);    // Prints: "I am a leaked variable..."
// console.log(secure); // UNCOMMENTING THIS WILL CRASH THE SCRIPT! secure is not defined.

// 3. THE FUNCTION SHIELD DEMO

console.log("\n--- Function Shield Demo ---");

function vault() {
    var gold = "100 Gold Bars";
    console.log("Inside vault:", gold); // Works perfectly!
}

vault();

// Trying to steal the gold outside the function:
// console.log(gold); // UNCOMMENTING THIS WILL CRASH THE SCRIPT! ReferenceError: gold is not defined.