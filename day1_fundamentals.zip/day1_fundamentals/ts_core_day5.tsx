// Interface definitions
export interface IVehicle {
    make: string;
    model: string;
    getDetails(): string;
}

export interface ICar extends IVehicle {
    doors: number;
}

// TS Class Implementation
export class Vehicle implements IVehicle {
    public make: string;
    public model: string;

    constructor(make: string, model: string) {
        this.make = make;
        this.model = model;
    }

    public getDetails(): string {
        return `${this.make} ${this.model}`;
    }
}

export class Car extends Vehicle implements ICar {
    public doors: number;

    constructor(make: string, model: string, doors: number) {
        super(make, model);
        this.doors = doors;
        this.getDetails = this.getDetails.bind(this);
    }

    public override getDetails(): string {
        return `${super.getDetails()} with ${this.doors} doors`;
    }
}
