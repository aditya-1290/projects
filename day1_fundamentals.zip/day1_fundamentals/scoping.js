// var is function scoped (or global)
function testVar() {
    var x = 10;
    if  (true) {
        var x = 20; // same variable
        console.log('Inside block:', x); // 20
    }
    console.log('Otuside block:', x); // 20 (not 10)
}

// let is block-scoped
function testLet() {
    let y = 10;
    if (true) {
        let y = 20; // different variable 
        console.log('Inside block:', y); // 20
    }
    console.log('Outside block:', y); // 10
}

// Ternary Operator & Template Literals
const age = 18;
const canVote = age >= 18 ? 'Yes' : 'No';
console.log('Can this  person vote? ${canVote}');

// Spread and Rest Operators
const arr1 = [1,2,3];
const arr2 = [4,5,6];
const combined = [...arr1, ...arr2]; // [1,2,3,4,5,6]

// Rest in function parameters
function sum(...numbers) {
    return numbers.reduce((acc, n) => acc + n, 0);
}
console.log(sum(1,2,3,4)); // 10

