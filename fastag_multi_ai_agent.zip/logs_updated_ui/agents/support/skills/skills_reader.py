"""
Skill: Skills Reader
Reads skills.md, matches user query to the best skill by keyword scoring,
returns the matched skill name + SQL.
"""
import os
import re
from typing import Optional, Dict
from core.logger import get_logger

logger = get_logger("skills_reader")

SKILLS_MD_PATH = os.path.join(os.path.dirname(__file__), "..", "..", "..", "skills.md")


def load_skills() -> list:
    """
    Parse skills.md into a list of skill dicts.
    Each skill: { name, keywords: [str], sql: str }
    """
    skills = []
    try:
        with open(SKILLS_MD_PATH, "r", encoding="utf-8") as f:
            content = f.read()

        # Split by ## skill:
        blocks = re.split(r"##\s*skill:\s*", content, flags=re.IGNORECASE)
        for block in blocks:
            block = block.strip()
            if not block:
                continue

            lines = block.splitlines()
            skill_name = lines[0].strip()

            keywords_line = ""
            sql_line = ""

            for line in lines[1:]:
                line = line.strip()
                if line.lower().startswith("keywords:"):
                    keywords_line = line[len("keywords:"):].strip()
                elif line.lower().startswith("sql:"):
                    sql_line = line[len("sql:"):].strip()

            if skill_name and sql_line:
                keywords = [k.strip().lower() for k in keywords_line.split(",") if k.strip()]
                skills.append({
                    "name": skill_name,
                    "keywords": keywords,
                    "sql": sql_line,
                })

        logger.info(f"[SKILLS_READER] Loaded {len(skills)} skills from skills.md")
    except Exception as e:
        logger.error(f"[SKILLS_READER] Failed to load skills.md: {e}")

    return skills


def match_skill(user_query: str) -> Optional[Dict]:
    """
    Score each skill by token‑based keyword matches.
    Returns the best matching skill dict or None.
    """
    skills = load_skills()
    if not skills:
        return None

    query_lower = user_query.lower()
    query_tokens = set(query_lower.split())  # simple whitespace tokenisation

    best_skill = None
    best_score = 0

    for skill in skills:
        score = 0
        for kw in skill["keywords"]:
            # Exact whole keyword match gives 2 points
            if kw in query_lower:
                score += 2
            else:
                # Count overlapping tokens between keyword and query
                kw_tokens = set(kw.split())
                overlap = len(kw_tokens & query_tokens)
                score += overlap      # 1 point per overlapping token

        if score > best_score:
            best_score = score
            best_skill = skill

    if best_skill and best_score > 0:
        logger.info(f"[SKILLS_READER] Matched skill: '{best_skill['name']}' (score={best_score})")
        return best_skill, best_score

    logger.warning(f"[SKILLS_READER] No keyword match found for: '{user_query}'")
    return None, 0   # do NOT fallback to the first skill – return None
