"""
agents/support/agent.py
Support Agent — same ADK framework + bridge as orchestrator and mlff.
Reads SQL from skills.md, executes via MCP, explains result via LLM.
"""
import os
import warnings
os.environ["OTEL_SDK_DISABLED"] = "true"
warnings.filterwarnings("ignore", category=UserWarning, module="google.adk")

import re
import uuid as _uuid
import json
import asyncio
from typing import Any, Dict

from dotenv import load_dotenv
from google.adk.agents import LlmAgent
from google.adk.models.lite_llm import LiteLlm
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types

from agents.support.agent_card import SUPPORT_CARD
from agents.support.skills.skills_reader import match_skill
from agents.support.prompts import SUPPORT_RESULT_FORMATTER_PROMPT
from core.mcp_client import mcp_client
from core.llm_client import call_llm
from core.tool_call_parser import (
    parse_tool_call, execute_parsed_tool, detect_tool_call,
    detect_tool_response, detect_batch_tool_calls, parse_batch_tool_calls,
    format_tool_response, set_tools_map,
)
from core.logger import get_logger, success_logger, error_logger
from core.tool_call_parser import ALL_KNOWN_TOOLS

load_dotenv()
logger = get_logger("fastag_ai_agent_v2")

os.environ["OPENAI_API_KEY"] = os.getenv("LOCAL_LLM_API_KEY", "sk-local")
os.environ["OPENAI_API_BASE"] = os.getenv("LOCAL_LLM_BASE_URL", "http://127.0.0.1:8001/v1")

_model = LiteLlm(model=f"openai/{os.getenv('LOCAL_LLM_MODEL', 'local-model')}")

MAX_DISPLAY_ROWS = 50
MAX_BRIDGE_ITERATIONS = 8

ALL_KNOWN_TOOLS.extend(["read_skill", "execute_support_sql", "explain_support_result"])

# ── ADK Tool functions ────────────────────────────────────────────────────────

def read_skill(user_query: str) -> str:
    """Read skills.md and return the best matching skill name and SQL for the user query."""
    try:
        skill, _ = match_skill(user_query)   # unpack the tuple, ignore score
        if not skill:
            return json.dumps({
                "ok": False,
                "skill_name": "",
                "sql": "",
                "error": "No matching skill found in skills.md",
            })
        return json.dumps({
            "ok": True,
            "skill_name": skill["name"],
            "sql": skill["sql"],
            "keywords": skill["keywords"],
        })
    except Exception as e:
        error_logger.error(f"read_skill error: {e}")
        return json.dumps({"ok": False, "skill_name": "", "sql": "", "error": str(e)})


def execute_support_sql(sql: str) -> str:
    """Execute a pre-written SQL query from skills.md via MCP server. Read-only."""
    try:
        result = mcp_client.execute_query(sql)
        if result.get("rows"):
            result["rows"] = result["rows"][:MAX_DISPLAY_ROWS]
            result["row_count"] = len(result["rows"])
        return json.dumps(result, default=str)
    except Exception as e:
        error_logger.error(f"execute_support_sql error: {e}")
        return json.dumps({"ok": False, "error": str(e), "rows": [], "row_count": 0})


def explain_support_result(user_query: str, skill_name: str, sql: str, execution_result_json: str) -> str:
    """Generate a natural language explanation and chart suggestion for support query results."""
    try:
        if isinstance(execution_result_json, str):
            execution_result_json = execution_result_json.replace('<|"|>', '"').replace('<|"|', '"').replace('"|>', '"')

        exec_result = json.loads(execution_result_json) if isinstance(execution_result_json, str) else execution_result_json
        rows = exec_result.get("rows", [])
        row_count = exec_result.get("row_count", 0)
        sample_rows = rows[:5]

        try:
            sample_json = json.dumps(sample_rows, default=str, indent=2)
        except Exception:
            sample_json = str(sample_rows)

        prompt = SUPPORT_RESULT_FORMATTER_PROMPT.format(
            user_query=user_query,
            skill_name=skill_name,
            sql=sql,
            row_count=row_count,
            sample_rows=sample_json,
        )

        system = (
            "You are a data analyst. Return only valid JSON. "
            "No markdown. No extra text. Respond with the JSON object only."
        )

        raw = call_llm(system, prompt, max_tokens=256)
        raw = raw.strip()

        if "```" in raw:
            parts = raw.split("```")
            for part in parts:
                s = part.strip()
                if s.lower().startswith("json"):
                    s = s[4:].strip()
                if s.startswith("{"):
                    raw = s
                    break

        result = json.loads(raw)
        return json.dumps({
            "explanation": result.get("explanation", "Results retrieved successfully."),
            "chart_type": result.get("chart_type", "table"),
            "chart_reason": result.get("chart_reason", ""),
        })

    except Exception as e:
        error_logger.error(f"explain_support_result error: {e}")
        return json.dumps({
            "explanation": "Support query executed successfully.",
            "chart_type": "table",
            "chart_reason": "Fallback — LLM explanation failed.",
        })


# ── Tools map ─────────────────────────────────────────────────────────────────

_TOOLS_MAP = {
    "read_skill": read_skill,
    "execute_support_sql": execute_support_sql,
    "explain_support_result": explain_support_result,
}

set_tools_map(_TOOLS_MAP)


# ── ADK LlmAgent ──────────────────────────────────────────────────────────────

SUPPORT_INSTRUCTION = """
You are the Support Agent. Answer predefined business queries using skills.md.

For every request call these tools in order:

Step 1 - Read skill:
read_skill(user_query="the user's question")

Step 2 - Execute SQL:
execute_support_sql(sql="the sql from step 1")

Step 3 - Explain results:
explain_support_result(user_query="...", skill_name="from step 1", sql="from step 1", execution_result_json="result from step 2")

After all 3 tools, return ONLY this JSON (no markdown, no explanation):
{
  "sql": "<sql from step 1>",
  "ok": true,
  "rows": [],
  "row_count": 0,
  "columns": [],
  "explanation": "<from step 3>",
  "chart_type": "<from step 3>",
  "chart_reason": "<from step 3>",
  "error": ""
}
"""

support_llm_agent = LlmAgent(
    name="support",
    model=_model,
    description=SUPPORT_CARD.description,
    instruction=SUPPORT_INSTRUCTION,
    tools=[read_skill, execute_support_sql, explain_support_result],
    output_key="support_result",
)

_session_service = InMemorySessionService()


# ── Bridge Runner (identical pattern to mlff) ─────────────────────────────────

async def _run_with_bridge(
    session_service: InMemorySessionService,
    user_id: str,
    session_id: str,
    initial_message: str,
    app_name: str = "mlff_adk",
    query_id: str = "",
) -> str:
    tool_results = {}
    iterations = 0
    current_message = initial_message

    while iterations < MAX_BRIDGE_ITERATIONS:
        iterations += 1

        session_id_iter = f"{session_id}_{query_id}_iter{iterations}"
        await session_service.create_session(
            app_name=app_name,
            user_id=user_id,
            session_id=session_id_iter,
        )

        fresh_runner = Runner(
            agent=support_llm_agent,
            app_name=app_name,
            session_service=session_service,
        )

        logger.debug(f"[BRIDGE] Support Iteration {iterations} | session={session_id_iter}")

        message = types.Content(
            role="user",
            parts=[types.Part(text=current_message)],
        )

        raw_text = ""
        gen = fresh_runner.run_async(
            user_id=user_id,
            session_id=session_id_iter,
            new_message=message,
        )

        try:
            async for event in gen:
                if event.is_final_response():
                    if event.content and event.content.parts:
                        raw_text = event.content.parts[0].text or ""
                        logger.debug(f"[BRIDGE] Support raw output (iter {iterations}): {raw_text[:200]}")
                    await gen.aclose()
                    break
        except Exception as e:
            if "created in a different Context" not in str(e):
                logger.error(f"Support bridge unexpected error: {e}")

        if not raw_text:
            logger.warning(f"[BRIDGE] Support empty response on iteration {iterations}")
            break

        # ── Handle Batch tool calls ────────────────────────
        if detect_batch_tool_calls(raw_text):
            parsed_list = parse_batch_tool_calls(raw_text)
            if parsed_list:
                for parsed in parsed_list:
                    tool_result = await execute_parsed_tool(parsed, _TOOLS_MAP)
                    if tool_result:
                        tool_results[parsed['tool_name']] = tool_result

        # ── Handle Single tool CALL ────────────────────────
        elif detect_tool_call(raw_text):
            parsed = parse_tool_call(raw_text)
            if parsed:
                tool_result = await execute_parsed_tool(parsed, _TOOLS_MAP)
                if tool_result:
                    tool_results[parsed['tool_name']] = tool_result
                    logger.info(f"[BRIDGE] Support tool executed: {parsed['tool_name']} | result_len={len(tool_result)}")
                else:
                    break
            else:
                break
        # Early fallback if no matching skills
        if "read_skill" in tool_results:
            skill_data = json.loads(tool_results["read_skill"])
            if not skill_data.get("ok"):
                logger.warning("[BRIDGE] No matching skill found; returning error")
                return _synthesize_support_results(tool_results, initial_message)

        # ── Deterministic completion ─────────────────────
        if all(k in tool_results for k in ["read_skill", "execute_support_sql", "explain_support_result"]):
            logger.info("[BRIDGE] Support all tools complete, synthesizing")
            return _synthesize_support_results(tool_results, initial_message)

        if "read_skill" in tool_results and "execute_support_sql" not in tool_results:
            skill_data = json.loads(tool_results["read_skill"])
            sql = skill_data.get("sql", "")
            skill_name = skill_data.get("skill_name", "")
            if sql:
                exec_result = execute_support_sql(sql)
                tool_results["execute_support_sql"] = exec_result
                explain_result = explain_support_result(
                    user_query=initial_message,
                    skill_name=skill_name,
                    sql=sql,
                    execution_result_json=exec_result,
                )
                tool_results["explain_support_result"] = explain_result
                return _synthesize_support_results(tool_results, initial_message)

        # If no progress, break
        if not tool_results:
            break

        # Prepare for next iteration only if we still need execute/explain
        prior_context = "\n".join([f"Tool {k} returned: {v[:300]}" for k, v in tool_results.items()])
        current_message = (
            f"Original request:\n{initial_message}\n\n"
            f"Results so far:\n{prior_context}"
        )

    # Fallback
    if tool_results:
        return _synthesize_support_results(tool_results, initial_message)
    return ""

def _synthesize_support_results(tool_results: dict, user_query: str) -> str:
    """Build final Support JSON directly from collected tool results."""
    skill_raw = tool_results.get("read_skill", "{}")
    exec_raw = tool_results.get("execute_support_sql", "{}")
    explain_raw = tool_results.get("explain_support_result", "{}")

    # try:
    #     skill_data = json.loads(skill_raw) if isinstance(skill_raw, str) else skill_raw
    # except Exception:
    #     skill_data = {}

    # try:
    #     exec_data = json.loads(exec_raw) if isinstance(exec_raw, str) else exec_raw
    # except Exception:
    #     exec_data = {}

    try:
        skill_data = json.loads(skill_raw) if isinstance(skill_raw, str) else skill_raw
    except Exception:
        skill_data = {}

    # If execute_support_sql missing — run it directly
    if not exec_raw or exec_raw == "{}":
        sql = skill_data.get("sql", "")
        if sql:
            exec_raw = execute_support_sql(sql)

    try:
        exec_data = json.loads(exec_raw) if isinstance(exec_raw, str) else exec_raw
    except Exception:
        exec_data = {}

    try:
        explain_data = json.loads(explain_raw) if isinstance(explain_raw, str) else explain_raw
    except Exception:
        explain_data = {}

    rows = exec_data.get("rows", [])
    columns = list(rows[0].keys()) if rows else []

    return json.dumps({
        "sql": skill_data.get("sql", ""),
        "ok": exec_data.get("ok", True),
        "rows": rows,
        "row_count": exec_data.get("row_count", len(rows)),
        "columns": columns,
        "explanation": explain_data.get("explanation", "Support query executed successfully."),
        "chart_type": explain_data.get("chart_type", "table"),
        "chart_reason": explain_data.get("chart_reason", ""),
        "error": exec_data.get("error", ""),
        "skill_name": skill_data.get("skill_name", ""),
    })


# ── Fallback (direct Python — no ADK) ────────────────────────────────────────

async def _support_fallback(user_query: str, session_id: str) -> Dict[str, Any]:
    """Direct Python fallback if ADK bridge fails."""
    logger.warning(f"[{session_id}] Using Support fallback (direct skill calls)")
    try:
        skill_raw = read_skill(user_query)
        skill_data = json.loads(skill_raw)

        if not skill_data.get("ok"):
            raise ValueError(skill_data.get("error", "No skill found"))

        sql = skill_data["sql"]
        skill_name = skill_data["skill_name"]

        exec_raw = execute_support_sql(sql)
        exec_data = json.loads(exec_raw)

        rows = exec_data.get("rows", [])[:MAX_DISPLAY_ROWS]
        row_count = len(rows)
        columns = list(rows[0].keys()) if rows else []

        explain_raw = explain_support_result(user_query, skill_name, sql, exec_raw)
        explain_data = json.loads(explain_raw)

        return {
            "ok": exec_data.get("ok", False),
            "sql": sql,
            "rows": rows,
            "row_count": row_count,
            "columns": columns,
            "explanation": explain_data.get("explanation", ""),
            "chart_type": explain_data.get("chart_type", "table"),
            "chart_reason": explain_data.get("chart_reason", ""),
            "error": exec_data.get("error", ""),
            "skill_name": skill_name,
        }
    except Exception as e:
        return {
            "ok": False, "sql": "", "rows": [], "row_count": 0,
            "columns": [], "explanation": str(e),
            "chart_type": "none", "chart_reason": "", "error": str(e),
        }


# ── Public interface ──────────────────────────────────────────────────────────

async def run_support_async(
    user_query: str,
    session_id: str,
    user_id: str = "mlff_user",
) -> Dict[str, Any]:
    """Run Support Agent with bridge. Returns full result dict for UI."""

    success_logger.info(f"[{session_id}] Support Agent started | query={user_query[:80]}")

    context_message = f"""
User query: {user_query}

Read the matching skill from skills.md, execute the SQL, and explain the result.
Now call read_skill, then execute_support_sql, then explain_support_result.
"""

    try:
        support_session_id = f"support_{session_id}_{_uuid.uuid4().hex[:6]}"
        query_id = _uuid.uuid4().hex[:8]

        final_text = await _run_with_bridge(
            session_service=_session_service,
            user_id=user_id,
            session_id=support_session_id,
            initial_message=context_message,
            query_id=query_id,
        )

        success_logger.info(f"[{session_id}] Support raw output: {final_text[:200]}")

        clean = final_text.strip()
        if not clean:
            raise ValueError("Empty response from Support bridge")

        if "```" in clean:
            parts = clean.split("```")
            for part in parts:
                s = part.strip()
                if s.lower().startswith("json"):
                    s = s[4:].strip()
                if s.startswith("{"):
                    clean = s
                    break

        result = json.loads(clean)
        result["ok"] = result.get("ok", True)

    except Exception as e:
        error_logger.error(f"[{session_id}] Support bridge/parse error: {e}")
        result = await _support_fallback(user_query, session_id)

    result.update({
        "request_id": session_id,
        "user_query": user_query,
        "intent": "support",
        "query_type": "support",
        "confidence": 1.0,
        "confidence_note": "",
        "low_confidence": False,
        "selected_schema": "",
        "selected_tables": [],
        "context_summary": f"Answered via skills.md skill: {result.get('skill_name', '')}",
    })

    success_logger.info(f"[{session_id}] Support complete | ok={result.get('ok')} | rows={result.get('row_count', 0)}")
    return result
