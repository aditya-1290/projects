"""
Dispute Agent – Dynamic SQL generation + external log analysis.
Now uses only generated SQL from the LLM based on the fixed dispute tables.
"""
import os
import warnings
os.environ["OTEL_SDK_DISABLED"] = "true"
warnings.filterwarnings("ignore", category=UserWarning, module="google.adk")

import uuid as _uuid
import json
import asyncio
from typing import Any, Dict

from dotenv import load_dotenv
from google.adk.agents import LlmAgent
from google.adk.models.lite_llm import LiteLlm
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types

from agents.dispute.agent_card import DISPUTE_CARD
from agents.dispute.skills.param_extractor import extract_params
from agents.dispute.skills.log_service import call_log_analysis
from agents.dispute.prompts import DISPUTE_RESULT_FORMATTER_PROMPT
from core.mcp_client import mcp_client
from core.llm_client import call_llm
from core.tool_call_parser import (
    parse_tool_call, execute_parsed_tool, detect_tool_call,
    detect_tool_response, detect_batch_tool_calls, parse_batch_tool_calls,
    format_tool_response, set_tools_map, ALL_KNOWN_TOOLS,
)
from core.logger import get_logger, success_logger, error_logger
from core.config import config

load_dotenv()
logger = get_logger("dispute_agent")

os.environ["OPENAI_API_KEY"] = os.getenv("LOCAL_LLM_API_KEY", "sk-local")
os.environ["OPENAI_API_BASE"] = os.getenv("LOCAL_LLM_BASE_URL", "http://127.0.0.1:8001/v1")

_model = LiteLlm(model=f"openai/{os.getenv('LOCAL_LLM_MODEL', 'local-model')}")

MAX_DISPLAY_ROWS = 50
MAX_BRIDGE_ITERATIONS = 8

# Mini-cache for dispute tables
DISPUTE_TABLE_LIST = config.DISPUTE_TABLES

def _build_dispute_cache():
    full_cache = mcp_client.get_cache()
    schemas_data = full_cache.get("schemas", {})
    allowed = {}
    qualified_tables = []
    selected_schema = None

    for full_name in DISPUTE_TABLE_LIST:
        if "." in full_name:
            schema, table = full_name.split(".", 1)
        else:
            schema, table = "public", full_name
        if selected_schema is None:
            selected_schema = schema
        info = schemas_data.get(full_name, {})
        if info:
            allowed[table] = {
                "columns": info.get("columns", []),
                "row_count": info.get("row_count", 0),
            }
            qualified_tables.append(f"{schema}.{table}")

    all_rels = full_cache.get("relationships", {})
    rel_hints = []
    for rkey in all_rels:
        parts = rkey.split(" -> ")
        if len(parts) != 2:
            continue
        from_table = parts[0].split(".")[1] if "." in parts[0] else ""
        to_table = parts[1].split(".")[1] if "." in parts[1] else ""
        if from_table in allowed or to_table in allowed:
            rel_hints.append(rkey)

    return {
        "selected_schema": selected_schema,
        "selected_tables": list(allowed.keys()),        # for internal checks
        "qualified_tables": qualified_tables,           # for SQL generation
        "schema_details": allowed,
        "relationships_hint": rel_hints,
    }

_DISPUTE_CACHE = _build_dispute_cache()

# ── Tool functions ────────────────────────────────────────────────────

def generate_dispute_sql(user_query: str, intent: str = "lookup", query_type: str = "simple") -> str:
    """Generate ad‑hoc SQL for dispute queries using the dispute cache."""
    try:
        cache = _DISPUTE_CACHE
        if not cache["qualified_tables"]:
            return "-- No dispute tables configured"

        schema_text = "TABLES AND COLUMNS (use ONLY these exact names):\n\n"
        for full_name in cache["qualified_tables"]:
            _, table = full_name.split(".", 1)
            info = cache["schema_details"].get(table, {})
            cols = info.get("columns", [])[:10]
            schema_text += f"  Table: {full_name}\n"
            for c in cols:
                pk = " [PK]" if c.get("primary_key") else ""
                schema_text += f"    - {c['column_name']} ({c['data_type']}){pk}\n"
            schema_text += "\n"

        rel_text = "\n".join(cache["relationships_hint"]) or "None"

        prompt = f"""CRITICAL: Write a SELECT query ONLY for this question: "{user_query}"
            Intent: {intent}
            Complexity: {query_type}
            
            {schema_text}
            Foreign key hints: {rel_text}
            
            Rules:
            - Use ONLY the exact table/column names above.
            - Always qualify table names with the schema (e.g., toll.transactions).
            - Read‑only SELECT only. Add LIMIT 50.
            - Return ONLY the raw SQL, no markdown, no explanation."""

        system = "You are a PostgreSQL expert. Write only safe SELECT queries."
        raw = call_llm(system, prompt, max_tokens=256)
        sql = raw.strip()

        if "```" in sql:
            parts = sql.split("```")
            for part in parts:
                s = part.strip()
                if s.upper().startswith("SELECT") or s.upper().startswith("WITH"):
                    sql = s
                    break
        return sql
    except Exception as e:
        error_logger.error(f"generate_dispute_sql error: {e}")
        return f"-- SQL generation failed: {e}"


def execute_dispute_sql(sql: str) -> str:
    """Execute a SQL query via MCP server. Read‑only, validated."""
    try:
        result = mcp_client.execute_query(sql)
        if result.get("rows"):
            result["rows"] = result["rows"][:MAX_DISPLAY_ROWS]
            result["row_count"] = len(result["rows"])
        return json.dumps(result, default=str)
    except Exception as e:
        error_logger.error(f"execute_dispute_sql error: {e}")
        return json.dumps({"ok": False, "error": str(e), "rows": [], "row_count": 0})


async def call_log_analysis_tool(user_query: str, sql: str, exec_result_json: str) -> str:
    """Call external log analysis service (mock for now)."""
    params = extract_params(user_query)
    db_result = json.loads(exec_result_json) if isinstance(exec_result_json, str) else {}
    result = await call_log_analysis(user_query, params, db_result)
    return json.dumps(result)


def explain_dispute_result(
    user_query: str,
    sql: str,
    execution_result_json: str,
    log_analysis_json: str = "{}",
) -> str:
    """Generate natural language explanation combining DB and log analysis."""
    try:
        exec_result = json.loads(execution_result_json) if isinstance(execution_result_json, str) else {}
        rows = exec_result.get("rows", [])
        row_count = exec_result.get("row_count", len(rows))
        sample_rows = rows[:5]
        sample_json = json.dumps(sample_rows, default=str, indent=2)

        prompt = DISPUTE_RESULT_FORMATTER_PROMPT.format(
            user_query=user_query,
            skill_name="dynamic",  # no skill name anymore
            sql=sql,
            db_row_count=row_count,
            db_sample_rows=sample_json,
            log_analysis_json=log_analysis_json,
        )
        system = "You are a data analyst. Return only valid JSON. No markdown."
        raw = call_llm(system, prompt, max_tokens=300)
        raw = raw.strip()
        if "```" in raw:
            parts = raw.split("```")
            for part in parts:
                s = part.strip()
                if s.startswith("{"):
                    raw = s
                    break
        result = json.loads(raw)
        return json.dumps({
            "explanation": result.get("explanation", ""),
            "chart_type": result.get("chart_type", "table"),
            "chart_reason": result.get("chart_reason", ""),
        })
    except Exception as e:
        error_logger.error(f"explain_dispute_result error: {e}")
        return json.dumps({
            "explanation": "Dispute investigation completed.",
            "chart_type": "table",
            "chart_reason": "Fallback – LLM explanation failed.",
        })


# ── Tools map ──────────────────────────────────────────────────────────

_TOOLS_MAP = {
    "generate_dispute_sql": generate_dispute_sql,
    "execute_dispute_sql": execute_dispute_sql,
    "call_log_analysis": call_log_analysis_tool,
    "explain_dispute_result": explain_dispute_result,
}

set_tools_map(_TOOLS_MAP)
ALL_KNOWN_TOOLS.extend(list(_TOOLS_MAP.keys()))

# ── ADK Agent ───────────────────────────────────────────────────────────

DISPUTE_INSTRUCTION = """
You are the Dispute Agent. Investigate toll transaction disputes.

For every request, call these tools in order:

Step 1 - Generate SQL:
generate_dispute_sql(user_query="the user's question", intent="lookup", query_type="simple")

Step 2 - Execute SQL:
execute_dispute_sql(sql="the sql from step 1")

Step 3 - Call log service:
call_log_analysis(user_query="...", sql="...", exec_result_json="result from step 2")

Step 4 - Explain results:
explain_dispute_result(user_query="...", sql="...", execution_result_json="...", log_analysis_json="...")

After all tools, return ONLY this JSON:
{
  "sql": "...",
  "ok": true,
  "rows": [],
  "row_count": 0,
  "columns": [],
  "explanation": "...",
  "chart_type": "...",
  "chart_reason": "...",
  "error": ""
}
"""

dispute_llm_agent = LlmAgent(
    name="dispute",
    model=_model,
    description=DISPUTE_CARD.description,
    instruction=DISPUTE_INSTRUCTION,
    tools=list(_TOOLS_MAP.values()),
    output_key="dispute_result",
)

_session_service = InMemorySessionService()

# ── Bridge Runner ──────────────────────────────────────────────────────

async def _run_with_bridge(
    session_service: InMemorySessionService,
    user_id: str,
    session_id: str,
    initial_message: str,
    app_name: str = "mlff_adk",
    query_id: str = "",
) -> str:
    tool_results = {}
    iterations = 0
    current_message = initial_message

    while iterations < MAX_BRIDGE_ITERATIONS:
        iterations += 1

        session_id_iter = f"{session_id}_{query_id}_iter{iterations}"
        await session_service.create_session(
            app_name=app_name,
            user_id=user_id,
            session_id=session_id_iter,
        )

        fresh_runner = Runner(
            agent=dispute_llm_agent,
            app_name=app_name,
            session_service=session_service,
        )

        logger.debug(f"[BRIDGE] Dispute Iteration {iterations} | session={session_id_iter}")

        message = types.Content(
            role="user",
            parts=[types.Part(text=current_message)],
        )

        raw_text = ""
        gen = fresh_runner.run_async(
            user_id=user_id,
            session_id=session_id_iter,
            new_message=message,
        )

        try:
            async for event in gen:
                if event.is_final_response():
                    if event.content and event.content.parts:
                        raw_text = event.content.parts[0].text or ""
                        logger.debug(f"[BRIDGE] Raw output (iter {iterations}): {raw_text[:200]}")
                    await gen.aclose()
                    break
        except Exception as e:
            if "created in a different Context" not in str(e):
                logger.error(f"Unexpected error: {e}")

        if not raw_text:
            logger.warning(f"[BRIDGE] Empty response on iteration {iterations}")
            break

        # ── Process tool calls ──
        if detect_batch_tool_calls(raw_text):
            parsed_list = parse_batch_tool_calls(raw_text)
            if parsed_list:
                for parsed in parsed_list:
                    tool_result = await execute_parsed_tool(parsed, _TOOLS_MAP)
                    if tool_result:
                        tool_results[parsed['tool_name']] = tool_result
        elif detect_tool_call(raw_text):
            parsed = parse_tool_call(raw_text)
            if parsed:
                tool_result = await execute_parsed_tool(parsed, _TOOLS_MAP)
                if tool_result:
                    tool_results[parsed['tool_name']] = tool_result
                    logger.info(f"[BRIDGE] Tool executed: {parsed['tool_name']} | result_len={len(tool_result)}")

        # ── Deterministic completion: after SQL generation, force the rest ──
        if "generate_dispute_sql" in tool_results and "execute_dispute_sql" not in tool_results:
            sql = tool_results["generate_dispute_sql"]
            logger.info("[BRIDGE] Forcing execute_dispute_sql and remaining tools")
            exec_result = execute_dispute_sql(sql)
            tool_results["execute_dispute_sql"] = exec_result

            if config.LOG_SERVICE_ENABLED:
                log_result = await call_log_analysis_tool(initial_message, sql, exec_result)
                tool_results["call_log_analysis"] = log_result
            else:
                tool_results["call_log_analysis"] = "{}"

            explain_result = explain_dispute_result(
                user_query=initial_message,
                sql=sql,
                execution_result_json=exec_result,
                log_analysis_json=tool_results["call_log_analysis"],
            )
            tool_results["explain_dispute_result"] = explain_result
            return _synthesize_dispute_results(tool_results, initial_message)

        # If we have all tools already, synthesize
        if all(k in tool_results for k in ["generate_dispute_sql", "execute_dispute_sql", "explain_dispute_result"]):
            return _synthesize_dispute_results(tool_results, initial_message)

        # If no progress, break
        if not tool_results:
            break

        # Prepare for next iteration (should rarely happen now)
        prior_context = "\n".join([f"Tool {k} returned: {v[:300]}" for k, v in tool_results.items()])
        current_message = (
            f"Original request:\n{initial_message}\n\n"
            f"Results so far:\n{prior_context}"
        )

    # Exhausted iterations – synthesize from whatever we collected
    if tool_results:
        return _synthesize_dispute_results(tool_results, initial_message)
    return ""


def _synthesize_dispute_results(tool_results: dict, user_query: str) -> str:
    """Build final JSON from collected tool results."""
    sql = tool_results.get("generate_dispute_sql", "")
    exec_raw = tool_results.get("execute_dispute_sql", "{}")
    explain_raw = tool_results.get("explain_dispute_result", "{}")
    log_raw = tool_results.get("call_log_analysis", "{}")

    try:
        exec_data = json.loads(exec_raw) if isinstance(exec_raw, str) else exec_raw
    except:
        exec_data = {}
    try:
        explain_data = json.loads(explain_raw) if isinstance(explain_raw, str) else explain_raw
    except:
        explain_data = {}
    try:
        log_data = json.loads(log_raw) if isinstance(log_raw, str) else log_raw
    except:
        log_data = {}

    rows = exec_data.get("rows", [])
    columns = list(rows[0].keys()) if rows else []

    return json.dumps({
        "sql": sql,
        "ok": exec_data.get("ok", True),
        "rows": rows,
        "row_count": exec_data.get("row_count", len(rows)),
        "columns": columns,
        "explanation": explain_data.get("explanation", "Dispute investigation completed."),
        "chart_type": explain_data.get("chart_type", "table"),
        "chart_reason": explain_data.get("chart_reason", ""),
        "error": exec_data.get("error", ""),
        "log_analysis": log_data,
    })


# ── Fallback (direct Python) ────────────────────────────────────────

async def _dispute_fallback(user_query: str, session_id: str) -> Dict[str, Any]:
    """Direct Python fallback without ADK."""
    logger.warning(f"[{session_id}] Using Dispute fallback")
    try:
        sql = generate_dispute_sql(user_query, "lookup", "simple")
        exec_raw = execute_dispute_sql(sql)
        exec_data = json.loads(exec_raw)

        if config.LOG_SERVICE_ENABLED:
            log_raw = await call_log_analysis_tool(user_query, sql, exec_raw)
            log_data = json.loads(log_raw)
        else:
            log_data = {}

        explain_raw = explain_dispute_result(
            user_query=user_query,
            sql=sql,
            execution_result_json=exec_raw,
            log_analysis_json=json.dumps(log_data),
        )
        explain_data = json.loads(explain_raw)

        rows = exec_data.get("rows", [])[:MAX_DISPLAY_ROWS]
        return {
            "ok": exec_data.get("ok", False),
            "sql": sql,
            "rows": rows,
            "row_count": len(rows),
            "columns": list(rows[0].keys()) if rows else [],
            "explanation": explain_data.get("explanation", ""),
            "chart_type": explain_data.get("chart_type", "table"),
            "chart_reason": explain_data.get("chart_reason", ""),
            "error": exec_data.get("error", ""),
            "log_analysis": log_data,
        }
    except Exception as e:
        return {
            "ok": False, "sql": "", "rows": [], "row_count": 0,
            "columns": [], "explanation": str(e),
            "chart_type": "none", "chart_reason": "", "error": str(e),
        }


# ── Public interface ────────────────────────────────────────────────────

async def run_dispute_async(
    user_query: str,
    session_id: str,
    user_id: str = "mlff_user",
) -> Dict[str, Any]:
    """Run Dispute Agent with bridge."""
    success_logger.info(f"[{session_id}] Dispute Agent started | query={user_query[:80]}")

    context_message = f"""
User query: {user_query}

Generate SQL using the dispute tables, execute it, call log analysis, and explain the result.
Now call generate_dispute_sql, then execute_dispute_sql, then call_log_analysis, then explain_dispute_result.
"""

    try:
        dispute_session_id = f"dispute_{session_id}_{_uuid.uuid4().hex[:6]}"
        query_id = _uuid.uuid4().hex[:8]

        final_text = await _run_with_bridge(
            session_service=_session_service,
            user_id=user_id,
            session_id=dispute_session_id,
            initial_message=context_message,
            query_id=query_id,
        )

        success_logger.info(f"[{session_id}] Dispute raw output: {final_text[:200]}")

        clean = final_text.strip()
        if not clean:
            raise ValueError("Empty response from Dispute bridge")

        if "```" in clean:
            parts = clean.split("```")
            for part in parts:
                s = part.strip()
                if s.lower().startswith("json"):
                    s = s[4:].strip()
                if s.startswith("{"):
                    clean = s
                    break

        result = json.loads(clean)
        result["ok"] = result.get("ok", True)

    except Exception as e:
        error_logger.error(f"[{session_id}] Dispute bridge/parse error: {e}")
        result = await _dispute_fallback(user_query, session_id)

    result.update({
        "request_id": session_id,
        "user_query": user_query,
        "intent": "dispute",
        "query_type": "dispute",
        "confidence": 1.0,
        "confidence_note": "",
        "low_confidence": False,
        "selected_schema": "",
        "selected_tables": [],
        "context_summary": "Dispute investigation via dynamic SQL generation.",
    })

    success_logger.info(f"[{session_id}] Dispute complete | ok={result.get('ok')} | rows={result.get('row_count', 0)}")
    return result
