import json
import asyncio
from core.config import config
from core.logger import get_logger

logger = get_logger("log_service")

async def call_log_analysis(user_query: str, params: dict, db_result: dict) -> dict:
    """
    Mock log analysis service.
    Replace with real HTTP call later.
    """
    if not config.LOG_SERVICE_ENABLED:
        return {"status": "disabled"}

    await asyncio.sleep(0.2)  # simulate network delay

    vehicle = params.get("vehicle_no", "unknown")
    transaction = params.get("transaction_id", "unknown")

    mock_response = {
        "service_status": {
            "TollPlazaAPI": "degraded",
            "PaymentGateway": "healthy",
            "VehicleRegistry": "healthy",
        },
        "relevant_logs": [
            {
                "timestamp": "2025-01-15T08:12:33Z",
                "api": "TollPlazaAPI",
                "level": "ERROR",
                "message": f"Timeout while processing transaction {transaction} for vehicle {vehicle}",
            },
            {
                "timestamp": "2025-01-15T08:12:35Z",
                "api": "TollPlazaAPI",
                "level": "WARNING",
                "message": f"Retry attempt failed for transaction {transaction}",
            },
        ],
        "error_rate": "23% timeout errors between 08:00-09:00",
        "overall_health": "degraded",
    }

    logger.info(f"Mock log analysis returned for {vehicle}/{transaction}")
    return mock_response
