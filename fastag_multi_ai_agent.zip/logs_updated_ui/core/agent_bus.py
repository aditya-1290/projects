"""
Capability‑based Agent Bus – declarative, scoring‑driven A2A routing.
"""
import json
from collections import defaultdict
from core.logger import get_logger
from core.config import config

logger = get_logger("agent_bus")

# Registry: agent_id -> { "handler", "keywords", "handled_intents", "capabilities" }
_registry = {}

# Scoring weights (tune as needed)
WEIGHT_KEYWORD = 3
WEIGHT_CAPABILITY = 1
WEIGHT_INTENT = 5
MIN_SCORE_DIRECT = 3      # threshold to bypass orchestrator


def register(agent_id: str, capabilities: list, handler,
             keywords: list = None, handled_intents: list = None):
    """Register an agent with its capabilities, keywords, and handled intents."""
    _registry[agent_id] = {
        "handler": handler,
        "capabilities": capabilities or [],
        "keywords": keywords or [],
        "handled_intents": handled_intents or [],
    }
    logger.info(f"Registered agent: {agent_id} | keywords: {keywords} | intents: {handled_intents}")


async def call_agent(agent_id: str, request: dict):
    if agent_id not in _registry:
        raise ValueError(f"Agent {agent_id} not found")
    return await _registry[agent_id]["handler"](request)


def _tokenize(text: str) -> set:
    return set(text.lower().split())


def _score_agent(agent_info: dict, query: str, intent: str = None) -> int:
    """Compute a score for an agent based on the query and optional intent."""
    query_tokens = _tokenize(query)
    score = 0

    # Keyword overlap
    for kw in agent_info["keywords"]:
        kw_tokens = _tokenize(kw)
        score += WEIGHT_KEYWORD * len(kw_tokens & query_tokens)

    # Capability overlap (lower weight)
    for cap in agent_info["capabilities"]:
        cap_tokens = _tokenize(cap)
        score += WEIGHT_CAPABILITY * len(cap_tokens & query_tokens)

    # Intent match (if orchestrator provided intent)
    if intent and intent in agent_info["handled_intents"]:
        score += WEIGHT_INTENT

    return score


async def route(request: dict) -> dict:
    user_query = request.get("user_query", "")
    agent = request.get("agent")
    session_id = request.get("session_id", "")

    # 1. Manual selection
    if agent and agent != "auto":
        return await call_agent(agent, request)

    # 2. Skill match (only support agent for now – keep standalone)
    from agents.support.skills.skills_reader import match_skill
    skill, skill_score = match_skill(user_query)
    if skill and skill_score >= config.SKILL_MATCH_THRESHOLD:
        logger.info(f"Support skill match: {skill['name']}")
        if "support" in _registry:
            return await call_agent("support", request)

    # 3. Score all agents (excluding orchestrator) without intent
    best_id, best_score = None, 0
    for aid, info in _registry.items():
        if aid == "orchestrator":
            continue
        s = _score_agent(info, user_query)
        if s > best_score:
            best_score = s
            best_id = aid

    if best_id and best_score >= MIN_SCORE_DIRECT:
        logger.info(f"Direct score match: {best_id} (score={best_score})")
        return await call_agent(best_id, request)

    # 4. No clear winner – use orchestrator to get intent, then re‑score with intent
    if "orchestrator" in _registry:
        intent_result = await call_agent("orchestrator", {
            "user_query": user_query,
            "session_id": session_id
        })
        intent = intent_result.get("intent", "lookup")
        query_type = intent_result.get("query_type", "simple")
        confidence = intent_result.get("confidence", 0.0)

        # Re‑score with intent
        best_id, best_score = None, 0
        for aid, info in _registry.items():
            if aid == "orchestrator":
                continue
            s = _score_agent(info, user_query, intent)
            if s > best_score:
                best_score = s
                best_id = aid

        if best_id:
            logger.info(f"Intent‑based score match: {best_id} (intent={intent}, score={best_score})")
            # Inject context for MLFF if needed
            if best_id == "mlff":
                from agents.mlff.agent import _MLFF_CACHE
                request["orchestrator_payload"] = {
                    "ok": True,
                    "user_query": user_query,
                    "intent": intent,
                    "query_type": query_type,
                    "confidence": confidence,
                    "selected_schema": _MLFF_CACHE["selected_schema"],
                    "selected_tables": _MLFF_CACHE["selected_tables"],
                    "schema_details": _MLFF_CACHE["schema_details"],
                    "relationships_hint": _MLFF_CACHE["relationships_hint"],
                    "context_summary": "",
                    "routing_to": "mlff",
                    "request_id": session_id,
                }
            return await call_agent(best_id, request)

    # 5. Ultimate fallback to MLFF
    logger.warning("No agent matched, falling back to MLFF")
    if "mlff" in _registry:
        from agents.mlff.agent import _MLFF_CACHE
        request["orchestrator_payload"] = {
            "ok": True,
            "user_query": user_query,
            "intent": "lookup",
            "query_type": "simple",
            "confidence": 0.5,
            "selected_schema": _MLFF_CACHE["selected_schema"],
            "selected_tables": _MLFF_CACHE["selected_tables"],
            "schema_details": _MLFF_CACHE["schema_details"],
            "relationships_hint": _MLFF_CACHE["relationships_hint"],
            "context_summary": "",
            "routing_to": "mlff",
            "request_id": session_id,
        }
        return await call_agent("mlff", request)

    return {"error": "No agent available"}
