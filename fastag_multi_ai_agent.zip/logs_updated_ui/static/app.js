/* static/app.js */
let SESSION_ID = null;
let currentChartInstance = null;

const queryInput      = document.getElementById('queryInput');
const sendBtn         = document.getElementById('sendBtn');
const sendLabel       = document.getElementById('sendLabel');
const sendSpinner     = document.getElementById('sendSpinner');
const resultArea      = document.getElementById('resultArea');
const welcomeState    = document.getElementById('welcomeState');
const metaIntent      = document.getElementById('metaIntent');
const metaType        = document.getElementById('metaType');
const metaConfidence  = document.getElementById('metaConfidence');
const metaSchema      = document.getElementById('metaSchema');
const metaRows        = document.getElementById('metaRows');
const lowConfWarning  = document.getElementById('lowConfidenceWarning');
const errorBox        = document.getElementById('errorBox');
const sqlOutput       = document.getElementById('sqlOutput');
const explanationOut  = document.getElementById('explanationOutput');
const explanationCard = document.getElementById('explanationCard');
const tableHead       = document.getElementById('tableHead');
const tableBody       = document.getElementById('tableBody');
const rowCountLabel   = document.getElementById('rowCountLabel');
const chartCard       = document.getElementById('chartCard');
const chartReasonEl   = document.getElementById('chartReason');
const historyList     = document.getElementById('historyList');

async function checkStatus() {
  const dot  = document.getElementById('statusDot');
  const text = document.getElementById('statusText');
  try {
    const r = await fetch('/health');
    if (r.ok) {
      dot.className = 'status-dot online';
      text.textContent = 'System Online';
    } else {
      throw new Error();
    }
  } catch {
    dot.className = 'status-dot offline';
    text.textContent = 'Offline';
  }
}
checkStatus();

queryInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendQuery();
  }
});

queryInput.addEventListener('input', () => {
  queryInput.style.height = 'auto';
  queryInput.style.height = Math.min(queryInput.scrollHeight, 120) + 'px';
});

document.getElementById('explanationToggle')?.addEventListener('click', () => {
  if (explanationCard) explanationCard.classList.toggle('open');
});

document.getElementById('suggestions')?.addEventListener('click', (e) => {
  const chip = e.target.closest('.suggestion-chip');
  if (!chip) return;
  queryInput.value = chip.dataset.query;
  queryInput.focus();
  queryInput.style.height = 'auto';
  queryInput.style.height = queryInput.scrollHeight + 'px';
});

document.getElementById('copySqlBtn')?.addEventListener('click', () => {
  const sql = sqlOutput.textContent;
  if (!sql || sql.startsWith('--')) return;
  navigator.clipboard.writeText(sql).then(() => {
    const btn = document.getElementById('copySqlBtn');
    const label = btn.querySelector('.copy-label');
    label.textContent = 'Copied!';
    btn.classList.add('copied');
    setTimeout(() => {
      label.textContent = 'Copy';
      btn.classList.remove('copied');
    }, 1800);
  });
});

async function sendQuery() {
  const query = queryInput.value.trim();
  if (!query) return;

  const agent = document.getElementById('agentSelect').value || 'auto';

  setLoading(true);
  clearResult();

  if (welcomeState) welcomeState.classList.add('hidden');
  resultArea.classList.remove('hidden');

  try {
    const resp = await fetch('/query', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: query, session_id: SESSION_ID, agent: agent }),
    });

    if (!resp.ok) {
      const txt = await resp.text();
      throw new Error(txt || `HTTP ${resp.status}`);
    }

    const data = await resp.json();
    SESSION_ID = data.session_id || SESSION_ID;

    renderResult(data, query);
    addToHistorySidebar(query, data);

  } catch (err) {
    showError(err.message || 'Request failed. Check that all 3 terminals are running.');
    resultArea.classList.remove('hidden');
  } finally {
    setLoading(false);
  }
}

function renderResult(data, query) {
  resultArea.classList.remove('hidden');

  metaIntent.textContent    = `Intent: ${data.intent || 'N/A'}`;
  metaType.textContent      = `Type: ${data.query_type || 'N/A'}`;
  metaSchema.textContent    = `Schema: ${data.selected_schema || 'N/A'}`;
  metaRows.textContent      = `Rows: ${data.row_count ?? 0}`;

  const conf = data.confidence ?? 0;
  metaConfidence.textContent = `Confidence: ${(conf * 100).toFixed(0)}%`;
  metaConfidence.className = 'meta-chip confidence-chip ' + confidenceClass(conf);

  if (data.low_confidence && data.confidence_note) {
    lowConfWarning.textContent = '⚠ ' + data.confidence_note;
    lowConfWarning.classList.remove('hidden');
  } else {
    lowConfWarning.classList.add('hidden');
  }

  if (!data.ok || data.error) {
    showError(data.error || data.explanation || 'An error occurred.');
    if (data.sql) sqlOutput.textContent = data.sql;
    return;
  }

  errorBox.classList.add('hidden');
  sqlOutput.textContent = data.sql || '-- No SQL generated';

  explanationOut.textContent = data.explanation || 'No explanation available.';
  if (explanationCard) {
    if (!explanationCard.classList.contains('open')) {
      if (historyList.querySelectorAll('.history-item').length === 0) {
        explanationCard.classList.add('open');
      }
    }
  }

  renderTable(data.columns || [], data.rows || []);
  rowCountLabel.textContent = `${data.row_count} row${data.row_count !== 1 ? 's' : ''}`;

  if (data.chart_type && data.chart_type !== 'none' && data.chart_type !== 'table' && data.rows?.length > 0) {
    chartCard.style.display = 'block';
    chartReasonEl.textContent = data.chart_reason || '';
    renderChart(data.chart_type, data.rows, data.columns);
  } else {
    chartCard.style.display = 'none';
  }
}

function renderTable(columns, rows) {
  tableHead.innerHTML = '';
  tableBody.innerHTML = '';

  if (!columns.length && rows.length) {
    columns = Object.keys(rows[0]);
  }

  if (!columns.length) return;

  const numericCols = new Set();
  if (rows.length > 0) {
    columns.forEach(col => {
      const val = rows[0][col];
      if (val !== null && val !== undefined && !isNaN(Number(val)) && typeof val !== 'string') {
        numericCols.add(col);
      }
    });
  }

  const tr = document.createElement('tr');
  columns.forEach(col => {
    const th = document.createElement('th');
    th.textContent = col;
    tr.appendChild(th);
  });
  tableHead.appendChild(tr);

  rows.forEach(row => {
    const tr = document.createElement('tr');
    columns.forEach(col => {
      const td = document.createElement('td');
      const val = row[col];
      td.textContent = val === null || val === undefined ? '—' : String(val);
      td.title = td.textContent;
      if (numericCols.has(col)) {
        td.classList.add('num-cell');
      }
      tr.appendChild(td);
    });
    tableBody.appendChild(tr);
  });
}

function addToHistorySidebar(query, data) {
  const empty = historyList.querySelector('.history-empty');
  if (empty) empty.remove();

  const item = document.createElement('div');
  item.className = `history-item ${data.ok ? 'history-ok' : 'history-fail'}`;

  const ts = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  item.innerHTML = `
    <div class="history-query">${escapeHtml(query)}</div>
    <div class="history-meta">${ts} · ${data.row_count ?? 0} rows · ${((data.confidence ?? 0) * 100).toFixed(0)}%</div>
  `;

  item.onclick = () => {
    queryInput.value = query;
    queryInput.focus();
    queryInput.style.height = 'auto';
    queryInput.style.height = queryInput.scrollHeight + 'px';
  };

  historyList.prepend(item);
}

function setLoading(on) {
  sendBtn.disabled = on;
  sendLabel.textContent = on ? 'Running…' : 'Run Query';
  sendSpinner.classList.toggle('hidden', !on);
}

function clearResult() {
  errorBox.classList.add('hidden');
  lowConfWarning.classList.add('hidden');
  sqlOutput.textContent = '';
  explanationOut.textContent = '';
  if (explanationCard) explanationCard.classList.remove('open');
  tableHead.innerHTML = '';
  tableBody.innerHTML = '';
  chartCard.style.display = 'none';
  if (currentChartInstance) { currentChartInstance.destroy(); currentChartInstance = null; }
}

function showError(msg) {
  errorBox.textContent = '✖ ' + msg;
  errorBox.classList.remove('hidden');
}

function confidenceClass(conf) {
  if (conf >= 0.75) return 'high';
  if (conf >= 0.60) return 'medium';
  return 'low';
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

async function loadAgents() {
  try {
    const resp = await fetch('/agents');
    const agents = await resp.json();
    const select = document.getElementById('agentSelect');
    select.innerHTML = '<option value="auto">🤖 Auto</option>';
    agents.forEach(agent => {
      const option = document.createElement('option');
      option.value = agent.agent_id;
      option.textContent = agent.agent_name || agent.agent_id;
      select.appendChild(option);
    });
  } catch (err) {
    console.warn('Could not load agent list', err);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  checkStatus();
  loadAgents();
});
