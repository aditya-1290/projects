## skill: active employees
keywords: active employees, employee count, total employees, how many employees, employees active, employee total
sql: SELECT COUNT(*) AS employee_count FROM hr.employees

## skill: employees by department
keywords: employees by department, department employees, employee distribution, headcount by department
sql: SELECT d.department_name, COUNT(e.employee_id) AS employee_count FROM hr.departments d LEFT JOIN hr.employees e ON d.department_id = e.department_id GROUP BY d.department_name ORDER BY employee_count DESC

## skill: highest paid employees
keywords: highest salary, top salaries, highest paid employees, top paid employees
sql: SELECT e.first_name, e.last_name, s.salary FROM hr.employees e JOIN hr.salaries s ON e.employee_id = s.employee_id ORDER BY s.salary DESC LIMIT 10

## skill: total customers
keywords: total customers, customer count, how many customers, customer total
sql: SELECT COUNT(*) AS total_customers FROM sales.customers

## skill: top customers by orders
keywords: top customers, best customers, customers by orders, highest orders, loyal customers
sql: SELECT c.customer_name, COUNT(o.order_id) AS total_orders FROM sales.customers c JOIN sales.orders o ON c.customer_id = o.customer_id GROUP BY c.customer_id,c.customer_name ORDER BY total_orders DESC LIMIT 10

## skill: total orders
keywords: total orders, order count, number of orders
sql: SELECT COUNT(*) AS total_orders FROM sales.orders

## skill: orders per day
keywords: daily orders, orders per day, order trend, daily sales
sql: SELECT order_date, COUNT(*) AS orders FROM sales.orders GROUP BY order_date ORDER BY order_date DESC LIMIT 30

## skill: top sales employees
keywords: top employees, best sales employees, employee performance, highest sales employee
sql: SELECT e.first_name, e.last_name, COUNT(o.order_id) AS orders_processed FROM hr.employees e JOIN sales.orders o ON e.employee_id=o.employee_id GROUP BY e.employee_id ORDER BY orders_processed DESC LIMIT 10

## skill: total products
keywords: total products, product count, inventory size
sql: SELECT COUNT(*) AS total_products FROM inventory.products

## skill: most expensive products
keywords: expensive products, highest price products, costly products
sql: SELECT product_name, price FROM inventory.products ORDER BY price DESC LIMIT 10

## skill: cheapest products
keywords: cheap products, lowest price products, inexpensive products
sql: SELECT product_name, price FROM inventory.products ORDER BY price ASC LIMIT 10

## skill: low stock products
keywords: low stock, products running out, inventory shortage, stock alerts
sql: SELECT p.product_name, s.quantity FROM inventory.stock s JOIN inventory.products p ON s.product_id=p.product_id WHERE s.quantity < 20 ORDER BY s.quantity LIMIT 50

## skill: out of stock products
keywords: out of stock, no inventory, zero stock
sql: SELECT p.product_name FROM inventory.stock s JOIN inventory.products p ON s.product_id=p.product_id WHERE s.quantity = 0

## skill: total revenue
keywords: total revenue, revenue, income, earnings, total sales amount
sql: SELECT SUM(amount) AS total_revenue FROM sales.payments

## skill: average order value
keywords: average order value, avg order amount, order average
sql: SELECT AVG(amount) AS avg_order_value FROM sales.payments

## skill: monthly revenue
keywords: monthly revenue, revenue by month, sales trend, monthly sales, revenue trend, month revenue, highest revenue month, revenue over time
sql: SELECT DATE_TRUNC('month', invoice_date) AS month, COUNT(*) AS invoices FROM finance.invoices GROUP BY month ORDER BY month DESC

## skill: total tickets
keywords: ticket count, support tickets, total tickets
sql: SELECT COUNT(*) AS total_tickets FROM support.tickets

## skill: tickets by status
keywords: ticket status, tickets by status, support status
sql: SELECT ts.status_name, COUNT(*) AS total FROM support.tickets t JOIN support.ticket_status ts ON t.status_id=ts.status_id GROUP BY ts.status_name ORDER BY total DESC

## skill: average feedback
keywords: feedback score, customer rating, support rating, average rating
sql: SELECT AVG(rating) AS avg_rating FROM support.feedback

## skill: total logs
keywords: log count, application logs, total logs
sql: SELECT COUNT(*) AS total_logs FROM logging.application_logs

## skill: error logs
keywords: errors, application errors, failures, exceptions
sql: SELECT COUNT(*) AS error_count FROM logging.application_logs WHERE log_level='ERROR'

## skill: top error services
keywords: error services, failing services, services with errors
sql: SELECT service_name, COUNT(*) AS total_errors FROM logging.application_logs WHERE log_level='ERROR'GROUP BY service_name ORDER BY total_errors DESC LIMIT 20

## skill: customer revenue
keywords: customer revenue, revenue by customer, top revenue customers
sql: SELECT c.customer_name, SUM(p.amount) AS revenue FROM sales.customers c JOIN sales.orders o ON c.customer_id=o.customer_id JOIN sales.payments p ON o.order_id=p.order_id GROUP BY c.customer_id,c.customer_name ORDER BY revenue DESC LIMIT 20

## skill: product revenue
keywords: product revenue, best selling products, top products
sql: SELECT pr.product_name, COUNT(*) AS total_sales FROM sales.order_items oi JOIN inventory.products pr ON oi.product_id=pr.product_id GROUP BY pr.product_id,pr.product_name ORDER BY total_sales DESC LIMIT 20

## skill: employee ticket load
keywords: support workload, tickets per employee, employee tickets
sql: SELECT e.first_name, e.last_name, COUNT(t.ticket_id) AS tickets FROM hr.employees e JOIN support.tickets t ON e.employee_id=t.employee_id GROUP BY e.employee_id LIMIT 20

