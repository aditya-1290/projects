# FORGE — Project Folder Structure
**Version:** 1.0  
**Date:** May 2026

---

## Overview

The repo is organized into clearly separated concerns — each top-level folder owns one layer of the system. Nothing bleeds into another layer's folder.

```
forge/
│
├── agents/                         # All Google ADK agents
├── backend/                        # FastAPI backend server
├── broker/                         # Redis message broker config & utilities
├── cli/                            # CLI tool (Typer + Rich)
├── lsp/                            # LSP server (pygls) for IDE integration
├── mcp/                            # MCP servers (Filesystem, Terminal, Git)
├── extensions/                     # IDE extensions (VS Code, PyCharm)
├── memory/                         # Checkpoint & session persistence
├── storage/                        # DB models, migrations, ChromaDB
├── config/                         # Forge configuration management
├── installer/                      # Installer scripts & packaging
├── deployment/                     # Deployment templates for user projects
├── shared/                         # Shared utilities, types, constants
├── tests/                          # Forge's own test suite
├── docs/                           # Project documentation
└── scripts/                        # Dev & ops scripts
```

---

## Full Detailed Structure

```
forge/
│
│
├── agents/
│   ├── __init__.py
│   ├── base_agent.py                   # Base class all agents inherit from
│   │                                   # Handles model connection, tool calling,
│   │                                   # streaming, checkpoint hooks
│   │
│   ├── orchestrator/
│   │   ├── __init__.py
│   │   ├── agent.py                    # Root orchestrator agent
│   │   ├── router.py                   # Decides which agent handles what
│   │   ├── mode_detector.py            # Detects build/ingest/test mode
│   │   └── prompts/
│   │       └── orchestrator.txt        # System prompt for orchestrator
│   │
│   ├── intake/
│   │   ├── __init__.py
│   │   ├── agent.py                    # Intake agent — gathers requirements
│   │   ├── user_type_detector.py       # Technical vs non-technical user
│   │   ├── requirements_builder.py     # Structures collected requirements
│   │   ├── project_plan_generator.py   # Builds plan for user approval
│   │   └── prompts/
│   │       ├── intake_technical.txt    # Prompt for developer users
│   │       └── intake_founder.txt      # Prompt for non-technical users
│   │
│   ├── architect/
│   │   ├── __init__.py
│   │   ├── agent.py                    # Architect agent
│   │   ├── stack_selector.py           # Recommends/confirms tech stack
│   │   ├── file_tree_planner.py        # Designs directory & module structure
│   │   ├── build_order_planner.py      # Orders what gets built first
│   │   └── prompts/
│   │       └── architect.txt
│   │
│   ├── coder/
│   │   ├── __init__.py
│   │   ├── agent.py                    # Coder agent — writes code iteratively
│   │   ├── language_detector.py        # Detects target language from context
│   │   ├── code_writer.py              # Core code generation logic
│   │   ├── stream_handler.py           # Manages streaming output to CLI
│   │   └── prompts/
│   │       ├── coder_base.txt          # Base coding prompt
│   │       └── coder_continuation.txt  # Context recovery prompt (post-burst)
│   │
│   ├── tester/
│   │   ├── __init__.py
│   │   ├── agent.py                    # Tester agent — generates test suites
│   │   ├── test_analyser.py            # Analyses codebase for test targets
│   │   ├── unit_writer.py              # Writes unit tests
│   │   ├── integration_writer.py       # Writes integration tests
│   │   ├── e2e_writer.py               # Writes E2E tests
│   │   ├── coverage_reporter.py        # Reports test coverage gaps
│   │   └── prompts/
│   │       └── tester.txt
│   │
│   ├── patcher/
│   │   ├── __init__.py
│   │   ├── agent.py                    # Patcher agent — applies code patches
│   │   ├── diff_generator.py           # Generates human-readable diffs
│   │   ├── patch_applier.py            # Applies patches to files
│   │   └── prompts/
│   │       └── patcher.txt
│   │
│   ├── reviewer/
│   │   ├── __init__.py
│   │   ├── agent.py                    # Reviewer/Suggester agent
│   │   ├── code_reviewer.py            # Reviews code quality & patterns
│   │   ├── suggestion_builder.py       # Builds enhancement suggestions
│   │   └── prompts/
│   │       └── reviewer.txt
│   │
│   └── memory_manager/
│       ├── __init__.py
│       ├── checkpoint_monitor.py       # Monitors token usage, triggers saves
│       ├── context_summariser.py       # Compresses context before checkpoint
│       └── context_injector.py        # Rebuilds context after restart
│
│
├── backend/
│   ├── __init__.py
│   ├── main.py                         # FastAPI app entry point
│   ├── dependencies.py                 # Shared FastAPI dependencies
│   │
│   ├── api/
│   │   ├── __init__.py
│   │   ├── sessions.py                 # Session CRUD endpoints
│   │   ├── agents.py                   # Agent task dispatch endpoints
│   │   ├── files.py                    # File read/write/patch endpoints
│   │   ├── permissions.py              # Permission grant/revoke endpoints
│   │   ├── streaming.py                # SSE streaming endpoints
│   │   ├── projects.py                 # Project ingest & metadata endpoints
│   │   └── health.py                   # Health check endpoint
│   │
│   ├── services/
│   │   ├── __init__.py
│   │   ├── session_service.py          # Session lifecycle management
│   │   ├── permission_gateway.py       # Central permission check logic
│   │   ├── project_ingestor.py         # Scans & analyses existing codebases
│   │   ├── file_lock_manager.py        # Redis-based file locking (team mode)
│   │   ├── streaming_manager.py        # Manages SSE streams to clients
│   │   └── deployment_service.py       # Generates deployment configs
│   │
│   └── middleware/
│       ├── __init__.py
│       ├── logging.py                  # Request/response logging
│       └── error_handler.py            # Global error handling
│
│
├── broker/
│   ├── __init__.py
│   ├── client.py                       # Redis Streams client wrapper
│   ├── publisher.py                    # Publishes messages to agent queues
│   ├── subscriber.py                   # Subscribes agents to their queues
│   ├── message_schema.py               # A2A message envelope definition
│   ├── queues.py                       # Queue name constants
│   └── event_bus.py                    # Broadcast event bus (agent.events)
│
│
├── cli/
│   ├── __init__.py
│   ├── main.py                         # CLI entry point (forge command)
│   │
│   ├── commands/
│   │   ├── __init__.py
│   │   ├── start.py                    # forge start
│   │   ├── resume.py                   # forge resume
│   │   ├── sessions.py                 # forge sessions
│   │   ├── switch.py                   # forge switch <name>
│   │   ├── status.py                   # forge status
│   │   ├── checkpoint.py               # forge checkpoint
│   │   ├── config.py                   # forge config
│   │   └── connect.py                  # forge connect <url>
│   │
│   ├── conversation/
│   │   ├── __init__.py
│   │   ├── loop.py                     # Main conversational chat loop
│   │   ├── command_parser.py           # Parses /commands from conversation
│   │   └── input_handler.py            # Prompt toolkit input management
│   │
│   ├── views/
│   │   ├── __init__.py
│   │   ├── status_view.py              # Status streaming view (default)
│   │   ├── code_view.py                # Code streaming view (/view code)
│   │   ├── patch_prompt.py             # Patch permission prompt UI
│   │   ├── session_list.py             # Session list display
│   │   └── diff_view.py                # Diff display for patch review
│   │
│   └── themes/
│       ├── __init__.py
│       └── forge_theme.py              # Rich theme — colors, styles, panels
│
│
├── lsp/
│   ├── __init__.py
│   ├── server.py                       # pygls LSP server entry point
│   ├── capabilities.py                 # LSP capabilities declaration
│   │
│   ├── handlers/
│   │   ├── __init__.py
│   │   ├── text_document.py            # Text document sync handlers
│   │   ├── completion.py               # Code completion via Forge agents
│   │   ├── diagnostics.py              # Code diagnostics & suggestions
│   │   └── commands.py                 # Custom Forge LSP commands
│   │
│   └── bridge/
│       ├── __init__.py
│       └── backend_bridge.py           # LSP ↔ FastAPI backend bridge
│
│
├── mcp/
│   ├── __init__.py
│   │
│   ├── filesystem/
│   │   ├── __init__.py
│   │   ├── server.py                   # Filesystem MCP server
│   │   ├── reader.py                   # File read operations
│   │   ├── writer.py                   # File write operations (perm-gated)
│   │   ├── patcher.py                  # File patch operations (perm-gated)
│   │   └── deleter.py                  # File delete operations (perm-gated)
│   │
│   ├── terminal/
│   │   ├── __init__.py
│   │   ├── server.py                   # Terminal MCP server
│   │   ├── executor.py                 # Command execution (scoped to project)
│   │   ├── scope_enforcer.py           # Enforces project dir boundary
│   │   └── allowed_commands.py         # Pre-approved command whitelist
│   │
│   └── git/
│       ├── __init__.py
│       ├── server.py                   # Git MCP server
│       ├── commit.py                   # Git commit operations
│       ├── diff.py                     # Git diff operations
│       ├── branch.py                   # Branch management
│       └── push_pull.py                # Push/pull (requires explicit approval)
│
│
├── extensions/
│   │
│   ├── vscode/
│   │   ├── package.json                # VS Code extension manifest
│   │   ├── tsconfig.json
│   │   ├── .vscodeignore
│   │   │
│   │   └── src/
│   │       ├── extension.ts            # Extension entry point
│   │       ├── forgeClient.ts          # Forge backend HTTP/WS client
│   │       ├── lspClient.ts            # LSP client connection
│   │       │
│   │       ├── panels/
│   │       │   ├── sidebarPanel.ts     # Sidebar session status panel
│   │       │   └── chatPanel.ts        # In-IDE chat panel
│   │       │
│   │       ├── providers/
│   │       │   ├── completionProvider.ts  # Code completion via Forge
│   │       │   └── diagnosticProvider.ts # Inline suggestions
│   │       │
│   │       └── ui/
│   │           ├── patchNotification.ts  # Patch approval popup
│   │           └── statusBar.ts          # Status bar item
│   │
│   └── pycharm/
│       ├── build.gradle.kts            # PyCharm plugin build config
│       ├── plugin.xml                  # Plugin manifest
│       │
│       └── src/main/kotlin/
│           └── com/forge/plugin/
│               ├── ForgePlugin.kt      # Plugin entry point
│               ├── ForgeClient.kt      # Forge backend client
│               │
│               ├── toolwindow/
│               │   ├── ForgeToolWindow.kt     # Main tool window
│               │   └── ChatPanel.kt           # Conversation panel
│               │
│               ├── actions/
│               │   ├── StartForgeAction.kt    # Start session action
│               │   └── AskForgeAction.kt      # Ask about file action
│               │
│               └── diff/
│                   └── PatchDiffViewer.kt     # Native diff viewer for patches
│
│
├── memory/
│   ├── __init__.py
│   ├── checkpoint_manager.py           # Orchestrates checkpoint save/load
│   ├── session_store.py                # Session CRUD against DB
│   ├── checkpoint_store.py             # Checkpoint CRUD against DB
│   ├── context_builder.py              # Rebuilds agent context from checkpoint
│   └── token_counter.py               # Tracks token usage per agent call
│
│
├── storage/
│   ├── __init__.py
│   │
│   ├── database/
│   │   ├── __init__.py
│   │   ├── connection.py               # DB connection (SQLite / PostgreSQL)
│   │   ├── models.py                   # SQLAlchemy ORM models
│   │   │                               # sessions, checkpoints, permissions,
│   │   │                               # project_files tables
│   │   └── migrations/
│   │       └── versions/               # Alembic migration files
│   │
│   └── vector/
│       ├── __init__.py
│       ├── chroma_client.py            # ChromaDB client wrapper
│       ├── embedder.py                 # Embeds code files into ChromaDB
│       └── searcher.py                 # Semantic search over codebase
│
│
├── config/
│   ├── __init__.py
│   ├── settings.py                     # Pydantic settings model
│   │                                   # Reads from config file + env vars
│   ├── config_manager.py               # Read/write ~/.forge/config.json
│   ├── defaults.py                     # Default config values
│   └── schema.py                       # Config file JSON schema
│
│   # Config file lives at:
│   # ~/.forge/config.json (personal)
│   # Config is pushed to clients from server in team mode
│
│
├── installer/
│   ├── online/
│   │   ├── install.sh                  # Linux / macOS online installer
│   │   └── install.ps1                 # Windows PowerShell online installer
│   │
│   ├── docker/
│   │   ├── Dockerfile                  # Forge backend Docker image
│   │   ├── docker-compose.yml          # Full stack (FastAPI+Redis+ChromaDB+LSP)
│   │   └── .env.example                # Environment variable template
│   │
│   └── executable/
│       ├── build_windows.py            # PyInstaller + Inno Setup build script
│       ├── build_macos.py              # PyInstaller + create-dmg build script
│       ├── build_linux.py              # PyInstaller AppImage build script
│       └── forge.spec                  # PyInstaller spec file
│
│
├── deployment/
│   │                                   # Templates Forge uses to generate
│   │                                   # deployment configs for USER projects
│   │
│   ├── templates/
│   │   ├── docker/
│   │   │   ├── python_fastapi.dockerfile
│   │   │   ├── node_express.dockerfile
│   │   │   ├── java_spring.dockerfile
│   │   │   └── generic.dockerfile
│   │   │
│   │   ├── docker-compose/
│   │   │   ├── with_postgres.yml
│   │   │   ├── with_redis.yml
│   │   │   └── full_stack.yml
│   │   │
│   │   ├── cicd/
│   │   │   ├── github_actions.yml
│   │   │   ├── gitlab_ci.yml
│   │   │   └── bitbucket_pipelines.yml
│   │   │
│   │   └── providers/
│   │       ├── aws/
│   │       │   ├── ecs_task_definition.json
│   │       │   ├── elastic_beanstalk.yml
│   │       │   └── lambda_config.json
│   │       ├── gcp/
│   │       │   ├── cloud_run.yml
│   │       │   └── app_engine.yml
│   │       ├── azure/
│   │       │   └── app_service.yml
│   │       ├── digitalocean/
│   │       │   └── app_platform.yml
│   │       ├── railway/
│   │       │   └── railway.json
│   │       ├── render/
│   │       │   └── render.yaml
│   │       ├── vercel/
│   │       │   └── vercel.json
│   │       ├── flyio/
│   │       │   └── fly.toml
│   │       └── heroku/
│   │           └── Procfile
│   │
│   └── generator.py                    # Renders templates for user's project
│
│
├── shared/
│   ├── __init__.py
│   ├── types.py                        # Shared dataclasses & TypedDicts
│   │                                   # AgentMessage, SessionState,
│   │                                   # CheckpointData, PermissionRequest
│   ├── constants.py                    # App-wide constants
│   ├── exceptions.py                   # Custom exception classes
│   ├── logger.py                       # Centralised logging setup
│   └── utils/
│       ├── __init__.py
│       ├── file_utils.py               # File tree walking, language detection
│       ├── language_detector.py        # Detects programming language of file
│       ├── framework_detector.py       # Detects framework from config files
│       └── token_utils.py              # Token estimation utilities
│
│
├── tests/
│   │                                   # Forge's own test suite
│   │                                   # (testing the agent, not user projects)
│   │
│   ├── unit/
│   │   ├── test_agents/
│   │   │   ├── test_orchestrator.py
│   │   │   ├── test_intake.py
│   │   │   ├── test_architect.py
│   │   │   ├── test_coder.py
│   │   │   ├── test_tester.py
│   │   │   ├── test_patcher.py
│   │   │   └── test_reviewer.py
│   │   │
│   │   ├── test_backend/
│   │   │   ├── test_permission_gateway.py
│   │   │   ├── test_project_ingestor.py
│   │   │   └── test_session_service.py
│   │   │
│   │   ├── test_broker/
│   │   │   ├── test_publisher.py
│   │   │   └── test_subscriber.py
│   │   │
│   │   ├── test_memory/
│   │   │   ├── test_checkpoint_manager.py
│   │   │   └── test_context_builder.py
│   │   │
│   │   └── test_mcp/
│   │       ├── test_filesystem.py
│   │       ├── test_terminal.py
│   │       └── test_git.py
│   │
│   ├── integration/
│   │   ├── test_agent_flow.py          # Full agent conversation flows
│   │   ├── test_a2a_communication.py   # Agent-to-agent via broker
│   │   ├── test_permission_flow.py     # Full permission gateway flow
│   │   └── test_session_persistence.py # Checkpoint save & restore
│   │
│   ├── e2e/
│   │   ├── test_build_from_scratch.py  # Full Mode 1 flow
│   │   ├── test_ingest_project.py      # Full Mode 2 flow
│   │   └── test_generate_tests.py      # Full Mode 3 flow
│   │
│   └── fixtures/
│       ├── sample_projects/            # Sample codebases for ingestion tests
│       └── mock_responses/             # Mock LLM responses for unit tests
│
│
├── docs/
│   ├── specification.md                # Full project specification (v1.1)
│   ├── architecture.md                 # Architecture deep-dive
│   ├── agent_prompts.md                # Guide to writing/editing agent prompts
│   ├── api_reference.md                # FastAPI endpoint documentation
│   ├── config_reference.md             # All config options documented
│   ├── mcp_reference.md                # MCP server tool documentation
│   └── development_setup.md            # How to set up Forge for development
│
│
├── scripts/
│   ├── dev_start.sh                    # Start all services for development
│   │                                   # (FastAPI + Redis + llama.cpp + LSP)
│   ├── dev_stop.sh                     # Stop all dev services
│   ├── reset_db.py                     # Wipe and recreate local SQLite DB
│   ├── seed_config.py                  # Write default config to ~/.forge/
│   └── run_tests.sh                    # Run full Forge test suite
│
│
├── .forge/                             # Forge's own project manifest
│   └── manifest.json                   # (Forge uses itself during development)
│
├── pyproject.toml                      # Python project config (deps, build)
├── requirements.txt                    # Pinned dependencies
├── requirements-dev.txt                # Dev-only deps (pytest, ruff, etc.)
├── .env.example                        # Environment variable template
├── .gitignore
├── alembic.ini                         # Alembic DB migration config
└── README.md
```

---

## What Each Top-Level Folder Owns

| Folder | Owns | Does NOT own |
|---|---|---|
| `agents/` | Agent logic, prompts, agent-specific tools | HTTP routing, DB access |
| `backend/` | FastAPI routes, services, middleware | Agent logic, model calls |
| `broker/` | Redis client, message publishing/subscribing | Business logic |
| `cli/` | Terminal UI, commands, conversation loop | Agent logic, HTTP serving |
| `lsp/` | LSP protocol, IDE bridge | Agent logic, CLI rendering |
| `mcp/` | MCP tool servers | Agent logic, permission decisions |
| `extensions/` | IDE plugin code (TS/Kotlin) | Python logic |
| `memory/` | Checkpoint save/load, context rebuild | Agent logic, DB schema |
| `storage/` | DB models, migrations, ChromaDB | Business logic |
| `config/` | Config file read/write, settings | App logic |
| `installer/` | Packaging, install scripts | App logic |
| `deployment/` | User project deployment templates | Forge's own deployment |
| `shared/` | Types, constants, utilities | Business logic |
| `tests/` | Forge's own tests | Production code |

---

## Key Files To Know First

When you sit down to start building, these are the most important files to understand:

```
forge/shared/types.py           → Understand the data shapes first
forge/config/settings.py        → How Forge reads its config
forge/broker/message_schema.py  → The A2A message envelope
forge/agents/base_agent.py      → What every agent inherits
forge/backend/main.py           → FastAPI entry point
forge/cli/main.py               → CLI entry point
forge/storage/database/models.py → All DB tables in one place
```

---

## How The Layers Talk To Each Other

```
CLI / IDE Extension
      ↓ HTTP / WebSocket
FastAPI Backend
      ↓ publishes tasks
Redis Broker
      ↓ delivers to
ADK Agents
      ↓ call tools via
MCP Servers
      ↓ read/write
File System / Git / Terminal

Agents ↔ Memory Manager    (checkpoint save/load)
Agents ↔ Storage/ChromaDB  (semantic code search)
Backend ↔ Permission Gateway (before every write)
```

---

*Folder structure v1.0 — reflects Forge Specification v1.1*


# FORGE — Project Folder Structure
**Version:** 2.0
**Date:** May 2026

---

## Overview

The repo is organized into clearly separated concerns — each top-level folder owns one layer of the system. Nothing bleeds into another layer's folder.

```
forge/
│
├── agents/                         # All Google ADK agents (core + new)
├── backend/                        # FastAPI backend server
├── broker/                         # Redis message broker config & utilities
├── cli/                            # CLI tool (Typer + Rich)
├── lsp/                            # LSP server (pygls) for IDE integration
├── mcp/                            # MCP servers (Filesystem, Terminal, Git)
├── extensions/                     # IDE extensions (VS Code, PyCharm)
├── memory/                         # Checkpoint & session persistence
├── storage/                        # DB models, migrations, ChromaDB
├── config/                         # Forge configuration management
├── installer/                      # Installer scripts & packaging
├── deployment/                     # Deployment templates for user projects
├── quality/                        # Security scanning, linting, self-healing
├── knowledge/                      # Knowledge graph, tech debt, doc generation
├── collaboration/                  # Team features: handoff, activity feed, conflict
├── web_ui/                         # Optional localhost browser UI
├── shared/                         # Shared utilities, types, constants
├── tests/                          # Forge's own test suite
├── docs/                           # Project documentation
└── scripts/                        # Dev & ops scripts
```

---

## Full Detailed Structure

```
forge/
│
│
├── agents/
│   ├── __init__.py
│   ├── base_agent.py                     # Base class all agents inherit from
│   │                                     # Handles model connection, tool calling,
│   │                                     # streaming, checkpoint hooks,
│   │                                     # parallel execution support
│   │
│   ├── orchestrator/
│   │   ├── __init__.py
│   │   ├── agent.py                      # Root orchestrator agent
│   │   ├── router.py                     # Decides which agent handles what
│   │   ├── mode_detector.py              # Detects build/ingest/test mode
│   │   ├── parallel_scheduler.py         # Schedules independent tasks in parallel
│   │   └── prompts/
│   │       └── orchestrator.txt
│   │
│   ├── intake/
│   │   ├── __init__.py
│   │   ├── agent.py                      # Intake agent — gathers requirements
│   │   ├── user_type_detector.py         # Technical vs non-technical user
│   │   ├── requirements_builder.py       # Structures collected requirements
│   │   ├── project_plan_generator.py     # Builds plan for user approval
│   │   ├── template_matcher.py           # Matches project to template library
│   │   ├── voice_handler.py              # Voice input via Whisper (optional)
│   │   └── prompts/
│   │       ├── intake_technical.txt
│   │       └── intake_founder.txt        # Product Manager mode for founders
│   │
│   ├── architect/
│   │   ├── __init__.py
│   │   ├── agent.py                      # Architect agent
│   │   ├── stack_selector.py             # Recommends/confirms tech stack
│   │   ├── file_tree_planner.py          # Designs directory & module structure
│   │   ├── build_order_planner.py        # Orders what gets built first
│   │   ├── dependency_conflict_checker.py # Checks package compatibility pre-build
│   │   ├── architecture_diagram.py       # Generates interactive arch diagram
│   │   └── prompts/
│   │       └── architect.txt
│   │
│   ├── coder/
│   │   ├── __init__.py
│   │   ├── agent.py                      # Coder agent — writes code iteratively
│   │   ├── language_detector.py          # Detects target language from context
│   │   ├── code_writer.py                # Core code generation logic
│   │   ├── stream_handler.py             # Manages streaming output to CLI
│   │   ├── self_healer.py                # Runs code, catches errors, auto-fixes
│   │   ├── style_learner.py              # Learns codebase style patterns (1D)
│   │   ├── prompt_cache_manager.py       # Manages prompt caching for large repos
│   │   └── prompts/
│   │       ├── coder_base.txt
│   │       └── coder_continuation.txt    # Context recovery prompt (post-burst)
│   │
│   ├── tester/
│   │   ├── __init__.py
│   │   ├── agent.py                      # Tester agent
│   │   ├── test_analyser.py              # Analyses codebase for test targets
│   │   ├── unit_writer.py                # Writes unit tests
│   │   ├── integration_writer.py         # Writes integration tests
│   │   ├── e2e_writer.py                 # Writes E2E tests
│   │   ├── coverage_reporter.py          # Reports test coverage gaps
│   │   ├── mutation_tester.py            # Mutation testing to validate test quality
│   │   ├── performance_benchmarker.py    # Writes performance benchmarks
│   │   ├── test_maintainer.py            # Updates tests when code is patched
│   │   └── prompts/
│   │       └── tester.txt
│   │
│   ├── patcher/
│   │   ├── __init__.py
│   │   ├── agent.py                      # Patcher agent — applies code patches
│   │   ├── diff_generator.py             # Generates human-readable diffs
│   │   ├── patch_applier.py              # Applies patches to files
│   │   ├── rollback_manager.py           # Manages patch version history
│   │   └── prompts/
│   │       └── patcher.txt
│   │
│   ├── reviewer/
│   │   ├── __init__.py
│   │   ├── agent.py                      # Reviewer/Suggester agent
│   │   ├── code_reviewer.py              # Reviews code quality & patterns
│   │   ├── suggestion_builder.py         # Builds enhancement suggestions
│   │   ├── changelog_generator.py        # Generates changelog entries per session
│   │   └── prompts/
│   │       └── reviewer.txt
│   │
│   ├── security/                         # NEW — Security Scanning Agent (1D)
│   │   ├── __init__.py
│   │   ├── agent.py                      # Security scanner agent
│   │   ├── secret_detector.py            # Finds hardcoded secrets/keys
│   │   ├── vulnerability_scanner.py      # Common vulnerability patterns (SQLi, XSS etc.)
│   │   ├── dependency_auditor.py         # Checks deps for known CVEs
│   │   ├── exposure_checker.py           # Checks for exposed endpoints/data
│   │   ├── report_builder.py             # Builds security report for user
│   │   └── prompts/
│   │       └── security.txt
│   │
│   ├── debugger/                         # NEW — Debug Mode Agent (8B)
│   │   ├── __init__.py
│   │   ├── agent.py                      # Debug agent
│   │   ├── error_analyser.py             # Parses stack traces & error messages
│   │   ├── root_cause_finder.py          # Traces error to origin in codebase
│   │   ├── fix_suggester.py              # Suggests or applies the fix
│   │   └── prompts/
│   │       └── debugger.txt
│   │
│   ├── environment/                      # NEW — Environment Management Agent (6B)
│   │   ├── __init__.py
│   │   ├── agent.py                      # Environment management agent
│   │   ├── env_generator.py              # Generates .env files per environment
│   │   ├── secrets_manager.py            # Integrates with Vault, AWS Secrets etc.
│   │   ├── env_validator.py              # Validates env vars are complete & correct
│   │   └── prompts/
│   │       └── environment.txt
│   │
│   └── memory_manager/
│       ├── __init__.py
│       ├── checkpoint_monitor.py         # Monitors token usage, triggers saves
│       ├── context_summariser.py         # Compresses context before checkpoint
│       └── context_injector.py           # Rebuilds context after restart
│
│
├── backend/
│   ├── __init__.py
│   ├── main.py                           # FastAPI app entry point
│   ├── dependencies.py                   # Shared FastAPI dependencies
│   │
│   ├── api/
│   │   ├── __init__.py
│   │   ├── sessions.py                   # Session CRUD endpoints
│   │   ├── agents.py                     # Agent task dispatch endpoints
│   │   ├── files.py                      # File read/write/patch endpoints
│   │   ├── permissions.py                # Permission grant/revoke endpoints
│   │   ├── streaming.py                  # SSE streaming endpoints
│   │   ├── projects.py                   # Project ingest & metadata endpoints
│   │   ├── security.py                   # Security scan trigger & results
│   │   ├── debug.py                      # Debug session endpoints
│   │   ├── rollback.py                   # Rollback endpoints
│   │   ├── collaboration.py              # Team handoff, activity feed endpoints
│   │   ├── voice.py                      # Voice input endpoints (optional)
│   │   └── health.py                     # Health check endpoint
│   │
│   ├── services/
│   │   ├── __init__.py
│   │   ├── session_service.py            # Session lifecycle management
│   │   ├── permission_gateway.py         # Central permission check logic
│   │   ├── project_ingestor.py           # Scans & analyses existing codebases
│   │   ├── file_lock_manager.py          # Redis-based file locking (team mode)
│   │   ├── streaming_manager.py          # Manages SSE streams to clients
│   │   ├── deployment_service.py         # Generates deployment configs
│   │   ├── rollback_service.py           # Manages Forge-level rollback history
│   │   ├── parallel_executor.py          # Runs independent agent tasks in parallel
│   │   └── env_config_service.py         # Environment config management
│   │
│   └── middleware/
│       ├── __init__.py
│       ├── logging.py
│       └── error_handler.py
│
│
├── broker/
│   ├── __init__.py
│   ├── client.py
│   ├── publisher.py
│   ├── subscriber.py
│   ├── message_schema.py                 # A2A message envelope
│   ├── queues.py                         # Queue name constants (includes new agents)
│   └── event_bus.py
│
│
├── cli/
│   ├── __init__.py
│   ├── main.py
│   │
│   ├── commands/
│   │   ├── __init__.py
│   │   ├── start.py
│   │   ├── resume.py
│   │   ├── sessions.py
│   │   ├── switch.py
│   │   ├── status.py
│   │   ├── checkpoint.py
│   │   ├── config.py
│   │   ├── connect.py
│   │   ├── debug.py                      # NEW — forge debug (enter debug mode)
│   │   ├── rollback.py                   # NEW — forge rollback
│   │   ├── security.py                   # NEW — forge security (run security scan)
│   │   ├── explain.py                    # NEW — forge explain (explain mode)
│   │   └── changelog.py                  # NEW — forge changelog
│   │
│   ├── conversation/
│   │   ├── __init__.py
│   │   ├── loop.py
│   │   ├── command_parser.py
│   │   └── input_handler.py
│   │
│   ├── views/
│   │   ├── __init__.py
│   │   ├── status_view.py
│   │   ├── code_view.py
│   │   ├── patch_prompt.py
│   │   ├── session_list.py
│   │   ├── diff_view.py
│   │   ├── security_report_view.py       # NEW — displays security scan results
│   │   ├── activity_feed_view.py         # NEW — team activity feed display
│   │   ├── arch_diagram_view.py          # NEW — renders architecture diagram in CLI
│   │   ├── tech_debt_view.py             # NEW — tech debt report display
│   │   └── rollback_view.py              # NEW — rollback history display
│   │
│   └── themes/
│       ├── __init__.py
│       └── forge_theme.py
│
│
├── lsp/
│   ├── __init__.py
│   ├── server.py
│   ├── capabilities.py
│   │
│   ├── handlers/
│   │   ├── __init__.py
│   │   ├── text_document.py
│   │   ├── completion.py
│   │   ├── diagnostics.py
│   │   ├── commands.py
│   │   └── explain.py                    # NEW — LSP handler for Explain Mode (8A)
│   │
│   └── bridge/
│       ├── __init__.py
│       └── backend_bridge.py
│
│
├── mcp/
│   ├── __init__.py
│   │
│   ├── filesystem/
│   │   ├── __init__.py
│   │   ├── server.py
│   │   ├── reader.py
│   │   ├── writer.py
│   │   ├── patcher.py
│   │   └── deleter.py
│   │
│   ├── terminal/
│   │   ├── __init__.py
│   │   ├── server.py
│   │   ├── executor.py
│   │   ├── scope_enforcer.py
│   │   └── allowed_commands.py
│   │
│   └── git/
│       ├── __init__.py
│       ├── server.py
│       ├── commit.py
│       ├── diff.py
│       ├── branch.py
│       └── push_pull.py
│
│
├── extensions/
│   │
│   ├── vscode/
│   │   ├── package.json
│   │   ├── tsconfig.json
│   │   ├── .vscodeignore
│   │   │
│   │   └── src/
│   │       ├── extension.ts
│   │       ├── forgeClient.ts
│   │       ├── lspClient.ts
│   │       │
│   │       ├── panels/
│   │       │   ├── sidebarPanel.ts
│   │       │   ├── chatPanel.ts
│   │       │   ├── activityFeedPanel.ts  # NEW — team activity feed
│   │       │   └── securityPanel.ts      # NEW — security scan results panel
│   │       │
│   │       ├── providers/
│   │       │   ├── completionProvider.ts
│   │       │   ├── diagnosticProvider.ts
│   │       │   └── explainProvider.ts    # NEW — explain selected code
│   │       │
│   │       └── ui/
│   │           ├── patchNotification.ts
│   │           ├── statusBar.ts
│   │           └── rollbackNotification.ts # NEW — rollback prompt UI
│   │
│   └── pycharm/
│       ├── build.gradle.kts
│       ├── plugin.xml
│       │
│       └── src/main/kotlin/
│           └── com/forge/plugin/
│               ├── ForgePlugin.kt
│               ├── ForgeClient.kt
│               │
│               ├── toolwindow/
│               │   ├── ForgeToolWindow.kt
│               │   ├── ChatPanel.kt
│               │   ├── ActivityFeedPanel.kt  # NEW
│               │   └── SecurityPanel.kt      # NEW
│               │
│               ├── actions/
│               │   ├── StartForgeAction.kt
│               │   ├── AskForgeAction.kt
│               │   ├── ExplainCodeAction.kt  # NEW — explain selected code
│               │   └── DebugErrorAction.kt   # NEW — send error to debug agent
│               │
│               └── diff/
│                   └── PatchDiffViewer.kt
│
│
├── memory/
│   ├── __init__.py
│   ├── checkpoint_manager.py
│   ├── session_store.py
│   ├── checkpoint_store.py
│   ├── context_builder.py
│   └── token_counter.py
│
│
├── storage/
│   ├── __init__.py
│   │
│   ├── database/
│   │   ├── __init__.py
│   │   ├── connection.py
│   │   ├── models.py                     # Includes new tables:
│   │   │                                 # rollback_snapshots, security_reports,
│   │   │                                 # changelogs, tech_debt_items,
│   │   │                                 # activity_feed, session_handoffs
│   │   └── migrations/
│   │       └── versions/
│   │
│   └── vector/
│       ├── __init__.py
│       ├── chroma_client.py
│       ├── embedder.py
│       └── searcher.py
│
│
├── config/
│   ├── __init__.py
│   ├── settings.py
│   ├── config_manager.py
│   ├── defaults.py
│   └── schema.py
│
│
├── installer/
│   ├── online/
│   │   ├── install.sh
│   │   └── install.ps1
│   │
│   ├── docker/
│   │   ├── Dockerfile
│   │   ├── docker-compose.yml
│   │   └── .env.example
│   │
│   └── executable/
│       ├── build_windows.py
│       ├── build_macos.py
│       ├── build_linux.py
│       └── forge.spec
│
│
├── deployment/
│   ├── templates/
│   │   ├── docker/
│   │   │   ├── python_fastapi.dockerfile
│   │   │   ├── node_express.dockerfile
│   │   │   ├── java_spring.dockerfile
│   │   │   └── generic.dockerfile
│   │   │
│   │   ├── docker-compose/
│   │   │   ├── with_postgres.yml
│   │   │   ├── with_redis.yml
│   │   │   └── full_stack.yml
│   │   │
│   │   ├── cicd/
│   │   │   ├── github_actions.yml
│   │   │   ├── gitlab_ci.yml
│   │   │   └── bitbucket_pipelines.yml
│   │   │
│   │   ├── iac/                          # NEW — Infrastructure as Code (6A)
│   │   │   ├── terraform/
│   │   │   │   ├── aws_ecs.tf
│   │   │   │   ├── gcp_cloud_run.tf
│   │   │   │   └── azure_app_service.tf
│   │   │   └── pulumi/
│   │   │       ├── aws_stack.py
│   │   │       └── gcp_stack.py
│   │   │
│   │   └── providers/
│   │       ├── aws/
│   │       ├── gcp/
│   │       ├── azure/
│   │       ├── digitalocean/
│   │       ├── railway/
│   │       ├── render/
│   │       ├── vercel/
│   │       ├── flyio/
│   │       └── heroku/
│   │
│   └── generator.py
│
│
├── quality/                              # NEW top-level folder
│   │                                     # Owns all code quality concerns:
│   │                                     # security, self-healing, linting
│   │
│   ├── __init__.py
│   │
│   ├── self_healing/                     # Suggestion 1A
│   │   ├── __init__.py
│   │   ├── runner.py                     # Runs generated code silently
│   │   ├── error_catcher.py              # Catches syntax/runtime errors
│   │   ├── fix_loop.py                   # Sends errors back to Coder Agent
│   │   └── heal_report.py                # Reports what was auto-fixed
│   │
│   ├── review_gate/                      # Suggestion 1B — inter-agent review loop
│   │   ├── __init__.py
│   │   ├── gate.py                       # Silent quality gate before file is saved
│   │   ├── issue_classifier.py           # Classifies issues found by reviewer
│   │   └── rerouter.py                   # Sends back to Coder if issues found
│   │
│   ├── security/                         # Suggestion 1D (shared with agents/security)
│   │   ├── __init__.py
│   │   ├── patterns/
│   │   │   ├── secrets.py                # Hardcoded secret patterns
│   │   │   ├── injections.py             # SQL/command injection patterns
│   │   │   └── exposures.py              # Exposed endpoint patterns
│   │   └── cve_checker.py                # Checks deps against CVE database
│   │
│   └── linting/
│       ├── __init__.py
│       ├── lint_runner.py                # Runs linter for detected language
│       └── lint_config_generator.py      # Generates lint config for project
│
│
├── knowledge/                            # NEW top-level folder
│   │                                     # Owns project understanding features:
│   │                                     # knowledge graph, tech debt, docs
│   │
│   ├── __init__.py
│   │
│   ├── graph/                            # Suggestion 2A — Knowledge Graph
│   │   ├── __init__.py
│   │   ├── builder.py                    # Builds module relationship graph
│   │   ├── call_analyser.py              # Analyses which modules call which
│   │   ├── data_flow_mapper.py           # Maps data flow across codebase
│   │   ├── dependency_resolver.py        # Resolves what depends on what
│   │   └── graph_store.py                # Persists graph (NetworkX + SQLite)
│   │
│   ├── docs/                             # Suggestion 2B — Auto Documentation
│   │   ├── __init__.py
│   │   ├── readme_generator.py           # Generates project README
│   │   ├── api_doc_generator.py          # Generates API documentation
│   │   ├── inline_commenter.py           # Adds inline code comments
│   │   └── doc_templates/
│   │       ├── readme_template.md
│   │       └── api_doc_template.md
│   │
│   └── tech_debt/                        # Suggestion 2C — Tech Debt Detector
│       ├── __init__.py
│       ├── detector.py                   # Detects debt: deprecated deps, dead code
│       ├── pattern_checker.py            # Finds inconsistent patterns
│       ├── prioritiser.py                # Prioritises debt items by impact
│       └── report_builder.py             # Builds prioritised debt report
│
│
├── collaboration/                        # NEW top-level folder
│   │                                     # Owns all team collaboration features
│   │
│   ├── __init__.py
│   │
│   ├── handoff/                          # Suggestion 4A — Session Handoff
│   │   ├── __init__.py
│   │   ├── handoff_manager.py            # Manages session handoff between devs
│   │   ├── context_packager.py           # Packages session context for receiver
│   │   └── handoff_notifier.py           # Notifies receiving developer
│   │
│   ├── activity_feed/                    # Suggestion 4B — Activity Feed
│   │   ├── __init__.py
│   │   ├── feed_publisher.py             # Publishes agent activity to feed
│   │   ├── feed_subscriber.py            # Team members subscribe to feed
│   │   └── feed_formatter.py             # Formats feed entries for display
│   │
│   └── conflict_prevention/             # Suggestion 4C — Conflict Prevention
│       ├── __init__.py
│       ├── ownership_tracker.py          # Tracks which session owns which module
│       ├── overlap_detector.py           # Detects when two sessions plan same work
│       └── conflict_notifier.py          # Notifies both devs of overlap
│
│
├── web_ui/                               # NEW — Optional Web UI (Suggestion 3A)
│   │                                     # Runs on localhost, browser-based
│   │                                     # companion to CLI
│   │
│   ├── backend/
│   │   ├── __init__.py
│   │   ├── server.py                     # Lightweight FastAPI serving the web UI
│   │   └── websocket.py                  # WebSocket for live streaming to browser
│   │
│   └── frontend/
│       ├── index.html
│       ├── css/
│       │   └── forge.css
│       └── js/
│           ├── app.js                    # Main app
│           ├── terminal.js               # Browser terminal (xterm.js)
│           ├── filetree.js               # File tree with agent annotations
│           ├── diff_viewer.js            # Diff viewer for patch review
│           ├── session_manager.js        # Session switching UI
│           └── activity_feed.js          # Team activity feed UI
│
│
├── shared/
│   ├── __init__.py
│   ├── types.py                          # Shared dataclasses & TypedDicts
│   │                                     # Includes new types:
│   │                                     # SecurityReport, TechDebtItem,
│   │                                     # RollbackSnapshot, ActivityFeedEntry,
│   │                                     # HandoffPackage, KnowledgeGraphNode
│   ├── constants.py
│   ├── exceptions.py
│   ├── logger.py
│   └── utils/
│       ├── __init__.py
│       ├── file_utils.py
│       ├── language_detector.py
│       ├── framework_detector.py
│       └── token_utils.py
│
│
├── tests/
│   ├── unit/
│   │   ├── test_agents/
│   │   │   ├── test_orchestrator.py
│   │   │   ├── test_intake.py
│   │   │   ├── test_architect.py
│   │   │   ├── test_coder.py
│   │   │   ├── test_tester.py
│   │   │   ├── test_patcher.py
│   │   │   ├── test_reviewer.py
│   │   │   ├── test_security.py          # NEW
│   │   │   ├── test_debugger.py          # NEW
│   │   │   └── test_environment.py       # NEW
│   │   │
│   │   ├── test_backend/
│   │   │   ├── test_permission_gateway.py
│   │   │   ├── test_project_ingestor.py
│   │   │   ├── test_session_service.py
│   │   │   ├── test_rollback_service.py  # NEW
│   │   │   └── test_parallel_executor.py # NEW
│   │   │
│   │   ├── test_broker/
│   │   │   ├── test_publisher.py
│   │   │   └── test_subscriber.py
│   │   │
│   │   ├── test_memory/
│   │   │   ├── test_checkpoint_manager.py
│   │   │   └── test_context_builder.py
│   │   │
│   │   ├── test_mcp/
│   │   │   ├── test_filesystem.py
│   │   │   ├── test_terminal.py
│   │   │   └── test_git.py
│   │   │
│   │   ├── test_quality/                 # NEW
│   │   │   ├── test_self_healing.py
│   │   │   ├── test_review_gate.py
│   │   │   └── test_security_patterns.py
│   │   │
│   │   ├── test_knowledge/               # NEW
│   │   │   ├── test_graph_builder.py
│   │   │   ├── test_doc_generator.py
│   │   │   └── test_tech_debt_detector.py
│   │   │
│   │   └── test_collaboration/           # NEW
│   │       ├── test_handoff.py
│   │       ├── test_activity_feed.py
│   │       └── test_conflict_prevention.py
│   │
│   ├── integration/
│   │   ├── test_agent_flow.py
│   │   ├── test_a2a_communication.py
│   │   ├── test_permission_flow.py
│   │   ├── test_session_persistence.py
│   │   ├── test_self_heal_loop.py        # NEW
│   │   ├── test_security_scan_flow.py    # NEW
│   │   ├── test_parallel_execution.py    # NEW
│   │   └── test_team_collaboration.py    # NEW
│   │
│   ├── e2e/
│   │   ├── test_build_from_scratch.py
│   │   ├── test_ingest_project.py
│   │   ├── test_generate_tests.py
│   │   ├── test_debug_flow.py            # NEW
│   │   ├── test_rollback_flow.py         # NEW
│   │   └── test_security_flow.py         # NEW
│   │
│   └── fixtures/
│       ├── sample_projects/
│       │   ├── incomplete_fastapi/       # For Mode 2 testing
│       │   ├── complete_react_app/       # For Mode 3 testing
│       │   ├── vulnerable_project/       # For security scan testing
│       │   └── multi_language_project/   # For language detection testing
│       └── mock_responses/
│
│
├── docs/
│   ├── specification.md                  # Full project specification (v1.2)
│   ├── folder_structure.md               # This document
│   ├── architecture.md
│   ├── agent_prompts.md
│   ├── api_reference.md
│   ├── config_reference.md
│   ├── mcp_reference.md
│   ├── security_guide.md                 # NEW — security scanning docs
│   ├── collaboration_guide.md            # NEW — team features docs
│   ├── web_ui_guide.md                   # NEW — web UI setup & usage
│   └── development_setup.md
│
│
├── scripts/
│   ├── dev_start.sh                      # Starts all services for development
│   ├── dev_stop.sh
│   ├── reset_db.py
│   ├── seed_config.py
│   ├── build_knowledge_graph.py          # NEW — pre-builds graph for large repos
│   └── run_tests.sh
│
│
├── .forge/
│   └── manifest.json
│
├── pyproject.toml
├── requirements.txt
├── requirements-dev.txt
├── .env.example
├── .gitignore
├── alembic.ini
└── README.md
```

---

## What Each Top-Level Folder Owns

| Folder | Owns | Does NOT own |
|---|---|---|
| `agents/` | Agent logic, prompts, all agent types | HTTP routing, DB access |
| `backend/` | FastAPI routes, services, middleware | Agent logic, model calls |
| `broker/` | Redis client, message publishing/subscribing | Business logic |
| `cli/` | Terminal UI, commands, conversation loop | Agent logic, HTTP serving |
| `lsp/` | LSP protocol, IDE bridge | Agent logic, CLI rendering |
| `mcp/` | MCP tool servers | Agent logic, permission decisions |
| `extensions/` | IDE plugin code (TS/Kotlin) | Python logic |
| `memory/` | Checkpoint save/load, context rebuild | Agent logic, DB schema |
| `storage/` | DB models, migrations, ChromaDB | Business logic |
| `config/` | Config file read/write, settings | App logic |
| `installer/` | Packaging, install scripts | App logic |
| `deployment/` | User project deployment templates | Forge's own deployment |
| `quality/` | Self-healing, review gate, security patterns, linting | Agent logic |
| `knowledge/` | Knowledge graph, auto-docs, tech debt | Agent logic, UI |
| `collaboration/` | Handoff, activity feed, conflict prevention | Agent logic, storage |
| `web_ui/` | Browser UI frontend + its mini-server | CLI logic, agent logic |
| `shared/` | Types, constants, utilities | Business logic |
| `tests/` | Forge's own tests | Production code |

---

## New Additions Summary (v1.0 → v2.0)

| Addition | Suggestion | Where |
|---|---|---|
| `agents/security/` | 1D — Security Scanning Agent | agents/ |
| `agents/debugger/` | 8B — Debug Mode Agent | agents/ |
| `agents/environment/` | 6B — Environment Management Agent | agents/ |
| `agents/coder/self_healer.py` | 1A — Self-Healing Code | agents/coder/ |
| `agents/coder/style_learner.py` | 8D — Learn Mode | agents/coder/ |
| `agents/coder/prompt_cache_manager.py` | 7B — Prompt Caching | agents/coder/ |
| `agents/architect/dependency_conflict_checker.py` | 1C — Dependency Conflict Detection | agents/architect/ |
| `agents/architect/architecture_diagram.py` | 3D — Interactive Architecture Review | agents/architect/ |
| `agents/tester/mutation_tester.py` | 5A — Mutation Testing | agents/tester/ |
| `agents/tester/performance_benchmarker.py` | 5C — Performance Benchmarking | agents/tester/ |
| `agents/tester/test_maintainer.py` | 5B — Automatic Test Maintenance | agents/tester/ |
| `agents/patcher/rollback_manager.py` | 6C — Rollback System | agents/patcher/ |
| `agents/reviewer/changelog_generator.py` | 8C — Changelog Generator | agents/reviewer/ |
| `agents/intake/template_matcher.py` | 3C — Project Templates Library | agents/intake/ |
| `agents/intake/voice_handler.py` | 3B — Voice Input Mode | agents/intake/ |
| `agents/orchestrator/parallel_scheduler.py` | 7C — Parallel Agent Execution | agents/orchestrator/ |
| `quality/` | 1A, 1B, 1D — Quality concerns | top-level |
| `knowledge/` | 2A, 2B, 2C — Project understanding | top-level |
| `collaboration/` | 4A, 4B, 4C — Team features | top-level |
| `web_ui/` | 3A — Web UI companion | top-level |
| `deployment/templates/iac/` | 6A — Infrastructure as Code | deployment/ |

---

## Key Files To Know First

```
forge/shared/types.py                    → Understand data shapes first
forge/config/settings.py                 → How Forge reads its config
forge/broker/message_schema.py           → The A2A message envelope
forge/agents/base_agent.py               → What every agent inherits
forge/backend/main.py                    → FastAPI entry point
forge/cli/main.py                        → CLI entry point
forge/storage/database/models.py         → All DB tables in one place
forge/quality/self_healing/runner.py     → Self-heal entry point
forge/knowledge/graph/builder.py         → Knowledge graph entry point
forge/collaboration/handoff/handoff_manager.py → Team handoff entry point
```

---

## How The Layers Talk To Each Other

```
CLI / Web UI / IDE Extension
        ↓ HTTP / WebSocket
  FastAPI Backend
        ↓ publishes tasks
    Redis Broker
        ↓ delivers to
      ADK Agents
      ↙    ↓    ↘
 Quality  MCP  Knowledge
 Layer   Servers  Layer
           ↓
    File System / Git / Terminal

Agents    ↔ Memory Manager       (checkpoint save/load)
Agents    ↔ Storage/ChromaDB     (semantic code search)
Agents    ↔ Knowledge Graph      (codebase relationships)
Backend   ↔ Permission Gateway   (before every write)
Backend   ↔ Collaboration Layer  (team features)
Coder     ↔ Quality/Self-Healing (auto-fix before save)
Reviewer  ↔ Quality/Review Gate  (silent quality check)
```

---

*Folder structure v2.0 — reflects Forge Specification v1.2 with all enhancements*