"""
app.py - FIXED
"""
import core.suppress_warnings

import os
import sys
# os.environ["OTEL_SDK_DISABLED"] = "true"
# os.environ["OTEL_PYTHON_LOG_LEVEL"] = "error"

# import warnings
# # Suppress all warnings
# warnings.filterwarnings("ignore")
#
# import logging
# logging.getLogger("LiteLLM").setLevel(logging.CRITICAL)
# logging.getLogger("litellm").setLevel(logging.CRITICAL)
# logging.getLogger("asyncio").setLevel(logging.CRITICAL)
# logging.getLogger("opentelemetry").setLevel(logging.CRITICAL)


# # ── MUST be before ALL other imports ──────────────────
# os.environ["PYTHONUTF8"] = "1"
# os.environ["LITELLM_LOG"] = "ERROR"
#
# # Suppress specific noisy modules
# warnings.filterwarnings("ignore", category=UserWarning, module="google.adk")
# warnings.filterwarnings("ignore", category=DeprecationWarning)
# warnings.filterwarnings("ignore", message=".*EXPERIMENTAL.*")
# warnings.filterwarnings("ignore", message=".*datetime.datetime.utcnow.*")

sys.path.insert(0, os.path.dirname(__file__))

# Now import everything else
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from typing import Optional
import httpx
import logging

# Silence LiteLLM logging
logging.getLogger("LiteLLM").setLevel(logging.ERROR)
logging.getLogger("litellm").setLevel(logging.ERROR)

from core.logger import get_logger, success_logger, error_logger
from core.session_manager import get_or_create_session, add_to_history, get_history
from agents.orchestrator.agent import run_orchestrator_async
from agents.mlff.agent import run_mlff_async
from agents.support.agent import run_support_async
from agents.dispute.agent import run_dispute_async
from core.config import config
from core.agent_registry import discover_agents

logger = get_logger("app")
app = FastAPI(title="MLFF ADK Analytics", version="2.0.0")
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")


class QueryRequest(BaseModel):
    message: str
    session_id: Optional[str] = None
    agent: Optional[str] = None  # "auto", "mlff", "support", etc.

# In app.py startup event
@app.on_event("startup")
async def check_llm_health():
    try:
        async with httpx.AsyncClient(timeout=60.0) as client:
            # llama.cpp doesn't have /health, use /v1/models instead
            resp = await client.get(f"{config.LOCAL_LLM_BASE_URL}/models")
            if resp.status_code == 200:
                logger.info("LLM server is healthy")
            else:
                logger.warning(f"LLM server returned status {resp.status_code}")
    except Exception as e:
        logger.error(f"LLM server not reachable: {e}")

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.post("/query")
async def query(payload: QueryRequest):
    session_id = get_or_create_session(payload.session_id)
    user_query = payload.message.strip()
    if not user_query:
        raise HTTPException(status_code=400, detail="Query cannot be empty.")

    success_logger.info(f"Query received | session={session_id} | query={user_query[:80]}")

    try:
        # ── Direct agent selection (if user picked a specific agent) ──
        if payload.agent and payload.agent != "auto":
            if payload.agent == "mlff":
                # Build dummy orchestrator payload from pre‑loaded cache
                from agents.mlff.agent import _MLFF_CACHE
                orch_payload = {
                    "ok": True,
                    "user_query": user_query,
                    "intent": "lookup",          # safe default
                    "query_type": "simple",
                    "confidence": 1.0,
                    "selected_schema": _MLFF_CACHE["selected_schema"],
                    "selected_tables": _MLFF_CACHE["selected_tables"],
                    "schema_details": _MLFF_CACHE["schema_details"],
                    "relationships_hint": _MLFF_CACHE["relationships_hint"],
                    "context_summary": "",
                    "routing_to": "mlff",
                    "request_id": session_id,
                }
                agent_result = await run_mlff_async(orch_payload, session_id)
            elif payload.agent == "support":
                agent_result = await run_support_async(user_query, session_id)
            elif payload.agent == "dispute":
                agent_result = await run_dispute_async(user_query, session_id)
            else:
                # Unknown agent – fall back to auto pipeline
                orchestrator_result = await run_orchestrator_async(user_query=user_query, session_id=session_id)
                if orchestrator_result.get("routing_to") == "support":
                    agent_result = await run_support_async(user_query=user_query, session_id=session_id)
                else:
                    agent_result = await run_mlff_async(orchestrator_payload=orchestrator_result, session_id=session_id)
        else:
            # ── Normal auto pipeline ──────────────────────────────────
            orchestrator_result = await run_orchestrator_async(user_query=user_query, session_id=session_id)
            if orchestrator_result.get("routing_to") == "support":
                agent_result = await run_support_async(user_query=user_query, session_id=session_id)
            elif orchestrator_result.get("routing_to") == "dispute":
                agent_result = await run_dispute_async(user_query, session_id)
            else:
                agent_result = await run_mlff_async(orchestrator_payload=orchestrator_result, session_id=session_id)

        add_to_history(session_id, {
            "user_query": user_query,
            "sql": agent_result.get("sql", ""),
            "row_count": agent_result.get("row_count", 0),
            "explanation": agent_result.get("explanation", ""),
            "intent": agent_result.get("intent", ""),
            "confidence": agent_result.get("confidence", 0),
            "ok": agent_result.get("ok", False),
        })

        return {**agent_result, "session_id": session_id}

    except Exception as e:
        error_logger.error(f"Pipeline error: {e}")
        return JSONResponse(status_code=500, content={
            "ok": False, "error": str(e), "session_id": session_id,
            "sql": "", "rows": [], "row_count": 0,
            "explanation": str(e), "chart_type": "none", "columns": [],
        })


@app.get("/history/{session_id}")
def get_session_history(session_id: str):
    return {"session_id": session_id, "history": get_history(session_id)}


@app.get("/health")
def health():
    return {"status": "ok", "service": "MLFF ADK App v2"}


@app.get("/agent-cards")
def agent_cards():
    from agents.orchestrator.agent_card import ORCHESTRATOR_CARD
    from agents.mlff.agent_card import MLFF_CARD
    from agents.dispute.agent_card import DISPUTE_CARD
    from agents.support.agent_card import SUPPORT_CARD
    return {"orchestrator": ORCHESTRATOR_CARD.to_dict(), "mlff": MLFF_CARD.to_dict(), "support": SUPPORT_CARD.to_dict(), "dispute": DISPUTE_CARD.to_dict()}

@app.get("/agents")
def list_agents():
    return discover_agents()
