"""
agents/orchestrator/agent.py
Updated to use the tool call parser bridge.
"""
import os
import warnings
os.environ["OTEL_SDK_DISABLED"] = "true"
warnings.filterwarnings("ignore", category=UserWarning, module="google.adk")

import os
import json
# import asyncio
from typing import Any, Dict

from dotenv import load_dotenv
from google.adk.agents import LlmAgent
from google.adk.models.lite_llm import LiteLlm
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService

from agents.orchestrator.agent_card import ORCHESTRATOR_CARD
from agents.orchestrator.skills.intent_detection import run_intent_detection
from agents.orchestrator.skills.schema_context_selector import select_schema_context
from agents.support.skills.skills_reader import match_skill
from agents.mlff.agent import _MLFF_CACHE
from core.mcp_client import mcp_client
from core.tool_call_parser import set_tools_map, patch_adk_agent,make_tool, detect_tool_response
from core.logger import get_logger, success_logger, error_logger

load_dotenv()
logger = get_logger("orchestrator")

os.environ["OPENAI_API_KEY"] = os.getenv("LOCAL_LLM_API_KEY", "sk-local")
os.environ["OPENAI_API_BASE"] = os.getenv("LOCAL_LLM_BASE_URL", "http://127.0.0.1:8001/v1")

_model = LiteLlm(model=f"openai/{os.getenv('LOCAL_LLM_MODEL', 'local-model')}")

SKILL_MATCH_THRESHOLD = 3   # minimum score to auto‑route to support

# ── ADK Tool functions ────────────────────────────────────────────────────────

def detect_query_intent(user_query: str) -> str:
    """Detect intent and complexity of a user database query."""
    result = run_intent_detection(user_query)
    logger.info(f"Intent detected: {result}")
    return json.dumps(result)


# def get_database_context(user_query: str, intent: str, query_type: str) -> str:
#     """Fetch database schema cache and select relevant schema, tables, columns."""
#     try:
#         cache = mcp_client.get_cache()
#         context = select_schema_context(user_query, intent, query_type, cache)
#
#         selected_schema = context.get("selected_schema", "public")
#         selected_tables = context.get("selected_tables", [])
#         schemas_data = cache.get("schemas", {})
#
#         schema_details = {}
#         for table in selected_tables:
#             full_name = f"{selected_schema}.{table}"
#             info = schemas_data.get(full_name) or schemas_data.get(table, {})
#             if info:
#                 schema_details[table] = {
#                     "columns": info.get("columns", []),
#                     "row_count": info.get("row_count", 0),
#                 }
#
#         context["schema_details"] = schema_details
#         context["table_count"] = cache.get("metadata", {}).get("table_count", 0)
#         return json.dumps(context)
#     except Exception as e:
#         error_logger.error(f"get_database_context failed: {e}")
#         return json.dumps({"error": str(e)})

wrapped_detect_intent = make_tool(detect_query_intent)
# wrapped_get_context = make_tool(get_database_context)

# ── Tools map for bridge ──────────────────────────────────────────────────────
_TOOLS_MAP = {
    "detect_query_intent": detect_query_intent,   # ← Tool name matches LLM call
    # "get_database_context": get_database_context, # ← Tool name matches LLM call
}

# Set global tools map
set_tools_map(_TOOLS_MAP)

# Patch ADK agent to intercept tool calls
# patch_adk_agent()


# ── ADK LlmAgent ──────────────────────────────────────────────────────────────

ORCHESTRATOR_INSTRUCTION = """
You are the Orchestrator Agent for the MLFF analytics system.

CRITICAL RULE: When calling any tool, pass the EXACT original question the user asked,
word for word.

Call this tool:
1. detect_query_intent(user_query="<EXACT USER QUERY from the first message>")

After the tool returns, output ONLY this JSON using the values it provided:
{
  "intent": "<from detect_query_intent>",
  "query_type": "<from detect_query_intent>",
  "confidence": <from detect_query_intent>,
  "selected_schema": "",
  "selected_tables": [],
  "context_summary": ""
}
Do NOT add any other text, markdown, or code fences.
"""

orchestrator_llm_agent = LlmAgent(
    name="orchestrator",
    model=_model,
    description=ORCHESTRATOR_CARD.description,
    instruction=ORCHESTRATOR_INSTRUCTION,
    tools=[wrapped_detect_intent],
    output_key="orchestrator_result",
)

_session_service = InMemorySessionService()
_runner = Runner(
    agent=orchestrator_llm_agent,
    app_name="mlff_adk",
    session_service=_session_service,
)


# ── Bridge Runner (Intercepts and handles tool calls) ─────────────────────────

MAX_BRIDGE_ITERATIONS = 10

async def _run_with_bridge(
    session_service: InMemorySessionService,
    user_id: str,
    session_id: str,
    initial_message: str,
    app_name: str = "mlff_adk",
    query_id: str = "",
) -> str:
    from google.genai import types
    from core.tool_call_parser import (
        parse_tool_call, execute_parsed_tool,
        detect_tool_call, format_tool_response,
        detect_batch_tool_calls, parse_batch_tool_calls,
    )

    tool_results = {}
    iterations = 0
    current_message = initial_message

    while iterations < MAX_BRIDGE_ITERATIONS:
        iterations += 1

        session_id_iter = f"orch_{session_id}_{query_id}_iter{iterations}"
        await session_service.create_session(
            app_name=app_name,
            user_id=user_id,
            session_id=session_id_iter,
        )

        fresh_runner = Runner(
            agent=orchestrator_llm_agent,
            app_name=app_name,
            session_service=session_service,
        )

        logger.debug(f"[BRIDGE] Orchestrator Iteration {iterations} | session={session_id_iter}")

        message = types.Content(
            role="user",
            parts=[types.Part(text=current_message)],
        )

        raw_text = ""
        gen = fresh_runner.run_async(
            user_id=user_id,
            session_id=session_id_iter,
            new_message=message,
        )

        try:
            async for event in gen:
                if event.is_final_response():
                    if event.content and event.content.parts:
                        raw_text = event.content.parts[0].text or ""
                        logger.debug(f"[BRIDGE] Raw output (iter {iterations}): {raw_text[:200]}")
                    await gen.aclose()
                    break
        except Exception as e:
            if "created in a different Context" not in str(e):
                logger.error(f"Unexpected error: {e}")

        if not raw_text:
            logger.warning(f"[BRIDGE] Empty response on iteration {iterations}")
            break

        # ── Case 1: Batch JSON array tool calls ──────────────────────
        if detect_batch_tool_calls(raw_text):
            parsed_list = parse_batch_tool_calls(raw_text)
            if parsed_list:
                for parsed in parsed_list:
                    tool_result = await execute_parsed_tool(parsed, _TOOLS_MAP)
                    if tool_result:
                        tool_results[parsed['tool_name']] = tool_result

        # ── Case 2: Single tool CALL ──────────────────────────────────
        elif detect_tool_call(raw_text):
            parsed = parse_tool_call(raw_text)
            if parsed:
                tool_result = await execute_parsed_tool(parsed, _TOOLS_MAP)
                if tool_result:
                    tool_results[parsed['tool_name']] = tool_result
                    logger.info(f"[BRIDGE] Tool executed: {parsed['tool_name']} | result_len={len(tool_result)}")
                else:
                    logger.error(f"[BRIDGE] Tool returned None: {parsed['tool_name']}")
                    break
            else:
                logger.warning(f"[BRIDGE] Tool detected but parse failed: {raw_text[:200]}")
                break

        # ── Case 3: Tool RESPONSE – ignore, we'll handle completion below ──
        elif detect_tool_response(raw_text):
            logger.info(f"[BRIDGE] Got tool response on iter {iterations}, ignoring")

        # ── Deterministic completion after each iteration ─────────
        # If both tools are present (batch case), decide routing
        if all(k in tool_results for k in ["detect_query_intent", "get_database_context"]):
            skill, skill_score = match_skill(initial_message)
            force_support = bool(skill and skill_score >= SKILL_MATCH_THRESHOLD)
            if force_support:
                logger.info(f"[BRIDGE] Batch: forcing support (skill={skill['name']}, score={skill_score})")
            return _synthesize_from_tool_results(tool_results, initial_message, force_support=force_support)

        # If only intent is ready, determine next step
        if "detect_query_intent" in tool_results and "get_database_context" not in tool_results:
            intent_data = json.loads(tool_results["detect_query_intent"])
            if intent_data.get("intent") == "support":
                return _synthesize_from_tool_results(tool_results, initial_message)

            # Check dispute intent
            if intent_data.get("intent") == "dispute":
                logger.info("[BRIDGE] Routing to dispute agent")
                return _synthesize_from_tool_results(tool_results, initial_message, routing_to="dispute")

            # Check skill match
            skill, skill_score = match_skill(initial_message)
            if skill and skill_score >= SKILL_MATCH_THRESHOLD:
                logger.info(f"[BRIDGE] Strong skill match '{skill['name']}' (score={skill_score}), forcing support")
                return _synthesize_from_tool_results(tool_results, initial_message, force_support=True)

            # ── No support match → route to MLFF with pre‑loaded table cache ──
            logger.info("[BRIDGE] Routing to MLFF with pre‑configured tables")
            # Simulate a get_database_context result using the MLFF mini‑cache
            context_result = json.dumps({
                "selected_schema": _MLFF_CACHE["selected_schema"],
                "selected_tables": _MLFF_CACHE["selected_tables"],
                "schema_details": _MLFF_CACHE["schema_details"],
                "relationships_hint": _MLFF_CACHE["relationships_hint"],
                "context_summary": "",
            })
            tool_results["get_database_context"] = context_result
            return _synthesize_from_tool_results(tool_results, initial_message)

        # If we made no progress, break
        if not tool_results:
            logger.warning("[BRIDGE] No tools executed, breaking")
            break

        # Prepare for next iteration only if we still need the intent tool
        prior_context = "\n".join([f"Tool {k} returned: {v[:300]}" for k, v in tool_results.items()])
        current_message = (
            f"Original request:\n{initial_message}\n\n"
            f"Results so far:\n{prior_context}"
        )

    # ── If the LLM didn't call any tool, run intent detection directly ──
    if not tool_results:
        logger.info("[BRIDGE] LLM produced no tool calls – running intent detection directly")
        intent_result = detect_query_intent(initial_message)  # call the real function
        tool_results["detect_query_intent"] = intent_result

        intent_data = json.loads(intent_result)

        if intent_data.get("intent") == "support":
            return _synthesize_from_tool_results(tool_results, initial_message)

        skill, skill_score = match_skill(initial_message)
        if skill and skill_score >= SKILL_MATCH_THRESHOLD:
            logger.info(f"[BRIDGE] Direct intent matched skill '{skill['name']}', forcing support")
            return _synthesize_from_tool_results(tool_results, initial_message, force_support=True)

        # ── Dispute keyword routing ──────────────────────────────────
        dispute_kw = ["transaction", "transactions", "dispute", "disputes",
                      "chargeback", "chargebacks", "toll", "plaza", "fastag"]
        if any(kw in initial_message.lower() for kw in dispute_kw):
            logger.info("[BRIDGE] Dispute keyword match – routing to dispute agent")
            return _synthesize_from_tool_results(tool_results, initial_message, routing_to="dispute")

        # Route to MLFF with pre‑loaded table cache
        logger.info("[BRIDGE] Routing to MLFF with pre‑configured tables")
        context_result = json.dumps({
            "selected_schema": _MLFF_CACHE["selected_schema"],
            "selected_tables": _MLFF_CACHE["selected_tables"],
            "schema_details": _MLFF_CACHE["schema_details"],
            "relationships_hint": _MLFF_CACHE["relationships_hint"],
            "context_summary": "",
        })
        tool_results["get_database_context"] = context_result
        return _synthesize_from_tool_results(tool_results, initial_message)

    # Exhausted iterations – synthesize from whatever we collected
    if tool_results:
        logger.info(f"[BRIDGE] Synthesizing from {len(tool_results)} tool results")
        return _synthesize_from_tool_results(tool_results, initial_message)

    return ""


def _synthesize_from_tool_results(
        tool_results: dict,
        user_query: str,
        force_support: bool = False,
        routing_to: str = None
) -> str:
    """Build the orchestrator JSON directly from collected tool results.

    Args:
        tool_results: dict with keys 'detect_query_intent', 'get_database_context'
        user_query: the original user query (not used, but kept for signature)
        force_support: if True, routing is forced to 'support' even if intent is not 'support',
                       and schema-related fields are left empty.
    """
    import json

    intent_raw = tool_results.get("detect_query_intent", "{}")
    context_raw = tool_results.get("get_database_context", "{}")

    try:
        intent_data = json.loads(intent_raw) if isinstance(intent_raw, str) else intent_raw
    except Exception:
        intent_data = {}

    try:
        context_data = json.loads(context_raw) if isinstance(context_raw, str) else context_raw
    except Exception:
        context_data = {}

    # Determine routing: support if intent is 'support' or force flag is set
    if routing_to:
        final_routing = routing_to
    else:
        final_routing = "support" if (intent_data.get("intent") == "support" or force_support) else "mlff"

    # Schema details only relevant for non-support queries
    if not force_support:
        schema_details = context_data.get("schema_details", {})
        selected_tables = context_data.get("selected_tables", [])
        relevant_columns = context_data.get("relevant_columns", {})
        relationships_hint = context_data.get("relationships_hint", [])
        selected_schema = context_data.get("selected_schema", "public")
        context_summary = context_data.get("context_summary", "")
    else:
        # When forcing support, we don't need schema details
        schema_details = {}
        selected_tables = []
        relevant_columns = {}
        relationships_hint = []
        selected_schema = ""
        context_summary = ""

    return json.dumps({
        "intent": intent_data.get("intent", "aggregation"),
        "query_type": intent_data.get("query_type", "select"),
        "confidence": intent_data.get("confidence", 0.75),
        "selected_schema": selected_schema,
        "selected_tables": selected_tables,
        "relevant_columns": relevant_columns,
        "relationships_hint": relationships_hint,
        "context_summary": context_summary,
        "schema_details": schema_details,
        "routing_to": final_routing,
    })

# ── Run with bridge ──────────────────────────────────────────────────────────
async def run_orchestrator_async(
    user_query: str,
    session_id: str,
    user_id: str = "mlff_user",
) -> Dict[str, Any]:

    success_logger.info(f"[{session_id}] Orchestrator started | query={user_query[:80]}")

    try:
        import uuid
        query_id = uuid.uuid4().hex[:8]

        final_text = await _run_with_bridge(
            session_service=_session_service,
            user_id=user_id,
            session_id=session_id,
            initial_message=user_query,
            query_id=query_id,
        )

        success_logger.info(f"[{session_id}] Orchestrator response: {final_text[:200]}")

        clean = final_text.strip()
        if not clean:
            raise ValueError("Empty response from orchestrator")

        # FIXED: Better markdown extraction
        if "```" in clean:
            parts = clean.split("```")
            for part in parts:
                s = part.strip()
                # Handle "```json" prefix
                if s.lower().startswith("json"):
                    s = s[4:].strip()
                if s.startswith("{"):
                    clean = s
                    break
            else:
                # If no part starts with {, try the second part (most common)
                if len(parts) >= 2:
                    s = parts[1].strip()
                    if s.lower().startswith("json"):
                        s = s[4:].strip()
                    if s.startswith("{"):
                        clean = s

        payload = json.loads(clean)
        payload["ok"] = True
        payload["user_query"] = user_query
        payload["request_id"] = session_id

        return payload

    except Exception as e:
        error_logger.error(f"[{session_id}] Orchestrator failed: {e}")
        return await _orchestrator_fallback(user_query, session_id)

async def _orchestrator_fallback(user_query: str, session_id: str) -> Dict[str, Any]:
    logger.warning(f"[{session_id}] Using orchestrator fallback (no full schema scan)")
    try:
        intent_result = run_intent_detection(user_query)
        intent_data = intent_result   # it's already a dict

        # ── Support ──────────────────────────────────────────────
        if intent_data.get("intent") == "support":
            return {
                "ok": True,
                "request_id": session_id,
                "user_query": user_query,
                "intent": intent_data["intent"],
                "query_type": intent_data["query_type"],
                "confidence": intent_data["confidence"],
                "confidence_note": intent_data.get("confidence_note", ""),
                "low_confidence": intent_data["confidence"] < 0.60,
                "selected_schema": "",
                "selected_tables": [],
                "relevant_columns": {},
                "relationships_hint": [],
                "context_summary": "",
                "schema_details": {},
                "routing_to": "support",
            }

        # ── Dispute ──────────────────────────────────────────────
        # ── Force dispute for transaction/dispute keywords ──────────
        query_lower = user_query.lower()
        if any(kw in query_lower for kw in ["transaction", "transactions", "dispute", "disputes", "chargeback", "chargebacks", "toll", "plaza", "fastag"]):
            return {
                "ok": True,
                "request_id": session_id,
                "user_query": user_query,
                "intent": intent_data["intent"],
                "query_type": intent_data["query_type"],
                "confidence": intent_data["confidence"],
                "confidence_note": intent_data.get("confidence_note", ""),
                "low_confidence": intent_data["confidence"] < 0.60,
                "selected_schema": "",
                "selected_tables": [],
                "relevant_columns": {},
                "relationships_hint": [],
                "context_summary": "",
                "schema_details": {},
                "routing_to": "dispute",
            }

        # ── Skill match (support) ──────────────────────────────
        skill, skill_score = match_skill(user_query)
        if skill and skill_score >= SKILL_MATCH_THRESHOLD:
            return {
                "ok": True,
                "request_id": session_id,
                "user_query": user_query,
                "intent": intent_data["intent"],
                "query_type": intent_data["query_type"],
                "confidence": intent_data["confidence"],
                "confidence_note": intent_data.get("confidence_note", ""),
                "low_confidence": intent_data["confidence"] < 0.60,
                "selected_schema": "",
                "selected_tables": [],
                "relevant_columns": {},
                "relationships_hint": [],
                "context_summary": "",
                "schema_details": {},
                "routing_to": "support",
            }

        # ── Default: MLFF ──────────────────────────────────────
        from agents.mlff.agent import _MLFF_CACHE
        return {
            "ok": True,
            "request_id": session_id,
            "user_query": user_query,
            "intent": intent_data["intent"],
            "query_type": intent_data["query_type"],
            "confidence": intent_data["confidence"],
            "confidence_note": intent_data.get("confidence_note", ""),
            "low_confidence": intent_data["confidence"] < 0.60,
            "selected_schema": _MLFF_CACHE["selected_schema"],
            "selected_tables": _MLFF_CACHE["selected_tables"],
            "relevant_columns": {},
            "relationships_hint": _MLFF_CACHE["relationships_hint"],
            "context_summary": "",
            "schema_details": _MLFF_CACHE["schema_details"],
            "routing_to": "mlff",
        }
    except Exception as e:
        return {
            "ok": False,
            "request_id": session_id,
            "user_query": user_query,
            "error": str(e),
            "confidence": 0.0,
        }