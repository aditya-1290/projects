import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    # App
    APP_HOST: str = os.getenv("APP_HOST", "127.0.0.1")
    APP_PORT: int = int(os.getenv("APP_PORT", "8000"))

    # PostgreSQL
    POSTGRES_HOST: str = os.getenv("POSTGRES_HOST", "127.0.0.1")
    POSTGRES_PORT: int = int(os.getenv("POSTGRES_PORT", "5432"))
    POSTGRES_USER: str = os.getenv("POSTGRES_USER", "postgres")
    POSTGRES_PASSWORD: str = os.getenv("POSTGRES_PASSWORD", "root")
    POSTGRES_DATABASE: str = os.getenv("POSTGRES_DATABASE", "enterprisehub")


    # ── MLFF Agent specific tables ─────────────────────────────────────
    # These tables must belong to MLFF_SCHEMA (set below)
    MLFF_SCHEMA = os.getenv("MLFF_SCHEMA", "security")  # or whatever your main schema is
    MLFF_TABLES = os.getenv("MLFF_TABLES", "user_roles, user_accounts").split(",")
    MLFF_TABLES = [t.strip() for t in MLFF_TABLES if t.strip()]

    # ── Dispute Agent ──────────────────────────────────────────────────
    DISPUTE_TABLES_RAW = os.getenv("DISPUTE_TABLES", "toll.transactions,toll.disputes,toll.vehicles")
    DISPUTE_TABLES = [t.strip() for t in DISPUTE_TABLES_RAW.split(",") if t.strip()]

    # ── External Log Analysis Service (mock for now) ───────────────────
    LOG_SERVICE_ENABLED = os.getenv("LOG_SERVICE_ENABLED", "true").lower() == "true"
    LOG_SERVICE_URL = os.getenv("LOG_SERVICE_URL", "http://localhost:9002/analyze")
    LOG_SERVICE_API_KEY = os.getenv("LOG_SERVICE_API_KEY", "mock-key")
    LOG_SERVICE_TIMEOUT = float(os.getenv("LOG_SERVICE_TIMEOUT", "5.0"))

    # ── Agent enablement ───────────────────────────────────────────────
    ENABLED_AGENTS_RAW = os.getenv("ENABLED_AGENTS", "mlff,support,dispute")
    ENABLED_AGENTS = [a.strip() for a in ENABLED_AGENTS_RAW.split(",") if a.strip()]

    # MCP
    MCP_BASE_URL: str = os.getenv("MCP_BASE_URL", "http://127.0.0.1:9000")
    MCP_API_KEY: str = os.getenv("MCP_API_KEY", "local-mcp-key")

    # LLM
    LOCAL_LLM_BASE_URL: str = os.getenv("LOCAL_LLM_BASE_URL", "http://127.0.0.1:8083/v1")
    LOCAL_LLM_MODEL: str = os.getenv("LOCAL_LLM_MODEL", "local-model")
    LOCAL_LLM_API_KEY: str = os.getenv("LOCAL_LLM_API_KEY", "sk-local")
    USE_LOCAL_LLM: bool = os.getenv("USE_LOCAL_LLM", "true").lower() == "true"

    # Logging
    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")

    @property
    def postgres_dsn(self) -> str:
        return (
            f"postgresql://{self.POSTGRES_USER}:{self.POSTGRES_PASSWORD}"
            f"@{self.POSTGRES_HOST}:{self.POSTGRES_PORT}/{self.POSTGRES_DATABASE}"
        )


config = Config()
