# core/logging_config.py
"""
Clean terminal output — human-readable, color-coded, noise-free.
Files still get full JSON logs. Terminal gets only what matters.
"""
import logging
import os
import sys
import structlog
from core.config import settings

# ── ANSI colors ───────────────────────────────────────────────────────────
RESET  = "\033[0m"
BOLD   = "\033[1m"
DIM    = "\033[2m"
CYAN   = "\033[36m"
GREEN  = "\033[32m"
YELLOW = "\033[33m"
RED    = "\033[31m"
BLUE   = "\033[34m"
MAGENTA= "\033[35m"
WHITE  = "\033[37m"

# ── Events to show on terminal + how to format them ──────────────────────
_EVENT_FORMATS = {
    # Startup
    "server_startup":            (GREEN,   "🚀 Server starting up"),
    "agent_registry_initialized":(GREEN,   "📋 Agent registry initialized"),
    "manager_agent_built":       (GREEN,   "🧠 Manager agent ready  sub_agents={sub_agents}"),
    "adk_runner_ready":          (GREEN,   "✅ System ready — listening on :8000"),
    "server_shutdown":           (YELLOW,  "🛑 Server shutting down"),

    # Agent init
    "registry_creating_agent":   (CYAN,    "   ├─ Creating agent: {agent} ({schema})"),
    "agent_created":             (CYAN,    "   └─ Agent ready: {agent}"),

    # Query lifecycle
    "query_received":            (BOLD+BLUE, "━━━ Query [{query_id}]  \"{user_query}\""),
    "transfer_detected":         (MAGENTA,   "   ├─ Routed → {target_agent}"),
    "schema_agent_starting":     (CYAN,      "   ├─ Schema agent starting: {agent}"),
    "schema_agent_response":     (DIM,       "   ├─ LLM responded"),
    "sql_extracted":             (WHITE,     "   ├─ SQL: {sql_preview}"),
    "rows_collected":            (GREEN,     "   ├─ Rows returned: {row_count}"),
    "chart_generated":           (GREEN,     "   ├─ Chart generated"),
    "schema_agent_done":         (GREEN,     "   ├─ Agent done  rows={rows}  chart={has_chart}"),
    "query_completed":           (BOLD+GREEN,"   └─ Done [{query_id}]  agent={agent_used}  rows={rows}  {duration_ms}"),

    # MCP calls
    "mcp_http_call":             (DIM,    "   │  MCP → {tool}"),
    "mcp_init_status":           (DIM,    "   │  MCP init {status}"),
    "mcp_session_acquired":      (DIM,    "   │  MCP session acquired"),
    "mcp_http_result":           (DIM,    "   │  MCP ← {tool}  {preview}"),
    "mcp_http_call_failed":      (RED,    "   │  MCP ✗ {tool}  {error}"),

    # MCP server side
    "tool_called":               (CYAN,   "   ⚙  Tool called: {tool}"),
    "tool_done":                 (CYAN,   "   ✓  Tool done:   {tool}"),
    "sse_server_starting":       (GREEN,  "🔌 MCP SSE  starting on :{port}"),
    "http_server_starting":      (GREEN,  "🔌 MCP HTTP starting on :{port}"),

    # Errors / warnings
    "sql_validation_failed":     (YELLOW, "   ⚠  SQL invalid: {error}"),
    "no_sql_extracted":          (YELLOW, "   ⚠  No SQL extracted from agent response"),
    "schema_agent_not_found":    (RED,    "   ✗  Agent not found: {agent}"),
    "manager_run_failed":        (RED,    "   ✗  Manager failed: {error}"),
    "agent_run_failed":          (RED,    "   ✗  Agent run failed: {error}"),
}

# ── Noisy loggers to silence on terminal ─────────────────────────────────
_SILENCE = [
    "litellm",
    "litellm.utils",
    "litellm.cost_calculator",
    "litellm.litellm_logging",
    "litellm.litellm_core_utils",
    "LiteLLM",
    "httpx",
    "httpcore",
    "openai",
    "google.adk.features",
    "google.auth",
    "urllib3",
    "asyncio",
]


class _CleanConsoleHandler(logging.Handler):
    """
    Reads structlog JSON records and prints only known events
    in a clean human-readable format.
    Unknown events and noisy loggers are silently dropped.
    """

    def emit(self, record: logging.LogRecord):
        # Drop noisy loggers
        if any(record.name.startswith(s) for s in _SILENCE):
            return

        # structlog emits the rendered string as record.msg
        msg = record.getMessage()

        # Try to parse as structlog JSON
        import json as _json
        try:
            data = _json.loads(msg)
        except Exception:
            # Not our structlog JSON — drop it
            return

        event = data.get("event", "")
        fmt_entry = _EVENT_FORMATS.get(event)
        if not fmt_entry:
            return  # unknown event — don't print

        color, template = fmt_entry

        # Fill template with available keys, leave missing as ""
        try:
            # Format duration nicely if present
            if "duration_ms" in data:
                ms = data["duration_ms"]
                if ms < 1000:
                    data["duration_ms"] = f"{ms}ms"
                else:
                    total_s = ms // 1000
                    m, s = divmod(total_s, 60)
                    data["duration_ms"] = f"{m}m {s}s" if m else f"{s}s"

            text = template.format_map(_SafeDict(data))
        except Exception:
            text = template

        print(f"{color}{text}{RESET}", flush=True)


class _SafeDict(dict):
    """Returns '' for missing keys so .format_map never raises."""
    def __missing__(self, key):
        return ""


def setup_logging():
    os.makedirs(settings.log_dir, exist_ok=True)
    level = getattr(logging, settings.log_level.upper(), logging.INFO)

    # ── File handlers (full JSON, unchanged) ─────────────────────────────
    fmt = logging.Formatter("%(message)s")

    def file_handler(name: str, min_level: int = logging.DEBUG):
        h = logging.FileHandler(os.path.join(settings.log_dir, name))
        h.setLevel(min_level)
        h.setFormatter(fmt)
        return h

    root = logging.getLogger()
    root.setLevel(logging.DEBUG)
    root.addHandler(file_handler("app.log"))
    root.addHandler(file_handler("errors.log", logging.ERROR))

    agent_logger = logging.getLogger("agent")
    agent_logger.addHandler(file_handler("agents.log"))
    agent_logger.propagate = True

    # ── Silence noisy third-party loggers ─────────────────────────────────
    for name in _SILENCE:
        logging.getLogger(name).setLevel(logging.CRITICAL)

    # Suppress pydantic and ADK warnings
    import warnings
    warnings.filterwarnings("ignore", category=UserWarning, module="pydantic")
    warnings.filterwarnings("ignore", category=UserWarning, module="google.adk")

    # ── Clean console handler ─────────────────────────────────────────────
    console = _CleanConsoleHandler()
    console.setLevel(logging.DEBUG)
    root.addHandler(console)

    # ── structlog config ──────────────────────────────────────────────────
    structlog.configure(
        processors=[
            structlog.stdlib.add_log_level,
            structlog.stdlib.add_logger_name,
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.JSONRenderer(),
        ],
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )


def get_logger(name: str = "app"):
    return structlog.get_logger(name)