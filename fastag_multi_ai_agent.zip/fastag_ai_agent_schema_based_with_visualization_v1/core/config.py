# core/config.py
import os
from typing import List
from dotenv import load_dotenv
from pydantic_settings import BaseSettings

# FORCE load .env from project root
load_dotenv()



class AgentConfig:
    """Holds one AGENT_N_* block parsed from .env."""

    def __init__(self, name: str, schema: str, tables: List[str]):
        self.name = name        # e.g. "hr_agent"
        self.schema = schema    # e.g. "humanresources"
        self.tables = tables    # e.g. ["employee", "department"]


class Settings(BaseSettings):
    # LLM
    llama_server_url: str = "http://127.0.0.1:8000/v1"
    llama_model_path: str = "./models/gemma.gguf"
    llama_n_ctx: int = 2048
    llama_n_threads: int = 4
    # llama_n_gpu_layers: int = 0

    # DB
    db_host: str = "localhost"
    db_port: int = 5432
    db_name: str = "postgres"
    db_user: str = "postgres"
    db_password: str = ""

    # MCP SSE transport
    mcp_server_port: int = 8001
    mcp_server_url: str = "http://127.0.0.1:8001"    #SSE transport
 
     #MCP - Streamble HTTP transport 
    mcp_http_port: int = 8002
    mcp_http_url: str = "http://127.0.0.1:8002"     # Streamable-HTTP transport

    # FastAPI
    api_port: int = 8003

    # Logging
    log_dir: str = "./logs"
    log_level: str = "INFO"

    class Config:
        env_file = ".env"
        case_sensitive = False
        extra = "allow"         # allows AGENT_N_* keys to pass through

    def get_agent_configs(self) -> List[AgentConfig]:
        """
        Reads AGENT_1_NAME/SCHEMA/TABLES dynamically from .env
        """
        configs: List[AgentConfig] = []

        i = 1

        while True:
            name = os.getenv(f"AGENT_{i}_NAME")
            schema = os.getenv(f"AGENT_{i}_SCHEMA")
            tables = os.getenv(f"AGENT_{i}_TABLES")


            if not name:
                break

            configs.append(
                AgentConfig(
                    name=name,
                    schema=schema,
                    tables=[t.strip() for t in tables.split(",") if t.strip()],
                )
            )

            i += 1
        print(f"[CONFIG] Loaded {len(configs)} agents")

        return configs


settings = Settings()
