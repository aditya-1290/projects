# api/routes/query.py
import time
import uuid
import json
import re
from datetime import datetime, timezone
from typing import Optional

import httpx
from fastapi import APIRouter
from pydantic import BaseModel
from core.logging_config import get_logger
from core.session_store import append_query, create_session
from core.config import settings

logger = get_logger("app")
router = APIRouter()

_runner = None
_manager_agent = None


def set_runner(runner, manager_agent):
    global _runner, _manager_agent
    _runner = runner
    _manager_agent = manager_agent


class QueryRequest(BaseModel):
    user_query: str
    session_id: Optional[str] = None


class QueryResponse(BaseModel):
    session_id: str
    query_id: str
    user_query: str
    agent_used: str
    schema_used: str
    sql_generated: str
    rows: list
    row_count: int
    summary: str
    chart_html: Optional[str]
    duration_ms: int


# ── MCP HTTP JSON-RPC caller ───────────────────────────────────────────────
async def _call_mcp_tool(tool_name: str, args: dict) -> str:
    """
    Call a tool on the MCP streamable-HTTP server.
    MCP protocol requires:
      1. POST initialize  → get mcp-session-id
      2. POST tools/call  → with mcp-session-id header
    """
    url = f"{settings.mcp_http_url}/mcp"
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/event-stream",
    }

    logger.info("mcp_http_call", tool=tool_name, args_preview=str(args)[:100])

    try:
        async with httpx.AsyncClient(timeout=30.0) as client:

            # ── Step 1: MCP initialize (required before any tool call) ────
            init_resp = await client.post(
                url,
                json={
                    "jsonrpc": "2.0",
                    "method": "initialize",
                    "params": {
                        "protocolVersion": "2024-11-05",
                        "capabilities": {},
                        "clientInfo": {
                            "name": "text-to-sql-client",
                            "version": "1.0.0",
                        },
                    },
                    "id": 1,
                },
                headers=headers,
            )
            logger.info("mcp_init_status", status=init_resp.status_code)

            # Grab session ID if server returns one
            session_id = init_resp.headers.get("mcp-session-id")
            if session_id:
                headers["mcp-session-id"] = session_id
                logger.info("mcp_session_acquired", session_id=session_id[:16])

            # ── Step 2: tools/call ────────────────────────────────────────
            tool_resp = await client.post(
                url,
                json={
                    "jsonrpc": "2.0",
                    "method": "tools/call",
                    "params": {"name": tool_name, "arguments": args},
                    "id": 2,
                },
                headers=headers,
            )
            tool_resp.raise_for_status()

            # Response may be JSON or SSE — handle both
            content_type = tool_resp.headers.get("content-type", "")
            if "text/event-stream" in content_type:
                # SSE response: parse data: lines
                result_text = ""
                async for line in tool_resp.aiter_lines():
                    if line.startswith("data:"):
                        data_str = line[5:].strip()
                        if data_str and data_str != "[DONE]":
                            try:
                                chunk = json.loads(data_str)
                                content = (
                                    chunk.get("result", {})
                                    .get("content", [])
                                )
                                if content and content[0].get("type") == "text":
                                    result_text = content[0]["text"]
                            except Exception:
                                pass
                logger.info("mcp_http_result", tool=tool_name, preview=result_text[:120])
                return result_text

            else:
                # Plain JSON response
                data = tool_resp.json()
                content = data.get("result", {}).get("content", [])
                result = (
                    content[0]["text"]
                    if content and content[0].get("type") == "text"
                    else json.dumps(data.get("result", {}))
                )
                logger.info("mcp_http_result", tool=tool_name, preview=result[:120])
                return result

    except Exception as e:
        logger.error("mcp_http_call_failed", tool=tool_name, error=str(e))
        return json.dumps({"error": str(e)})


async def _generate_summary(
    user_query: str,
    rows: list,
    agent_name: str,
    sql: str,
) -> str:
    """
    Call LLM to generate a meaningful natural language summary
    of the query results instead of a hardcoded string.
    """
    if not rows:
        return "The query executed successfully but returned no results."

    # Build a compact data snapshot for the LLM
    cols = list(rows[0].keys())
    schema_name = agent_name.replace("_agent", "")

    # Show max 5 rows to keep prompt short
    sample = rows[:5]
    rows_text = "\n".join(
        ", ".join(f"{k}: {v}" for k, v in row.items())
        for row in sample
    )
    remaining = len(rows) - len(sample)
    if remaining > 0:
        rows_text += f"\n... and {remaining} more row(s)"

    prompt = f"""You are a data analyst. A user asked: "{user_query}"

The SQL query ran against the {schema_name} database and returned {len(rows)} row(s).

Data returned:
{rows_text}

Write 2-3 sentences summarizing what the data shows. Be specific — mention actual values, 
highest/lowest if relevant, patterns, or key takeaways. Do not say "the query returned" 
or mention technical details. Write as if explaining results to a business user."""

    try:
        async with httpx.AsyncClient(timeout=60.0) as client:
            resp = await client.post(
                f"{settings.llama_server_url}/chat/completions",
                json={
                    "model": "gemma-local",
                    "messages": [{"role": "user", "content": prompt}],
                    "max_tokens": 150,
                    "temperature": 0.3,
                },
                headers={"Authorization": "Bearer not-needed"},
            )
            resp.raise_for_status()
            data = resp.json()
            summary = data["choices"][0]["message"]["content"].strip()

            # Clean up any Gemma special tokens
            summary = re.sub(r'<\|.*?\|>', '', summary).strip()
            return summary

    except Exception as e:
        logger.warning("summary_generation_failed", error=str(e))
        # Fallback to basic summary if LLM call fails
        top = rows[0]
        highlights = ", ".join(f"{k}: {v}" for k, v in list(top.items())[:3])
        return (
            f"Retrieved {len(rows)} record(s) from the {schema_name} schema. "
            f"Top result — {highlights}."
        )
    
# ── Gemma text parsers ─────────────────────────────────────────────────────

def _clean_gemma_quotes(text: str) -> str:
    """Gemma 4 uses <|"|>value<|"|> instead of "value"."""
    text = re.sub(r'<\|"\|>(.*?)<\|"\|>', r'"\1"', text, flags=re.DOTALL)
    text = re.sub(r'<\|" \|>(.*?)<\|" \|>', r'"\1"', text, flags=re.DOTALL)
    return text

def _parse_transfer(text: str) -> Optional[str]:
    """Extract agent name from Gemma transfer_to_agent text output."""

    cleaned = _clean_gemma_quotes(text)

    match = re.search(
        r'transfer_to_agent\s*[\({]\s*agent_name\s*[=:]\s*["\']?(\w+)["\']?',
        cleaned,
        flags=re.IGNORECASE,
    )

    if match:
        return match.group(1)

    match = re.search(
        r'TRANSFER::\s*(\w+)',
        cleaned,
        flags=re.IGNORECASE,
    )

    if match:
        return match.group(1)

    return None


_ALL_TOOLS = [
    "validate_sql_tool",
    "execute_sql_tool",
    "generate_visualization_tool",
    "get_schema_metadata_tool",
    "get_table_sample_tool",
]


def _parse_tool_call(text: str) -> Optional[dict]:
    """Extract tool name + args from Gemma text tool call output."""
    cleaned = _clean_gemma_quotes(text)

    # Pattern: call:TOOLNAME{key:"value", ...}
    match = re.search(r'call:(\w+)\s*\{([^}]*(?:\{[^}]*\}[^}]*)*)\}', cleaned, re.DOTALL)
    if match and match.group(1) in _ALL_TOOLS:
        return {"tool_name": match.group(1), "args": _extract_args(match.group(2))}

    # Pattern: TOOLNAME(key="value")
    for tool in _ALL_TOOLS:
        match = re.search(rf'{tool}\s*\(([^)]*)\)', cleaned, re.DOTALL)
        if match:
            return {"tool_name": tool, "args": _extract_args(match.group(1))}

    # Pattern: call:TOOLNAME followed by JSON blob
    match = re.search(r'call:(\w+)\s*(\{.*\})', cleaned, re.DOTALL)
    if match and match.group(1) in _ALL_TOOLS:
        try:
            return {"tool_name": match.group(1), "args": json.loads(match.group(2))}
        except Exception:
            pass

    return None


def _extract_args(args_text: str) -> dict:
    args = {}
    try:
        parsed = json.loads("{" + args_text + "}")
        if isinstance(parsed, dict):
            return parsed
    except Exception:
        pass
    for m in re.finditer(r'(\w+)\s*:\s*"((?:[^"\\]|\\.)*)"', args_text, re.DOTALL):
        args[m.group(1)] = m.group(2).replace('\\"', '"')
    for m in re.finditer(r'(\w+)\s*=\s*["\']([^"\']*)["\']', args_text, re.DOTALL):
        if m.group(1) not in args:
            args[m.group(1)] = m.group(2)
    return args

def _extract_sql(text: str) -> str:
    cleaned = _clean_gemma_quotes(text)

    # Remove Gemma special tokens
    cleaned = re.sub(
        r"<\|.*?\|>",
        "",
        cleaned,
        flags=re.DOTALL,
    )

    # =========================================================
    # 1. Try extracting SQL from tool-call args
    # =========================================================
    match = re.search(
        r'(?:"sql"|sql)\s*:\s*"((?:[^"\\]|\\.)+)"',
        cleaned,
        re.DOTALL,
    )

    if match:
        sql = match.group(1)

        # Unescape chars
        sql = sql.replace("\\n", "\n")
        sql = sql.replace('\\"', '"')
        sql = sql.replace("\\t", " ")

        return _normalize_sql(sql)

    # =========================================================
    # 2. Extract complete SQL ending with semicolon
    # =========================================================
    match = re.search(
        r'((SELECT|WITH)\s+.*?;)',
        cleaned,
        re.IGNORECASE | re.DOTALL,
    )

    if match:
        return _normalize_sql(match.group(1))

    # =========================================================
    # 3. Fallback for SQL without semicolon
    # =========================================================
    match = re.search(
        r'((SELECT|WITH)\s+.*)',
        cleaned,
        re.IGNORECASE | re.DOTALL,
    )

    if match:
        sql = match.group(1)

        # Stop at junk markers
        sql = re.split(r'[}"<|]', sql)[0]

        return _normalize_sql(sql)

    return ""


def _normalize_sql(sql: str) -> str:
    """
    Cleanup SQL and safely inject LIMIT.
    """

    sql = sql.strip()

    # Remove trailing garbage
    sql = re.sub(r'[}"\]]+$', '', sql)

    # Remove ending semicolon temporarily
    sql = sql.rstrip(";").strip()

    blocked = ["DROP ", "DELETE ", "TRUNCATE ", "ALTER ", "UPDATE ", "INSERT "]

    upper_sql = sql.upper()

    if any(cmd in upper_sql for cmd in blocked):
        raise ValueError("Only read-only SELECT queries are allowed.")

    # Add LIMIT safely
    if (
        sql.upper().startswith("SELECT")
        and "LIMIT" not in sql.upper()
    ):
        sql += " LIMIT 10"

    # Final semicolon
    return sql + ";"

#============================================================
def _is_transfer_message(text: str) -> bool:
    """
    Detect raw ADK transfer messages generated by Gemma.
    """

    cleaned = _clean_gemma_quotes(text)

    return bool(
        re.search(
            r"transfer_to_agent",
            cleaned,
            flags=re.IGNORECASE,
        )
    )
# ── Manager runner ─────────────────────────────────────────────────────────

async def _run_agent_and_collect(user_message, session_id: str) -> dict:
    collected = {
        "agent_used": "unknown",
        "schema_used": "unknown",
        "sql_generated": "",
        "rows": [],
        "row_count": 0,
        "summary": "",
        "chart_html": None,
        "all_texts": [],
    }

    # =========================================================
    # IMPORTANT:
    # Never reuse ADK session memory.
    # Gemma transfer_to_agent messages break on next request.
    # =========================================================
    temp_session_id = f"temp_{uuid.uuid4().hex[:8]}"

    try:
        await _runner.session_service.create_session(
            app_name="text_to_sql",
            user_id="default_user",
            session_id=temp_session_id,
        )
    except Exception:
        pass

    try:

        async for event in _runner.run_async(
            user_id="default_user",
            session_id=temp_session_id,
            new_message=user_message,
        ):

            author = getattr(event, "author", "unknown")
            is_final = getattr(event, "is_final_response", lambda: False)()

            if not (hasattr(event, "content") and event.content):
                continue

            for part in event.content.parts:

                text = getattr(part, "text", "") or ""

                if not text:
                    continue

                # =====================================================
                # CRITICAL FIX
                # Skip raw transfer messages from being stored
                # =====================================================
                if _is_transfer_message(text):

                    logger.info(
                        "transfer_message_skipped",
                        preview=text[:120],
                    )

                    agent_name = _parse_transfer(text)

                    if agent_name:
                        collected["agent_used"] = agent_name
                        collected["schema_used"] = agent_name.replace(
                            "_agent",
                            "",
                        )

                    continue

                collected["all_texts"].append(text)

                logger.info(
                    "manager_event",
                    author=author,
                    is_final=is_final,
                    preview=text[:150],
                )

                # ── Detect transfer from manager ─────────────────────
                agent_name = _parse_transfer(text)

                if agent_name:

                    logger.info(
                        "transfer_detected",
                        target_agent=agent_name,
                    )

                    collected["agent_used"] = agent_name

                    collected["schema_used"] = agent_name.replace(
                        "_agent",
                        "",
                    )

    except Exception as e:

        logger.error(
            "manager_run_failed",
            error=str(e),
        )

        collected["summary"] = f"Manager error: {e}"

        return collected

    # =========================================================
    # Run routed schema agent
    # =========================================================
    if collected["agent_used"] not in ("unknown", "manager_agent"):

        await _run_schema_agent(
            collected["agent_used"],
            user_message,
            session_id,
            collected,
        )

    else:

        # Manager direct response fallback
        for t in reversed(collected["all_texts"]):

            if len(t.strip()) > 20 and not _parse_transfer(t):

                collected["summary"] = t.strip()

                break

    if not collected["summary"]:
        collected["summary"] = "Query completed."

    return collected


# ── Schema agent runner — calls MCP via HTTP JSON-RPC ─────────────────────

async def _run_schema_agent(
    agent_name: str, user_message, session_id: str, collected: dict
):
    """
    Run the schema agent and handle Gemma text tool calls by forwarding
    each one to the MCP HTTP server via JSON-RPC.
    Real MCP calls — no Python function bypass.
    """
    from agents.agent_registry import get_agent
    from google.adk.runners import Runner
    from google.adk.sessions import InMemorySessionService

    target_agent = get_agent(agent_name)
    if not target_agent:
        collected["summary"] = f"Agent '{agent_name}' not found."
        logger.error("schema_agent_not_found", agent=agent_name)
        return

    logger.info("schema_agent_starting", agent=agent_name)

    temp_ss = InMemorySessionService()
    temp_runner = Runner(
        agent=target_agent,
        app_name="text_to_sql",
        session_service=temp_ss,
    )
    sub_session = f"sub_{uuid.uuid4().hex[:8]}"
    try:
        await temp_ss.create_session(
            app_name="text_to_sql",
            user_id="default_user",
            session_id=sub_session,
        )
    except Exception:
        pass

    # ── Step 1: get first LLM response (should contain SQL + tool call) ──
    first_text = ""
    async for event in temp_runner.run_async(
        user_id="default_user",
        session_id=sub_session,
        new_message=user_message,
    ):
        if hasattr(event, "content") and event.content:
            for part in event.content.parts:
                t = getattr(part, "text", "") or ""
                if t:
                    first_text = t
                    logger.info("schema_agent_response", preview=t[:200])

    # ── Step 2: extract SQL ───────────────────────────────────────────────
    sql = _extract_sql(first_text)
    if not sql:
        parsed = _parse_tool_call(first_text)
        if parsed:
            sql = parsed.get("args", {}).get("sql", "")

    if not sql:
        logger.warning("no_sql_extracted", agent=agent_name, text_preview=first_text[:200])
        collected["summary"] = first_text.strip() or "Could not generate SQL for this query."
        return

    logger.info("sql_extracted", sql_preview=sql[:120])
    collected["sql_generated"] = sql

    # ── Step 3: validate_sql_tool → MCP HTTP ─────────────────────────────
    validate_result = await _call_mcp_tool("validate_sql_tool", {"sql": sql})
    try:
        v = json.loads(validate_result)
        if not v.get("valid", True) and v.get("error"):
            logger.warning("sql_validation_failed", error=v["error"])
            collected["summary"] = f"SQL validation failed: {v['error']}"
            return
    except Exception:
        pass  # non-JSON validate response is fine

    # ── Step 4: execute_sql_tool → MCP HTTP ──────────────────────────────
    exec_result = await _call_mcp_tool("execute_sql_tool", {"sql": sql})
    try:
        data = json.loads(exec_result)
        if "rows" in data:
            collected["rows"] = data["rows"]
            collected["row_count"] = data.get("row_count", len(data["rows"]))
            logger.info("rows_collected", row_count=collected["row_count"])
    except Exception:
        pass

    # ── Step 5: generate_visualization_tool → MCP HTTP ───────────────────
    if collected["rows"]:
        user_query_text = user_message.parts[0].text if hasattr(user_message, "parts") else str(user_message)
        viz_result = await _call_mcp_tool(
            "generate_visualization_tool",
            {
                "rows_json": json.dumps(collected["rows"], default=str),
                "user_query": user_query_text,
            },
        )
        try:
            viz_data = json.loads(viz_result)
            if viz_data.get("chart_html"):
                collected["chart_html"] = viz_data["chart_html"]
                logger.info("chart_generated", agent=agent_name)
        except Exception:
            pass

    # ── Step 6: build summary — LLM generated ────────────────────────────
    collected["summary"] = await _generate_summary(
        user_query=user_message.parts[0].text if hasattr(user_message, "parts") else str(user_message),
        rows=collected["rows"],
        agent_name=agent_name,
        sql=sql,
    )

    logger.info(
        "schema_agent_done",
        agent=agent_name,
        rows=collected["row_count"],
        has_chart=bool(collected["chart_html"]),
    )


# ── API endpoint ───────────────────────────────────────────────────────────

@router.post("/query", response_model=QueryResponse)
async def handle_query(req: QueryRequest):
    from google.genai.types import Content, Part

    start_ms = time.time()
    session_id = req.session_id or create_session()
    query_id = f"q_{uuid.uuid4().hex[:8]}"

    logger.info(
        "query_received",
        session_id=session_id,
        query_id=query_id,
        user_query=req.user_query,
    )

    user_message = Content(role="user", parts=[Part(text=req.user_query)])
    collected = await _run_agent_and_collect(user_message, session_id)
    duration_ms = int((time.time() - start_ms) * 1000)

    response = QueryResponse(
        session_id=session_id,
        query_id=query_id,
        user_query=req.user_query,
        agent_used=collected["agent_used"],
        schema_used=collected["schema_used"],
        sql_generated=collected["sql_generated"],
        rows=collected["rows"],
        row_count=collected["row_count"],
        summary=collected["summary"],
        chart_html=collected["chart_html"],
        duration_ms=duration_ms,
    )

    append_query(session_id, {
        "id": query_id,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        **response.model_dump(),
    })

    logger.info(
        "query_completed",
        session_id=session_id,
        query_id=query_id,
        agent_used=collected["agent_used"],
        rows=collected["row_count"],
        duration_ms=duration_ms,
    )

    return response