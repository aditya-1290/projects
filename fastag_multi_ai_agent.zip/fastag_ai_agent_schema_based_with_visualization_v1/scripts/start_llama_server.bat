@echo off
REM ============================================================
REM  Start llama-cpp-python HTTP server (Windows CPU)
REM  Important logs shown on terminal — rest goes to logs\llama.log
REM ============================================================

SET MODEL_PATH=%LLAMA_MODEL_PATH%
IF "%MODEL_PATH%"=="" SET MODEL_PATH=D:\Models\gemma-4-E4B-it-Q5_K_M.gguf

SET PORT=8080
SET N_CTX=2048
SET N_THREADS=4
SET N_GPU_LAYERS=0

IF NOT EXIST "%MODEL_PATH%" (
    echo.
    echo [ERROR] Model not found at %MODEL_PATH%
    echo         Update LLAMA_MODEL_PATH in .env or edit this script.
    echo.
    pause
    exit /b 1
)

if not exist logs mkdir logs

echo.
echo  +--------------------------------------------------+
echo  ^|        LLM Server  --  llama-cpp-python          ^|
echo  +--------------------------------------------------+
echo  ^|  Model   : %MODEL_PATH%
echo  ^|  Port    : %PORT%
echo  ^|  Context : %N_CTX% tokens
echo  ^|  Threads : %N_THREADS%
echo  ^|  GPU     : %N_GPU_LAYERS% layers (0 = CPU only)
echo  ^|  Logs    : logs\llama.log
echo  +--------------------------------------------------+
echo.
echo  Starting...
echo  --------------------------------------------------
echo.

python -m llama_cpp.server ^
  --model "%MODEL_PATH%" ^
  --port %PORT% ^
  --n_ctx %N_CTX% ^
  --n_threads %N_THREADS% ^
  --n_gpu_layers %N_GPU_LAYERS% ^
  --host 127.0.0.1 ^
  2>> logs\llama.log | findstr /i "started waiting complete running POST GET ERROR WARNING"

echo.
echo  [INFO] Server stopped.
pause