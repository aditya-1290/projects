# FORGE — Programming Agent
## Complete Project Specification
**Version:** 1.1 — Pre-Implementation  
**Status:** Finalized for Development  
**Date:** May 2026

---

## Table of Contents

1. Project Overview
2. Core Operating Modes
3. Target Users
4. Agent Roster & Responsibilities
5. System Architecture
6. A2A Communication Protocol
7. Memory & Checkpoint System
8. Permission Gateway
9. CLI Design & UX
10. IDE Integration Strategy
11. Deployment & Distribution
12. LLM & Model Strategy
13. Tech Stack
14. Data Models
15. Phased Roadmap

---

## 1. Project Overview

Forge is a context-aware, autonomous programming agent that assists developers, teams, and non-technical founders in building, completing, and testing software projects. It operates iteratively, communicates in plain English, supports multiple programming languages, and runs across Linux, macOS, and Windows.

Forge is designed local-first but fully supports a shared team server mode for collaborative use. It ships as a CLI tool with IDE plugin support for VS Code and PyCharm, and as an installable package via an online installer or Docker.

### Core Principles

- **No assumptions** — Forge always asks before acting, never guesses at requirements
- **Permission-gated writes** — patching, deleting, and executing are always user-approved
- **Iterative by design** — work is done in steps with checkpoints, never in one uninterruptible sweep
- **Language-agnostic output** — Forge generates code in any language; it runs on Python internally
- **Context resilient** — when token limits are hit, Forge checkpoints and resumes seamlessly
- **Plain English first** — non-technical users are first-class citizens

---

## 2. Core Operating Modes

### Mode 1 — Build From Scratch
User describes a project in plain English or technical terms. Forge gathers requirements, sets a timeline, collects user stories if available, designs the architecture, and builds iteratively.

**Intake flow:**
1. Forge asks what the project does, who uses it, and what problem it solves
2. Forge asks for tech stack preference or recommends one
3. Forge asks for a deadline / timeline
4. Forge asks if user stories or requirements documents are available
5. Forge presents a project plan and waits for approval before writing a single line of code
6. On approval, Architect Agent designs the file/module structure
7. Coder Agent builds iteratively, checkpointing after each meaningful unit

### Mode 2 — Ingest & Complete Existing Project
User points Forge at an existing codebase. Forge scans, analyses, identifies what is incomplete, then asks targeted questions before filling gaps.

**Ingestion flow:**
1. Forge walks the file tree
2. Detects languages, frameworks, and dependency files (package.json, requirements.txt, pom.xml, .csproj, go.mod, etc.)
3. Reads README and any documentation
4. Builds an internal map of what exists vs what appears incomplete
5. Reports findings to user with specific observations
6. Asks what to focus on first — never assumes priority
7. Suggests enhancements based on project state (optional, user can dismiss)

### Mode 3 — Test Existing Project
User provides a completed project and requests tests. Forge analyses the codebase, asks about desired test depth, and writes a comprehensive test suite.

**Testing depth options (user chooses):**
1. Unit tests only
2. Unit + Integration tests
3. Full suite (Unit + Integration + E2E)
4. Let Forge decide based on project analysis
5. Custom — user specifies exact requirements

Forge also asks whether a coverage percentage target is desired (e.g. 80%, 90%, 100%).

---

## 3. Target Users

### Solo Developers
Technical users who want an autonomous coding partner. They communicate in technical terms, use CLI primarily, and expect Forge to move fast once requirements are clear.

### Development Teams
Multiple developers working on the same project. Each developer has their own separate conversation thread with Forge. All threads operate on the same project files. File-level locking prevents conflicts. All team members have equal permissions within their session.

### Non-Technical Founders / Product Owners
Users who describe projects in plain English without technical vocabulary. Forge's Intake Agent operates in "Product Manager mode" — asking about goals, users, and features — and the Architect Agent translates this into a technical spec internally. Founders never see the tech spec unless they ask.

---

## 4. Agent Roster & Responsibilities

All agents are built in Python using Google ADK. Each is a specialized sub-agent. The Orchestrator delegates tasks via the message broker.

### Orchestrator Agent
- Root agent, receives all user input
- Determines which mode the user is in (build / ingest / test)
- Delegates tasks to specialized agents via message broker
- Tracks overall task state and progress
- Reports back to user in CLI
- Manages checkpoint triggers
- Handles context burst recovery

### Intake Agent
- First agent to interact with the user in all modes
- Gathers requirements, timeline, user stories, tech stack preferences
- Switches between "technical mode" and "product manager mode" based on user type
- Never passes incomplete requirements downstream
- Presents project plan to user for approval before any code is written

### Architect Agent
- Receives approved requirements from Intake Agent
- Designs file/module/directory structure
- Selects or confirms tech stack
- Produces an architecture plan
- Plans the iterative build order (what gets built first, second, etc.)
- Presents plan to user for review

### Coder Agent
- Receives build tasks from Orchestrator one unit at a time
- Language-aware — detects and generates code in any required language
- Streams output to CLI (status view or code view, user toggles)
- Checkpoints after each meaningful unit is complete
- Never writes to files without permission
- In advisory mode: shows generated code and asks for patch permission
- In permitted mode: writes directly, logs all actions

### Tester Agent
- Analyses existing codebase to understand what needs testing
- Generates unit, integration, and E2E tests based on user-specified depth
- Runs tests via Terminal MCP and reports results
- Identifies gaps in coverage and reports them
- Suggests additional edge cases

### Patcher Agent
- Receives patch tasks from Orchestrator or user requests
- Always checks Permission Gateway before writing
- If no permission: shows diff in CLI, prompts user to allow or generate-only
- If permission granted: applies patch, logs action, creates checkpoint
- Handles delete operations with same permission check

### Reviewer / Suggester Agent
- Activated after code is written or when user asks for a review
- Reviews code quality, patterns, potential bugs
- Suggests enhancements based on current project state
- Never forces suggestions — always optional
- Can suggest architectural improvements as project grows

### Memory / Checkpoint Manager
- Not a conversational agent — a background service
- Monitors token usage across all active agents
- Triggers checkpoint saves before context window is exceeded
- Saves: work summary, files touched, next planned step, token count
- On restart: feeds compressed context back to the relevant agent
- Surfaces checkpoint status to user in CLI ("Refreshing context — continuing from checkpoint 7")

---

## 5. System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    SURFACES / INTERFACES                        │
│                                                                 │
│  ┌──────────────────┐    ┌───────────────┐   ┌──────────────┐  │
│  │   CLI (Primary)  │    │  VS Code Ext  │   │ PyCharm Plug │  │
│  │  Typer + Rich    │    │  (thin shell) │   │ (thin shell) │  │
│  └────────┬─────────┘    └───────┬───────┘   └──────┬───────┘  │
│           │                      │                  │          │
│           └──────────────────────┼──────────────────┘          │
│                                  │ LSP Protocol                 │
└──────────────────────────────────┼──────────────────────────────┘
                                   │
┌──────────────────────────────────▼──────────────────────────────┐
│                      LSP Server                                 │
│              (bridges IDE plugins to FastAPI)                   │
└──────────────────────────────────┬──────────────────────────────┘
                                   │ HTTP / WebSocket
┌──────────────────────────────────▼──────────────────────────────┐
│                       FastAPI Backend                           │
│                                                                 │
│  ┌──────────────┐  ┌─────────────────┐  ┌────────────────────┐ │
│  │ Session &    │  │  Permission     │  │  Project           │ │
│  │ Memory Mgr   │  │  Gateway        │  │  Ingestor          │ │
│  └──────────────┘  └─────────────────┘  └────────────────────┘ │
│                                                                 │
│  ┌──────────────┐  ┌─────────────────┐  ┌────────────────────┐ │
│  │ Streaming    │  │  File Lock      │  │  Deployment        │ │
│  │ Manager      │  │  Manager        │  │  Template Library  │ │
│  │ (SSE)        │  │  (team mode)    │  │                    │ │
│  └──────────────┘  └─────────────────┘  └────────────────────┘ │
└──────────────────────────────────┬──────────────────────────────┘
                                   │
┌──────────────────────────────────▼──────────────────────────────┐
│                    Google ADK Agent Layer                       │
│                                                                 │
│  ┌─────────────┐  ┌────────────┐  ┌─────────────┐             │
│  │ Orchestrator│  │  Intake    │  │  Architect  │             │
│  │ Agent       │  │  Agent     │  │  Agent      │             │
│  └─────────────┘  └────────────┘  └─────────────┘             │
│                                                                 │
│  ┌─────────────┐  ┌────────────┐  ┌─────────────┐             │
│  │  Coder      │  │  Tester    │  │  Patcher    │             │
│  │  Agent      │  │  Agent     │  │  Agent      │             │
│  └─────────────┘  └────────────┘  └─────────────┘             │
│                                                                 │
│  ┌─────────────┐  ┌──────────────────────────────────────────┐ │
│  │  Reviewer / │  │  Memory / Checkpoint Manager             │ │
│  │  Suggester  │  │  (background service)                    │ │
│  └─────────────┘  └──────────────────────────────────────────┘ │
└──────────────────────────────────┬──────────────────────────────┘
                                   │
┌──────────────────────────────────▼──────────────────────────────┐
│                    Message Broker (Redis Streams)               │
│                                                                 │
│  Queues per agent:                                              │
│  intake.tasks | architect.tasks | coder.tasks                  │
│  tester.tasks | patcher.tasks   | reviewer.tasks               │
│                                                                 │
│  Event bus:  agent.events  (broadcast, all agents subscribe)   │
│  Results:    orchestrator.results                               │
└──────────────────────────────────┬──────────────────────────────┘
                                   │
┌──────────────────────────────────▼──────────────────────────────┐
│                        MCP Server Layer                         │
│                                                                 │
│  ┌──────────────────┐  ┌──────────────────┐  ┌──────────────┐  │
│  │  Filesystem MCP  │  │  Terminal MCP    │  │  Git MCP     │  │
│  │                  │  │                  │  │              │  │
│  │  read, write,    │  │  Scoped to       │  │  commit,     │  │
│  │  patch, delete   │  │  project dir     │  │  diff,       │  │
│  │  (perm-gated)    │  │  only (chroot)   │  │  branch,     │  │
│  │                  │  │  run tests,      │  │  push, pull  │  │
│  │                  │  │  builds, linters │  │  (optional)  │  │
│  └──────────────────┘  └──────────────────┘  └──────────────┘  │
└──────────────────────────────────┬──────────────────────────────┘
                                   │
┌──────────────────────────────────▼──────────────────────────────┐
│                   Persistent Storage (Local)                    │
│                                                                 │
│  ┌──────────────────┐  ┌──────────────────┐  ┌──────────────┐  │
│  │  SQLite          │  │  ChromaDB        │  │  Session     │  │
│  │  (→ PostgreSQL   │  │  (local vector   │  │  Logs        │  │
│  │  in team mode)   │  │  store for code  │  │  audit trail │  │
│  │                  │  │  embeddings)     │  │              │  │
│  │  sessions        │  │                  │  │              │  │
│  │  checkpoints     │  │  Semantic code   │  │              │  │
│  │  permissions     │  │  search across   │  │              │  │
│  │  project meta    │  │  large codebases │  │              │  │
│  └──────────────────┘  └──────────────────┘  └──────────────┘  │
└─────────────────────────────────────────────────────────────────┘
```

### Deployment Modes

**Local Mode (default)**
Everything runs on the developer's machine. SQLite for storage, local Redis instance, local ChromaDB. No network dependency after install.

**Team Server Mode**
One shared instance runs on a central machine or cloud server. Developers connect their CLI and IDE plugins to the server URL. Storage upgrades to PostgreSQL. Redis handles distributed session locking for concurrent access. Each developer maintains their own conversation thread against the shared project.

---

## 6. A2A Communication Protocol

All agent-to-agent communication flows through Redis Streams via a standardized message envelope. This decouples agents completely — any agent can run on any machine in a scaled deployment.

### Message Envelope Schema

```json
{
  "message_id": "uuid-v4",
  "session_id": "project-session-uuid",
  "from_agent": "orchestrator",
  "to_agent": "coder",
  "task_type": "write_module",
  "priority": "normal",
  "payload": {
    "file_path": "src/auth/login.py",
    "instructions": "Write the login endpoint using JWT...",
    "context_summary": "Project is a FastAPI backend. Auth module. JWT chosen.",
    "checkpoint_id": "chk_0042"
  },
  "reply_to": "orchestrator.results",
  "timestamp": "2026-05-30T10:00:00Z",
  "ttl_seconds": 300
}
```

### Task Types

| task_type | From | To | Description |
|---|---|---|---|
| gather_requirements | orchestrator | intake | Start intake conversation |
| design_architecture | orchestrator | architect | Design file/module structure |
| write_module | orchestrator | coder | Write a specific file or module |
| write_tests | orchestrator | tester | Generate tests for a target |
| run_tests | orchestrator | tester | Execute tests, report results |
| apply_patch | orchestrator | patcher | Patch a file (permission required) |
| review_code | orchestrator | reviewer | Review and suggest improvements |
| checkpoint_save | any | memory_manager | Save current progress |
| checkpoint_load | orchestrator | memory_manager | Restore from checkpoint |
| ingest_project | orchestrator | intake | Scan and analyse existing project |

### File-Level Locking (Team Mode)

When multiple developers are active on the same project, Redis handles distributed file locks:

- Before any agent writes to a file, it acquires a Redis lock on that file path
- Lock TTL is 60 seconds, auto-renewed while the agent is actively writing
- If a file is locked, the requesting agent queues behind it
- User sees in CLI: "Waiting — teammate's session is writing to auth/login.py"
- On lock release, queued agent proceeds automatically

---

## 7. Memory & Checkpoint System

Session continuity is a first-class feature. Forge never loses progress.

### Database Schema (SQLite / PostgreSQL)

**sessions**
```
session_id          UUID primary key
project_path        TEXT
project_name        TEXT
mode                ENUM(scratch, ingest, test)
status              ENUM(active, paused, complete, error)
user_type           ENUM(developer, team, founder)
language_stack      JSON
git_enabled         BOOLEAN
test_depth          ENUM(unit, integration, full, custom, auto)
patch_permission    ENUM(none, ask_each_time, session_global)
created_at          TIMESTAMP
updated_at          TIMESTAMP
last_checkpoint_id  UUID FK
```

**checkpoints**
```
checkpoint_id           UUID primary key
session_id              UUID FK
step_number             INTEGER
agent_who_saved         TEXT
summary_of_work_done    TEXT (compressed context summary)
files_touched           JSON (list of file paths and operations)
next_planned_step       TEXT
token_count_at_save     INTEGER
created_at              TIMESTAMP
```

**permissions**
```
permission_id       UUID primary key
session_id          UUID FK
permission_type     ENUM(patch, delete, git_commit, terminal_exec)
scope               ENUM(global, file_specific)
file_path           TEXT nullable
granted_at          TIMESTAMP
expires_at          TIMESTAMP nullable
granted_by          TEXT
```

**project_files**
```
file_id             UUID primary key
session_id          UUID FK
file_path           TEXT
language            TEXT
last_read_at        TIMESTAMP
last_written_at     TIMESTAMP
chroma_embedded     BOOLEAN
```

### Context Burst Recovery Flow

```
1. Coder Agent token count approaches 80% of limit
          ↓
2. Checkpoint Manager triggers pre-emptive save:
   - Compress work summary into compact form
   - Save all file states written this session
   - Record "next_planned_step" explicitly
   - Write checkpoint record to DB
          ↓
3. Agent process restarts with injected context:
   "You are Forge Coder Agent continuing a session.
    Completed so far: [checkpoint summary]
    Files written: [list]
    Your next task: [next_planned_step]
    Continue from here without repeating completed work."
          ↓
4. CLI shows to user:
   "⟳ Context refreshed — continuing from checkpoint #7"
   (seamless, user sees no interruption)
```

### Session Resumption (Returning User)

When user opens Forge after closing it:
```
forge start

Forge → Welcome back. You have active sessions:
        
        ● FastAPI Backend          checkpoint #12 — writing payment module
          Last active: 2 hours ago
        
        ○ React App Tests           checkpoint #4 — unit tests complete
          Last active: yesterday
        
        ○ Mobile App                waiting for your input on nav design
          Last active: 3 days ago

        Which would you like to resume? (or start new)
```

### Multi-Session Background Execution (Option 3)

- One session is "active" — receives the user's conversation
- Other sessions marked "running" continue agent work autonomously in background
- User switches with `/switch [session-name]`
- Background sessions surface completed work and blockers via notifications in CLI
- Sessions marked "paused" are waiting for user input and do no background work

---

## 8. Permission Gateway

Every write, patch, delete, and terminal execution passes through the Permission Gateway in FastAPI before reaching the MCP servers.

### Permission Flow

```
Agent requests action (patch/delete/exec)
              ↓
Permission Gateway checks:
  1. What type of action is this?
  2. Does a global permission exist for this session?
  3. Does a file-specific permission exist?
  4. Is the action within the project directory scope?
              ↓
       ┌──────┴──────┐
       │             │
  PERMITTED      NOT PERMITTED
       │             │
   Log & proceed    Show diff/preview in CLI
                     │
                  Prompt user:
                  [P] Patch now
                  [G] Generate only (show me the code)
                  [A] Allow all patches this session
                  [S] Skip this change
                     │
              Record decision → proceed
```

### Terminal MCP Scope Enforcement

The Terminal MCP server enforces a hard boundary at the project root directory:

- All commands are prefixed with a chroot-equivalent check
- Any command attempting to navigate above the project root is rejected
- Commands that can access the network (curl, wget, etc.) require explicit user approval per invocation
- Build commands (npm build, pytest, mvn package) are pre-approved by default
- Destructive system commands (rm -rf, format, etc.) are blocked entirely outside the project dir

### Git Operations (Optional)

Git integration is opt-in per session. When enabled:

- Auto-commit after each iterative step with generated commit message
- User can review and edit commit message before commit
- Push to remote requires explicit user approval every time
- Branching strategy suggested by Architect Agent based on project type

---

## 9. CLI Design & UX

### Technology

- **Typer** — command and argument parsing
- **Rich** — terminal rendering (panels, progress bars, streaming text, tables)
- **Prompt Toolkit** — conversational input with history

### Primary Entry Points

```bash
forge                    # Start or resume (conversational mode)
forge start              # Explicitly start new session
forge resume             # List and resume existing sessions
forge sessions           # Show all active/paused sessions
forge switch <name>      # Switch active session
forge status             # Current session progress
forge checkpoint         # Force a checkpoint save
forge config             # Configuration settings
forge connect <url>      # Connect to team server
```

### Conversational Mode

Forge opens in a chat-loop. The user types naturally. Commands prefixed with `/` are available at any time without breaking conversation flow.

```
/help                    Show available commands
/switch <session>        Switch active session
/view code               Toggle to code streaming view
/view status             Toggle to status streaming view  
/sessions                Show all sessions
/checkpoint              Force save checkpoint
/permissions             Show current permission grants
/allow patch             Grant patch permission for this session
/allow patch <filepath>  Grant patch permission for specific file
/git on|off              Toggle git integration
/suggest                 Ask Reviewer Agent for enhancement suggestions
/deploy                  Start deployment configuration
/exit                    Exit (sessions continue in background)
```

### Streaming Output — Two Views

**Status View (default)**
```
╔══════════════════════════════════════════════════════════════╗
║  FORGE  ●  FastAPI Backend  ●  checkpoint #8  ●  Coder Agent ║
╚══════════════════════════════════════════════════════════════╝

 ✓ Designed project structure
 ✓ Written: src/main.py
 ✓ Written: src/config.py
 ✓ Written: src/models/user.py
 → Writing: src/auth/login.py
   Creating JWT token handler...
   Writing login endpoint...
   Adding password hashing...
 ○ Pending: src/auth/register.py
 ○ Pending: src/auth/middleware.py
```

**Code View (/view code)**
```
╔══════════════════════════════════════════════════════════════╗
║  FORGE  ●  FastAPI Backend  ●  Writing: src/auth/login.py   ║
╚══════════════════════════════════════════════════════════════╝

 from fastapi import APIRouter, Depends, HTTPException
 from fastapi.security import OAuth2PasswordRequestForm
 from ..models.user import User
 from ..services.auth import create_access_token
 import bcrypt

 router = APIRouter()

 @router.post("/login")
 async def login(
     form_data: OAuth2PasswordRequestForm = Depends()
 ):▌
```

### Patch Permission Prompt

```
╔══════════════════════════════════════════════════════════════╗
║  FORGE — Permission Required                                 ║
╚══════════════════════════════════════════════════════════════╝

 Forge wants to patch: src/auth/login.py

 ── DIFF ─────────────────────────────────────────────────────
 - async def login(form_data):
 + async def login(
 +     form_data: OAuth2PasswordRequestForm = Depends(),
 +     db: AsyncSession = Depends(get_db)
 + ):
 ─────────────────────────────────────────────────────────────

 [P] Patch now       [G] Generate only       
 [A] Allow all       [S] Skip

 Choice:
```

---

## 10. IDE Integration Strategy

### Architecture — LSP First

Forge runs a local Language Server Protocol (LSP) server. IDE plugins are thin clients that communicate with this LSP server. All intelligence lives in the LSP server — the plugins are UI shells only.

This means:
- One codebase for core agent logic
- VS Code and PyCharm plugins share the same backend
- Any other LSP-compatible editor (Vim, Emacs, Helix, Neovim) works with minimal effort
- Updates to agent logic deploy once, all IDEs benefit automatically

### LSP Server

- Runs as a background process alongside FastAPI
- Exposes standard LSP capabilities plus custom Forge commands
- Communicates with FastAPI backend over local socket

### VS Code Extension

- Sidebar panel: current session status, file tree with agent annotations
- Inline code streaming: watch Forge write in the editor buffer
- Patch approval popups: native VS Code notification with approve/reject
- Chat panel: conversational interface without leaving the IDE
- Status bar: active session name and current agent

### PyCharm Plugin

- Tool window panel: session status and conversation
- Editor annotations: files touched by Forge highlighted
- Patch diff viewer: native PyCharm diff tool for reviewing changes
- Action menu: right-click on file to ask Forge about it

### Distribution

- VS Code: distributed as `.vsix` file (installable locally), later via VS Code Marketplace
- PyCharm: distributed as `.zip` plugin (installable via Plugins > Install from disk), later via JetBrains Marketplace

---

## 11. Deployment & Distribution

### Agent Distribution (Installing Forge Itself)

**Path A — Online Installer**
A small shell/PowerShell script (~10MB) that:
1. Detects OS (Linux / macOS / Windows)
2. Checks for existing dependencies (Python 3.10+, Redis, Docker)
3. Downloads only what is missing
4. Installs Forge agent package
5. Configures Redis as a background service
6. Runs first-time setup wizard

Target install size: under 50MB download, under 200MB installed.

**Path B — Docker-based**
For developers who have Docker installed:
```bash
curl -sSL https://getforge.dev/install | sh
# or
docker compose up -d  # using the provided docker-compose.yml
```

Docker Compose spins up: FastAPI backend, Redis, ChromaDB, LSP server — all pre-configured, zero manual setup.

**Path C — Executable Installer (Internal Team)**
For teammates who are not developers:
- Windows: `.exe` installer built with PyInstaller + Inno Setup
- macOS: `.dmg` installer built with PyInstaller + create-dmg
- Linux: `.AppImage` portable executable

These bundle the Python runtime but use lazy loading for heavy components (ChromaDB, Redis) to keep the installer file under 100MB. Heavy deps are downloaded and installed on first run.

**Setup Wizard (all paths)**
On first launch:
```
Welcome to Forge!

Are you setting up for:
1. Just yourself (local mode)
2. Connecting to a team server (I'll enter the server URL)
3. Setting this up as a team server (others will connect to me)
```

### User's Project Deployment (Forge Helping Deploy)

**Built-in template library** for the following providers:
- AWS (ECS, EC2, Lambda, Elastic Beanstalk)
- Google Cloud Platform (Cloud Run, GKE, App Engine)
- Microsoft Azure (App Service, AKS, Container Instances)
- DigitalOcean (App Platform, Droplets)
- Railway
- Render
- Vercel (frontend / serverless)
- Fly.io
- Heroku

**On-demand generation:** User can ask for any provider not in the library and Forge generates deployment config from scratch.

**Deployment artifacts Forge produces:**
- `Dockerfile` and `.dockerignore`
- `docker-compose.yml` for local production simulation
- CI/CD pipeline config (GitHub Actions, GitLab CI, or Bitbucket Pipelines)
- Provider-specific config files (e.g. `fly.toml`, `render.yaml`, `railway.json`)
- Environment variable templates (`.env.example`)
- Infrastructure-as-code scripts when appropriate (Terraform for AWS/GCP/Azure)

---

## 12. LLM & Model Strategy

### Core Principle — Local Models Only

Forge uses exclusively local, self-hosted language models. No external API calls, no internet dependency for inference, no API key management. All model inference happens either on the developer's own machine or on organisation-hosted inference servers accessible over the internal network.

This means:
- Code never leaves the machine or org network
- No per-token billing or rate limits
- Works fully air-gapped
- Organisation retains full data sovereignty

### Two Deployment Contexts

**Personal / Development Context**
Used during Forge's own development and by individual developers running their own local instance.

- Model: Gemma 3 12B
- Inference server: llama.cpp HTTP server
- Endpoint: localhost (e.g. http://localhost:8080)
- Started manually by the developer before using Forge
- Full control over inference parameters (threads, GPU layers, context size, batch size)

Starting the llama.cpp server for personal use:
```bash
./llama-server -m gemma-3-12b.gguf \
  --host 0.0.0.0 \
  --port 8080 \
  -c 32768 \
  --n-gpu-layers 40
```

**Organisation / Team Context**
Used once Forge is deployed and operational within the organisation.

- Model: organisation-chosen model hosted on org inference servers
- Inference server: llama.cpp server or org inference infrastructure
- Endpoint: internal network URL (e.g. http://forge-model.internal.org:8080)
- Always running, maintained by org/admin
- Accessible to all Forge instances connected to the org Forge backend
- No internet exposure — internal network only

### Model Configuration

Forge stores model configuration in `~/.forge/config.json`. This file is set once by the admin or developer and inherited by all connected clients automatically.

**Personal mode config:**
```json
{
  "model": {
    "provider": "llama_cpp",
    "base_url": "http://localhost:8080",
    "model_name": "gemma-3-12b",
    "context_window": 32768,
    "temperature": 0.2,
    "mode": "personal"
  }
}
```

**Organisation mode config (set by admin, inherited by all):**
```json
{
  "model": {
    "provider": "llama_cpp",
    "base_url": "http://forge-model.internal.org:8080",
    "model_name": "org-model-name",
    "context_window": 131072,
    "temperature": 0.2,
    "mode": "organisation"
  }
}
```

### Why llama.cpp Server

llama.cpp HTTP server exposes an OpenAI-compatible REST API. Google ADK supports custom base URLs for model endpoints, meaning ADK talks to llama.cpp identically to how it would talk to any OpenAI-compatible endpoint — no code changes, just a config value.

Advantages of llama.cpp over alternatives:
- Lean and fast — lower memory overhead than higher-level wrappers
- Full control over inference parameters
- Excellent cross-platform support (Linux, macOS, Windows)
- OpenAI-compatible API — plug-and-play with ADK
- Production-grade for org server deployments
- No dependency on third-party model management tools

### Single Model Architecture (Phase 1)

Forge starts with a single model serving all agents. Every agent — Orchestrator, Intake, Architect, Coder, Tester, Patcher, Reviewer — calls the same model endpoint. This simplifies the initial build significantly.

The model is a config value, not hardcoded anywhere in agent logic. When the team is ready to move to a multi-model setup in a future phase (different models for different agent types), this requires only config changes and a routing layer addition — no agent rewrites.

### Who Configures The Model Endpoint

The org admin or lead developer configures the model endpoint once on the Forge backend server. All IDE extensions and CLI instances connected to that backend automatically inherit the model configuration. Individual developers and team members never need to configure or think about the model — they install the extension, connect to the Forge server URL, and everything works.

This is the complete zero-prerequisite experience for end users:
```
Developer installs Forge extension from IDE marketplace
              ↓
Enters Forge server URL (provided by admin)
              ↓
Done — model, backend, agents all pre-configured
```

---

## 13. Tech Stack

| Layer | Technology | Purpose |
|---|---|---|
| Agent Framework | Google ADK (Python) | Agent definition, orchestration, tool use |
| LLM Inference | llama.cpp HTTP server | Local model serving, OpenAI-compatible API |
| Model (Personal) | Gemma 3 12B | Dev/personal use via local llama.cpp |
| Model (Org) | Org-hosted model | Team/production use via internal network endpoint |
| Backend API | FastAPI (Python) | REST + WebSocket, session management, permission gateway |
| Message Broker | Redis Streams | A2A communication, file locking, pub/sub |
| CLI | Typer + Rich + Prompt Toolkit | Conversational terminal UX |
| LSP Server | pygls | IDE integration protocol |
| Session Storage | SQLite → PostgreSQL | Project state, checkpoints, permissions |
| Vector Store | ChromaDB (local) | Code semantic search and embeddings |
| MCP Servers | Custom Python MCP | Filesystem, Terminal (scoped), Git |
| IDE — VS Code | TypeScript Extension API | VS Code plugin shell |
| IDE — PyCharm | Kotlin Plugin API | PyCharm plugin shell |
| Containerisation | Docker + Docker Compose | Deployment, team server setup |
| Installer — Windows | PyInstaller + Inno Setup | .exe installer |
| Installer — macOS | PyInstaller + create-dmg | .dmg installer |
| Installer — Linux | PyInstaller | .AppImage |
| OS Support | Linux, macOS, Windows | All platforms via Python cross-compatibility |

---

## 14. Data Models — Key Structures

### Project Manifest (stored in project root as `.forge/manifest.json`)

```json
{
  "forge_version": "1.0.0",
  "project_name": "My FastAPI Backend",
  "session_id": "uuid",
  "language_stack": ["python", "sql"],
  "framework": "fastapi",
  "mode": "scratch",
  "architecture_plan": "path/to/arch_plan.md",
  "created_at": "ISO8601",
  "last_active": "ISO8601",
  "git_enabled": true,
  "test_depth": "full",
  "patch_permission": "ask_each_time"
}
```

### ChromaDB Collection Structure

One collection per project session. Each document is a file embedding:
```
collection: forge_<session_id>
documents:  [file contents]
metadatas:  [{ file_path, language, last_modified, module_type }]
ids:        [file_path as id]
```

This allows the Coder Agent to query: "find where database connections are handled" and get relevant files without reading the entire codebase.

---

## 15. Phased Roadmap

### Phase 1 — Core Foundation (Local Mode)

**Goal:** Working CLI agent that can build a project from scratch and complete existing ones on a developer's local machine.

- Orchestrator Agent + Intake Agent + Architect Agent
- Coder Agent with streaming output (status view)
- Basic Permission Gateway (ask each time)
- Filesystem MCP (read + write, no delete yet)
- SQLite session storage
- Checkpoint system (basic version)
- Conversational CLI with Typer + Rich
- Linux and macOS support
- llama.cpp server integration (personal mode, Gemma 3 12B)
- Python, JavaScript, TypeScript as initial target languages

### Phase 2 — Testing + Full Permission System

**Goal:** Complete all three operating modes, harden permissions.

- Tester Agent (unit + integration)
- Patcher Agent with full diff view in CLI
- Reviewer / Suggester Agent
- Terminal MCP (scoped to project dir)
- Git MCP (optional, commit + diff)
- Full permission model (global grants, file-specific, expiry)
- Code view streaming mode
- ChromaDB integration for large codebase search
- Windows support
- Expand language support (Java, C#, C, C++, Go, Rust)

### Phase 3 — Multi-Session + IDE Integration

**Goal:** Multi-session background execution, IDE plugins.

- Multi-session management (Option 3 — background execution)
- Session switching (/switch command)
- LSP server
- VS Code extension (sidebar, inline streaming, patch popups)
- PyCharm plugin (tool window, diff viewer)
- Full checkpoint recovery (context burst handling)
- E2E testing support in Tester Agent

### Phase 4 — Team Mode + Distribution

**Goal:** Team collaboration, installer packages, deployment assistance, org model integration.

- Team server mode (PostgreSQL, Redis distributed locking)
- Org model endpoint integration (internal network, admin-configured)
- Separate conversation threads per developer on shared project
- Presence awareness in CLI
- Deployment template library (all cloud providers)
- Online installer (Linux, macOS, Windows)
- Docker Compose team server setup
- .vsix and PyCharm plugin distributables for internal team
- Zero-prerequisite extension install (server URL only, model inherited)

### Phase 5 — Executable Installers + Polish

**Goal:** Non-developer-friendly distribution, production hardening.

- Windows .exe installer
- macOS .dmg installer
- Linux .AppImage
- First-time setup wizard
- Non-technical founder UX polish (Product Manager mode in Intake Agent)
- Performance tuning for large codebases
- Audit log viewer in CLI
- Full deployment assistance (Dockerfile generation, CI/CD config)

---

*Specification v1.1 complete. LLM strategy finalised. Ready for implementation planning.*


# FORGE — Programming Agent
## Complete Project Specification
**Version:** 1.2 — Pre-Implementation  
**Status:** Finalized for Development  
**Date:** May 2026

---

## Table of Contents

1. Project Overview
2. Core Operating Modes
3. Target Users
4. Agent Roster & Responsibilities
5. System Architecture
6. A2A Communication Protocol
7. Memory & Checkpoint System
8. Permission Gateway
9. CLI Design & UX
10. IDE Integration Strategy
11. Deployment & Distribution
12. LLM & Model Strategy
13. Tech Stack
14. Data Models
15. Phased Roadmap

---

## 1. Project Overview

Forge is a context-aware, autonomous programming agent that assists developers, teams, and non-technical founders in building, completing, and testing software projects. It operates iteratively, communicates in plain English, supports multiple programming languages, and runs across Linux, macOS, and Windows.

Forge is designed local-first but fully supports a shared team server mode for collaborative use. It ships as a CLI tool with IDE plugin support for VS Code and PyCharm, and as an installable package via an online installer or Docker.

### Core Principles

- **No assumptions** — Forge always asks before acting, never guesses at requirements
- **Permission-gated writes** — patching, deleting, and executing are always user-approved
- **Iterative by design** — work is done in steps with checkpoints, never in one uninterruptible sweep
- **Language-agnostic output** — Forge generates code in any language; it runs on Python internally
- **Context resilient** — when token limits are hit, Forge checkpoints and resumes seamlessly
- **Plain English first** — non-technical users are first-class citizens

---

## 2. Core Operating Modes

### Mode 1 — Build From Scratch
User describes a project in plain English or technical terms. Forge gathers requirements, sets a timeline, collects user stories if available, designs the architecture, and builds iteratively.

**Intake flow:**
1. Forge asks what the project does, who uses it, and what problem it solves
2. Forge asks for tech stack preference or recommends one
3. Forge asks for a deadline / timeline
4. Forge asks if user stories or requirements documents are available
5. Forge presents a project plan and waits for approval before writing a single line of code
6. On approval, Architect Agent designs the file/module structure
7. Coder Agent builds iteratively, checkpointing after each meaningful unit

### Mode 2 — Ingest & Complete Existing Project
User points Forge at an existing codebase. Forge scans, analyses, identifies what is incomplete, then asks targeted questions before filling gaps.

**Ingestion flow:**
1. Forge walks the file tree
2. Detects languages, frameworks, and dependency files (package.json, requirements.txt, pom.xml, .csproj, go.mod, etc.)
3. Reads README and any documentation
4. Builds an internal map of what exists vs what appears incomplete
5. Reports findings to user with specific observations
6. Asks what to focus on first — never assumes priority
7. Suggests enhancements based on project state (optional, user can dismiss)

### Mode 3 — Test Existing Project
User provides a completed project and requests tests. Forge analyses the codebase, asks about desired test depth, and writes a comprehensive test suite.

**Testing depth options (user chooses):**
1. Unit tests only
2. Unit + Integration tests
3. Full suite (Unit + Integration + E2E)
4. Let Forge decide based on project analysis
5. Custom — user specifies exact requirements

Forge also asks whether a coverage percentage target is desired (e.g. 80%, 90%, 100%).

---

## 3. Target Users

### Solo Developers
Technical users who want an autonomous coding partner. They communicate in technical terms, use CLI primarily, and expect Forge to move fast once requirements are clear.

### Development Teams
Multiple developers working on the same project. Each developer has their own separate conversation thread with Forge. All threads operate on the same project files. File-level locking prevents conflicts. All team members have equal permissions within their session.

### Non-Technical Founders / Product Owners
Users who describe projects in plain English without technical vocabulary. Forge's Intake Agent operates in "Product Manager mode" — asking about goals, users, and features — and the Architect Agent translates this into a technical spec internally. Founders never see the tech spec unless they ask.

---

## 4. Agent Roster & Responsibilities

All agents are built in Python using Google ADK. Each is a specialized sub-agent. The Orchestrator delegates tasks via the message broker.

### Orchestrator Agent
- Root agent, receives all user input
- Determines which mode the user is in (build / ingest / test)
- Delegates tasks to specialized agents via message broker
- Tracks overall task state and progress
- Reports back to user in CLI
- Manages checkpoint triggers
- Handles context burst recovery

### Intake Agent
- First agent to interact with the user in all modes
- Gathers requirements, timeline, user stories, tech stack preferences
- Switches between "technical mode" and "product manager mode" based on user type
- Never passes incomplete requirements downstream
- Presents project plan to user for approval before any code is written

### Architect Agent
- Receives approved requirements from Intake Agent
- Designs file/module/directory structure
- Selects or confirms tech stack
- Produces an architecture plan
- Plans the iterative build order (what gets built first, second, etc.)
- Presents plan to user for review

### Coder Agent
- Receives build tasks from Orchestrator one unit at a time
- Language-aware — detects and generates code in any required language
- Streams output to CLI (status view or code view, user toggles)
- Checkpoints after each meaningful unit is complete
- Never writes to files without permission
- In advisory mode: shows generated code and asks for patch permission
- In permitted mode: writes directly, logs all actions

### Tester Agent
- Analyses existing codebase to understand what needs testing
- Generates unit, integration, and E2E tests based on user-specified depth
- Runs tests via Terminal MCP and reports results
- Identifies gaps in coverage and reports them
- Suggests additional edge cases

### Patcher Agent
- Receives patch tasks from Orchestrator or user requests
- Always checks Permission Gateway before writing
- If no permission: shows diff in CLI, prompts user to allow or generate-only
- If permission granted: applies patch, logs action, creates checkpoint
- Handles delete operations with same permission check

### Reviewer / Suggester Agent
- Activated after code is written or when user asks for a review
- Reviews code quality, patterns, potential bugs
- Suggests enhancements based on current project state
- Never forces suggestions — always optional
- Can suggest architectural improvements as project grows

### Memory / Checkpoint Manager
- Not a conversational agent — a background service
- Monitors token usage across all active agents
- Triggers checkpoint saves before context window is exceeded
- Saves: work summary, files touched, next planned step, token count
- On restart: feeds compressed context back to the relevant agent
- Surfaces checkpoint status to user in CLI ("Refreshing context — continuing from checkpoint 7")

---

## 5. System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    SURFACES / INTERFACES                        │
│                                                                 │
│  ┌──────────────────┐    ┌───────────────┐   ┌──────────────┐  │
│  │   CLI (Primary)  │    │  VS Code Ext  │   │ PyCharm Plug │  │
│  │  Typer + Rich    │    │  (thin shell) │   │ (thin shell) │  │
│  └────────┬─────────┘    └───────┬───────┘   └──────┬───────┘  │
│           │                      │                  │          │
│           └──────────────────────┼──────────────────┘          │
│                                  │ LSP Protocol                 │
└──────────────────────────────────┼──────────────────────────────┘
                                   │
┌──────────────────────────────────▼──────────────────────────────┐
│                      LSP Server                                 │
│              (bridges IDE plugins to FastAPI)                   │
└──────────────────────────────────┬──────────────────────────────┘
                                   │ HTTP / WebSocket
┌──────────────────────────────────▼──────────────────────────────┐
│                       FastAPI Backend                           │
│                                                                 │
│  ┌──────────────┐  ┌─────────────────┐  ┌────────────────────┐ │
│  │ Session &    │  │  Permission     │  │  Project           │ │
│  │ Memory Mgr   │  │  Gateway        │  │  Ingestor          │ │
│  └──────────────┘  └─────────────────┘  └────────────────────┘ │
│                                                                 │
│  ┌──────────────┐  ┌─────────────────┐  ┌────────────────────┐ │
│  │ Streaming    │  │  File Lock      │  │  Deployment        │ │
│  │ Manager      │  │  Manager        │  │  Template Library  │ │
│  │ (SSE)        │  │  (team mode)    │  │                    │ │
│  └──────────────┘  └─────────────────┘  └────────────────────┘ │
└──────────────────────────────────┬──────────────────────────────┘
                                   │
┌──────────────────────────────────▼──────────────────────────────┐
│                    Google ADK Agent Layer                       │
│                                                                 │
│  ┌─────────────┐  ┌────────────┐  ┌─────────────┐             │
│  │ Orchestrator│  │  Intake    │  │  Architect  │             │
│  │ Agent       │  │  Agent     │  │  Agent      │             │
│  └─────────────┘  └────────────┘  └─────────────┘             │
│                                                                 │
│  ┌─────────────┐  ┌────────────┐  ┌─────────────┐             │
│  │  Coder      │  │  Tester    │  │  Patcher    │             │
│  │  Agent      │  │  Agent     │  │  Agent      │             │
│  └─────────────┘  └────────────┘  └─────────────┘             │
│                                                                 │
│  ┌─────────────┐  ┌──────────────────────────────────────────┐ │
│  │  Reviewer / │  │  Memory / Checkpoint Manager             │ │
│  │  Suggester  │  │  (background service)                    │ │
│  └─────────────┘  └──────────────────────────────────────────┘ │
└──────────────────────────────────┬──────────────────────────────┘
                                   │
┌──────────────────────────────────▼──────────────────────────────┐
│                    Message Broker (Redis Streams)               │
│                                                                 │
│  Queues per agent:                                              │
│  intake.tasks | architect.tasks | coder.tasks                  │
│  tester.tasks | patcher.tasks   | reviewer.tasks               │
│                                                                 │
│  Event bus:  agent.events  (broadcast, all agents subscribe)   │
│  Results:    orchestrator.results                               │
└──────────────────────────────────┬──────────────────────────────┘
                                   │
┌──────────────────────────────────▼──────────────────────────────┐
│                        MCP Server Layer                         │
│                                                                 │
│  ┌──────────────────┐  ┌──────────────────┐  ┌──────────────┐  │
│  │  Filesystem MCP  │  │  Terminal MCP    │  │  Git MCP     │  │
│  │                  │  │                  │  │              │  │
│  │  read, write,    │  │  Scoped to       │  │  commit,     │  │
│  │  patch, delete   │  │  project dir     │  │  diff,       │  │
│  │  (perm-gated)    │  │  only (chroot)   │  │  branch,     │  │
│  │                  │  │  run tests,      │  │  push, pull  │  │
│  │                  │  │  builds, linters │  │  (optional)  │  │
│  └──────────────────┘  └──────────────────┘  └──────────────┘  │
└──────────────────────────────────┬──────────────────────────────┘
                                   │
┌──────────────────────────────────▼──────────────────────────────┐
│                   Persistent Storage (Local)                    │
│                                                                 │
│  ┌──────────────────┐  ┌──────────────────┐  ┌──────────────┐  │
│  │  SQLite          │  │  ChromaDB        │  │  Session     │  │
│  │  (→ PostgreSQL   │  │  (local vector   │  │  Logs        │  │
│  │  in team mode)   │  │  store for code  │  │  audit trail │  │
│  │                  │  │  embeddings)     │  │              │  │
│  │  sessions        │  │                  │  │              │  │
│  │  checkpoints     │  │  Semantic code   │  │              │  │
│  │  permissions     │  │  search across   │  │              │  │
│  │  project meta    │  │  large codebases │  │              │  │
│  └──────────────────┘  └──────────────────┘  └──────────────┘  │
└─────────────────────────────────────────────────────────────────┘
```

### Deployment Modes

**Local Mode (default)**
Everything runs on the developer's machine. SQLite for storage, local Redis instance, local ChromaDB. No network dependency after install.

**Team Server Mode**
One shared instance runs on a central machine or cloud server. Developers connect their CLI and IDE plugins to the server URL. Storage upgrades to PostgreSQL. Redis handles distributed session locking for concurrent access. Each developer maintains their own conversation thread against the shared project.

---

## 6. A2A Communication Protocol

All agent-to-agent communication flows through Redis Streams via a standardized message envelope. This decouples agents completely — any agent can run on any machine in a scaled deployment.

### Message Envelope Schema

```json
{
  "message_id": "uuid-v4",
  "session_id": "project-session-uuid",
  "from_agent": "orchestrator",
  "to_agent": "coder",
  "task_type": "write_module",
  "priority": "normal",
  "payload": {
    "file_path": "src/auth/login.py",
    "instructions": "Write the login endpoint using JWT...",
    "context_summary": "Project is a FastAPI backend. Auth module. JWT chosen.",
    "checkpoint_id": "chk_0042"
  },
  "reply_to": "orchestrator.results",
  "timestamp": "2026-05-30T10:00:00Z",
  "ttl_seconds": 300
}
```

### Task Types

| task_type | From | To | Description |
|---|---|---|---|
| gather_requirements | orchestrator | intake | Start intake conversation |
| design_architecture | orchestrator | architect | Design file/module structure |
| write_module | orchestrator | coder | Write a specific file or module |
| write_tests | orchestrator | tester | Generate tests for a target |
| run_tests | orchestrator | tester | Execute tests, report results |
| apply_patch | orchestrator | patcher | Patch a file (permission required) |
| review_code | orchestrator | reviewer | Review and suggest improvements |
| checkpoint_save | any | memory_manager | Save current progress |
| checkpoint_load | orchestrator | memory_manager | Restore from checkpoint |
| ingest_project | orchestrator | intake | Scan and analyse existing project |

### File-Level Locking (Team Mode)

When multiple developers are active on the same project, Redis handles distributed file locks:

- Before any agent writes to a file, it acquires a Redis lock on that file path
- Lock TTL is 60 seconds, auto-renewed while the agent is actively writing
- If a file is locked, the requesting agent queues behind it
- User sees in CLI: "Waiting — teammate's session is writing to auth/login.py"
- On lock release, queued agent proceeds automatically

---

## 7. Memory & Checkpoint System

Session continuity is a first-class feature. Forge never loses progress.

### Database Schema (SQLite / PostgreSQL)

**sessions**
```
session_id          UUID primary key
project_path        TEXT
project_name        TEXT
mode                ENUM(scratch, ingest, test)
status              ENUM(active, paused, complete, error)
user_type           ENUM(developer, team, founder)
language_stack      JSON
git_enabled         BOOLEAN
test_depth          ENUM(unit, integration, full, custom, auto)
patch_permission    ENUM(none, ask_each_time, session_global)
created_at          TIMESTAMP
updated_at          TIMESTAMP
last_checkpoint_id  UUID FK
```

**checkpoints**
```
checkpoint_id           UUID primary key
session_id              UUID FK
step_number             INTEGER
agent_who_saved         TEXT
summary_of_work_done    TEXT (compressed context summary)
files_touched           JSON (list of file paths and operations)
next_planned_step       TEXT
token_count_at_save     INTEGER
created_at              TIMESTAMP
```

**permissions**
```
permission_id       UUID primary key
session_id          UUID FK
permission_type     ENUM(patch, delete, git_commit, terminal_exec)
scope               ENUM(global, file_specific)
file_path           TEXT nullable
granted_at          TIMESTAMP
expires_at          TIMESTAMP nullable
granted_by          TEXT
```

**project_files**
```
file_id             UUID primary key
session_id          UUID FK
file_path           TEXT
language            TEXT
last_read_at        TIMESTAMP
last_written_at     TIMESTAMP
chroma_embedded     BOOLEAN
```

### Context Burst Recovery Flow

```
1. Coder Agent token count approaches 80% of limit
          ↓
2. Checkpoint Manager triggers pre-emptive save:
   - Compress work summary into compact form
   - Save all file states written this session
   - Record "next_planned_step" explicitly
   - Write checkpoint record to DB
          ↓
3. Agent process restarts with injected context:
   "You are Forge Coder Agent continuing a session.
    Completed so far: [checkpoint summary]
    Files written: [list]
    Your next task: [next_planned_step]
    Continue from here without repeating completed work."
          ↓
4. CLI shows to user:
   "⟳ Context refreshed — continuing from checkpoint #7"
   (seamless, user sees no interruption)
```

### Session Resumption (Returning User)

When user opens Forge after closing it:
```
forge start

Forge → Welcome back. You have active sessions:
        
        ● FastAPI Backend          checkpoint #12 — writing payment module
          Last active: 2 hours ago
        
        ○ React App Tests           checkpoint #4 — unit tests complete
          Last active: yesterday
        
        ○ Mobile App                waiting for your input on nav design
          Last active: 3 days ago

        Which would you like to resume? (or start new)
```

### Multi-Session Background Execution (Option 3)

- One session is "active" — receives the user's conversation
- Other sessions marked "running" continue agent work autonomously in background
- User switches with `/switch [session-name]`
- Background sessions surface completed work and blockers via notifications in CLI
- Sessions marked "paused" are waiting for user input and do no background work

---

## 8. Permission Gateway

Every write, patch, delete, and terminal execution passes through the Permission Gateway in FastAPI before reaching the MCP servers.

### Permission Flow

```
Agent requests action (patch/delete/exec)
              ↓
Permission Gateway checks:
  1. What type of action is this?
  2. Does a global permission exist for this session?
  3. Does a file-specific permission exist?
  4. Is the action within the project directory scope?
              ↓
       ┌──────┴──────┐
       │             │
  PERMITTED      NOT PERMITTED
       │             │
   Log & proceed    Show diff/preview in CLI
                     │
                  Prompt user:
                  [P] Patch now
                  [G] Generate only (show me the code)
                  [A] Allow all patches this session
                  [S] Skip this change
                     │
              Record decision → proceed
```

### Terminal MCP Scope Enforcement

The Terminal MCP server enforces a hard boundary at the project root directory:

- All commands are prefixed with a chroot-equivalent check
- Any command attempting to navigate above the project root is rejected
- Commands that can access the network (curl, wget, etc.) require explicit user approval per invocation
- Build commands (npm build, pytest, mvn package) are pre-approved by default
- Destructive system commands (rm -rf, format, etc.) are blocked entirely outside the project dir

### Git Operations (Optional)

Git integration is opt-in per session. When enabled:

- Auto-commit after each iterative step with generated commit message
- User can review and edit commit message before commit
- Push to remote requires explicit user approval every time
- Branching strategy suggested by Architect Agent based on project type

---

## 9. CLI Design & UX

### Technology

- **Typer** — command and argument parsing
- **Rich** — terminal rendering (panels, progress bars, streaming text, tables)
- **Prompt Toolkit** — conversational input with history

### Primary Entry Points

```bash
forge                    # Start or resume (conversational mode)
forge start              # Explicitly start new session
forge resume             # List and resume existing sessions
forge sessions           # Show all active/paused sessions
forge switch <name>      # Switch active session
forge status             # Current session progress
forge checkpoint         # Force a checkpoint save
forge config             # Configuration settings
forge connect <url>      # Connect to team server
```

### Conversational Mode

Forge opens in a chat-loop. The user types naturally. Commands prefixed with `/` are available at any time without breaking conversation flow.

```
/help                    Show available commands
/switch <session>        Switch active session
/view code               Toggle to code streaming view
/view status             Toggle to status streaming view  
/sessions                Show all sessions
/checkpoint              Force save checkpoint
/permissions             Show current permission grants
/allow patch             Grant patch permission for this session
/allow patch <filepath>  Grant patch permission for specific file
/git on|off              Toggle git integration
/suggest                 Ask Reviewer Agent for enhancement suggestions
/deploy                  Start deployment configuration
/exit                    Exit (sessions continue in background)
```

### Streaming Output — Two Views

**Status View (default)**
```
╔══════════════════════════════════════════════════════════════╗
║  FORGE  ●  FastAPI Backend  ●  checkpoint #8  ●  Coder Agent ║
╚══════════════════════════════════════════════════════════════╝

 ✓ Designed project structure
 ✓ Written: src/main.py
 ✓ Written: src/config.py
 ✓ Written: src/models/user.py
 → Writing: src/auth/login.py
   Creating JWT token handler...
   Writing login endpoint...
   Adding password hashing...
 ○ Pending: src/auth/register.py
 ○ Pending: src/auth/middleware.py
```

**Code View (/view code)**
```
╔══════════════════════════════════════════════════════════════╗
║  FORGE  ●  FastAPI Backend  ●  Writing: src/auth/login.py   ║
╚══════════════════════════════════════════════════════════════╝

 from fastapi import APIRouter, Depends, HTTPException
 from fastapi.security import OAuth2PasswordRequestForm
 from ..models.user import User
 from ..services.auth import create_access_token
 import bcrypt

 router = APIRouter()

 @router.post("/login")
 async def login(
     form_data: OAuth2PasswordRequestForm = Depends()
 ):▌
```

### Patch Permission Prompt

```
╔══════════════════════════════════════════════════════════════╗
║  FORGE — Permission Required                                 ║
╚══════════════════════════════════════════════════════════════╝

 Forge wants to patch: src/auth/login.py

 ── DIFF ─────────────────────────────────────────────────────
 - async def login(form_data):
 + async def login(
 +     form_data: OAuth2PasswordRequestForm = Depends(),
 +     db: AsyncSession = Depends(get_db)
 + ):
 ─────────────────────────────────────────────────────────────

 [P] Patch now       [G] Generate only       
 [A] Allow all       [S] Skip

 Choice:
```

---

## 10. IDE Integration Strategy

### Architecture — LSP First

Forge runs a local Language Server Protocol (LSP) server. IDE plugins are thin clients that communicate with this LSP server. All intelligence lives in the LSP server — the plugins are UI shells only.

This means:
- One codebase for core agent logic
- VS Code and PyCharm plugins share the same backend
- Any other LSP-compatible editor (Vim, Emacs, Helix, Neovim) works with minimal effort
- Updates to agent logic deploy once, all IDEs benefit automatically

### LSP Server

- Runs as a background process alongside FastAPI
- Exposes standard LSP capabilities plus custom Forge commands
- Communicates with FastAPI backend over local socket

### VS Code Extension

- Sidebar panel: current session status, file tree with agent annotations
- Inline code streaming: watch Forge write in the editor buffer
- Patch approval popups: native VS Code notification with approve/reject
- Chat panel: conversational interface without leaving the IDE
- Status bar: active session name and current agent

### PyCharm Plugin

- Tool window panel: session status and conversation
- Editor annotations: files touched by Forge highlighted
- Patch diff viewer: native PyCharm diff tool for reviewing changes
- Action menu: right-click on file to ask Forge about it

### Distribution

- VS Code: distributed as `.vsix` file (installable locally), later via VS Code Marketplace
- PyCharm: distributed as `.zip` plugin (installable via Plugins > Install from disk), later via JetBrains Marketplace

---

## 11. Deployment & Distribution

### Agent Distribution (Installing Forge Itself)

**Path A — Online Installer**
A small shell/PowerShell script (~10MB) that:
1. Detects OS (Linux / macOS / Windows)
2. Checks for existing dependencies (Python 3.10+, Redis, Docker)
3. Downloads only what is missing
4. Installs Forge agent package
5. Configures Redis as a background service
6. Runs first-time setup wizard

Target install size: under 50MB download, under 200MB installed.

**Path B — Docker-based**
For developers who have Docker installed:
```bash
curl -sSL https://getforge.dev/install | sh
# or
docker compose up -d  # using the provided docker-compose.yml
```

Docker Compose spins up: FastAPI backend, Redis, ChromaDB, LSP server — all pre-configured, zero manual setup.

**Path C — Executable Installer (Internal Team)**
For teammates who are not developers:
- Windows: `.exe` installer built with PyInstaller + Inno Setup
- macOS: `.dmg` installer built with PyInstaller + create-dmg
- Linux: `.AppImage` portable executable

These bundle the Python runtime but use lazy loading for heavy components (ChromaDB, Redis) to keep the installer file under 100MB. Heavy deps are downloaded and installed on first run.

**Setup Wizard (all paths)**
On first launch:
```
Welcome to Forge!

Are you setting up for:
1. Just yourself (local mode)
2. Connecting to a team server (I'll enter the server URL)
3. Setting this up as a team server (others will connect to me)
```

### User's Project Deployment (Forge Helping Deploy)

**Built-in template library** for the following providers:
- AWS (ECS, EC2, Lambda, Elastic Beanstalk)
- Google Cloud Platform (Cloud Run, GKE, App Engine)
- Microsoft Azure (App Service, AKS, Container Instances)
- DigitalOcean (App Platform, Droplets)
- Railway
- Render
- Vercel (frontend / serverless)
- Fly.io
- Heroku

**On-demand generation:** User can ask for any provider not in the library and Forge generates deployment config from scratch.

**Deployment artifacts Forge produces:**
- `Dockerfile` and `.dockerignore`
- `docker-compose.yml` for local production simulation
- CI/CD pipeline config (GitHub Actions, GitLab CI, or Bitbucket Pipelines)
- Provider-specific config files (e.g. `fly.toml`, `render.yaml`, `railway.json`)
- Environment variable templates (`.env.example`)
- Infrastructure-as-code scripts when appropriate (Terraform for AWS/GCP/Azure)

---

## 12. LLM & Model Strategy

### Core Principle — Local Models Only

Forge uses exclusively local, self-hosted language models. No external API calls, no internet dependency for inference, no API key management. All model inference happens either on the developer's own machine or on organisation-hosted inference servers accessible over the internal network.

This means:
- Code never leaves the machine or org network
- No per-token billing or rate limits
- Works fully air-gapped
- Organisation retains full data sovereignty

### Two Deployment Contexts

**Personal / Development Context**
Used during Forge's own development and by individual developers running their own local instance.

- Model: Gemma 3 12B
- Inference server: llama.cpp HTTP server
- Endpoint: localhost (e.g. http://localhost:8080)
- Started manually by the developer before using Forge
- Full control over inference parameters (threads, GPU layers, context size, batch size)

Starting the llama.cpp server for personal use:
```bash
./llama-server -m gemma-3-12b.gguf \
  --host 0.0.0.0 \
  --port 8080 \
  -c 32768 \
  --n-gpu-layers 40
```

**Organisation / Team Context**
Used once Forge is deployed and operational within the organisation.

- Model: organisation-chosen model hosted on org inference servers
- Inference server: llama.cpp server or org inference infrastructure
- Endpoint: internal network URL (e.g. http://forge-model.internal.org:8080)
- Always running, maintained by org/admin
- Accessible to all Forge instances connected to the org Forge backend
- No internet exposure — internal network only

### Model Configuration

Forge stores model configuration in `~/.forge/config.json`. This file is set once by the admin or developer and inherited by all connected clients automatically.

**Personal mode config:**
```json
{
  "model": {
    "provider": "llama_cpp",
    "base_url": "http://localhost:8080",
    "model_name": "gemma-3-12b",
    "context_window": 32768,
    "temperature": 0.2,
    "mode": "personal"
  }
}
```

**Organisation mode config (set by admin, inherited by all):**
```json
{
  "model": {
    "provider": "llama_cpp",
    "base_url": "http://forge-model.internal.org:8080",
    "model_name": "org-model-name",
    "context_window": 131072,
    "temperature": 0.2,
    "mode": "organisation"
  }
}
```

### Why llama.cpp Server

llama.cpp HTTP server exposes an OpenAI-compatible REST API. Google ADK supports custom base URLs for model endpoints, meaning ADK talks to llama.cpp identically to how it would talk to any OpenAI-compatible endpoint — no code changes, just a config value.

Advantages of llama.cpp over alternatives:
- Lean and fast — lower memory overhead than higher-level wrappers
- Full control over inference parameters
- Excellent cross-platform support (Linux, macOS, Windows)
- OpenAI-compatible API — plug-and-play with ADK
- Production-grade for org server deployments
- No dependency on third-party model management tools

### Single Model Architecture (Phase 1)

Forge starts with a single model serving all agents. Every agent — Orchestrator, Intake, Architect, Coder, Tester, Patcher, Reviewer — calls the same model endpoint. This simplifies the initial build significantly.

The model is a config value, not hardcoded anywhere in agent logic. When the team is ready to move to a multi-model setup in a future phase (different models for different agent types), this requires only config changes and a routing layer addition — no agent rewrites.

### Who Configures The Model Endpoint

The org admin or lead developer configures the model endpoint once on the Forge backend server. All IDE extensions and CLI instances connected to that backend automatically inherit the model configuration. Individual developers and team members never need to configure or think about the model — they install the extension, connect to the Forge server URL, and everything works.

This is the complete zero-prerequisite experience for end users:
```
Developer installs Forge extension from IDE marketplace
              ↓
Enters Forge server URL (provided by admin)
              ↓
Done — model, backend, agents all pre-configured
```

---

## 13. Tech Stack

| Layer | Technology | Purpose |
|---|---|---|
| Agent Framework | Google ADK (Python) | Agent definition, orchestration, tool use |
| LLM Inference | llama.cpp HTTP server | Local model serving, OpenAI-compatible API |
| Model (Personal) | Gemma 3 12B | Dev/personal use via local llama.cpp |
| Model (Org) | Org-hosted model | Team/production use via internal network endpoint |
| Backend API | FastAPI (Python) | REST + WebSocket, session management, permission gateway |
| Message Broker | Redis Streams | A2A communication, file locking, pub/sub |
| CLI | Typer + Rich + Prompt Toolkit | Conversational terminal UX |
| LSP Server | pygls | IDE integration protocol |
| Session Storage | SQLite → PostgreSQL | Project state, checkpoints, permissions |
| Vector Store | ChromaDB (local) | Code semantic search and embeddings |
| MCP Servers | Custom Python MCP | Filesystem, Terminal (scoped), Git |
| IDE — VS Code | TypeScript Extension API | VS Code plugin shell |
| IDE — PyCharm | Kotlin Plugin API | PyCharm plugin shell |
| Containerisation | Docker + Docker Compose | Deployment, team server setup |
| Installer — Windows | PyInstaller + Inno Setup | .exe installer |
| Installer — macOS | PyInstaller + create-dmg | .dmg installer |
| Installer — Linux | PyInstaller | .AppImage |
| OS Support | Linux, macOS, Windows | All platforms via Python cross-compatibility |

---

## 14. Data Models — Key Structures

### Project Manifest (stored in project root as `.forge/manifest.json`)

```json
{
  "forge_version": "1.0.0",
  "project_name": "My FastAPI Backend",
  "session_id": "uuid",
  "language_stack": ["python", "sql"],
  "framework": "fastapi",
  "mode": "scratch",
  "architecture_plan": "path/to/arch_plan.md",
  "created_at": "ISO8601",
  "last_active": "ISO8601",
  "git_enabled": true,
  "test_depth": "full",
  "patch_permission": "ask_each_time"
}
```

### ChromaDB Collection Structure

One collection per project session. Each document is a file embedding:
```
collection: forge_<session_id>
documents:  [file contents]
metadatas:  [{ file_path, language, last_modified, module_type }]
ids:        [file_path as id]
```

This allows the Coder Agent to query: "find where database connections are handled" and get relevant files without reading the entire codebase.

---

## 15. Phased Roadmap

### Phase 1 — Core Foundation (Local Mode)

**Goal:** Working CLI agent that can build a project from scratch and complete existing ones on a developer's local machine.

- Orchestrator Agent + Intake Agent + Architect Agent
- Coder Agent with streaming output (status view)
- Basic Permission Gateway (ask each time)
- Filesystem MCP (read + write, no delete yet)
- SQLite session storage
- Checkpoint system (basic version)
- Conversational CLI with Typer + Rich
- Linux and macOS support
- llama.cpp server integration (personal mode, Gemma 3 12B)
- Python, JavaScript, TypeScript as initial target languages

### Phase 2 — Testing + Full Permission System

**Goal:** Complete all three operating modes, harden permissions.

- Tester Agent (unit + integration)
- Patcher Agent with full diff view in CLI
- Reviewer / Suggester Agent
- Terminal MCP (scoped to project dir)
- Git MCP (optional, commit + diff)
- Full permission model (global grants, file-specific, expiry)
- Code view streaming mode
- ChromaDB integration for large codebase search
- Windows support
- Expand language support (Java, C#, C, C++, Go, Rust)

### Phase 3 — Multi-Session + IDE Integration

**Goal:** Multi-session background execution, IDE plugins.

- Multi-session management (Option 3 — background execution)
- Session switching (/switch command)
- LSP server
- VS Code extension (sidebar, inline streaming, patch popups)
- PyCharm plugin (tool window, diff viewer)
- Full checkpoint recovery (context burst handling)
- E2E testing support in Tester Agent

### Phase 4 — Team Mode + Distribution

**Goal:** Team collaboration, installer packages, deployment assistance, org model integration.

- Team server mode (PostgreSQL, Redis distributed locking)
- Org model endpoint integration (internal network, admin-configured)
- Separate conversation threads per developer on shared project
- Presence awareness in CLI
- Deployment template library (all cloud providers)
- Online installer (Linux, macOS, Windows)
- Docker Compose team server setup
- .vsix and PyCharm plugin distributables for internal team
- Zero-prerequisite extension install (server URL only, model inherited)

### Phase 5 — Executable Installers + Polish

**Goal:** Non-developer-friendly distribution, production hardening.

- Windows .exe installer
- macOS .dmg installer
- Linux .AppImage
- First-time setup wizard
- Non-technical founder UX polish (Product Manager mode in Intake Agent)
- Performance tuning for large codebases
- Audit log viewer in CLI
- Full deployment assistance (Dockerfile generation, CI/CD config)

---

*Specification v1.1 complete. LLM strategy finalised. Ready for implementation planning.*

---

## 16. Enhanced Features & Upgrades

All suggestions from the enhancement review have been accepted and incorporated. This section documents each addition.

### 16.1 — Self-Healing Code (1A)
After the Coder Agent writes a module, it is automatically passed to the Self-Healing system in `quality/self_healing/`. The code is executed silently via Terminal MCP. Any syntax errors or runtime crashes are caught, sent back to the Coder Agent with the error context, and fixed before the file is ever presented to the user. The user only ever sees working output. A brief heal report is shown if any fixes were made.

### 16.2 — Inter-Agent Review Gate (1B)
Before any file written by the Coder Agent is saved, it passes through a silent Review Gate in `quality/review_gate/`. The Reviewer Agent validates it internally. If issues are found they are classified and the file is rerouted back to the Coder Agent for correction. This happens transparently — the user sees a slight delay at most. No back-and-forth is surfaced unless the user asks.

### 16.3 — Dependency Conflict Detection (1C)
The Architect Agent runs a dependency compatibility check via `agents/architect/dependency_conflict_checker.py` before any code is written. It validates that all chosen packages and versions are mutually compatible. Conflicts are surfaced at planning time with alternatives suggested.

### 16.4 — Security Scanning Agent (1D)
A dedicated Security Agent lives in `agents/security/`. It runs automatically after code is written and on-demand via `forge security`. It scans for hardcoded secrets, SQL/command injection patterns, insecure dependency versions (checked against CVE database), and exposed endpoints. Results are presented as a prioritised report. The agent suggests fixes and can apply them with permission.

### 16.5 — Knowledge Graph (2A)
When ingesting an existing project, Forge builds a knowledge graph of the codebase stored in `knowledge/graph/`. It maps which modules call which, where data flows, and what depends on what. This graph is used by all agents — the Coder Agent queries it to understand relationships before writing, the Tester Agent uses it to prioritise test coverage, and the Reviewer Agent uses it to assess architectural impact of suggested changes.

### 16.6 — Automatic Documentation Generation (2B)
After building or completing a project, the Documentation Generator in `knowledge/docs/` produces a README, API documentation, and inline code comments. Triggered automatically at project completion or on-demand via `/docs generate`.

### 16.7 — Tech Debt Detector (2C)
During Mode 2 ingestion, the Tech Debt Detector in `knowledge/tech_debt/` analyses the codebase for deprecated dependencies, outdated patterns, dead code, inconsistent naming, and missing error handling. Results are presented as a prioritised list. The user can choose to address items, defer them, or ignore them entirely.

### 16.8 — Web UI Companion (3A)
An optional browser-based interface in `web_ui/` runs on localhost alongside the CLI. It provides a visual project dashboard with a file tree showing agent annotations, a browser terminal with live streaming, a diff viewer for patch review, and session management. Particularly useful for non-technical founders. Launched via `forge web` or `forge --ui`.

### 16.9 — Voice Input Mode (3B)
The Intake Agent supports voice input via a local Whisper-compatible model through `agents/intake/voice_handler.py`. The user can describe their project by speaking. Activated via `forge start --voice`. Runs fully locally — no cloud speech service.

### 16.10 — Project Templates Library (3C)
A curated library of project archetypes lives in `agents/intake/template_matcher.py`. When the user describes a project, the Intake Agent matches it to the closest template — REST API, full-stack web app, CLI tool, microservice, data pipeline, mobile backend, etc. The template pre-fills the architecture plan, skipping a large portion of the intake conversation. Users can override any pre-filled value.

### 16.11 — Interactive Architecture Review (3D)
Before coding begins, the Architect Agent renders an interactive diagram of the planned structure via `agents/architect/architecture_diagram.py`. In CLI mode this is a Rich-rendered tree with relationship annotations. In web UI mode it is a clickable visual graph. The user reviews the architecture visually before approving.

### 16.12 — Session Handoff (4A)
A developer can hand off their active session to a teammate via `forge handoff <teammate>`. The `collaboration/handoff/` module packages the full session context — what's been built, what's pending, all decisions made — and delivers it to the receiving developer. They resume the session with complete context, as if they had been there from the start.

### 16.13 — Team Activity Feed (4B)
In team mode, a shared activity feed shows what each developer's Forge session is currently doing on the project. Published via `collaboration/activity_feed/` and visible in CLI via `/feed` and in the IDE extensions' activity feed panels. Entries are concise: "Dev A: writing payment module", "Dev B: security scan complete — 2 issues found".

### 16.14 — Conflict Prevention System (4C)
Before an agent begins writing any module, `collaboration/conflict_prevention/` checks whether another developer's session has that module planned or in-progress. If overlap is detected both developers are notified and asked to decide who owns the work. This is smarter than file-level locking alone — it catches conflicts at the planning stage, before any code is written.

### 16.15 — Mutation Testing (5A)
The Tester Agent includes `agents/tester/mutation_tester.py` which deliberately introduces small controlled bugs into a copy of the code and verifies that the test suite catches them. This validates that tests are meaningful, not just coverage-padding. Results show which parts of the test suite are robust and which need strengthening.

### 16.16 — Automatic Test Maintenance (5B)
When the Patcher Agent updates existing code, `agents/tester/test_maintainer.py` automatically checks whether existing tests still pass against the changes. Tests that broke due to the patch are updated to reflect the new behaviour. Tests stay in sync with code automatically after every patch.

### 16.17 — Performance Benchmarking (5C)
The Tester Agent writes basic performance benchmarks alongside unit tests via `agents/tester/performance_benchmarker.py`. These measure response times, memory usage, and throughput for critical paths. The user gets a performance baseline from day one rather than discovering issues in production.

### 16.18 — Infrastructure as Code (6A)
The deployment template library in `deployment/templates/iac/` includes Terraform and Pulumi scripts for AWS, GCP, and Azure. The Deployment Service generates full infrastructure provisioning scripts alongside Dockerfiles and CI/CD configs. The user goes from working code to fully provisioned cloud infrastructure in one step.

### 16.19 — Environment Management (6B)
A dedicated Environment Agent in `agents/environment/` manages configuration across dev, staging, and production environments. It generates `.env` files, integrates with secrets management systems (AWS Secrets Manager, HashiCorp Vault), and validates that all required environment variables are present and correctly typed. It actively prevents secrets from appearing in code.

### 16.20 — Rollback System (6C)
The Patcher Agent maintains a Forge-level version history of every file it touches, independent of Git, managed via `agents/patcher/rollback_manager.py` and `backend/services/rollback_service.py`. Snapshots are stored in the `rollback_snapshots` DB table. The user can say "rollback to before this session" and Forge restores the previous state instantly. Rollback history is viewable via `forge rollback` or `/rollback` in conversation.

### 16.21 — Multi-Model Routing (7A — Future Phase)
The model is a config value throughout. When the team is ready to move to per-agent model routing (different models for different agent types), a routing layer is added with zero agent rewrites required. Deferred to a future phase after single-model architecture is stable.

### 16.22 — Prompt Caching (7B)
For large codebase ingestion, `agents/coder/prompt_cache_manager.py` manages prompt caching so that embedded representations of unchanged files are reused across sessions rather than recomputed on every call. Significantly reduces inference time and load on the model server for repeat work on large projects.

### 16.23 — Parallel Agent Execution (7C)
The Orchestrator Agent's `parallel_scheduler.py` identifies tasks that are genuinely independent — files with no shared dependencies — and dispatches them to multiple Coder Agent instances simultaneously via the message broker. This dramatically reduces build time on large projects. The scheduler uses the knowledge graph to determine which tasks are safe to parallelise.

### 16.24 — Explain Mode (8A)
Users can highlight any code in their IDE and ask Forge to explain it. The LSP handler in `lsp/handlers/explain.py` sends the selection to the Reviewer Agent which returns a plain English explanation of what the code does, why it is written that way, and what would break if it were removed. Available in IDE via right-click → "Forge: Explain This" and in CLI via `forge explain`.

### 16.25 — Debug Mode (8B)
The dedicated Debug Agent in `agents/debugger/` receives a stack trace or error message from the user. It analyses the error, traces it to its root cause in the codebase using the knowledge graph, identifies the exact location of the problem, and either applies a fix directly (with permission) or shows the user precisely what to change. Available via `forge debug` or by pasting an error directly into the conversation.

### 16.26 — Changelog Generator (8C)
After each development session, `agents/reviewer/changelog_generator.py` automatically generates a human-readable changelog entry describing what was built or changed. Entries accumulate in a `CHANGELOG.md` at the project root. The user gets a complete project changelog without any manual effort.

### 16.27 — Learn Mode / Style Learner (8D)
The Coder Agent's `style_learner.py` analyses the existing codebase before writing new code — observing error handling patterns, naming conventions, file structure preferences, comment style, and architectural choices. All generated code mirrors these patterns. New code feels native to the project, not like it was written by a different author.

---

## 17. Updated Phased Roadmap

### Phase 1 — Core Foundation
Orchestrator, Intake, Architect, Coder agents. Basic CLI. Filesystem MCP. SQLite. Checkpointing. llama.cpp + Gemma 3 12B. Python, JS, TS output.

### Phase 2 — Quality & Testing
Tester Agent (unit + integration). Patcher Agent. Self-Healing (1A). Review Gate (1B). Dependency Conflict Detection (1C). Terminal MCP. Git MCP (optional). ChromaDB. Windows support. Expanded language support.

### Phase 3 — Intelligence Layer
Security Agent (1D). Knowledge Graph (2A). Tech Debt Detector (2C). Reviewer/Suggester Agent. Debug Mode (8B). Explain Mode (8A). Learn Mode (8D). Multi-session + LSP + IDE extensions.

### Phase 4 — Team & Collaboration
Team server mode. Session Handoff (4A). Activity Feed (4B). Conflict Prevention (4C). Rollback System (6C). Changelog Generator (8C). Presence awareness. Org model endpoint integration.

### Phase 5 — Advanced Features
Mutation Testing (5A). Test Maintenance (5B). Performance Benchmarking (5C). Infrastructure as Code (6A). Environment Management (6B). Prompt Caching (7B). Parallel Execution (7C). Web UI (3A). Voice Input (3B). Project Templates (3C). Interactive Architecture Diagram (3D). Auto-Documentation (2B).

### Phase 6 — Distribution & Polish
Executable installers (.exe, .dmg, .AppImage). Setup wizard. Non-technical founder UX polish. Full deployment template library. Audit log viewer. Multi-model routing (7A).

---

*Specification v1.2 complete. All enhancements incorporated. Ready for Phase 1 implementation.*
