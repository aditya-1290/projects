# MLFF ADK Analytics System

Multi-Agent Database Intelligence using Google ADK, LiteLLM, local GGUF model, PostgreSQL, and MCP Server.

---

## Project Structure

```
fastag_ai_agent/
├── .env                          <- Your config (edit this first)
├── app.py                        <- Terminal 3 - Main FastAPI app
├── skills.md                     <- Pre-written support SQL skills
├── requirements.txt
│
├── mcp_server/                   <- Terminal 2 - Standalone MCP Server
│   ├── main.py
│   ├── db_scanner.py             <- Scans full DB on startup
│   ├── memory_store.py           <- In-memory cache
│   ├── schemas.py
│   ├── security.py
│   └── tools/
│       ├── execute_query.py
│       ├── get_schema.py
│       ├── get_relationships.py
│       └── refresh_cache.py
│
├── agents/
│   ├── orchestrator/             <- Orchestrator Agent
│   │   ├── agent.py
│   │   ├── agent_card.py
│   │   ├── capabilities.json
│   │   ├── prompts.py
│   │   └── skills/
│   │       ├── intent_detection.py
│   │       └── schema_context_selector.py
│   ├── mlff/                     <- MLFF Analytics Agent
│   │   ├── agent.py
│   │   ├── agent_card.py
│   │   ├── capabilities.json
│   │   ├── prompts.py
│   │   └── skills/
│   │       ├── sql_generator.py
│   │       └── result_formatter.py
│   └── support/                  <- Support Agent
│       ├── agent.py
│       ├── agent_card.py
│       ├── prompts.py
│       └── skills/
│           └── skills_reader.py
│
├── core/
│   ├── config.py
│   ├── logger.py
│   ├── session_manager.py
│   ├── mcp_client.py
│   └── llm_client.py
│
├── static/
│   ├── style.css
│   ├── app.js
│   └── charts.js
│
├── templates/
│   └── index.html
│
└── logs/
    ├── success.log
    └── error.log
```

---

## Step 1 - Prerequisites

- Python 3.11 installed
- PostgreSQL running with a database
- Your GGUF model file (gemma-4-E4B-it-Q5_K_M.gguf or similar) downloaded

---

## Step 2 - Create Virtual Environment

Open a terminal inside `D:\kunal_mlff_adk\`

```bash
python -3.11 -m venv .venv
```

Activate it:

**Windows:**
```bash
.venv\Scripts\activate
```

**Mac/Linux:**
```bash
source .venv/bin/activate
```

---

## Step 3 - Install Requirements

```bash
pip install -r requirements.txt
```

If you plan to use llama_cpp_python with GPU (optional, CPU works fine):
```bash
pip install llama-cpp-python
```

Or with CUDA (if you have NVIDIA GPU):
```bash
pip install llama-cpp-python --extra-index-url https://abetlen.github.io/llama-cpp-python/whl/cu121
```

---

## Step 4 - Edit .env

Open `.env` and update these values:

```env
POSTGRES_HOST=127.0.0.1
POSTGRES_PORT=5432
POSTGRES_USER=postgres
POSTGRES_PASSWORD=your_password_here
POSTGRES_DATABASE=your_database_name_here

GGUF_MODEL_PATH=D:\Models\gemma-4-E4B-it-Q5_K_M.gguf
```

Everything else can stay as-is for local development.

---

## Step 5 - Run the 3 Terminals

Open **3 separate terminal windows** inside `D:\kunal_mlff_adk\`
Activate `.venv` in each terminal first.

---

### Terminal 1 - Local LLM Server

```bash
python -m llama_cpp.server --model "D:\Models\gemma-4-E4B-it-Q5_K_M.gguf" --host 127.0.0.1 --port 8001 --chat_format chatml --n_ctx 4096
```

Test it:
```bash
curl http://127.0.0.1:8001/v1/models
```

You should see a JSON response with model info.

> Note: First run may take 30-60 seconds to load the model into memory.

---

### Terminal 2 - MCP Server

```bash
uvicorn mcp_server.main:app --host 127.0.0.1 --port 9000 --reload
```

On startup it will scan your full PostgreSQL database and load everything into memory.
You will see logs like:

```
DB SCAN STARTED
Schemas found: ['public']
Schema 'public': 15 tables
Total tables: 15
DB SCAN COMPLETE - Cache populated.
MCP Server ready.
```

Test it:
```bash
curl http://127.0.0.1:9000/health
curl http://127.0.0.1:9000/schemas -H "x-api-key: local-mcp-key"
```

---

### Terminal 3 - Main App (UI + API)

```bash
uvicorn app:app --host 127.0.0.1 --port 8000 --reload
```

Open your browser:
```
http://127.0.0.1:8000
```

---

## How It Works

```
User Query (UI)
    ↓
POST /query (FastAPI port 8000)
    ↓
Session Manager (creates/resolves session ID)
    ↓
Orchestrator Agent
  ├── Skill: Intent Detection (keyword-based, fast)
  ├── Confidence Scoring (0.0 to 1.0)
  └── Skill: Schema Context Selector (LLM selects relevant tables)
    ↓
MLFF Agent
  ├── Skill: SQL Generator (LLM generates PostgreSQL SQL)
  ├── MCP Client → MCP Server (validates + executes SQL)
  └── Skill: Result Formatter (LLM explains results + suggests chart)
    ↓
FastAPI returns JSON to UI

Support Agent (optional alternate path):
  ├── Matches a user query to pre-written SQL in `skills.md`
  ├── Executes the SQL via MCP Client / MCP Server
  └── Uses the LLM to explain results and recommend the best chart
    ↓
UI renders: query meta, SQL, rows (table), explanation, optional chart
```

---

## DB Scan Behaviour

- DB is scanned **ONCE on MCP server startup**
- All schemas, tables, columns, relationships, indexes, sample data → stored in memory
- No DB scanning during query processing (uses cache only)
- To force rescan: `POST http://127.0.0.1:9000/tools/refresh_cache -H "x-api-key: local-mcp-key"`

---

## UI Features

- **Session History** (left sidebar) - all queries in current session
- **Meta chips** - intent, query type, confidence level, schema, row count
- **Low confidence warning** - if confidence < 0.60
- **SQL panel** - exact SQL generated
- **Explanation panel** - natural language answer
- **Results table** - scrollable, max 50 rows displayed
- **Smart charts** - only shown when data warrants it (bar, line, pie)

---

## Test Queries

**Simple:**
- Show all tables in the database
- List top 10 customers by total amount

**Medium:**
- Show monthly revenue for the last 6 months
- Find customers who made more than 5 purchases

**Complex:**
- Find top 5 products by revenue per category with percentage contribution
- Compare store performance by total revenue and average transaction value

---

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/` | UI |
| POST | `/query` | Main query endpoint |
| GET | `/history/{session_id}` | Session history |
| GET | `/health` | App health |
| GET | `/agent-cards` | Both agent cards |

**MCP Server (port 9000):**

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/health` | Cache status |
| GET | `/cache` | Full in-memory cache |
| GET | `/tools/get_schema` | Schema info |
| POST | `/tools/execute_query` | Execute SQL |
| GET | `/tools/get_relationships` | FK relationships |
| POST | `/tools/refresh_cache` | Force DB rescan |

---

## Logs

All activity is logged to:
- `logs/success.log` - all requests, agent steps, completions
- `logs/error.log` - all errors with context

Log format: `TIMESTAMP | LEVEL | MODULE | [request_id] message`

---

## Common Issues

**"Cannot connect to LLM server"**
→ Terminal 1 not running. Start it and wait for model to fully load.

**"Cannot connect to MCP server"**
→ Terminal 2 not running. Start it.

**"Cannot connect to PostgreSQL"**
→ Check your `.env` POSTGRES_* settings. Make sure PostgreSQL is running.

**"Blocked keyword detected"**
→ LLM tried to generate a non-SELECT query. MLFF agent will retry automatically.

**LLM gives wrong SQL (columns don't exist)**
→ This can happen with very large DBs. The schema context selection picks top relevant tables.
   Try rephrasing your query to be more specific about what data you want.

**Context window error from llama_cpp**
→ Query or schema too long for model. Reduce `--n_ctx` value or use a larger context model.
   Try: `--n_ctx 2048` if 4096 causes memory issues.

---

## Read-Only Safety

The system enforces read-only access:
- Blocked: INSERT, UPDATE, DELETE, DROP, ALTER, CREATE, TRUNCATE, GRANT, REVOKE
- Allowed: SELECT, WITH, EXPLAIN
- Auto LIMIT added to all non-aggregate queries (max 100 rows from DB, 50 shown in UI)

---

## Session Management

Sessions are maintained in-memory per server run.
Each browser session gets a unique `session_id` (UUID).
History is stored per session (max 50 entries).
Sessions are cleared when the server restarts.
