    ## skill: active customers
    keywords: active customers, active customer, how many customers, count customers, customers active, activebool, total active, number of customers
    sql: SELECT COUNT(*) AS active_customer_count FROM customer WHERE activebool = true

    ## skill: top customers by payment
    keywords: top customers, best customers, highest paying, most paying, top customers by payment, customers by payment, show top customers, highest revenue customers, most valuable customers, customer ranking, customers by amount
    sql: SELECT c.first_name || ' ' || c.last_name AS customer_name, SUM(p.amount) AS total_paid FROM payment p JOIN customer c ON p.customer_id = c.customer_id GROUP BY c.customer_id, customer_name ORDER BY total_paid DESC LIMIT 10

    ## skill: total revenue
    keywords: total revenue, total income, total amount, overall revenue, how much earned, total sales, revenue total, sum of payments, total payment, how much revenue, overall income
    sql: SELECT SUM(amount) AS total_revenue FROM payment

    ## skill: monthly revenue
    keywords: monthly revenue, revenue per month, month wise revenue, monthly income, revenue by month, month revenue, revenue trend, monthly sales, revenue monthly, each month revenue
    sql: SELECT DATE_TRUNC('month', payment_date) AS month, SUM(amount) AS revenue FROM payment GROUP BY month ORDER BY month DESC LIMIT 12

    ## skill: top rented films
    keywords: top films, most rented, popular films, best films, most popular movies, top movies, highest rented, most rented films, film ranking, popular movies, top rented, most watched, frequently rented
    sql: SELECT f.title, COUNT(r.rental_id) AS rental_count FROM rental r JOIN inventory i ON r.inventory_id = i.inventory_id JOIN film f ON i.film_id = f.film_id GROUP BY f.film_id, f.title ORDER BY rental_count DESC LIMIT 10

    ## skill: available inventory
    keywords: available inventory, stock, films in stock, inventory count, how many copies, film stock, inventory available, copies available, films available, stock count, inventory levels
    sql: SELECT f.title, COUNT(i.inventory_id) AS copies_available FROM inventory i JOIN film f ON i.film_id = f.film_id GROUP BY f.film_id, f.title ORDER BY copies_available DESC LIMIT 20

    ## skill: store performance
    keywords: store performance, store revenue, store wise, each store, store comparison, store sales, revenue by store, store income, which store, store ranking, store wise revenue, compare stores, store analytics
    sql: SELECT s.store_id, SUM(p.amount) AS total_revenue, COUNT(DISTINCT r.customer_id) AS unique_customers FROM payment p JOIN rental r ON p.rental_id = r.rental_id JOIN inventory i ON r.inventory_id = i.inventory_id JOIN store s ON i.store_id = s.store_id GROUP BY s.store_id ORDER BY total_revenue DESC

    ## skill: overdue rentals
    keywords: overdue, late returns, not returned, pending returns, overdue rentals, unreturned, missing returns, due returns, rentals not returned, who has not returned, late rentals, pending rentals, overdue films
    sql: SELECT c.first_name || ' ' || c.last_name AS customer_name, f.title, r.rental_date, r.return_date FROM rental r JOIN customer c ON r.customer_id = c.customer_id JOIN inventory i ON r.inventory_id = i.inventory_id JOIN film f ON i.film_id = f.film_id WHERE r.return_date IS NULL ORDER BY r.rental_date ASC LIMIT 50
