"""
Orchestrator Agent Card.
Defines identity, capabilities, and routing metadata for the Orchestrator agent.
"""
from dataclasses import dataclass, field
from typing import List


@dataclass
class OrchestratorAgentCard:
    agent_name: str = "orchestrator"
    agent_id: str = "orchestrator_v1"
    version: str = "1.0.0"
    domain: str = "query_routing"
    description: str = (
        "Receives natural language queries, detects intent, classifies query type, "
        "scores confidence, pulls relevant context from in-memory DB cache, "
        "and routes to the MLFF agent with enriched context."
    )
    capabilities: List[str] = field(default_factory=lambda: [
        "intent_detection",
        "query_classification",
        "confidence_scoring",
        "schema_context_selection",
        "agent_routing",
    ])
    limitations: List[str] = field(default_factory=lambda: [
        "Does not execute SQL directly",
        "Does not write to the database",
        "Cannot handle non-database queries",
        "Confidence below 0.60 proceeds with warning",
    ])
    confidence_threshold: float = 0.60
    routes_to: List[str] = field(default_factory=lambda: ["mlff", "support"])
    out_of_scope_message: str = (
        "I can only process natural language queries about the connected PostgreSQL database. "
        "I cannot answer general knowledge questions or write to the database."
    )

    def to_dict(self) -> dict:
        return {
            "agent_name": self.agent_name,
            "agent_id": self.agent_id,
            "version": self.version,
            "domain": self.domain,
            "description": self.description,
            "capabilities": self.capabilities,
            "limitations": self.limitations,
            "confidence_threshold": self.confidence_threshold,
            "routes_to": self.routes_to,
            "out_of_scope_message": self.out_of_scope_message,
        }


ORCHESTRATOR_CARD = OrchestratorAgentCard()
