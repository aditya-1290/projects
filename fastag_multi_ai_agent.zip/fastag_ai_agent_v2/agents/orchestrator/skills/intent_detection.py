"""
Skill: Intent Detection
Detects the intent of a user query using keyword matching + LLM.
"""
import json
import re
from typing import Dict

INTENT_KEYWORDS = {
    "support": [
        "active customers", "top customers", "total revenue", "monthly revenue",
        "top rented", "most rented", "popular films", "available inventory",
        "store performance", "overdue rentals", "late returns", "not returned",
        "best customers", "highest paying", "overall revenue",
        "how many customers", "count customers", "active customer",
    ],
    "aggregation": ["total", "sum", "count", "average", "avg", "maximum", "minimum", "max", "min", "how many", "how much"],
    "ranking": ["top", "bottom", "highest", "lowest", "best", "worst", "most", "least", "rank", "order by"],
    "filtering": ["where", "filter", "find", "show", "get", "with", "having", "only", "specific"],
    "comparison": ["compare", "versus", "vs", "difference", "between", "against"],
    "trend": ["trend", "over time", "monthly", "weekly", "daily", "growth", "change", "increase", "decrease", "history"],
    "lookup": ["who", "what", "which", "detail", "info", "information", "list all", "show all"],
}


def detect_intent_keyword(user_query: str) -> str:
    """Fast keyword-based intent detection — support gets phrase-match priority."""
    query_lower = user_query.lower()

    # Check support first — phrase matches take absolute priority
    for kw in INTENT_KEYWORDS["support"]:
        if kw in query_lower:
            return "support"

    # Then score remaining intents normally
    scores = {intent: 0 for intent in INTENT_KEYWORDS if intent != "support"}
    for intent, keywords in INTENT_KEYWORDS.items():
        if intent == "support":
            continue
        for kw in keywords:
            if kw in query_lower:
                scores[intent] += 1

    best = max(scores, key=scores.get)
    return best if scores[best] > 0 else "lookup"


def classify_query_complexity(user_query: str) -> str:
    """Classify query as simple, medium, or complex based on linguistic cues."""
    query_lower = user_query.lower()

    complex_cues = ["join", "relate", "across", "multiple", "combined", "together", "correlation",
                    "pattern", "trend", "compare", "performance", "analysis", "rank", "percentile"]
    medium_cues = ["group", "category", "per", "each", "top", "filter", "where", "having"]

    complex_count = sum(1 for c in complex_cues if c in query_lower)
    medium_count = sum(1 for c in medium_cues if c in query_lower)

    if complex_count >= 2:
        return "complex"
    elif medium_count >= 1 or complex_count == 1:
        return "medium"
    return "simple"


def score_confidence(intent: str, query_type: str, user_query: str) -> float:
    """
    Score confidence 0.0 to 1.0.
    Based on: intent clarity + query length + keyword density.
    """
    base = 0.65

    # Boost for clear intent signals
    if intent != "unknown":
        base += 0.10

    # Boost for reasonable query length
    words = user_query.split()
    if 4 <= len(words) <= 30:
        base += 0.10
    elif len(words) < 3:
        base -= 0.20

    # Slight penalty for very complex queries (harder to route correctly)
    if query_type == "complex":
        base -= 0.05

    return round(min(max(base, 0.0), 1.0), 2)


def run_intent_detection(user_query: str) -> Dict:
    """
    Run full intent detection pipeline.
    Returns intent, query_type, confidence.
    """
    intent = detect_intent_keyword(user_query)
    query_type = classify_query_complexity(user_query)
    confidence = score_confidence(intent, query_type, user_query)

    return {
        "intent": intent,
        "query_type": query_type,
        "confidence": confidence,
        "confidence_note": (
            f"Low confidence ({confidence}). Query may be ambiguous or too vague. Proceeding anyway."
            if confidence < 0.60 else ""
        ),
    }