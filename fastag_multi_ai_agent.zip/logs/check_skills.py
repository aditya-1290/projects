import os
path = os.path.join("agents", "support", "skills", "skills_reader.py")
dir_name = os.path.dirname(path)
skills_path = os.path.join(dir_name, "", "../..", "..", "logs/skills.md")
print("Resolved path:", os.path.abspath(skills_path))
print("File exists:", os.path.exists(skills_path))
if os.path.exists(skills_path):
    with open(skills_path, "r", encoding="utf-8") as f:
        content = f.read()
    print("File size:", len(content), "bytes")
    print("Contains '## skill:':", content.count("## skill:"))
    print("First 200 chars:", repr(content[:200]))