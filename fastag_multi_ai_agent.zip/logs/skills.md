## skill: active employees
keywords: active employees, employee count, total employees, how many employees, employees active, employee total, number of employees, staff count, headcount, workforce
sql: SELECT COUNT(*) AS employee_count FROM hr.employees


## skill: employees by department
keywords: employees by department, department employees, employee distribution, headcount by department, staff per department, department wise employees, employees in each department
sql: SELECT d.department_name, COUNT(e.employee_id) AS employee_count FROM hr.departments d LEFT JOIN hr.employees e ON d.department_id = e.department_id GROUP BY d.department_name ORDER BY employee_count DESC


## skill: highest paid employees
keywords: highest salary, top salaries, highest paid employees, top paid employees, maximum salary, earners, highest earners, top earners
sql: SELECT e.first_name, e.last_name, s.salary FROM hr.employees e JOIN hr.salaries s ON e.employee_id = s.employee_id ORDER BY s.salary DESC LIMIT 10


## skill: average salary
keywords: average salary, avg salary, mean salary, salary average, typical salary
sql: SELECT ROUND(AVG(salary), 2) AS average_salary, MIN(salary) AS min_salary, MAX(salary) AS max_salary FROM hr.salaries


## skill: total customers
keywords: total customers, customer count, how many customers, customer total, number of customers, client count
sql: SELECT COUNT(*) AS total_customers FROM sales.customers


## skill: top customers by orders
keywords: top customers, best customers, customers by orders, highest orders, loyal customers, frequent customers, repeat customers
sql: SELECT c.customer_name, COUNT(o.order_id) AS total_orders FROM sales.customers c JOIN sales.orders o ON c.customer_id = o.customer_id GROUP BY c.customer_id, c.customer_name ORDER BY total_orders DESC LIMIT 10


## skill: top customers by revenue
keywords: customer revenue, revenue by customer, top revenue customers, highest spending customers, best customers by revenue, customer lifetime value, top spending
sql: SELECT c.customer_name, SUM(p.amount) AS total_revenue FROM sales.customers c JOIN sales.orders o ON c.customer_id = o.customer_id JOIN sales.payments p ON o.order_id = p.order_id GROUP BY c.customer_id, c.customer_name ORDER BY total_revenue DESC LIMIT 20


## skill: total orders
keywords: total orders, order count, number of orders, how many orders, orders total
sql: SELECT COUNT(*) AS total_orders FROM sales.orders


## skill: orders per day
keywords: daily orders, orders per day, order trend, daily sales, orders by date, order volume by day, today's orders
sql: SELECT order_date, COUNT(*) AS orders FROM sales.orders WHERE order_date >= CURRENT_DATE - INTERVAL '30 days' GROUP BY order_date ORDER BY order_date DESC


## skill: top sales employees
keywords: top employees, best sales employees, employee performance, highest sales employee, employee by orders, employees by sales, top performing employees
sql: SELECT e.first_name, e.last_name, COUNT(o.order_id) AS orders_processed FROM hr.employees e JOIN sales.orders o ON e.employee_id = o.employee_id GROUP BY e.employee_id, e.first_name, e.last_name ORDER BY orders_processed DESC LIMIT 10


## skill: total products
keywords: total products, product count, inventory size, how many products, number of products, product total, items count
sql: SELECT COUNT(*) AS total_products FROM inventory.products


## skill: most expensive products
keywords: expensive products, highest price products, costly products, premium products, priciest products, top priced
sql: SELECT product_name, price FROM inventory.products ORDER BY price DESC LIMIT 10


## skill: cheapest products
keywords: cheap products, lowest price products, inexpensive products, budget products, affordable products
sql: SELECT product_name, price FROM inventory.products ORDER BY price ASC LIMIT 10


## skill: low stock products
keywords: low stock, products running out, inventory shortage, stock alerts, low inventory, stock warning, out of stock soon, reorder needed
sql: SELECT p.product_name, s.quantity FROM inventory.stock s JOIN inventory.products p ON s.product_id = p.product_id WHERE s.quantity < 20 ORDER BY s.quantity ASC LIMIT 50


## skill: out of stock products
keywords: out of stock, no inventory, zero stock, unavailable products, stock out
sql: SELECT p.product_name FROM inventory.stock s JOIN inventory.products p ON s.product_id = p.product_id WHERE s.quantity = 0


## skill: total revenue
keywords: total revenue, revenue, income, earnings, total sales amount, total income, total earnings, overall revenue
sql: SELECT SUM(amount) AS total_revenue FROM sales.payments


## skill: average order value
keywords: average order value, avg order amount, order average, mean order value, typical order amount
sql: SELECT ROUND(AVG(amount), 2) AS avg_order_value FROM sales.payments


## skill: monthly revenue
keywords: monthly revenue, revenue by month, sales trend, monthly sales, revenue trend, month revenue, highest revenue month, revenue over time, revenue per month
sql: SELECT TO_CHAR(DATE_TRUNC('month', o.order_date), 'YYYY-MM') AS month, SUM(p.amount) AS total_revenue, COUNT(*) AS order_count FROM sales.orders o JOIN sales.payments p ON o.order_id = p.order_id GROUP BY 1 ORDER BY 1 DESC LIMIT 12


## skill: daily revenue trend
keywords: daily revenue, revenue by day, daily sales amount, revenue per day, day wise revenue
sql: SELECT o.order_date, SUM(p.amount) AS daily_revenue, COUNT(*) AS orders FROM sales.orders o JOIN sales.payments p ON o.order_id = p.order_id GROUP BY o.order_date ORDER BY o.order_date DESC LIMIT 30


## skill: revenue by region
keywords: revenue by region, regional sales, region wise revenue, sales by region, regional performance, state wise revenue
sql: SELECT r.region_name, SUM(p.amount) AS total_revenue FROM sales.regions r JOIN sales.stores s ON r.region_id = s.region_id JOIN sales.orders o ON s.store_id = o.store_id JOIN sales.payments p ON o.order_id = p.order_id GROUP BY r.region_name ORDER BY total_revenue DESC


## skill: total tickets
keywords: ticket count, support tickets, total tickets, how many tickets, ticket total
sql: SELECT COUNT(*) AS total_tickets FROM support.tickets WHERE status_name NOT IN ('RESOLVED')


## skill: tickets by status
keywords: ticket status, tickets by status, support status, open tickets, closed tickets, ticket breakdown, ticket distribution
sql: SELECT ts.status_name, COUNT(*) AS total FROM support.tickets t JOIN support.ticket_status ts ON t.status_id = ts.status_id WHERE ts.status_name IN ('SUCCESS', 'FAILED') GROUP BY ts.status_name ORDER BY total DESC

## skill: average feedback
keywords: feedback score, customer rating, support rating, average rating, satisfaction score, customer satisfaction
sql: SELECT ROUND(AVG(rating), 2) AS avg_rating, COUNT(*) AS total_ratings, MIN(rating) AS min_rating, MAX(rating) AS max_rating FROM support.feedback


## skill: total logs
keywords: log count, application logs, total logs, how many logs, log total
sql: SELECT log_level, COUNT(*) AS total FROM logging.application_logs GROUP BY log_level ORDER BY total DESC


## skill: error logs
keywords: errors, application errors, failures, exceptions, error count, how many errors, error total
sql: SELECT COUNT(*) AS error_count FROM logging.application_logs WHERE log_level = 'ERROR'


## skill: top error services
keywords: error services, failing services, services with errors, most errors, error prone services, unreliable services
sql: SELECT service_name, COUNT(*) AS total_errors FROM logging.application_logs WHERE log_level = 'ERROR' GROUP BY service_name ORDER BY total_errors DESC LIMIT 20


## skill: api response times
keywords: api performance, response time, slow endpoints, api speed, endpoint performance, latency, slow api
sql: SELECT endpoint, method, ROUND(AVG(response_time_ms), 0) AS avg_ms, COUNT(*) AS total_requests, ROUND(AVG(response_time_ms) * 100.0 / NULLIF(MAX(response_time_ms), 0), 1) AS pct_of_slowest FROM logging.api_logs GROUP BY endpoint, method ORDER BY avg_ms DESC LIMIT 15


## skill: system resource usage
keywords: cpu usage, memory usage, disk usage, system resources, server load, system health, resource monitoring, infrastructure
sql: SELECT DATE_TRUNC('hour', recorded_at) AS hour, ROUND(AVG(cpu_usage), 1) AS avg_cpu, ROUND(AVG(memory_usage), 1) AS avg_memory, ROUND(AVG(disk_usage), 1) AS avg_disk FROM logging.system_metrics GROUP BY 1 ORDER BY 1 DESC LIMIT 72


## skill: top performing products
keywords: best selling products, top products, product performance, most sold products, popular products, highest selling
sql: SELECT p.product_name, pp.total_sold, p.price, ROUND(pp.total_sold * p.price, 2) AS total_revenue FROM analytics.product_performance pp JOIN inventory.products p ON pp.product_id = p.product_id ORDER BY pp.total_sold DESC LIMIT 20


## skill: top customers by lifetime value
keywords: lifetime value, ltv, customer value, top customers by value, high value customers, customer lifetime
sql: SELECT c.customer_name, ROUND(cm.lifetime_value, 2) AS lifetime_value FROM analytics.customer_metrics cm JOIN sales.customers c ON cm.customer_id = c.customer_id ORDER BY cm.lifetime_value DESC LIMIT 20


## skill: employee performance ranking
keywords: employee ranking, employee performance, top performers, best employees, employee leaderboard, staff performance
sql: SELECT e.first_name, e.last_name, ep.total_orders FROM analytics.employee_performance ep JOIN hr.employees e ON ep.employee_id = e.employee_id ORDER BY ep.total_orders DESC LIMIT 20


## skill: inventory health
keywords: inventory health, stock status, inventory status, stock levels, warehouse status, stock summary
sql: SELECT p.product_name, p.price, im.stock_remaining, CASE WHEN im.stock_remaining = 0 THEN 'OUT OF STOCK' WHEN im.stock_remaining < 20 THEN 'LOW STOCK' WHEN im.stock_remaining < 100 THEN 'MODERATE' ELSE 'HEALTHY' END AS stock_status FROM analytics.inventory_metrics im JOIN inventory.products p ON im.product_id = p.product_id ORDER BY im.stock_remaining ASC LIMIT 50


## skill: employee ticket load
keywords: support workload, tickets per employee, employee tickets, support load, ticket assignment
sql: SELECT e.first_name, e.last_name, COUNT(t.ticket_id) AS tickets FROM hr.employees e JOIN support.tickets t ON e.employee_id = t.employee_id GROUP BY e.employee_id, e.first_name, e.last_name ORDER BY tickets DESC LIMIT 20


## skill: sales by store
keywords: store sales, sales by store, store performance, store wise sales, shop revenue, outlet performance
sql: SELECT s.store_name, r.region_name, COUNT(o.order_id) AS total_orders, SUM(p.amount) AS total_revenue FROM sales.stores s JOIN sales.regions r ON s.region_id = r.region_id JOIN sales.orders o ON s.store_id = o.store_id JOIN sales.payments p ON o.order_id = p.order_id GROUP BY s.store_name, r.region_name ORDER BY total_revenue DESC LIMIT 20
