-- ═══════════════════════════════════════════════════════════════════
-- FasTag Multi-Agents — Database Migration
-- Run ONCE against enterprisehub database
-- ═══════════════════════════════════════════════════════════════════

-- ── STEP 1: Add missing foreign keys ──────────────────────────────

ALTER TABLE sales.order_items
    ADD CONSTRAINT fk_order_items_product
    FOREIGN KEY (product_id) REFERENCES inventory.products(product_id);

ALTER TABLE toll.transactions
    ADD CONSTRAINT fk_transactions_plaza
    FOREIGN KEY (plaza_id) REFERENCES toll.plazas(plaza_id);

-- ── STEP 2: Populate analytics tables from raw data ──────────────

INSERT INTO analytics.daily_sales
SELECT order_date, SUM(amount) AS total_sales
FROM sales.orders o
JOIN sales.payments p ON o.order_id = p.order_id
GROUP BY order_date
ON CONFLICT DO NOTHING;

INSERT INTO analytics.monthly_sales
SELECT TO_CHAR(DATE_TRUNC('month', order_date), 'YYYY-MM') AS month_name, SUM(amount) AS total_sales
FROM sales.orders o
JOIN sales.payments p ON o.order_id = p.order_id
GROUP BY 1
ON CONFLICT DO NOTHING;

INSERT INTO analytics.product_performance
SELECT oi.product_id, COUNT(*) AS total_sold
FROM sales.order_items oi
GROUP BY oi.product_id
ON CONFLICT DO NOTHING;

INSERT INTO analytics.customer_metrics
SELECT o.customer_id, SUM(p.amount) AS lifetime_value
FROM sales.orders o
JOIN sales.payments p ON o.order_id = p.order_id
GROUP BY o.customer_id
ON CONFLICT DO NOTHING;

INSERT INTO analytics.employee_performance
SELECT employee_id, COUNT(*) AS total_orders
FROM sales.orders
GROUP BY employee_id
ON CONFLICT DO NOTHING;

INSERT INTO analytics.inventory_metrics
SELECT product_id, quantity AS stock_remaining
FROM inventory.stock
ON CONFLICT DO NOTHING;

-- ── STEP 3: Seed logging tables ──────────────────────────────────

-- application_logs: 500 rows
INSERT INTO logging.application_logs (log_timestamp, log_level, service_name, message)
SELECT
    CURRENT_TIMESTAMP - (random() * 30 || ' days')::interval - (random() * 86400 || ' seconds')::interval,
    CASE random()
        WHEN random() < 0.70 THEN 'INFO'
        WHEN random() < 0.88 THEN 'WARNING'
        ELSE 'ERROR'
    END,
    CASE floor(random() * 8)::int
        WHEN 0 THEN 'TollPlazaAPI'
        WHEN 1 THEN 'PaymentGateway'
        WHEN 2 THEN 'VehicleRegistry'
        WHEN 3 THEN 'FastTagService'
        WHEN 4 THEN 'NotificationService'
        WHEN 5 THEN 'AnalyticsEngine'
        WHEN 6 THEN 'AuthServer'
        ELSE 'ReportGenerator'
    END,
    CASE random()
        WHEN random() < 0.3 THEN 'Request processed successfully'
        WHEN random() < 0.5 THEN 'Cache hit for key: session_' || floor(random()*1000)::int
        WHEN random() < 0.65 THEN 'Connection pool stats: active=' || floor(random()*20)::int || ' idle=' || floor(random()*10)::int
        WHEN random() < 0.75 THEN 'Slow query detected: ' || (random()*5000 + 500)::int || 'ms'
        WHEN random() < 0.85 THEN 'Retry attempt ' || floor(random()*3 + 1)::int || ' for external service'
        WHEN random() < 0.92 THEN 'Timeout while connecting to upstream service'
        ELSE 'Null pointer exception in request handler'
    END
FROM generate_series(1, 500);

-- error_logs: 60 rows
INSERT INTO logging.error_logs (error_timestamp, service_name, error_message, stack_trace)
SELECT
    CURRENT_TIMESTAMP - (random() * 30 || ' days')::interval,
    CASE floor(random() * 5)::int
        WHEN 0 THEN 'TollPlazaAPI'
        WHEN 1 THEN 'PaymentGateway'
        WHEN 2 THEN 'FastTagService'
        WHEN 3 THEN 'AuthServer'
        ELSE 'ReportGenerator'
    END,
    CASE random()
        WHEN random() < 0.3 THEN 'Connection refused: upstream service unavailable'
        WHEN random() < 0.5 THEN 'Timeout after 30000ms waiting for response'
        WHEN random() < 0.7 THEN 'HTTP 503 Service Unavailable from payment provider'
        WHEN random() < 0.85 THEN 'Database connection pool exhausted'
        ELSE 'Unexpected null value in transaction response'
    END,
    'Traceback (most recent call last):\n  File "service/handler.py", line ' || (random()*200+50)::int || '\n    result = await process_request()\n' ||
    '  File "service/client.py", line ' || (random()*150+20)::int || '\n    response = await httpx.post(url)\n' ||
    'Exception: ' ||
    CASE random()
        WHEN random() < 0.5 THEN 'ConnectionError'
        ELSE 'TimeoutError'
    END
FROM generate_series(1, 60);

-- api_logs: 300 rows
INSERT INTO logging.api_logs (request_time, endpoint, method, status_code, response_time_ms)
SELECT
    CURRENT_TIMESTAMP - (random() * 14 || ' days')::interval - (random() * 86400 || ' seconds')::interval,
    CASE floor(random() * 6)::int
        WHEN 0 THEN '/api/query'
        WHEN 1 THEN '/api/agents'
        WHEN 2 THEN '/api/health'
        WHEN 3 THEN '/api/history/'
        WHEN 4 THEN '/tools/execute_query'
        ELSE '/cache'
    END,
    CASE floor(random() * 3)::int
        WHEN 0 THEN 'GET'
        WHEN 1 THEN 'POST'
        ELSE 'GET'
    END,
    CASE random()
        WHEN random() < 0.85 THEN 200
        WHEN random() < 0.92 THEN 400
        WHEN random() < 0.97 THEN 401
        ELSE 500
    END,
    CASE random()
        WHEN random() < 0.7 THEN floor(random() * 200 + 10)::int
        WHEN random() < 0.9 THEN floor(random() * 2000 + 500)::int
        ELSE floor(random() * 10000 + 2000)::int
    END
FROM generate_series(1, 300);

-- audit_events: 100 rows
INSERT INTO logging.audit_events (event_time, user_id, event_type, entity_name, entity_id, description)
SELECT
    CURRENT_TIMESTAMP - (random() * 30 || ' days')::interval,
    floor(random() * 100 + 1)::int,
    CASE floor(random() * 4)::int
        WHEN 0 THEN 'LOGIN'
        WHEN 1 THEN 'QUERY_EXECUTE'
        WHEN 2 THEN 'DATA_EXPORT'
        ELSE 'CONFIG_CHANGE'
    END,
    CASE floor(random() * 4)::int
        WHEN 0 THEN 'user_accounts'
        WHEN 1 THEN 'sales.orders'
        WHEN 2 THEN 'toll.transactions'
        ELSE 'system_config'
    END,
    floor(random() * 50000 + 1)::int,
    CASE random()
        WHEN random() < 0.4 THEN 'User logged in successfully'
        WHEN random() < 0.6 THEN 'SQL query executed: SELECT COUNT(*) FROM...'
        WHEN random() < 0.8 THEN 'Exported data to CSV'
        ELSE 'Updated system configuration parameter'
    END
FROM generate_series(1, 100);

-- system_metrics: 720 rows (one per hour for 30 days)
INSERT INTO logging.system_metrics (recorded_at, cpu_usage, memory_usage, disk_usage)
SELECT
    CURRENT_TIMESTAMP - (720 - g) || ' hours' :: interval,
    round((20 + random() * 60)::numeric, 2),
    round((40 + random() * 40)::numeric, 2),
    round((30 + random() * 50)::numeric, 2)
FROM generate_series(1, 720) g;

-- ── STEP 4: Add more toll vehicles (50 total) ───────────────────

INSERT INTO toll.vehicles (registration_no, owner_name, vehicle_type, fastag_id)
SELECT
    UPPER(SUBSTRING('ABCDEFGHJKLMNPQRSTUVWXYZ', floor(random()*23+1)::int, 1)) ||
    UPPER(SUBSTRING('ABCDEFGHJKLMNPQRSTUVWXYZ', floor(random()*23+1)::int, 1)) ||
    '-' || LPAD(floor(random()*99+1)::int::text, 2, '0') ||
    '-' || UPPER(SUBSTRING('ABCDEFGHJKLMNPQRSTUVWXYZ', floor(random()*23+1)::int, 1)) ||
    UPPER(SUBSTRING('ABCDEFGHJKLMNPQRSTUVWXYZ', floor(random()*23+1)::int, 1)) ||
    '-' || LPAD(floor(random()*9000+1000)::int::text, 4, '0'),
    'Owner_' || g,
    (ARRAY['Car', 'Car', 'Car', 'Bus', 'Truck', 'Motorcycle'])[floor(random()*6 + 1)::int],
    'FT-' || (1000 + g)::text
FROM generate_series(6, 50) g;

-- ── STEP 5: Generate 1000 toll transactions over 90 days ─────────

INSERT INTO toll.transactions (vehicle_id, plaza_id, transaction_date, amount, status, payment_method, failure_reason)
SELECT
    floor(random() * 50 + 1)::int,
    floor(random() * 3 + 1)::int,
    TIMESTAMP '2026-03-18 00:00:00' + (random() * 90 || ' days')::interval + (random() * 16 || ' hours')::interval + (random() * 3600 || ' seconds')::interval,
    CASE floor(random() * 5)::int
        WHEN 0 THEN round((35 + random() * 15)::numeric, 2)    -- Motorcycle: 35-50
        WHEN 1 THEN round((70 + random() * 30)::numeric, 2)    -- Car: 70-100
        WHEN 2 THEN round((70 + random() * 30)::numeric, 2)    -- Car: 70-100
        WHEN 3 THEN round((120 + random() * 60)::numeric, 2)   -- Bus: 120-180
        ELSE round((200 + random() * 150)::numeric, 2)         -- Truck: 200-350
    END,
    CASE random()
        WHEN random() < 0.80 THEN 'SUCCESS'
        WHEN random() < 0.90 THEN 'FAILED'
        WHEN random() < 0.95 THEN 'PENDING'
        ELSE 'REFUNDED'
    END,
    CASE random()
        WHEN random() < 0.72 THEN 'FASTAG'
        WHEN random() < 0.90 THEN 'CASH'
        ELSE 'CARD'
    END,
    CASE
        WHEN random() < 0.80 THEN NULL
        WHEN random() < 0.35 THEN 'Insufficient balance'
        WHEN random() < 0.55 THEN 'Tag not detected'
        WHEN random() < 0.70 THEN 'Low balance'
        WHEN random() < 0.85 THEN 'Network timeout'
        ELSE 'Expired FASTag'
    END
FROM generate_series(1, 1000);

-- ── STEP 6: Generate disputes from failed transactions ───────────

INSERT INTO toll.disputes (transaction_id, vehicle_id, dispute_date, reason, status, resolution_notes)
SELECT
    t.transaction_id,
    t.vehicle_id,
    t.transaction_date + INTERVAL '1 hour',
    CASE floor(random() * 5)::int
        WHEN 0 THEN 'Double charged – amount deducted twice for same plaza crossing'
        WHEN 1 THEN 'Tag not detected but amount deducted from FASTag wallet'
        WHEN 2 THEN 'Incorrect toll amount – charged for truck but vehicle is car'
        WHEN 3 THEN 'Transaction failed at plaza but amount still debited'
        ELSE 'Vehicle not at this plaza – fraudulent transaction detected'
    END,
    CASE random()
        WHEN random() < 0.25 THEN 'OPEN'
        WHEN random() < 0.50 THEN 'IN_PROGRESS'
        WHEN random() < 0.80 THEN 'RESOLVED'
        ELSE 'CLOSED'
    END,
    CASE random()
        WHEN random() < 0.5 THEN 'Refund processed to FASTag wallet'
        WHEN random() < 0.8 THEN 'Under investigation – awaiting plaza CCTV footage'
        ELSE NULL
    END
FROM toll.transactions t
WHERE t.status IN ('FAILED', 'REFUNDED')
  AND random() < 0.35
  AND NOT EXISTS (SELECT 1 FROM toll.disputes d WHERE d.transaction_id = t.transaction_id);

-- ── STEP 7: Generate chargebacks from disputes ──────────────────

INSERT INTO toll.chargebacks (transaction_id, vehicle_id, amount, chargeback_date, reason, status)
SELECT
    d.transaction_id,
    d.vehicle_id,
    t.amount,
    d.dispute_date + INTERVAL '2 hours',
    d.reason,
    CASE random()
        WHEN random() < 0.35 THEN 'PENDING'
        WHEN random() < 0.75 THEN 'APPROVED'
        ELSE 'REJECTED'
    END
FROM toll.disputes d
JOIN toll.transactions t ON d.transaction_id = t.transaction_id
WHERE random() < 0.30
  AND NOT EXISTS (SELECT 1 FROM toll.chargebacks c WHERE c.transaction_id = d.transaction_id);

-- ── Verify counts ────────────────────────────────────────────────

SELECT 'analytics.daily_sales' AS table_name, COUNT(*) AS rows FROM analytics.daily_sales
UNION ALL SELECT 'analytics.monthly_sales', COUNT(*) FROM analytics.monthly_sales
UNION ALL SELECT 'analytics.product_performance', COUNT(*) FROM analytics.product_performance
UNION ALL SELECT 'analytics.customer_metrics', COUNT(*) FROM analytics.customer_metrics
UNION ALL SELECT 'analytics.employee_performance', COUNT(*) FROM analytics.employee_performance
UNION ALL SELECT 'analytics.inventory_metrics', COUNT(*) FROM analytics.inventory_metrics
UNION ALL SELECT 'logging.application_logs', COUNT(*) FROM logging.application_logs
UNION ALL SELECT 'logging.error_logs', COUNT(*) FROM logging.error_logs
UNION ALL SELECT 'logging.api_logs', COUNT(*) FROM logging.api_logs
UNION ALL SELECT 'logging.audit_events', COUNT(*) FROM logging.audit_events
UNION ALL SELECT 'logging.system_metrics', COUNT(*) FROM logging.system_metrics
UNION ALL SELECT 'toll.vehicles', COUNT(*) FROM toll.vehicles
UNION ALL SELECT 'toll.transactions', COUNT(*) FROM toll.transactions
UNION ALL SELECT 'toll.disputes', COUNT(*) FROM toll.disputes
UNION ALL SELECT 'toll.chargebacks', COUNT(*) FROM toll.chargebacks
ORDER BY table_name;
