/**
 * charts.js
 * Renders Chart.js charts based on agent-suggested chart type and data.
 * Supports: bar, line, pie
 */

const CHART_COLORS = [
  '#00e5ff', '#7c3aed', '#00ff88', '#ffd600', '#ff6b35',
  '#e91e8c', '#4caf50', '#2196f3', '#ff5722', '#9c27b0',
];

function renderChart(chartType, rows, columns) {
  if (currentChartInstance) {
    currentChartInstance.destroy();
    currentChartInstance = null;
  }

  if (!rows || rows.length === 0) return;

  const canvas = document.getElementById('myChart');
  const ctx = canvas.getContext('2d');

  const { labelCol, valueCol, valueCols } = detectColumns(rows, columns);

  if (!labelCol || !valueCol) return;

  const labels = rows.map(r => {
    const v = r[labelCol];
    return v === null || v === undefined ? 'N/A' : String(v).substring(0, 24);
  });

  const maxPoints = 20;
  const trimmedLabels = labels.slice(0, maxPoints);
  const trimmedRows   = rows.slice(0, maxPoints);

  const chartConfig = buildChartConfig(chartType, trimmedLabels, trimmedRows, valueCol, valueCols);

  if (!chartConfig) return;

  currentChartInstance = new Chart(ctx, chartConfig);
}

function detectColumns(rows, columns) {
  if (!columns || !columns.length) {
    columns = Object.keys(rows[0] || {});
  }

  const labelCol = columns.find(col => {
    const val = rows[0]?.[col];
    return isNaN(Number(val)) || typeof val === 'string';
  }) || columns[0];

  const valueCols = columns.filter(col => {
    const val = rows[0]?.[col];
    return col !== labelCol && !isNaN(Number(val)) && val !== null;
  });

  const valueCol = valueCols[0] || columns[1] || columns[0];

  return { labelCol, valueCol, valueCols };
}

function toNumbers(rows, col) {
  return rows.map(r => {
    const v = r[col];
    return v === null || v === undefined ? 0 : Number(v);
  });
}

function buildChartConfig(chartType, labels, rows, valueCol, valueCols) {
  const baseFont = { family: "'JetBrains Mono', monospace", size: 11 };

  const commonScales = {
    x: {
      ticks: { color: '#55556a', font: baseFont, maxRotation: 30 },
      grid: { color: 'rgba(255,255,255,0.04)' },
      border: { color: 'rgba(255,255,255,0.06)' },
    },
    y: {
      ticks: { color: '#55556a', font: baseFont },
      grid: { color: 'rgba(255,255,255,0.04)' },
      border: { color: 'rgba(255,255,255,0.06)' },
    },
  };

  const commonPlugins = {
    legend: {
      labels: { color: '#9898b0', font: baseFont, boxWidth: 10, padding: 16 },
    },
    tooltip: {
      backgroundColor: 'rgba(14,14,21,0.95)',
      titleColor: '#00e5ff',
      bodyColor: '#e8e8f0',
      borderColor: 'rgba(255,255,255,0.1)',
      borderWidth: 1,
      cornerRadius: 8,
      padding: 10,
      titleFont: { family: "'Syne', sans-serif", weight: '700', size: 12 },
      bodyFont: { family: "'JetBrains Mono', monospace", size: 11 },
    },
  };

  if (chartType === 'bar') {
    return {
      type: 'bar',
      data: {
        labels,
        datasets: [{
          label: valueCol,
          data: toNumbers(rows, valueCol),
          backgroundColor: labels.map((_, i) => CHART_COLORS[i % CHART_COLORS.length] + '55'),
          borderColor: labels.map((_, i) => CHART_COLORS[i % CHART_COLORS.length]),
          borderWidth: 1.5,
          borderRadius: 6,
          borderSkipped: false,
          hoverBackgroundColor: labels.map((_, i) => CHART_COLORS[i % CHART_COLORS.length] + '88'),
        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: commonPlugins,
        scales: commonScales,
        animation: { duration: 600, easing: 'easeOutQuart' },
      },
    };
  }

  if (chartType === 'line') {
    const datasets = (valueCols.length > 0 ? valueCols.slice(0, 3) : [valueCol]).map((col, i) => ({
      label: col,
      data: toNumbers(rows, col),
      borderColor: CHART_COLORS[i],
      backgroundColor: CHART_COLORS[i] + '15',
      pointBackgroundColor: CHART_COLORS[i],
      pointBorderColor: 'transparent',
      tension: 0.35,
      fill: i === 0,
      pointRadius: 3,
      pointHoverRadius: 6,
      borderWidth: 2,
    }));

    return {
      type: 'line',
      data: { labels, datasets },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: commonPlugins,
        scales: commonScales,
        animation: { duration: 800, easing: 'easeOutQuart' },
        interaction: { intersect: false, mode: 'index' },
      },
    };
  }

  if (chartType === 'pie') {
    const values = toNumbers(rows, valueCol);
    return {
      type: 'pie',
      data: {
        labels,
        datasets: [{
          data: values,
          backgroundColor: labels.map((_, i) => CHART_COLORS[i % CHART_COLORS.length] + '99'),
          borderColor: '#0e0e15',
          borderWidth: 2,
          hoverBackgroundColor: labels.map((_, i) => CHART_COLORS[i % CHART_COLORS.length] + 'cc'),
          hoverBorderColor: '#0e0e15',
          hoverOffset: 6,
        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          ...commonPlugins,
          legend: {
            position: 'right',
            labels: { color: '#9898b0', font: baseFont, boxWidth: 10, padding: 14 },
          },
        },
        animation: { duration: 700, easing: 'easeOutQuart' },
      },
    };
  }

  return null;
}

/* ═══════════════════════════════════════════════════════════════
   Visualization Spec Renderer
   ═══════════════════════════════════════════════════════════════ */

const VIZ_COLORS = [
  '#00e5ff', '#7c3aed', '#00ff88', '#ffd600', '#ff6b35',
  '#e91e8c', '#4caf50', '#2196f3', '#ff5722', '#9c27b0',
];

function renderChartFromSpec(canvas, spec, allRows) {
  const { type, x_column, y_columns, options = {} } = spec;
  let chartData;

  if (type === 'scatter') {
    chartData = prepareScatter(allRows, x_column, y_columns);
  } else if (type === 'pie') {
    chartData = prepareCategorical(allRows, x_column, y_columns, true, type);
  } else if (type === 'bar') {
    chartData = prepareCategorical(allRows, x_column, y_columns, false, type);
  } else if (type === 'line') {
    chartData = prepareTimeSeries(allRows, x_column, y_columns);
  }

  if (!chartData) return;

  const config = buildVizConfig(type, chartData, options);
  if (!config) return;

  const instance = new Chart(canvas.getContext('2d'), config);
  chartInstances.push(instance);
}

/* ── Data Preparation Functions ─────────────────────────────────────── */

function prepareCategorical(rows, xCol, yCols, limitTop, type) {   // ← ADD type
  const groups = {};
  rows.forEach(row => {
    const key = String(row[xCol] ?? 'N/A').substring(0, 30);
    if (!groups[key]) groups[key] = { [xCol]: key };
    yCols.forEach(y => {
      groups[key][y] = (groups[key][y] || 0) + Number(row[y] || 0);
    });
  });

  const sorted = Object.values(groups).sort((a, b) => (b[yCols[0]] || 0) - (a[yCols[0]] || 0));

  if (limitTop && sorted.length > 10) {
    const top = sorted.slice(0, 9);
    const others = { [xCol]: 'Others' };
    yCols.forEach(y => {
      others[y] = sorted.slice(9).reduce((s, r) => s + (r[y] || 0), 0);
    });
    sorted.length = 0;
    sorted.push(...top, others);
  }

  return {
    labels: sorted.map(d => d[xCol]),
    datasets: yCols.map((y, i) => ({
      label: y,
      data: sorted.map(d => d[y] || 0),
      backgroundColor: sorted.map((_, j) => VIZ_COLORS[j % VIZ_COLORS.length] + '66'),
      borderColor: sorted.map((_, j) => VIZ_COLORS[j % VIZ_COLORS.length]),
      borderWidth: 1.5,
      borderRadius: type === 'pie' ? 0 : 6,   // now works
      borderSkipped: false,
    })),
  };
}

function prepareTimeSeries(rows, xCol, yCols) {
  const sorted = [...rows].sort((a, b) => {
    const av = a[xCol], bv = b[xCol];
    if (av == null && bv == null) return 0;
    if (av == null) return 1;
    if (bv == null) return -1;
    return av < bv ? -1 : av > bv ? 1 : 0;
  });

  const labels = sorted.map(r => {
    const v = r[xCol];
    if (v === null || v === undefined) return 'N/A';
    const s = String(v);
    return s.length > 16 ? s.substring(0, 16) + '…' : s;
  });

  return {
    labels,
    datasets: yCols.map((y, i) => ({
      label: y,
      data: sorted.map(r => Number(r[y]) || 0),
      borderColor: VIZ_COLORS[i % VIZ_COLORS.length],
      backgroundColor: VIZ_COLORS[i % VIZ_COLORS.length] + '18',
      pointBackgroundColor: VIZ_COLORS[i % VIZ_COLORS.length],
      pointBorderColor: 'transparent',
      pointRadius: 3,
      pointHoverRadius: 6,
      tension: 0.35,
      fill: i === 0,
      borderWidth: 2,
    })),
  };
}

function prepareScatter(rows, xCol, yCols) {
  const xData = rows.map(r => Number(r[xCol]) || 0);
  const yData = rows.map(r => Number(r[yCols[0]]) || 0);
  return {
    datasets: [{
      label: `${yCols[0]} vs ${xCol}`,
      data: xData.map((x, i) => ({ x, y: yData[i] })),
      backgroundColor: VIZ_COLORS[0] + '88',
      borderColor: VIZ_COLORS[0],
      pointRadius: 4,
      pointHoverRadius: 7,
    }],
  };
}

/* ── Config Builder ──────────────────────────────────────────────────── */

function buildVizConfig(type, data, options) {
  const baseFont = { family: "'JetBrains Mono', monospace", size: 11 };

  const commonPlugins = {
    legend: { labels: { color: '#9898b0', font: baseFont, boxWidth: 10, padding: 14 } },
    tooltip: {
      backgroundColor: 'rgba(14,14,21,0.95)',
      titleColor: '#00e5ff',
      bodyColor: '#e8e8f0',
      borderColor: 'rgba(255,255,255,0.1)',
      borderWidth: 1,
      cornerRadius: 8,
      padding: 10,
    },
  };

  const scales = {
    x: {
      ticks: { color: '#55556a', font: baseFont, maxRotation: 30 },
      grid: { color: 'rgba(255,255,255,0.04)' },
      border: { color: 'rgba(255,255,255,0.06)' },
    },
    y: {
      ticks: { color: '#55556a', font: baseFont },
      grid: { color: 'rgba(255,255,255,0.04)' },
      border: { color: 'rgba(255,255,255,0.06)' },
    },
  };

  if (type === 'bar') {
    const isH = options.horizontal || false;
    return {
      type: 'bar',
      data,
      options: {
        indexAxis: isH ? 'y' : 'x',
        responsive: true,
        maintainAspectRatio: false,
        plugins: commonPlugins,
        scales: isH ? { x: { ...scales.y }, y: { ...scales.x } } : scales,
        animation: { duration: 600, easing: 'easeOutQuart' },
      },
    };
  }

  if (type === 'line') {
    return {
      type: 'line',
      data,
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: { intersect: false, mode: 'index' },
        plugins: commonPlugins,
        scales,
        animation: { duration: 800, easing: 'easeOutQuart' },
      },
    };
  }

  if (type === 'pie') {
    return {
      type: 'pie',
      data,
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          ...commonPlugins,
          legend: {
            position: 'right',
            labels: { color: '#9898b0', font: baseFont, boxWidth: 10, padding: 12 },
          },
        },
        animation: { duration: 700, easing: 'easeOutQuart' },
      },
    };
  }

  if (type === 'scatter') {
    return {
      type: 'scatter',
      data,
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: commonPlugins,
        scales: {
          x: { ...scales.x, title: { display: true, color: '#55556a', font: baseFont } },
          y: { ...scales.y, title: { display: true, color: '#55556a', font: baseFont } },
        },
        animation: { duration: 600, easing: 'easeOutQuart' },
      },
    };
  }

  return null;
}
