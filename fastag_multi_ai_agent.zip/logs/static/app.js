/* static/app.js */
let SESSION_ID = null;
let currentChartInstance = null;
let chartInstances = [];         // ADD THIS LINE
let lastQuery = '';

const queryInput      = document.getElementById('queryInput');
const sendBtn         = document.getElementById('sendBtn');
const sendLabel       = document.getElementById('sendLabel');
const sendSpinner     = document.getElementById('sendSpinner');
const resultArea      = document.getElementById('resultArea');
const welcomeState    = document.getElementById('welcomeState');
const metaIntent      = document.getElementById('metaIntent');
const metaType        = document.getElementById('metaType');
const metaConfidence  = document.getElementById('metaConfidence');
const metaSchema      = document.getElementById('metaSchema');
const metaRows        = document.getElementById('metaRows');
const lowConfWarning  = document.getElementById('lowConfidenceWarning');
const errorBox        = document.getElementById('errorBox');
const sqlOutput       = document.getElementById('sqlOutput');
const explanationOut  = document.getElementById('explanationOutput');
const explanationCard = document.getElementById('explanationCard');
const tableHead       = document.getElementById('tableHead');
const tableBody       = document.getElementById('tableBody');
const rowCountLabel   = document.getElementById('rowCountLabel');
const chartCard       = document.getElementById('chartCard');
const chartReasonEl   = document.getElementById('chartReason');
const historyList     = document.getElementById('historyList');
const agentBadge      = document.getElementById('agentBadge');

async function checkStatus() {
  const dot  = document.getElementById('statusDot');
  const text = document.getElementById('statusText');
  try {
    const r = await fetch('/health');
    if (r.ok) {
      dot.className = 'status-dot online';
      text.textContent = 'System Online';
    } else {
      throw new Error();
    }
  } catch {
    dot.className = 'status-dot offline';
    text.textContent = 'Offline';
  }
}
checkStatus();

queryInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendQuery();
  }
});

queryInput.addEventListener('input', () => {
  queryInput.style.height = 'auto';
  queryInput.style.height = Math.min(queryInput.scrollHeight, 120) + 'px';
});

document.getElementById('explanationToggle')?.addEventListener('click', () => {
  if (explanationCard) explanationCard.classList.toggle('open');
});

document.getElementById('suggestions')?.addEventListener('click', (e) => {
  const chip = e.target.closest('.suggestion-chip');
  if (!chip) return;
  queryInput.value = chip.dataset.query;
  queryInput.focus();
  queryInput.style.height = 'auto';
  queryInput.style.height = queryInput.scrollHeight + 'px';
});

document.getElementById('copySqlBtn')?.addEventListener('click', () => {
  const sql = sqlOutput.textContent;
  if (!sql || sql.startsWith('--')) return;
  navigator.clipboard.writeText(sql).then(() => {
    const btn = document.getElementById('copySqlBtn');
    const label = btn.querySelector('.copy-label');
    label.textContent = 'Copied!';
    btn.classList.add('copied');
    setTimeout(() => {
      label.textContent = 'Copy';
      btn.classList.remove('copied');
    }, 1800);
  });
});

document.getElementById('retryBtn')?.addEventListener('click', () => {
  if (lastQuery) {
    queryInput.value = lastQuery;
    sendQuery();
  }
});

document.getElementById('clearHistoryBtn')?.addEventListener('click', () => {
  historyList.innerHTML = '<div class="history-empty">No queries yet</div>';
});

async function sendQuery() {
  const query = queryInput.value.trim();
  if (!query) return;

  const agent = document.getElementById('agentSelect').value || 'auto';
  lastQuery = query;

  setLoading(true);
  clearResult();

  if (welcomeState) welcomeState.classList.add('hidden');
  resultArea.classList.remove('hidden');

  try {
    const resp = await fetch('/query', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: query, session_id: SESSION_ID, agent: agent }),
    });

    if (!resp.ok) {
      const txt = await resp.text();
      throw new Error(txt || `HTTP ${resp.status}`);
    }

    const data = await resp.json();
    SESSION_ID = data.session_id || SESSION_ID;

    renderResult(data, query);
    addToHistorySidebar(query, data);

  } catch (err) {
    showError(err.message || 'Request failed. Check that all 3 terminals are running.');
    resultArea.classList.remove('hidden');
  } finally {
    setLoading(false);
  }
}

function renderResult(data, query) {
  resultArea.classList.remove('hidden');

  /* ── Agent badge ── */
  const handledBy = data.handled_by || '';
  if (handledBy && agentBadge) {
    const labels = {
      mlff: 'MLFF Agent',
      support: 'Support Agent',
      dispute: 'Dispute Agent',
      orchestrator: 'Orchestrator',
    };
    agentBadge.textContent = labels[handledBy] || handledBy;
    agentBadge.className = 'agent-badge agent-' + handledBy;
    agentBadge.classList.remove('hidden');
  } else if (agentBadge) {
    agentBadge.classList.add('hidden');
  }

  /* ── Meta chips ── */
  metaIntent.textContent    = `Intent: ${data.intent || 'N/A'}`;
  metaType.textContent      = `Type: ${data.query_type || 'N/A'}`;
  metaSchema.textContent    = `Schema: ${data.selected_schema || 'N/A'}`;
  metaRows.textContent      = `Rows: ${data.row_count ?? 0}`;

  const conf = data.confidence ?? 0;
  metaConfidence.textContent = `Confidence: ${(conf * 100).toFixed(0)}%`;
  metaConfidence.className = 'meta-chip confidence-chip ' + confidenceClass(conf);

  if (data.low_confidence && data.confidence_note) {
    lowConfWarning.textContent = '⚠ ' + data.confidence_note;
    lowConfWarning.classList.remove('hidden');
  } else {
    lowConfWarning.classList.add('hidden');
  }

  if (!data.ok || data.error) {
    showError(data.error || data.explanation || 'An error occurred.');
    if (data.sql) sqlOutput.textContent = data.sql;
    return;
  }

  errorBox.classList.add('hidden');
  sqlOutput.textContent = data.sql || '-- No SQL generated';

  explanationOut.textContent = data.explanation || 'No explanation available.';
  if (explanationCard) {
    if (!explanationCard.classList.contains('open')) {
      if (historyList.querySelectorAll('.history-item').length === 0) {
        explanationCard.classList.add('open');
      }
    }
  }

  renderTable(data.columns || [], data.rows || []);
  rowCountLabel.textContent = `${data.row_count} row${data.row_count !== 1 ? 's' : ''}`;

    /* ── Visualization ── */
  if (data.viz && (data.viz.charts?.length > 0 || data.viz.kpi_cards?.length > 0)) {
    renderVizSpec(data.viz, data.rows);
  } else if (data.chart_type && data.chart_type !== 'none' && data.chart_type !== 'table' && data.rows?.length > 0) {
    chartCard.style.display = 'block';
    chartReasonEl.textContent = data.chart_reason || '';
    renderChart(data.chart_type, data.rows, data.columns);
  } else {
    chartCard.style.display = 'none';
  }
}

function renderVizSpec(viz, allRows) {
  const kpiContainer = document.getElementById('kpiContainer');
  const chartsContainer = document.getElementById('chartsContainer');

  /* Store col_types for the table renderer */
  window._lastVizSpec = viz;

  /* ── KPI Cards ── */
  if (viz.kpi_cards && viz.kpi_cards.length > 0) {
    kpiContainer.innerHTML = viz.kpi_cards.map(kpi => {
      const val = kpi.computed !== undefined ? kpi.value : (allRows[kpi.row]?.[kpi.column] ?? '—');
      const formatted = formatKPI(val, kpi.format);
      return `<div class="kpi-card">
        <div class="kpi-label">${escapeHtml(kpi.label)}</div>
        <div class="kpi-value ${kpi.format}">${formatted}</div>
      </div>`;
    }).join('');
    kpiContainer.classList.remove('hidden');
  } else {
    kpiContainer.classList.add('hidden');
  }

  /* ── Charts ── */
  if (viz.charts && viz.charts.length > 0) {
    chartsContainer.innerHTML = viz.charts.map((spec, i) => {
      const title = spec.title || 'Chart';
      const reason = spec.options?.reason || '';
      return `<div class="card">
        <div class="card-label-row">
          <span class="card-label">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>
            ${escapeHtml(title)}
          </span>
          ${reason ? `<span class="chart-reason">${escapeHtml(reason)}</span>` : ''}
        </div>
        <div class="chart-wrap"><canvas id="vizChart_${i}"></canvas></div>
      </div>`;
    }).join('');

    chartsContainer.classList.remove('hidden');

    /* Render each chart */
    viz.charts.forEach((spec, i) => {
      const canvas = document.getElementById(`vizChart_${i}`);
      if (canvas) renderChartFromSpec(canvas, spec, allRows);
    });
  } else {
    chartsContainer.classList.add('hidden');
  }
}

function formatKPI(value, format) {
  const num = Number(value);
  if (format === 'currency') {
    if (isNaN(num)) return String(value);
    return '₹' + num.toLocaleString('en-IN', { maximumFractionDigits: 2, minimumFractionDigits: 0 });
  }
  if (format === 'percent') {
    return isNaN(num) ? String(value) : num.toFixed(1) + '%';
  }
  if (format === 'number') {
    return isNaN(num) ? String(value) : num.toLocaleString('en-IN');
  }
  return String(value);
}

function renderTable(columns, rows) {
  tableHead.innerHTML = '';
  tableBody.innerHTML = '';

  /* Use viz-specified columns if available, otherwise use all columns */
  let displayCols = columns;
  const viz = window._lastVizSpec;
  if (viz && viz.table_display_columns && viz.table_display_columns.length > 0) {
    displayCols = viz.table_display_columns;
  }

  if (!displayCols.length && rows.length) {
    displayCols = Object.keys(rows[0]);
  }
  if (!displayCols.length) return;

  const colTypes = viz?.col_types || {};
  const numericCols = new Set();

  if (rows.length > 0 && colTypes && Object.keys(colTypes).length > 0) {
    displayCols.forEach(col => {
      if (colTypes[col]?.type === 'numeric') numericCols.add(col);
    });
  } else {
    /* Fallback: auto-detect numeric */
    if (rows.length > 0) {
      displayCols.forEach(col => {
        const val = rows[0][col];
        if (val !== null && val !== undefined && !isNaN(Number(val)) && typeof val !== 'string') {
          numericCols.add(col);
        }
      });
    }
  }

  const tr = document.createElement('tr');
  displayCols.forEach(col => {
    const th = document.createElement('th');
    th.textContent = col;
    tr.appendChild(th);
  });
  tableHead.appendChild(tr);

  rows.forEach(row => {
    const tr = document.createElement('tr');
    displayCols.forEach(col => {
      const td = document.createElement('td');
      const val = row[col];
      td.textContent = val === null || val === undefined ? '—' : String(val);
      td.title = td.textContent;
      if (numericCols.has(col)) td.classList.add('num-cell');
      tr.appendChild(td);
    });
    tableBody.appendChild(tr);
  });
}

function addToHistorySidebar(query, data) {
  const empty = historyList.querySelector('.history-empty');
  if (empty) empty.remove();

  const item = document.createElement('div');
  item.className = `history-item ${data.ok ? 'history-ok' : 'history-fail'}`;

  const ts = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const agent = data.handled_by || '';
  item.innerHTML = `
    <div class="history-query">${escapeHtml(query)}</div>
    <div class="history-meta">${ts} · ${data.row_count ?? 0} rows · ${((data.confidence ?? 0) * 100).toFixed(0)}%${agent ? ' · ' + agent : ''}</div>
  `;

  item.onclick = () => {
    queryInput.value = query;
    queryInput.focus();
    queryInput.style.height = 'auto';
    queryInput.style.height = queryInput.scrollHeight + 'px';
  };

  historyList.prepend(item);
}

function setLoading(on) {
  sendBtn.disabled = on;
  sendLabel.textContent = on ? 'Running…' : 'Run Query';
  sendSpinner.classList.toggle('hidden', !on);
}

function clearResult() {
  errorBox.classList.add('hidden');
  lowConfWarning.classList.add('hidden');
  sqlOutput.textContent = '';
  explanationOut.textContent = '';
  if (explanationCard) explanationCard.classList.remove('open');
  if (agentBadge) agentBadge.classList.add('hidden');
  tableHead.innerHTML = '';
  tableBody.innerHTML = '';
  chartCard.style.display = 'none';
  document.getElementById('kpiContainer').innerHTML = '';
  document.getElementById('kpiContainer').classList.add('hidden');
  document.getElementById('chartsContainer').innerHTML = '';
  document.getElementById('chartsContainer').classList.add('hidden');
  chartInstances.forEach(c => c.destroy());
  chartInstances = [];
  if (currentChartInstance) { currentChartInstance.destroy(); currentChartInstance = null; }
  window._lastVizSpec = null;
}

function showError(msg) {
  errorBox.textContent = '✖ ' + msg;
  errorBox.classList.remove('hidden');
}

function confidenceClass(conf) {
  if (conf >= 0.75) return 'high';
  if (conf >= 0.60) return 'medium';
  return 'low';
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

async function loadAgents() {
  try {
    const resp = await fetch('/agents');
    const agents = await resp.json();
    const select = document.getElementById('agentSelect');
    select.innerHTML = '<option value="auto">🤖 Auto — pick best agent</option>';
    agents.forEach(agent => {
      const option = document.createElement('option');
      option.value = agent.agent_id;
      const desc = agent.description || '';
      option.textContent = desc.length > 45 ? desc.substring(0, 42) + '…' : desc;
      select.appendChild(option);
    });
  } catch (err) {
    console.warn('Could not load agent list', err);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  checkStatus();
  loadAgents();
});
