import os
import re
from typing import Any, Dict, List

import psycopg2
import psycopg2.extras
from dotenv import load_dotenv

load_dotenv()

# Blocked SQL keywords - read only enforcement
BLOCKED_KEYWORDS = re.compile(
    r"\b(INSERT|UPDATE|DELETE|DROP|ALTER|CREATE|TRUNCATE|GRANT|REVOKE|REPLACE|MERGE|UPSERT|EXEC|EXECUTE|CALL)\b",
    re.IGNORECASE,
)

DEFAULT_ROW_LIMIT = 100


def _get_conn():
    return psycopg2.connect(
        host=os.getenv("POSTGRES_HOST", "127.0.0.1"),
        port=int(os.getenv("POSTGRES_PORT", "5433")),
        user=os.getenv("POSTGRES_USER", "postgres"),
        password=os.getenv("POSTGRES_PASSWORD", "root_123"),
        dbname=os.getenv("POSTGRES_DATABASE", "dvdrental_rst"),
    )


def _is_safe_sql(query: str) -> tuple[bool, str]:
    """Check if SQL is read-only."""
    stripped = query.strip().lstrip(";").strip()
    match = BLOCKED_KEYWORDS.search(stripped)
    if match:
        return False, f"Blocked keyword detected: {match.group().upper()}"

    # Must start with SELECT, WITH, or EXPLAIN
    first_word = stripped.split()[0].upper() if stripped.split() else ""
    if first_word not in ("SELECT", "WITH", "EXPLAIN"):
        return False, f"Only SELECT/WITH/EXPLAIN queries are allowed. Got: {first_word}"

    return True, "ok"


def execute_query(query: str, params: Dict[str, Any] = None) -> Dict[str, Any]:
    """
    Execute a parameterized read-only SQL query against PostgreSQL.
    Returns rows as list of dicts.
    """
    safe, reason = _is_safe_sql(query)
    if not safe:
        return {"ok": False, "error": reason, "rows": [], "row_count": 0}

    conn = None
    try:
        conn = _get_conn()
        cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        # Inject LIMIT if not present (safety cap)
        q = query.strip().rstrip(";")
        if "LIMIT" not in q.upper():
            q = f"{q} LIMIT {DEFAULT_ROW_LIMIT}"

        cur.execute(q, params or {})
        rows: List[Dict] = [dict(r) for r in cur.fetchall()]

        # Convert non-serializable types to str
        for row in rows:
            for k, v in row.items():
                if not isinstance(v, (str, int, float, bool, type(None))):
                    row[k] = str(v)

        return {
            "ok": True,
            "rows": rows,
            "row_count": len(rows),
            "columns": list(rows[0].keys()) if rows else [],
        }

    except Exception as e:
        return {"ok": False, "error": str(e), "rows": [], "row_count": 0}
    finally:
        if conn:
            conn.close()
