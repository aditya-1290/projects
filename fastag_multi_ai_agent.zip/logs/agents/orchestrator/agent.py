"""
Orchestrator Agent – pure intent detection, no routing.
"""
import os
import warnings
os.environ["OTEL_SDK_DISABLED"] = "true"
warnings.filterwarnings("ignore", category=UserWarning, module="google.adk")

import json
# import asyncio
from typing import Any, Dict

from dotenv import load_dotenv
from google.adk.agents import LlmAgent
from google.adk.models.lite_llm import LiteLlm
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService

from agents.orchestrator.agent_card import ORCHESTRATOR_CARD
from agents.orchestrator.skills.intent_detection import run_intent_detection
from core.tool_call_parser import set_tools_map, make_tool
from core.logger import get_logger, success_logger, error_logger

load_dotenv()
logger = get_logger("orchestrator")

os.environ["OPENAI_API_KEY"] = os.getenv("LOCAL_LLM_API_KEY", "sk-local")
os.environ["OPENAI_API_BASE"] = os.getenv("LOCAL_LLM_BASE_URL", "http://127.0.0.1:8001/v1")

_model = LiteLlm(model=f"openai/{os.getenv('LOCAL_LLM_MODEL', 'local-model')}")


# ── Tool function ─────────────────────────────────────────────────
def detect_query_intent(user_query: str) -> str:
    result = run_intent_detection(user_query)
    logger.info(f"Intent detected: {result}")
    return json.dumps(result)


wrapped_detect_intent = make_tool(detect_query_intent)
_TOOLS_MAP = {"detect_query_intent": detect_query_intent}
set_tools_map(_TOOLS_MAP)

ORCHESTRATOR_INSTRUCTION = """
You are the Orchestrator Agent. Your only job is to call the tool:
detect_query_intent(user_query="<EXACT USER QUERY>")

After the tool returns, output ONLY this JSON:
{
  "intent": "<from tool>",
  "query_type": "<from tool>",
  "confidence": <from tool>
}
Do NOT add any other text.
"""

orchestrator_llm_agent = LlmAgent(
    name="orchestrator",
    model=_model,
    description=ORCHESTRATOR_CARD.description,
    instruction=ORCHESTRATOR_INSTRUCTION,
    tools=[wrapped_detect_intent],
    output_key="orchestrator_result",
)

_session_service = InMemorySessionService()


# ── Simplified bridge that ONLY runs intent detection ─────────────
MAX_BRIDGE_ITERATIONS = 5

async def _run_with_bridge(
    session_service, user_id, session_id, initial_message,
    app_name="mlff_adk", query_id="",
):
    from google.genai import types
    from core.tool_call_parser import (
        parse_tool_call, execute_parsed_tool,
        detect_tool_call, detect_batch_tool_calls, parse_batch_tool_calls,
    )

    tool_results = {}
    iterations = 0
    current_message = initial_message

    while iterations < MAX_BRIDGE_ITERATIONS:
        iterations += 1
        session_id_iter = f"orch_{session_id}_{query_id}_iter{iterations}"
        await session_service.create_session(
            app_name=app_name,
            user_id=user_id,
            session_id=session_id_iter,
        )

        fresh_runner = Runner(
            agent=orchestrator_llm_agent,
            app_name=app_name,
            session_service=session_service,
        )

        message = types.Content(role="user", parts=[types.Part(text=current_message)])
        raw_text = ""
        gen = fresh_runner.run_async(user_id=user_id, session_id=session_id_iter, new_message=message)

        try:
            async for event in gen:
                if event.is_final_response():
                    if event.content and event.content.parts:
                        raw_text = event.content.parts[0].text or ""
                    await gen.aclose()
                    break
        except Exception as e:
            if "created in a different Context" not in str(e):
                logger.error(f"Unexpected error: {e}")

        if not raw_text:
            break

        if detect_batch_tool_calls(raw_text):
            parsed_list = parse_batch_tool_calls(raw_text)
            if parsed_list:
                for parsed in parsed_list:
                    tool_result = await execute_parsed_tool(parsed, _TOOLS_MAP)
                    if tool_result:
                        tool_results[parsed['tool_name']] = tool_result
        elif detect_tool_call(raw_text):
            parsed = parse_tool_call(raw_text)
            if parsed:
                tool_result = await execute_parsed_tool(parsed, _TOOLS_MAP)
                if tool_result:
                    tool_results[parsed['tool_name']] = tool_result

        # As soon as we have the intent, return it
        if "detect_query_intent" in tool_results:
            return json.dumps(json.loads(tool_results["detect_query_intent"]))

    # If LLM didn't call the tool, run it directly
    logger.info("[BRIDGE] Running intent detection directly")
    intent_result = detect_query_intent(initial_message)
    return json.dumps(json.loads(intent_result))


async def run_orchestrator_async(
    user_query: str, session_id: str, user_id: str = "mlff_user"
) -> Dict[str, Any]:
    import uuid
    query_id = uuid.uuid4().hex[:8]
    final_text = await _run_with_bridge(
        session_service=_session_service,
        user_id=user_id,
        session_id=session_id,
        initial_message=user_query,
        query_id=query_id,
    )
    payload = json.loads(final_text)
    payload["user_query"] = user_query
    return payload
