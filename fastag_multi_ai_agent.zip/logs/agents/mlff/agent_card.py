"""
MLFF Agent Card.
Multi-Lane Free Flow analytics agent.
"""
from dataclasses import dataclass, field
from typing import List


@dataclass
class MLFFAgentCard:
    agent_name: str = "mlff"
    agent_id: str = "mlff"
    version: str = "1.0.0"
    domain: str = "data_analytics"
    description: str = (
        "Multi-Lane Free Flow analytics agent. "
        "Receives routed queries with DB context from Orchestrator, "
        "generates optimized PostgreSQL SQL, executes via MCP server, "
        "and returns structured results with explanation."
    )
    capabilities: List[str] = field(default_factory=lambda: [
        "sql_generation",
        "table_selection",
        "schema_understanding",
        "query_execution_via_mcp",
        "result_formatting",
        "natural_language_explanation",
        "chart_type_suggestion",
    ])
    keywords: List[str] = field(default_factory=lambda: [
        "sales", "orders", "customers", "revenue", "payment", "order items",
        "regions", "stores", "employees", "staff", "inventory",
    ])
    handled_intents: List[str] = field(default_factory=lambda: [
        "lookup", "aggregation", "ranking", "filtering", "comparison", "trend",
    ])
    limitations: List[str] = field(default_factory=lambda: [
        "Read-only database access",
        "Cannot write, modify, or delete database records",
        "Depends on MCP server for SQL execution",
        "Context limited to selected tables from Orchestrator",
        "MAX_ROWS_RETURNED: 100",
    ])
    preconditions: List[str] = field(default_factory=lambda: [
        "orchestrator_routing_complete",
        "mcp_server_available",
        "schema_context_provided",
    ])
    required_skills: List[str] = field(default_factory=lambda: [
        "sql_generator",
        "result_formatter",
    ])
    max_iterations: int = 2  # Retry once if SQL fails
    out_of_scope_message: str = (
        "I can only query the connected PostgreSQL database using the provided schema context. "
        "I cannot write data or access external systems."
    )

    def to_dict(self) -> dict:
        return {
            "agent_name": self.agent_name,
            "agent_id": self.agent_id,
            "version": self.version,
            "domain": self.domain,
            "description": self.description,
            "capabilities": self.capabilities,
            "keywords": self.keywords,
            "handled_intents": self.handled_intents,
            "limitations": self.limitations,
            "preconditions": self.preconditions,
            "required_skills": self.required_skills,
            "max_iterations": self.max_iterations,
            "out_of_scope_message": self.out_of_scope_message,
        }


MLFF_CARD = MLFFAgentCard()
AGENT_CARD = MLFF_CARD
