"""
Skill: Skills Reader
Reads skills.md, matches user query to the best skill by keyword scoring,
returns the matched skill name + SQL.
"""
import os
import re
from typing import Optional, Dict, Tuple
from core.logger import get_logger

logger = get_logger("skills_reader")

# Resolve path relative to THIS file, going up to project root
_SKILLS_MD_PATH = os.path.normpath(
    os.path.join(os.path.dirname(__file__), "..", "..", "..", "skills.md")
)

# Module-level cache
_skills_cache: list = None
_cache_mtime: float = 0


def _read_file_mtime() -> float:
    try:
        return os.path.getmtime(_SKILLS_MD_PATH)
    except OSError:
        return 0


def load_skills() -> list:
    global _skills_cache, _cache_mtime

    current_mtime = _read_file_mtime()

    if _skills_cache is not None and current_mtime == _cache_mtime:
        return _skills_cache

    skills = []
    try:
        if not os.path.exists(_SKILLS_MD_PATH):
            logger.error(f"[SKILLS_READER] skills.md NOT FOUND at: {os.path.abspath(_SKILLS_MD_PATH)}")
            return []

        with open(_SKILLS_MD_PATH, "r", encoding="utf-8") as f:
            content = f.read()

        logger.info(f"[SKILLS_READER] Reading skills.md from: {os.path.abspath(_SKILLS_MD_PATH)} ({len(content)} chars)")

        blocks = re.split(r"##\s*skill:\s*", content, flags=re.IGNORECASE)

        for block in blocks:
            block = block.strip()
            if not block:
                continue

            lines = block.splitlines()
            skill_name = lines[0].strip()

            keywords_line = ""
            sql_line = ""

            for line in lines[1:]:
                line = line.strip()
                if line.lower().startswith("keywords:"):
                    keywords_line = line[len("keywords:"):].strip()
                elif line.lower().startswith("sql:"):
                    # Everything after "sql:" is the SQL, including newlines
                    sql_line = line[len("sql:"):].strip()

            if skill_name and sql_line:
                keywords = [k.strip().lower() for k in keywords_line.split(",") if k.strip()]
                skills.append({
                    "name": skill_name,
                    "keywords": keywords,
                    "sql": sql_line,
                })
            else:
                if skill_name:
                    logger.warning(f"[SKILLS_READER] Skipping skill '{skill_name}': missing SQL")

        _skills_cache = skills
        _cache_mtime = current_mtime
        logger.info(f"[SKILLS_READER] Loaded {len(skills)} skills from skills.md")

        if len(skills) < 5:
            logger.warning(
                f"[SKILLS_READER] Only {len(skills)} skills loaded — expected 30+. "
                f"Check that skills.md has all skill blocks in '## skill: name' format."
            )

    except Exception as e:
        logger.error(f"[SKILLS_READER] Failed to load skills.md: {e}")
        if _skills_cache is None:
            _skills_cache = []

    return _skills_cache


def match_skill(user_query: str) -> Tuple[Optional[Dict], int]:
    skills = load_skills()
    if not skills:
        return None, 0

    query_lower = user_query.lower()
    query_tokens = set(query_lower.split())

    best_skill = None
    best_score = 0

    for skill in skills:
        score = 0
        for kw in skill["keywords"]:
            if kw in query_lower:
                score += 2
            else:
                kw_tokens = set(kw.split())
                overlap = len(kw_tokens & query_tokens)
                score += overlap

        if score > best_score:
            best_score = score
            best_skill = skill

    if best_skill and best_score > 0:
        logger.info(f"[SKILLS_READER] Matched skill: '{best_skill['name']}' (score={best_score})")
        return best_skill, best_score

    logger.warning(f"[SKILLS_READER] No keyword match found for: '{user_query}'")
    return None, 0
