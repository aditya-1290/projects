"""
Support Agent Card.
"""
from dataclasses import dataclass, field
from typing import List


@dataclass
class SupportAgentCard:
    agent_name: str = "support"
    agent_id: str = "support"
    version: str = "1.0.0"
    domain: str = "support_queries"
    description: str = (
        "Support agent that answers predefined business queries "
        "by matching user intent to pre-written SQL stored in skills.md, "
        "executing via MCP, and explaining results in natural language."
    )
    capabilities: List[str] = field(default_factory=lambda: [
        "skills_md_lookup",
        "keyword_based_sql_matching",
        "mcp_query_execution",
        "natural_language_result_explanation",
    ])
    keywords: List[str] = field(default_factory=list)  # rely on skills.md matching
    handled_intents: List[str] = field(default_factory=lambda: ["support"])
    limitations: List[str] = field(default_factory=lambda: [
        "Only answers queries defined in skills.md",
        "Cannot generate new SQL — SQL is pre-written",
        "Read-only database access",
    ])

    def to_dict(self) -> dict:
        return {
            "agent_name": self.agent_name,
            "agent_id": self.agent_id,
            "version": self.version,
            "domain": self.domain,
            "description": self.description,
            "capabilities": self.capabilities,
            "keywords": self.keywords,
            "handled_intents": self.handled_intents,
            "limitations": self.limitations,
        }

SUPPORT_CARD = SupportAgentCard()
AGENT_CARD = SUPPORT_CARD
