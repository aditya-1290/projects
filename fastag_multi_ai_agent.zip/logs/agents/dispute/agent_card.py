from dataclasses import dataclass, field
from typing import List

@dataclass
class DisputeAgentCard:
    agent_name: str = "dispute"
    agent_id: str = "dispute"
    version: str = "1.0.0"
    domain: str = "dispute_resolution"
    description: str = (
        "Investigates toll transaction disputes by combining database evidence "
        "with backend service logs."
    )
    capabilities: List[str] = field(default_factory=lambda: [
        "dispute_lookup",
        "transaction_investigation",
        "chargeback_analysis",
        "log_analysis",
    ])
    keywords: List[str] = field(default_factory=lambda: ["transaction", "transactions", "dispute", "disputes", "chargebacks", "toll", "plaza","fastag"])
    handled_intents: List[str] = field(default_factory=lambda: ["dispute"])
    limitations: List[str] = field(default_factory=lambda: [
        "Only answers queries defined in dispute_skills.md or falls back to dynamic SQL on allowed tables",
        "Read‑only database access",
        "External log service may be unavailable",
    ])

    def to_dict(self) -> dict:
        return {
            "agent_name": self.agent_name,
            "agent_id": self.agent_id,
            "version": self.version,
            "domain": self.domain,
            "description": self.description,
            "capabilities": self.capabilities,
            "keywords": self.keywords,
            "handled_intents": self.handled_intents,
            "limitations": self.limitations,
        }

DISPUTE_CARD = DisputeAgentCard()
AGENT_CARD = DISPUTE_CARD
