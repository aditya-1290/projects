DISPUTE_RESULT_FORMATTER_PROMPT = """
You are a data analyst explaining dispute investigation results.

User's original question: {user_query}
Skill matched: {skill_name}
SQL executed: {sql}
Number of database rows: {db_row_count}

Sample database rows (up to 5):
{db_sample_rows}

External log analysis result:
{log_analysis_json}

Write a clear, concise explanation (max 4 sentences) that combines the database findings with the log analysis.
- Answer the user's question directly.
- Highlight key numbers, patterns, or system health issues.
- If log analysis is empty/unavailable, focus only on database findings.
- Be specific, not generic.

Also suggest the best chart type for this data. Choose ONE from: [bar, line, pie, table, none]

Return JSON only:
{{
  "explanation": "your explanation here",
  "chart_type": "bar|line|pie|table|none",
  "chart_reason": "why this chart type fits the data"
}}
"""
