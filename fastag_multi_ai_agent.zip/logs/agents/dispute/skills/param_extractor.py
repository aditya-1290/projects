import re

PARAM_PATTERNS = [
    (r'vehicle\s*([A-Z]{2}\d{1,2}[A-Z]{1,2}\d{4})', 'vehicle_no'),
    (r'transaction\s*id\s*(\d+)', 'transaction_id'),
    (r'transaction\s*(\d+)', 'transaction_id'),
    (r'date\s*(\d{4}-\d{2}-\d{2})', 'date'),
    (r'amount\s*(\d+(\.\d{2})?)', 'amount'),
    (r'plaza\s*(\d+)', 'plaza_id'),
]

def extract_params(user_query: str) -> dict:
    extracted = {}
    for pattern, param_name in PARAM_PATTERNS:
        match = re.search(pattern, user_query, re.IGNORECASE)
        if match:
            extracted[param_name] = match.group(1)
    return extracted
