"""
Log Analysis Service — A2A client.

Calls the log_analysis_agent_v3 backend via its /a2a endpoint using the
Agent-to-Agent (A2A) protocol. Only the Dispute agent is allowed to call
this service — the log analysis system enforces this on its side.
"""
import json
import asyncio
import os
from typing import Any, Dict
import httpx
from core.logger import get_logger
from core.config import config

logger = get_logger("log_service")

# ── Config ─────────────────────────────────────────────────────────────
A2A_URL      = os.getenv("LOG_SERVICE_URL", "http://127.0.0.1:8002/a2a")
A2A_API_KEY  = os.getenv("A2A_API_KEY", "dispute-agent-key")
A2A_TIMEOUT  = float(os.getenv("LOG_SERVICE_TIMEOUT", "120.0"))  # log analysis is slow
CALLER_ID    = "dispute_agent"
CALLER_VER   = "1.0"


def _build_a2a_payload(user_query: str, params: dict, db_result: dict) -> dict:
    """
    Build the A2A message payload that log_analysis_agent_v3 expects.

    The log analysis system's /a2a endpoint receives:
      - caller_id   : identity of calling agent (must be 'dispute_agent')
      - query       : the enriched context to analyze
      - session_id  : unique per-request session
      - metadata    : any extra context the log system might use
    """
    import uuid

    # Build a rich query from all available context
    rows = db_result.get("rows", [])
    row_summary = (
        f"{len(rows)} transaction(s) found" if rows
        else "No matching transactions found in DB"
    )

    enriched_query = (
        f"Dispute log analysis request:\n"
        f"User query: {user_query}\n\n"
        f"DB result summary: {row_summary}\n"
        f"SQL used: {db_result.get('sql', 'N/A')}\n"
        f"Vehicle: {params.get('vehicle_no', 'unknown')}\n"
        f"Transaction ID: {params.get('transaction_id', 'unknown')}\n"
        f"Date: {params.get('date', 'unknown')}\n\n"
        f"Sample DB rows (up to 3):\n"
        f"{json.dumps(rows[:3], default=str, indent=2)}\n\n"
        f"Analyze any log errors, API failures, or service degradation "
        f"related to this dispute and provide root cause + fix suggestions."
    )

    return {
        "protocol":    "a2a/1.0",
        "caller_id":   CALLER_ID,
        "caller_version": CALLER_VER,
        "message_type": "REQUEST",
        "session_id":  f"dispute_{uuid.uuid4().hex[:12]}",
        "query":       enriched_query,
        "metadata": {
            "source":         "dispute_agent",
            "vehicle_no":     params.get("vehicle_no"),
            "transaction_id": params.get("transaction_id"),
            "db_row_count":   db_result.get("row_count", len(rows)),
        },
    }


def _parse_a2a_response(raw: dict) -> dict:
    """
    Normalize the A2A response from log_analysis_agent_v3 into the
    format that dispute agent's explain_dispute_result expects.
    """
    # The log analysis backend returns its standard pipeline response
    # wrapped in an A2A envelope.
    inner = raw.get("result") or raw.get("response") or raw

    return {
        "service_status": inner.get("service_status", {}),
        "relevant_logs":  inner.get("relevant_logs", []),
        "root_cause":     inner.get("root_cause", ""),
        "fix_suggestion": inner.get("fix_suggestion", ""),
        "explanation":    inner.get("explanation", inner.get("response", "")),
        "confidence":     inner.get("confidence", 0.0),
        "pipeline_stages": inner.get("pipeline_stages", []),
        "overall_health": inner.get("overall_health", "unknown"),
        "a2a_protocol":   raw.get("protocol", "a2a/1.0"),
        "caller_accepted": raw.get("caller_accepted", True),
    }


async def call_log_analysis(
    user_query: str,
    params: dict,
    db_result: dict,
) -> dict:
    """
    Send an A2A request to the log analysis multi-agent backend and
    return a structured analysis result.

    Only called when config.LOG_SERVICE_ENABLED is True (checked by caller).
    """
    if not config.LOG_SERVICE_ENABLED:
        return {"status": "disabled"}

    payload = _build_a2a_payload(user_query, params, db_result)
    headers = {
        "Content-Type":  "application/json",
        "X-A2A-Caller":  CALLER_ID,
        "X-A2A-Version": CALLER_VER,
        "Authorization": f"Bearer {A2A_API_KEY}",
    }

    logger.info(
        f"[A2A] Calling log analysis | url={A2A_URL} | "
        f"session={payload['session_id']} | "
        f"vehicle={params.get('vehicle_no', '?')} "
        f"tx={params.get('transaction_id', '?')}"
    )

    try:
        async with httpx.AsyncClient(timeout=A2A_TIMEOUT) as client:
            resp = await client.post(A2A_URL, json=payload, headers=headers)

        if resp.status_code == 200:
            raw = resp.json()
            result = _parse_a2a_response(raw)
            logger.info(
                f"[A2A] Log analysis succeeded | "
                f"confidence={result.get('confidence', '?')} | "
                f"stages={result.get('pipeline_stages', [])}"
            )
            return result

        elif resp.status_code == 403:
            logger.warning(
                f"[A2A] Caller rejected by log analysis backend (403) — "
                f"check A2A_API_KEY and A2A_ALLOWED_CALLERS config"
            )
            return {
                "status": "rejected",
                "error": f"Caller not authorized: {resp.text[:200]}",
            }

        else:
            logger.error(
                f"[A2A] Log analysis backend returned HTTP {resp.status_code}: "
                f"{resp.text[:300]}"
            )
            return {
                "status": "error",
                "error": f"HTTP {resp.status_code}: {resp.text[:200]}",
            }

    except httpx.TimeoutException:
        logger.error(
            f"[A2A] Log analysis timed out after {A2A_TIMEOUT}s — "
            f"backend may be busy with a long pipeline run"
        )
        return {
            "status": "timeout",
            "error": f"Log analysis backend timed out after {A2A_TIMEOUT}s",
        }

    except httpx.ConnectError:
        logger.error(
            f"[A2A] Cannot connect to log analysis backend at {A2A_URL} — "
            f"is adk_server.py running?"
        )
        return {
            "status": "unavailable",
            "error": f"Log analysis backend unreachable at {A2A_URL}",
        }

    except Exception as e:
        logger.error(f"[A2A] Unexpected error: {e}")
        return {"status": "error", "error": str(e)}
    