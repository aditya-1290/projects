# core/llm_client.py

# import os
import logging
import httpx

# Silence LiteLLM
logging.getLogger("LiteLLM").setLevel(logging.ERROR)
logging.getLogger("litellm").setLevel(logging.ERROR)

from typing import Any

# import httpx
from core.config import config
from core.logger import get_logger

logger = get_logger("llm_client")

def call_llm(system_prompt: str, user_prompt: str, max_tokens: int = 1048) -> Any | None:
    """
    Call local LLM via HTTP directly (bypassing litellm issues)
    """
    url = f"{config.LOCAL_LLM_BASE_URL}/chat/completions"
    
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt},
    ]
    
    payload = {
        "model": config.LOCAL_LLM_MODEL,
        "messages": messages,
        "max_tokens": max_tokens,
        "temperature": 0.1,
    }
    
    headers = {
        "Content-Type": "application/json",
    }
    
    # Add API key if provided
    if config.LOCAL_LLM_API_KEY and config.LOCAL_LLM_API_KEY != "sk-local":
        headers["Authorization"] = f"Bearer {config.LOCAL_LLM_API_KEY}"
    
    logger.debug(f"LLM call | url={url} | prompt_len={len(user_prompt)}")

    # Retry up to 3 times
    for attempt in range(3):
        try:
            with httpx.Client(timeout=1500.0) as client:  # 5 min timeout
                response = client.post(url, json=payload, headers=headers)
                response.raise_for_status()
                data = response.json()
                result = data["choices"][0]["message"]["content"].strip()
                logger.debug(f"LLM response len={len(result)}")
                return result
        except (httpx.ConnectError, httpx.ReadError) as e:
            if attempt < 2:
                logger.warning(f"LLM attempt {attempt + 1} failed: {e}. Retrying...")
                import time
                time.sleep(2)
            else:
                raise RuntimeError(
                    f"Cannot connect to LLM server at {url}. "
                    "Is Terminal 1 running?"
                )
        except Exception as e:
            logger.error(f"LLM error: {e}")
            raise
    return None
