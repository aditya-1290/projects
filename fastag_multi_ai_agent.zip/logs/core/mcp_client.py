"""
MCP Client for Agents to call MCP Server tools.
Uses a singleton httpx.Client for connection reuse.
"""

import json
import httpx
from typing import Any, Dict, Optional
from core.config import config
from core.logger import get_logger

logger = get_logger("mcp_client")

# ── Singleton HTTP client (created once, reused across all calls) ──
_client: Optional[httpx.Client] = None


def _get_client() -> httpx.Client:
    """Get or create the singleton HTTP client."""
    global _client
    if _client is None or _client.is_closed:
        _client = httpx.Client(
            base_url=config.MCP_BASE_URL,
            headers={"x-api-key": config.MCP_API_KEY, "Content-Type": "application/json"},
            timeout=600.0,
        )
        logger.debug("MCP HTTP client created")
    return _client


class MCPClient:
    """Client for calling MCP Server tools."""

    def call_tool(self, tool_name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        if tool_name == "query_database":
            return self.execute_query(arguments.get("sql", ""), arguments.get("params", {}))
        elif tool_name == "get_schema":
            return self.get_schema(arguments.get("table_name"))
        elif tool_name == "get_relationships":
            return self.get_relationships()
        elif tool_name == "get_table_list":
            return self.get_table_list()
        elif tool_name == "get_cache_status":
            return self.get_cache_status()
        elif tool_name == "refresh_cache":
            return self.refresh_cache()
        else:
            return {"error": f"Unknown tool: {tool_name}"}

    def execute_query(self, sql: str, params: Dict = None) -> Dict[str, Any]:
        try:
            client = _get_client()
            resp = client.post(
                "/tools/execute_query",
                json={"query": sql, "params": params or {}},
            )
            resp.raise_for_status()
            return resp.json()
        except Exception as e:
            logger.error(f"MCP execute_query failed: {e}")
            return {"ok": False, "error": str(e), "rows": [], "row_count": 0}

    def get_cache(self) -> Dict[str, Any]:
        try:
            client = _get_client()
            resp = client.get("/cache")
            resp.raise_for_status()
            return resp.json()
        except Exception as e:
            logger.error(f"MCP get_cache failed: {e}")
            return {"schemas": {}, "relationships": {}, "table_map": {}}

    def get_schema(self, table_name: str = None) -> Dict[str, Any]:
        try:
            cache = self.get_cache()
            if table_name:
                for full_name, info in cache.get("schemas", {}).items():
                    if full_name.endswith(f".{table_name}") or full_name == table_name:
                        return {"table": full_name, "columns": info.get("columns", [])}
                return {"error": f"Table '{table_name}' not found"}
            return {"schemas": cache.get("schemas", {})}
        except Exception as e:
            return {"error": str(e)}

    def get_relationships(self) -> Dict[str, Any]:
        try:
            cache = self.get_cache()
            return {"relationships": cache.get("relationships", {})}
        except Exception as e:
            return {"relationships": {}}

    def get_table_list(self) -> Dict[str, Any]:
        try:
            cache = self.get_cache()
            return {"table_map": cache.get("table_map", {})}
        except Exception as e:
            return {"table_map": {}}

    def get_cache_status(self) -> Dict[str, Any]:
        try:
            client = _get_client()
            resp = client.get("/health")
            return resp.json()
        except Exception as e:
            return {"status": "error", "error": str(e)}

    def refresh_cache(self) -> Dict[str, Any]:
        try:
            client = _get_client()
            resp = client.post("/tools/refresh_cache")
            return resp.json()
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def get_table_schemas(self, table_list: list) -> dict:
        """Fetch metadata for specific tables."""
        try:
            client = _get_client()
            resp = client.post(
                "/tools/get_table_schemas",
                json={"table_list": table_list},
            )
            resp.raise_for_status()
            return resp.json()
        except Exception as e:
            logger.error(f"get_table_schemas failed: {e}")
            return {}


# Singleton instance
mcp_client = MCPClient()
