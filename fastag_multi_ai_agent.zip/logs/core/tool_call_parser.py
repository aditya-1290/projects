"""
Tool Call Parser Bridge for MLFF ADK
Parses Gemma/Qwen plain-text tool calls and executes matching functions.

Handles formats like:
  <|tool_call|>call:detect_query_intent{user_query:<|"|>Show top 10 customers<|"|>}<tool_call|>
  <|tool_call|>call:generate_sql_query{user_query:"...", intent:"aggregation"}<tool_call|>
"""
import core.suppress_warnings

import os
# os.environ["OTEL_SDK_DISABLED"] = "true"
# os.environ["OTEL_PYTHON_LOG_LEVEL"] = "error"
#
# import warnings
# warnings.filterwarnings("ignore", category=UserWarning, module="google.adk")
# warnings.filterwarnings("ignore", message=".*EXPERIMENTAL.*")
#
# import logging
# logging.getLogger("LiteLLM").setLevel(logging.CRITICAL)
# logging.getLogger("litellm").setLevel(logging.CRITICAL)

import re
import json
import asyncio
import inspect
from typing import Optional, Dict, Any, Callable
from google.adk.tools import BaseTool
import ast

from core.logger import get_logger

logger = get_logger("tool_call_parser")


# Add this RIGHT AFTER the imports in core/tool_call_parser.py
# This monkey-patches ADK's tracing to be silent

# def _silence_adk_tracing():
#     """Monkey-patch ADK to disable OpenTelemetry tracing entirely."""
#     try:
#         from google.adk.telemetry import tracing
#
#         # Replace the span decorators with no-op versions
#         def noop_span(*args, **kwargs):
#             def decorator(func):
#                 return func
#
#             if len(args) == 1 and callable(args[0]):
#                 return args[0]
#             return decorator
#
#         tracing._use_native_generate_content_span_stable_semconv = noop_span
#         tracing._use_native_generate_content_span = noop_span
#         tracing.use_inference_span = noop_span
#
#         logger.info("[BRIDGE] ADK tracing silenced")
#     except Exception:
#         pass


# Call it after imports
# _silence_adk_tracing()

# ============================================================================
# TOOL WRAPPER
# ============================================================================

class SimpleTool(BaseTool):
    """Simple tool wrapper for ADK compatibility."""
    
    def __init__(self, func: Callable, name: str = None, description: str = None):
        self.name = name or func.__name__
        self.description = description or func.__doc__ or ""
        self._func = func
        
        sig = inspect.signature(func)
        params = list(sig.parameters.keys())
        self._user_params = [p for p in params if p != 'tool_context']
        
    async def run_async(self, *, args: dict, tool_context=None) -> str:
        filtered = {k: v for k, v in args.items() if k in self._user_params}
        
        if 'tool_context' in inspect.signature(self._func).parameters:
            result = await self._func(tool_context=tool_context, **filtered)
        else:
            if asyncio.iscoroutinefunction(self._func):
                result = await self._func(**filtered)
            else:
                result = self._func(**filtered)
        return str(result)


def make_tool(fn: Callable) -> SimpleTool:
    """Wrap a function as an ADK-compatible tool."""
    return SimpleTool(fn)

# ============================================================================
# PARSER CORE
# ============================================================================

def parse_tool_call(text: str) -> Optional[Dict[str, Any]]:
    """
    Parse a plain-text tool call from model output.

    Returns:
        {"tool_name": "...", "args": {...}} or None if no tool call found
    """
    if not text:
        return None

    # Pattern 0: <|tool_call>call: TOOL_NAME(args)   ← actual Gemma output (no closing | on open tag)
    # Also handles <|tool_call|>call: TOOL_NAME(args) for safety
    # Pattern 0: <|tool_call>call: TOOL_NAME(args)
    pattern0 = r"<\|tool_call\|?>call:\s*(\w+)\s*\((.+?)\)\s*$"
    match = re.search(pattern0, text, re.DOTALL | re.MULTILINE)
    if not match:
        # Try without end anchor in case there's trailing text
        pattern0b = r"<\|tool_call\|?>call:\s*(\w+)\s*\((.+)\)"
        match = re.search(pattern0b, text, re.DOTALL)

    if match:
        tool_name = match.group(1).strip()
        args_text = match.group(2).strip()
        # Strip trailing quote+paren if regex over-captured
        # e.g. args_text might end with '")' — clean it
        if args_text.endswith('")'):
            args_text = args_text[:-1]  # remove trailing )
        elif args_text.endswith("')"):
            args_text = args_text[:-1]
        if tool_name in ALL_KNOWN_TOOLS:
            result = _parse_function_style(tool_name, args_text)
            if result:
                return result
            else:
                logger.warning(f"[PARSER] Pattern 0 matched but _parse_function_style failed | args_text={args_text!r}")

    # Pattern 0b: <|tool_call>call:TOOL_NAME{...}  (no closing tag, missing | on open)
    pattern0b = r"<\|tool_call\|?>call:\s*(\w+)\s*\{(.+)\}\s*$"
    match = re.search(pattern0b, text, re.DOTALL | re.MULTILINE)
    if not match:
        # Try without end anchor
        pattern0b2 = r"<\|tool_call\|?>call:\s*(\w+)\s*\{(.+)\}"
        match = re.search(pattern0b2, text, re.DOTALL)

    if match:
        tool_name = match.group(1).strip()
        args_text = match.group(2).strip()
        if tool_name in ALL_KNOWN_TOOLS:
            args = _parse_arguments(args_text)
            if args:
                logger.info(f"[PARSER] Parsed tool call (brace format): {tool_name} | args: {list(args.keys())}")
                return {"tool_name": tool_name, "args": args}
            else:
                logger.warning(f"[PARSER] Brace format matched but _parse_arguments failed | args_text={args_text[:100]!r}")

    # Pattern 1: <|tool_call|>call:TOOL_NAME{...}<tool_call|>  (original Gemma format)
    pattern1 = r"<\|tool_call\|\>\s*call:(\w+)\s*\{([^}]*(?:\{[^}]*\}[^}]*)*)\}\s*<tool_call\|\>"
    match = re.search(pattern1, text, re.DOTALL)
    if match:
        tool_name = match.group(1).strip()
        args_text = match.group(2).strip()
        args = _parse_arguments(args_text)
        if args:
            logger.info(f"[PARSER] Parsed tool call: {tool_name} | args: {list(args.keys())}")
            return {"tool_name": tool_name, "args": args}

    # Pattern 2: <tool_call>call:TOOL_NAME{...}</tool_call>
    pattern2 = r"<tool_call>\s*call:(\w+)\s*\{([^}]*(?:\{[^}]*\}[^}]*)*)\}\s*</tool_call>"
    match = re.search(pattern2, text, re.DOTALL)
    if match:
        tool_name = match.group(1).strip()
        args_text = match.group(2).strip()
        args = _parse_arguments(args_text)
        if args:
            logger.info(f"[PARSER] Parsed tool call: {tool_name} | args: {list(args.keys())}")
            return {"tool_name": tool_name, "args": args}

    # Pattern 3: bare TOOL_NAME(arg1="value") without any wrapper
    for tool in ALL_KNOWN_TOOLS:
        if tool in text:
            match = re.search(rf'{tool}\s*\(\s*([^)]+)\s*\)', text, re.DOTALL)
            if match:
                result = _parse_function_style(tool, match.group(1))
                if result:
                    return result

    return None


def _parse_function_style(tool_name: str, args_text: str) -> Optional[Dict[str, Any]]:
    """Parse function-call style: arg1="value", arg2='value', arg3=123"""
    args = {}
    logger.debug(f"[PARSER] _parse_function_style | tool={tool_name} | args_text={args_text!r}")

    pattern = r'(\w+)\s*=\s*(?:"([^"\\]*(?:\\.[^"\\]*)*)"|\'([^\'\\]*(?:\\.[^\'\\]*)*)\'|(\d+(?:\.\d+)?))'
    for m in re.finditer(pattern, args_text):
        key = m.group(1)
        # Take first non-None group among capture groups 2,3,4
        value = next((g for g in (m.group(2), m.group(3), m.group(4)) if g is not None), "")
        args[key] = value
    
    if not args:
        logger.warning(f"[PARSER] No args parsed from: {args_text[:100]}")
        return None

    logger.info(f"[PARSER] Parsed tool call: {tool_name} | args: {list(args.keys())}")
    return {"tool_name": tool_name, "args": args}

def _sanitize_json_string(val: str) -> Any:
    """Convert Python-style dict/list strings to valid JSON."""
    if not val:
        return val
    try:
        # Try direct JSON parse first
        return json.loads(val)
    except Exception:
        pass
    try:
        # Replace Python-style quotes and booleans
        import ast
        parsed = ast.literal_eval(val)
        return parsed  # returns actual dict/list
    except Exception:
        pass
    return val  # return as-is if all else fails

def _extract_balanced(text: str, start: int) -> str:
    """Extract a balanced JSON array [...] or object {...} starting at `start`."""
    if start >= len(text):
        return ""
    ch = text[start]
    if ch not in ('[', '{'):
        return ""
    close = ']' if ch == '[' else '}'
    depth = 0
    for i in range(start, len(text)):
        if text[i] == ch:
            depth += 1
        elif text[i] == close:
            depth -= 1
            if depth == 0:
                return text[start:i+1]
    return ""

def _parse_arguments(args_text: str) -> Dict[str, Any]:
    """
    Parse Gemma-style tool call arguments.
    Returns a dict with all values properly cleaned and JSON-parsed.
    """
    args = {}

    # 1. Replace all Gemma quote tokens globally in the arguments string
    clean_text = args_text
    for token in ['<|"|>', '<|"|', '"|>']:
        clean_text = clean_text.replace(token, '"')

    arg_names = [
        "user_query", "intent", "query_type", "selected_schema",
        "selected_tables_json", "schema_details_json", "relationships_hint_json",
        "sql", "execution_result_json"
    ]

    # 2. Extract complex JSON values (objects/arrays) using balanced extraction
    for arg_name in ["selected_tables_json", "schema_details_json", "relationships_hint_json",
                     "execution_result_json"]:
        if arg_name in args:
            continue
        key_match = re.search(rf'{arg_name}\s*[=:]\s*', clean_text)
        if key_match:
            start = key_match.end()
            val_str = _extract_balanced(clean_text, start)
            if val_str:
                try:
                    args[arg_name] = json.loads(val_str)
                except (json.JSONDecodeError, ValueError):
                    try:
                        # ast can handle unquoted keys and single-quoted strings
                        args[arg_name] = ast.literal_eval(val_str)
                    except (SyntaxError, ValueError):
                        # Last resort: keep the cleaned string
                        args[arg_name] = val_str
            else:
                # Fallback: try a simpler regex if balanced extraction failed
                match = re.search(rf'{arg_name}\s*[=:]\s*(.+?)(?:,\s*\w+\s*[=:]|$)', clean_text, re.DOTALL)
                if match:
                    val = match.group(1).strip()
                    try:
                        args[arg_name] = json.loads(val)
                    except:
                        try:
                            args[arg_name] = ast.literal_eval(val)
                        except:
                            args[arg_name] = val

    # 3. Extract simple values (strings, numbers)
    for arg_name in arg_names:
        if arg_name in args:  # already parsed
            continue

        # Priority 1: double-quoted
        match = re.search(rf'{arg_name}\s*[=:]\s*"((?:[^"\\]|\\.)*)"', clean_text)
        if match:
            args[arg_name] = match.group(1)
            continue

        # Priority 2: single-quoted
        match = re.search(rf"{arg_name}\s*[=:]\s*'((?:[^'\\]|\\.)*)'", clean_text)
        if match:
            args[arg_name] = match.group(1)
            continue

        # Priority 3: unquoted until comma or end
        match = re.search(rf'{arg_name}\s*[=:]\s*([^,}}]+)', clean_text)
        if match:
            val = match.group(1).strip().strip('"').strip("'")
            args[arg_name] = val

    return args

def parse_batch_tool_calls(text: str) -> Optional[list]:
    """
    Parse JSON array format tool calls:
    [{"tool_name": "...", "parameters": {...}}, ...]
    """
    if not text:
        return None
    
    # Find JSON array in text
    match = re.search(r'\[\s*\{.*?\}\s*\]', text, re.DOTALL)
    if not match:
        return None
    
    try:
        data = json.loads(match.group(0))
        if not isinstance(data, list):
            return None
        
        results = []
        for item in data:
            if not isinstance(item, dict):
                continue
            tool_name = item.get("tool_name") or item.get("name")
            parameters = (
                item.get("parameters")
                or item.get("params")        # ← ADD THIS
                or item.get("args")
                or item.get("arguments")
                or {}
            )            
            if tool_name and tool_name in ALL_KNOWN_TOOLS:
                results.append({"tool_name": tool_name, "args": parameters})
        
        return results if results else None
        
    except (json.JSONDecodeError, Exception):
        return None


def detect_batch_tool_calls(text: str) -> bool:
    """Check if text contains a JSON array of tool calls."""
    if not text:
        return False
    if not ('[' in text and 'tool_name' in text):
        return False
    return parse_batch_tool_calls(text) is not None

def detect_tool_call(text: str) -> bool:
    """Check if text contains a tool CALL (not tool response)."""
    if not text:
        return False
    
    # Explicitly ignore tool responses
    if "<|tool_response|>" in text or "<tool_response|>" in text:
        return False
    
    # Batch JSON array format
    if detect_batch_tool_calls(text):
        return True
    
    # Original formats
    if "<|tool_call|>" in text or "<tool_call>" in text:
        return True
    
    # Gemma actual output (missing closing | on opening tag)
    if "<|tool_call>" in text:
        return True
    
    # call: prefix with or without space
    for tool in ALL_KNOWN_TOOLS:
        if f"call: {tool}" in text or f"call:{tool}" in text:
            return True
    
    return False

def detect_tool_response(text: str) -> bool:
    """Check if text is a tool response that needs another LLM iteration."""
    if not text:
        return False
    return "<|tool_response|>" in text or "<tool_response|>" in text


def format_tool_response(tool_name: str, result: str, max_chars: int = 8000) -> str:
    """Format a tool result back to the model in Gemma's expected format."""
    # Truncate if too long
    if len(result) > max_chars:
        result = result[:max_chars] + "\n... [truncated]"
    
    return f"<|tool_response|>response:{tool_name}{{value:<|\"|>{result}<|\"|>}}<tool_response|>"


# ============================================================================
# TOOL EXECUTOR
# ============================================================================

async def execute_parsed_tool(
    parsed: Dict[str, Any],
    tools_map: Dict[str, Callable],
) -> Optional[str]:
    """
    Execute a parsed tool call against the tools map.

    Args:
        parsed: {"tool_name": "...", "args": {...}}
        tools_map: {"tool_name": tool_function, ...}

    Returns:
        Tool execution result as string, or None if tool not found
    """
    tool_name = parsed["tool_name"]
    args = parsed["args"]
    
    if tool_name not in tools_map:
        logger.error(f"[EXECUTOR] Unknown tool: {tool_name}")
        return None
    
    try:
        tool_fn = tools_map[tool_name]
        wrapped_tool = make_tool(tool_fn)  # ← Use make_tool wrapper
        result = await wrapped_tool.run_async(args=args, tool_context=None)
        return str(result)
    except Exception as e:
        logger.error(f"[EXECUTOR] Error: {e}")
        return json.dumps({"error": str(e)})


# ============================================================================
# ADK BRIDGE PATCH
# ============================================================================

# List of known tools across agents
ALL_KNOWN_TOOLS = [
    "detect_query_intent",
    "get_database_context", 
    "generate_sql_query",
    "execute_sql_via_mcp",
    "explain_results",
]

# Global tools map (will be set by agents)
_TOOLS_MAP = {}


def set_tools_map(tools_map: Dict[str, Callable]):
    """Merge into the global tools map for the bridge."""
    global _TOOLS_MAP
    _TOOLS_MAP.update(tools_map)  # ← update instead of replace
    logger.info(f"[BRIDGE] Tools map updated, total={len(_TOOLS_MAP)} tools")


def create_tool_wrapper(fn: Callable) -> Callable:
    """
    Wrapper for tools to make them compatible with the bridge.
    Similar to the make_tool pattern you showed.
    """
    sig = inspect.signature(fn)
    params = list(sig.parameters.keys())
    user_params = [p for p in params if p != 'tool_context']
    
    async def wrapper(tool_context=None, **kwargs):
        filtered = {k: v for k, v in kwargs.items() if k in user_params}
        if asyncio.iscoroutinefunction(fn):
            return await fn(**filtered)
        return fn(**filtered)
    
    return wrapper


# ============================================================================
# PATCH ADK LlmAgent to intercept tool calls
# ============================================================================

def patch_adk_agent():
    try:
        from google.adk.agents.llm_agent import LlmAgent
        from google.genai.types import Content, Part

        original_run_async = LlmAgent._run_async_impl

        async def patched_run_async_impl(self, ctx):
            async for event in original_run_async(self, ctx):
                # Only inspect final response events that have content
                if not (hasattr(event, 'content') and event.content):
                    yield event
                    continue

                parts = getattr(event.content, 'parts', [])
                if not parts:
                    yield event
                    continue

                # Scan all parts for a tool call
                tool_call_found = False
                for part in parts:
                    text = getattr(part, 'text', '')
                    if not text:
                        continue

                    if detect_tool_call(text):
                        parsed = parse_tool_call(text)
                        if parsed:
                            logger.info(f"[ADK BRIDGE] Intercepted tool call: {parsed['tool_name']}")
                            result = await execute_parsed_tool(parsed, _TOOLS_MAP)
                            if result:
                                tool_response = format_tool_response(parsed['tool_name'], result)
                                event.content = Content(
                                    role="model",
                                    parts=[Part(text=tool_response)]
                                )
                                tool_call_found = True
                                break

                # Always yield the event — either modified or original
                yield event

        LlmAgent._run_async_impl = patched_run_async_impl
        logger.info("[ADK BRIDGE] Successfully patched LlmAgent")
        return True

    except Exception as e:
        logger.error(f"[ADK BRIDGE] Failed to patch ADK: {e}")
        return False

# ============================================================================
# SIMPLE BRIDGE (without ADK patching)
# ============================================================================

class SimpleBridge:
    """
    Simple bridge that doesn't patch ADK.
    Use this if ADK patching causes issues.
    """
    
    def __init__(self, tools_map: Dict[str, Callable]):
        self.tools_map = tools_map
        self.max_iterations = 5
    
    async def process(self, text: str) -> str:
        """
        Process text, execute any tool calls, return final result.
        """
        current_text = text
        iterations = 0
        
        while iterations < self.max_iterations:
            if detect_tool_call(current_text):
                parsed = parse_tool_call(current_text)
                if parsed:
                    logger.info(f"[SimpleBridge] Executing: {parsed['tool_name']}")
                    result = await execute_parsed_tool(parsed, self.tools_map)
                    if result:
                        # Replace tool call with result and continue
                        current_text = format_tool_response(parsed['tool_name'], result)
                        iterations += 1
                        continue
            break
        
        return current_text
    