"""
Query Classifier
Multi-feature weighted scoring for agent routing.
Replaces simple token overlap with:
  1. Synonym-expanded keyword matching
  2. Phrase-level matching (exact phrase = highest signal)
  3. Query pattern detection (structural analysis of query shape)
  4. Negative signal detection (prevents definition questions from routing to data agents)
  5. Domain word presence (weak but catches what keywords miss)
  6. Intent as a feature (from orchestrator, if available)
"""
import re
import copy
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple


# ══════════════════════════════════════════════════════════════════════════
# Synonym Map
# Each key is a canonical word. Values are synonyms.
# When ANY word in the set appears in a query, all words get checked.
# ════════════════════════════════════════════════════════════════════

SYNONYM_MAP = {
    # Revenue / Sales
    "revenue": {"earnings", "income", "money", "sales", "amount", "total", "sum", "gross", "turnover", "billing", "receipts", "collections", "payments", "invoiced", "collected", "charged", "billed"},
    "orders": {"order", "purchase", "transaction", "sale", "booking", "invoice", "receipt", "line_item", "item"},
    "customers": {"customer", "client", "user", "buyer", "account", "clientele", "consumer"},
    "payment": {"payment", "paid", "bill", "charge", "receipt", "transaction", "settled", "received"},
    "employees": {"employee", "staff", "worker", "personnel", "workforce", "headcount", "team", "member"},
    "products": {"product", "item", "sku", "goods", "merchandise", "inventory", "stock"},

    # Dispute / Toll
    "transaction": {"transaction", "tx", "txn", "charge", "toll", "crossing", "passage", "trip", "entry", "exit", "record"},
    "dispute": {"dispute", "disagreement", "complaint", "grievance", "issue", "problem", "wrong", "incorrect", "failed", "unauthorized", "unrecognized"},
    "chargeback": {"chargeback", "refund", "reversal", "clawback", "return", "credit", "adjustment", "reversal"},
    "fastag": {"fastag", "fastrak", "tag", "electronic toll", "etc tag", "rfid", "etag", "sticker", "passenger", "vehicle_tag"},
    "toll": {"toll", "plaza", "booth", "barrier", "fee", "charge", "levy", "highway", "expressway", "gentry", "toll plaza", "toll booth"},
    "vehicle": {"vehicle", "car", "truck", "bus", "motorcycle", "van", "lcv", "hcv", "two-wheeler", "auto", "suv", "cab", "taxi"},
    "fastag": {"fastag", "fastrak", "tag", "electronic toll", "etc tag", "rfid", "etag"},

    # Support
    "ticket": {"ticket", "issue", "request", "case", "incident", "complaint", "sr", "help", "support", "query"},
    "feedback": {"feedback", "rating", "review", "satisfaction", "score", "survey", "csat", "nps"},
    "status": {"status", "state", "stage", "progress", "resolution", "outcome"},
    "log": {"log", "logs", "logging", "error", "audit", "trace", "entry", "record"},
    "error": {"error", "failure", "exception", "failed"},
    "api": {"api", "endpoint", "rest", "http", "request", "response", "endpoint"},
    "system": {"system", "server", "infrastructure", "resource", "cpu", "memory", "disk", "performance", "health"},
    "metric": {"metric", "stat", "counter", "measure", "indicator", "monitor"},

    # General patterns
    "trend": {"trend", "over time", "history", "timeline", "progression", "series", "chronological"},
    "comparison": {"compare", "vs", "versus", "difference", "between", "against", "relative"},
    "ranking": {"top", "bottom", "highest", "lowest", "best", "worst", "most", "least", "rank", "leaderboard"},
    "aggregation": {"total", "sum", "count", "average", "avg", "mean", "min", "max", "overall"},
}


def expand_word(word: str) -> Set[str]:
    """Expand a word into itself + all its synonyms."""
    word_lower = word.lower().strip()
    expanded = {word_lower}
    for key, syns in SYNONYM_MAP.items():
        if word_lower == key:
            expanded.update(s.lower() for s in syns)
            break
        if word_lower in syns:
            expanded.add(key)
            expanded.update(s.lower() for s in syns)
    return expanded


# ════════════════════════════════════════════════════════════════════
# Agent Configuration
# Each agent's routing profile. Can be enriched via register_agent().
# ══════════════════════════════════════════════════════════════════

@dataclass
class AgentConfigs:
    agent_id: str
    keywords: List[str] = field(default_factory=list)
    capabilities: List[str] = field(default_factory=list)
    handled_intents: List[str] = field(default_factory=list)
    phrases: List[str] = field(default_factory=list)
    domain_words: List[str] = field(default_factory=list)
    negative_patterns: List[str] = field(default_factory=list)


# Default configurations per agent — can be enriched via register_agent()
# DEFAULT_CONFIGS: Dict[str, AgentConfigs] = {
#     "mlff": AgentConfigs(
#         "sales",
#         ["sql_generation", "table_selection", "schema_understanding",
#          "query_execution_via_mcp", "result_formatting", "natural_language_explanation",
#          "chart_type_suggestion"],
#         ["lookup", "aggregation", "ranking", "filtering", "comparison", "trend"],
#         [
#             "revenue by month", "revenue by region", "orders per day", "top customers",
#             "top employees", "monthly sales", "daily revenue", "sales trend",
#         ],
#         ["revenue", "sales", "order", "customer", "payment", "product", "store", "region"],
#     ),
#     "support": AgentConfigs(
#         [],
#         [],
#         ["support", "lookup"],
#         [
#             "ticket count", "tickets by status", "total tickets", "open tickets", "closed tickets",
#             "error logs", "error count", "top error services", "api response times",
#             "system resource usage", "employee ticket load", "feedback score",
#             "product performance", "customer revenue", "employee performance",
#             "inventory health", "sales by store",
#         ],
#         ["ticket", "status", "feedback", "rating", "employee", "request", "issue",
#          "error", "log", "api", "system", "resource", "metric",
#          "support", "help", "how many", "count", "show", "list", "find", "get"],
#     ),
#     "dispute": AgentConfigs(
#         ["transaction", "transactions", "dispute", "disputes", "chargebacks", "toll", "plaza",
#          "fastag", "investigate", "wrong", "incorrect", "failed", "refund", "duplicate"],
#         [],
#         ["dispute", "lookup"],
#         [
#             "transaction details", "dispute status", "chargeback status",
#         ],
#         ["transaction", "dispute", "chargeback", "toll", "plaza", "vehicle", "fastag",
#          "wrong amount", "failed", "refund", "duplicate charge"],
#         [
#             "what is a", "define ", "meaning of", "explain what", "how does",
#             "can you", "is it possible", "why does",
#         ],
#     ),
# }

DEFAULT_CONFIGS: Dict[str, AgentConfigs] = {
    "mlff": AgentConfigs(
        agent_id="mlff",
        keywords=["sales", "orders", "customers", "revenue", "payment", "order items",
                  "regions", "stores", "employees", "staff", "inventory"],
        capabilities=["sql_generation", "table_selection", "schema_understanding",
                      "query_execution_via_mcp", "result_formatting",
                      "natural_language_explanation", "chart_type_suggestion"],
        handled_intents=["lookup", "aggregation", "ranking", "filtering", "comparison", "trend"],
        phrases=[
            "revenue by month", "revenue by region", "orders per day", "top customers",
            "top employees", "monthly sales", "daily revenue", "sales trend",
        ],
        domain_words=["revenue", "sales", "order", "customer", "payment", "product", "store", "region"],
    ),
    "support": AgentConfigs(
        agent_id="support",
        keywords=[],
        capabilities=[],
        handled_intents=["support", "lookup"],
        phrases=[
            "ticket count", "tickets by status", "total tickets", "open tickets",
            "closed tickets", "error logs", "error count", "top error services",
            "api response times", "system resource usage", "employee ticket load",
            "feedback score", "product performance", "customer revenue",
            "employee performance", "inventory health", "sales by store",
        ],
        domain_words=["ticket", "status", "feedback", "rating", "employee", "request",
                      "issue", "error", "log", "api", "system", "resource", "metric",
                      "support", "help", "how many", "count", "show", "list", "find", "get"],
    ),
    "dispute": AgentConfigs(
        agent_id="dispute",
        keywords=["transaction", "transactions", "dispute", "disputes", "chargebacks",
                  "toll", "plaza", "fastag", "investigate", "wrong", "incorrect",
                  "failed", "refund", "duplicate"],
        capabilities=[],
        handled_intents=["dispute", "lookup"],
        phrases=[
            "transaction details", "dispute status", "chargeback status",
        ],
        domain_words=["transaction", "dispute", "chargeback", "toll", "plaza",
                      "vehicle", "fastag", "wrong amount", "failed", "refund",
                      "duplicate charge"],
        negative_patterns=[
            "what is a", "define ", "meaning of", "explain what", "how does",
            "can you", "is it possible", "why does",
        ],
    ),
}

@dataclass
class ScoredAgent:
    agent_id: str
    score: float
    details: Dict[str, float]


class QueryClassifier:
    """Multi-feature weighted classifier for agent routing."""

    def __init__(self):
        self._configs: Dict[str, AgentConfigs] = copy.deepcopy(DEFAULT_CONFIGS)

    def register_agent(self, config: AgentConfigs):
        """Add or update an agent config."""
        self._configs[config.agent_id] = config

    def add_keywords(self, agent_id: str, keywords: List[str]):
        """Append keywords to an existing agent config."""
        if agent_id in self._configs:
            self._configs[agent_id].keywords.extend(keywords)

    def add_phrases(self, agent_id: str, phrases: List[str]):
        """Add phrase matches to an existing agent config."""
        if agent_id in self._configs:
            self._configs[agent_id].phrases.extend(phrases)

    def classify(self, query: str, intent: str = None) -> List[ScoredAgent]:
        """
        Classify which agent should handle the query.
        Returns ranked list of agents with scores.
        """
        query_lower = query.lower().strip()
        query_tokens = self._tokenize(query_lower)

        results = []
        for agent_id, config in self._configs.items():
            score, details = self._compute_score(query_lower, query_tokens, agent_id, config, intent)
            results.append(ScoredAgent(agent_id, score, details))

        return sorted(results, key=lambda x: x.score, reverse=True)

    def debug_classify(self, query: str, intent: str = None) -> List[ScoredAgent]:
        """Same as classify but returns all agents including score=0 for debugging."""
        return self.classify(query, intent)

    def _compute_score(
        self,
        query_lower: str,
        query_tokens: Set[str],
        agent_id: str,
        config: AgentConfigs,
        intent: str = None,
    ) -> Tuple[float, Dict[str, float]]:
        details = {}
        total = 0.0

        # ── Feature 1: Synonym-expanded keyword overlap (weight: 3) ───────────────
        kw_score = self._keyword_score(query_tokens, config.keywords)
        if kw_score > 0:
            details["keyword"] = kw_score
            total += kw_score

        # ── Feature 2: Phrase matching (weight: 8) ────────────────────────
        phrase_score = self._phrase_score(query_lower, config.phrases)
        if phrase_score > 0:
            details["phrase"] = phrase_score
            total += phrase_score

        # ── Feature 3: Domain word presence (weight: 2) ────────────────
        domain_score = self._domain_score(query_tokens, config.domain_words)
        if domain_score > 0:
            details["domain"] = domain_score
            total += domain_score

        # ── Feature 4: Query pattern detection (weight: 5) ─────────────
        pattern_scores = _detect_patterns(query_lower)
        pattern_weight = self._pattern_to_agent_weight(pattern_scores, agent_id)
        if pattern_weight > 0:
            details["pattern"] = pattern_weight
            total += pattern_weight

        # ── Feature 5: Negative signal (weight: -8) ───────────────────
        neg = pattern_scores.get("negative_routing", 0)
        if neg > 0:
            details["negative"] = neg
            total += neg

        # ── Feature 6: Capability overlap (weight: 1) ────────────────────
        cap_score = self._capability_score(query_tokens, config.capabilities)
        if cap_score > 0:
            details["capability"] = cap_score
            total += cap_score

        # ── Feature 7: Intent match (weight: 6) ────────────────────
        if intent and intent in config.handled_intents:
            details["intent"] = 6
            total += 6

        return total, details

    # ── Internal helpers ────────────────────────────────────────────────

    def _keyword_score(self, query_tokens: Set[str], keywords: List[str]) -> float:
        if not keywords:
            return 0
        score = 0
        for kw in keywords:
            kw_lower = kw.lower().strip()
            expanded = expand_word(kw_lower)
            overlap = expanded & query_tokens
            score += len(overlap) * 3
        return score

    def _phrase_score(self, query_lower: str, phrases: List[str]) -> float:
        if not phrases:
            return 0
        score = 0
        for phrase in phrases:
            phrase_lower = phrase.lower().strip()
            if phrase_lower in query_lower:
                # Longer phrases get higher score
                score += 8 + (len(phrase_lower.split()) - 1) * 2
        return score

    def _domain_score(self, query_tokens: Set[str], domain_words: List[str]) -> float:
        if not domain_words:
            return 0
        score = 0
        for word in domain_words:
            word_lower = word.lower().strip()
            expanded = expand_word(word_lower)
            overlap = expanded & query_tokens
            score += len(overlap) * 2
        return score

    @staticmethod
    def _capability_score(query_tokens: Set[str], capabilities: List[str]) -> float:
        if not capabilities:
            return 0
        score = 0
        for cap in capabilities:
            cap_tokens = QueryClassifier._tokenize(cap.lower())
            overlap = cap_tokens & query_tokens
            score += len(overlap) * 1
        return score

    @staticmethod
    def _pattern_to_agent_weight(patterns: Dict[str, float], agent_id: str) -> float:
        weight = 0
        mapping = {
            "aggregation": ["mlff", "support"],
            "ranking": ["mlff"],
            "comparison": ["mlff"],
            "trend": ["mlff"],
            "dispute_signal": ["dispute"],
        }
        for pid, w in patterns.items():
            if agent_id in mapping.get(pid, []):
                weight += w
        return weight

    @staticmethod
    def _tokenize(text: str) -> Set[str]:
        return set(re.findall(r'\b\w+', text))


# ── Pattern Definitions ──────────────────────────────────────────────────────
PATTERNS = [
    {
        "id": "aggregation",
        "weight": 4,
        "patterns": [
            r"\bhow many\b", r"\bhow much\b", r"\bwhat is the count\b", r"\bnumber of\b",
            r"\btotal\s+\w+", r"\boverall\s+\w+", r"\bsum\s+of\b", r"\bcount\s+of\b",
        ],
    },
    {
        "id": "ranking",
        "weight": 3,
        "patterns": [
            r"\btop\s+\d+", r"\bbottom\s+\d+", r"\bhighest\s+\w+", r"\blowest\s+\w+",
            r"\bbest\s+\w+", r"\bworst\s+\w+", r"\bmost\s+\w+", r"\bleast\s+\w+",
            r"\brank(?:ed|ing)?\b",
        ],
    },
    {
        "id": "comparison",
        "weight": 4,
        "patterns": [
            r"\bcompare\b", r"\bvs\.?\b", r"\bversus\b", r"\bdifference\b",
            r"\bbetween\b.*\band\b", r"\bagainst\b", r"\brelative\b",
        ],
    },
    {
        "id": "trend",
        "weight": 5,
        "patterns": [
            r"\bover time\b", r"\bmonthly\b", r"\bweekly\b", r"\bdaily\b",
            r"\bhourly\b", r"\btrend\b", r"\bgrowth\b", r"\bchange\b",
            r"\bhistory\b", r"\bprogression\b", r"\bseries\b",
            r"\bper\s+(?:month|week|day|hour|year|quarter)\b",
            r"\bby\s+(?:month|week|day|hour|year|quarter)\b",
        ],
    },
    {
        "id": "dispute_signal",
        "weight": 0,
        "patterns": [
            r'\bdispute\b', r'\bchargeback\b', r'\bdouble\s+charge\b', r'\bincorrect\b',
            r'\bwrong\s+amount\b', r'\bfailed\s+transaction\b', r'\brefund\b',
            r'\bduplicate\b', r'\bunauthorized\b',
        ],
    },
    {
        "id": "negative_routing",
        "weight": -8,
        "patterns": [
            r'\bwhat\s+is+a\s+\w+\b',
            r'\bdefine\b', r'\bmeaning\s+of\b', r'\bexplain\s+what\b',
            r'\bhow\s+does\s+\w+\s+work\b',
            r'\bcan\s+you\b', r'\bis\s+it\s+possible\b',
        ],
    },
]


def _detect_patterns(query_lower: str) -> Dict[str, float]:
    detected = {}
    for pattern_group in PATTERNS:
        pid = str(pattern_group["id"])
        weight = pattern_group["weight"]
        for pat in pattern_group["patterns"]:
            if re.search(pat, query_lower):
                detected[pid] = max(detected.get(pid, 0), weight)
    return detected
