"""
Capability-based Agent Bus – declarative, scoring-driven A2A routing.
Uses QueryClassifier for multi-feature weighted scoring instead of simple token overlap.
"""
import json
from core.logger import get_logger
from core.config import config
from core.agent_registry import discover_agents
from core.query_classifier import QueryClassifier, AgentConfigs

logger = get_logger("agent_bus")

# Registry: agent_id -> { "handler", "keywords", "handled_intents", "capabilities" }
_registry = {}

# Minimum score to bypass orchestrator (lowered from 3 because classifier is more accurate)
MIN_SCORE_DIRECT = 3


def register(agent_id: str, capabilities: list, handler,
             keywords: list = None, handled_intents: list = None):
    """Register an agent with its capabilities, keywords, and handled intents."""
    _registry[agent_id] = {
        "handler": handler,
        "capabilities": capabilities or [],
        "keywords": keywords or [],
        "handled_intents": handled_intents or [],
    }
    logger.info(f"Registered agent: {agent_id} | keywords: {keywords} | intents: {handled_intents}")


async def call_agent(agent_id: str, request: dict):
    if agent_id not in _registry:
        raise ValueError(f"Agent {agent_id} not found")
    return await _registry[agent_id]["handler"](request)


# ── Classifier instance (initialized at startup) ──────────────────────
_classifier = None


def _ensure_classifier() -> QueryClassifier:
    global _classifier
    if _classifier is None:
        _classifier = QueryClassifier()
    return _classifier


async def route(request: dict) -> dict:
    user_query = request.get("user_query", "")
    agent = request.get("agent")
    session_id = request.get("session_id", "")

    # 1. Manual selection
    if agent and agent != "auto":
        result = await call_agent(agent, request)
        result["handled_by"] = agent
        return result

    # 2. Skill match (only support agent for now – keep standalone)
    from agents.support.skills.skills_reader import match_skill
    skill, skill_score = match_skill(user_query)
    if skill and skill_score >= config.SKILL_MATCH_THRESHOLD:
        logger.info(f"Support skill match: {skill['name']}")
        if "support" in _registry:
            result = await call_agent("support", request)
            result["handled_by"] = "support"
            return result

    # 3. Classifier-based scoring (replaces old Level 3 + Level 4)
    classifier = _ensure_classifier()
    results = classifier.classify(user_query)
    top = results[0] if results else None

    if top and top.score >= MIN_SCORE_DIRECT:
        logger.info(f"Classifier match: {top.agent_id} (score={top.score:.1f})")
        if top.details:
            top_features = ", ".join(f"{k}:{v:.0f}" for k, v in top.details.items() if v != 0)
            logger.info(f"  features: {top_features}")
        if top.agent_id == "mlff":
            from agents.mlff.agent import _MLFF_CACHE
            request["orchestrator_payload"] = {
                "ok": True,
                "user_query": user_query,
                "intent": "lookup",
                "query_type": "simple",
                "confidence": 0.5,
                "selected_schema": _MLFF_CACHE["selected_schema"],
                "selected_tables": _MLFF_CACHE["selected_tables"],
                "schema_details": _MLFF_CACHE["schema_details"],
                "relationships_hint": _MLFF_CACHE["relationships_hint"],
                "context_summary": "",
                "routing_to": "mlff",
                "request_id": session_id,
            }
        result = await call_agent(top.agent_id, request)
        result["handled_by"] = top.agent_id
        return result

    # 4. No clear winner – orchestrator for intent → re-classify with intent
    if "orchestrator" in _registry:
        intent_result = await call_agent("orchestrator", {
            "user_query": user_query,
            "session_id": session_id
        })
        intent = intent_result.get("intent", "lookup")
        query_type = intent_result.get("query_type", "simple")
        confidence = intent_result.get("confidence", 0.0)

        # Re-classify with intent
        results = classifier.classify(user_query, intent=intent)
        top = results[0] if results else None

        if top:
            logger.info(f"Intent-based classifier match: {top.agent_id} (intent={intent}, score={top.score:.1f})")
            if top.details:
                top_features = ", ".join(f"{k}:{v:.0f}" for k, v in top.details.items() if v != 0)
                logger.info(f"  features: {top_features}")

            if top.agent_id == "mlff":
                from agents.mlff.agent import _MLFF_CACHE
                request["orchestrator_payload"] = {
                    "ok": True,
                    "user_query": user_query,
                    "intent": intent,
                    "query_type": query_type,
                    "confidence": confidence,
                    "selected_schema": _MLFF_CACHE["selected_schema"],
                    "selected_tables": _MLFF_CACHE["selected_tables"],
                    "schema_details": _MLFF_CACHE["schema_details"],
                    "relationships_hint": _MLFF_CACHE["relationships_hint"],
                    "context_summary": "",
                    "routing_to": "mlff",
                    "request_id": session_id,
                }
            result = await call_agent(top.agent_id, request)
            result["handled_by"] = top.agent_id
            return result

    # 5. Ultimate fallback to MLFF
    logger.warning("No agent matched, falling back to MLFF")
    if "mlff" in _registry:
        from agents.mlff.agent import _MLFF_CACHE
        request["orchestrator_payload"] = {
            "ok": True,
            "user_query": user_query,
            "intent": "lookup",
            "query_type": "simple",
            "confidence": 0.5,
            "selected_schema": _MLFF_CACHE["selected_schema"],
            "selected_tables": _MLFF_CACHE["selected_tables"],
            "schema_details": _MLFF_CACHE["schema_details"],
            "relationships_hint": _MLFF_CACHE["relationships_hint"],
            "context_summary": "",
            "routing_to": "mlff",
            "request_id": session_id,
        }
        result = await call_agent("mlff", request)
        result["handled_by"] = "mlff"
        return result

    return {"error": "No agent available"}
