"""
Visualization Spec Builder
Orchestrates: classify → generate candidates → LLM picks → return spec JSON.
Also provides enrich_with_viz() for easy integration into any agent.
"""
import json
from typing import Any, Dict, List

from core.viz.column_classifier import classify_columns
from core.viz.chart_candidate_generator import (
    generate_candidates,
    detect_kpis,
    select_table_columns,
)
from core.llm_client import call_llm
from core.logger import get_logger

logger = get_logger("viz_spec_builder")


def build_visualization(
    user_query: str,
    sql: str,
    rows: List[Dict],
    columns: List[str],
    explanation: str = "",
) -> str:
    try:
        col_types = classify_columns(rows, columns)

        type_summary = {k: v['type'] for k, v in col_types.items()}
        logger.debug(f"[VIZ] Types: {type_summary}")

        candidates = generate_candidates(user_query, rows, columns, col_types)
        logger.info(f"[VIZ] {len(candidates)} chart candidates")

        kpis = detect_kpis(user_query, rows, columns, col_types)

        chart_cols = set()
        for c in candidates:
            chart_cols.add(c["x_column"])
            chart_cols.update(c["y_columns"])

        table_cols, hidden_cols = select_table_columns(user_query, columns, col_types, list(chart_cols))

        if not candidates and not kpis:
            return json.dumps({
                "charts": [],
                "kpi_cards": [],
                "table_display_columns": columns,
                "hidden_columns": [],
            })

        selected = candidates
        if len(candidates) > 1:
            selected = _llm_pick(user_query, candidates, col_types)

        return json.dumps({
            "charts": selected,
            "kpi_cards": kpis,
            "table_display_columns": table_cols if table_cols else columns,
            "hidden_columns": hidden_cols,
        })

    except Exception as e:
        logger.error(f"[VIZ] Error: {e}")
        return json.dumps({
            "charts": [],
            "kpi_cards": [],
            "table_display_columns": columns if columns else [],
            "hidden_columns": [],
        })


def _llm_pick(user_query: str, candidates: list, col_types: dict) -> list:
    if len(candidates) <= 1:
        return candidates

    query_lower = user_query.lower()
    if any(w in query_lower for w in ["trend", "over time", "monthly", "daily"]):
        lines = [c for c in candidates if c["type"] == "line"]
        if lines:
            return lines
    if any(w in query_lower for w in ["compare", " vs ", "versus", "breakdown"]):
        bars = [c for c in candidates if c["type"] in ("bar", "pie")]
        if bars:
            return bars

    prompt = f"""User asked: "{user_query}"

Pick 1-2 charts that best answer the question:

{json.dumps(candidates, indent=2)}

Return ONLY a JSON array of the chosen objects. No explanation. No markdown."""

    try:
        raw = call_llm("Return only JSON arrays. No markdown.", prompt, max_tokens=512)
        raw = raw.strip()
        if "```" in raw:
            for part in raw.split("```"):
                s = part.strip()
                if s.startswith("["):
                    raw = s
                    break
        picked = json.loads(raw)
        if isinstance(picked, list) and picked:
            valid = []
            for p in picked:
                for c in candidates:
                    if c["type"] == p.get("type") and c["x_column"] == p.get("x_column"):
                        merged = {**c}
                        if "title" in p and p["title"]:
                            merged["title"] = p["title"]
                        if "y_columns" in p:
                            merged["y_columns"] = p["y_columns"]
                        if "options" in p:
                            merged["options"] = {**c.get("options", {}), **p["options"]}
                        valid.append(merged)
                        break
            if valid:
                return valid[:2]
    except Exception as e:
        logger.warning(f"[VIZ] LLM pick failed: {e}")

    return candidates[:1]


def enrich_with_viz(result: dict, user_query: str) -> dict:
    """Add viz spec to any agent result dict. Call before json.dumps."""
    rows = result.get("rows", [])
    columns = result.get("columns", [])

    if not rows:
        result["viz"] = {"charts": [], "kpi_cards": [], "table_display_columns": columns, "hidden_columns": []}
        return result

    try:
        viz_json = build_visualization(
            user_query=user_query,
            sql=result.get("sql", ""),
            rows=rows,
            columns=columns,
            explanation=result.get("explanation", ""),
        )
        result["viz"] = json.loads(viz_json)
    except Exception as e:
        logger.warning(f"[VIZ] Enrich failed: {e}")
        result["viz"] = {"charts": [], "kpi_cards": [], "table_display_columns": columns, "hidden_columns": []}

    return result
