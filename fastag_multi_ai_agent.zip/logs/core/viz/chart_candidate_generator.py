"""
Chart Candidate Generator
Rule-based engine that produces chart configurations from classified columns.
"""
from typing import Any, Dict, List

MAX_CAT_PIE = 8
MAX_CAT_BAR = 40
MAX_CANDIDATES = 4
MAX_Y_COLS = 3


def generate_candidates(
    user_query: str,
    rows: List[Dict],
    columns: List[str],
    col_types: Dict[str, Dict],
) -> List[Dict]:
    if not rows or not columns:
        return []

    candidates = []
    temporals = [c for c in columns if col_types.get(c, {}).get("type") == "temporal"]
    small_cats = [
        c for c in columns
        if col_types.get(c, {}).get("type") == "categorical"
        and col_types[c].get("unique_count", 0) <= MAX_CAT_BAR
    ]
    pie_cats = [
        c for c in small_cats
        if col_types[c].get("unique_count", 0) <= MAX_CAT_PIE
    ]
    numerics = [c for c in columns if col_types.get(c, {}).get("type") == "numeric"]

    query_lower = user_query.lower()
    is_trend = any(w in query_lower for w in ["trend", "over time", "monthly", "daily", "weekly", "hourly", "history"])

    # ── Rule 1: Temporal + Numeric → Line ────────────────────────
    if temporals and numerics:
        x = temporals[0]
        ys = numerics[:MAX_Y_COLS]
        candidates.append({
            "type": "line",
            "title": _title(ys[0], "over time"),
            "x_column": x,
            "y_columns": ys,
            "priority": 10 if is_trend else 7,
            "options": {"fill": len(ys) == 1, "tension": 0.3},
        })

    # ── Rule 2: Small categorical + Numeric → Pie ───────────────────
    if pie_cats and numerics:
        for x in pie_cats[:2]:
            candidates.append({
                "type": "pie",
                "title": _title(numerics[0], f"by {x}"),
                "x_column": x,
                "y_columns": [numerics[0]],
                "priority": 6,
                "options": {},
            })

    # ── Rule 3: Categorical + Numeric → Bar ───────────────────────
    if small_cats and numerics:
        for x in small_cats[:2]:
            for y in numerics[:2]:
                uc = col_types[x].get("unique_count", 0)
                candidates.append({
                    "type": "bar",
                    "title": _title(y, f"by {x}"),
                    "x_column": x,
                    "y_columns": [y],
                    "priority": 8 if uc > 10 else 6,
                    "options": {"horizontal": uc > 10},
                })

    # ── Rule 4: Multi-series: multiple numerics + categorical → grouped bar ─
    if len(numerics) >= 2 and small_cats:
        x = small_cats[0]
        ys = numerics[:MAX_Y_COLS]
        candidates.append({
            "type": "bar",
            "title": f"Comparison by {x}",
            "x_column": x,
            "y_columns": ys,
            "priority": 5,
            "options": {"grouped": True},
        })

    # ── Rule 5: Multi-series: multiple numerics + temporal → multi-line ─
    if len(numerics) >= 2 and temporals:
        x = temporals[0]
        ys = numerics[:MAX_Y_COLS]
        candidates.append({
            "type": "line",
            "title": "Trends comparison",
            "x_column": x,
            "y_columns": ys,
            "priority": 5 if is_trend else 4,
            "options": {"fill": False, "tension": 0.3},
        })

    # ── Rule 6: 2 numerics, no categorical/temporal → scatter ──
    if len(numerics) >= 2 and not small_cats and not temporals:
        candidates.append({
            "type": "scatter",
            "title": f"{numerics[0]} vs {numerics[1]}",
            "x_column": numerics[0],
            "y_columns": [numerics[1]],
            "priority": 2,
            "options": {},
        })

    # ── Deduplicate and rank ──────────────────────────────────────
    seen = set()
    unique = []
    for c in sorted(candidates, key=lambda x: x.get("priority", 0), reverse=True):
        key = (c["type"], c["x_column"], tuple(c["y_columns"]))
        if key not in seen:
            seen.add(key)
            unique.append(c)
    return unique[:MAX_CANDIDATES]


def detect_kpis(
    user_query: str,
    rows: List[Dict],
    columns: List[str],
    col_types: Dict[str, Dict],
) -> List[Dict]:
    kpis = []
    numerics = [c for c in columns if col_types.get(c, {}).get("type") == "numeric"]

    # Single row → all numerics are KPIs
    if len(rows) == 1:
        for col in numerics:
            val = rows[0].get(col)
            kpis.append({
                "label": _humanize(col),
                "column": col,
                "row": 0,
                "format": _detect_format(col, val),
                "value": val,
            })
        return kpis

    # Multi-row but query asks for aggregate
    query_lower = user_query.lower()
    agg_words = ["total", "average", "avg", "count", "how many", "sum", "overall", "number of"]
    if any(w in query_lower for w in agg_words) and numerics:
        best = numerics[0]
        for col in numerics:
            for word in query_lower.split():
                if word in col.lower():
                    best = col
                    break
            else:
                continue
            break

        total = sum(float(str(r.get(best, 0)) or 0) for r in rows)
        kpis.append({
            "label": f"Total {_humanize(best)}",
            "column": best,
            "value": total,
            "format": _detect_format(best, total),
            "computed": True,
        })

    return kpis


def select_table_columns(
    user_query: str,
    columns: List[str],
    col_types: Dict[str, Dict],
    chart_cols: List[str],
) -> tuple:
    query_lower = user_query.lower()
    show = set(chart_cols)

    for col in columns:
        if col.lower() in query_lower:
            show.add(col)

    for col in columns:
        ct = col_types.get(col, {})
        if ct.get("type") == "categorical" and ct.get("unique_count", 0) <= 30:
            show.add(col)
        elif ct.get("type") == "text":
            avg_len = sum(len(str(v)) for v in ct.get("sample_values", [])) / max(len(ct.get("sample_values", [])), 1)
            if avg_len < 60:
                show.add(col)

    hide = set()
    for col in columns:
        ct = col_types.get(col, {})
        if ct.get("type") == "id":
            hide.add(col)
        elif ct.get("type") == "text":
            avg_len = sum(len(str(v)) for v in ct.get("sample_values", [])) / max(len(ct.get("sample_values", [])), 1)
            if avg_len > 120:
                hide.add(col)

    show -= hide
    ordered = [c for c in columns if c in show]
    return ordered, list(hide)


def _title(y_col: str, suffix: str) -> str:
    return f"{_humanize(y_col)} {suffix}"


def _humanize(col: str) -> str:
    return col.replace("_", " ").replace(".", " ").title().strip()


def _detect_format(col: str, value: Any) -> str:
    cl = col.lower()
    if any(w in cl for w in ["amount", "revenue", "price", "salary", "cost", "fee", "tax", "payment", "income", "earnings", "value"]):
        return "currency"
    if any(w in cl for w in ["percent", "rate", "ratio", "usage"]):
        return "percent"
    if _try_float_val(value) is not None:
        return "number"
    return "text"


def _try_float_val(v) -> float:
    try:
        return float(str(v).replace(",", "").strip())
    except (ValueError, TypeError):
        return None
    