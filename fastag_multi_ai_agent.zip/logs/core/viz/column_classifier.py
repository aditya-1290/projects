"""
Column Classifier
Analyzes result set columns and classifies each as:
numeric, categorical, temporal, id, boolean, text
"""
from typing import Any, Dict, List
from collections import Counter
from datetime import datetime
import re


def classify_columns(rows: List[Dict], columns: List[str]) -> Dict[str, Dict]:
    if not rows or not columns:
        return {}

    result = {}

    for col in columns:
        values = [row.get(col) for row in rows]
        non_null = [v for v in values if v is not None]
        null_count = len(values) - len(non_null)

        info = {
            "unique_count": len(set(str(v) for v in non_null)),
            "null_count": null_count,
            "sample_values": [str(v)[:60] for v in non_null[:5]],
        }

        if _is_boolean(non_null):
            info["type"] = "boolean"
        elif _is_temporal(col, non_null):
            info["type"] = "temporal"
        elif _is_id(col, non_null):
            info["type"] = "id"
        elif _is_numeric(non_null):
            info["type"] = "numeric"
            nums = [float(v) for v in non_null if _try_float(v) is not None]
            if nums:
                info["numeric_stats"] = {
                    "min": round(min(nums), 4),
                    "max": round(max(nums), 4),
                    "mean": round(sum(nums) / len(nums), 4),
                }
        else:
            unique_ratio = info["unique_count"] / max(len(non_null), 1)
            avg_len = sum(len(str(v)) for v in non_null) / max(len(non_null), 1)
            if unique_ratio < 0.25 or info["unique_count"] <= 20:
                info["type"] = "categorical"
                value_counts = Counter(str(v) for v in non_null)
                info["top_values"] = value_counts.most_common(30)
            else:
                info["type"] = "text"

        result[col] = info

    return result


def _try_float(v) -> float:
    try:
        return float(str(v).replace(",", "").strip())
    except (ValueError, TypeError):
        return None


def _is_boolean(values: list) -> bool:
    if not values:
        return False
    lower = {str(v).lower() for v in values}
    return lower.issubset({"true", "false", "t", "f", "0", "1", "yes", "no"})


def _is_temporal(col_name: str, values: list) -> bool:
    hints = [
        "date", "time", "month", "year", "day", "hour", "minute",
        "second", "created", "updated", "timestamp", "recorded_at", "log_time",
    ]
    col_lower = col_name.lower()
    if any(h in col_lower for h in hints):
        return True
    for v in values[:5]:
        if v is None:
            continue
        s = str(v).strip()[:19]
        for fmt in [
            "%Y-%m-%d", "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S",
            "%d-%m-%Y", "%d/%m/%Y", "%Y-%m", "%Y",
        ]:
            try:
                datetime.strptime(s, fmt)
                return True
            except ValueError:
                continue
    return False


def _is_id(col_name: str, values: list) -> bool:
    col_lower = col_name.lower().strip()

    # Aggregate aliases that are commonly mistaken for IDs
    _aggregate_aliases = {"total", "count", "sum", "average", "avg", "mean", "min", "max",
                      "num", "cnt", "qty", "amount", "balance", "value"}
    if col_lower in _aggregate_aliases:
        return False

    # Column name ends with _id
    if col_lower.endswith("_id") or col_lower == "id":
        return True

    # All values are unique numbers — likely an auto-increment or sequence
    if values and len(values) > 2 and len(set(str(v) for v in values)) == len(values):
        if all(_try_float(v) is not None for v in values):
            return True

    return False


def _is_numeric(values: list) -> bool:
    if not values:
        return False
    hits = sum(1 for v in values[:20] if _try_float(v) is not None)
    return hits / len(values[:20]) > 0.8
