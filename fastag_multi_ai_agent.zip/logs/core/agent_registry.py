"""
Dynamic agent discovery – scans the agents/ directory for sub‑packages
that expose an AGENT_CARD in agent_card.py, filters by ENABLED_AGENTS.
"""
import importlib
import json
from pathlib import Path

from core.config import config
from core.logger import get_logger

logger = get_logger("agent_registry")

AGENTS_DIR = Path(__file__).resolve().parent.parent / "agents"


def discover_agents() -> list[dict]:
    if not AGENTS_DIR.is_dir():
        logger.error(f"Agents directory not found: {AGENTS_DIR}")
        return []

    enabled = set(config.ENABLED_AGENTS)
    logger.info(f"Enabled agent IDs: {enabled}")          # new
    result = []

    for entry in sorted(AGENTS_DIR.iterdir()):            # sorted for consistency
        if not entry.is_dir() or entry.name.startswith("_"):
            continue

        agent_card_file = entry / "agent_card.py"
        if not agent_card_file.exists():
            logger.warning(f"No agent_card.py in {entry.name}, skipping")
            continue

        module_name = f"agents.{entry.name}.agent_card"
        try:
            card_module = importlib.import_module(module_name)
        except Exception as e:
            logger.warning(f"Could not import {module_name}: {e}")
            continue

        card = getattr(card_module, "AGENT_CARD", None)
        if card is None:
            logger.warning(f"{entry.name}: agent_card.py has no AGENT_CARD attribute, skipping")
            continue

        # Convert to dict
        if hasattr(card, "to_dict"):
            info = card.to_dict()
        elif isinstance(card, dict):
            info = card.copy()
        else:
            logger.warning(f"{entry.name}: AGENT_CARD is neither dict nor has to_dict(), skipping")
            continue

        agent_id = info.get("agent_id", entry.name)
        logger.info(f"Found agent: {agent_id}")

        if agent_id not in enabled:
            logger.warning(f"{agent_id} not in ENABLED_AGENTS, skipping")
            continue
        if agent_id == "orchestrator":
            logger.info("Skipping orchestrator")
            continue

        info["agent_id"] = agent_id
        result.append(info)

    logger.info(f"Discovered agents: {[a['agent_id'] for a in result]}")
    return result
