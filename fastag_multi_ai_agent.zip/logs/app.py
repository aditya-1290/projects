"""
app.py - FIXED with capability‑based Agent Bus
"""
import core.suppress_warnings

import os
import sys
sys.path.insert(0, os.path.dirname(__file__))

from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from typing import Optional
import httpx
import logging

# Silence LiteLLM logging
logging.getLogger("LiteLLM").setLevel(logging.ERROR)
logging.getLogger("litellm").setLevel(logging.ERROR)

from core.logger import get_logger, success_logger, error_logger
from core.session_manager import get_or_create_session, add_to_history, get_history
from core.config import config
from core.agent_registry import discover_agents
from core.agent_bus import register, route as bus_route

logger = get_logger("app")
app = FastAPI(title="MLFF ADK Analytics", version="3.0.0")
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")


class QueryRequest(BaseModel):
    message: str
    session_id: Optional[str] = None
    agent: Optional[str] = None  # "auto", "mlff", "support", "dispute"


@app.on_event("startup")
async def startup():
    # Check LLM health
    try:
        async with httpx.AsyncClient(timeout=60.0) as client:
            resp = await client.get(f"{config.LOCAL_LLM_BASE_URL}/models")
            if resp.status_code == 200:
                logger.info("LLM server is healthy")
            else:
                logger.warning(f"LLM server returned status {resp.status_code}")
    except Exception as e:
        logger.error(f"LLM server not reachable: {e}")

    # ── Register all agents with the bus ────────────────────────
    from agents.orchestrator.agent import run_orchestrator_async
    from agents.mlff.agent import run_mlff_async, _MLFF_CACHE
    from agents.support.agent import run_support_async
    from agents.dispute.agent import run_dispute_async

    from agents.mlff.agent_card import MLFF_CARD
    from agents.support.agent_card import SUPPORT_CARD
    from agents.dispute.agent_card import DISPUTE_CARD

    # Orchestrator – only intent detection, no keywords/intents needed
    register("orchestrator", ["intent_detection"],
             lambda req: run_orchestrator_async(
                 req.get("user_query", ""),
                 req.get("session_id", "")
             ))

    # MLFF – ad‑hoc SQL generation
    register("mlff", MLFF_CARD.capabilities,
             lambda req: run_mlff_async(
                 req.get("orchestrator_payload", {}),
                 req.get("session_id", "")
             ),
             keywords=MLFF_CARD.keywords,
             handled_intents=MLFF_CARD.handled_intents)

    # Support – skill‑based lookups
    register("support", SUPPORT_CARD.capabilities,
             lambda req: run_support_async(
                 req.get("user_query", ""),
                 req.get("session_id", "")
             ),
             keywords=SUPPORT_CARD.keywords,
             handled_intents=SUPPORT_CARD.handled_intents)

    # Dispute – dispute investigation + log analysis
    register("dispute", DISPUTE_CARD.capabilities,
             lambda req: run_dispute_async(
                 req.get("user_query", ""),
                 req.get("session_id", "")
             ),
             keywords=DISPUTE_CARD.keywords,
             handled_intents=DISPUTE_CARD.handled_intents)

    logger.info("All agents registered with the bus")


@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.post("/query")
async def query(payload: QueryRequest):
    session_id = get_or_create_session(payload.session_id)
    user_query = payload.message.strip()
    if not user_query:
        raise HTTPException(status_code=400, detail="Query cannot be empty.")

    success_logger.info(f"Query received | session={session_id} | query={user_query[:80]}")

    request_data = {
        "user_query": user_query,
        "session_id": session_id,
        "agent": payload.agent,      # None, "auto", or specific agent ID
    }

    try:
        agent_result = await bus_route(request_data)

        add_to_history(session_id, {
            "user_query": user_query,
            "sql": agent_result.get("sql", ""),
            "row_count": agent_result.get("row_count", 0),
            "explanation": agent_result.get("explanation", ""),
            "intent": agent_result.get("intent", ""),
            "confidence": agent_result.get("confidence", 0),
            "ok": agent_result.get("ok", False),
        })

        return {**agent_result, "session_id": session_id}

    except Exception as e:
        error_logger.error(f"Pipeline error: {e}")
        return JSONResponse(status_code=500, content={
            "ok": False, "error": str(e), "session_id": session_id,
            "sql": "", "rows": [], "row_count": 0,
            "explanation": str(e), "chart_type": "none", "columns": [],
        })


@app.get("/history/{session_id}")
def get_session_history(session_id: str):
    return {"session_id": session_id, "history": get_history(session_id)}


@app.get("/health")
def health():
    return {"status": "ok", "service": "MLFF ADK App v3"}


@app.get("/agent-cards")
def agent_cards():
    from agents.orchestrator.agent_card import ORCHESTRATOR_CARD
    from agents.mlff.agent_card import MLFF_CARD
    from agents.dispute.agent_card import DISPUTE_CARD
    from agents.support.agent_card import SUPPORT_CARD
    return {
        "orchestrator": ORCHESTRATOR_CARD.to_dict(),
        "mlff": MLFF_CARD.to_dict(),
        "support": SUPPORT_CARD.to_dict(),
        "dispute": DISPUTE_CARD.to_dict(),
    }


@app.get("/agents")
def list_agents():
    return discover_agents()
