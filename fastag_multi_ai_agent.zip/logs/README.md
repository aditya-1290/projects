# FastTag MLFF AI Agent

A modular multi-agent system that answers natural language questions about your PostgreSQL database.

It combines **pre-defined business queries**, **ad-hoc SQL generation**, and **external log analysis** into a single chat-like interface.

---

# Features

* 🔹 **Natural Language to SQL**

  * Ask questions in plain English and get database results instantly.

* 🔹 **Multiple Specialized Agents**

  * **Support Agent**

    * Matches user questions to pre-built SQL queries stored in `skills.md`.
  * **MLFF Agent**

    * Generates safe, read-only SQL for ad-hoc database analysis.
  * **Dispute Agent**

    * Investigates toll transactions, chargebacks, failed payments, and optionally calls an external log analysis service.
  * **Orchestrator**

    * Detects user intent and routes requests to the appropriate agent automatically.

* 🔹 **Dynamic Agent Selection**

  * Select an agent manually from the UI or let the orchestrator decide automatically.

* 🔹 **Database Safety**

  * Only `SELECT` statements are permitted.
  * SQL validation prevents unsafe queries.
  * Row limits are enforced.

* 🔹 **Rich Visualization**

  * Interactive tables
  * Bar charts
  * Line charts
  * Pie charts

* 🔹 **External Service Integration**

  * The Dispute Agent can combine database results with an external log analysis service.

* 🔹 **Configurable Agents**

  * Enable or disable agents directly from the `.env` file.

* 🔹 **Modular Architecture**

  * Add a new agent simply by creating an agent folder with an `agent_card.py` and its runner.

---

# Architecture

```text
                     User Query
                          │
                          ▼
                ┌──────────────────┐
                │   Orchestrator   │
                │ Intent Detection │
                │     Routing      │
                └────────┬─────────┘
                         │
          ┌──────────────┴──────────────┐
          ▼                             ▼
 ┌────────────────┐          ┌──────────────────────┐
 │ Support Agent  │          │ MLFF / Dispute / ... │
 │ Skill Matching │          │ SQL Generation       │
 └───────┬────────┘          └─────────┬────────────┘
         │                              │
         └──────────────┬───────────────┘
                        ▼
               ┌────────────────┐
               │   MCP Server   │
               │ Database Layer │
               └───────┬────────┘
                       ▼
               ┌────────────────┐
               │   PostgreSQL   │
               └────────────────┘
```

All agents communicate with the local LLM (Gemma or Qwen) through a custom **Tool Call Parser Bridge**, which intercepts plain-text tool calls and executes the corresponding Python functions.

The web frontend is built using:

* FastAPI
* Jinja2
* Chart.js

---

# Project Structure

```text
.
├── agents/
│   ├── orchestrator/          # Intent detection & routing
│   ├── support/               # Pre-defined SQL skills
│   ├── mlff/                  # Dynamic SQL generation
│   └── dispute/               # Dispute investigation & log analysis
│
├── core/
│   ├── config.py
│   ├── tool_call_parser.py
│   ├── mcp_client.py
│   ├── llm_client.py
│   └── ...
│
├── mcp_server/                # MCP database server
├── static/                    # CSS, JavaScript, Chart.js
├── templates/                 # HTML templates
├── logs/                      # Application logs
│
├── app.py                     # FastAPI application
├── skills.md                  # Support Agent skills
├── dispute_skills.md          # Optional dispute skills
├── .env                       # Environment variables
└── requirements.txt
```

---

# Prerequisites

* Python **3.11+**
* PostgreSQL
* Local LLM Server

  * Gemma
  * Qwen
  * Running through `llama.cpp`
* MCP Server (included)

The application expects an OpenAI-compatible API running at:

```text
http://127.0.0.1:8083/v1
```

---

# Installation

## 1. Clone the Repository

```bash
git clone <repository-url>
cd FastTag-MLFF-Agent
```

---

## 2. Create a Virtual Environment

### Windows

```bash
python -m venv .venv
.venv\Scripts\activate
```

### Linux / macOS

```bash
python -m venv .venv
source .venv/bin/activate
```

---

## 3. Install Dependencies

```bash
pip install -r requirements.txt
```

---

## 4. Configure Environment Variables

Copy `.env.example` to `.env` (or edit the existing `.env`) and provide:

* PostgreSQL credentials
* LLM settings
* MCP configuration
* Agent configuration

---

# Environment Variables

| Variable              | Description                       | Default                               |
| --------------------- | --------------------------------- | ------------------------------------- |
| `POSTGRES_HOST`       | PostgreSQL host                   | `127.0.0.1`                           |
| `POSTGRES_PORT`       | PostgreSQL port                   | `5432`                                |
| `POSTGRES_USER`       | Database username                 | `postgres`                            |
| `POSTGRES_PASSWORD`   | Database password                 | `root`                                |
| `POSTGRES_DATABASE`   | Database name                     | `enterprisehub`                       |
| `MLFF_SCHEMA`         | Schema used by MLFF Agent         | `security`                            |
| `MLFF_TABLES`         | Allowed MLFF tables               | `user_accounts,user_roles`            |
| `DISPUTE_TABLES`      | Tables available to Dispute Agent | `toll.transactions,toll.disputes,...` |
| `LOG_SERVICE_ENABLED` | Enable external log service       | `true`                                |
| `LOG_SERVICE_URL`     | Log service endpoint              | `http://localhost:9002/analyze`       |
| `ENABLED_AGENTS`      | Enabled agents                    | `mlff,support,dispute`                |
| `LOCAL_LLM_BASE_URL`  | OpenAI-compatible API             | `http://127.0.0.1:8083/v1`            |
| `LOCAL_LLM_MODEL`     | Local model name                  | `local-model`                         |
| `GGUF_MODEL_PATH`     | GGUF model location               | *(your local path)*                   |

---

# Running the Application

Open **three terminals**.

---

## Terminal 1 — Start the LLM Server

```bash
llama-server \
-m D:\python_tasks\model\gemma-4-E4B-it-Q5_K_M.gguf \
--port 8083
```

---

## Terminal 2 — Start the MCP Server

```bash
python mcp_server/main.py
```

This starts:

* HTTP Server → Port **9000**
* SSE Server → Port **9001**

The MCP server scans the configured database and exposes safe read-only tools.

---

## Terminal 3 — Start the FastAPI Application

```bash
uvicorn app:app --host 127.0.0.1 --port 8000
```

Open your browser:

```text
http://127.0.0.1:8000
```

---

# Usage

1. Enter a natural language question in the query box.

Example:

```text
total revenue
```

```text
show top customers
```

```text
latest transactions
```

2. Select:

* Auto
* Support Agent
* MLFF Agent
* Dispute Agent

3. Click **Run Query**.

---

# Results Displayed

The application returns:

* Intent Detection
* Query Type
* Confidence Score
* Generated SQL
* Matched Skill (if applicable)
* Natural Language Explanation
* Result Table
* Interactive Charts

---

# Example Queries

### Support Agent

```text
total revenue
```

Matches the **"total revenue"** SQL skill.

---

### Dispute Agent

```text
latest transactions
```

Generates SQL for `toll.transactions` and optionally calls the external log service.

---

### MLFF Agent

```text
show all columns from table user_accounts
```

Generates SQL if `user_accounts` is included in `MLFF_TABLES`.

---

# Adding a New Agent

Create a new folder:

```text
agents/
    finance/
```

Inside the folder create:

```text
finance/
├── __init__.py
├── agent.py
└── agent_card.py
```

## `agent_card.py`

Define:

* `agent_id`
* `agent_name`
* `description`
* `to_dict()`

## `agent.py`

Implement:

```python
# run_finance_async(user_query, session_id)
```

Then:

1. Import the runner in `app.py`.
2. Add a routing branch.
3. Add the agent ID to:

```text
ENABLED_AGENTS
```

Restart the application.

The new agent will automatically appear in the UI.

---

# Adding a New Skill

Edit:

```text
skills.md
```

Each skill follows the format:

```markdown
## skill: Total Revenue

keywords:
revenue,total,sales

sql:
SELECT SUM(amount) FROM sales;
```

The Support Agent automatically matches user queries based on keyword overlap.

---

# Technology Stack

## Backend

* FastAPI
* Python
* PostgreSQL
* MCP Server

## Frontend

* HTML
* CSS
* JavaScript
* Jinja2
* Chart.js

## AI

* Gemma
* Qwen
* llama.cpp

## Database

* PostgreSQL

---

# Security

* Read-only SQL execution
* SQL validation
* Only `SELECT` statements allowed
* Row limits enforced
* Safe database access through the MCP Server

---

# Future Improvements

* Multi-turn conversation memory
* Agent collaboration
* More visualization types
* Authentication and user roles
* Additional business agents
* Streaming responses
* SQL explanation mode
* Export results to CSV / Excel / PDF

---

# License

This project is intended for internal use and demonstration purposes unless otherwise specified.

## Natural Language Queries

**for support agent**

How many customers do we have?

Show me the total number of orders.

How many products are there in inventory?

What is our total revenue?

Show me all active users.

How many employees do we have?

Show me all support tickets.

How many error logs are there?

Which products have low stock?

Show me the top 10 customers.

Can you tell me the customer count?

How many people have bought from us?

What is the size of our customer base?

How many orders have been placed?

How many sales orders exist?

What's our order volume?

Which customers order most often?

Who are our best customers?

Who spends the most money?

Which products sell the best?

Which department has the highest salary expense?

Who are our highest paid employees?

Show revenue generated by each customer.

Which employee processed the most orders?

Which supplier provides the most products?

What are the top 20 selling products?

Which products have never been ordered?

Show average order value.

What is the average salary by department?

Which department has the largest workforce?

How many support tickets are open?

How many tickets were resolved?

Which support agent handles the most tickets?

Show average customer rating.

What is the ticket distribution by status?

Which employees receive the highest feedback scores?

Show me unresolved tickets.

How many customers submitted feedback?

What percentage of tickets are resolved?

Who is overloaded with support work?

What is the total inventory value?

Which products are running out of stock?

Show products with stock below 10.

What is the average stock level?

Which warehouse stores the most inventory?  #### whether this query will fetch data or not will depend on the schema selected for mlff agent

Which supplier has the largest catalog?  ### whether this query will fetch data or not will depend on the schema selected for mlff agent

Show all out-of-stock products.  ### whether this query will fetch data or not will depend on the schema selected for mlff agent

Which category contains the most products?  ### whether this query will fetch data or not will depend on the schema selected for mlff agent

What are our most expensive products?  ### whether this query will fetch data or not will depend on the schema selected for mlff agent

What are our cheapest products?  #### no graphs from this query

What is our monthly revenue?  #### can show graphs for this query

Show revenue trends.  ##### can show graphs for this query

What was the revenue this month?   #### can show graphs for this query  \\ support agent

Which month had the highest revenue?   #### can show graphs for this query

What is the average payment amount?

Show the largest transactions.

How many invoices were generated?

What is our total income?

Who generates the most revenue?

Which customers contribute most to revenue?

==============Security Schema====================
How many active accounts exist?

Which role has the most users?

Show login statistics.

How many API keys have been generated?

Which users have admin access?

Show role distribution.

How many active sessions exist?

Who logged in most frequently?

Which permissions are most assigned?

List inactive accounts.
==========================================

How many application logs do we have?

Show all error logs.

Which services generate the most errors?

What is the busiest service?

How many warnings were recorded?

Show me services with high failure rates.

Which service is failing the most?

What percentage of logs are errors?

Show error trends.

Which services generate the most traffic?

Which customers generate the highest revenue?

Which employees generate the most sales?

Which products generate the most revenue?

Show customers who created support tickets.

Show revenue generated by each department.

Which department handles the most support tickets?

Which products are sold most frequently?

Which employees process the most orders?

Show customers who spend a lot and also create many tickets.

Which support agents handle high-value customers?

Show me the top customers and their revenue.

Which employee generated the most orders and revenue?

Give me total customers, orders, and revenue.

Show top products along with current stock.

Show ticket counts and average feedback ratings.

Compare revenue and support tickets by customer.

Show the top departments by salary cost and employee count.

List customers with the highest orders and support tickets.

Show the busiest services and their error rates.

Compare product sales against inventory levels.
