#!/bin/bash
# ============================================================
#  Start FastAPI server -- port 8003
#  Run AFTER both llama server and MCP server are up
# ============================================================

set -e
cd "$(dirname "$0")/.."

mkdir -p logs

echo ""
echo "  +--------------------------------------------------+"
echo "  |           FastAPI Server                         |"
echo "  +--------------------------------------------------+"
echo "  |  URL    : http://127.0.0.1:8003                  |"
echo "  |  Logs   : logs/api.log                           |"
echo "  +--------------------------------------------------+"
echo ""
echo "  Starting..."
echo "  --------------------------------------------------"
echo ""

python -m api.main 2>> logs/api.log | grep --line-buffered -iE "started|waiting|complete|running|POST|GET|ERROR|WARNING|query_received|query_completed"

echo ""
echo "  [INFO] FastAPI server stopped."