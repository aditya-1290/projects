@echo off
REM ============================================================
REM  Start FastAPI server — port 8003
REM  Run AFTER both llama server and MCP server are up
REM ============================================================

cd /d "%~dp0\.."

if not exist logs mkdir logs

echo.
echo  +--------------------------------------------------+
echo  ^|           FastAPI Server                         ^|
echo  +--------------------------------------------------+
echo  ^|  URL    : http://127.0.0.1:8003                  ^|
echo  ^|  Logs   : logs\api.log                           ^|
echo  +--------------------------------------------------+
echo.
echo  Starting...
echo  --------------------------------------------------
echo.

echo.
echo  [INFO] FastAPI server stopped.
pause