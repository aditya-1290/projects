#!/bin/bash
# ============================================================
#  Start MCP Server -- SSE (port 8001) + HTTP (port 8002)
#  Run AFTER llama server, BEFORE FastAPI
# ============================================================

set -e
cd "$(dirname "$0")/.."

mkdir -p logs

echo ""
echo "  +--------------------------------------------------+"
echo "  |           MCP Server  --  FastMCP                |"
echo "  +--------------------------------------------------+"
echo "  |  SSE    : http://127.0.0.1:8001/sse              |"
echo "  |  HTTP   : http://127.0.0.1:8002/mcp              |"
echo "  |  Logs   : logs/mcp.log                           |"
echo "  +--------------------------------------------------+"
echo ""
echo "  Starting..."
echo "  --------------------------------------------------"
echo ""

python -m mcp_server.server 2>> logs/mcp.log | grep --line-buffered -iE "started|waiting|complete|running|ERROR|WARNING|tool_called|tool_done|sse|http"

echo ""
echo "  [INFO] MCP server stopped."