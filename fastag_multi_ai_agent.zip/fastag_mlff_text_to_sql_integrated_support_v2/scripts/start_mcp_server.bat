@echo off
REM ============================================================
REM  Start MCP Server -- SSE (port 8001) + HTTP (port 8002)
REM  Run AFTER llama server, BEFORE FastAPI
REM ============================================================

cd /d "%~dp0\.."

if not exist logs mkdir logs

echo.
echo  +--------------------------------------------------+
echo  ^|           MCP Server  --  FastMCP                ^|
echo  +--------------------------------------------------+
echo  ^|  SSE    : http://127.0.0.1:8001/sse              ^|
echo  ^|  HTTP   : http://127.0.0.1:8002/mcp              ^|
echo  ^|  Logs   : logs\mcp.log                           ^|
echo  +--------------------------------------------------+
echo.
echo  Starting...
echo  --------------------------------------------------
echo.


echo.
echo  [INFO] MCP server stopped.
pause