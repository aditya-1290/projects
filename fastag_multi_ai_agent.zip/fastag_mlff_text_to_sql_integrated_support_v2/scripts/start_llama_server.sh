#!/bin/bash
# ============================================================
#  Start llama-cpp-python HTTP server (Mac -- Metal GPU)
#  Important logs shown on terminal -- rest goes to logs/llama.log
# ============================================================

set -e
cd "$(dirname "$0")/.."

MODEL_PATH="${LLAMA_MODEL_PATH:-/Users/$(whoami)/models/gemma.gguf}"
PORT="${LLAMA_PORT:-8000}"
N_CTX="${LLAMA_N_CTX:-2048}"
N_THREADS="${LLAMA_N_THREADS:-4}"
N_GPU_LAYERS="${LLAMA_N_GPU_LAYERS:-35}"

if [ ! -f "$MODEL_PATH" ]; then
    echo ""
    echo "  [ERROR] Model not found at: $MODEL_PATH"
    echo "          Update LLAMA_MODEL_PATH in .env or this script."
    echo ""
    exit 1
fi

mkdir -p logs

echo ""
echo "  +--------------------------------------------------+"
echo "  |        LLM Server  --  llama-cpp-python          |"
echo "  +--------------------------------------------------+"
echo "  |  Model   : $MODEL_PATH"
echo "  |  Port    : $PORT"
echo "  |  Context : $N_CTX tokens"
echo "  |  Threads : $N_THREADS"
echo "  |  GPU     : $N_GPU_LAYERS layers (Metal)"
echo "  |  Logs    : logs/llama.log"
echo "  +--------------------------------------------------+"
echo ""
echo "  Starting..."
echo "  --------------------------------------------------"
echo ""

python -m llama_cpp.server \
  --model "$MODEL_PATH" \
  --port "$PORT" \
  --n_ctx "$N_CTX" \
  --n_threads "$N_THREADS" \
  --n_gpu_layers "$N_GPU_LAYERS" \
  --host 127.0.0.1 \
  2>> logs/llama.log | grep --line-buffered -iE "started|waiting|complete|running|POST|GET|ERROR|WARNING"

echo ""
echo "  [INFO] Server stopped."