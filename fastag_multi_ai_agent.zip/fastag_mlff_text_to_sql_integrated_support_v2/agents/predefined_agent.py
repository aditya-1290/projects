# agents/predefined_agent.py
"""
Support Agent — predefined query matcher.

How it works:
  1. Loads hardcoded SQL queries from JSON file (path in .env)
  2. LLM sees ONLY intent labels (not SQL, not schema)
  3. LLM returns matching query number (1-15) or 0 for no match
  4. SQL is looked up from JSON and executed via MCP HTTP

Context given to LLM:
  - List of 15 intent descriptions (short labels only)
  - User query
  - Instruction to return a single number

This agent handles cross-schema queries that existing
single-schema agents cannot — because SQL is hardcoded
with explicit schema-qualified table names.

Configurable via .env:
  SUPPORT_AGENT_ENABLED=true
  SUPPORT_AGENT_NAME=support_agent
  SUPPORT_AGENT_QUERIES_FILE=./config/predefined_queries.json
"""

import json
import os
from pathlib import Path
from typing import List, Dict, Any, Optional

from google.adk.agents import LlmAgent
from google.adk.tools.mcp_tool.mcp_toolset import (
    MCPToolset,
    SseConnectionParams,
    StreamableHTTPConnectionParams,
)

from core.config import settings
from core.logging_config import get_logger

logger = get_logger("agent")

_MODEL = "openai/gemma-local"


# ── Load queries from JSON ─────────────────────────────────────────────────

def load_predefined_queries() -> List[Dict[str, Any]]:
    """
    Load hardcoded queries from JSON file.
    Path comes from .env: SUPPORT_AGENT_QUERIES_FILE
    Falls back to ./config/predefined_queries.json
    """
    queries_file = getattr(settings, "support_agent_queries_file",
                           "./config/predefined_queries.json")
    path = Path(queries_file)

    if not path.exists():
        logger.error("predefined_queries_file_not_found", path=str(path))
        return []

    try:
        with open(path, "r", encoding="utf-8") as f:
            queries = json.load(f)
        logger.info("predefined_queries_loaded",
                    count=len(queries), path=str(path))
        return queries
    except Exception as e:
        logger.error("predefined_queries_load_failed", error=str(e))
        return []


def get_query_by_id(queries: List[Dict], query_id: int) -> Optional[Dict]:
    """Look up a query by its id number."""
    for q in queries:
        if q["id"] == query_id:
            return q
    return None


def build_intent_list(queries: List[Dict]) -> str:
    """
    Build the intent label list shown to LLM.
    LLM sees ONLY id + description — never the SQL.
    """
    lines = []
    for q in queries:
        lines.append(f"{q['id']}. {q['intent']} — {q['description']}")
    return "\n".join(lines)


# ── Agent factory ──────────────────────────────────────────────────────────

def create_predefined_agent() -> Optional[LlmAgent]:
    """
    Build the support agent.
    Returns None if disabled in .env or queries file missing.
    """
    # Check if enabled
    enabled = str(getattr(settings, "support_agent_enabled", "true")).lower()
    if enabled == "false":
        logger.info("support_agent_disabled")
        return None

    agent_name = getattr(settings, "support_agent_name", "support_agent")
    queries = load_predefined_queries()

    if not queries:
        logger.error("support_agent_no_queries_found")
        return None

    intent_list = build_intent_list(queries)

    # ── System prompt ──────────────────────────────────────────────────────
    # LLM only sees intent labels — NOT SQL, NOT schema metadata
    # Job: return the matching number only
    system_prompt = f"""You are a query matcher. Your ONLY job is to match the user's question to one of these predefined queries.

PREDEFINED QUERIES:
{intent_list}

RULES:
- Read the user question carefully
- Find the query whose description best matches the user's intent
- Reply with ONLY the query number (example: 3)
- If no query matches, reply with ONLY: 0
- Do NOT explain your answer
- Do NOT generate SQL
- Do NOT write anything except the number
"""

    description = (
        "Handles standard predefined reports and cross-schema queries. "
        "Use this agent for: employee details with full names, "
        "salary reports, sales performance, vendor analysis, "
        "purchase orders by employee, monthly trends, territory revenue, "
        "product pricing, work order summaries. "
        "Best for standard business reports that span multiple schemas."
    )

    # ── Toolsets ───────────────────────────────────────────────────────────
    sse_toolset = MCPToolset(
        connection_params=SseConnectionParams(
            url=f"{settings.mcp_server_url}/sse"
        )
    )
    http_toolset = MCPToolset(
        connection_params=StreamableHTTPConnectionParams(
            url=f"{settings.mcp_http_url}/mcp"
        )
    )

    agent = LlmAgent(
        name=agent_name,
        model=_MODEL,
        description=description,
        instruction=system_prompt,
        tools=[sse_toolset, http_toolset],
    )

    logger.info("support_agent_created",
                agent=agent_name,
                query_count=len(queries))
    return agent