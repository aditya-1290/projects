# core/logging_config.py
"""
Clean terminal output — human-readable, color-coded, noise-free.
Uses plain ASCII only — no Unicode box chars that break Windows terminal.
Files still get full JSON logs. Terminal gets only what matters.

TERMINAL COLOR GUIDE:
  GREEN   = startup / success
  CYAN    = agent lifecycle / tool calls
  MAGENTA = routing decisions
  BLUE    = query received
  WHITE   = SQL / data
  DIM     = MCP internal calls (less important)
  YELLOW  = warnings
  RED     = errors
"""
import logging
import os
import structlog
from core.config import settings

# ── ANSI colors (plain, no Unicode) ──────────────────────────────────────
RESET   = "\033[0m"
BOLD    = "\033[1m"
DIM     = "\033[2m"
CYAN    = "\033[36m"
GREEN   = "\033[32m"
YELLOW  = "\033[33m"
RED     = "\033[31m"
BLUE    = "\033[34m"
MAGENTA = "\033[35m"
WHITE   = "\033[37m"

# ── ALL events shown on terminal ─────────────────────────────────────────
# Format: "event_key": (COLOR, "template with {placeholders}")
# Placeholders must match keys in the structlog event dict exactly.
_EVENT_FORMATS = {

    # ── Startup ──────────────────────────────────────────────────────────
    "server_startup":             (GREEN,        "[ BOOT ] Server starting up"),
    "agent_registry_initialized": (GREEN,        "[ BOOT ] Agent registry initialized"),
    "manager_agent_built":        (GREEN,        "[ BOOT ] Manager ready | sub_agents={sub_agents}"),
    "adk_runner_ready":           (BOLD+GREEN,   "[ BOOT ] System ready — all agents loaded"),
    "server_shutdown":            (YELLOW,       "[ BOOT ] Server shutting down"),

    # ── Agent creation ────────────────────────────────────────────────────
    "registry_creating_agent":    (CYAN,  "  [AGENT] Creating : {agent} (schema={schema})"),
    "agent_created":              (CYAN,  "  [AGENT] Ready    : {agent}"),
    "support_agent_created":      (CYAN,  "  [AGENT] Ready    : support_agent ({query_count} predefined queries)"),
    "support_agent_registered":   (CYAN,  "  [AGENT] Registered: support_agent"),
    "support_agent_disabled":     (YELLOW,"  [AGENT] support_agent DISABLED in .env"),
    "predefined_queries_loaded":  (GREEN, "  [AGENT] Predefined queries loaded: {count} from {path}"),
    "predefined_queries_load_failed": (RED, "  [ERROR] Failed to load predefined_queries.json: {error}"),
    "support_agent_no_queries_found": (RED, "  [ERROR] support_agent skipped — no queries loaded"),

    # ── Query lifecycle ───────────────────────────────────────────────────
    "query_received":     (BOLD+BLUE,  "\n[QUERY] #{query_id} | \"{user_query}\""),
    "transfer_detected":  (MAGENTA,    "  [ROUTE] manager -> {target_agent}"),
    "transfer_message_skipped": (DIM,  "  [ROUTE] transfer msg skipped (internal)"),

    # ── Schema agent flow ─────────────────────────────────────────────────
    "schema_agent_starting":  (CYAN,   "  [AGENT] Starting  : {agent}"),
    "schema_agent_response":  (DIM,    "  [AGENT] LLM responded (raw text captured)"),
    "sql_extracted":          (WHITE,  "  [SQL]   Extracted : {sql_preview}"),
    "rows_collected":         (GREEN,  "  [DATA]  Rows returned : {row_count}"),
    "chart_generated":        (GREEN,  "  [CHART] Chart generated for {agent}"),
    "schema_agent_done":      (BOLD+GREEN, "  [DONE]  Agent={agent} | rows={rows} | chart={has_chart}"),

    # ── Support agent (predefined query) flow ─────────────────────────────
    "predefined_query_matched":   (MAGENTA, "  [PREDEF] LLM matched query ID={query_id}"),
    "predefined_sql_selected":    (WHITE,   "  [PREDEF] Intent={intent} | SQL={sql_preview}"),
    "predefined_rows_collected":  (GREEN,   "  [PREDEF] Rows={row_count} | Intent={intent}"),
    "predefined_chart_generated": (GREEN,   "  [PREDEF] Chart generated | Intent={intent}"),
    "predefined_query_no_number": (YELLOW,  "  [PREDEF] WARN: LLM returned no number | response={response}"),

    # ── MCP HTTP calls (show tool name + result preview) ──────────────────
    "mcp_http_call":         (DIM,    "  [MCP]   --> {tool} | args={args_preview}"),
    "mcp_init_status":       (DIM,    "  [MCP]   init status={status}"),
    "mcp_session_acquired":  (DIM,    "  [MCP]   session={session_id}"),
    "mcp_http_result":       (DIM,    "  [MCP]   <-- {tool} | {preview}"),
    "mcp_http_call_failed":  (RED,    "  [MCP]   FAILED {tool} | error={error}"),

    # ── MCP server side (tool execution) ──────────────────────────────────
    "tool_called":         (CYAN,  "  [TOOL]  >> {tool} | {sql_preview}"),
    "tool_done":           (CYAN,  "  [TOOL]  << {tool} | {result_preview}"),
    "sse_server_starting": (GREEN, "[ MCP  ] SSE  server starting on port {port}"),
    "http_server_starting":(GREEN, "[ MCP  ] HTTP server starting on port {port}"),

    # ── Query completed ───────────────────────────────────────────────────
    "query_completed": (
        BOLD+GREEN,
        "  [DONE]  #{query_id} | agent={agent_used} | rows={rows} | time={duration_ms}"
    ),

    # ── Warnings ──────────────────────────────────────────────────────────
    "sql_validation_failed":   (YELLOW, "  [WARN]  SQL invalid: {error}"),
    "no_sql_extracted":        (YELLOW, "  [WARN]  No SQL extracted | agent={agent} | text={text_preview}"),
    "summary_generation_failed":(YELLOW,"  [WARN]  Summary LLM failed: {error}"),
    "predefined_sql_validation_failed": (YELLOW, "  [WARN]  Predefined SQL invalid: {error}"),

    # ── Errors ────────────────────────────────────────────────────────────
    "schema_agent_not_found": (RED, "  [ERROR] Agent not found: {agent}"),
    "manager_run_failed":     (RED, "  [ERROR] Manager failed: {error}"),
    "agent_run_failed":       (RED, "  [ERROR] Agent run failed: {error}"),
    "predefined_queries_file_not_found": (RED, "  [ERROR] predefined_queries.json not found at {path}"),
}

# ── Third-party loggers to silence on terminal ────────────────────────────
_SILENCE = [
    "litellm",
    "litellm.utils",
    "litellm.cost_calculator",
    "litellm.litellm_logging",
    "litellm.litellm_core_utils",
    "LiteLLM",
    "httpx",
    "httpcore",
    "openai",
    "google.adk",
    "google.adk.features",
    "google.auth",
    "urllib3",
    "asyncio",
    "mcp.server",
    "mcp.shared",
]


class _SafeDict(dict):
    """Returns '' for missing keys so .format_map never raises KeyError."""
    def __missing__(self, key):
        return ""


class _CleanConsoleHandler(logging.Handler):
    """
    Reads structlog JSON records.
    Prints ONLY known events in clean human-readable colored format.
    Everything else is silently dropped from terminal (still goes to file).
    """

    def emit(self, record: logging.LogRecord):
        # Drop noisy third-party loggers
        if any(record.name.startswith(s) for s in _SILENCE):
            return

        msg = record.getMessage()

        # Parse structlog JSON
        import json as _json
        try:
            data = _json.loads(msg)
        except Exception:
            # Not our structlog JSON — drop from terminal
            return

        event = data.get("event", "")
        fmt_entry = _EVENT_FORMATS.get(event)
        if not fmt_entry:
            # Unknown event — don't show on terminal
            return

        color, template = fmt_entry

        # Format duration nicely if present
        if "duration_ms" in data:
            ms = data["duration_ms"]
            if isinstance(ms, (int, float)):
                if ms < 1000:
                    data["duration_ms"] = f"{int(ms)}ms"
                else:
                    total_s = int(ms) // 1000
                    m, s = divmod(total_s, 60)
                    data["duration_ms"] = f"{m}m {s}s" if m else f"{s}s"

        # Truncate long fields for readability
        for field in ("sql_preview", "args_preview", "preview",
                      "result_preview", "text_preview", "response"):
            if field in data and isinstance(data[field], str):
                if len(data[field]) > 120:
                    data[field] = data[field][:120] + "..."

        try:
            text = template.format_map(_SafeDict(data))
        except Exception:
            text = template

        print(f"{color}{text}{RESET}", flush=True)


def setup_logging():
    os.makedirs(settings.log_dir, exist_ok=True)
    level = getattr(logging, settings.log_level.upper(), logging.INFO)

    fmt = logging.Formatter("%(message)s")

    def _file_handler(name: str, min_level: int = logging.DEBUG) -> logging.FileHandler:
        h = logging.FileHandler(
            os.path.join(settings.log_dir, name),
            encoding="utf-8",   # force UTF-8 in files
        )
        h.setLevel(min_level)
        h.setFormatter(fmt)
        return h

    # ── Root logger ───────────────────────────────────────────────────────
    root = logging.getLogger()
    root.setLevel(logging.DEBUG)
    root.addHandler(_file_handler("app.log"))
    root.addHandler(_file_handler("errors.log", logging.ERROR))

    # ── Per-module file ────────────────────────────────────────────────────
    agent_logger = logging.getLogger("agent")
    agent_logger.addHandler(_file_handler("agents.log"))
    agent_logger.propagate = True

    # ── Silence noisy third-party loggers (terminal only) ─────────────────
    for name in _SILENCE:
        logging.getLogger(name).setLevel(logging.CRITICAL)

    # ── Suppress pydantic / ADK warnings ──────────────────────────────────
    import warnings
    warnings.filterwarnings("ignore", category=UserWarning, module="pydantic")
    warnings.filterwarnings("ignore", category=UserWarning, module="google.adk")

    # ── Windows terminal: force UTF-8 output ──────────────────────────────
    # This prevents garbled characters on Windows CMD / PowerShell
    import sys
    if sys.platform == "win32":
        try:
            sys.stdout.reconfigure(encoding="utf-8")
        except Exception:
            pass

    # ── Clean console handler (terminal only) ─────────────────────────────
    console = _CleanConsoleHandler()
    console.setLevel(logging.DEBUG)
    root.addHandler(console)

    # ── structlog configuration ────────────────────────────────────────────
    structlog.configure(
        processors=[
            structlog.stdlib.add_log_level,
            structlog.stdlib.add_logger_name,
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.JSONRenderer(),
        ],
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )


def get_logger(name: str = "app"):
    return structlog.get_logger(name)