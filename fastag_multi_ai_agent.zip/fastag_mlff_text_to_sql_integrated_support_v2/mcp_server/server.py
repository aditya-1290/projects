# mcp_server/server.py
import sys
import os
import threading

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from mcp.server.fastmcp import FastMCP
from core.config import settings
from core.logging_config import setup_logging, get_logger

from mcp_server.tools.execute_sql import execute_sql
from mcp_server.tools.get_schema_metadata import get_schema_metadata
from mcp_server.tools.validate_sql import validate_sql
from mcp_server.tools.generate_visualization import generate_visualization
from mcp_server.tools.get_table_sample import get_table_sample

setup_logging()
logger = get_logger("mcp_server")

# ── SSE server on port 8001 ───────────────────────────────────────────────
mcp_sse = FastMCP("text_to_sql_tools_sse")

# ── Streamable HTTP server on port 8002 ───────────────────────────────────
mcp_http = FastMCP("text_to_sql_tools_http")


def register_tools(mcp_instance: FastMCP):
    """Register all tools on a FastMCP instance."""

    @mcp_instance.tool()
    def execute_sql_tool(sql: str) -> str:
        """Execute a PostgreSQL SQL query and return up to 10 rows as JSON."""
        logger.info("tool_called", tool="execute_sql_tool", sql_preview=sql[:80])
        result = execute_sql(sql)
        logger.info("tool_done", tool="execute_sql_tool", result_preview=result[:80])
        return result

    @mcp_instance.tool()
    def validate_sql_tool(sql: str) -> str:
        """Validate SQL syntax using PostgreSQL EXPLAIN."""
        logger.info("tool_called", tool="validate_sql_tool", sql_preview=sql[:80])
        result = validate_sql(sql)
        logger.info("tool_done", tool="validate_sql_tool", result=result)
        return result

    @mcp_instance.tool()
    def get_schema_metadata_tool(schema: str, tables: str) -> str:
        """Get table and column metadata for a schema."""
        logger.info("tool_called", tool="get_schema_metadata_tool", schema=schema)
        result = get_schema_metadata(schema, tables)
        logger.info("tool_done", tool="get_schema_metadata_tool", schema=schema)
        return result

    @mcp_instance.tool()
    def generate_visualization_tool(rows_json: str, user_query: str) -> str:
        """Decide if a chart is meaningful and generate Plotly HTML if so."""
        logger.info("tool_called", tool="generate_visualization_tool", query=user_query)
        result = generate_visualization(rows_json, user_query)
        logger.info("tool_done", tool="generate_visualization_tool", result_preview=result[:80])
        return result

    @mcp_instance.tool()
    def get_table_sample_tool(schema: str, table: str) -> str:
        """Preview column structure of a table."""
        logger.info("tool_called", tool="get_table_sample_tool", schema=schema, table=table)
        result = get_table_sample(schema, table)
        logger.info("tool_done", tool="get_table_sample_tool", schema=schema, table=table)
        return result


# Register tools on both instances
register_tools(mcp_sse)
register_tools(mcp_http)


def run_sse():
    logger.info("sse_server_starting", port=8001)
    print(f"[MCP SSE]  Starting on port 8001 ...")
    mcp_sse.settings.port = 8004
    mcp_sse.settings.host = "127.0.0.1"
    mcp_sse.run(transport="sse")


def run_http():
    logger.info("http_server_starting", port=8002)
    print(f"[MCP HTTP] Starting on port 8002 ...")
    mcp_http.settings.port = 8002
    mcp_http.settings.host = "127.0.0.1"
    mcp_http.run(transport="streamable-http")


if __name__ == "__main__":
    print("=" * 50)
    print("  MCP Server — SSE (8001) + HTTP (8002)")
    print("=" * 50)

    # Run SSE in background thread
    sse_thread = threading.Thread(target=run_sse, daemon=True)
    sse_thread.start()

    # Run HTTP in main thread
    run_http()