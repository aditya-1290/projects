# mcp_server/tools/generate_visualization.py
"""
MCP tool: generate_visualization
Decides if a chart is meaningful. If yes, returns Plotly HTML string.
Supports: bar, horizontal bar, line, pie, scatter, multi-bar charts.
"""
# import json
from typing import Any, Dict, List, Optional, Tuple


def _to_float(v: Any) -> Optional[float]:
    """
    Coerce value to float.
    Handles int, float, Decimal-as-string ("55000.00"), "1234", etc.
    Returns float on success, None on failure.
    """
    if isinstance(v, (int, float)):
        return float(v)
    if isinstance(v, str):
        try:
            return float(v.replace(",", "").strip())
        except ValueError:
            pass
    return None


def _detect_columns(rows: List[Dict]) -> Tuple[List[str], List[str]]:
    """
    Split columns into numeric and label (text) columns.
    Returns (numeric_cols, label_cols).
    """
    if not rows:
        return [], []

    first = rows[0]
    numeric_cols = [
        k for k, v in first.items()
        if _to_float(v) is not None
        and not k.lower().endswith("id")
        and not k.lower() in ("year", "month_num", "day_num")
    ]
    label_cols = [
        k for k in first.keys()
        if k not in numeric_cols
    ]
    return numeric_cols, label_cols


def _is_time_col(col_name: str) -> bool:
    time_hints = ["date", "month", "year", "time", "day", "period", "week", "quarter"]
    return any(h in col_name.lower() for h in time_hints)


def _pick_chart_type(
    rows: List[Dict],
    numeric_cols: List[str],
    label_cols: List[str],
    user_query: str,
) -> str:
    """
    Decide the best chart type based on data shape and query intent.

    Rules:
      pie        — ≤5 rows, 1 numeric, query has share/distribution feel
      scatter    — 2+ numeric cols, query has correlation feel
      multi_bar  — 2+ numeric cols, category label exists
      line       — label col is time-based
      hbar       — >6 rows, 1 numeric, long category labels
      bar        — default for category + 1 numeric
    """
    query_lower = user_query.lower()
    n_rows = len(rows)
    n_numeric = len(numeric_cols)
    label_col = label_cols[0] if label_cols else None

    # ── Pie ────────────────────────────────────────────────────────────────
    pie_keywords = ["share", "distribution", "breakdown", "percent", "proportion",
                    "by status", "by type", "by category", "composition"]
    if (
        n_rows <= 6
        and n_numeric == 1
        and any(kw in query_lower for kw in pie_keywords)
    ):
        return "pie"

    # ── Scatter ───────────────────────────────────────────────────────────
    scatter_keywords = ["vs", "versus", "correlation", "relationship",
                        "compare", "against", "scatter"]
    if n_numeric >= 2 and any(kw in query_lower for kw in scatter_keywords):
        return "scatter"

    # ── Multi-bar ─────────────────────────────────────────────────────────
    if n_numeric >= 2 and label_col and not _is_time_col(label_col):
        return "multi_bar"

    # ── Line ──────────────────────────────────────────────────────────────
    if label_col and _is_time_col(label_col):
        return "line"

    # ── Horizontal bar ────────────────────────────────────────────────────
    # Use when many rows or long label names
    if label_col:
        avg_label_len = sum(len(str(r.get(label_col, ""))) for r in rows) / n_rows
        if n_rows > 6 or avg_label_len > 12:
            return "hbar"

    # ── Default: vertical bar ─────────────────────────────────────────────
    return "bar"


def generate_visualization(rows_json: str, user_query: str) -> str:
    """
    Decide if chart is meaningful and generate Plotly HTML if so.

    Args:
        rows_json: JSON string of rows (list of dicts).
        user_query: The original user natural language query.

    Returns:
        JSON string: {"chart_html": "<div>...</div>" or null, "reason": str}
    """
    # ── Parse rows ─────────────────────────────────────────────────────────
    try:
        rows: List[Dict[str, Any]] = json.loads(rows_json)
    except Exception:
        return json.dumps({"chart_html": None, "reason": "Invalid rows JSON."})

    # ── Gate 1: need more than 1 row ───────────────────────────────────────
    if len(rows) <= 1:
        return json.dumps({
            "chart_html": None,
            "reason": "Single row or empty result — no chart needed.",
        })

    # ── Gate 2: need at least one numeric column ───────────────────────────
    numeric_cols, label_cols = _detect_columns(rows)
    if not numeric_cols:
        return json.dumps({
            "chart_html": None,
            "reason": "No numeric measure columns found — skipping chart.",
        })

    # ── Gate 3: query should look like aggregation/analysis ───────────────
    chart_keywords = [
        "total", "count", "sum", "average", "avg", "per", "by",
        "trend", "over time", "monthly", "yearly", "daily",
        "compare", "top", "highest", "lowest", "most", "least",
        "salary", "amount", "revenue", "quantity", "orders", "sales",
        "price", "cost", "profit", "rate", "ratio", "percent",
        "share", "distribution", "breakdown", "vs", "versus",
        "show", "list", "all",
    ]
    query_lower = user_query.lower()
    is_meaningful = any(kw in query_lower for kw in chart_keywords)

    if not is_meaningful and len(rows) < 3:
        return json.dumps({
            "chart_html": None,
            "reason": "Query does not appear to need a chart.",
        })

    # ── Build chart ────────────────────────────────────────────────────────
    try:
        import plotly.graph_objects as go
        import pandas as pd

        df = pd.DataFrame(rows)

        # Coerce all numeric columns to float
        for col in numeric_cols:
            df[col] = df[col].apply(lambda x: _to_float(x) if _to_float(x) is not None else 0.0)

        measure_col = numeric_cols[0]
        label_col = label_cols[0] if label_cols else df.columns[0]

        chart_type = _pick_chart_type(rows, numeric_cols, label_cols, user_query)

        # ── Dark theme shared layout ───────────────────────────────────────
        base_layout = dict(
            title=dict(text=user_query[:80], font=dict(size=14, color="#e2e8f0")),
            template="plotly_dark",
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            font=dict(color="#e2e8f0", size=12),
            margin=dict(l=60, r=20, t=50, b=80),
            legend=dict(bgcolor="rgba(0,0,0,0)"),
        )

        fig = go.Figure()

        # ── Bar chart ─────────────────────────────────────────────────────
        if chart_type == "bar":
            fig.add_trace(go.Bar(
                x=df[label_col].astype(str),
                y=df[measure_col],
                marker=dict(
                    color=df[measure_col],
                    colorscale="Blues",
                    showscale=False,
                ),
                text=df[measure_col].round(2),
                textposition="outside",
                name=measure_col,
            ))
            fig.update_layout(
                **base_layout,
                xaxis=dict(title=label_col, tickangle=-30),
                yaxis=dict(title=measure_col, gridcolor="rgba(255,255,255,0.1)"),
            )

        # ── Horizontal bar ────────────────────────────────────────────────
        elif chart_type == "hbar":
            df_sorted = df.sort_values(measure_col, ascending=True)
            fig.add_trace(go.Bar(
                x=df_sorted[measure_col],
                y=df_sorted[label_col].astype(str),
                orientation="h",
                marker=dict(
                    color=df_sorted[measure_col],
                    colorscale="Teal",
                    showscale=False,
                ),
                text=df_sorted[measure_col].round(2),
                textposition="outside",
                name=measure_col,
            ))
            fig.update_layout(
                **base_layout,
                margin=dict(l=140, r=60, t=50, b=40),
                xaxis=dict(title=measure_col, gridcolor="rgba(255,255,255,0.1)"),
                yaxis=dict(title=label_col),
                height=max(300, len(rows) * 36),
            )

        # ── Line chart ────────────────────────────────────────────────────
        elif chart_type == "line":
            fig.add_trace(go.Scatter(
                x=df[label_col].astype(str),
                y=df[measure_col],
                mode="lines+markers",
                name=measure_col,
                line=dict(color="#4f8ef7", width=2),
                marker=dict(size=7, color="#4f8ef7"),
                fill="tozeroy",
                fillcolor="rgba(79,142,247,0.1)",
            ))
            fig.update_layout(
                **base_layout,
                xaxis=dict(title=label_col, tickangle=-30, gridcolor="rgba(255,255,255,0.1)"),
                yaxis=dict(title=measure_col, gridcolor="rgba(255,255,255,0.1)"),
            )

        # ── Pie chart ─────────────────────────────────────────────────────
        elif chart_type == "pie":
            fig.add_trace(go.Pie(
                labels=df[label_col].astype(str),
                values=df[measure_col],
                hole=0.4,            # donut style — easier to read
                textinfo="label+percent",
                textfont=dict(size=12, color="#e2e8f0"),
                marker=dict(
                    colors=[
                        "#4f8ef7", "#4ade80", "#fbbf24",
                        "#f87171", "#a78bfa", "#34d399",
                    ],
                    line=dict(color="rgba(0,0,0,0.3)", width=1),
                ),
            ))
            fig.update_layout(
                **base_layout,
                margin=dict(l=20, r=20, t=50, b=20),
                showlegend=True,
            )

        # ── Scatter plot ──────────────────────────────────────────────────
        elif chart_type == "scatter":
            x_col = numeric_cols[0]
            y_col = numeric_cols[1]
            fig.add_trace(go.Scatter(
                x=df[x_col],
                y=df[y_col],
                mode="markers+text",
                text=df[label_col].astype(str) if label_cols else None,
                textposition="top center",
                textfont=dict(size=10),
                marker=dict(
                    size=10,
                    color=df[x_col],
                    colorscale="Viridis",
                    showscale=True,
                    colorbar=dict(title=x_col),
                ),
                name=f"{x_col} vs {y_col}",
            ))
            fig.update_layout(
                **base_layout,
                xaxis=dict(title=x_col, gridcolor="rgba(255,255,255,0.1)"),
                yaxis=dict(title=y_col, gridcolor="rgba(255,255,255,0.1)"),
            )

        # ── Multi-bar ─────────────────────────────────────────────────────
        elif chart_type == "multi_bar":
            colors = ["#4f8ef7", "#4ade80", "#fbbf24", "#f87171", "#a78bfa"]
            for i, col in enumerate(numeric_cols[:5]):
                fig.add_trace(go.Bar(
                    x=df[label_col].astype(str),
                    y=df[col],
                    name=col,
                    marker_color=colors[i % len(colors)],
                    text=df[col].round(2),
                    textposition="outside",
                ))
            fig.update_layout(
                **base_layout,
                barmode="group",
                xaxis=dict(title=label_col, tickangle=-30),
                yaxis=dict(title="value", gridcolor="rgba(255,255,255,0.1)"),
            )

        # ── Render ────────────────────────────────────────────────────────
        chart_html = fig.to_html(full_html=False, include_plotlyjs="cdn")
        return json.dumps({
            "chart_html": chart_html,
            "reason": f"Generated {chart_type} chart: {label_col} vs {measure_col}.",
        })

    except Exception as e:
        return json.dumps({
            "chart_html": None,
            "reason": f"Chart generation failed: {e}",
        })# mcp_server/tools/generate_visualization.py
"""
MCP tool: generate_visualization
Decides if a chart is meaningful. If yes, returns Plotly HTML string.
Supports: bar, horizontal bar, line, pie, scatter, multi-bar charts.
"""
import json
from typing import Any, Dict, List, Optional, Tuple


def _to_float(v: Any) -> Optional[float]:
    """
    Coerce value to float.
    Handles int, float, Decimal-as-string ("55000.00"), "1234", etc.
    Returns float on success, None on failure.
    """
    if isinstance(v, (int, float)):
        return float(v)
    if isinstance(v, str):
        try:
            return float(v.replace(",", "").strip())
        except ValueError:
            pass
    return None


def _detect_columns(rows: List[Dict]) -> Tuple[List[str], List[str]]:
    """
    Split columns into numeric and label (text) columns.
    Returns (numeric_cols, label_cols).
    """
    if not rows:
        return [], []

    first = rows[0]
    numeric_cols = [
        k for k, v in first.items()
        if _to_float(v) is not None
        and not k.lower().endswith("id")
        and not k.lower() in ("year", "month_num", "day_num")
    ]
    label_cols = [
        k for k in first.keys()
        if k not in numeric_cols
    ]
    return numeric_cols, label_cols


def _is_time_col(col_name: str) -> bool:
    time_hints = ["date", "month", "year", "time", "day", "period", "week", "quarter"]
    return any(h in col_name.lower() for h in time_hints)


def _pick_chart_type(
    rows: List[Dict],
    numeric_cols: List[str],
    label_cols: List[str],
    user_query: str,
) -> str:
    """
    Decide the best chart type based on data shape and query intent.

    Rules:
      pie        — ≤5 rows, 1 numeric, query has share/distribution feel
      scatter    — 2+ numeric cols, query has correlation feel
      multi_bar  — 2+ numeric cols, category label exists
      line       — label col is time-based
      hbar       — >6 rows, 1 numeric, long category labels
      bar        — default for category + 1 numeric
    """
    query_lower = user_query.lower()
    n_rows = len(rows)
    n_numeric = len(numeric_cols)
    label_col = label_cols[0] if label_cols else None

    # ── Pie ────────────────────────────────────────────────────────────────
    pie_keywords = ["share", "distribution", "breakdown", "percent", "proportion",
                    "by status", "by type", "by category", "composition"]
    if (
        n_rows <= 6
        and n_numeric == 1
        and any(kw in query_lower for kw in pie_keywords)
    ):
        return "pie"

    # ── Scatter ───────────────────────────────────────────────────────────
    scatter_keywords = ["vs", "versus", "correlation", "relationship",
                        "compare", "against", "scatter"]
    if n_numeric >= 2 and any(kw in query_lower for kw in scatter_keywords):
        return "scatter"

    # ── Multi-bar ─────────────────────────────────────────────────────────
    if n_numeric >= 2 and label_col and not _is_time_col(label_col):
        return "multi_bar"

    # ── Line ──────────────────────────────────────────────────────────────
    if label_col and _is_time_col(label_col):
        return "line"

    # ── Horizontal bar ────────────────────────────────────────────────────
    # Use when many rows or long label names
    if label_col:
        avg_label_len = sum(len(str(r.get(label_col, ""))) for r in rows) / n_rows
        if n_rows > 6 or avg_label_len > 12:
            return "hbar"

    # ── Default: vertical bar ─────────────────────────────────────────────
    return "bar"


def generate_visualization(rows_json: str, user_query: str) -> str:
    """
    Decide if chart is meaningful and generate Plotly HTML if so.

    Args:
        rows_json: JSON string of rows (list of dicts).
        user_query: The original user natural language query.

    Returns:
        JSON string: {"chart_html": "<div>...</div>" or null, "reason": str}
    """
    # ── Parse rows ─────────────────────────────────────────────────────────
    try:
        rows: List[Dict[str, Any]] = json.loads(rows_json)
    except Exception:
        return json.dumps({"chart_html": None, "reason": "Invalid rows JSON."})

    # ── Gate 1: need more than 1 row ───────────────────────────────────────
    if len(rows) <= 1:
        return json.dumps({
            "chart_html": None,
            "reason": "Single row or empty result — no chart needed.",
        })

    # ── Gate 2: need at least one numeric column ───────────────────────────
    numeric_cols, label_cols = _detect_columns(rows)
    if not numeric_cols:
        return json.dumps({
            "chart_html": None,
            "reason": "No numeric measure columns found — skipping chart.",
        })

    # ── Gate 3: query should look like aggregation/analysis ───────────────
    chart_keywords = [
        "total", "count", "sum", "average", "avg", "per", "by",
        "trend", "over time", "monthly", "yearly", "daily",
        "compare", "top", "highest", "lowest", "most", "least",
        "salary", "amount", "revenue", "quantity", "orders", "sales",
        "price", "cost", "profit", "rate", "ratio", "percent",
        "share", "distribution", "breakdown", "vs", "versus",
        "show", "list", "all",
    ]
    query_lower = user_query.lower()
    is_meaningful = any(kw in query_lower for kw in chart_keywords)

    if not is_meaningful and len(rows) < 3:
        return json.dumps({
            "chart_html": None,
            "reason": "Query does not appear to need a chart.",
        })

    # ── Build chart ────────────────────────────────────────────────────────
    try:
        import plotly.graph_objects as go
        import pandas as pd

        df = pd.DataFrame(rows)

        # Coerce all numeric columns to float
        for col in numeric_cols:
            df[col] = df[col].apply(lambda x: _to_float(x) if _to_float(x) is not None else 0.0)

        measure_col = numeric_cols[0]
        label_col = label_cols[0] if label_cols else df.columns[0]

        chart_type = _pick_chart_type(rows, numeric_cols, label_cols, user_query)

        # ── Dark theme shared layout ───────────────────────────────────────
        base_layout = dict(
            title=dict(text=user_query[:80], font=dict(size=14, color="#e2e8f0")),
            template="plotly_dark",
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            font=dict(color="#e2e8f0", size=12),
            margin=dict(l=60, r=20, t=50, b=80),
            legend=dict(bgcolor="rgba(0,0,0,0)"),
        )

        fig = go.Figure()

        # ── Bar chart ─────────────────────────────────────────────────────
        if chart_type == "bar":
            fig.add_trace(go.Bar(
                x=df[label_col].astype(str),
                y=df[measure_col],
                marker=dict(
                    color=df[measure_col],
                    colorscale="Blues",
                    showscale=False,
                ),
                text=df[measure_col].round(2),
                textposition="outside",
                name=measure_col,
            ))
            fig.update_layout(
                **base_layout,
                xaxis=dict(title=label_col, tickangle=-30),
                yaxis=dict(title=measure_col, gridcolor="rgba(255,255,255,0.1)"),
            )

        # ── Horizontal bar ────────────────────────────────────────────────
        elif chart_type == "hbar":
            df_sorted = df.sort_values(measure_col, ascending=True)
            fig.add_trace(go.Bar(
                x=df_sorted[measure_col],
                y=df_sorted[label_col].astype(str),
                orientation="h",
                marker=dict(
                    color=df_sorted[measure_col],
                    colorscale="Teal",
                    showscale=False,
                ),
                text=df_sorted[measure_col].round(2),
                textposition="outside",
                name=measure_col,
            ))
            fig.update_layout(
                **base_layout,
                margin=dict(l=140, r=60, t=50, b=40),
                xaxis=dict(title=measure_col, gridcolor="rgba(255,255,255,0.1)"),
                yaxis=dict(title=label_col),
                height=max(300, len(rows) * 36),
            )

        # ── Line chart ────────────────────────────────────────────────────
        elif chart_type == "line":
            fig.add_trace(go.Scatter(
                x=df[label_col].astype(str),
                y=df[measure_col],
                mode="lines+markers",
                name=measure_col,
                line=dict(color="#4f8ef7", width=2),
                marker=dict(size=7, color="#4f8ef7"),
                fill="tozeroy",
                fillcolor="rgba(79,142,247,0.1)",
            ))
            fig.update_layout(
                **base_layout,
                xaxis=dict(title=label_col, tickangle=-30, gridcolor="rgba(255,255,255,0.1)"),
                yaxis=dict(title=measure_col, gridcolor="rgba(255,255,255,0.1)"),
            )

        # ── Pie chart ─────────────────────────────────────────────────────
        elif chart_type == "pie":
            fig.add_trace(go.Pie(
                labels=df[label_col].astype(str),
                values=df[measure_col],
                hole=0.4,            # donut style — easier to read
                textinfo="label+percent",
                textfont=dict(size=12, color="#e2e8f0"),
                marker=dict(
                    colors=[
                        "#4f8ef7", "#4ade80", "#fbbf24",
                        "#f87171", "#a78bfa", "#34d399",
                    ],
                    line=dict(color="rgba(0,0,0,0.3)", width=1),
                ),
            ))
            fig.update_layout(
                **base_layout,
                margin=dict(l=20, r=20, t=50, b=20),
                showlegend=True,
            )

        # ── Scatter plot ──────────────────────────────────────────────────
        elif chart_type == "scatter":
            x_col = numeric_cols[0]
            y_col = numeric_cols[1]
            fig.add_trace(go.Scatter(
                x=df[x_col],
                y=df[y_col],
                mode="markers+text",
                text=df[label_col].astype(str) if label_cols else None,
                textposition="top center",
                textfont=dict(size=10),
                marker=dict(
                    size=10,
                    color=df[x_col],
                    colorscale="Viridis",
                    showscale=True,
                    colorbar=dict(title=x_col),
                ),
                name=f"{x_col} vs {y_col}",
            ))
            fig.update_layout(
                **base_layout,
                xaxis=dict(title=x_col, gridcolor="rgba(255,255,255,0.1)"),
                yaxis=dict(title=y_col, gridcolor="rgba(255,255,255,0.1)"),
            )

        # ── Multi-bar ─────────────────────────────────────────────────────
        elif chart_type == "multi_bar":
            colors = ["#4f8ef7", "#4ade80", "#fbbf24", "#f87171", "#a78bfa"]
            for i, col in enumerate(numeric_cols[:5]):
                fig.add_trace(go.Bar(
                    x=df[label_col].astype(str),
                    y=df[col],
                    name=col,
                    marker_color=colors[i % len(colors)],
                    text=df[col].round(2),
                    textposition="outside",
                ))
            fig.update_layout(
                **base_layout,
                barmode="group",
                xaxis=dict(title=label_col, tickangle=-30),
                yaxis=dict(title="value", gridcolor="rgba(255,255,255,0.1)"),
            )

        # ── Render ────────────────────────────────────────────────────────
        chart_html = fig.to_html(full_html=False, include_plotlyjs="cdn")
        return json.dumps({
            "chart_html": chart_html,
            "reason": f"Generated {chart_type} chart: {label_col} vs {measure_col}.",
        })

    except Exception as e:
        return json.dumps({
            "chart_html": None,
            "reason": f"Chart generation failed: {e}",
        })