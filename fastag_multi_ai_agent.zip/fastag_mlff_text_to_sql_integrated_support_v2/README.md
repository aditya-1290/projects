 Get-ChildItem -Recurse -Filter *.py | Rename-Item -NewName { $_.Name -replace '\.py$','.txt' }
 to conver .py files to .txt files extension conversion
 
# Text-to-SQL Multi-Agent System
**Stack:** Python 3.11 · Google ADK 1.32.0 · llama-cpp-python · FastAPI · PostgreSQL · MCP SSE
## How it works (30-second summary)
```
Browser → FastAPI → ADK Runner → Manager LlmAgent
                                      ↓  (AutoFlow reads description fields)
                                 Schema LlmAgent  (hr / sales / production)
                                      ↓  (MCPToolset SSE)
                                 MCP Server  (port 8001)
                                      ↓
                                 PostgreSQL
```
The Manager agent reads each schema agent's **description field** and automatically calls
`transfer_to_agent(name)`. Zero custom routing code needed.
## Startup order (ALWAYS follow this — both platforms)

| Step | What to start | Wait for |
|------|---------------|----------|
| 1 | llama-cpp-python server (port 8080) | `HTTP server listening at 8000` |
| 2 | MCP server (port 8001) | `Starting MCP server on port 8001  AND 8002` |
| 3 | FastAPI server (port 8000) | `Uvicorn running on port 8003` |

---

## Windows Setup (step by step)

### Prerequisites
- Python 3.11 from https://python.org (tick "Add to PATH" during install)
- Your model file at `D:\models\gemma.gguf` (or update `.env`)

### Step 1 — Unzip the project
```
Right-click text_to_sql.zip → Extract All → e.g. C:\projects\text_to_sql
```
Open **Command Prompt** and go there:
```cmd
cd C:\projects\text_to_sql
```
### Step 2 — Create virtual environment
```cmd
python -m venv .venv
.venv\Scripts\activate
```
### Step 3 — Install llama-cpp-python (Windows CPU — no GPU flags)
```cmd
pip install llama-cpp-python==0.3.4 --no-cache-dir
```
#
pip install llama-cpp-python==0.2.90 --extra-index-url https://abetlen.github.io/llama-cpp-python/whl/cpu --force-reinstall --no-cache-dir

> On Windows there is no Metal/CUDA flag needed — it runs on CPU automatically.
> With 16 GB RAM and Gemma E4B Q5 model, expect 30–60 sec response time. That is normal.

### Step 4 — Install everything else

```cmd
pip install -r requirements.txt
```

### Step 5 — Edit .env

Open `.env` in Notepad and set:

```env
LLAMA_MODEL_PATH=D:\models\gemma.gguf
LLAMA_N_GPU_LAYERS=0

DB_HOST=localhost
DB_NAME=your_db_name
DB_USER=your_user
DB_PASSWORD=your_password
```

### Step 6 — Open 3 Command Prompt windows, run in order

**Window 1 — Llama server (double-click or run):**
```cmd
scripts\start_llama_server.bat
```
Wait until you see: `HTTP server listening at http://127.0.0.1:8080`

**Window 2 — MCP server:**
```cmd
scripts\start_mcp_server.bat
```

**Window 3 — FastAPI:**
```cmd
scripts\start_api_server.bat
```

### Step 7 — Open browser

```
http://localhost:8000
```

---

## Mac M4 Setup (step by step)

### Prerequisites
- macOS with Xcode command-line tools: `xcode-select --install`
- Python 3.11: `brew install python@3.11`
- Your model file copied to Mac (e.g. `~/models/gemma.gguf`)

### Step 1 — Copy model to Mac

```bash
mkdir -p ~/models
# Copy gemma.gguf from your Windows machine or USB to here
```

### Step 2 — Unzip and enter folder

```bash
unzip text_to_sql.zip
cd text_to_sql
```

### Step 3 — Create virtual environment

```bash
python3.11 -m venv .venv
source .venv/bin/activate
```

### Step 4 — Install llama-cpp-python WITH Metal (critical for M4 speed)

```bash
CMAKE_ARGS="-DLLAMA_METAL=on" \
  pip install llama-cpp-python==0.3.4 --no-cache-dir --force-reinstall
```

> You should see `metal` in the build output. This enables GPU acceleration on M4.
> Do NOT skip this — without it llama runs CPU-only and is much slower.

### Step 5 — Install everything else

```bash
pip install -r requirements.txt
```

### Step 6 — Edit .env

```env
LLAMA_MODEL_PATH=/Users/YOUR_USERNAME/models/gemma.gguf
LLAMA_N_GPU_LAYERS=35          # 35 for Mac M4 Metal

DB_HOST=your-neon-host.neon.tech
DB_NAME=your_db_name
DB_USER=your_user
DB_PASSWORD=your_password
```

### Step 7 — Open 3 Terminal tabs, run in order

```bash
# Tab 1
bash scripts/start_llama_server.sh

# Tab 2 (after Tab 1 shows "listening")
bash scripts/start_mcp_server.sh

# Tab 3 (after Tab 2 is running)
bash scripts/start_api_server.sh
```

### Step 8 — Open browser

```
http://localhost:8000
```

---

## Switching from Windows dev → Mac FASTag production

In `.env`, change only:

```env
LLAMA_MODEL_PATH=/Users/YOUR_USERNAME/models/gemma.gguf
LLAMA_N_GPU_LAYERS=35
DB_HOST=localhost          # or Mac's IP for FASTag PostgreSQL
```

No code changes needed anywhere.

---

## Adding a new agent (no code change)

Add to `.env`:

```env
AGENT_4_NAME=purchasing_agent
AGENT_4_SCHEMA=purchasing
AGENT_4_TABLES=purchaseorderheader,vendor,shipmethod
```

Restart FastAPI. Done.

---

## Folder structure

```
text_to_sql/
├── .env                          ← ALL config: agents, DB, model path
├── requirements.txt
├── README.md
│
├── frontend/
│   └── index.html                ← full chat UI, no build step
│
├── mcp_server/
│   ├── server.py                 ← MCP SSE server port 8001
│   └── tools/
│       ├── execute_sql.py
│       ├── get_schema_metadata.py
│       ├── validate_sql.py
│       ├── generate_visualization.py
│       └── get_table_sample.py
│-------CONFIG/
|           |-predefined_queries.json
├── agents/
│   ├── agent_registry.py         ← ★ SINGLE PLACE all agents are registered
│   ├── manager_agent.py          ← root LlmAgent, AutoFlow routing
│   └── schema_agent.py           ← factory: one LlmAgent per .env block
│
├── core/
│   ├── config.py                 ← typed .env loader + dynamic agent parser
│   ├── database.py               ← SQLAlchemy connection pool
│   ├── cache.py                  ← per-agent schema metadata cache
│   ├── session_store.py          ← file-based JSON sessions
│   └── logging_config.py         ← structlog JSON logs
│
├── api/
│   ├── main.py                   ← FastAPI startup + ADK Runner init
│   └── routes/
│       ├── query.py              ← POST /query
│       └── sessions.py           ← GET /sessions, GET /sessions/{id}
│
└── scripts/
    ├── start_llama_server.sh     ← Mac Terminal 1
    ├── start_llama_server.bat    ← Windows CMD 1
    ├── start_mcp_server.sh       ← Mac Terminal 2
    ├── start_mcp_server.bat      ← Windows CMD 2
    ├── start_api_server.sh       ← Mac Terminal 3
    └── start_api_server.bat      ← Windows CMD 3
```

---

## Test queries (AdventureWorks)

| Query | Expected agent |
|---|---|
| Show all employees | hr_agent |
| Total sales per region | sales_agent |
| List products by work orders | production_agent |
| How many departments exist | hr_agent |
| Top 5 customers by order value | sales_agent |

---

## Logs

```
logs/
  app.log      ← all events (JSON)
  agents.log   ← agent routing events only
  errors.log   ← errors with traceback
```

---

## Troubleshooting

| Problem | Fix |
|---|---|
| Windows: `ModuleNotFoundError: llama_cpp` | Run Step 3 again with venv activated |
| Mac: Metal not showing at startup | Reinstall with `CMAKE_ARGS="-DLLAMA_METAL=on"` |
| `Connection refused` on port 8080 | Start llama server first, wait for "listening" |
| `Connection refused` on port 8001 | Start MCP server before FastAPI |
| Agent says "outside my scope" | Check AGENT_N_TABLES in .env matches actual DB table names |
| Very slow responses on Windows | Normal — CPU inference on 16GB RAM. Gemma E4B Q5 takes 30–60s |
| Very slow responses on Mac | Check GPU layers: should be 35, not 0 |
==================================================================

#simple queries

show all employees
list all departments
show all products
show all vendors
show all customers
show all shifts
list all work orders
show all salespersons

====================================
#medium queries
show employees hired after 2019
show employees with salary above 70000
show active work orders
show products in Bikes category
show shipped orders only
show vendors from India
show employees in Engineering department
show products with list price above 5000
show closed work orders
show customers in North territory
================================================
#complex queries
total salary by department
count employees per department
average salary by department
total sales by territory
count orders by status
total order value by territory
products by category with average price
count work orders by status
top products by list price
total purchase amount by vendor
employees count by job title
average bonus by territory for salespersons
monthly orders count in 2024
total work order quantity by product
salary range minimum and maximum by department
===============================================================================================


HR Agent-
total salary by department
employee count by department

Sales Agent-
total sales amount by customer
count orders by status

Production Agent-
total work order quantity by product
products by category with average price
########################################################################################################################################################################################################################################################################################
Based on your three agents and AdventureWorks schema:

HR Agent
Simple:
show all departments
list all employees with their job title
Medium:
total salary by department
employee count by department
show employees hired after 2019
Complex:
show top 5 highest paid employees with their department name
average salary by job title ordered by highest first

Sales Agent
Simple:
show all customers
list all salespersons
Medium:
total sales amount by salesperson
count orders by status
top 10 customers by total purchase amount
Complex:
monthly order count trend for all years
top 5 salespersons by total revenue with order count

Production Agent
Simple:
show all products
list all work orders
Medium:
total work order quantity by product
top 10 products by work order count
products with average list price by product line
Complex:
top 10 products by total work order quantity with average scrapped quantity
monthly work order count trend

Guaranteed visualization queries — these will always produce a chart based on your data:
total salary by department
employee count by department
total work order quantity by product
total sales amount by salesperson
count orders by status



===========================================================================
Based on your AdventureWorks database:

Bar chart=========
total sales amount by salesperson

Horizontal bar==========
total salary by department
or
top 10 products by work order count

Line chart==================
monthly order count trend for all years

Pie chart==============
count orders by status
or
total work orders by status

Scatter plot=======
compare order quantity vs scrapped quantity by product

Multi-bar============
total order quantity and scrapped quantity by product
or
total sales amount and order count by salesperson
====================================================================================================================================================================================================================================.

🧑‍💼 hr_agent — humanresources schema
These should show hr_agent in the badge and query only humanresources tables.
Show me all active employees and their job titles
Which department has the highest number of employees?
List all employees hired after 2010 ordered by hire date
What is the salary range minimum and maximum in each department?
Show me all employees in the Engineering department
Which employees earn more than 70000?
How many employees are in each shift?
Show all job titles and count of employees per title
List employees hired in 2015
What is the total payroll cost per department?
==============================================================================?

💰 sales_agent — sales schema
These should show sales_agent badge and query only sales tables.
Show total revenue by territory
Who are the top 10 customers by total spending?
How many sales orders were placed each year?
What is the average order value per territory?
Show all orders with status shipped
Which territory has the highest number of customers?
List top 5 salespersons by sales quota
How many customers do we have per territory?
Show monthly order count trend across all years
What is the total revenue from all orders?
================================================================================================================================
?

🏭 production_agent — production schema
These should show production_agent badge and query only production tables.
List top 10 most expensive products by list price
Show all products with their category and standard cost
Which products have the most work orders?
Show work orders grouped by status
List all products that weigh more than 10
What is the average list price per product category?
Show total quantity ordered per product from work orders
Which products have zero list price?
How many work orders are currently in progress?
Show products where list price is greater than standard cost by more than 100
================================================================================================================================


🛡️ support_agent — predefined queries (NO SQL generated by LLM)
These are the most important tests. The LLM returns only a number — SQL comes from your JSON file. You should see the exact SQL from predefined_queries.json in the SQL block, not LLM-generated SQL.
What is the total salary paid to each department?
→ ID 1 — joins employee + department, cross-schema not possible for hr_agent alone
Show me employee hiring trend year by year
→ ID 4 — EXTRACT(YEAR FROM hire_date) grouping
Which products have the highest list price?
→ ID 5 — production schema, should NOT go to production_agent
Show total work order quantity grouped by product name
→ ID 6 — joins workorder + product
How much total amount have we spent with each vendor?
→ ID 8 — purchasing schema, no purchasing_agent exists
Which vendors have placed the most purchase orders?
→ ID 9 — purchasing.vendor + purchaseorderheader join
Show total sales revenue grouped by territory
→ ID 10 — sales schema aggregation
Who are the top salespersons by revenue with their full name?
→ ID 13 — 4-table cross-schema JOIN: sales + humanresources + person
Show all employees with full name email phone and department
→ ID 14 — cross-schema: humanresources + person + department
Which employees placed purchase orders and what is their total amount?
→ ID 15 — cross-schema: purchasing + humanresources + person
=========================================================================================================================================

✅ What to verify for each query
For hr_agent, sales_agent, production_agent — check these 4 things on the UI card:

Check	Expected
Badge	correct agent name
SQL block	LLM-generated SQL with schema prefix e.g. humanresources.employee
Results table	actual rows from DB
Chart	bar/line/pie depending on data shape
For support_agent — check these specifically:

Check	Expected
Badge	support_agent
SQL block	exact SQL from your JSON file — not LLM written
Schema prefix	has explicit schema e.g. humanresources.employee, person.person
Results table	real rows
Summary	LLM natural language summary of the data
⚠️ If support_agent queries go to wrong agent
IDs 1, 2, 3 overlap with hr_agent scope. If manager routes "total salary by department" to hr_agent instead of support_agent, that is normal — the real proof of support_agent is IDs 13, 14, 15 because no other agent can do those cross-schema joins. Test those three first.

