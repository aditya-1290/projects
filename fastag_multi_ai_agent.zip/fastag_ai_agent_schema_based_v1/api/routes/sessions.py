# api/routes/sessions.py
"""
GET /sessions              — list all sessions (for sidebar)
GET /sessions/{id}         — full session with all queries
GET /sessions/{id}/queries/{qid} — single query replay (no new LLM call)
"""
from fastapi import APIRouter, HTTPException
from core.session_store import list_all_sessions, load_session, get_query

router = APIRouter()


@router.get("/sessions")
def list_sessions():
    """Return all sessions — used to populate left sidebar."""
    return {"sessions": list_all_sessions()}


@router.get("/sessions/{session_id}")
def get_session(session_id: str):
    """Return a full session with all stored queries."""
    session = load_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    return session


@router.get("/sessions/{session_id}/queries/{query_id}")
def replay_query(session_id: str, query_id: str):
    """
    Read-only replay of a past query result.
    NO new LLM call is made — returns exactly what was stored.
    """
    query = get_query(session_id, query_id)
    if not query:
        raise HTTPException(status_code=404, detail="Query not found")
    return query
