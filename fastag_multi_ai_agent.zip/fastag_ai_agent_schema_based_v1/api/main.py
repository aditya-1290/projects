# api/main.py
"""
FastAPI application entry point.

Startup order (all in one process after llama + MCP are running):
  1. Setup logging
  2. Initialize agent registry (reads .env, creates all LlmAgents, warms cache)
  3. Build manager agent (sub_agents = all schema agents)
  4. Create ADK Runner with InMemorySessionService
  5. Mount static frontend
  6. Register API routes
"""
import os
from contextlib import asynccontextmanager
from fastapi import FastAPI
# from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

from core.logging_config import setup_logging, get_logger

logger = get_logger("app")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Runs once at startup before any request is served."""
    # ── 1. Logging ─────────────────────────────────────────────────────────
    setup_logging()
    logger.info("server_startup")

    # ── 2. Agent registry ──────────────────────────────────────────────────
    from agents.agent_registry import initialize_registry
    initialize_registry()
    logger.info("agent_registry_initialized")

    # ── 3. Manager agent ───────────────────────────────────────────────────
    from agents.manager_agent import build_manager_agent
    manager_agent = build_manager_agent()

    # ── 4. ADK Runner ──────────────────────────────────────────────────────
    from google.adk.runners import Runner
    from google.adk.sessions import InMemorySessionService
    import litellm
    
    litellm.set_verbose = False
    litellm.suppress_debug_info = True
    litellm.drop_params = True
    litellm.success_callback = []
    litellm.failure_callback = []

    # Tell LiteLLM where llama-cpp-python is running
    from core.config import settings
    os.environ["OPENAI_API_BASE"] = settings.llama_server_url
    os.environ["OPENAI_API_KEY"] = "not-needed"     # llama-cpp-python needs any value

    session_service = InMemorySessionService()
    runner = Runner(
        agent=manager_agent,
        app_name="text_to_sql",
        session_service=session_service,
    )

    # ── 5. Wire runner into route handler ──────────────────────────────────
    from api.routes.query import set_runner
    set_runner(runner, manager_agent)

    logger.info("adk_runner_ready", app_name="text_to_sql")

    yield
    # Shutdown (nothing special needed)
    logger.info("server_shutdown")


# ── App ────────────────────────────────────────────────────────────────────
app = FastAPI(
    title="Text-to-SQL Multi-Agent System",
    version="1.0.0",
    lifespan=lifespan,
)

# ── Routes ─────────────────────────────────────────────────────────────────
from api.routes.query import router as query_router
from api.routes.sessions import router as sessions_router

app.include_router(query_router)
app.include_router(sessions_router)


# ── Frontend ───────────────────────────────────────────────────────────────
@app.get("/")
def serve_frontend():
    return FileResponse("frontend/index.html")


# ── Dev runner ─────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import uvicorn
    from core.config import settings
    uvicorn.run("api.main:app", host="0.0.0.0", port=settings.api_port, reload=False)
