# agents/schema_agent.py
"""
Factory that creates one LlmAgent per AgentConfig block read from .env.

Each schema agent:
  - Is a google.adk.agents.LlmAgent
  - Gets TWO MCPToolsets: one SSE (port 8001) + one streamable-HTTP (port 8002)
  - ADK merges tools from both toolsets automatically
  - No bypass — all tool calls go through real MCP connections
"""

import asyncio
from google.adk.agents import LlmAgent
from google.adk.tools.mcp_tool.mcp_toolset import (
    MCPToolset,
    SseConnectionParams,
    StreamableHTTPConnectionParams,
)

from core.config import AgentConfig, settings
from core.cache import load_schema_cache, cache_as_prompt_text
from core.logging_config import get_logger

logger = get_logger("agent")

_MODEL = "openai/gemma-local"


def _build_sse_toolset() -> MCPToolset:
    """
    SSE transport — persistent connection, lower latency for repeated calls.
    ADK uses SseConnectionParams (not SseServerParams — that name doesn't exist
    in this ADK version).
    """
    url = f"{settings.mcp_server_url}/sse"
    logger.info("mcp_sse_toolset_building", url=url)
    return MCPToolset(
        connection_params=SseConnectionParams(url=url)
    )


def _build_http_toolset() -> MCPToolset:
    """
    Streamable-HTTP transport — stateless per-request, good fallback.
    FastMCP serves this at /mcp on port 8002.
    """
    url = f"{settings.mcp_http_url}/mcp"
    logger.info("mcp_http_toolset_building", url=url)
    return MCPToolset(
        connection_params=StreamableHTTPConnectionParams(url=url)
    )


def create_schema_agent(cfg: AgentConfig) -> LlmAgent:
    """
    Build one LlmAgent for the given AgentConfig.
    Wires up BOTH MCPToolsets so ADK has SSE + HTTP tools available.
    """
    # 1. Warm schema cache
    load_schema_cache(cfg.name, cfg.schema, cfg.tables)
    schema_text = cache_as_prompt_text(cfg.name)

    logger.info(
        "agent_initializing",
        agent=cfg.name,
        schema=cfg.schema,
        tables=cfg.tables,
        mcp_sse=settings.mcp_server_url,
        mcp_http=settings.mcp_http_url,
    )

    tables_str = ", ".join(cfg.tables)

    description = (
        f"Handles all queries about the '{cfg.schema}' database schema. "
        f"Responsible for these tables: {tables_str}. "
        f"Use this agent for any question involving {cfg.schema} data "
        f"such as {tables_str}."
    )

    system_prompt = f"""You are a Text-to-SQL agent for the '{cfg.schema}' schema.

Your assigned tables are: {tables_str}
ONLY generate SQL for these tables. Refuse queries for other schemas/tables.

SCHEMA METADATA (use this to write correct SQL):
{schema_text}

WORKFLOW — follow this exact order for every user query:
1. Call validate_sql_tool to check the SQL you plan to generate.
2. Call execute_sql_tool to run the validated SQL (always max 10 rows).
3. Call generate_visualization_tool with the rows and user query.
4. Return a final natural language summary to the user.

RULES:
- Always prefix table names with schema: {cfg.schema}.tablename
- Never return more than 10 rows
- Never generate DROP, DELETE, UPDATE, INSERT or DDL statements
- If a query is about tables not in your list, say: "This query is outside my assigned scope."
"""

    # 2. Build both toolsets
    #    ADK accepts a list of toolsets — it merges all discovered tools.
    #    SSE is primary (persistent connection); HTTP is secondary (stateless fallback).
    sse_toolset = _build_sse_toolset()
    http_toolset = _build_http_toolset()

    logger.info(
        "agent_toolsets_ready",
        agent=cfg.name,
        transports=["sse:8001", "streamable-http:8002"],
    )

    agent = LlmAgent(
        name=cfg.name,
        model=_MODEL,
        description=description,
        instruction=system_prompt,
        tools=[sse_toolset, http_toolset],   # ← both transports wired in
    )

    logger.info("agent_created", agent=cfg.name)
    return agent