# agents/agent_registry.py
"""
  AGENT REGISTRY — THE SINGLE SOURCE OF TRUTH
  This is the ONE file where the LLM (Manager agent) sees ALL agents.
  To add a new agent: just add AGENT_4_* to .env — nothing here changes.

This module:
  1. Reads all AGENT_N_* blocks from .env via config.py
  2. Creates one LlmAgent per block via schema_agent.py factory
  3. Exposes `ALL_SCHEMA_AGENTS` list — used by manager_agent.py
  4. Exposes `AGENT_MAP` dict {agent_name: LlmAgent} — used by FastAPI runner

The Manager LlmAgent reads the `description` field of every agent in
ALL_SCHEMA_AGENTS and uses ADK AutoFlow to call transfer_to_agent(name)
based on which description best matches the user query.
"""
from typing import Dict, List

from google.adk.agents import LlmAgent

from core.config import settings
from core.logging_config import get_logger
from agents.schema_agent import create_schema_agent

logger = get_logger("agent")


def _build_registry() -> tuple[List[LlmAgent], Dict[str, LlmAgent]]:
    """
    Read .env, create all schema agents, return list + lookup dict.
    Called ONCE at FastAPI startup.
    """
    agent_configs = settings.get_agent_configs()

    if not agent_configs:
        raise RuntimeError(
            "No agents found in .env! "
            "Add at least AGENT_1_NAME, AGENT_1_SCHEMA, AGENT_1_TABLES."
        )

    agents_list: List[LlmAgent] = []
    agents_map: Dict[str, LlmAgent] = {}

    for cfg in agent_configs:
        logger.info("registry_creating_agent", agent=cfg.name, schema=cfg.schema)
        agent = create_schema_agent(cfg)
        agents_list.append(agent)
        agents_map[cfg.name] = agent

    logger.info(
        "registry_ready",
        total_agents=len(agents_list),
        agent_names=[a.name for a in agents_list],
    )
    return agents_list, agents_map


# ── Module-level singletons (built once at import time) ────────────────────
ALL_SCHEMA_AGENTS: List[LlmAgent] = []
AGENT_MAP: Dict[str, LlmAgent] = {}


def initialize_registry():
    """
    Call this explicitly from api/main.py on startup.
    Populates ALL_SCHEMA_AGENTS and AGENT_MAP.
    """
    global ALL_SCHEMA_AGENTS, AGENT_MAP
    ALL_SCHEMA_AGENTS, AGENT_MAP = _build_registry()


def get_all_agents() -> List[LlmAgent]:
    return ALL_SCHEMA_AGENTS


def get_agent(name: str) -> LlmAgent:
    return AGENT_MAP.get(name)
