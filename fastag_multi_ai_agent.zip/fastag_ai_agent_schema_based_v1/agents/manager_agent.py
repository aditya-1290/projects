# agents/manager_agent.py
"""
Manager Agent — Root LlmAgent (entry point for all user queries).

Pure ADK AutoFlow routing:
  - Manager has NO tools of its own
  - Manager has sub_agents = ALL_SCHEMA_AGENTS
  - ADK reads each sub-agent's `description` field
  - ADK calls transfer_to_agent(name) automatically based on description match
  - Zero custom routing code needed here

Call build_manager_agent() AFTER initialize_registry() in api/main.py.
"""
from google.adk.agents import LlmAgent

from agents.agent_registry import get_all_agents
from core.logging_config import get_logger

logger = get_logger("agent")

_MODEL = "openai/gemma-local"

_MANAGER_INSTRUCTION = """You are the routing manager for a Text-to-SQL multi-agent system.

Your ONLY job is to read the user's query and route it to the correct specialist agent.

You have access to these specialist agents (each handles a specific database schema):
{agent_descriptions}

RULES:
- Do NOT answer SQL questions yourself.
- Do NOT generate SQL yourself.
- ALWAYS transfer to the most relevant specialist agent based on the schema/tables mentioned.
- If the query is ambiguous, pick the most likely schema based on keywords.
- If no agent matches, reply: "I could not find a relevant agent for this query."
"""


def build_manager_agent() -> LlmAgent:
    """
    Build the Manager LlmAgent with all schema agents as sub_agents.
    Must be called after initialize_registry().
    """
    schema_agents = get_all_agents()

    if not schema_agents:
        raise RuntimeError("Cannot build manager: registry is empty. Call initialize_registry() first.")

    # Build a readable list of agent descriptions for the system prompt
    agent_descriptions = "\n".join(
        f"- {agent.name}: {agent.description}"
        for agent in schema_agents
    )

    instruction = _MANAGER_INSTRUCTION.format(agent_descriptions=agent_descriptions)

    manager = LlmAgent(
        name="manager_agent",
        model=_MODEL,
        description="Root routing agent. Routes user queries to the correct schema specialist agent.",
        instruction=instruction,
        sub_agents=schema_agents,   # ← Pure ADK AutoFlow: reads descriptions, calls transfer_to_agent
    )

    logger.info(
        "manager_agent_built",
        sub_agents=[a.name for a in schema_agents],
    )

    return manager
