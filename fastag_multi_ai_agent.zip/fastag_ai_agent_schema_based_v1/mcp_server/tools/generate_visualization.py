# mcp_server/tools/generate_visualization.py
"""
MCP tool: generate_visualization
Decides if a chart is meaningful. If yes, returns Plotly HTML string.
If no, returns null.
"""
import json
from typing import Any, Dict, List


def generate_visualization(rows_json: str, user_query: str) -> str:
    """
    Decide if chart is meaningful and generate Plotly HTML if so.

    Args:
        rows_json: JSON string of rows (list of dicts).
        user_query: The original user natural language query.

    Returns:
        JSON string: {"chart_html": "<div>...</div>" or null, "reason": str}
    """
    try:
        rows: List[Dict[str, Any]] = json.loads(rows_json)
    except Exception:
        return json.dumps({"chart_html": None, "reason": "Invalid rows JSON."})

    # ── Decision logic ──────────────────────────────────────────────────────
    # No chart for single row or empty
    if len(rows) <= 1:
        return json.dumps({
            "chart_html": None,
            "reason": "Single row or empty result — no chart needed.",
        })

    # No chart if all columns are free-form text / IDs (no numeric column)
    numeric_cols = [
        k for k, v in rows[0].items()
        if isinstance(v, (int, float)) and not k.lower().endswith("id")
    ]
    if not numeric_cols:
        return json.dumps({
            "chart_html": None,
            "reason": "No numeric measure columns found — skipping chart.",
        })

    # Keyword hints for meaningful aggregation/trend queries
    chart_keywords = [
        "total", "count", "sum", "average", "avg", "per", "by",
        "trend", "over time", "monthly", "yearly", "daily",
        "compare", "region", "top", "highest", "lowest",
    ]
    query_lower = user_query.lower()
    is_meaningful = any(kw in query_lower for kw in chart_keywords)

    if not is_meaningful and len(rows) < 3:
        return json.dumps({
            "chart_html": None,
            "reason": "Query does not appear to be aggregation/trend — skipping chart.",
        })

    # ── Chart generation ────────────────────────────────────────────────────
    try:
        import plotly.graph_objects as go
        import pandas as pd

        df = pd.DataFrame(rows)
        measure_col = numeric_cols[0]

        # Pick label column: first non-numeric, non-id column
        label_col = next(
            (c for c in df.columns if c != measure_col and not c.lower().endswith("id")),
            df.columns[0],
        )

        # Detect time-series vs bar
        time_hints = ["date", "month", "year", "time", "day", "period"]
        is_time = any(h in label_col.lower() for h in time_hints)

        if is_time:
            fig = go.Figure(go.Scatter(
                x=df[label_col].astype(str),
                y=df[measure_col],
                mode="lines+markers",
                name=measure_col,
            ))
            chart_type = "line"
        else:
            fig = go.Figure(go.Bar(
                x=df[label_col].astype(str),
                y=df[measure_col],
                name=measure_col,
            ))
            chart_type = "bar"

        fig.update_layout(
            title=user_query[:80],
            xaxis_title=label_col,
            yaxis_title=measure_col,
            template="plotly_white",
            margin=dict(l=40, r=20, t=50, b=40),
        )

        chart_html = fig.to_html(full_html=False, include_plotlyjs="cdn")
        return json.dumps({
            "chart_html": chart_html,
            "reason": f"Generated {chart_type} chart: {label_col} vs {measure_col}.",
        })

    except Exception as e:
        return json.dumps({
            "chart_html": None,
            "reason": f"Chart generation failed: {e}",
        })
