# mcp_server/tools/execute_sql.py
"""
MCP tool: execute_sql
Runs a SQL string on PostgreSQL. Always returns max 10 rows.
"""
import json
from core.database import execute_query


def execute_sql(sql: str) -> str:
    """
    Execute a SQL query and return up to 10 rows as a JSON string.

    Args:
        sql: Valid PostgreSQL SQL string to execute.

    Returns:
        JSON string: {"rows": [...], "row_count": int, "error": null or str}
    """
    try:
        rows = execute_query(sql, max_rows=10)
        return json.dumps({
            "rows": rows,
            "row_count": len(rows),
            "error": None,
        }, default=str)
    except Exception as e:
        return json.dumps({
            "rows": [],
            "row_count": 0,
            "error": str(e),
        })
