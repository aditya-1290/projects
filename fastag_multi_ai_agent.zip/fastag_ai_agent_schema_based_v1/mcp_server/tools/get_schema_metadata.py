# mcp_server/tools/get_schema_metadata.py
"""
MCP tool: get_schema_metadata
Fetch table + column metadata for a given schema directly from DB.
Used at agent startup to warm the in-memory cache.
"""
import json
from sqlalchemy import inspect
from core.database import get_engine


def get_schema_metadata(schema: str, tables: str) -> str:
    """
    Fetch metadata for specific tables in a schema.

    Args:
        schema: PostgreSQL schema name e.g. "humanresources"
        tables: Comma-separated table names e.g. "employee,department"

    Returns:
        JSON string with full column/FK metadata per table.
    """
    table_list = [t.strip() for t in tables.split(",") if t.strip()]
    inspector = inspect(get_engine())
    result = {}

    for table in table_list:
        try:
            cols = inspector.get_columns(table, schema=schema)
            pks  = inspector.get_pk_constraint(table, schema=schema)
            fks  = inspector.get_foreign_keys(table, schema=schema)
            pk_cols = pks.get("constrained_columns") or []
            result[table] = {
                "columns": [
                    {
                        "name": c["name"],
                        "type": str(c["type"]),
                        "nullable": c.get("nullable", True),
                        "primary_key": c["name"] in pk_cols,
                    }
                    for c in cols
                ],
                "foreign_keys": [
                    {
                        "column": fk["constrained_columns"][0],
                        "references": (
                            f"{fk['referred_schema'] or schema}"
                            f".{fk['referred_table']}"
                            f".{fk['referred_columns'][0]}"
                        ),
                    }
                    for fk in fks if fk["constrained_columns"]
                ],
            }
        except Exception as e:
            result[table] = {"error": str(e)}

    return json.dumps({"schema": schema, "tables": result})
