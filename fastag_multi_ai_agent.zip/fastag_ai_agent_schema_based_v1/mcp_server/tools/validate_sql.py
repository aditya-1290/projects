# mcp_server/tools/validate_sql.py
"""
MCP tool: validate_sql
Syntax-checks SQL using PostgreSQL EXPLAIN without executing it.
"""
import json
from core.database import validate_sql_syntax


def validate_sql(sql: str) -> str:
    """
    Check SQL syntax using PostgreSQL EXPLAIN.

    Args:
        sql: SQL string to validate.

    Returns:
        JSON string: {"valid": bool, "error": null or str}
    """
    result = validate_sql_syntax(sql)
    return json.dumps(result)
