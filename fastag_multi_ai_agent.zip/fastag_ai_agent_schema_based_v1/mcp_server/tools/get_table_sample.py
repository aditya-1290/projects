# mcp_server/tools/get_table_sample.py
"""
MCP tool: get_table_sample
Preview column structure of a table with zero row data returned.
"""
import json
from sqlalchemy import inspect
from core.database import get_engine


def get_table_sample(schema: str, table: str) -> str:
    """
    Return column names and types for a table — no row data ever.

    Args:
        schema: Schema name e.g. "humanresources"
        table:  Table name  e.g. "employee"

    Returns:
        JSON string: {"schema": str, "table": str, "columns": [...]}
    """
    try:
        inspector = inspect(get_engine())
        cols = inspector.get_columns(table, schema=schema)
        return json.dumps({
            "schema": schema,
            "table": table,
            "columns": [
                {"name": c["name"], "type": str(c["type"]), "nullable": c.get("nullable", True)}
                for c in cols
            ],
        })
    except Exception as e:
        return json.dumps({"error": str(e)})
