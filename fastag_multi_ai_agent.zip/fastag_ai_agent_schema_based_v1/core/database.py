# core/database.py
from typing import Any, Dict, List

from sqlalchemy import create_engine, text
from sqlalchemy.pool import QueuePool

from core.config import settings

_engine = None


def get_engine():
    global _engine
    if _engine is None:
        url = (
            f"postgresql+psycopg2://{settings.db_user}:{settings.db_password}"
            f"@{settings.db_host}:{settings.db_port}/{settings.db_name}"
        )
        _engine = create_engine(
            url,
            poolclass=QueuePool,
            pool_size=5,
            max_overflow=2,
            pool_pre_ping=True,
        )
    return _engine


def execute_query(sql: str, max_rows: int = 10) -> List[Dict[str, Any]]:
    """Run SQL safely. Always caps at max_rows=10. Returns list of row dicts."""
    with get_engine().connect() as conn:
        result = conn.execute(text(sql))
        rows = result.mappings().fetchmany(max_rows)
        return [dict(row) for row in rows]


def validate_sql_syntax(sql: str) -> Dict[str, Any]:
    """Use EXPLAIN to check SQL syntax without executing it."""
    try:
        with get_engine().connect() as conn:
            conn.execute(text(f"EXPLAIN {sql}"))
        return {"valid": True, "error": None}
    except Exception as e:
        return {"valid": False, "error": str(e)}
