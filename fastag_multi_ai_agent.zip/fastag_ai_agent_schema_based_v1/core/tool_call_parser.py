# core/tool_call_parser.py
"""
Tool Call Parser Bridge for local GGUF + Google ADK
Handles Gemma 4's specific tool call format:
  <|tool_call>call:validate_sql_tool{sql:<|"|>SELECT ...<|"|>}<tool_call|>
"""

import re
import json
import asyncio
import inspect
from typing import Optional, Dict, Any, Callable
from google.adk.tools import BaseTool
from google.genai.types import Content, Part
from core.logging_config import get_logger

logger = get_logger("tool_call_parser")

ALL_KNOWN_TOOLS = [
    "validate_sql_tool",
    "execute_sql_tool",
    "generate_visualization_tool",
    "get_schema_metadata_tool",
    "get_table_sample_tool",
]

_TOOLS_MAP: Dict[str, Callable] = {}


class SimpleTool(BaseTool):
    def __init__(self, func: Callable, name: str = None, description: str = None):
        self.name = name or func.__name__
        self.description = description or func.__doc__ or ""
        self._func = func
        sig = inspect.signature(func)
        self._user_params = [p for p in sig.parameters.keys() if p != "tool_context"]

    async def run_async(self, *, args: dict, tool_context=None) -> str:
        filtered = {k: v for k, v in args.items() if k in self._user_params}
        try:
            if asyncio.iscoroutinefunction(self._func):
                result = await self._func(**filtered)
            else:
                result = self._func(**filtered)
            return str(result)
        except Exception as e:
            logger.exception("tool_execution_failed")
            return json.dumps({"error": str(e)})


def make_tool(fn: Callable) -> SimpleTool:
    return SimpleTool(fn)


def set_tools_map(tools_map: Dict[str, Callable]):
    global _TOOLS_MAP
    _TOOLS_MAP.update(tools_map)
    logger.info("tool_map_registered", total_tools=len(_TOOLS_MAP))


# ── THE KEY FIX: Gemma 4 uses <|"|>value<|"|> instead of "value" ──────────
def _clean_gemma_quotes(text: str) -> str:
    text = re.sub(r'<\|"\|>(.*?)<\|"\|>', r'"\1"', text, flags=re.DOTALL)
    text = re.sub(r'<\|" \|>(.*?)<\|" \|>', r'"\1"', text, flags=re.DOTALL)
    text = re.sub(r'<\|["\u201c]\|>(.*?)<\|["\u201d]\|>', r'"\1"', text, flags=re.DOTALL)
    return text


def detect_tool_call(text: str) -> bool:
    if not text:
        return False
    markers = ["transfer_to_agent{", "transfer_to_agent(", "<|tool_call", "call:", "TRANSFER::"]
    for marker in markers:
        if marker in text:
            return True
    for tool in ALL_KNOWN_TOOLS:
        if f"{tool}(" in text:
            return True
    return False


def parse_transfer_agent(text: str) -> Optional[str]:
    if not text:
        return None
    cleaned = _clean_gemma_quotes(text)

    match = re.search(
        r'transfer_to_agent\s*[\({]\s*agent_name\s*[=:]\s*["\']?(\w+)["\']?',
        cleaned, re.IGNORECASE,
    )
    if match:
        return match.group(1)

    match = re.search(r'TRANSFER::\s*(\w+)', cleaned, re.IGNORECASE)
    if match:
        return match.group(1)

    for agent in ["hr_agent", "sales_agent", "production_agent"]:
        if "transfer_to_agent" in text and agent in text:
            return agent

    return None


def parse_tool_call(text: str) -> Optional[Dict[str, Any]]:
    
    print(f"[DEBUG PARSE] RAW TEXT: {repr(text[:300])}")  # ADD THIS LINE


    if not text:
        return None

    # Clean Gemma 4 quote tokens → standard quotes FIRST
    cleaned = _clean_gemma_quotes(text)

    print(f"[DEBUG PARSE] CLEANED: {repr(cleaned[:300])}")  # ADD THIS LINE


    logger.info("parse_tool_call_input", preview=cleaned[:200])

    # Pattern 1: call:TOOLNAME{...}  ← Gemma 4 primary format
    match = re.search(
        r'call:(\w+)\s*\{([^}]*(?:\{[^}]*\}[^}]*)*)\}',
        cleaned, re.DOTALL,
    )
    if match:
        tool_name = match.group(1).strip()
        args_text = match.group(2).strip()
        if tool_name in ALL_KNOWN_TOOLS:
            args = _extract_args(args_text)
            logger.info("tool_call_parsed", pattern=1, tool=tool_name, args=list(args.keys()))
            return {"tool_name": tool_name, "args": args}

    # Pattern 2: TOOLNAME(key="value")
    for tool in ALL_KNOWN_TOOLS:
        match = re.search(rf'{tool}\s*\(([^)]*)\)', cleaned, re.DOTALL)
        if match:
            args = _extract_args(match.group(1))
            logger.info("tool_call_parsed", pattern=2, tool=tool, args=list(args.keys()))
            return {"tool_name": tool, "args": args}

    # Pattern 3: call:TOOLNAME followed by JSON
    match = re.search(r'call:(\w+)\s*(\{.*\})', cleaned, re.DOTALL)
    if match:
        tool_name = match.group(1).strip()
        if tool_name in ALL_KNOWN_TOOLS:
            try:
                args = json.loads(match.group(2))
                logger.info("tool_call_parsed", pattern=3, tool=tool_name)
                return {"tool_name": tool_name, "args": args}
            except Exception:
                pass

    logger.info("tool_call_not_parsed", preview=text[:200])
    return None


def _extract_args(args_text: str) -> Dict[str, Any]:
    args = {}
    # Try JSON first
    try:
        parsed = json.loads("{" + args_text + "}")
        if isinstance(parsed, dict):
            return parsed
    except Exception:
        pass
    # key:"value"
    for m in re.finditer(r'(\w+)\s*:\s*"((?:[^"\\]|\\.)*)"', args_text, re.DOTALL):
        args[m.group(1)] = m.group(2).replace('\\"', '"')
    # key='value'
    for m in re.finditer(r"(\w+)\s*=\s*'((?:[^'\\]|\\.)*)'", args_text, re.DOTALL):
        if m.group(1) not in args:
            args[m.group(1)] = m.group(2)
    # key="value"
    for m in re.finditer(r'(\w+)\s*=\s*"((?:[^"\\]|\\.)*)"', args_text, re.DOTALL):
        if m.group(1) not in args:
            args[m.group(1)] = m.group(2)
    return args


async def execute_parsed_tool(parsed: Dict[str, Any]) -> Optional[str]:
    tool_name = parsed["tool_name"]
    args = parsed["args"]
    if tool_name not in _TOOLS_MAP:
        logger.error("unknown_tool", tool_name=tool_name, available=list(_TOOLS_MAP.keys()))
        return json.dumps({"error": f"Tool '{tool_name}' not found"})
    try:
        tool_fn = _TOOLS_MAP[tool_name]
        wrapped = make_tool(tool_fn)
        result = await wrapped.run_async(args=args, tool_context=None)
        logger.info("tool_executed", tool_name=tool_name, result_preview=str(result)[:100])
        return str(result)
    except Exception as e:
        logger.exception("tool_execution_failed", tool_name=tool_name)
        return json.dumps({"error": str(e)})


def format_tool_response(tool_name: str, result: str) -> str:
    return f"""TOOL RESULT: {tool_name}
{result}

Now continue with the next step of the workflow.
"""


def patch_adk_agent():
    try:
        from google.adk.agents.llm_agent import LlmAgent
        original_run_async = LlmAgent._run_async_impl

        async def patched_run_async_impl(self, ctx):

            # Collect ALL events from the original run
            events_so_far = []
            async for event in original_run_async(self, ctx):

                if not (hasattr(event, "content") and event.content):
                    yield event
                    continue

                parts = getattr(event.content, "parts", [])
                if not parts:
                    yield event
                    continue

                handled = False
                for part in parts:
                    text = getattr(part, "text", "")
                    if not text:
                        continue

                    if not detect_tool_call(text):
                        continue

                    # ── Transfer? ─────────────────────────────────────────
                    agent_name = parse_transfer_agent(text)
                    if agent_name:
                        logger.info("manual_agent_transfer", agent_name=agent_name)
                        event.content = Content(
                            role="model",
                            parts=[Part(text=f"TRANSFER::{agent_name}")]
                        )
                        yield event
                        handled = True
                        break

                    # ── Tool call? ────────────────────────────────────────
                    parsed = parse_tool_call(text)
                    if parsed:
                        logger.info("tool_call_intercepted", tool=parsed["tool_name"])
                        result = await execute_parsed_tool(parsed)
                        if result:
                            tool_response = format_tool_response(parsed["tool_name"], result)

                            # Yield the tool result event
                            event.content = Content(
                                role="model",
                                parts=[Part(text=tool_response)]
                            )
                            yield event

                            # ── KEY FIX: append tool result to ctx and re-run ──
                            try:
                                from google.adk.events import Event as AdkEvent
                                ctx.session.events.append(
                                    AdkEvent(
                                        author=self.name,
                                        content=Content(
                                            role="model",
                                            parts=[Part(text=tool_response)]
                                        )
                                    )
                                )
                                # Re-run the agent so it continues to next step
                                async for follow_event in patched_run_async_impl(self, ctx):
                                    yield follow_event
                                return
                            except Exception as e:
                                logger.error("context_append_failed", error=str(e))

                            handled = True
                            break

                if not handled:
                    yield event

        LlmAgent._run_async_impl = patched_run_async_impl
        logger.info("adk_patch_successful")
        return True

    except Exception as e:
        logger.exception("adk_patch_failed")
        return False    