# core/session_store.py
"""
File-based JSON session store.
One JSON file per browser session → sessions/session_{id}.json
Written to disk instantly after every query completes.
"""
import json
import os
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

SESSIONS_DIR = "sessions"


def _ensure_dir():
    os.makedirs(SESSIONS_DIR, exist_ok=True)


def _session_path(session_id: str) -> str:
    return os.path.join(SESSIONS_DIR, f"session_{session_id}.json")


def create_session() -> str:
    """Create a new session file and return the session_id."""
    _ensure_dir()
    session_id = str(uuid.uuid4())[:8]
    data = {
        "session_id": session_id,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "queries": [],
    }
    with open(_session_path(session_id), "w") as f:
        json.dump(data, f, indent=2, default=str)
    return session_id


def load_session(session_id: str) -> Optional[Dict[str, Any]]:
    """Load a session from disk. Returns None if not found."""
    path = _session_path(session_id)
    if not os.path.exists(path):
        return None
    with open(path) as f:
        return json.load(f)


def append_query(session_id: str, query_record: Dict[str, Any]) -> None:
    """Append a completed query record to the session file instantly."""
    _ensure_dir()
    session = load_session(session_id)
    if session is None:
        # Auto-create if missing (e.g. server restart with old session_id)
        session = {
            "session_id": session_id,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "queries": [],
        }
    session["queries"].append(query_record)
    with open(_session_path(session_id), "w") as f:
        json.dump(session, f, indent=2, default=str)


def list_all_sessions() -> List[Dict[str, Any]]:
    """Return a summary list of all sessions (id + created_at + query count)."""
    _ensure_dir()
    result = []
    for fname in sorted(os.listdir(SESSIONS_DIR)):
        if fname.startswith("session_") and fname.endswith(".json"):
            try:
                with open(os.path.join(SESSIONS_DIR, fname)) as f:
                    data = json.load(f)
                result.append({
                    "session_id": data["session_id"],
                    "created_at": data.get("created_at"),
                    "query_count": len(data.get("queries", [])),
                })
            except Exception:
                pass
    return result


def get_query(session_id: str, query_id: str) -> Optional[Dict[str, Any]]:
    """Fetch a single stored query by its id (read-only replay)."""
    session = load_session(session_id)
    if not session:
        return None
    for q in session.get("queries", []):
        if q.get("id") == query_id:
            return q
    return None
