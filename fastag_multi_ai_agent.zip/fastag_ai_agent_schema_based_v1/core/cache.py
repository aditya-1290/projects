# core/cache.py
"""
Per-agent in-memory schema metadata cache.
Loaded once at FastAPI startup. Never stores row data.
"""
from typing import Any, Dict, List

from sqlalchemy import inspect

from core.database import get_engine

# { agent_name: { "schema": str, "tables": { table_name: { columns, fks } } } }
_cache: Dict[str, Dict[str, Any]] = {}


def load_schema_cache(agent_name: str, schema: str, tables: List[str]) -> None:
    """
    Called once per agent at startup.
    Introspects PostgreSQL and fills _cache[agent_name].
    """
    inspector = inspect(get_engine())
    table_meta: Dict[str, Any] = {}

    for table in tables:
        try:
            cols = inspector.get_columns(table, schema=schema)
            pks  = inspector.get_pk_constraint(table, schema=schema)
            fks  = inspector.get_foreign_keys(table, schema=schema)
            idxs = inspector.get_indexes(table, schema=schema)
            pk_cols = pks.get("constrained_columns") or []

            table_meta[table] = {
                "columns": [
                    {
                        "name": c["name"],
                        "type": str(c["type"]),
                        "nullable": c.get("nullable", True),
                        "primary_key": c["name"] in pk_cols,
                    }
                    for c in cols
                ],
                "foreign_keys": [
                    {
                        "column": fk["constrained_columns"][0],
                        "references": (
                            f"{fk['referred_schema'] or schema}"
                            f".{fk['referred_table']}"
                            f".{fk['referred_columns'][0]}"
                        ),
                    }
                    for fk in fks
                    if fk["constrained_columns"]
                ],
                "indexes": [
                    {
                        "name": idx["name"],
                        "columns": idx["column_names"],
                        "unique": idx.get("unique", False),
                    }
                    for idx in idxs
                ],
            }
        except Exception as e:
            # Log and continue — don't crash startup if one table is missing
            print(f"[cache] WARNING: could not introspect {schema}.{table}: {e}")
            table_meta[table] = {"columns": [], "foreign_keys": [], "indexes": []}

    _cache[agent_name] = {"schema": schema, "tables": table_meta}


def get_cache(agent_name: str) -> Dict[str, Any]:
    """Return the cached metadata for an agent (empty dict if not found)."""
    return _cache.get(agent_name, {})


def cache_as_prompt_text(agent_name: str) -> str:
    """
    Render the cached schema as a compact text block suitable for
    injecting into an LLM prompt (used by generate_sql_tool).
    """
    data = get_cache(agent_name)
    if not data:
        return "No schema metadata available."

    schema = data["schema"]
    lines = [f"Schema: {schema}\n"]
    for table, meta in data["tables"].items():
        lines.append(f"Table: {schema}.{table}")
        for col in meta["columns"]:
            pk_marker = " [PK]" if col["primary_key"] else ""
            null_marker = "" if col["nullable"] else " NOT NULL"
            lines.append(f"  - {col['name']}  {col['type']}{pk_marker}{null_marker}")
        for fk in meta["foreign_keys"]:
            lines.append(f"  FK: {col['name']} -> {fk['references']}")
        lines.append("")
    return "\n".join(lines)
