# core/logging_config.py
"""
Structured JSON logging via structlog.
Three log files: app.log (all), agents.log (agent events), errors.log (errors only).
"""
import logging
import os
import structlog
from core.config import settings


def setup_logging():
    os.makedirs(settings.log_dir, exist_ok=True)

    level = getattr(logging, settings.log_level.upper(), logging.INFO)

    # --- standard Python logging handlers ---
    fmt = logging.Formatter("%(message)s")

    def make_handler(filename: str, level_filter: int = logging.DEBUG) -> logging.FileHandler:
        h = logging.FileHandler(os.path.join(settings.log_dir, filename))
        h.setLevel(level_filter)
        h.setFormatter(fmt)
        return h

    root = logging.getLogger()
    root.setLevel(level)
    root.addHandler(make_handler("app.log"))
    root.addHandler(make_handler("errors.log", logging.ERROR))

    # agents.log only for logger named "agent"
    agent_logger = logging.getLogger("agent")
    agent_logger.addHandler(make_handler("agents.log"))
    agent_logger.propagate = True

    # Also log to console
    console = logging.StreamHandler()
    console.setLevel(level)
    console.setFormatter(fmt)
    root.addHandler(console)

    # --- structlog config ---
    structlog.configure(
        processors=[
            structlog.stdlib.add_log_level,
            structlog.stdlib.add_logger_name,
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.JSONRenderer(),
        ],
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )


def get_logger(name: str = "app"):
    return structlog.get_logger(name)
