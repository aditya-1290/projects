@echo off
REM ============================================================
REM  Start llama-cpp-python HTTP server (Windows CPU)
REM  Model: D:\models\gemma.gguf  (update path below or in .env)
REM  Port:  8080
REM ============================================================

SET MODEL_PATH=%LLAMA_MODEL_PATH%
IF "%MODEL_PATH%"=="" SET MODEL_PATH=D:\Models\gemma-4-E4B-it-Q5_K_M.gguf

SET PORT=8080
SET N_CTX=2048
SET N_THREADS=4
SET N_GPU_LAYERS=0

IF NOT EXIST "%MODEL_PATH%" (
    echo ERROR: Model not found at %MODEL_PATH%
    echo Update LLAMA_MODEL_PATH in .env or edit this script.
    pause
    exit /b 1
)

echo ==============================================
echo   llama-cpp-python HTTP Server  [Windows CPU]
echo   Model     : %MODEL_PATH%
echo   Port      : %PORT%
echo   GPU layers: %N_GPU_LAYERS%  (0 = CPU only)
echo   Context   : %N_CTX% tokens
echo ==============================================

python -m llama_cpp.server ^
  --model "%MODEL_PATH%" ^
  --port %PORT% ^
  --n_ctx %N_CTX% ^
  --n_threads %N_THREADS% ^
  --n_gpu_layers %N_GPU_LAYERS% ^
  --host 127.0.0.1

pause
