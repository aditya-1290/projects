#!/bin/bash
# ============================================================
# Start MCP SSE Server on port 8001
# Run AFTER llama server, BEFORE FastAPI
# ============================================================
set -e
cd "$(dirname "$0")/.."
echo "Starting MCP server on port 8001..."
python -m mcp_server.server
