#!/bin/bash
# ============================================================
# Start llama-cpp-python HTTP server (Mac M4 — Metal GPU)
# Model: /Users/YOUR_USERNAME/models/gemma.gguf  (update path below)
# Port:  8080
# ============================================================

set -e

# ── Config ────────────────────────────────────────────────
MODEL_PATH="${LLAMA_MODEL_PATH:-/Users/$(whoami)/models/gemma.gguf}"
PORT="${LLAMA_PORT:-8080}"
N_CTX="${LLAMA_N_CTX:-2048}"
N_THREADS="${LLAMA_N_THREADS:-4}"
N_GPU_LAYERS="${LLAMA_N_GPU_LAYERS:-35}"    # 35 for Mac M4 Metal

# ── Sanity check ──────────────────────────────────────────
if [ ! -f "$MODEL_PATH" ]; then
  echo "❌  Model not found at: $MODEL_PATH"
  echo "    Update LLAMA_MODEL_PATH in .env or this script."
  exit 1
fi

echo "=============================================="
echo "  llama-cpp-python HTTP Server"
echo "  Model     : $MODEL_PATH"
echo "  Port      : $PORT"
echo "  GPU layers: $N_GPU_LAYERS (Metal)"
echo "  Context   : $N_CTX tokens"
echo "=============================================="

# ── Start server ──────────────────────────────────────────
python -m llama_cpp.server \
  --model "$MODEL_PATH" \
  --port "$PORT" \
  --n_ctx "$N_CTX" \
  --n_threads "$N_THREADS" \
  --n_gpu_layers "$N_GPU_LAYERS" \
  --host "127.0.0.1"
