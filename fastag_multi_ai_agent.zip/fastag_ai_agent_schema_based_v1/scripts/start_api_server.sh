#!/bin/bash
# ============================================================
# Start FastAPI server on port 8000
# Run AFTER both llama server and MCP server are up
# ============================================================
set -e
cd "$(dirname "$0")/.."
echo "Starting FastAPI server on port 8000..."
python -m api.main
