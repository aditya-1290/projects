@echo off
REM ============================================================
REM  Start MCP Server — SSE (port 8001) + HTTP (port 8002)
REM  Run AFTER llama server, BEFORE FastAPI
REM ============================================================

cd /d "%~dp0\.."
echo Starting MCP server — SSE on port 8001, HTTP on port 8002...
python -m mcp_server.server
pause