@echo off
REM ============================================================
REM  Start FastAPI server — port 8000
REM  Run AFTER both llama server and MCP server are up
REM ============================================================

cd /d "%~dp0\.."
echo Starting FastAPI server on port 8000...
python -m api.main
pause
