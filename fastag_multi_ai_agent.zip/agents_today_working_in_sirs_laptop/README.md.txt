=================================================================================================================
hr_agent-
=========
show all active employees with job title
show employees hired after 2019
show all departments
total salary by department
employee count by department

sales_agent-
============
show all customers with territory
show all salespersons with quota
show shipped orders only
count orders by status
total sales revenue by territory

production_agent-
=================
show all products with category
list work orders with status
show products with list price above 1000
work orders by status
total work order quantity by product

support_agent-
==============
show products with sales orders                   ----- sales and production
show employees who placed purchase orders and also made sales   ----
show customer full name email phone with their total spending   ----
show customer full name email phone with their total spending   -----sales, person



show all employees with full name email phone and department
who are top salespersons by revenue with full name
which employees placed purchase orders and total amount
total salary by department
total work order quantity by product
=================================================================================================================
# Get-ChildItem -Recurse -Filter *.py | Rename-Item -NewName { $_.Name -replace '\.py$','.txt' }
================================================
 to convert .py files to .txt files extension conversion
 
# Text-to-SQL Multi-Agent System
**Stack:** Python 3.11 · Google ADK 1.32.0 · llama-cpp-python · FastAPI · PostgreSQL · MCP SSE
## How it works (30-second summary)
```
Browser → FastAPI → ADK Runner → Manager LlmAgent
                                      ↓  (AutoFlow reads description fields)
                                 Schema LlmAgent  (hr / sales / production)
                                      ↓  (MCPToolset SSE)
                                 MCP Server  (port 8001)
                                      ↓
                                 PostgreSQL
```
The Manager agent reads each schema agent's **description field** and automatically calls
`transfer_to_agent(name)`. Zero custom routing code needed.
## Startup order (ALWAYS follow this — both platforms)

| Step | What to start | Wait for |
|------|---------------|----------|
| 1 | llama-cpp-python server (port 8080) | `HTTP server listening at 8000` |
| 2 | MCP server (port 8001) | `Starting MCP server on port 8001  AND 8002` |
| 3 | FastAPI server (port 8000) | `Uvicorn running on port 8003` |

---

## Windows Setup (step by step)

### Prerequisites
- Python 3.11 from https://python.org (tick "Add to PATH" during install)
- Your model file at `D:\models\gemma.gguf` (or update `.env`)

### Step 1 — Unzip the project
```
Right-click text_to_sql.zip → Extract All → e.g. C:\projects\text_to_sql
```
Open **Command Prompt** and go there:
```cmd
cd C:\projects\text_to_sql
```
### Step 2 — Create virtual environment
```cmd
python -m venv .venv
.venv\Scripts\activate
```
### Step 3 — Install llama-cpp-python (Windows CPU — no GPU flags)
```cmd
pip install llama-cpp-python==0.3.4 --no-cache-dir
```
#
pip install llama-cpp-python==0.2.90 --extra-index-url https://abetlen.github.io/llama-cpp-python/whl/cpu --force-reinstall --no-cache-dir

> On Windows there is no Metal/CUDA flag needed — it runs on CPU automatically.
> With 16 GB RAM and Gemma E4B Q5 model, expect 30–60 sec response time. That is normal.

### Step 4 — Install everything else

```cmd
pip install -r requirements.txt
```

### Step 5 — Edit .env

Open `.env` in Notepad and set:

```env
LLAMA_MODEL_PATH=D:\models\gemma.gguf
LLAMA_N_GPU_LAYERS=0

DB_HOST=localhost
DB_NAME=your_db_name
DB_USER=your_user
DB_PASSWORD=your_password
```

### Step 6 — Open 3 Command Prompt windows, run in order

**Window 1 — Llama server (double-click or run):**
```cmd
scripts\start_llama_server.bat
```
Wait until you see: `HTTP server listening at http://127.0.0.1:8080`

**Window 2 — MCP server:**
```cmd
scripts\start_mcp_server.bat
```

**Window 3 — FastAPI:**
```cmd
scripts\start_api_server.bat
```

### Step 7 — Open browser

```
http://localhost:8000
```

---

## Mac M4 Setup (step by step)

### Prerequisites
- macOS with Xcode command-line tools: `xcode-select --install`
- Python 3.11: `brew install python@3.11`
- Your model file copied to Mac (e.g. `~/models/gemma.gguf`)

### Step 1 — Copy model to Mac

```bash
mkdir -p ~/models
# Copy gemma.gguf from your Windows machine or USB to here
```

### Step 2 — Unzip and enter folder

```bash
unzip text_to_sql.zip
cd text_to_sql
```

### Step 3 — Create virtual environment

```bash
python3.11 -m venv .venv
source .venv/bin/activate
```

### Step 4 — Install llama-cpp-python WITH Metal (critical for M4 speed)

```bash
CMAKE_ARGS="-DLLAMA_METAL=on" \
  pip install llama-cpp-python==0.3.4 --no-cache-dir --force-reinstall
```

> You should see `metal` in the build output. This enables GPU acceleration on M4.
> Do NOT skip this — without it llama runs CPU-only and is much slower.

### Step 5 — Install everything else

```bash
pip install -r requirements.txt
```

### Step 6 — Edit .env

```env
LLAMA_MODEL_PATH=/Users/YOUR_USERNAME/models/gemma.gguf
LLAMA_N_GPU_LAYERS=35          # 35 for Mac M4 Metal

DB_HOST=your-neon-host.neon.tech
DB_NAME=your_db_name
DB_USER=your_user
DB_PASSWORD=your_password
```

### Step 7 — Open 3 Terminal tabs, run in order

```bash
# Tab 1
bash scripts/start_llama_server.sh

# Tab 2 (after Tab 1 shows "listening")
bash scripts/start_mcp_server.sh

# Tab 3 (after Tab 2 is running)
bash scripts/start_api_server.sh
```

### Step 8 — Open browser

```
http://localhost:8000
```

---

## Switching from Windows dev → Mac FASTag production

In `.env`, change only:

```env
LLAMA_MODEL_PATH=/Users/YOUR_USERNAME/models/gemma.gguf
LLAMA_N_GPU_LAYERS=35
DB_HOST=localhost          # or Mac's IP for FASTag PostgreSQL
```

No code changes needed anywhere.

---

## Adding a new agent (no code change)

Add to `.env`:

```env
AGENT_4_NAME=purchasing_agent
AGENT_4_SCHEMA=purchasing
AGENT_4_TABLES=purchaseorderheader,vendor,shipmethod
```

Restart FastAPI. Done.

---

## Folder structure

```
text_to_sql/
├── .env                          ← ALL config: agents, DB, model path
├── requirements.txt
├── README.md
│
├── frontend/
│   └── index.html                ← full chat UI, no build step
│
├── mcp_server/
│   ├── server.py                 ← MCP SSE server port 8001
│   └── tools/
│       ├── execute_sql.py
│       ├── get_schema_metadata.py
│       ├── validate_sql.py
│       ├── generate_visualization.py
│       └── get_table_sample.py
│-------CONFIG/
|           |-predefined_queries.json
├── agents/
│   ├── agent_registry.py         ← ★ SINGLE PLACE all agents are registered
│   ├── manager_agent.py          ← root LlmAgent, AutoFlow routing
│   └── schema_agent.py           ← factory: one LlmAgent per .env block
│
├── core/
│   ├── config.py                 ← typed .env loader + dynamic agent parser
│   ├── database.py               ← SQLAlchemy connection pool
│   ├── cache.py                  ← per-agent schema metadata cache
│   ├── session_store.py          ← file-based JSON sessions
│   └── logging_config.py         ← structlog JSON logs
│
├── api/
│   ├── main.py                   ← FastAPI startup + ADK Runner init
│   └── routes/
│       ├── query.py              ← POST /query
│       └── sessions.py           ← GET /sessions, GET /sessions/{id}
│
└── scripts/
    ├── start_llama_server.sh     ← Mac Terminal 1
    ├── start_llama_server.bat    ← Windows CMD 1
    ├── start_mcp_server.sh       ← Mac Terminal 2
    ├── start_mcp_server.bat      ← Windows CMD 2
    ├── start_api_server.sh       ← Mac Terminal 3
    └── start_api_server.bat      ← Windows CMD 3
```

---

## Test queries (AdventureWorks)

| Query | Expected agent |
|---|---|
| Show all employees | hr_agent |
| Total sales per region | sales_agent |
| List products by work orders | production_agent |
| How many departments exist | hr_agent |
| Top 5 customers by order value | sales_agent |

---

## Logs

```
logs/
  app.log      ← all events (JSON)
  agents.log   ← agent routing events only
  errors.log   ← errors with traceback
```

---

## Troubleshooting

| Problem | Fix |
|---|---|
| Windows: `ModuleNotFoundError: llama_cpp` | Run Step 3 again with venv activated |
| Mac: Metal not showing at startup | Reinstall with `CMAKE_ARGS="-DLLAMA_METAL=on"` |
| `Connection refused` on port 8080 | Start llama server first, wait for "listening" |
| `Connection refused` on port 8001 | Start MCP server before FastAPI |
| Agent says "outside my scope" | Check AGENT_N_TABLES in .env matches actual DB table names |
| Very slow responses on Windows | Normal — CPU inference on 16GB RAM. Gemma E4B Q5 takes 30–60s |
| Very slow responses on Mac | Check GPU layers: should be 35, not 0 |
=================================================================================================================