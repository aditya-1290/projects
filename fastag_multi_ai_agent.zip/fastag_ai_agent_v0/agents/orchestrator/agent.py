"""
agents/orchestrator/agent.py
Updated to use the tool call parser bridge.
"""
# from core.suppress_warnings

import os
import json
import asyncio
from typing import Any, Dict

from dotenv import load_dotenv
from google.adk.agents import LlmAgent
from google.adk.models.lite_llm import LiteLlm
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService

from agents.orchestrator.agent_card import ORCHESTRATOR_CARD
from agents.orchestrator.skills.intent_detection import run_intent_detection
from agents.orchestrator.skills.schema_context_selector import select_schema_context
from core.mcp_client import mcp_client
from core.tool_call_parser import set_tools_map, patch_adk_agent,make_tool, SimpleBridge, parse_tool_call, execute_parsed_tool, detect_tool_call, format_tool_response
from core.logger import get_logger, success_logger, error_logger

load_dotenv()
logger = get_logger("orchestrator")

os.environ["OPENAI_API_KEY"] = os.getenv("LOCAL_LLM_API_KEY", "sk-local")
os.environ["OPENAI_API_BASE"] = os.getenv("LOCAL_LLM_BASE_URL", "http://127.0.0.1:8001/v1")

_model = LiteLlm(model=f"openai/{os.getenv('LOCAL_LLM_MODEL', 'local-model')}")


# ── ADK Tool functions ────────────────────────────────────────────────────────

def detect_query_intent(user_query: str) -> str:
    """Detect intent and complexity of a user database query."""
    result = run_intent_detection(user_query)
    logger.info(f"Intent detected: {result}")
    return json.dumps(result)


def get_database_context(user_query: str, intent: str, query_type: str) -> str:
    """Fetch database schema cache and select relevant schema, tables, columns."""
    try:
        cache = mcp_client.get_cache()
        context = select_schema_context(user_query, intent, query_type, cache)

        selected_schema = context.get("selected_schema", "public")
        selected_tables = context.get("selected_tables", [])
        schemas_data = cache.get("schemas", {})

        schema_details = {}
        for table in selected_tables:
            full_name = f"{selected_schema}.{table}"
            info = schemas_data.get(full_name) or schemas_data.get(table, {})
            if info:
                schema_details[table] = {
                    "columns": info.get("columns", []),
                    "row_count": info.get("row_count", 0),
                }

        context["schema_details"] = schema_details
        context["table_count"] = cache.get("metadata", {}).get("table_count", 0)
        return json.dumps(context)
    except Exception as e:
        error_logger.error(f"get_database_context failed: {e}")
        return json.dumps({"error": str(e)})

wrapped_detect_intent = make_tool(detect_query_intent)
wrapped_get_context = make_tool(get_database_context)

# ── Tools map for bridge ──────────────────────────────────────────────────────
_TOOLS_MAP = {
    "detect_query_intent": detect_query_intent,   # ← Tool name matches LLM call
    "get_database_context": get_database_context, # ← Tool name matches LLM call
}

# Set global tools map
set_tools_map(_TOOLS_MAP)

# Patch ADK agent to intercept tool calls
patch_adk_agent()


# ── ADK LlmAgent ──────────────────────────────────────────────────────────────

ORCHESTRATOR_INSTRUCTION = """
You are the Orchestrator Agent for the MLFF analytics system.

The user's message contains their database query. You must process it using exactly 2 tool calls in order.

STEP 1 — Call detect_query_intent. Pass the user's EXACT message as user_query.
STEP 2 — Call get_database_context. Pass the SAME user message as user_query, plus intent and query_type from step 1.

DO NOT use placeholder text like "the user's question" or "from step 1" as literal values.
Copy the actual text from the user's message into user_query.
Copy the actual intent value returned by detect_query_intent into intent.
Copy the actual query_type value returned by detect_query_intent into query_type.

After both tools complete, return ONLY this JSON:
{
  "intent": "<actual value from detect_query_intent result>",
  "query_type": "<actual value from detect_query_intent result>",
  "confidence": <actual number from detect_query_intent result>,
  "selected_schema": "<actual value from get_database_context result>",
  "selected_tables": [<actual values from get_database_context result>],
  "context_summary": "<actual value from get_database_context result>",
  "routing_to": "mlff"
}
"""

orchestrator_llm_agent = LlmAgent(
    name="orchestrator",
    model=_model,
    description=ORCHESTRATOR_CARD.description,
    instruction=ORCHESTRATOR_INSTRUCTION,
    tools=[wrapped_detect_intent, wrapped_get_context],
    output_key="orchestrator_result",
)

_session_service = InMemorySessionService()
_runner = Runner(
    agent=orchestrator_llm_agent,
    app_name="mlff_adk",
    session_service=_session_service,
)


# ── Bridge Runner (Intercepts and handles tool calls) ─────────────────────────

MAX_BRIDGE_ITERATIONS = 10

async def _run_with_bridge(
    session_service: InMemorySessionService,
    user_id: str,
    session_id: str,
    initial_message: str,
    app_name: str = "mlff_adk",
    query_id: str = "",
) -> str:
    from google.genai import types
    from core.tool_call_parser import (
        parse_tool_call, execute_parsed_tool,
        detect_tool_call, detect_tool_response, format_tool_response,
        detect_batch_tool_calls, parse_batch_tool_calls,
    )

    tool_results = {}
    iterations = 0

    # ── real_query is IMMUTABLE — never overwrite it ────────────
    real_query = initial_message
    if initial_message.startswith('Process this database query:'):
        real_query = initial_message.split('"', 1)[-1].rsplit('"', 1)[0]

    # current_message is what gets sent to the LLM each iteration
    # it changes — real_query never does
    current_message = f'Process this database query: "{real_query}"'

    while iterations < MAX_BRIDGE_ITERATIONS:
        iterations += 1

        session_id_iter = f"orch_{session_id}_{query_id}_iter{iterations}"
        await session_service.create_session(
            app_name=app_name,
            user_id=user_id,
            session_id=session_id_iter,
        )

        fresh_runner = Runner(
            agent=orchestrator_llm_agent,
            app_name=app_name,
            session_service=session_service,
        )

        logger.debug(f"[BRIDGE] Orchestrator Iteration {iterations} | session={session_id_iter}")

        message = types.Content(
            role="user",
            parts=[types.Part(text=current_message)],     # ← use current_message, not real_query
        )

        raw_text = ""
        gen = fresh_runner.run_async(
            user_id=user_id,
            session_id=session_id_iter,
            new_message=message,
        )

        try:
            async for event in gen:
                if event.is_final_response():
                    if event.content and event.content.parts:
                        raw_text = event.content.parts[0].text or ""
                        logger.debug(f"[BRIDGE] Raw output (iter {iterations}): {raw_text[:200]}")
                    await gen.aclose()
                    break
        except Exception as e:
            if "created in a different Context" not in str(e):
                logger.error(f"Unexpected error: {e}")

        if not raw_text:
            logger.warning(f"[BRIDGE] Empty response on iteration {iterations}")
            break

        # ── Case 1: Batch tool calls ──────────────────────────────────
        if detect_batch_tool_calls(raw_text):
            parsed_list = parse_batch_tool_calls(raw_text)
            if parsed_list:
                for parsed in parsed_list:
                    # Always override user_query with real value
                    if parsed['tool_name'] in ('detect_query_intent', 'get_database_context'):
                        parsed['args']['user_query'] = real_query
                    tool_result = await execute_parsed_tool(parsed, _TOOLS_MAP)
                    if tool_result:
                        tool_results[parsed['tool_name']] = tool_result

            # Fill any missing tool by calling Python directly
            _fill_missing_tools(tool_results, real_query)  # ← always real_query
            return _synthesize_from_tool_results(tool_results, real_query)

        # ── Case 2: Single tool CALL ──────────────────────────────────
        elif detect_tool_call(raw_text):
            parsed = parse_tool_call(raw_text)
            if parsed:
                # Always force the real user_query — never trust the LLM's value
                if parsed['tool_name'] in ('detect_query_intent', 'get_database_context'):
                    parsed['args']['user_query'] = real_query   # ← always real_query

                tool_result = await execute_parsed_tool(parsed, _TOOLS_MAP)
                if tool_result:
                    tool_results[parsed['tool_name']] = tool_result
                    logger.info(f"[BRIDGE] Tool executed: {parsed['tool_name']} | result_len={len(tool_result)}")

                    # ── After detect_query_intent: call get_database_context
                    #    directly in Python — don't wait for LLM to do it ──
                    if parsed['tool_name'] == 'detect_query_intent' \
                            and 'get_database_context' not in tool_results:
                        logger.info("[BRIDGE] Calling get_database_context directly in Python")
                        try:
                            intent_data = json.loads(tool_result)
                            context_result = get_database_context(
                                user_query=real_query,     # ← always real_query
                                intent=intent_data.get("intent", "lookup"),
                                query_type=intent_data.get("query_type", "simple"),
                            )
                            tool_results["get_database_context"] = context_result
                            logger.info(f"[BRIDGE] get_database_context done | result_len={len(context_result)}")
                        except Exception as e:
                            logger.error(f"[BRIDGE] Direct get_database_context failed: {e}")

                    # If both tools are done, synthesize and return immediately
                    if 'detect_query_intent' in tool_results \
                            and 'get_database_context' in tool_results:
                        logger.info("[BRIDGE] Both tools complete — synthesizing directly")
                        return _synthesize_from_tool_results(tool_results, real_query)

                    prior_context = "\n".join([
                        f"Tool {k} returned: {v[:300]}"
                        for k, v in tool_results.items()
                    ])
                    current_message = (
                        f'Original request: "{real_query}"\n\n'
                        f"Results so far:\n{prior_context}\n\n"
                        f"{format_tool_response(parsed['tool_name'], tool_result)}"
                    )
                    continue
                else:
                    logger.error(f"[BRIDGE] Tool returned None: {parsed['tool_name']}")
                    break
            else:
                logger.warning(f"[BRIDGE] Tool detected but parse failed: {raw_text[:200]}")
                break

        # ── Case 3: Tool RESPONSE from ADK patch ─────────────────────
        elif detect_tool_response(raw_text):

            # ── Extract tool results from ADK patch responses ─────────────
            # Pattern: response:TOOLNAME{value:<|"|>RESULT<|"|>}
            tool_response_pattern = re.compile(
                r'response:(\w+)\{value:<\|"\|>(.*?)<\|"\|>\}',
                re.DOTALL
            )
            for match in tool_response_pattern.finditer(raw_text):
                tool_name = match.group(1)
                tool_value = match.group(2).strip()
                if tool_name not in tool_results:
                    tool_results[tool_name] = tool_value
                    logger.info(
                        f"[BRIDGE] Extracted tool result from ADK response: {tool_name} | len={len(tool_value)}")

            # ── If detect_query_intent done, call get_database_context now ─
            if "detect_query_intent" in tool_results \
                    and "get_database_context" not in tool_results:
                logger.info("[BRIDGE] detect_query_intent done — calling get_database_context directly")
                try:
                    intent_data = json.loads(tool_results["detect_query_intent"])
                    context_result = get_database_context(
                        user_query=real_query,     # ← always real_query
                        intent=intent_data.get("intent", "lookup"),
                        query_type=intent_data.get("query_type", "simple"),
                    )
                    tool_results["get_database_context"] = context_result
                    logger.info("[BRIDGE] get_database_context done directly")
                except Exception as e:
                    logger.error(f"[BRIDGE] Direct get_database_context failed: {e}")

            # ── If both tools done, synthesize and return immediately ──────
            if "detect_query_intent" in tool_results \
                    and "get_database_context" in tool_results:
                logger.info("[BRIDGE] Both tools complete — synthesizing")
                return _synthesize_from_tool_results(tool_results, real_query)

            logger.info(f"[BRIDGE] Got tool response on iter {iterations}, continuing...")
            real_query = raw_text
            continue

        # ── Case 4: Final JSON response ───────────────────────────────
        else:
            # LLM jumped to final answer — check if tools are missing
            if 'detect_query_intent' not in tool_results \
                    or 'get_database_context' not in tool_results:
                logger.warning("[BRIDGE] LLM gave final answer but tools incomplete — filling directly")
                _fill_missing_tools(tool_results, real_query)    # ← always real_query
                return _synthesize_from_tool_results(tool_results, real_query)

            logger.info(f"[BRIDGE] Final response on iteration {iterations}")
            return raw_text

    if tool_results:
        _fill_missing_tools(tool_results, real_query)
        return _synthesize_from_tool_results(tool_results, real_query)

    return ""

def _fill_missing_tools(tool_results: dict, user_query: str) -> None:
    """Call any missing orchestrator tools directly in Python."""
    if 'detect_query_intent' not in tool_results:
        try:
            result = detect_query_intent(user_query)
            tool_results['detect_query_intent'] = result
            logger.info("[BRIDGE] Filled detect_query_intent directly")
        except Exception as e:
            logger.error(f"[BRIDGE] detect_query_intent direct call failed: {e}")

    if 'get_database_context' not in tool_results:
        try:
            intent_data = json.loads(tool_results.get('detect_query_intent', '{}'))
            result = get_database_context(
                user_query=user_query,
                intent=intent_data.get("intent", "lookup"),
                query_type=intent_data.get("query_type", "simple"),
            )
            # ── Filter hallucinated relevant_columns ──────────────
            try:
                ctx = json.loads(result)
                selected = ctx.get("selected_tables", [])
                ctx["relevant_columns"] = {
                    k: v for k, v in ctx.get("relevant_columns", {}).items()
                    if k in selected
                }
                result = json.dumps(ctx)
            except Exception:
                pass
            # ─────────────────────────────────────────────────────
            tool_results['get_database_context'] = result
            logger.info("[BRIDGE] Filled get_database_context directly")
        except Exception as e:
            logger.error(f"[BRIDGE] get_database_context direct call failed: {e}")

def _synthesize_from_tool_results(tool_results: dict, user_query: str) -> str:
    """Build the orchestrator JSON directly from collected tool results."""
    import json

    intent_raw = tool_results.get("detect_query_intent", "{}")
    context_raw = tool_results.get("get_database_context", "{}")

    try:
        intent_data = json.loads(intent_raw) if isinstance(intent_raw, str) else intent_raw
    except Exception:
        intent_data = {}

    try:
        context_data = json.loads(context_raw) if isinstance(context_raw, str) else context_raw
    except Exception:
        context_data = {}

    selected_tables = context_data.get("selected_tables", [])

    # ── Only keep relevant_columns for tables that were actually selected ──
    raw_relevant_columns = context_data.get("relevant_columns", {})
    relevant_columns = {
        k: v for k, v in raw_relevant_columns.items()
        if k in selected_tables
    }

    schema_details_raw = context_data.get("schema_details", {})
    schema_details_clean = {
        k: v for k, v in schema_details_raw.items()
        if k in selected_tables
    }

    return json.dumps({
        "intent": intent_data.get("intent", "aggregation"),
        "query_type": intent_data.get("query_type", "select"),
        "confidence": intent_data.get("confidence", 0.75),
        "selected_schema": context_data.get("selected_schema", "public"),
        "selected_tables": context_data.get("selected_tables", []),
        "relevant_columns": relevant_columns,
        "relationships_hint": context_data.get("relationships_hint", []),
        "context_summary": context_data.get("context_summary", ""),
        "schema_details": schema_details_clean,
        "routing_to": "mlff",
    })

# ── Run with bridge ──────────────────────────────────────────────────────────
async def run_orchestrator_async(
    user_query: str,
    session_id: str,
    user_id: str = "mlff_user",
) -> Dict[str, Any]:

    success_logger.info(f"[{session_id}] Orchestrator started | query={user_query[:80]}")

    try:
        import uuid
        query_id = uuid.uuid4().hex[:8]

        final_text = await _run_with_bridge(
            session_service=_session_service,
            user_id=user_id,
            session_id=session_id,
            initial_message=f'Process this database query: "{user_query}"',
            query_id=query_id,
        )

        success_logger.info(f"[{session_id}] Orchestrator response: {final_text[:200]}")

        clean = final_text.strip()
        if not clean:
            raise ValueError("Empty response from orchestrator")

        # FIXED: Better markdown extraction
        if "```" in clean:
            parts = clean.split("```")
            for part in parts:
                s = part.strip()
                # Handle "```json" prefix
                if s.lower().startswith("json"):
                    s = s[4:].strip()
                if s.startswith("{"):
                    clean = s
                    break
            else:
                # If no part starts with {, try the second part (most common)
                if len(parts) >= 2:
                    s = parts[1].strip()
                    if s.lower().startswith("json"):
                        s = s[4:].strip()
                    if s.startswith("{"):
                        clean = s

        payload = json.loads(clean)
        payload["ok"] = True
        payload["user_query"] = user_query
        payload["request_id"] = session_id

        return payload

    except Exception as e:
        error_logger.error(f"[{session_id}] Orchestrator failed: {e}")
        return await _orchestrator_fallback(user_query, session_id)
    

async def _orchestrator_fallback(
    user_query: str,
    session_id: str,
) -> Dict[str, Any]:
    """Direct fallback — calls skills in Python."""
    logger.warning(f"[{session_id}] Using orchestrator fallback")
    try:
        intent_result = run_intent_detection(user_query)
        cache = mcp_client.get_cache()
        context = select_schema_context(
            user_query,
            intent_result["intent"],
            intent_result["query_type"],
            cache,
        )
        schemas_data = cache.get("schemas", {})
        selected_schema = context.get("selected_schema", "public")
        schema_details = {}
        for table in context.get("selected_tables", []):
            full_name = f"{selected_schema}.{table}"
            info = schemas_data.get(full_name) or schemas_data.get(table, {})
            if info:
                schema_details[table] = {
                    "columns": info.get("columns", []),
                    "row_count": info.get("row_count", 0),
                }
        return {
            "ok": True,
            "request_id": session_id,
            "user_query": user_query,
            "intent": intent_result["intent"],
            "query_type": intent_result["query_type"],
            "confidence": intent_result["confidence"],
            "confidence_note": intent_result.get("confidence_note", ""),
            "low_confidence": intent_result["confidence"] < 0.60,
            "selected_schema": selected_schema,
            "selected_tables": context.get("selected_tables", []),
            "relevant_columns": context.get("relevant_columns", {}),
            "relationships_hint": context.get("relationships_hint", []),
            "context_summary": context.get("context_summary", ""),
            "schema_details": schema_details,
            "routing_to": "mlff",
        }
    except Exception as e:
        return {
            "ok": False,
            "request_id": session_id,
            "user_query": user_query,
            "error": str(e),
            "confidence": 0.0,
        }
    