"""
agents/orchestrator/skills/schema_context_selector.py
Two-stage table selection:
  Stage 1: Python scoring (handles 10k tables, multiple schemas)
  Stage 2: LLM refinement only for complex queries on small candidate list
"""
import json
import re
from typing import Any, Dict, List, Tuple

from core.llm_client import call_llm
from core.logger import get_logger

logger = get_logger("schema_context_skill")

MAX_TABLES_IN_CONTEXT = 5
MAX_COLUMNS_PER_TABLE = 6
MAX_CANDIDATES_FOR_LLM = 20


def _score_tables(
    user_query: str,
    all_tables: List[str],
    schemas_data: Dict[str, Any],
    schema: str,
) -> List[Tuple[float, str]]:
    """
    Score every table by relevance to the query using pure Python.
    Handles 10,000+ tables in milliseconds.
    """
    query_lower = user_query.lower()
    query_lower = re.sub(r'process this database query:\s*"?', '', query_lower).strip('"')
    query_words = set(re.sub(r'[^a-z0-9 ]', ' ', query_lower).split())

    scored = []
    for table in all_tables:
        score = 0.0

        # Exact table name appears in query — strongest signal
        if table.lower() in query_lower:
            score += 10.0

        # Table name words overlap with query words
        table_words = set(re.sub(r'[^a-z0-9]', ' ', table.lower()).split())
        word_overlap = len(query_words & table_words)
        score += word_overlap * 3.0

        # Column names appear in query
        full_name = f"{schema}.{table}"
        info = schemas_data.get(full_name) or schemas_data.get(table, {})
        cols = info.get("columns", [])
        for col in cols:
            col_name = col.get("column_name", "").lower()
            if col_name in query_lower and len(col_name) > 2:
                score += 2.0
            col_words = set(col_name.replace('_', ' ').split())
            score += len(query_words & col_words) * 1.0

        if score > 0:
            scored.append((score, table))

    scored.sort(reverse=True)
    return scored


def _expand_via_fk(
    selected_tables: List[str],
    relationships: Dict[str, Any],
    all_tables: List[str],
    max_total: int,
) -> List[str]:
    """
    One-hop FK expansion — adds directly related tables up to max_total.
    Originals always kept first.
    """
    adj_map: Dict[str, List[str]] = {}
    for rel in relationships.keys():
        parts = rel.split(" -> ")
        if len(parts) != 2:
            continue
        from_parts = parts[0].split(".")
        to_parts = parts[1].split(".")
        if len(from_parts) >= 2 and len(to_parts) >= 2:
            from_table = from_parts[1]
            to_table = to_parts[1]
            adj_map.setdefault(from_table, [])
            adj_map.setdefault(to_table, [])
            if to_table not in adj_map[from_table]:
                adj_map[from_table].append(to_table)
            if from_table not in adj_map[to_table]:
                adj_map[to_table].append(from_table)

    expanded = list(selected_tables)
    for table in list(selected_tables):
        if len(expanded) >= max_total:
            break
        for related in adj_map.get(table, []):
            if related not in expanded and related in all_tables:
                expanded.append(related)
                if len(expanded) >= max_total:
                    break

    return expanded[:max_total]


def _select_schema(
    user_query: str,
    table_map: Dict[str, List[str]],
    schemas_data: Dict[str, Any],
) -> str:
    """
    Pick the most relevant schema when multiple schemas exist.
    Scores each schema by keyword overlap with query.
    """
    if len(table_map) == 1:
        return list(table_map.keys())[0]

    query_lower = user_query.lower()
    query_words = set(re.sub(r'[^a-z0-9 ]', ' ', query_lower).split())

    best_schema = None
    best_score = -1

    for schema, tables in table_map.items():
        score = 0.0

        # Schema name directly in query — very strong signal
        if schema.lower() in query_lower:
            score += 20.0

        schema_words = set(schema.lower().replace('_', ' ').split())
        score += len(query_words & schema_words) * 5.0

        # How many tables in this schema match query words
        for table in tables:
            if table.lower() in query_lower:
                score += 3.0
            table_words = set(re.sub(r'[^a-z0-9]', ' ', table.lower()).split())
            score += len(query_words & table_words) * 1.0

        if score > best_score:
            best_score = score
            best_schema = schema

    return best_schema or list(table_map.keys())[0]


def _llm_refine_tables(
    user_query: str,
    intent: str,
    query_type: str,
    candidates: List[Dict[str, Any]],
    relationships: Dict[str, Any],
) -> List[str]:
    """
    LLM picks final tables from a small pre-filtered candidate list.
    Only called for complex/analytical queries.
    Input is capped at MAX_CANDIDATES_FOR_LLM so local models handle it.
    """
    rel_lines = list(relationships.keys())[:10]

    prompt = f"""Pick the most relevant tables to answer this query.

USER QUERY: {user_query}
INTENT: {intent}

CANDIDATE TABLES (choose from ONLY these):
{json.dumps(candidates, indent=2)}

FOREIGN KEY RELATIONSHIPS:
{chr(10).join(rel_lines) if rel_lines else 'None'}

Return ONLY a JSON array of table names, maximum {MAX_TABLES_IN_CONTEXT}:
["table1", "table2"]

No explanation. No markdown. Just the JSON array."""

    system = (
        f"You pick database tables. "
        f"Return ONLY a JSON array of table names from the provided list. "
        f"Maximum {MAX_TABLES_IN_CONTEXT} tables."
    )

    try:
        raw = call_llm(system, prompt, max_tokens=128)
        raw = raw.strip().strip('`').strip()
        if raw.lower().startswith('json'):
            raw = raw[4:].strip()

        result = json.loads(raw)
        if isinstance(result, list):
            valid_names = [c["table"] for c in candidates]
            valid = [t for t in result if t in valid_names]
            if valid:
                logger.info(f"[SCHEMA_CTX] LLM refined tables: {valid}")
                return valid[:MAX_TABLES_IN_CONTEXT]
    except Exception as e:
        logger.warning(f"[SCHEMA_CTX] LLM refinement failed: {e}. Using top candidates.")

    return [c["table"] for c in candidates[:MAX_TABLES_IN_CONTEXT]]


def select_schema_context(
    user_query: str,
    intent: str,
    query_type: str,
    cache: Dict[str, Any],
) -> Dict[str, Any]:

    logger.debug(
        f"[SCHEMA_CTX] Received user_query={user_query!r} | "
        f"intent={intent} | query_type={query_type}"
    )

    table_map = cache.get("table_map", {})
    schemas_data = cache.get("schemas", {})
    relationships = cache.get("relationships", {})

    if not table_map:
        logger.error("[SCHEMA_CTX] Empty table_map in cache")
        return {
            "selected_schema": "public",
            "selected_tables": [],
            "relevant_columns": {},
            "relationships_hint": [],
            "context_summary": "No schema data available.",
            "schema_details": {},
        }

    # ── Step 1: Pick the right schema ────────────────────────────────────────
    selected_schema = _select_schema(user_query, table_map, schemas_data)
    all_tables = table_map.get(selected_schema, [])
    logger.debug(
        f"[SCHEMA_CTX] Schema={selected_schema} | "
        f"Total tables in schema: {len(all_tables)}"
    )

    # ── Step 2: Score all tables with Python ─────────────────────────────────
    scored = _score_tables(user_query, all_tables, schemas_data, selected_schema)
    top_candidates = scored[:MAX_CANDIDATES_FOR_LLM]

    # ── Step 3: Decide path based on complexity ───────────────────────────────
    complex_intents = ("aggregation", "ranking", "analytics")
    complex_query_types = ("complex", "analytical", "multi_join", "medium")

    needs_llm = (
        len(top_candidates) > MAX_TABLES_IN_CONTEXT
        and (
            intent in complex_intents
            or query_type in complex_query_types
        )
    )

    if not top_candidates:
        # No scoring signal at all — use first N tables as last resort
        selected_tables = all_tables[:MAX_TABLES_IN_CONTEXT]
        logger.info(f"[SCHEMA_CTX] No score signal. Using first {len(selected_tables)} tables.")

    elif not needs_llm:
        # Simple query or few candidates — Python scoring is enough
        selected_tables = [t for _, t in top_candidates[:MAX_TABLES_IN_CONTEXT]]
        logger.info(f"[SCHEMA_CTX] Python-only selection: {selected_tables}")

    else:
        # Complex query — LLM refines from small candidate list
        candidates_for_llm = [
            {
                "table": t,
                "score": round(s, 1),
                "columns": [
                    c["column_name"]
                    for c in (
                        schemas_data.get(f"{selected_schema}.{t}") or
                        schemas_data.get(t, {})
                    ).get("columns", [])[:4]
                ]
            }
            for s, t in top_candidates
        ]
        selected_tables = _llm_refine_tables(
            user_query, intent, query_type,
            candidates_for_llm, relationships
        )
        logger.info(f"[SCHEMA_CTX] LLM-refined selection: {selected_tables}")

    # ── Step 4: FK expansion only when joins are needed ──────────────────────
    join_keywords = ["join", "with", "across", "each", "per", "by", "relate", "together"]
    needs_expansion = any(kw in user_query.lower() for kw in join_keywords)

    if needs_expansion and len(selected_tables) < MAX_TABLES_IN_CONTEXT:
        before = list(selected_tables)
        selected_tables = _expand_via_fk(
            selected_tables, relationships, all_tables, MAX_TABLES_IN_CONTEXT
        )
        if selected_tables != before:
            logger.info(f"[SCHEMA_CTX] FK expansion: {before} -> {selected_tables}")

    # ── Step 5: Build output ──────────────────────────────────────────────────
    relevant_columns = {}
    schema_details = {}

    for table in selected_tables:
        full_name = f"{selected_schema}.{table}"
        info = schemas_data.get(full_name) or schemas_data.get(table, {})
        cols = info.get("columns", [])
        relevant_columns[table] = [
            c["column_name"] for c in cols[:MAX_COLUMNS_PER_TABLE]
        ]
        schema_details[table] = {
            "columns": cols,
            "row_count": info.get("row_count", 0),
        }

    rel_lines = [
        r for r in relationships.keys()
        if any(t in r for t in selected_tables)
    ][:10]

    logger.info(f"Schema selected: {selected_schema} | Tables: {selected_tables}")

    return {
        "selected_schema": selected_schema,
        "selected_tables": selected_tables,
        "relevant_columns": relevant_columns,
        "relationships_hint": rel_lines,
        "context_summary": f"Selected tables for query: {', '.join(selected_tables)}",
        "schema_details": schema_details,
    }
