from fastapi import FastAPI, Depends
from sqlalchemy.orm import Session
from database import SessionLocal, engine
from models import SampleProject, Base
# import uvicorn

app = FastAPI()

@app.on_event("startup")
def startup():
    print("🚀 App started")

# Dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Create tables
@app.on_event("startup")
def startup():
    Base.metadata.create_all(bind=engine)

# Home Route
@app.get('/')
def home_root():
    return {"message": "Hello, Welcome to my application."}

@app.get("/hello/{name}")
def greet(name: str, db: Session = Depends(get_db)):
    user = db.query(SampleProject).filter(SampleProject.name == name).first()
    
    if user:
        return {
            "id": user.id,
            "name": user.name,
            "age": user.age
        }
    return{"message": f"No user found with the name {name}"}

# # Run app
# if __name__ == "__main__":
#     uvicorn.run("main:app", host="127.0.0.1", reload=True)