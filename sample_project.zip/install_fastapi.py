import subprocess
import sys

def install(package):
    """Install a Python package using pip programmatically"""
    subprocess.check_call([sys.executable, "-m", "pip", "install", package])

# Install FastAPI and Uvicorn
install("fastapi")
install("uvicorn")
install("sqlalchemy")
install("pymysql")