"""
Global Configuration for Log Analysis Multi-Agent System
Reads from .env file for environment-specific settings
"""

import os
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

QWEN_CONTEXT_SIZE = int(os.getenv("QWEN_CONTEXT_SIZE", "4096"))  # Was 16384

# ============================================
# Project Paths
# ============================================
BASE_DIR = Path(__file__).parent
MODELS_DIR = BASE_DIR / "models"
LLM_DIR = MODELS_DIR / "llm"
OCR_DIR = MODELS_DIR / "ocr"
EMBEDDINGS_DIR = MODELS_DIR / "embeddings"
PROMPTS_DIR = BASE_DIR / "prompts"
MEMORY_STORE_DIR = BASE_DIR / "memory_store"
LOGS_DIR = MEMORY_STORE_DIR / "logs"
CHROMA_DIR = MEMORY_STORE_DIR / "chroma_db"

# ============================================
# Model Paths (from .env)
# ============================================
GEMMA_MODEL_PATH = os.getenv("GEMMA_MODEL_PATH", str(LLM_DIR / "gemma-4-e4b-it-Q5_K_M.gguf"))
QWEN_MODEL_PATH = os.getenv("QWEN_MODEL_PATH", str(LLM_DIR / "qwen2.5-3b-instruct-Q4_K_M.gguf"))
OCR_MODEL_PATH = os.getenv("OCR_MODEL_PATH", str(OCR_DIR))
EMBEDDING_MODEL_PATH = os.getenv("EMBEDDING_MODEL_PATH", str(EMBEDDINGS_DIR / "bge-small-en-v1.5"))

# ============================================
# Model Inference Settings (from .env)
# ============================================
N_THREADS = int(os.getenv("N_THREADS", "8"))
N_BATCH = int(os.getenv("N_BATCH", "512"))

GEMMA_TEMPERATURE = float(os.getenv("GEMMA_TEMPERATURE", "0.1"))
GEMMA_TOP_P = float(os.getenv("GEMMA_TOP_P", "0.9"))
GEMMA_TOP_K = int(os.getenv("GEMMA_TOP_K", "40"))
GEMMA_REPEAT_PENALTY = float(os.getenv("GEMMA_REPEAT_PENALTY", "1.1"))
GEMMA_MAX_TOKENS = int(os.getenv("GEMMA_MAX_TOKENS", "2048"))
GEMMA_CONTEXT_SIZE = int(os.getenv("GEMMA_CONTEXT_SIZE", "8192"))
GEMMA_QUANTIZATION = os.getenv("GEMMA_QUANTIZATION", "Q5_K_M")

QWEN_TEMPERATURE = float(os.getenv("QWEN_TEMPERATURE", "0.0"))
QWEN_TOP_P = float(os.getenv("QWEN_TOP_P", "0.9"))
QWEN_TOP_K = int(os.getenv("QWEN_TOP_K", "40"))
QWEN_REPEAT_PENALTY = float(os.getenv("QWEN_REPEAT_PENALTY", "1.1"))
QWEN_MAX_TOKENS = int(os.getenv("QWEN_MAX_TOKENS", "4096"))
QWEN_CONTEXT_SIZE = int(os.getenv("QWEN_CONTEXT_SIZE", "16384"))
QWEN_QUANTIZATION = os.getenv("QWEN_QUANTIZATION", "Q4_K_M")

# ============================================
# Model Configurations
# ============================================
MODEL_CONFIGS = {
    "gemma": {
        "name": "gemma-4-e4b-it",
        "path": GEMMA_MODEL_PATH,
        "type": "llm",
        "size_gb": 3.0,
        "context_size": GEMMA_CONTEXT_SIZE,
        "quantization": GEMMA_QUANTIZATION,
        "n_threads": N_THREADS,
        "n_batch": N_BATCH,
        "temperature": GEMMA_TEMPERATURE,
        "top_p": GEMMA_TOP_P,
        "top_k": GEMMA_TOP_K,
        "repeat_penalty": GEMMA_REPEAT_PENALTY,
        "max_tokens": GEMMA_MAX_TOKENS,
        "priority": 1,  # 1=always_loaded
        "load_on_startup": True,
        "description": "Primary reasoning model"
    },
    "qwen_small": {
        "name": "qwen2.5-3b-it",
        "path": QWEN_MODEL_PATH,
        "type": "llm",
        "size_gb": 2.0,
        "context_size": QWEN_CONTEXT_SIZE,
        "quantization": QWEN_QUANTIZATION,
        "n_threads": N_THREADS,
        "n_batch": N_BATCH,
        "temperature": QWEN_TEMPERATURE,
        "top_p": QWEN_TOP_P,
        "top_k": QWEN_TOP_K,
        "repeat_penalty": QWEN_REPEAT_PENALTY,
        "max_tokens": QWEN_MAX_TOKENS,
        "priority": 1,
        "load_on_startup": True,
        "description": "Lightweight preprocessing model"
    },
    "deepseek_ocr": {
        "name": "deepseek-ocr2",
        "path": OCR_MODEL_PATH,
        "type": "ocr",
        "size_gb": 10.0,
        "context_size": 4096,
        "priority": 2,  # 2=on_demand
        "load_on_startup": False,
        "description": "OCR model for image extraction"
    },
    "embedding": {
        "name": "bge-small-en",
        "path": EMBEDDING_MODEL_PATH,
        "type": "embedding",
        "size_gb": 0.5,
        "priority": 1,
        "load_on_startup": True,
        "description": "Embedding model for memory retrieval"
    }
}

# ============================================
# System Limits (from .env)
# ============================================
MAX_MEMORY_GB = float(os.getenv("MAX_MEMORY_GB", "15.0"))
MAX_CONTEXT_TOKENS = int(os.getenv("MAX_CONTEXT_TOKENS", "4096"))
MAX_CHUNK_SIZE = int(os.getenv("MAX_CHUNK_SIZE", "4000"))
MAX_RETRIES = int(os.getenv("MAX_RETRIES", "3"))
LOOP_DETECTION_THRESHOLD = int(os.getenv("LOOP_DETECTION_THRESHOLD", "3"))
CONFIDENCE_THRESHOLD = float(os.getenv("CONFIDENCE_THRESHOLD", "0.5"))

# ============================================
# File Size Limits (from .env)
# ============================================
MAX_FILE_SIZE = int(os.getenv("MAX_FILE_SIZE", "104857600"))  # 100MB default
MAX_LOG_PASTE_LENGTH = int(os.getenv("MAX_LOG_PASTE_LENGTH", "50000"))

# ============================================
# Agent Configuration
# ============================================
AGENT_IDS = {
    "extractor": os.getenv("EXTRACTOR_AGENT_ID", "extractor_v1"),
    "preprocessor": os.getenv("PREPROCESSOR_AGENT_ID", "preprocessor_v1"),
    "analyzer": os.getenv("ANALYZER_AGENT_ID", "analyzer_v1"),
    "solver": os.getenv("SOLVER_AGENT_ID", "solver_v1"),
    "debugger": os.getenv("DEBUGGER_AGENT_ID", "debugger_v1"),
    "critic": os.getenv("CRITIC_AGENT_ID", "critic_v1"),
    "memory": os.getenv("MEMORY_AGENT_ID", "memory_v1"),
    "orchestrator": os.getenv("ORCHESTRATOR_AGENT_ID", "orchestrator_v1")
}

# Agent-to-Model mapping
AGENT_MODEL_MAP = {
    "extractor": None,          # Uses custom parsers
    "extractor_ocr": "deepseek_ocr",
    "preprocessor": "qwen_small",
    "analyzer": "gemma",
    "solver": "gemma",
    "debugger": "gemma",
    "critic": "gemma",
    "memory": "qwen_small",
    "orchestrator": "gemma"
}

# ============================================
# Tool Configuration
# ============================================
ENABLED_TOOLS = os.getenv(
    "ENABLED_TOOLS",
    "file_reader,terminal_exec,ocr_tool,search_tool,code_analysis"
).split(",")

# ============================================
# Safety Configuration (from .env)
# ============================================
SANDBOX_ENABLED = os.getenv("SANDBOX_ENABLED", "false").lower() == "true"
REQUIRE_HUMAN_APPROVAL = os.getenv("REQUIRE_HUMAN_APPROVAL", "true").lower() == "true"
AUDIT_LOGGING = os.getenv("AUDIT_LOGGING", "true").lower() == "true"

# Command categories that require human approval
DANGEROUS_COMMANDS = os.getenv(
    "DANGEROUS_COMMANDS",
    "rm,mv,cp,dd,mkfs,kill,pkill,shutdown,reboot,chmod,chown,sudo,su"
).split(",")

# ============================================
# Communication Bus Configuration (from .env)
# ============================================
MESSAGE_TTL = int(os.getenv("MESSAGE_TTL", "10"))
BROADCAST_TIMEOUT = int(os.getenv("BROADCAST_TIMEOUT", "30"))
DISCOVERY_TIMEOUT = int(os.getenv("DISCOVERY_TIMEOUT", "10"))

# ============================================
# Logging Configuration (from .env)
# ============================================
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
LOG_FORMAT = os.getenv("LOG_FORMAT", "%(asctime)s - %(name)s - %(levelname)s - %(message)s")
LOG_FILE = os.getenv("LOG_FILE", str(LOGS_DIR / "system.log"))

# ============================================
# CLI Configuration
# ============================================
CLI_PROMPT = os.getenv("CLI_PROMPT", "\n📝 Enter log/query (type 'quit' to exit):\n> ")
MAX_HISTORY = int(os.getenv("MAX_HISTORY", "100"))

# ============================================
# Storage Paths (from .env)
# ============================================
CHROMA_DB_PATH = os.getenv("CHROMA_DB_PATH", str(CHROMA_DIR))
AUDIT_LOG_PATH = os.getenv("AUDIT_LOG_PATH", str(LOGS_DIR / "audit.log"))

# ============================================
# Print Config Summary (for debugging)
# ============================================
def print_config_summary():
    """Print a summary of current configuration"""
    print("\n" + "=" * 60)
    print("CONFIGURATION SUMMARY")
    print("=" * 60)
    print(f"\n📁 Paths:")
    print(f"   Models: {MODELS_DIR}")
    print(f"   Logs: {LOGS_DIR}")
    print(f"   ChromaDB: {CHROMA_DIR}")
    print(f"\n🧠 Models:")
    print(f"   Gemma: {GEMMA_MODEL_PATH}")
    print(f"   Qwen: {QWEN_MODEL_PATH}")
    print(f"   OCR: {OCR_MODEL_PATH}")
    print(f"   Embedding: {EMBEDDING_MODEL_PATH}")
    print(f"\n⚙️ Settings:")
    print(f"   Max Memory: {MAX_MEMORY_GB}GB")
    print(f"   Threads: {N_THREADS}")
    print(f"   Max Retries: {MAX_RETRIES}")
    print(f"   Log Level: {LOG_LEVEL}")
    print(f"\n🔒 Safety:")
    print(f"   Sandbox: {SANDBOX_ENABLED}")
    print(f"   Human Approval: {REQUIRE_HUMAN_APPROVAL}")
    print(f"   Audit Logging: {AUDIT_LOGGING}")
    print("=" * 60 + "\n")


if __name__ == "__main__":
    print_config_summary()