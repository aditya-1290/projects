"""
Local Model Server — Serves Gemma and Qwen as OpenAI-compatible APIs.

Usage:
    python model_server.py                    # Both models
    python model_server.py --model gemma      # Gemma only on 8081
    python model_server.py --model qwen       # Qwen only on 8082
    python model_server.py --both             # Gemma:8081, Qwen:8082

Endpoints:
    GET  /v1/models              — List loaded models
    POST /v1/chat/completions    — Chat completion
    POST /v1/completions          — Text completion
    GET  /health                  — Health check
"""

import argparse
import sys
import subprocess
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

# Import model configs from your config
from config import MODEL_CONFIGS


def start_server(model_key: str, port: int):
    """Start a single llama-cpp model server."""
    config = MODEL_CONFIGS.get(model_key)
    if not config:
        print(f"  Model '{model_key}' not found in MODEL_CONFIGS")
        return None

    model_path = config["path"]
    context_size = config.get("context_size", 8192)
    n_threads = config.get("n_threads", 8)
    model_name = config.get("name", model_key)

    print(f"  Starting {model_name} on port {port}...")
    print(f"    Path: {model_path}")
    print(f"    Context: {context_size}")

    cmd = [
        sys.executable, "-m", "llama_cpp.server",
        "--model", model_path,
        "--n_ctx", str(context_size),
        "--n_threads", str(n_threads),
        "--host", "127.0.0.1",
        "--port", str(port),
    ]

    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )

    # Wait for it to be ready
    import requests
    for i in range(30):
        try:
            r = requests.get(f"http://127.0.0.1:{port}/health", timeout=2)
            if r.status_code == 200:
                print(f"  ✅ {model_name} ready on port {port}")
                return proc
        except Exception:
            time.sleep(1)

    print(f"  ⚠️ {model_name} may not have started (check port {port})")
    return proc


def main():
    parser = argparse.ArgumentParser(description="Local Model Server")
    parser.add_argument("--model", default="both", choices=["gemma", "qwen", "both"])
    args = parser.parse_args()

    print("""
    ╔══════════════════════════════════════════════════════════════╗
    ║     LOCAL MODEL SERVER                                      ║
    ║     OpenAI-compatible API for Gemma & Qwen                  ║
    ╚══════════════════════════════════════════════════════════════╝
    """)

    processes = []

    if args.model in ("gemma", "both"):
        proc = start_server("gemma", 8081)
        if proc:
            processes.append(proc)

    if args.model in ("qwen", "both"):
        proc = start_server("qwen_small", 8082)
        if proc:
            processes.append(proc)

    if not processes:
        print("No models started.")
        return

    print(f"\n✅ {len(processes)} model(s) running. Press Ctrl+C to stop.\n")
    print("Endpoints:")
    if args.model in ("gemma", "both"):
        print("  Gemma: http://127.0.0.1:8081/v1/chat/completions")
    if args.model in ("qwen", "both"):
        print("  Qwen:  http://127.0.0.1:8082/v1/completions")
    print(f"\n  Docs:  http://127.0.0.1:8081/docs")

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nShutting down...")
        for proc in processes:
            proc.terminate()
        print("Done.")


if __name__ == "__main__":
    main()
