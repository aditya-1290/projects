"""
agents/preprocessor/grep.py

Grep-style log filtering module for the Preprocessor Agent.

Design principles:
  - Zero external dependencies (pure stdlib only)
  - No async, no agents, no imports from other agents — safe to import anywhere
  - All regex patterns compiled once at construction time (fast on repeated calls)
  - Every filter records exactly what it removed and why (full audit trail)
  - Chainable: multiple filters applied in a defined, predictable order
  - Handles all edge cases: empty input, binary bleed, huge files, malformed lines

Public API:
  GrepFilter(config: GrepConfig)  →  filter(text: str) → GrepResult
  GrepConfig                      —  dataclass for all filter settings
  GrepResult                      —  dataclass for filtered text + stats
  LogLine                         —  internal parsed line representation

  Predefined profiles (pass to GrepFilter.from_profile()):
    PROFILE_SIGNAL_ONLY    — keep ERROR / WARN / CRITICAL lines + context
    PROFILE_NO_NOISE       — remove health checks, heartbeats, metrics spam
    PROFILE_ERRORS_ONLY    — keep only lines with explicit error keywords
    PROFILE_SECURITY       — keep auth, permission, credential events
    PROFILE_PERFORMANCE    — keep slow query, timeout, latency events
    PROFILE_FULL_CLEAN     — all noise removed, deduped, severity-sorted

Usage in preprocessor/agent.py:
    from agents.preprocessor.grep import GrepFilter, GrepConfig, PROFILE_NO_NOISE

    gf     = GrepFilter(PROFILE_NO_NOISE)
    result = gf.filter(raw_logs)
    clean  = result.filtered_text
"""

from __future__ import annotations

import re
import time
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, FrozenSet, List, Optional, Pattern, Set, Tuple


# =============================================================================
# Constants — noise patterns and severity maps
# =============================================================================

# Lines matching ANY of these are classified as noise (low-signal spam)
_NOISE_REGEXES: List[str] = [
    # Health / liveness probes
    r'"(?:GET|HEAD)\s+(?:/health|/healthz|/ping|/ready|/readyz|/live|/livez|/status)\s',
    r'\bhealth.?check\b',
    r'\bkeepalive\b',
    r'\bheartbeat\b',

    # Metrics / scrape endpoints
    r'"(?:GET|HEAD)\s+/metrics\s',
    r'\bprometheus.*scrape\b',
    r'\bstatsd.*gauge\b',

    # Regular polling / cron spam (every few seconds)
    r'\bpolling\b.*\bevery\s+\d+\s*s',
    r'\bscheduled\b.*\btask\b.*\bcompleted\b',
    r'\bwatchdog\b.*\btick\b',

    # Debug verbosity that adds no signal
    r'\bdebug\b.*\benter(?:ing)?\s+(?:method|function|handler)\b',
    r'\bdebug\b.*\bexit(?:ing)?\s+(?:method|function|handler)\b',
    r'\bverbose\b.*\btrace\b',

    # Routine successful DB pings
    r'\bSELECT\s+1\b',
    r'\bPING\s+OK\b',

    # k8s / Docker runtime chatter
    r'\bkubernetes.*lease\b',
    r'\bendpoint\s+slice\b',
    r'\bnode\s+heartbeat\b',
    r'\bcontainer.*already\s+running\b',

    # Load balancer noise
    r'\bELB-HealthChecker\b',
    r'\bGoogleHC\b',
    r'\bkube-probe\b',
]

# Severity keyword → canonical level (checked in order — first match wins)
_SEVERITY_MAP: List[Tuple[int, str, List[str]]] = [
    # (numeric_level, canonical_name, [keywords])
    (60, "CRITICAL", ["CRITICAL", "FATAL", "EMERGENCY", "EMERG", "PANIC"]),
    (50, "ERROR",    ["ERROR",    "ERR",   "SEVERE"]),
    (40, "WARNING",  ["WARNING",  "WARN"]),
    (30, "NOTICE",   ["NOTICE"]),
    (20, "INFO",     ["INFO",     "INFORMATION"]),
    (10, "DEBUG",    ["DEBUG",    "TRACE", "VERBOSE"]),
]
_LEVEL_BY_NAME: Dict[str, int] = {}
for _lvl, _name, _kws in _SEVERITY_MAP:
    _LEVEL_BY_NAME[_name] = _lvl
    for _kw in _kws:
        _LEVEL_BY_NAME[_kw.upper()] = _lvl

# Timestamp patterns — ordered most-specific first
_TIMESTAMP_PATTERNS: List[Tuple[str, str]] = [
    # ISO 8601 with timezone
    (r'\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?',
     "%Y-%m-%dT%H:%M:%S"),
    # RFC 3164 syslog
    (r'(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2}\s+\d{2}:\d{2}:\d{2}',
     "%b %d %H:%M:%S"),
    # Apache Combined Log
    (r'\d{2}/(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)/\d{4}:\d{2}:\d{2}:\d{2}',
     "%d/%b/%Y:%H:%M:%S"),
    # Windows Event / SQL Server
    (r'\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}(?:\.\d+)?',
     "%Y-%m-%d %H:%M:%S"),
    # Epoch seconds (10 digits)
    (r'\b1[5-9]\d{8}\b', "epoch"),
]

# Signal patterns for each profile (lines matching are KEPT)
_SIGNAL_REGEXES: Dict[str, List[str]] = {
    "SECURITY": [
        r'\bauth(?:entication|orization|oriz)?\b',
        r'\bpermission\b', r'\bprivilege\b', r'\bunauthorized\b',
        r'\bforbidden\b', r'\baccess\s+denied\b', r'\blogin\b',
        r'\blogout\b', r'\bsudo\b', r'\bsu\b', r'\bsetuid\b',
        r'\bcredential\b', r'\btoken\b', r'\bsecret\b',
        r'\bssl\b', r'\btls\b', r'\bcertificate\b',
        r'\bbrute\s+force\b', r'\bsql\s+injection\b',
        r'\bpath\s+traversal\b', r'\bxss\b', r'\bcsrf\b',
        r'(?:401|403)\s+',
    ],
    "PERFORMANCE": [
        r'\bslow\s+quer(?:y|ies)\b', r'\bquery\s+time\b', r'\bduration\b',
        r'\blatency\b', r'\btimeout\b', r'\btimed?\s+out\b',
        r'\bresponse\s+time\b', r'\belapsed\b', r'\bms\b.*\d{4,}',
        r'\bslow\b.*\d{3,}\s*ms', r'\bthreshold\b',
        r'\bgc\s+pause\b', r'\bstop.the.world\b',
        r'\bheap\s+usage\b', r'\bmemory\s+pressure\b',
        r'\bcpu\s+(?:spike|usage|load)\b', r'\bthrottle\b',
        r'\bqueue\s+depth\b', r'\bbackpressure\b',
    ],
}


# =============================================================================
# Data structures
# =============================================================================

@dataclass
class LogLine:
    """
    A single parsed log line with all extracted metadata.
    Used internally throughout the filter pipeline.
    """
    number:    int             # 1-based line number in original input
    raw:       str             # original text (no trailing newline)
    severity:  str    = ""    # canonical severity name e.g. "ERROR"
    level_num: int    = 0     # numeric level (60=CRITICAL … 10=DEBUG, 0=unknown)
    timestamp: Optional[datetime] = None
    fields:    Dict[str, str] = field(default_factory=dict)  # key=value from logfmt / JSON
    is_noise:  bool   = False
    is_continuation: bool = False  # stack trace frame / indented continuation

    @property
    def text(self) -> str:
        return self.raw

    def __str__(self) -> str:
        return self.raw


@dataclass
class FilterStats:
    """Counts for each filter type applied."""
    total_input:          int = 0
    severity_removed:     int = 0
    pattern_removed:      int = 0
    noise_removed:        int = 0
    timestamp_removed:    int = 0
    field_removed:        int = 0
    dedup_removed:        int = 0
    context_added:        int = 0
    total_output:         int = 0

    @property
    def total_removed(self) -> int:
        return (self.severity_removed + self.pattern_removed + self.noise_removed
                + self.timestamp_removed + self.field_removed + self.dedup_removed)

    @property
    def compression_ratio(self) -> float:
        if self.total_input == 0:
            return 0.0
        return round(1.0 - self.total_output / self.total_input, 3)


@dataclass
class GrepResult:
    """
    Output of GrepFilter.filter().

    Attributes:
        filtered_text:      The cleaned log content ready for the Analyzer.
        original_lines:     Line count of the input.
        filtered_lines:     Line count of the output.
        removed_lines:      Lines that were filtered out.
        compression_ratio:  Fraction of input removed (0.0 = nothing removed).
        applied_filters:    Human-readable list of which filters fired.
        stats:              Detailed breakdown per filter type.
        noise_patterns:     Most common noise patterns found (for audit).
        severity_distribution: Count per severity level in the OUTPUT.
        warnings:           Any data-quality warnings (e.g. binary bleed, truncation).
    """
    filtered_text:          str
    original_lines:         int
    filtered_lines:         int
    removed_lines:          int
    compression_ratio:      float
    applied_filters:        List[str]
    stats:                  FilterStats
    noise_patterns:         List[str]
    severity_distribution:  Dict[str, int]
    warnings:               List[str]

    @property
    def is_empty(self) -> bool:
        return not self.filtered_text.strip()

    @property
    def signal_ratio(self) -> float:
        """Fraction of output lines that have a known severity level."""
        if self.filtered_lines == 0:
            return 0.0
        sig = sum(v for k, v in self.severity_distribution.items() if k != "UNKNOWN")
        return round(sig / self.filtered_lines, 3)


@dataclass
class GrepConfig:
    """
    All configuration for a GrepFilter instance.

    Each field is optional — only configured fields are applied.
    """
    # ── Pattern filters ──────────────────────────────────────────────────────
    include_patterns:    List[str] = field(default_factory=list)
    """Keep only lines matching ANY of these regex patterns."""

    exclude_patterns:    List[str] = field(default_factory=list)
    """Remove lines matching ANY of these regex patterns."""

    include_fixed:       List[str] = field(default_factory=list)
    """Keep only lines containing ANY of these fixed strings (faster than regex)."""

    exclude_fixed:       List[str] = field(default_factory=list)
    """Remove lines containing ANY of these fixed strings."""

    case_sensitive:      bool = True
    """Whether pattern matching is case-sensitive."""

    invert_match:        bool = False
    """If True, keep lines that DON'T match include_patterns (like grep -v)."""

    # ── Severity filter ──────────────────────────────────────────────────────
    min_severity:        Optional[str] = None
    """
    Keep only lines at or above this severity.
    Values: DEBUG < INFO < NOTICE < WARNING < ERROR < CRITICAL
    Lines with unknown severity are KEPT (safe default).
    """

    keep_continuations:  bool = True
    """
    If True, keep stack trace frames / indented continuation lines
    even if they don't match the severity filter.
    This ensures tracebacks stay intact.
    """

    # ── Noise filter ─────────────────────────────────────────────────────────
    remove_noise:        bool = False
    """Remove lines matching built-in noise patterns (health checks, heartbeats, etc.)."""

    extra_noise_patterns:List[str] = field(default_factory=list)
    """Additional custom noise patterns (added to the built-in list)."""

    noise_threshold:     float = 0.0
    """
    If >0, remove recurring patterns that appear more than this
    fraction of total lines. E.g. 0.10 removes any pattern repeated
    in more than 10% of lines.
    Useful for log spam that isn't caught by noise_patterns.
    """

    # ── Deduplication ────────────────────────────────────────────────────────
    deduplicate:         bool = False
    """Remove exact duplicate lines (keeps first occurrence)."""

    dedup_window:        int = 0
    """
    If >0, only remove duplicates within a sliding window of this many lines.
    0 means global deduplication across the entire input.
    """

    max_occurrences:     int = 0
    """
    If >0, keep at most this many occurrences of any repeated line.
    E.g. max_occurrences=3 means you see each repeated line at most 3 times.
    """

    # ── Context lines (like grep -A / -B / -C) ───────────────────────────────
    context_before:      int = 0
    """Lines of context to keep BEFORE each matching line (like grep -B N)."""

    context_after:       int = 0
    """Lines of context to keep AFTER each matching line (like grep -A N)."""

    context_separator:   str = "--"
    """Separator printed between non-contiguous context groups (like grep --group-separator)."""

    # ── Timestamp range filter ───────────────────────────────────────────────
    after_time:          Optional[str] = None
    """Keep only lines with timestamps >= this value. ISO 8601 format."""

    before_time:         Optional[str] = None
    """Keep only lines with timestamps <= this value. ISO 8601 format."""

    # ── Field-based filter (for logfmt / JSON logs) ──────────────────────────
    field_filters:       Dict[str, str] = field(default_factory=dict)
    """
    Keep only lines where field matches value.
    E.g. {"service": "api-server", "env": "production"}
    Supports simple regex in the value.
    """

    field_excludes:      Dict[str, str] = field(default_factory=dict)
    """
    Remove lines where field matches value.
    E.g. {"level": "debug"} removes all debug-level logfmt entries.
    """

    # ── Output controls ──────────────────────────────────────────────────────
    max_lines:           int = 0
    """
    If >0, truncate output to this many lines.
    Lines with higher severity are prioritised when truncating.
    """

    max_chars:           int = 0
    """If >0, truncate output to approximately this many characters."""

    strip_ansi:          bool = True
    """Remove ANSI terminal escape codes from output."""

    normalize_whitespace:bool = False
    """Collapse multiple spaces/tabs to single space per line."""

    add_line_numbers:    bool = False
    """Prefix each output line with its original line number."""


# =============================================================================
# Built-in profiles
# =============================================================================

PROFILE_SIGNAL_ONLY = GrepConfig(
    min_severity     = "WARNING",
    keep_continuations= True,
    remove_noise     = True,
    deduplicate      = True,
    max_occurrences  = 5,
    strip_ansi       = True,
)
"""
Keep WARNING and above; remove noise; deduplicate spam.
Good default for most log analysis pipelines.
"""

PROFILE_NO_NOISE = GrepConfig(
    remove_noise     = True,
    noise_threshold  = 0.15,
    deduplicate      = True,
    max_occurrences  = 10,
    strip_ansi       = True,
)
"""
Remove health-check spam, heartbeats, and any pattern that appears
in >15% of lines, but keep all severity levels.
"""

PROFILE_ERRORS_ONLY = GrepConfig(
    min_severity     = "ERROR",
    keep_continuations= True,
    remove_noise     = True,
    context_before   = 3,
    context_after    = 5,
    deduplicate      = True,
    strip_ansi       = True,
)
"""
Errors and above, with 3 lines of context before and 5 after.
Tracebacks are preserved intact. Ideal for error-focused analysis.
"""

PROFILE_SECURITY = GrepConfig(
    include_patterns = _SIGNAL_REGEXES["SECURITY"],
    remove_noise     = True,
    context_before   = 2,
    context_after    = 3,
    strip_ansi       = True,
    case_sensitive   = False,
)
"""
Keep only security-relevant lines (auth, permissions, credentials, TLS).
"""

PROFILE_PERFORMANCE = GrepConfig(
    include_patterns = _SIGNAL_REGEXES["PERFORMANCE"],
    remove_noise     = True,
    context_before   = 1,
    context_after    = 2,
    strip_ansi       = True,
    case_sensitive   = False,
)
"""
Keep only performance-relevant lines (slow queries, timeouts, GC, latency).
"""

PROFILE_FULL_CLEAN = GrepConfig(
    remove_noise     = True,
    noise_threshold  = 0.10,
    deduplicate      = True,
    max_occurrences  = 3,
    strip_ansi       = True,
    normalize_whitespace=False,
)
"""
Maximum noise reduction: remove spam, deduplicate, strip ANSI.
Does NOT filter by severity — all levels are preserved.
"""

_PROFILES: Dict[str, GrepConfig] = {
    "signal_only":  PROFILE_SIGNAL_ONLY,
    "no_noise":     PROFILE_NO_NOISE,
    "errors_only":  PROFILE_ERRORS_ONLY,
    "security":     PROFILE_SECURITY,
    "performance":  PROFILE_PERFORMANCE,
    "full_clean":   PROFILE_FULL_CLEAN,
}


# =============================================================================
# Core engine — GrepFilter
# =============================================================================

_ANSI_RE = re.compile(r"\x1b\[[0-9;]*[mABCDEFGHJKLMSTfhilmnsu]")
_LOGFMT_RE = re.compile(r'(\w[\w.\-]*)\s*=\s*(?:"([^"]*?)"|(\S+))')
_JSON_OBJECT_RE = re.compile(r'^\s*\{.*\}\s*$')


class GrepFilter:
    """
    Configurable grep-style log filter.

    Instantiate once, call `.filter(text)` repeatedly.
    All regex patterns are compiled at __init__ time.

    Example:
        gf     = GrepFilter(PROFILE_ERRORS_ONLY)
        result = gf.filter(raw_log_text)
        print(result.filtered_text)
        print(f"Removed {result.removed_lines} of {result.original_lines} lines")
    """

    def __init__(self, config: GrepConfig):
        self.config = config
        self._compile_patterns()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def filter(self, text: str) -> GrepResult:
        """
        Apply all configured filters to *text* and return a GrepResult.

        Filters are applied in this order:
          1. Strip ANSI codes (if configured)
          2. Parse lines into LogLine objects (severity, timestamp, fields)
          3. Mark continuation lines (stack frames, indented lines)
          4. Noise filter
          5. Severity filter
          6. Timestamp range filter
          7. Field-based filter
          8. Include / exclude pattern filter
          9. Deduplication + max_occurrences
         10. Context window expansion
         11. Output size limits
         12. Format output
        """
        if not text:
            return self._empty_result("empty input")

        stats    = FilterStats()
        warnings: List[str] = []

        # ── Sanitize ──────────────────────────────────────────────────────────
        if self.config.strip_ansi:
            text = _ANSI_RE.sub("", text)
        if "\r\n" in text:
            text = text.replace("\r\n", "\n")

        # ── Parse into LogLine objects ────────────────────────────────────────
        raw_lines = text.splitlines()
        stats.total_input = len(raw_lines)

        if stats.total_input == 0:
            return self._empty_result("no lines after sanitization")

        # Safety: warn on suspiciously long lines (binary bleed indicator)
        long_lines = sum(1 for l in raw_lines if len(l) > 10_000)
        if long_lines:
            warnings.append(f"{long_lines} lines exceed 10,000 chars — possible binary bleed")

        parsed: List[LogLine] = [self._parse_line(i + 1, l) for i, l in enumerate(raw_lines)]
        self._mark_continuations(parsed)

        applied: List[str] = []

        # ── 4. Noise filter ───────────────────────────────────────────────────
        if self.config.remove_noise or self._noise_patterns:
            parsed, n = self._apply_noise_filter(parsed)
            stats.noise_removed = n
            if n:
                applied.append(f"noise_filter({n} removed)")

        # ── Adaptive noise filter: high-frequency pattern removal ─────────────
        if self.config.noise_threshold > 0:
            parsed, n = self._apply_frequency_filter(parsed, stats.total_input)
            stats.noise_removed += n
            if n:
                applied.append(f"frequency_filter({n} removed)")

        # ── 5. Severity filter ────────────────────────────────────────────────
        if self.config.min_severity and self._min_level > 0:
            parsed, n = self._apply_severity_filter(parsed)
            stats.severity_removed = n
            if n:
                applied.append(f"severity_filter(min={self.config.min_severity}, {n} removed)")

        # ── 6. Timestamp range filter ─────────────────────────────────────────
        if self._after_time or self._before_time:
            parsed, n = self._apply_timestamp_filter(parsed)
            stats.timestamp_removed = n
            if n:
                applied.append(f"timestamp_filter({n} removed)")

        # ── 7. Field-based filter ─────────────────────────────────────────────
        if self.config.field_filters or self.config.field_excludes:
            parsed, n = self._apply_field_filter(parsed)
            stats.field_removed = n
            if n:
                applied.append(f"field_filter({n} removed)")

        # ── 8. Include / exclude pattern filter ───────────────────────────────
        has_include = bool(
            self._include_compiled or self.config.include_fixed
        )
        has_exclude = bool(
            self._exclude_compiled or self.config.exclude_fixed
        )
        if has_include or has_exclude:
            parsed, n = self._apply_pattern_filter(parsed)
            stats.pattern_removed = n
            if n or has_include:
                applied.append(f"pattern_filter({n} removed)")

        # ── 9. Deduplication ──────────────────────────────────────────────────
        if self.config.deduplicate or self.config.max_occurrences > 0:
            parsed, n = self._apply_dedup(parsed)
            stats.dedup_removed = n
            if n:
                applied.append(f"dedup({n} removed)")

        # ── 10. Context window ────────────────────────────────────────────────
        if self.config.context_before > 0 or self.config.context_after > 0:
            parsed, added = self._apply_context(parsed, raw_lines)
            stats.context_added = added
            if added:
                applied.append(f"context(+{added} context lines)")

        # ── 11. Output size limits ────────────────────────────────────────────
        if self.config.max_lines > 0 and len(parsed) > self.config.max_lines:
            parsed = self._trim_by_severity(parsed, self.config.max_lines)
            applied.append(f"max_lines({self.config.max_lines})")

        # ── 12. Assemble output ───────────────────────────────────────────────
        noise_patterns = self._find_top_noise_patterns(raw_lines, parsed)
        severity_dist  = self._severity_distribution(parsed)

        lines_out = self._format_output(parsed)
        output    = "\n".join(lines_out)

        if self.config.max_chars > 0 and len(output) > self.config.max_chars:
            output = output[:self.config.max_chars]
            output = output[:output.rfind("\n")] if "\n" in output else output
            applied.append(f"max_chars({self.config.max_chars})")
            warnings.append("Output truncated to max_chars limit")

        stats.total_output = output.count("\n") + 1 if output.strip() else 0

        return GrepResult(
            filtered_text        = output,
            original_lines       = stats.total_input,
            filtered_lines       = stats.total_output,
            removed_lines        = stats.total_removed,
            compression_ratio    = stats.compression_ratio,
            applied_filters      = applied,
            stats                = stats,
            noise_patterns       = noise_patterns,
            severity_distribution= severity_dist,
            warnings             = warnings,
        )

    # ------------------------------------------------------------------
    # Class method: build from profile name
    # ------------------------------------------------------------------

    @classmethod
    def from_profile(cls, profile_name: str) -> "GrepFilter":
        """
        Build a GrepFilter from a named profile.

        profile_name: one of 'signal_only', 'no_noise', 'errors_only',
                              'security', 'performance', 'full_clean'
        """
        name = profile_name.lower().replace("-","_").replace(" ","_")
        if name not in _PROFILES:
            raise ValueError(
                f"Unknown profile '{profile_name}'. "
                f"Available: {', '.join(_PROFILES)}"
            )
        return cls(_PROFILES[name])

    @classmethod
    def from_profiles(cls, *profile_names: str) -> "GrepFilter":
        """
        Merge multiple profiles into one GrepFilter.
        Later profiles override earlier ones for scalar fields;
        list fields (patterns) are merged.
        """
        merged = GrepConfig()
        for name in profile_names:
            p = _PROFILES[name.lower().replace("-","_").replace(" ","_")]
            for f in merged.__dataclass_fields__:
                val = getattr(p, f)
                if isinstance(val, list):
                    getattr(merged, f).extend(val)
                elif val is not None and val is not False and val != 0:
                    setattr(merged, f, val)
        return cls(merged)

    # ------------------------------------------------------------------
    # Pattern compilation (called once at __init__)
    # ------------------------------------------------------------------

    def _compile_patterns(self):
        flags = 0 if self.config.case_sensitive else re.IGNORECASE

        self._include_compiled: List[Pattern] = [
            re.compile(p, flags) for p in self.config.include_patterns
        ]
        self._exclude_compiled: List[Pattern] = [
            re.compile(p, flags) for p in self.config.exclude_patterns
        ]

        # Noise patterns: built-in + extra
        noise_src = list(_NOISE_REGEXES) + list(self.config.extra_noise_patterns)
        self._noise_patterns: List[Pattern] = [
            re.compile(p, re.IGNORECASE) for p in noise_src
        ] if (self.config.remove_noise or self.config.extra_noise_patterns) else []

        # Severity min level
        self._min_level = _LEVEL_BY_NAME.get(
            (self.config.min_severity or "").upper(), 0
        )

        # Timestamp bounds
        self._after_time:  Optional[datetime] = self._parse_datetime(self.config.after_time)
        self._before_time: Optional[datetime] = self._parse_datetime(self.config.before_time)

        # Precompile all timestamp patterns
        self._ts_patterns: List[Tuple[Pattern, str]] = [
            (re.compile(p), fmt) for p, fmt in _TIMESTAMP_PATTERNS
        ]

        # Severity keyword regex (fast one-pass scan per line)
        all_kws = [kw for _, _, kws in _SEVERITY_MAP for kw in kws]
        self._sev_re = re.compile(
            r'\b(' + '|'.join(re.escape(k) for k in all_kws) + r')\b',
            re.IGNORECASE
        )

        # Field filters (compiled)
        self._field_include: List[Tuple[str, Pattern]] = [
            (k, re.compile(v, re.IGNORECASE)) for k, v in self.config.field_filters.items()
        ]
        self._field_exclude: List[Tuple[str, Pattern]] = [
            (k, re.compile(v, re.IGNORECASE)) for k, v in self.config.field_excludes.items()
        ]

    # ------------------------------------------------------------------
    # Line parser
    # ------------------------------------------------------------------

    def _parse_line(self, number: int, raw: str) -> LogLine:
        line = LogLine(number=number, raw=raw)

        # Severity detection
        m = self._sev_re.search(raw)
        if m:
            kw = m.group(1).upper()
            line.level_num = _LEVEL_BY_NAME.get(kw, 0)
            # Map to canonical name
            for lvl, name, kws in _SEVERITY_MAP:
                if lvl == line.level_num:
                    line.severity = name
                    break

        # Timestamp detection
        line.timestamp = self._extract_timestamp(raw)

        # Field extraction (logfmt and simple JSON)
        line.fields = self._extract_fields(raw)

        # Normalize whitespace if requested
        if self.config.normalize_whitespace:
            line.raw = re.sub(r'[ \t]+', ' ', raw).rstrip()

        return line

    def _mark_continuations(self, lines: List[LogLine]):
        """
        Mark lines that are continuation lines (stack trace frames,
        indented continuations) so severity filters don't drop them.
        """
        for i, line in enumerate(lines):
            raw = line.raw
            if not raw:
                continue
            # Indented line following a non-empty line
            if raw[:1] in (' ', '\t') and i > 0:
                line.is_continuation = True
                continue
            # Python stack frame
            if raw.lstrip().startswith('File "') and '", line' in raw:
                line.is_continuation = True
                continue
            # Java / JS stack frame
            if re.match(r'\s*at\s+[\w.$]+\(', raw):
                line.is_continuation = True
                continue
            # "Caused by:" chained exception
            if raw.lstrip().startswith("Caused by:"):
                line.is_continuation = True
                continue
            # Go goroutine continuation
            if re.match(r'\s+\S+\.go:\d+', raw):
                line.is_continuation = True
                continue

    # ------------------------------------------------------------------
    # Timestamp extraction
    # ------------------------------------------------------------------

    def _extract_timestamp(self, text: str) -> Optional[datetime]:
        for ts_re, fmt in self._ts_patterns:
            m = ts_re.search(text)
            if not m:
                continue
            ts_str = m.group(0)
            if fmt == "epoch":
                try:
                    return datetime.fromtimestamp(int(ts_str), tz=timezone.utc)
                except (ValueError, OSError):
                    continue
            try:
                # Strip timezone for parsing (handle Z suffix)
                ts_clean = ts_str.replace("Z","").replace("T"," ")[:19]
                return datetime.strptime(ts_clean, fmt.replace("T"," ").replace("Z",""))
            except ValueError:
                continue
        return None

    @staticmethod
    def _parse_datetime(value: Optional[str]) -> Optional[datetime]:
        if not value:
            return None
        for fmt in ("%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
            try:
                return datetime.strptime(value[:19], fmt)
            except ValueError:
                continue
        return None

    # ------------------------------------------------------------------
    # Field extraction
    # ------------------------------------------------------------------

    def _extract_fields(self, text: str) -> Dict[str, str]:
        fields: Dict[str, str] = {}

        # logfmt: key=value or key="value with spaces"
        for m in _LOGFMT_RE.finditer(text):
            key = m.group(1)
            val = m.group(2) if m.group(2) is not None else m.group(3)
            fields[key.lower()] = val

        # Simple JSON: try to extract common fields from JSON log lines
        if _JSON_OBJECT_RE.match(text):
            import json
            try:
                obj = json.loads(text)
                if isinstance(obj, dict):
                    for k in ("level","severity","service","component","msg","message",
                              "error","host","hostname","ts","timestamp","time"):
                        if k in obj:
                            fields[k] = str(obj[k])
            except (ValueError, TypeError):
                pass

        return fields

    # ------------------------------------------------------------------
    # Filter implementations
    # ------------------------------------------------------------------

    def _apply_noise_filter(self, lines: List[LogLine]) -> Tuple[List[LogLine], int]:
        removed = 0
        result: List[LogLine] = []
        for line in lines:
            if line.is_continuation:
                result.append(line)
                continue
            is_noise = any(pat.search(line.raw) for pat in self._noise_patterns)
            if is_noise:
                line.is_noise = True
                removed += 1
            else:
                result.append(line)
        return result, removed

    def _apply_frequency_filter(
        self, lines: List[LogLine], total_input: int
    ) -> Tuple[List[LogLine], int]:
        """Remove lines whose exact text exceeds noise_threshold fraction."""
        threshold = self.config.noise_threshold
        if threshold <= 0 or total_input == 0:
            return lines, 0

        counts = Counter(l.raw.strip() for l in lines if not l.is_continuation)
        spam_lines: Set[str] = {
            text for text, count in counts.items()
            if count / total_input > threshold and text
        }
        if not spam_lines:
            return lines, 0

        result   = [l for l in lines if l.is_continuation or l.raw.strip() not in spam_lines]
        removed  = len(lines) - len(result)
        return result, removed

    def _apply_severity_filter(self, lines: List[LogLine]) -> Tuple[List[LogLine], int]:
        min_lvl = self._min_level
        keep_cont = self.config.keep_continuations
        result  = []
        removed = 0
        for line in lines:
            if keep_cont and line.is_continuation:
                result.append(line)
                continue
            # Lines with unknown severity (0) are KEPT — safe default
            if line.level_num == 0 or line.level_num >= min_lvl:
                result.append(line)
            else:
                removed += 1
        return result, removed

    def _apply_timestamp_filter(self, lines: List[LogLine]) -> Tuple[List[LogLine], int]:
        after  = self._after_time
        before = self._before_time
        result  = []
        removed = 0
        for line in lines:
            ts = line.timestamp
            # No timestamp → keep (can't filter what we can't parse)
            if ts is None:
                result.append(line)
                continue
            if after  and ts < after:
                removed += 1
                continue
            if before and ts > before:
                removed += 1
                continue
            result.append(line)
        return result, removed

    def _apply_field_filter(self, lines: List[LogLine]) -> Tuple[List[LogLine], int]:
        incl = self._field_include
        excl = self._field_exclude
        result  = []
        removed = 0
        for line in lines:
            fields = line.fields

            # Field exclude
            excluded = False
            for key, pat in excl:
                val = fields.get(key)
                if val is not None and pat.search(val):
                    excluded = True
                    break
            if excluded:
                removed += 1
                continue

            # Field include: if filters defined, line must match ALL of them
            included = True
            if incl and fields:
                for key, pat in incl:
                    val = fields.get(key)
                    if val is None or not pat.search(val):
                        included = False
                        break
            elif incl and not fields:
                # Structured filter on unstructured line → keep (can't evaluate)
                included = True

            if included:
                result.append(line)
            else:
                removed += 1
        return result, removed

    def _apply_pattern_filter(self, lines: List[LogLine]) -> Tuple[List[LogLine], int]:
        incl_re  = self._include_compiled
        excl_re  = self._exclude_compiled
        incl_fix = self.config.include_fixed
        excl_fix = self.config.exclude_fixed
        invert   = self.config.invert_match
        ci       = not self.config.case_sensitive
        result   = []
        removed  = 0

        for line in lines:
            # Continuations: keep if parent would be kept (handled via context)
            # Here we just always keep them to not break tracebacks
            if line.is_continuation:
                result.append(line)
                continue

            text = line.raw
            ctext = text.lower() if ci else text

            # Exclude patterns: remove if ANY matches
            if excl_re and any(p.search(text) for p in excl_re):
                removed += 1
                continue
            if excl_fix and any(
                (f.lower() in ctext if ci else f in text) for f in excl_fix
            ):
                removed += 1
                continue

            # Include patterns: keep only if ANY matches
            if incl_re or incl_fix:
                matches = (
                    (incl_re and any(p.search(text) for p in incl_re))
                    or (incl_fix and any(
                        (f.lower() in ctext if ci else f in text) for f in incl_fix
                    ))
                )
                if invert:
                    matches = not matches
                if matches:
                    result.append(line)
                else:
                    removed += 1
            else:
                # No include patterns — invert applies to everything
                if invert:
                    removed += 1
                else:
                    result.append(line)

        return result, removed

    def _apply_dedup(self, lines: List[LogLine]) -> Tuple[List[LogLine], int]:
        window    = self.config.dedup_window
        max_occ   = self.config.max_occurrences
        do_dedup  = self.config.deduplicate

        seen:     Dict[str, int]  = defaultdict(int)   # text → total count
        recent:   List[str]       = []                  # sliding window
        result:   List[LogLine]   = []
        removed   = 0

        for line in lines:
            if line.is_continuation:
                result.append(line)
                continue

            key = line.raw.strip()
            if not key:
                result.append(line)
                continue

            seen[key] += 1
            count = seen[key]

            # Sliding window: check recent N lines
            if window > 0:
                in_window = key in recent[-window:]
                if do_dedup and in_window:
                    removed += 1
                    continue
                if max_occ > 0 and count > max_occ:
                    removed += 1
                    continue
            else:
                if do_dedup and count > 1:
                    removed += 1
                    continue
                if max_occ > 0 and count > max_occ:
                    removed += 1
                    continue

            recent.append(key)
            result.append(line)

        return result, removed

    def _apply_context(
        self, lines: List[LogLine], all_raw: List[str]
    ) -> Tuple[List[LogLine], int]:
        """
        Expand kept lines to include N lines before/after from the original.
        Lines that were removed by earlier filters may be restored as context.
        """
        before = self.config.context_before
        after  = self.config.context_after
        if before == 0 and after == 0:
            return lines, 0

        # Build set of kept line numbers
        kept_nums: Set[int] = {l.number for l in lines}

        # Build context line numbers to add
        context_nums: Set[int] = set()
        max_num = len(all_raw)
        for n in kept_nums:
            for b in range(max(1, n - before), n):
                if b not in kept_nums:
                    context_nums.add(b)
            for a in range(n + 1, min(max_num, n + after) + 1):
                if a not in kept_nums:
                    context_nums.add(a)

        if not context_nums:
            return lines, 0

        # Build context LogLine objects
        ctx_lines = [
            LogLine(number=n, raw=all_raw[n-1], is_continuation=True)
            for n in context_nums
        ]

        # Merge and re-sort by line number
        merged = sorted(lines + ctx_lines, key=lambda l: l.number)
        added  = len(ctx_lines)
        return merged, added

    # ------------------------------------------------------------------
    # Output helpers
    # ------------------------------------------------------------------

    def _trim_by_severity(self, lines: List[LogLine], max_lines: int) -> List[LogLine]:
        """Trim to max_lines, keeping highest-severity lines preferentially."""
        if len(lines) <= max_lines:
            return lines
        # Sort by severity descending, then by line number
        sorted_lines = sorted(lines, key=lambda l: (-l.level_num, l.number))
        keep_nums    = {l.number for l in sorted_lines[:max_lines]}
        return sorted([l for l in lines if l.number in keep_nums], key=lambda l: l.number)

    def _format_output(self, lines: List[LogLine]) -> List[str]:
        add_nums = self.config.add_line_numbers
        sep      = self.config.context_separator
        result:  List[str] = []
        prev_num = -1

        for line in lines:
            # Insert separator for non-contiguous groups (like grep --group-separator)
            if (sep and prev_num >= 0 and line.number > prev_num + 1
                    and not line.is_continuation):
                result.append(sep)

            text = f"{line.number:>6}\t{line.raw}" if add_nums else line.raw
            result.append(text)
            prev_num = line.number

        return result

    def _severity_distribution(self, lines: List[LogLine]) -> Dict[str, int]:
        dist: Dict[str, int] = defaultdict(int)
        for line in lines:
            dist[line.severity or "UNKNOWN"] += 1
        return dict(dist)

    def _find_top_noise_patterns(
        self, raw_lines: List[str], kept: List[LogLine]
    ) -> List[str]:
        """Return the top 5 patterns that were removed as noise."""
        kept_nums = {l.number for l in kept}
        removed   = [raw_lines[i] for i in range(len(raw_lines)) if (i+1) not in kept_nums]
        if not removed:
            return []
        counter = Counter(l.strip() for l in removed if l.strip())
        return [f"'{text[:80]}' (×{cnt})" for text, cnt in counter.most_common(5)]

    @staticmethod
    def _empty_result(reason: str) -> GrepResult:
        return GrepResult(
            filtered_text="", original_lines=0, filtered_lines=0,
            removed_lines=0, compression_ratio=0.0,
            applied_filters=[f"skipped: {reason}"],
            stats=FilterStats(), noise_patterns=[],
            severity_distribution={}, warnings=[reason],
        )


# =============================================================================
# Convenience functions (for simple one-shot use in agent.py)
# =============================================================================

def filter_logs(text: str, profile: str = "no_noise") -> GrepResult:
    """
    One-shot log filtering with a named profile.

    Args:
        text:    Raw log content.
        profile: Profile name — one of: signal_only, no_noise, errors_only,
                 security, performance, full_clean.

    Returns:
        GrepResult with .filtered_text ready for the Analyzer.

    Example:
        from agents.preprocessor.grep import filter_logs
        result = filter_logs(raw_logs, profile="errors_only")
        clean  = result.filtered_text
    """
    return GrepFilter.from_profile(profile).filter(text)


def filter_by_severity(text: str, min_severity: str = "WARNING") -> GrepResult:
    """
    Filter logs to keep only lines at or above *min_severity*.
    Stack traces are always preserved.

    Args:
        text:         Raw log content.
        min_severity: One of DEBUG, INFO, NOTICE, WARNING, ERROR, CRITICAL.
    """
    cfg = GrepConfig(
        min_severity    = min_severity,
        keep_continuations = True,
        strip_ansi      = True,
    )
    return GrepFilter(cfg).filter(text)


def filter_by_pattern(
    text: str,
    include: Optional[List[str]] = None,
    exclude: Optional[List[str]] = None,
    context_lines: int = 0,
    case_sensitive: bool = True,
) -> GrepResult:
    """
    Filter logs by include/exclude regex patterns.

    Args:
        text:           Raw log content.
        include:        Keep only lines matching ANY of these patterns.
        exclude:        Remove lines matching ANY of these patterns.
        context_lines:  Lines of context to keep around matching lines.
        case_sensitive: Whether patterns are case-sensitive.
    """
    cfg = GrepConfig(
        include_patterns = include or [],
        exclude_patterns = exclude or [],
        context_before   = context_lines,
        context_after    = context_lines,
        case_sensitive   = case_sensitive,
        strip_ansi       = True,
    )
    return GrepFilter(cfg).filter(text)


def remove_noise(text: str, extra_patterns: Optional[List[str]] = None) -> GrepResult:
    """
    Remove health-check spam, heartbeats, and other noise.
    All severity levels are preserved.

    Args:
        text:             Raw log content.
        extra_patterns:   Additional regex patterns to treat as noise.
    """
    cfg = GrepConfig(
        remove_noise          = True,
        extra_noise_patterns  = extra_patterns or [],
        noise_threshold       = 0.15,
        deduplicate           = True,
        max_occurrences       = 5,
        strip_ansi            = True,
    )
    return GrepFilter(cfg).filter(text)


def smart_filter(text: str, hint: str = "auto") -> GrepResult:
    """
    Automatically choose the best filter profile based on content.

    Args:
        text: Raw log content.
        hint: "auto" (detect), "error", "security", "performance", or "clean".
    """
    if hint != "auto":
        profile_map = {
            "error": "errors_only", "security": "security",
            "performance": "performance", "clean": "full_clean",
        }
        return filter_logs(text, profile_map.get(hint, "no_noise"))

    # Auto-detect from content
    sample = text[:3000].lower()
    if any(w in sample for w in ["traceback", "exception", "fatal", "stack trace"]):
        return filter_logs(text, "errors_only")
    if any(w in sample for w in ["auth", "permission", "forbidden", "unauthorized", "ssl"]):
        return filter_logs(text, "security")
    if any(w in sample for w in ["slow query", "timeout", "latency", "duration", "elapsed"]):
        return filter_logs(text, "performance")
    return filter_logs(text, "no_noise")
