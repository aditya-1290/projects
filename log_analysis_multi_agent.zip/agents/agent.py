"""ADK Entry Point — Imports the root agent from the modular ADK package."""
from agents.adk.root_agent import root_agent
