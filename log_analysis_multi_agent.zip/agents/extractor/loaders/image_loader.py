"""
Image Loader - Extracts text from images using OCR.

Strategy (tried in order):
  1. Provided ocr_model (e.g. DeepSeek OCR)
  2. pytesseract with image pre-processing (grayscale + contrast boost)
  3. Mock fallback (for CI / environments without tesseract)
"""

import os
import base64
from typing import Optional

SUPPORTED_FORMATS = {".png", ".jpg", ".jpeg", ".bmp", ".tiff", ".tif", ".gif", ".webp"}


class ImageLoader:
    """
    Extracts text from image files.

    Features:
    - Image pre-processing (grayscale, contrast) for better OCR accuracy
    - Graceful degradation if pytesseract / Pillow isn't installed
    - Optional external ocr_model injection
    """

    def __init__(self, dpi: int = 300, lang: str = "eng"):
        self.dpi = dpi
        self.lang = lang  # tesseract language pack

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def extract(self, image_path: str, ocr_model=None) -> str:
        """
        Extract text from an image file.

        Args:
            image_path: Path to the image.
            ocr_model:  Optional external OCR model with .extract_text(path) method.

        Returns:
            Extracted text as a string.

        Raises:
            FileNotFoundError: if the image doesn't exist.
            ValueError: if format is unsupported or no text could be extracted.
        """
        image_path = os.path.abspath(image_path)

        if not os.path.exists(image_path):
            raise FileNotFoundError(f"Image not found: {image_path}")

        ext = os.path.splitext(image_path)[1].lower()
        if ext not in SUPPORTED_FORMATS:
            raise ValueError(
                f"Unsupported image format '{ext}'. "
                f"Supported: {', '.join(sorted(SUPPORTED_FORMATS))}"
            )

        text = await self._try_all_methods(image_path, ocr_model)

        if not text or not text.strip():
            raise ValueError(
                f"No text could be extracted from '{os.path.basename(image_path)}'. "
                "The image may be blank, purely graphical, or too low-resolution."
            )

        return text.strip()

    # ------------------------------------------------------------------
    # Internal: OCR strategy chain
    # ------------------------------------------------------------------

    async def _try_all_methods(self, path: str, ocr_model) -> str:
        # 1. External model (highest quality — e.g. DeepSeek)
        if ocr_model:
            try:
                result = await ocr_model.extract_text(path)
                if result and result.strip():
                    return result
            except Exception as exc:
                print(f"[ImageLoader] External OCR model failed: {exc}")

        # 2. pytesseract with pre-processing
        text = await self._tesseract_ocr(path)
        if text and text.strip():
            return text

        # 3. Mock OCR — call its extract_text if available
        if ocr_model:
            try:
                result = await ocr_model.extract_text(path)
                if result and result.strip():
                    return result
            except Exception:
                pass

        # 4. Last resort fallback
        print(f"[ImageLoader] Warning: falling back to mock OCR for '{os.path.basename(path)}'")
        return f"[MOCK OCR] Placeholder text for: {os.path.basename(path)}\nInstall transformers + torch for real OCR."
    

    async def _tesseract_ocr(self, path: str) -> str:
        """Run pytesseract with image pre-processing."""
        try:
            import pytesseract
            from PIL import Image, ImageEnhance, ImageFilter

            img = Image.open(path)

            # Pre-processing pipeline
            img = self._preprocess(img)

            config = f"--dpi {self.dpi} --oem 3 --psm 6"
            text = pytesseract.image_to_string(img, lang=self.lang, config=config)
            return text

        except ImportError as exc:
            missing = str(exc).split("'")[1] if "'" in str(exc) else str(exc)
            print(f"[ImageLoader] pytesseract/Pillow not installed ({missing}); skipping.")
            return ""
        except Exception as exc:
            print(f"[ImageLoader] pytesseract failed: {exc}")
            return ""

    # ------------------------------------------------------------------
    # Image pre-processing
    # ------------------------------------------------------------------

    def _preprocess(self, img):
        """Convert to grayscale and boost contrast for better OCR."""
        try:
            from PIL import Image, ImageEnhance, ImageFilter

            # Convert to RGB first (handles palette / RGBA images)
            if img.mode not in ("RGB", "L"):
                img = img.convert("RGB")

            # Grayscale
            img = img.convert("L")

            # Upscale small images so tesseract has enough resolution
            w, h = img.size
            if max(w, h) < 1000:
                scale = 1000 / max(w, h)
                img = img.resize((int(w * scale), int(h * scale)), Image.LANCZOS)

            # Contrast enhancement
            enhancer = ImageEnhance.Contrast(img)
            img = enhancer.enhance(2.0)

            # Slight sharpen
            img = img.filter(ImageFilter.SHARPEN)

            return img
        except Exception:
            return img  # Return original if pre-processing fails

    # ------------------------------------------------------------------
    # Utility
    # ------------------------------------------------------------------

    def is_supported(self, path: str) -> bool:
        ext = os.path.splitext(path)[1].lower()
        return ext in SUPPORTED_FORMATS

    async def to_base64(self, image_path: str) -> str:
        """Return a base64-encoded version of the image (for API calls)."""
        with open(image_path, "rb") as f:
            return base64.b64encode(f.read()).decode("utf-8")
