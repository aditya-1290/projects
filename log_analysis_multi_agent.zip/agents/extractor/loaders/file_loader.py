"""
File Loader - Handles text-based log files.

Supports: .log, .txt, .out, .err, .json, .csv, .xml, .tsv, .ndjson, .jsonl, .gz
"""

import os
import gzip
import bz2
import lzma
from typing import Optional

SUPPORTED_EXTENSIONS = {
    ".log", ".txt", ".out", ".err",
    ".json", ".jsonl", ".ndjson",
    ".csv", ".tsv",
    ".xml",
    ".gz", ".bz2", ".xz",
    ".syslog", ".access", ".error",
}

MAX_FILE_SIZE = 100 * 1024 * 1024   # 100 MB hard limit
CHUNK_SIZE    = 10 * 1024 * 1024    # 10 MB — read in chunks for large files

ENCODINGS = ["utf-8", "utf-8-sig", "latin-1", "cp1252", "iso-8859-1"]


class FileLoader:
    """
    Loads text-based log files from disk.

    Features:
    - Auto-detects encoding (UTF-8, Latin-1, CP1252, …)
    - Transparent decompression: .gz, .bz2, .xz
    - Large-file safety: refuses files >100 MB
    - Returns clean str content ready for parsers
    """

    def __init__(
        self,
        max_file_size: int = MAX_FILE_SIZE,
        supported_extensions: Optional[set] = None,
    ):
        self.max_file_size = max_file_size
        self.supported_extensions = supported_extensions or SUPPORTED_EXTENSIONS

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def load(self, path: str) -> str:
        """
        Read a file and return its text content.

        Args:
            path: Absolute or relative path to the file.

        Returns:
            The file's text content as a single string.

        Raises:
            FileNotFoundError: if the path doesn't exist.
            IsADirectoryError: if the path points to a directory.
            ValueError: if the file is empty, too large, or undecodable.
        """
        path = os.path.abspath(path)

        if not os.path.exists(path):
            raise FileNotFoundError(f"File not found: {path}")
        if os.path.isdir(path):
            raise IsADirectoryError(f"Path is a directory, not a file: {path}")

        size = os.path.getsize(path)
        if size > self.max_file_size:
            mb = size / (1024 * 1024)
            limit = self.max_file_size / (1024 * 1024)
            raise ValueError(
                f"File too large: {mb:.1f} MB (limit: {limit:.0f} MB). "
                "Consider splitting or truncating the file first."
            )

        ext = os.path.splitext(path)[1].lower()
        if ext not in self.supported_extensions:
            # Warn but still try — operator may have dropped the extension
            print(f"[FileLoader] Warning: unrecognised extension '{ext}', attempting to read anyway.")

        content = self._read_bytes(path, ext)
        text = self._decode(content, path)

        if not text.strip():
            raise ValueError(f"File is empty or contains only whitespace: {path}")

        return text

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _read_bytes(self, path: str, ext: str) -> bytes:
        """Read raw bytes, transparently decompressing if needed."""
        if ext == ".gz":
            with gzip.open(path, "rb") as f:
                return f.read()
        if ext == ".bz2":
            with bz2.open(path, "rb") as f:
                return f.read()
        if ext == ".xz":
            with lzma.open(path, "rb") as f:
                return f.read()

        # Plain file — read in one shot (size already checked above)
        with open(path, "rb") as f:
            return f.read()

    def _decode(self, raw: bytes, path: str) -> str:
        """Try a cascade of encodings; raise if none work."""
        for enc in ENCODINGS:
            try:
                return raw.decode(enc)
            except (UnicodeDecodeError, LookupError):
                continue
        raise ValueError(
            f"Cannot decode file '{os.path.basename(path)}' with any of "
            f"{ENCODINGS}. It may be a binary file."
        )

    # ------------------------------------------------------------------
    # Convenience helpers (used by ExtractorAgent)
    # ------------------------------------------------------------------

    def is_supported(self, path: str) -> bool:
        ext = os.path.splitext(path)[1].lower()
        return ext in self.supported_extensions

    def estimate_lines(self, path: str) -> int:
        """Fast line count without loading the full file."""
        try:
            count = 0
            with open(path, "rb") as f:
                for chunk in iter(lambda: f.read(CHUNK_SIZE), b""):
                    count += chunk.count(b"\n")
            return count
        except OSError:
            return -1
