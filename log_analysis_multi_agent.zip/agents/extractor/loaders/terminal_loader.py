"""
Terminal Loader - Captures terminal command output safely.

Security:
- Blocks a configurable set of dangerous commands
- Hard timeout (default 30s)
- Output capped at 1 MB
"""

import asyncio
import shlex
from typing import Optional, List

DANGEROUS_PATTERNS: List[str] = [
    "rm ", "rm\t",        # file deletion
    "sudo",               # privilege escalation
    "chmod", "chown",     # permission changes
    "dd ",                # disk destroyer
    "mkfs",               # format filesystem
    "> /dev/",            # write to devices
    ":(){ :|:& };:",      # fork bomb
    "wget ", "curl ",     # network fetch (configurable)
    "nc ", "ncat ",       # netcat
    "python -c", "perl -e", "ruby -e",  # inline interpreters
]

MAX_OUTPUT_BYTES = 1 * 1024 * 1024   # 1 MB
DEFAULT_TIMEOUT  = 30                  # seconds


class TerminalLoader:
    """
    Captures output from shell commands safely.

    Features:
    - Configurable dangerous-command blocklist
    - Hard timeout with process kill on expiry
    - Separate stdout / stderr capture
    - Output size cap with truncation notice
    """

    def __init__(
        self,
        timeout: int = DEFAULT_TIMEOUT,
        max_output_bytes: int = MAX_OUTPUT_BYTES,
        extra_blocked: Optional[List[str]] = None,
        allow_network: bool = False,
    ):
        self.timeout = timeout
        self.max_output_bytes = max_output_bytes
        self.blocked = list(DANGEROUS_PATTERNS)
        if not allow_network:
            self.blocked += ["wget ", "curl "]
        if extra_blocked:
            self.blocked += extra_blocked

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def capture(self, command: str, timeout: Optional[int] = None) -> str:
        """
        Run *command* in a shell and return its combined output.

        Args:
            command: The shell command to execute.
            timeout: Per-call override for the timeout (seconds).

        Returns:
            Combined stdout + stderr as a string.
            On block / error / timeout, returns a descriptive [TAG] message.
        """
        command = command.strip()
        if not command:
            return "[ERROR] Empty command"

        blocked_by = self._check_blocked(command)
        if blocked_by:
            return (
                f"[BLOCKED] Command refused for safety reasons "
                f"(matched pattern: '{blocked_by}'): {command}"
            )

        return await self._run(command, timeout or self.timeout)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _check_blocked(self, command: str) -> Optional[str]:
        lower = command.lower()
        for pattern in self.blocked:
            if pattern.lower() in lower:
                return pattern
        return None

    async def _run(self, command: str, timeout: int) -> str:
        try:
            proc = await asyncio.create_subprocess_shell(
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )

            try:
                stdout_bytes, stderr_bytes = await asyncio.wait_for(
                    proc.communicate(), timeout=timeout
                )
            except asyncio.TimeoutError:
                try:
                    proc.kill()
                    await proc.wait()
                except ProcessLookupError:
                    pass
                return (
                    f"[TIMEOUT] Command exceeded {timeout}s limit and was killed: {command}"
                )

            parts = []
            if stdout_bytes:
                parts.append(stdout_bytes.decode("utf-8", errors="replace"))
            if stderr_bytes:
                decoded = stderr_bytes.decode("utf-8", errors="replace").strip()
                if decoded:
                    parts.append(f"\n[STDERR]\n{decoded}")

            output = "".join(parts)

            if len(output.encode("utf-8")) > self.max_output_bytes:
                output = output[: self.max_output_bytes] + "\n[OUTPUT TRUNCATED — exceeded 1 MB]"

            return output.strip() or f"[NO OUTPUT] Command produced no output: {command}"

        except FileNotFoundError:
            return f"[ERROR] Command not found: {command.split()[0]}"
        except PermissionError:
            return f"[ERROR] Permission denied executing: {command}"
        except Exception as exc:
            return f"[ERROR] Unexpected error running '{command}': {exc}"

    # ------------------------------------------------------------------
    # Utility
    # ------------------------------------------------------------------

    async def capture_many(self, commands: List[str]) -> dict:
        """Run multiple commands and return a dict of command -> output."""
        results = {}
        for cmd in commands:
            results[cmd] = await self.capture(cmd)
        return results
