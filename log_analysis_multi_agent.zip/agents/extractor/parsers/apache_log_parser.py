"""
Apache Log Parser - Parses Apache access logs and error logs.

Supports:
  - Combined Log Format (CLF + Referer + User-Agent)
  - Common Log Format (CLF only)
  - Apache Error Log format (module:level[pid])
  - Custom formats with partial field matching
"""

import re
from typing import Any, Dict, List, Optional


# --------------------------------------------------------------------------
# Access log patterns (most complete first)
# --------------------------------------------------------------------------

# Combined Log Format: ip - user [timestamp] "METHOD /path HTTP/x" status size "ref" "ua"
_COMBINED = re.compile(
    r'(?P<ip>\S+)\s+'
    r'(?P<ident>\S+)\s+'
    r'(?P<user>\S+)\s+'
    r'\[(?P<timestamp>[^\]]+)\]\s+'
    r'"(?P<request>[^"]*)"\s+'
    r'(?P<status>\d{3})\s+'
    r'(?P<size>\S+)'
    r'(?:\s+"(?P<referer>[^"]*)"\s+"(?P<user_agent>[^"]*)")?'
)

# Apache Error Log: [weekday month day time.usec year] [module:level] [pid N] message
_ERROR_V24 = re.compile(
    r'\[(?P<timestamp>[A-Za-z]{3}\s+[A-Za-z]{3}\s+\d{1,2}\s+[\d:.]+\s+\d{4})\]\s+'
    r'\[(?P<module>[^:]+):(?P<level>\w+)\]\s+'
    r'\[pid\s+(?P<pid>\d+)(?::tid\s+\d+)?\]\s+'
    r'(?:\[client\s+(?P<client>[^\]]+)\]\s+)?'
    r'(?P<message>.*)'
)

# Apache Error Log v2.2: [weekday month day time year] [level] message
_ERROR_V22 = re.compile(
    r'\[(?P<timestamp>[A-Za-z]{3}\s+[A-Za-z]{3}\s+\d{1,2}\s+[\d:]+\s+\d{4})\]\s+'
    r'\[(?P<level>\w+)\]\s+'
    r'(?:\[client\s+(?P<client>[^\]]+)\]\s+)?'
    r'(?P<message>.*)'
)

# HTTP status code categories
STATUS_CATEGORIES = {
    "1": "Informational",
    "2": "Success",
    "3": "Redirection",
    "4": "Client Error",
    "5": "Server Error",
}


class ApacheLogParser:
    """
    Parses Apache access and error log lines.

    Output schema:
    {
        "format":  "apache_access" | "apache_error" | "apache_mixed",
        "entries": List[dict],
        "count":   int,
        "errors":  List[str],
        "summary": dict,        # quick stats (status codes, top IPs, …)
    }
    """

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def parse(self, content: str) -> Dict[str, Any]:
        content = content.strip()
        if not content:
            return self._empty("Empty content")

        lines = [l for l in content.splitlines() if l.strip()]
        entries: List[dict] = []
        errors: List[str] = []

        for lineno, line in enumerate(lines, 1):
            try:
                entry = self._parse_line(line)
                entries.append(entry)
            except Exception as exc:
                errors.append(f"Line {lineno}: {exc}")
                entries.append({"parsed": False, "raw": line})

        fmt = self._detect_format(entries)
        summary = self._build_summary(entries, fmt)

        return {
            "format": fmt,
            "entries": entries,
            "count": len(entries),
            "errors": errors,
            "summary": summary,
        }

    # ------------------------------------------------------------------
    # Line parsing
    # ------------------------------------------------------------------

    def _parse_line(self, line: str) -> dict:
        # Try access log (combined + common)
        m = _COMBINED.match(line)
        if m:
            return self._build_access_entry(m, line)

        # Try error log v2.4+
        m = _ERROR_V24.match(line)
        if m:
            return self._build_error_entry(m, line, version="2.4")

        # Try error log v2.2
        m = _ERROR_V22.match(line)
        if m:
            return self._build_error_entry(m, line, version="2.2")

        # Fallback: store raw
        return {"parsed": False, "raw": line}

    def _build_access_entry(self, m: re.Match, raw: str) -> dict:
        d = m.groupdict()
        status = d.get("status", "")
        size_str = d.get("size", "-")

        # Parse the request line: "METHOD /path HTTP/1.1"
        method, path, protocol = self._split_request(d.get("request", ""))

        return {
            "parsed":     True,
            "type":       "access",
            "ip":         d.get("ip"),
            "ident":      d.get("ident"),
            "user":       d.get("user"),
            "timestamp":  d.get("timestamp"),
            "method":     method,
            "path":       path,
            "protocol":   protocol,
            "status":     status,
            "status_cat": STATUS_CATEGORIES.get(status[:1], "Unknown"),
            "size":       int(size_str) if size_str.isdigit() else None,
            "referer":    d.get("referer") or None,
            "user_agent": d.get("user_agent") or None,
            "raw":        raw,
        }

    def _build_error_entry(self, m: re.Match, raw: str, version: str) -> dict:
        d = m.groupdict()
        return {
            "parsed":    True,
            "type":      "error",
            "version":   version,
            "timestamp": d.get("timestamp"),
            "module":    d.get("module"),
            "level":     (d.get("level") or "").upper(),
            "pid":       d.get("pid"),
            "client":    d.get("client"),
            "message":   (d.get("message") or "").strip(),
            "raw":       raw,
        }

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _split_request(self, request: str):
        """Split 'GET /path HTTP/1.1' into (method, path, protocol)."""
        parts = request.split(" ", 2)
        if len(parts) == 3:
            return parts[0], parts[1], parts[2]
        if len(parts) == 2:
            return parts[0], parts[1], None
        return None, request or None, None

    def _detect_format(self, entries: List[dict]) -> str:
        access_count = sum(1 for e in entries if e.get("type") == "access")
        error_count  = sum(1 for e in entries if e.get("type") == "error")
        if access_count > 0 and error_count == 0:
            return "apache_access"
        if error_count > 0 and access_count == 0:
            return "apache_error"
        if access_count > 0 and error_count > 0:
            return "apache_mixed"
        return "apache_unknown"

    def _build_summary(self, entries: List[dict], fmt: str) -> dict:
        summary: dict = {}
        if "access" in fmt:
            status_counts: dict = {}
            ip_counts: dict = {}
            for e in entries:
                if not e.get("parsed"):
                    continue
                s = e.get("status", "???")
                status_counts[s] = status_counts.get(s, 0) + 1
                ip = e.get("ip")
                if ip:
                    ip_counts[ip] = ip_counts.get(ip, 0) + 1

            summary["status_codes"] = status_counts
            summary["top_ips"] = dict(
                sorted(ip_counts.items(), key=lambda x: x[1], reverse=True)[:10]
            )
            summary["error_rate"] = (
                sum(v for k, v in status_counts.items() if k.startswith(("4", "5")))
                / max(len([e for e in entries if e.get("parsed")]), 1)
            )

        if "error" in fmt:
            level_counts: dict = {}
            for e in entries:
                if e.get("type") == "error":
                    lv = e.get("level", "UNKNOWN")
                    level_counts[lv] = level_counts.get(lv, 0) + 1
            summary["error_levels"] = level_counts

        return summary

    def _empty(self, reason: str) -> dict:
        return {
            "format": "apache_unknown",
            "entries": [],
            "count": 0,
            "errors": [reason],
            "summary": {},
        }
