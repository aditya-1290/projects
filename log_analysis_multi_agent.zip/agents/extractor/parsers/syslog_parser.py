"""
Syslog Parser - Parses standard syslog format (RFC 3164 & RFC 5424) and BSD variants.

Handles:
  - RFC 5424  <priority>version timestamp hostname app procid msgid [sd] message
  - RFC 3164  <priority>timestamp hostname tag: message
  - BSD/legacy  timestamp hostname tag[pid]: message
  - Plain text lines with inline severity keywords
"""

import re
from typing import Any, Dict, List, Optional


# --------------------------------------------------------------------------
# Compiled patterns (most specific first)
# --------------------------------------------------------------------------

# RFC 5424: <34>1 2025-01-15T10:23:45.123Z host app 1234 - - message
_RFC5424 = re.compile(
    r"<(?P<priority>\d+)>"
    r"(?P<version>\d+)\s+"
    r"(?P<timestamp>\S+)\s+"
    r"(?P<hostname>\S+)\s+"
    r"(?P<app_name>\S+)\s+"
    r"(?P<procid>\S+)\s+"
    r"(?P<msgid>\S+)\s+"
    r"(?:(?P<structured_data>\[.*?\])\s+)?"
    r"(?P<message>.*)"
)

# RFC 3164 with priority: <34>Jan 15 10:23:45 host tag: message
_RFC3164_PRI = re.compile(
    r"<(?P<priority>\d+)>"
    r"(?P<timestamp>\w{3}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2})\s+"
    r"(?P<hostname>\S+)\s+"
    r"(?P<tag>\S+?)(?:\[(?P<pid>\d+)\])?:\s+"
    r"(?P<message>.*)"
)

# BSD / legacy: Jan 15 10:23:45 host tag[pid]: message
_BSD = re.compile(
    r"(?P<timestamp>\w{3}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2})\s+"
    r"(?P<hostname>\S+)\s+"
    r"(?P<tag>\S+?)(?:\[(?P<pid>\d+)\])?:\s+"
    r"(?P<message>.*)"
)

# ISO timestamp variant: 2025-01-15T10:23:45 host tag[pid]: message
_ISO = re.compile(
    r"(?P<timestamp>\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?)\s+"
    r"(?P<hostname>\S+)\s+"
    r"(?P<tag>\S+?)(?:\[(?P<pid>\d+)\])?:\s+"
    r"(?P<message>.*)"
)

PATTERNS = [_RFC5424, _RFC3164_PRI, _BSD, _ISO]

# --------------------------------------------------------------------------
# Facility / severity tables
# --------------------------------------------------------------------------

FACILITIES: Dict[int, str] = {
    0: "kern", 1: "user", 2: "mail", 3: "daemon",
    4: "auth", 5: "syslog", 6: "lpr", 7: "news",
    8: "uucp", 9: "cron", 10: "authpriv", 11: "ftp",
    12: "ntp", 13: "audit", 14: "console", 15: "cron2",
    16: "local0", 17: "local1", 18: "local2", 19: "local3",
    20: "local4", 21: "local5", 22: "local6", 23: "local7",
}

SEVERITIES: Dict[int, str] = {
    0: "EMERG", 1: "ALERT", 2: "CRIT", 3: "ERR",
    4: "WARNING", 5: "NOTICE", 6: "INFO", 7: "DEBUG",
}

_SEVERITY_KEYWORDS = [
    ("EMERG",   ["emerg", "panic", "fatal"]),
    ("ALERT",   ["alert"]),
    ("CRIT",    ["crit", "critical"]),
    ("ERR",     ["error", "err", "fail", "failed", "failure"]),
    ("WARNING", ["warning", "warn"]),
    ("NOTICE",  ["notice"]),
    ("INFO",    ["info", "information"]),
    ("DEBUG",   ["debug", "trace", "verbose"]),
]


class SyslogParser:
    """
    Parses syslog-formatted content into normalised log entry dicts.

    Output schema:
    {
        "format":        "syslog",
        "entries":       List[dict],
        "count":         int,
        "parsed_count":  int,
        "errors":        List[str],
    }

    Each entry contains:
        parsed, timestamp, hostname, app_name, pid,
        facility, severity, message, raw
    """

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def parse(self, content: str) -> Dict[str, Any]:
        content = content.strip()
        if not content:
            return self._empty("Empty content")

        lines = content.splitlines()
        entries: List[dict] = []
        errors: List[str] = []

        for lineno, line in enumerate(lines, 1):
            line = line.strip()
            if not line:
                continue
            try:
                entry = self._parse_line(line)
                entries.append(entry)
            except Exception as exc:
                errors.append(f"Line {lineno}: {exc}")
                entries.append({"parsed": False, "raw": line, "error": str(exc)})

        return {
            "format": "syslog",
            "entries": entries,
            "count": len(entries),
            "parsed_count": sum(1 for e in entries if e.get("parsed")),
            "errors": errors,
        }

    # ------------------------------------------------------------------
    # Line parsing
    # ------------------------------------------------------------------

    def _parse_line(self, line: str) -> dict:
        for pattern in PATTERNS:
            m = pattern.match(line)
            if m:
                return self._build_entry(m, line)

        # Could not match any pattern — return raw entry with severity guess
        return {
            "parsed": False,
            "raw": line,
            "severity": self._infer_severity(line),
        }

    def _build_entry(self, m: re.Match, raw: str) -> dict:
        d = m.groupdict()
        entry: dict = {
            "parsed":    True,
            "raw":       raw,
            "timestamp": d.get("timestamp"),
            "hostname":  d.get("hostname"),
            "app_name":  d.get("app_name") or d.get("tag"),
            "pid":       d.get("pid") or (d.get("procid") if d.get("procid") != "-" else None),
            "message":   (d.get("message") or "").strip(),
        }

        # Decode priority into facility + severity
        pri_str = d.get("priority")
        if pri_str:
            try:
                pri = int(pri_str)
                entry["facility"] = FACILITIES.get(pri >> 3, f"facility_{pri >> 3}")
                entry["severity"] = SEVERITIES.get(pri & 0x07, "UNKNOWN")
            except (ValueError, TypeError):
                entry["severity"] = self._infer_severity(entry["message"])
        else:
            entry["severity"] = self._infer_severity(entry["message"])

        if d.get("structured_data") and d["structured_data"] != "-":
            entry["structured_data"] = d["structured_data"]

        return entry

    # ------------------------------------------------------------------
    # Severity inference (for unstructured lines)
    # ------------------------------------------------------------------

    def _infer_severity(self, text: str) -> str:
        lower = text.lower()
        for severity, keywords in _SEVERITY_KEYWORDS:
            if any(kw in lower for kw in keywords):
                return severity
        return "UNKNOWN"

    # ------------------------------------------------------------------
    # Utility
    # ------------------------------------------------------------------

    def _empty(self, reason: str) -> dict:
        return {
            "format": "syslog",
            "entries": [],
            "count": 0,
            "parsed_count": 0,
            "errors": [reason],
        }
