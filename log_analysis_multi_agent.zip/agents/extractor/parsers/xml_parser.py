"""
XML Parser - Structured extraction from XML log files.

Handles:
  - Standard XML with nested elements
  - XML with attributes (merged into entry dict)
  - Namespace-qualified tags (namespaces stripped for readability)
  - Malformed XML with a lenient recovery attempt
"""

import re
import xml.etree.ElementTree as ET
from typing import Any, Dict, List, Optional


class XMLParser:
    """
    Parses XML content into a normalised list of log entry dicts.

    Output schema:
    {
        "format":   "xml",
        "root_tag": str,
        "entries":  List[dict],
        "count":    int,
        "errors":   List[str],
    }
    """

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def parse(self, content: str) -> Dict[str, Any]:
        content = content.strip()
        if not content:
            return self._empty("Empty content")

        errors: List[str] = []

        # --- Strategy 1: strict parse ---------------------------------
        root = self._parse_strict(content, errors)

        # --- Strategy 2: strip namespaces and retry ------------------
        if root is None:
            cleaned = self._strip_namespaces_from_text(content)
            root = self._parse_strict(cleaned, errors)

        # --- Strategy 3: wrap in synthetic root ----------------------
        if root is None:
            wrapped = f"<_root_>{content}</_root_>"
            root = self._parse_strict(wrapped, errors)

        if root is None:
            return {
                "format": "xml",
                "root_tag": None,
                "entries": [],
                "count": 0,
                "errors": errors,
            }

        root_tag = self._strip_ns(root.tag)
        entries = self._extract_entries(root)

        return {
            "format": "xml",
            "root_tag": root_tag,
            "entries": entries,
            "count": len(entries),
            "errors": errors,
        }

    # ------------------------------------------------------------------
    # Parsing helpers
    # ------------------------------------------------------------------

    def _parse_strict(
        self, content: str, errors: List[str]
    ) -> Optional[ET.Element]:
        try:
            return ET.fromstring(content)
        except ET.ParseError as exc:
            errors.append(f"XML parse error: {exc}")
            return None

    def _strip_namespaces_from_text(self, content: str) -> str:
        """Remove xmlns declarations and {namespace} prefixes from tag names."""
        # Remove xmlns declarations
        content = re.sub(r'\s+xmlns(?::\w+)?="[^"]*"', "", content)
        # Remove {namespace} prefix from tags
        content = re.sub(r"<(/?)[\w.-]+:([\w.-]+)", r"<\1\2", content)
        return content

    # ------------------------------------------------------------------
    # Entry extraction
    # ------------------------------------------------------------------

    def _extract_entries(self, root: ET.Element) -> List[dict]:
        """
        Extract log entries from the XML tree.

        Heuristic:
        - If the root has direct children, treat each child as a log entry.
        - If root itself has no children (leaf), treat root as a single entry.
        """
        children = list(root)
        if not children:
            # Root is a leaf — single entry
            return [self._element_to_dict(root)]

        return [self._element_to_dict(child) for child in children]

    def _element_to_dict(self, element: ET.Element) -> dict:
        """Recursively convert an XML element into a flat dict."""
        result: dict = {}

        # Include element tag (sans namespace)
        result["_tag"] = self._strip_ns(element.tag)

        # Include element text if present
        text = (element.text or "").strip()
        if text:
            result["_text"] = text

        # Include attributes
        for attr_name, attr_value in element.attrib.items():
            result[self._strip_ns(attr_name)] = attr_value

        # Include child elements (recursive, with name collision handling)
        for child in element:
            child_tag = self._strip_ns(child.tag)
            child_dict = self._element_to_dict(child)

            if len(list(child)) == 0 and not child.attrib:
                # Leaf child — store as simple value
                child_value = (child.text or "").strip()
                if child_tag in result:
                    # Collision: turn into list
                    existing = result[child_tag]
                    if isinstance(existing, list):
                        existing.append(child_value)
                    else:
                        result[child_tag] = [existing, child_value]
                else:
                    result[child_tag] = child_value
            else:
                result[child_tag] = child_dict

        return result

    # ------------------------------------------------------------------
    # Utilities
    # ------------------------------------------------------------------

    def _strip_ns(self, tag: str) -> str:
        """Remove {namespace_uri} prefix from a tag name."""
        if tag.startswith("{"):
            return tag.split("}", 1)[1]
        return tag

    def _empty(self, reason: str) -> dict:
        return {
            "format": "xml",
            "root_tag": None,
            "entries": [],
            "count": 0,
            "errors": [reason],
        }
