"""
CSV / TSV Parser - Structured extraction from delimiter-separated log files.

Handles:
  - Auto-detects delimiter (comma, tab, pipe, semicolon)
  - Auto-detects header row
  - Detects common log columns (timestamp, level, message, …)
  - Returns normalised entry list
"""

import csv
import io
from typing import Any, Dict, List, Optional, Tuple

LOG_LEVEL_KEYWORDS = {"level", "severity", "loglevel", "log_level", "priority"}
TIMESTAMP_KEYWORDS = {"timestamp", "time", "datetime", "date", "ts", "@timestamp"}
MESSAGE_KEYWORDS   = {"message", "msg", "text", "content", "log", "body"}


class CSVParser:
    """
    Parses CSV / TSV log files into a normalised list of entry dicts.

    Output schema:
    {
        "format":    str,           # "csv" | "tsv" | "dsv"
        "delimiter": str,
        "columns":   List[str],
        "entries":   List[dict],
        "count":     int,
        "log_columns": dict,        # detected semantic column mapping
        "errors":    List[str],
    }
    """

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def parse(self, content: str) -> Dict[str, Any]:
        content = content.strip()
        if not content:
            return self._empty("Empty content")

        delimiter, fmt = self._detect_delimiter(content)
        errors: List[str] = []

        try:
            reader = csv.DictReader(
                io.StringIO(content),
                delimiter=delimiter,
                quoting=csv.QUOTE_MINIMAL,
                skipinitialspace=True,
            )
            entries: List[dict] = []
            for lineno, row in enumerate(reader, 2):  # line 1 is the header
                cleaned = {
                    k.strip(): (v.strip() if isinstance(v, str) else v)
                    for k, v in row.items()
                    if k is not None  # csv.DictReader can yield None keys for extra columns
                }
                if any(v for v in cleaned.values()):  # skip blank rows
                    entries.append(cleaned)

            columns = [c.strip() for c in (reader.fieldnames or [])]
            log_cols = self._detect_log_columns(columns)

            return {
                "format": fmt,
                "delimiter": repr(delimiter),
                "columns": columns,
                "entries": entries,
                "count": len(entries),
                "log_columns": log_cols,
                "errors": errors,
            }

        except csv.Error as exc:
            errors.append(f"CSV reader error: {exc}")
            # Fallback: split manually
            return self._manual_split(content, delimiter, fmt, errors)

    # ------------------------------------------------------------------
    # Delimiter detection
    # ------------------------------------------------------------------

    def _detect_delimiter(self, content: str) -> Tuple[str, str]:
        """Return (delimiter_char, format_name)."""
        sample = "\n".join(content.splitlines()[:10])

        try:
            dialect = csv.Sniffer().sniff(sample, delimiters=",\t|;")
            delim = dialect.delimiter
        except csv.Error:
            # Count occurrences in the sample and pick the winner
            counts = {d: sample.count(d) for d in [",", "\t", "|", ";"]}
            delim = max(counts, key=counts.get)

        fmt_map = {",": "csv", "\t": "tsv", "|": "dsv", ";": "dsv"}
        return delim, fmt_map.get(delim, "dsv")

    # ------------------------------------------------------------------
    # Semantic column detection
    # ------------------------------------------------------------------

    def _detect_log_columns(self, columns: List[str]) -> Dict[str, str]:
        """Map semantic log roles to actual column names."""
        mapping: Dict[str, str] = {}
        for col in columns:
            lower = col.lower().replace("-", "_").replace(" ", "_")
            if lower in TIMESTAMP_KEYWORDS and "timestamp" not in mapping:
                mapping["timestamp"] = col
            elif lower in LOG_LEVEL_KEYWORDS and "level" not in mapping:
                mapping["level"] = col
            elif lower in MESSAGE_KEYWORDS and "message" not in mapping:
                mapping["message"] = col
        return mapping

    # ------------------------------------------------------------------
    # Fallback
    # ------------------------------------------------------------------

    def _manual_split(
        self, content: str, delimiter: str, fmt: str, errors: List[str]
    ) -> Dict[str, Any]:
        """Last-resort: split each line by delimiter."""
        lines = [l for l in content.splitlines() if l.strip()]
        if not lines:
            return self._empty("No lines after splitting")

        header = [c.strip() for c in lines[0].split(delimiter)]
        entries: List[dict] = []
        for line in lines[1:]:
            parts = [p.strip() for p in line.split(delimiter)]
            row = dict(zip(header, parts))
            if len(parts) > len(header):
                row["_extra"] = delimiter.join(parts[len(header):])
            entries.append(row)

        return {
            "format": fmt,
            "delimiter": repr(delimiter),
            "columns": header,
            "entries": entries,
            "count": len(entries),
            "log_columns": self._detect_log_columns(header),
            "errors": errors,
        }

    def _empty(self, reason: str) -> Dict:
        return {
            "format": "empty",
            "delimiter": "",
            "columns": [],
            "entries": [],
            "count": 0,
            "log_columns": {},
            "errors": [reason],
        }

