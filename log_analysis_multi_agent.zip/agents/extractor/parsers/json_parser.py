"""
JSON Parser - Structured extraction from JSON / NDJSON log files.

Handles:
  - Single JSON object
  - JSON array of objects
  - NDJSON / JSON-lines (one object per line)
  - Mixed files where some lines are JSON and others are plain text
"""

import json
from typing import Any, Dict, List, Optional


class JSONParser:
    """
    Parses JSON content into a normalised list of log entry dicts.

    The output always follows the same schema:
    {
        "format":  str,          # "single_object" | "array" | "ndjson" | "mixed"
        "entries": List[dict],   # Flattened log entries
        "count":   int,
        "errors":  List[str],    # Parse warnings (non-fatal)
    }
    """

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def parse(self, content: str) -> Dict[str, Any]:
        content = content.strip()
        if not content:
            return self._empty("Empty content")

        errors: List[str] = []

        # --- Strategy 1: whole-document JSON (object or array) -------
        result = self._try_whole(content, errors)
        if result:
            return result

        # --- Strategy 2: NDJSON / JSON-Lines -------------------------
        result = self._try_ndjson(content, errors)
        if result:
            return result

        # --- Strategy 3: mixed file (log lines + JSON bursts) --------
        result = self._try_mixed(content, errors)
        if result:
            return result

        return {
            "format": "unknown",
            "entries": [],
            "count": 0,
            "errors": errors or ["Content could not be parsed as any JSON variant"],
        }

    # ------------------------------------------------------------------
    # Strategies
    # ------------------------------------------------------------------

    def _try_whole(self, content: str, errors: List[str]) -> Optional[Dict]:
        """Try to parse as a single JSON document."""
        try:
            data = json.loads(content)
        except json.JSONDecodeError as exc:
            errors.append(f"Whole-doc parse failed: {exc}")
            return None

        if isinstance(data, dict):
            return {
                "format": "single_object",
                "entries": [self._flatten(data)],
                "count": 1,
                "errors": [],
            }

        if isinstance(data, list):
            entries = []
            for i, item in enumerate(data):
                if isinstance(item, dict):
                    entries.append(self._flatten(item))
                else:
                    entries.append({"_index": i, "_value": item})
            return {
                "format": "array",
                "entries": entries,
                "count": len(entries),
                "errors": [],
            }

        # Scalar root (valid JSON but not useful as logs)
        return {
            "format": "scalar",
            "entries": [{"value": data}],
            "count": 1,
            "errors": [],
        }

    def _try_ndjson(self, content: str, errors: List[str]) -> Optional[Dict]:
        """Try to parse as NDJSON (one JSON object per line)."""
        lines = [l.strip() for l in content.splitlines() if l.strip()]
        if not lines:
            return None

        entries: List[dict] = []
        parse_errors: List[str] = []

        for lineno, line in enumerate(lines, 1):
            try:
                obj = json.loads(line)
                if isinstance(obj, dict):
                    entries.append(self._flatten(obj))
                else:
                    entries.append({"_line": lineno, "_value": obj})
            except json.JSONDecodeError as exc:
                parse_errors.append(f"Line {lineno}: {exc}")

        if not entries:
            errors.extend(parse_errors)
            return None

        # Only claim NDJSON if we managed to parse most lines as JSON
        ratio = len(entries) / len(lines)
        if ratio < 0.5:
            errors.extend(parse_errors)
            return None

        return {
            "format": "ndjson",
            "entries": entries,
            "count": len(entries),
            "errors": parse_errors,
        }

    def _try_mixed(self, content: str, errors: List[str]) -> Optional[Dict]:
        """Parse a mixed log file where JSON objects appear among plain-text lines."""
        lines = content.splitlines()
        entries: List[dict] = []
        parse_errors: List[str] = []

        for lineno, line in enumerate(lines, 1):
            stripped = line.strip()
            if not stripped:
                continue
            if stripped.startswith("{") or stripped.startswith("["):
                try:
                    obj = json.loads(stripped)
                    if isinstance(obj, dict):
                        entries.append(self._flatten(obj))
                    elif isinstance(obj, list):
                        for item in obj:
                            if isinstance(item, dict):
                                entries.append(self._flatten(item))
                    continue
                except json.JSONDecodeError:
                    parse_errors.append(f"Line {lineno}: looks like JSON but failed to parse")
            # Keep plain-text lines as raw entries
            entries.append({"_line": lineno, "_raw": stripped})

        if not entries:
            return None

        return {
            "format": "mixed",
            "entries": entries,
            "count": len(entries),
            "errors": parse_errors,
        }

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _flatten(self, data: dict, prefix: str = "") -> dict:
        """Recursively flatten nested dicts; lists become JSON strings."""
        result: dict = {}
        for key, value in data.items():
            full_key = f"{prefix}.{key}" if prefix else key
            if isinstance(value, dict):
                result.update(self._flatten(value, full_key))
            elif isinstance(value, list):
                # Keep short lists inline; stringify long ones
                if len(value) <= 5 and all(not isinstance(v, (dict, list)) for v in value):
                    result[full_key] = value
                else:
                    result[full_key] = json.dumps(value)
            else:
                result[full_key] = value
        return result

    def _empty(self, reason: str) -> Dict:
        return {"format": "empty", "entries": [], "count": 0, "errors": [reason]}
