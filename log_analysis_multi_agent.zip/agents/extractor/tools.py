"""
Tools registered to the Extractor Agent
"""

from typing import Dict, Any


class ExtractorTools:
    """Collection of tools available to the Extractor agent"""

    def __init__(self):
        self.tools = {
            "file_reader": self.read_file,
            "ocr_tool": self.extract_ocr,
            "terminal_capture": self.capture_terminal,
            "json_parser": self.parse_json,
            "csv_parser": self.parse_csv,
            "xml_parser": self.parse_xml,
            "syslog_parser": self.parse_syslog,
            "apache_parser": self.parse_apache,
        }

    async def read_file(self, path: str) -> str:
        """Read a file from disk"""
        from agents.extractor.loaders.file_loader import FileLoader
        loader = FileLoader()
        return await loader.load(path)

    async def extract_ocr(self, image_path: str) -> str:
        """Extract text from image using OCR"""
        from agents.extractor.loaders.image_loader import ImageLoader
        loader = ImageLoader()
        return await loader.extract(image_path)

    async def capture_terminal(self, command: str) -> str:
        """Capture terminal command output"""
        from agents.extractor.loaders.terminal_loader import TerminalLoader
        loader = TerminalLoader()
        return await loader.capture(command)

    async def parse_json(self, content: str) -> Dict:
        """Parse JSON content"""
        from agents.extractor.parsers.json_parser import JSONParser
        parser = JSONParser()
        return await parser.parse(content)

    async def parse_csv(self, content: str) -> Dict:
        """Parse CSV content"""
        from agents.extractor.parsers.csv_parser import CSVParser
        parser = CSVParser()
        return await parser.parse(content)

    async def parse_xml(self, content: str) -> Dict:
        """Parse XML content"""
        from agents.extractor.parsers.xml_parser import XMLParser
        parser = XMLParser()
        return await parser.parse(content)

    async def parse_syslog(self, content: str) -> Dict:
        """Parse syslog content"""
        from agents.extractor.parsers.syslog_parser import SyslogParser
        parser = SyslogParser()
        return await parser.parse(content)

    async def parse_apache(self, content: str) -> Dict:
        """Parse Apache log content"""
        from agents.extractor.parsers.apache_log_parser import ApacheLogParser
        parser = ApacheLogParser()
        return await parser.parse(content)

    def get_tool(self, tool_name: str):
        """Get a tool by name"""
        return self.tools.get(tool_name)

