"""
Agent Configuration
Maps agents to models and defines agent metadata
"""

from typing import Dict, Optional

# ============================================
# Agent Model Mapping
# ============================================
AGENT_MODEL_MAP: Dict[str, Optional[str]] = {
    "extractor": None,              # Uses custom parsers (no LLM)
    "extractor_ocr": "deepseek_ocr",
    "preprocessor": "qwen_small",
    "analyzer": "gemma",
    "solver": "gemma",
    "debugger": "gemma",
    "critic": "gemma",
    "memory": "qwen_small",
    "memory_embedding": "embedding",
    "orchestrator": "gemma"
}

# ============================================
# Agent Metadata
# ============================================
AGENT_METADATA = {
    "extractor": {
        "description": "Extracts logs from files, images, and terminal",
        "version": "1.0.0",
        "built_by": "Person C",
        "status": "pending"
    },
    "preprocessor": {
        "description": "Cleans, parses, and structures raw logs",
        "version": "1.0.0",
        "built_by": "You",
        "status": "complete"
    },
    "analyzer": {
        "description": "Classifies log types and detects user intent",
        "version": "1.0.0",
        "built_by": "Person B",
        "status": "pending"
    },
    "solver": {
        "description": "Root cause analysis and fix generation",
        "version": "1.0.0",
        "built_by": "You",
        "status": "complete"
    },
    "debugger": {
        "description": "Code-level debugging and patch generation",
        "version": "1.0.0",
        "built_by": "Person B",
        "status": "pending"
    },
    "critic": {
        "description": "Validates solutions and checks safety",
        "version": "1.0.0",
        "built_by": "You",
        "status": "complete"
    },
    "memory": {
        "description": "Stores and retrieves past analyses",
        "version": "1.0.0",
        "built_by": "You",
        "status": "complete"
    },
    "orchestrator": {
        "description": "Coordinates agents and manages workflow",
        "version": "1.0.0",
        "built_by": "You",
        "status": "complete"
    }
}

# ============================================
# Agent Priority (for loading order)
# ============================================
AGENT_LOAD_PRIORITY = [
    "memory",        # Load first (other agents may need it)
    "preprocessor",
    "analyzer",
    "solver",
    "debugger",
    "critic",
    "extractor",
    "orchestrator"   # Load last (depends on others being registered)
]

# ============================================
# Helper Functions
# ============================================

def get_model_for_agent(agent_name: str) -> Optional[str]:
    """Get the model assigned to an agent"""
    return AGENT_MODEL_MAP.get(agent_name)

def get_agent_metadata(agent_name: str) -> Dict:
    """Get metadata for an agent"""
    return AGENT_METADATA.get(agent_name, {})

def get_completed_agents() -> list:
    """Get list of completed agents"""
    return [
        name for name, meta in AGENT_METADATA.items()
        if meta.get("status") == "complete"
    ]

def get_pending_agents() -> list:
    """Get list of pending agents"""
    return [
        name for name, meta in AGENT_METADATA.items()
        if meta.get("status") == "pending"
    ]
