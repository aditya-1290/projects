"""
Debugger Agent - Code-level debugging and patch generation using skill prompts.

Production-quality implementation with:
  - Intelligent skill selection based on error characteristics
  - Safe prompt formatting (no KeyError on missing template fields)
  - Multi-step patch generation with refinement loop
  - Source code context window extraction
  - Language auto-detection
  - All 15 skill prompts accessible
"""

import json
import re
from collections import defaultdict
from typing import Any, Dict, List, Optional, Tuple

from agents.base_agent import BaseAgent, A2AMessage, MessageType
from agents.debugger.code_parser import CodeParser
from agents.debugger.patch_generator import PatchGenerator
from agents.debugger.prompts import (
    SKILL_PYTHON_DEBUG,
    SKILL_JAVA_DEBUG,
    SKILL_JS_TS_DEBUG,
    SKILL_GO_DEBUG,
    SKILL_ASYNC_ERROR_ANALYSIS,
    SKILL_DEEP_CALL_CHAIN,
    SKILL_CONCURRENT_ERROR,
    SKILL_LIBRARY_ERROR,
    SKILL_MEMORY_ERROR_ANALYSIS,
    SKILL_SECURITY_PATCH_REVIEW,
    SKILL_PATCH_TEST_SUGGESTION,
    SKILL_ERROR_PREVENTION,
    SKILL_MULTI_ERROR_TRIAGE,
)

_MAX_SOURCE_CHARS = 3000
_MAX_TRACE_CHARS = 2000


def _safe_format(template: str, **kwargs) -> str:
    """
    Format a template string safely. Missing keys are replaced with "N/A"
    instead of raising KeyError.
    """
    defaults = defaultdict(lambda: "N/A", **kwargs)
    return template.format_map(defaults)


class DebuggerAgent(BaseAgent):
    """
    Parses stack traces and generates code patches using skill-based prompts.

    Selects the right skill prompt based on error characteristics:
      - Language-specific (Python, Java, JS/TS, Go) for most code errors
      - Memory errors → SKILL_MEMORY_ERROR_ANALYSIS
      - Concurrency/race conditions → SKILL_CONCURRENT_ERROR
      - Library errors → SKILL_LIBRARY_ERROR
      - Async/event loop → SKILL_ASYNC_ERROR_ANALYSIS
      - Deep call chains (50+ frames) → SKILL_DEEP_CALL_CHAIN
      - Multiple simultaneous errors → SKILL_MULTI_ERROR_TRIAGE
    """

    def __init__(self):
        super().__init__("debugger_v1", "agents/debugger/capabilities.json")
        self._code_parser = CodeParser()
        self._patch_generator = PatchGenerator()
        self._max_patch_attempts = 2

    # =========================================================================
    # Main entry point
    # =========================================================================

    async def process(self, message: A2AMessage) -> A2AMessage:
        task = message.task or {}
        context = message.context or {}
        self.log_agent_event("process_start", {"input_size": len(str(message.task)), "action": message.task.get("action", "unknown")})
        action = task.get("action", "debug").lower()

        if action == "analyze":
            return await self._handle_code_analysis(message, task, context)
        return await self._handle_debug(message, task, context)

    # =========================================================================
    # Debug flow (main path)
    # =========================================================================

    async def _handle_debug(self, message, task, context):
        # 1. Gather inputs
        stack_trace = self._find_stack_trace(task, context)
        source_code = self._find_source_code(task, context)
        file_path = task.get("file_path", "") or context.get("file_path", "")
        language = task.get("language", "") or context.get("language", "")
        retry_feedback = task.get("retry_feedback", "")

        if not stack_trace or not stack_trace.strip():
            return self._make_response(
                message=message,
                response={
                    "parsed_trace": None,
                    "patch": None,
                    "guidance": "No stack trace found. Provide error output with traceback lines."
                },
                confidence=0.2,
                caveats=["No stack trace available"]
            )

        try:
            model = await self._get_model()

            # 2. Parse the stack trace
            parsed = await self._parse_trace(stack_trace, model)

            # 3. Determine effective language
            effective_lang = language or parsed.get("language", "unknown")
            effective_file = file_path or parsed.get("root_file", "")

            # 4. Extract code context window
            error_line = parsed.get("root_line", 0)
            code_context = {}
            code_structure = {}
            if source_code and error_line:
                code_context = self._code_parser.extract_error_context(
                    source_code, error_line, context_lines=12
                )
                code_structure = self._code_parser.parse(source_code, effective_lang)

            # 5. Select the best skill prompt
            skill_prompt, skill_name = self._select_skill(
                parsed, effective_lang, stack_trace
            )

            # 6. Generate patch with retry loop
            patch_result = await self._generate_patch_with_retry(
                skill_prompt=skill_prompt,
                skill_name=skill_name,
                parsed=parsed,
                stack_trace=stack_trace,
                source_code=source_code,
                code_context=code_context,
                code_structure=code_structure,
                effective_lang=effective_lang,
                effective_file=effective_file,
                retry_feedback=retry_feedback,
                model=model,
            )

            # 7. Post-patch: suggest test cases if patch generated
            if patch_result and model:
                test_suggestion = await self._suggest_tests(
                    parsed, patch_result, effective_lang, model
                )
                if test_suggestion:
                    patch_result["test_suggestions"] = test_suggestion

            # 8. Score and build response
            confidence = self._compute_confidence(parsed, patch_result, source_code, code_context)
            caveats = self._build_caveats(patch_result, source_code, parsed)

            self.log(
                f"Debug complete: lang={effective_lang}, skill={skill_name}, "
                f"conf={confidence:.2f}, patch={'yes' if patch_result else 'no'}",
                "INFO"
            )

            return self._make_response(
                message=message,
                response={
                    "parsed_trace": parsed,
                    "code_context": code_context,
                    "code_structure": code_structure,
                    "patch": patch_result,
                    "requires_source": not bool(source_code),
                    "language": effective_lang,
                    "file": effective_file,
                    "skill_used": skill_name,
                },
                confidence=confidence,
                caveats=caveats,
            )

        except Exception as exc:
            self.log(f"Debugging error: {exc}", "ERROR")
            return self._make_response(
                message=message,
                response={"parsed_trace": None, "patch": None, "error_detail": str(exc)},
                confidence=0.1,
                caveats=[f"Internal error: {exc}"]
            )

    # =========================================================================
    # Skill Selection — choose the right prompt for the error
    # =========================================================================

    def _select_skill(self, parsed, language, stack_trace):
        """
        Select the best skill prompt based on error characteristics.
        Returns (prompt_template, skill_name).
        """
        error_type = parsed.get("error_type", "").lower()
        error_msg = parsed.get("error_message", "").lower()
        call_chain = parsed.get("call_chain", [])
        frame_count = len(call_chain)

        # 1. Memory errors
        if any(kw in error_type for kw in ["outofmemory", "memory", "heap", "oom"]):
            return SKILL_MEMORY_ERROR_ANALYSIS, "memory_error_analysis"

        # 2. Concurrency / race conditions
        if any(kw in error_type + error_msg for kw in [
            "concurrent", "race", "deadlock", "thread", "synchroniz",
            "concurrentmodification"
        ]):
            return SKILL_CONCURRENT_ERROR, "concurrent_error"

        # 3. Async / event loop errors
        if any(kw in error_type + error_msg for kw in [
            "event loop", "coroutine", "await", "asyncio", "promise", "future"
        ]):
            return SKILL_ASYNC_ERROR_ANALYSIS, "async_error_analysis"

        # 4. External library errors
        if parsed.get("is_external_library") or self._is_library_error(call_chain, stack_trace):
            return SKILL_LIBRARY_ERROR, "library_error"

        # 5. Deep call chains (50+ frames)
        if frame_count >= 50:
            return SKILL_DEEP_CALL_CHAIN, "deep_call_chain"

        # 6. Multiple errors detected
        if len(re.findall(r"(Error|Exception):", stack_trace)) >= 3:
            return SKILL_MULTI_ERROR_TRIAGE, "multi_error_triage"

        # 7. Language-specific prompts
        lang_skill_map = {
            "python": (SKILL_PYTHON_DEBUG, "python_debug"),
            "java": (SKILL_JAVA_DEBUG, "java_debug"),
            "javascript": (SKILL_JS_TS_DEBUG, "js_ts_debug"),
            "typescript": (SKILL_JS_TS_DEBUG, "js_ts_debug"),
            "go": (SKILL_GO_DEBUG, "go_debug"),
        }

        if language.lower() in lang_skill_map:
            return lang_skill_map[language.lower()]

        # Default: Python (most common)
        return SKILL_PYTHON_DEBUG, "python_debug"

    def _is_library_error(self, call_chain, stack_trace):
        """Check if the error originates from a third-party library."""
        library_indicators = [
            "site-packages", "node_modules", "vendor/",
            ".m2/repository", "gradle/caches",
        ]
        for frame in call_chain[:3]:
            file_path = frame.get("file", "")
            if any(ind in file_path for ind in library_indicators):
                return True

        # Also check the trace text directly
        for ind in library_indicators:
            if ind in stack_trace:
                return True

        return False

    # =========================================================================
    # Patch generation with retry loop
    # =========================================================================

    async def _generate_patch_with_retry(
        self,
        skill_prompt,
        skill_name,
        parsed,
        stack_trace,
        source_code,
        code_context,
        code_structure,
        effective_lang,
        effective_file,
        retry_feedback,
        model,
    ):
        """Generate patch, retrying with refinement if needed."""
        if not model:
            return None

        patch_result = None
        last_issue = retry_feedback

        for attempt in range(1, self._max_patch_attempts + 1):
            # Build the prompt
            prompt = self._build_prompt(
                skill_prompt=skill_prompt,
                parsed=parsed,
                stack_trace=stack_trace,
                source_code=source_code,
                code_context=code_context,
                effective_lang=effective_lang,
                effective_file=effective_file,
                last_issue=last_issue,
                attempt=attempt,
            )

            try:
                raw = await self._generate_with_tracking(model, prompt, max_tokens=1024, action_name="debug_patch")
                raw_text = raw.text if hasattr(raw, "text") else str(raw)
                patch_result = self._extract_json(raw_text)

                if not patch_result:
                    last_issue = "LLM returned no structured JSON — retrying"
                    continue

                # If we have source code, try to apply and validate
                if source_code and patch_result.get("code_before") and patch_result.get("code_after"):
                    fixed = source_code.replace(
                        patch_result["code_before"],
                        patch_result["code_after"],
                        1
                    )
                    if fixed != source_code:
                        diff = self._patch_generator.generate(
                            source_code, fixed,
                            file_path=effective_file,
                            description=patch_result.get("fix_description", "")
                        )
                        if diff.get("is_valid"):
                            patch_result["unified_diff"] = diff
                            break
                        else:
                            last_issue = "; ".join(diff.get("validation_notes", ["invalid patch"]))
                    else:
                        # Snippet not found verbatim — still useful
                        patch_result["_note"] = "code_before not found verbatim — apply manually"
                        break
                else:
                    # No source or no snippets — accept LLM output as-is
                    break

            except Exception as exc:
                self.log(f"Patch attempt {attempt} failed: {exc}", "WARNING")
                last_issue = str(exc)

        return patch_result

    def _build_prompt(
        self,
        skill_prompt,
        parsed,
        stack_trace,
        source_code,
        code_context,
        effective_lang,
        effective_file,
        last_issue,
        attempt,
    ):
        """Build a formatted prompt from the skill template."""
        call_chain = parsed.get("call_chain", [])
        call_chain_text = "\n".join(
            f"  {i+1}. {f.get('file','?')} line {f.get('line','?')} in {f.get('function','?')}"
            for i, f in enumerate(call_chain)
        ) or "  (not available)"

        context_text = (
            code_context.get("snippet", "")
            or source_code[:_MAX_SOURCE_CHARS]
            or stack_trace[:_MAX_TRACE_CHARS]
        )

        # If this is a retry, inject the previous issue
        if last_issue and attempt > 1:
            context_text = (
                f"PREVIOUS ATTEMPT ISSUE: {last_issue}\n\n"
                f"Please fix the above issue in your new response.\n\n"
                f"{context_text}"
            )

        return _safe_format(
            skill_prompt,
            error_type=parsed.get("error_type", "Unknown"),
            error_message=parsed.get("error_message", ""),
            file=effective_file,
            line=parsed.get("root_line", 0),
            function=(
                call_chain[0].get("function", "unknown") if call_chain else "unknown"
            ),
            context=context_text,
            language=effective_lang,
            frame_count=len(call_chain),
            technologies=parsed.get("technologies", ""),
            call_chain=call_chain_text,
            root_file=parsed.get("root_file", effective_file),
            error_list="",
            timeline="",
            occurrence_count=1,
            affected_components="",
            fix_description="",
            fix_history="",
            patch="",
        )

    # =========================================================================
    # Test case suggestion
    # =========================================================================

    async def _suggest_tests(self, parsed, patch_result, language, model):
        """Generate test case suggestions for the patch."""
        if not model:
            return None

        try:
            prompt = _safe_format(
                SKILL_PATCH_TEST_SUGGESTION,
                error_type=parsed.get("error_type", "Unknown"),
                error_message=parsed.get("error_message", ""),
                fix_description=patch_result.get("fix_description", ""),
                language=language,
            )
            raw = await self._generate_with_tracking(model, prompt, max_tokens=512, action_name="debug_analysis")
            raw_text = raw.text if hasattr(raw, "text") else str(raw)
            return self._extract_json(raw_text)
        except Exception:
            return None

    # =========================================================================
    # Code analysis (proactive)
    # =========================================================================

    async def _handle_code_analysis(self, message, task, context):
        source_code = self._find_source_code(task, context)
        language = task.get("language", "auto")

        if not source_code:
            return self._make_response(
                message=message,
                response={"error": "No source code provided"},
                confidence=0.0,
                caveats=["Source code required for analysis"]
            )

        try:
            model = await self._get_model()
            structure = self._code_parser.parse(source_code, language)
            eff_lang = structure["language"]
            anti_patterns = self._code_parser._detect_anti_patterns(source_code, eff_lang)

            analysis = None
            if model:
                prompt = _safe_format(
                    SKILL_PYTHON_DEBUG,
                    error_type="Code Analysis",
                    error_message="Proactive bug scan",
                    file="unknown",
                    line=0,
                    function="unknown",
                    context=source_code[:_MAX_SOURCE_CHARS],
                    language=eff_lang,
                    frame_count=0,
                    technologies="",
                    call_chain="",
                    root_file="",
                    error_list="",
                    timeline="",
                    occurrence_count=0,
                    affected_components="",
                    fix_description="",
                    fix_history="",
                    patch="",
                )
                raw = await self._generate_with_tracking(model, prompt, max_tokens=1024, action_name="debug_patch")
                raw_text = raw.text if hasattr(raw, "text") else str(raw)
                analysis = self._extract_json(raw_text)

            return self._make_response(
                message=message,
                response={
                    "code_structure": structure,
                    "analysis": analysis,
                    "anti_patterns": anti_patterns,
                    "language": eff_lang,
                },
                confidence=0.75 if model else 0.5,
                caveats=["Static analysis only — runtime issues not detected"]
            )

        except Exception as exc:
            return self._make_response(
                message=message,
                response={"error": str(exc)},
                confidence=0.0,
                caveats=[f"Analysis failed: {exc}"]
            )

    # =========================================================================
    # Stack trace parsing
    # =========================================================================

    async def _parse_trace(self, trace, model):
        """Parse stack trace using regex patterns."""
        result = {
            "error_type": "Unknown",
            "error_message": "",
            "root_file": "",
            "root_line": 0,
            "language": "unknown",
            "call_chain": [],
            "technologies": "",
            "is_external_library": False,
        }

        # Extract error type and message
        match = re.search(r'(\w+(?:Error|Exception|Panic|Warning)):\s*(.+)', trace, re.IGNORECASE)
        if match:
            result["error_type"] = match.group(1)
            result["error_message"] = match.group(2).strip()[:500]

        # Python: File "path", line N
        py_pattern = re.compile(r'File\s+"([^"]+)",\s*line\s+(\d+)(?:,\s*in\s+(\w+))?')
        for m in py_pattern.finditer(trace):
            result["call_chain"].append({
                "file": m.group(1),
                "line": int(m.group(2)),
                "function": m.group(3) or "unknown"
            })

        # Java: at com/org.class.method(File.java:N)
        if not result["call_chain"]:
            java_pattern = re.compile(r'at\s+([\w.]+)\(([\w.]+):(\d+)\)')
            for m in java_pattern.finditer(trace):
                parts = m.group(1).rsplit(".", 1)
                func = parts[-1] if parts else m.group(1)
                result["call_chain"].append({
                    "file": m.group(2),
                    "line": int(m.group(3)),
                    "function": func
                })

        # Go: path/file.go:N + function
        if not result["call_chain"]:
            go_pattern = re.compile(r'([\w/.-]+\.go):(\d+)(?:\s+(\w+))?')
            for m in go_pattern.finditer(trace):
                result["call_chain"].append({
                    "file": m.group(1),
                    "line": int(m.group(2)),
                    "function": m.group(3) or "unknown"
                })

        # Set root from first frame
        if result["call_chain"]:
            result["root_file"] = result["call_chain"][0]["file"]
            result["root_line"] = result["call_chain"][0]["line"]

        # Check if root file is in a library
        root_file = result["root_file"].lower()
        if any(ind in root_file for ind in [
            "site-packages", "node_modules", ".m2/repository", "gradle/caches"
        ]):
            result["is_external_library"] = True

        # Detect language
        if "Traceback" in trace or 'File "' in trace:
            result["language"] = "python"
        elif "at com." in trace or "at org." in trace or ".java:" in trace:
            result["language"] = "java"
        elif ".js:" in trace or ".ts:" in trace or "node_modules" in trace:
            result["language"] = "javascript"
        elif "goroutine" in trace and ".go:" in trace:
            result["language"] = "go"

        return result

    # =========================================================================
    # Helpers
    # =========================================================================

    def _find_stack_trace(self, task, context):
        candidates = [
            task.get("stack_trace", ""),
            task.get("content", ""),
            task.get("raw_logs", ""),
            context.get("clean_logs", ""),
            context.get("stack_trace", ""),
            context.get("raw_logs", ""),
            context.get("query", ""),
        ]
        def score(text):
            if not text: return 0
            s = 0
            if "Traceback" in text: s += 10
            if "Error:" in text: s += 5
            if "Exception" in text: s += 5
            if 'File "' in text: s += 8
            if " line " in text: s += 3
            if "at " in text and ".java:" in text: s += 10
            if "goroutine" in text: s += 8
            return s
        return max(candidates, key=score) or ""

    def _find_source_code(self, task, context):
        return task.get("source_code", "") or context.get("source_code", "") or ""

    def _extract_json(self, text):
        if not text: return None
        text = re.sub(r"```(?:json)?\s*", "", text).strip()
        try: return json.loads(text)
        except json.JSONDecodeError: pass
        match = re.search(r"\{.*\}", text, re.DOTALL)
        if match:
            try: return json.loads(match.group())
            except json.JSONDecodeError: pass
        return None

    async def _get_model(self):
        try: return await self.get_model("gemma")
        except Exception:
            try: return await self.get_model("qwen_small")
            except Exception: return None

    def _compute_confidence(self, parsed, patch, source_code, code_context):
        score = 0.0
        if parsed.get("error_type") and parsed["error_type"] != "Unknown":
            score += 0.25
        if parsed.get("root_file"):
            score += 0.15
        if parsed.get("root_line"):
            score += 0.10
        if source_code:
            score += 0.15
        if code_context.get("snippet"):
            score += 0.05
        if patch:
            if patch.get("code_before") and patch.get("code_after"):
                score += 0.15
            if patch.get("unified_diff", {}).get("is_valid"):
                score += 0.10
            llm_conf = float(patch.get("confidence", 0))
            score += llm_conf * 0.05
        return round(min(1.0, score), 2)

    def _build_caveats(self, patch, source_code, parsed):
        caveats = []
        if not source_code:
            caveats.append("No source code provided — patch is based on stack trace only.")
        if patch:
            if patch.get("side_effects"):
                caveats.append(f"Side effect: {patch['side_effects']}")
            if patch.get("_note"):
                caveats.append(patch["_note"])
        caveats.append("Patch requires human review before applying to production.")
        return caveats

    def _make_response(self, message, response, confidence, caveats):
        return A2AMessage(
            message_type=MessageType.RESPONSE,
            sender_id=self.agent_id,
            sender_type="debugger",
            target_id=message.sender_id,
            correlation_id=message.message_id,
            response=response,
            confidence=confidence,
            caveats=caveats,
        )


