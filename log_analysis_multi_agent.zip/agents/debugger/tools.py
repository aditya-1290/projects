"""
Tools registered to the Debugger Agent.

FIX: The original tools.py had a circular import — it instantiated DebuggerAgent
     which in turn imports tools.py. All tools now use the parser/generator
     classes directly, with no reference to DebuggerAgent.
"""

from typing import Any, Dict, List, Optional


class DebuggerTools:
    """
    Thin wrappers around CodeParser and PatchGenerator.
    All methods are async for consistency with the agent bus protocol.
    """

    def __init__(self):
        self._tools = {
            "parse_trace":        self.parse_trace,
            "generate_patch":     self.generate_patch,
            "apply_patch":        self.apply_patch,
            "validate_patch":     self.validate_patch,
            "parse_code":         self.parse_code,
            "extract_context":    self.extract_context,
            "extract_function":   self.extract_function,
            "detect_anti_patterns": self.detect_anti_patterns,
        }

    # ------------------------------------------------------------------
    # Stack trace tools
    # ------------------------------------------------------------------

    async def parse_trace(self, trace: str) -> Dict:
        """
        Parse a stack trace using regex patterns.
        Returns structured error info (error_type, root_file, call_chain, …).
        """
        # Import locally to avoid circular dependency
        from agents.debugger.code_parser import CodeParser
        import re

        result = {
            "error_type":    "Unknown",
            "error_message": "",
            "language":      "unknown",
            "root_file":     "",
            "root_line":     0,
            "call_chain":    [],
            "summary":       "",
        }

        if not trace:
            return result

        # Error type + message
        err_match = re.search(
            r"([\w.]+(?:Error|Exception|Panic|Fault|Warning))[\s:]+(.+)", trace
        )
        if err_match:
            result["error_type"]    = err_match.group(1)
            result["error_message"] = err_match.group(2).strip()

        # Python call chain:  File "x.py", line N, in func
        py_frames = re.findall(r'File\s+"([^"]+)",\s*line\s+(\d+)(?:,\s*in\s+(\w+))?', trace)
        if py_frames:
            result["language"] = "python"
            result["call_chain"] = [
                {"file": f, "line": int(l), "function": fn or ""}
                for f, l, fn in py_frames
            ]
            # Innermost (last) frame is the error location
            result["root_file"] = py_frames[-1][0]
            result["root_line"] = int(py_frames[-1][1])

        # Java:  at package.Class.method(File.java:NN)
        java_frames = re.findall(r"at\s+([\w.$]+)\(([\w.]+):(\d+)\)", trace)
        if java_frames and not py_frames:
            result["language"] = "java"
            result["call_chain"] = [
                {"file": f, "line": int(l), "function": m}
                for m, f, l in java_frames
            ]
            result["root_file"] = java_frames[0][1]
            result["root_line"] = int(java_frames[0][2])

        # JavaScript:  at funcName (file.js:NN:CC)
        js_frames = re.findall(r"at\s+(\S+)\s+\(([^:)]+):(\d+):\d+\)", trace)
        if js_frames and not py_frames and not java_frames:
            result["language"] = "javascript"
            result["call_chain"] = [
                {"file": f, "line": int(l), "function": fn}
                for fn, f, l in js_frames
            ]
            result["root_file"] = js_frames[0][1]
            result["root_line"] = int(js_frames[0][2])

        # Go:  goroutine N [running]:  /path/file.go:NN
        go_frames = re.findall(r"([\w./]+\.go):(\d+)", trace)
        if go_frames and not py_frames and not java_frames:
            result["language"] = "go"
            result["call_chain"] = [
                {"file": f, "line": int(l), "function": ""}
                for f, l in go_frames
            ]
            result["root_file"] = go_frames[0][0]
            result["root_line"] = int(go_frames[0][1])

        result["summary"] = (
            f"{result['error_type']} in {result['root_file']} "
            f"line {result['root_line']}: {result['error_message'][:80]}"
            if result["root_file"] else result["error_message"][:120]
        )

        return result

    # ------------------------------------------------------------------
    # Patch tools
    # ------------------------------------------------------------------

    async def generate_patch(
        self,
        original_code: str,
        fixed_code: str,
        file_path: str = "",
        description: str = "",
    ) -> Dict:
        """Generate a unified diff patch between original and fixed code."""
        from agents.debugger.patch_generator import PatchGenerator
        return PatchGenerator().generate(original_code, fixed_code, file_path, description)

    async def apply_patch(self, original_code: str, patch_text: str) -> Optional[str]:
        """Apply a unified diff patch to original code."""
        from agents.debugger.patch_generator import PatchGenerator
        return PatchGenerator().apply_patch(original_code, patch_text)

    async def validate_patch(
        self, original_code: str, fixed_code: str, file_path: str = ""
    ) -> Dict:
        """Validate that a patch is safe (syntax, size, content checks)."""
        from agents.debugger.patch_generator import PatchGenerator
        return PatchGenerator().validate_patch(original_code, fixed_code, file_path)

    # ------------------------------------------------------------------
    # Code analysis tools
    # ------------------------------------------------------------------

    async def parse_code(self, code: str, language: str = "auto") -> Dict:
        """Full structural parse: functions, classes, imports, anti-patterns."""
        from agents.debugger.code_parser import CodeParser
        return CodeParser().parse(code, language)

    async def extract_context(
        self, code: str, error_line: int, context_lines: int = 10
    ) -> Dict:
        """Extract a code window around the error line with markers."""
        from agents.debugger.code_parser import CodeParser
        return CodeParser().extract_error_context(code, error_line, context_lines)

    async def extract_function(
        self, code: str, function_name: str, language: str = "auto"
    ) -> Optional[str]:
        """Extract the body of a named function."""
        from agents.debugger.code_parser import CodeParser
        return CodeParser().extract_function_body(code, function_name, language)

    async def detect_anti_patterns(self, code: str, language: str = "auto") -> List[Dict]:
        """Detect common coding anti-patterns in the source."""
        from agents.debugger.code_parser import CodeParser
        parser = CodeParser()
        if language == "auto":
            language = parser.detect_language(code)
        return parser._detect_anti_patterns(code, language)

    # ------------------------------------------------------------------
    # Registry interface
    # ------------------------------------------------------------------

    def get_tool(self, tool_name: str):
        return self._tools.get(tool_name)

    def list_tools(self) -> List[str]:
        return list(self._tools.keys())
