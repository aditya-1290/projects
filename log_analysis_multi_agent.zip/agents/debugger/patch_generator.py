"""
Patch Generator - Creates, validates, and scores code patches.

Features:
- Unified diff generation (difflib)
- Patch application with proper multi-hunk support
- Patch validation (syntax check for Python, basic structural checks)
- Patch quality scoring
- Revert support
"""

import difflib
import re
from typing import Dict, List, Optional, Tuple


class PatchGenerator:
    """
    Generates, validates, applies, and scores code patches.

    All public methods are synchronous — no async needed for difflib work.
    """

    # ------------------------------------------------------------------
    # Generation
    # ------------------------------------------------------------------

    def generate(
        self,
        original_code: str,
        fixed_code: str,
        file_path: str = "",
        description: str = "",
        context_lines: int = 3,
    ) -> Dict:
        """
        Generate a unified diff patch between original and fixed code.

        Args:
            original_code:  The original (buggy) code.
            fixed_code:     The corrected code.
            file_path:      File path used in the diff header.
            description:    Human-readable description of the fix.
            context_lines:  Lines of context around each change (default 3).

        Returns:
            Dict with: patch, description, file, original_lines, fixed_lines,
                       changes, hunks, quality_score, is_valid, validation_notes.
        """
        if not original_code and not fixed_code:
            return {
                "patch":       "",
                "description": description,
                "file":        file_path,
                "error":       "Both original and fixed code are empty",
                "is_valid":    False,
                "quality_score": 0.0,
            }

        original_lines = original_code.splitlines(keepends=True)
        fixed_lines    = fixed_code.splitlines(keepends=True)

        diff = list(difflib.unified_diff(
            original_lines,
            fixed_lines,
            fromfile=f"a/{file_path}" if file_path else "original",
            tofile=f"b/{file_path}"   if file_path else "fixed",
            n=context_lines,
        ))

        patch_text = "".join(diff)
        hunks      = self._count_hunks(diff)
        added      = sum(1 for l in diff if l.startswith("+") and not l.startswith("+++"))
        removed    = sum(1 for l in diff if l.startswith("-") and not l.startswith("---"))

        validation = self.validate_patch(original_code, fixed_code, file_path)
        quality    = self._score_patch(
            original_code, fixed_code, patch_text, added, removed, validation
        )

        return {
            "patch":            patch_text,
            "description":      description,
            "file":             file_path,
            "original_lines":   len(original_lines),
            "fixed_lines":      len(fixed_lines),
            "lines_added":      added,
            "lines_removed":    removed,
            "changes":          added + removed,
            "hunks":            hunks,
            "is_valid":         validation["is_valid"],
            "validation_notes": validation["notes"],
            "quality_score":    quality,
        }

    def generate_inline(
        self,
        original_code: str,
        error_line: int,
        fixed_line: str,
        file_path: str = "",
        description: str = "",
    ) -> Dict:
        """
        Generate a minimal single-line patch replacing one line.

        Useful when the LLM produces only the corrected line, not the full file.
        """
        lines = original_code.splitlines(keepends=True)
        if error_line < 1 or error_line > len(lines):
            return {"error": f"Line {error_line} out of range (file has {len(lines)} lines)"}

        fixed_lines = lines[:]
        fixed_lines[error_line - 1] = fixed_line.rstrip("\n") + "\n"
        fixed_code = "".join(fixed_lines)
        return self.generate(original_code, fixed_code, file_path, description)

    # ------------------------------------------------------------------
    # Application
    # ------------------------------------------------------------------

    def apply_patch(self, original: str, patch_text: str) -> Optional[str]:
        """
        Apply a unified diff patch to original code.

        Handles multi-hunk patches correctly. Returns None on failure.
        """
        if not patch_text or not patch_text.strip():
            return original

        try:
            original_lines = original.splitlines(keepends=True)
            hunks = self._parse_hunks(patch_text)

            result: List[str] = []
            orig_pos = 0  # 0-based current position in original

            for hunk in hunks:
                orig_start = hunk["orig_start"]  # 0-based

                # Copy unchanged lines before this hunk
                while orig_pos < orig_start:
                    if orig_pos < len(original_lines):
                        result.append(original_lines[orig_pos])
                    orig_pos += 1

                # Apply hunk operations
                for op, line in hunk["ops"]:
                    if op == " ":   # context
                        if orig_pos < len(original_lines):
                            result.append(original_lines[orig_pos])
                        orig_pos += 1
                    elif op == "-": # remove
                        orig_pos += 1
                    elif op == "+": # add
                        result.append(line)

            # Copy remaining original lines
            while orig_pos < len(original_lines):
                result.append(original_lines[orig_pos])
                orig_pos += 1

            return "".join(result)

        except Exception as exc:
            print(f"[PatchGenerator] apply_patch failed: {exc}")
            return None

    def revert_patch(self, patched_code: str, original_code: str) -> str:
        """Revert to original code."""
        return original_code

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def validate_patch(
        self,
        original_code: str,
        fixed_code: str,
        file_path: str = "",
    ) -> Dict:
        """
        Validate that a patch is safe to apply.

        Checks:
        - Code is non-empty after fix
        - Python syntax is valid (if .py file or Python-looking code)
        - The patch doesn't accidentally blank the file
        - Line count change is not extreme (>50% reduction is suspicious)

        Returns:
            {"is_valid": bool, "notes": List[str]}
        """
        notes: List[str] = []
        is_valid = True

        # Empty result check
        if not fixed_code or not fixed_code.strip():
            notes.append("Fixed code is empty — patch would blank the file")
            return {"is_valid": False, "notes": notes}

        # Suspicious line count reduction
        orig_count  = len(original_code.splitlines())
        fixed_count = len(fixed_code.splitlines())
        if orig_count > 10 and fixed_count < orig_count * 0.5:
            notes.append(
                f"Fixed code has {fixed_count} lines vs original {orig_count} "
                f"({100*(1-fixed_count/orig_count):.0f}% reduction — review carefully)"
            )

        # Python syntax check
        is_python = (
            file_path.endswith(".py")
            or ("def " in fixed_code and "import " in fixed_code)
        )
        if is_python:
            syntax_ok, syntax_msg = self._check_python_syntax(fixed_code)
            if not syntax_ok:
                is_valid = False
                notes.append(f"Syntax error in fixed code: {syntax_msg}")
            else:
                notes.append("Python syntax: OK")

        # No changes at all
        if original_code == fixed_code:
            notes.append("Patch makes no changes (original == fixed)")

        return {"is_valid": is_valid, "notes": notes}

    # ------------------------------------------------------------------
    # Quality scoring
    # ------------------------------------------------------------------

    def _score_patch(
        self,
        original: str,
        fixed: str,
        patch_text: str,
        added: int,
        removed: int,
        validation: Dict,
    ) -> float:
        """
        Score a patch on [0.0, 1.0].

        Factors:
        - Passes validation           → base 0.6
        - Minimal change size         → up to +0.2 (fewer lines = better)
        - Has meaningful content      → +0.1
        - No syntax errors (Python)   → +0.1
        """
        if not validation["is_valid"]:
            return 0.0

        score = 0.6

        # Minimality bonus
        total_change = added + removed
        if total_change == 0:
            score -= 0.2  # no change is bad
        elif total_change <= 5:
            score += 0.2
        elif total_change <= 20:
            score += 0.1

        # Content check
        if fixed.strip():
            score += 0.1

        # Syntax OK bonus (only if check ran)
        syntax_note = next(
            (n for n in validation["notes"] if n.startswith("Python syntax")), None
        )
        if syntax_note and "OK" in syntax_note:
            score += 0.1

        return round(min(1.0, max(0.0, score)), 2)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _check_python_syntax(self, code: str) -> Tuple[bool, str]:
        try:
            compile(code, "<string>", "exec")
            return True, ""
        except SyntaxError as e:
            return False, f"line {e.lineno}: {e.msg}"

    def _count_hunks(self, diff_lines: List[str]) -> int:
        return sum(1 for l in diff_lines if l.startswith("@@"))

    def _parse_hunks(self, patch_text: str) -> List[Dict]:
        """
        Parse a unified diff into a list of hunk dicts.

        Each hunk: {"orig_start": int (0-based), "ops": [(op_char, line), ...]}
        """
        hunks: List[Dict] = []
        current_hunk: Optional[Dict] = None
        hunk_header = re.compile(r"^@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@")

        for line in patch_text.splitlines(keepends=True):
            m = hunk_header.match(line)
            if m:
                if current_hunk:
                    hunks.append(current_hunk)
                orig_start = int(m.group(1)) - 1  # convert to 0-based
                current_hunk = {"orig_start": orig_start, "ops": []}
                continue

            if current_hunk is None:
                continue  # skip header lines (---, +++)

            if line.startswith("---") or line.startswith("+++"):
                continue
            elif line.startswith(" "):
                current_hunk["ops"].append((" ", line[1:]))
            elif line.startswith("-"):
                current_hunk["ops"].append(("-", line[1:]))
            elif line.startswith("+"):
                current_hunk["ops"].append(("+", line[1:]))

        if current_hunk:
            hunks.append(current_hunk)

        return hunks
