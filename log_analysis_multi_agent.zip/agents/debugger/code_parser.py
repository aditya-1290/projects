"""
Code Parser - Extracts code structure and error context for debugging.

Supports: Python, Java, JavaScript, TypeScript, Go, Rust, C#, C/C++
"""

import re
from typing import Dict, List, Optional, Tuple


# ---------------------------------------------------------------------------
# Language detection signatures
# ---------------------------------------------------------------------------

_LANG_SIGNATURES: List[Tuple[str, List[str]]] = [
    # (language_name, [patterns that strongly indicate this language])
    ("python",     ["def ", "import ", "elif ", "self.", "print(", "__init__", "async def"]),
    ("java",       ["public class", "private ", "protected ", "void ", "System.out", "@Override", "throws "]),
    ("typescript", ["interface ", ": string", ": number", ": boolean", "=> {", "export default", "as const"]),
    ("javascript", ["function ", "const ", "let ", "var ", "=>", "require(", "module.exports"]),
    ("go",         ["func ", "package ", ":= ", "fmt.Print", "goroutine", "chan ", "defer "]),
    ("rust",       ["fn ", "let mut", "impl ", "use std::", "println!", "match ", "Result<"]),
    ("csharp",     ["namespace ", "using System", "public class", "Console.Write", "async Task", ".NET"]),
    ("cpp",        ["#include", "std::", "cout <<", "nullptr", "template<", "::"]),
    ("c",          ["#include", "printf(", "malloc(", "free(", "struct ", "typedef "]),
    ("ruby",       ["def ", "end", "puts ", "require ", "attr_", ".each do", "class << self"]),
    ("php",        ["<?php", "echo ", "$", "->", "function ", "namespace "]),
]


class CodeParser:
    """
    Parses source code to extract structure useful for debugging.

    Features:
    - Multi-language detection (Python, Java, JS/TS, Go, Rust, C#, C/C++, Ruby, PHP)
    - Extracts functions, classes, imports with line numbers
    - Extracts a focused context window around a specific error line
    - Identifies the function/class that contains the error line
    - Detects common anti-patterns (bare except, unused vars, resource leaks)
    """

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def parse(self, code: str, language: str = "auto") -> Dict:
        """
        Full structural parse of source code.

        Args:
            code:     Source code string.
            language: Language name or "auto" for detection.

        Returns:
            Dict with language, functions, classes, imports, total_lines,
            and anti_patterns detected.
        """
        if not code or not code.strip():
            return self._empty("empty")

        if language == "auto":
            language = self.detect_language(code)

        lines = code.splitlines()

        return {
            "language":      language,
            "total_lines":   len(lines),
            "functions":     self._extract_functions(code, language),
            "classes":       self._extract_classes(code, language),
            "imports":       self._extract_imports(code, language),
            "anti_patterns": self._detect_anti_patterns(code, language),
        }

    def extract_error_context(
        self,
        code: str,
        error_line: int,
        context_lines: int = 10,
    ) -> Dict:
        """
        Extract a window of lines around the error line, plus the
        function/class the error line belongs to.

        Args:
            code:          Full source code.
            error_line:    1-based line number of the error.
            context_lines: How many lines before/after to include.

        Returns:
            Dict with snippet, start_line, end_line, error_line,
            containing_function, containing_class.
        """
        if not code:
            return {}

        lines = code.splitlines()
        total = len(lines)

        if error_line < 1 or error_line > total:
            # Clamp to valid range
            error_line = max(1, min(error_line, total))

        start = max(0, error_line - context_lines - 1)   # 0-based
        end   = min(total, error_line + context_lines)   # exclusive

        snippet_lines = []
        for i, line in enumerate(lines[start:end], start=start + 1):
            marker = ">>>" if i == error_line else "   "
            snippet_lines.append(f"{marker} {i:4d} | {line}")

        language = self.detect_language(code)

        return {
            "snippet":             "\n".join(snippet_lines),
            "start_line":          start + 1,
            "end_line":            end,
            "error_line":          error_line,
            "language":            language,
            "containing_function": self._find_containing_function(code, error_line, language),
            "containing_class":    self._find_containing_class(code, error_line, language),
        }

    def extract_function_body(
        self, code: str, function_name: str, language: str = "auto"
    ) -> Optional[str]:
        """
        Extract the body of a named function from source code.
        Returns None if the function is not found.
        """
        if language == "auto":
            language = self.detect_language(code)

        pattern = self._function_pattern(language)
        if not pattern:
            return None

        lines = code.splitlines()
        in_func = False
        func_lines: List[str] = []
        indent_level: Optional[int] = None

        for line in lines:
            m = pattern.match(line)
            if m and m.group(1) == function_name:
                in_func = True
                func_lines = [line]
                indent_level = len(line) - len(line.lstrip())
                continue

            if in_func:
                current_indent = len(line) - len(line.lstrip()) if line.strip() else indent_level + 1
                if line.strip() == "" or current_indent > indent_level:
                    func_lines.append(line)
                else:
                    break

        return "\n".join(func_lines) if func_lines else None

    # ------------------------------------------------------------------
    # Language detection
    # ------------------------------------------------------------------

    def detect_language(self, code: str) -> str:
        """Score each language by how many of its signatures appear in the code."""
        if not code:
            return "unknown"

        scores: Dict[str, int] = {}
        for lang, sigs in _LANG_SIGNATURES:
            scores[lang] = sum(1 for s in sigs if s in code)

        best_lang = max(scores, key=scores.get)
        return best_lang if scores[best_lang] > 0 else "unknown"

    # ------------------------------------------------------------------
    # Structure extraction
    # ------------------------------------------------------------------

    def _extract_functions(self, code: str, language: str) -> List[Dict]:
        pattern = self._function_pattern(language)
        if not pattern:
            return []
        results = []
        for m in pattern.finditer(code):
            results.append({
                "name": m.group(1),
                "line": code[: m.start()].count("\n") + 1,
            })
        return results

    def _extract_classes(self, code: str, language: str) -> List[Dict]:
        patterns = {
            "python":     re.compile(r"^class\s+(\w+)", re.MULTILINE),
            "java":       re.compile(r"(?:public|private|protected|abstract)?\s*class\s+(\w+)", re.MULTILINE),
            "typescript": re.compile(r"(?:export\s+)?class\s+(\w+)", re.MULTILINE),
            "javascript": re.compile(r"class\s+(\w+)", re.MULTILINE),
            "csharp":     re.compile(r"(?:public|private|internal|protected)?\s*class\s+(\w+)", re.MULTILINE),
            "cpp":        re.compile(r"class\s+(\w+)", re.MULTILINE),
            "rust":       re.compile(r"(?:pub\s+)?struct\s+(\w+)|(?:pub\s+)?enum\s+(\w+)", re.MULTILINE),
        }
        pattern = patterns.get(language)
        if not pattern:
            return []
        results = []
        for m in pattern.finditer(code):
            name = m.group(1) or (m.lastindex and m.group(m.lastindex))
            if name:
                results.append({"name": name, "line": code[: m.start()].count("\n") + 1})
        return results

    def _extract_imports(self, code: str, language: str) -> List[str]:
        lines = code.splitlines()
        import_starters = {
            "python":     ("import ", "from "),
            "java":       ("import ",),
            "typescript": ("import ", "require("),
            "javascript": ("import ", "const ", "require("),
            "go":         ("import ",),
            "rust":       ("use ",),
            "csharp":     ("using ",),
            "cpp":        ("#include",),
            "c":          ("#include",),
            "ruby":       ("require ", "require_relative "),
            "php":        ("use ", "require ", "include "),
        }
        starters = import_starters.get(language, ("import ",))
        return [
            line.strip()
            for line in lines
            if any(line.strip().startswith(s) for s in starters)
        ]

    # ------------------------------------------------------------------
    # Anti-pattern detection
    # ------------------------------------------------------------------

    def _detect_anti_patterns(self, code: str, language: str) -> List[Dict]:
        """Flag common coding anti-patterns that might cause bugs."""
        findings: List[Dict] = []
        lines = code.splitlines()

        checks = self._get_anti_pattern_checks(language)
        for lineno, line in enumerate(lines, 1):
            for pattern, name, severity in checks:
                if pattern.search(line):
                    findings.append({
                        "line":        lineno,
                        "pattern":     name,
                        "severity":    severity,
                        "code_line":   line.strip(),
                    })

        return findings

    def _get_anti_pattern_checks(self, language: str) -> List[Tuple]:
        """Return (compiled_regex, name, severity) tuples per language."""
        common = [
            (re.compile(r"\bTODO\b|\bFIXME\b|\bHACK\b|\bBUG\b"),  "todo_comment",      "info"),
        ]
        python_checks = [
            (re.compile(r"^\s*except\s*:"),              "bare_except",          "warning"),
            (re.compile(r"^\s*except\s+Exception\s*:"),  "broad_except",         "info"),
            (re.compile(r"pass\s*$"),                    "empty_block",          "info"),
            (re.compile(r"global\s+\w+"),                "global_variable",      "warning"),
            (re.compile(r"eval\("),                      "eval_usage",           "warning"),
            (re.compile(r"exec\("),                      "exec_usage",           "warning"),
            (re.compile(r"open\([^)]+\)(?!\s*as\b)"),   "unclosed_file",        "warning"),
        ]
        java_checks = [
            (re.compile(r"catch\s*\(\s*Exception\s+"),   "broad_exception_catch","warning"),
            (re.compile(r"System\.exit\("),              "system_exit",          "warning"),
            (re.compile(r"\.printStackTrace\(\)"),       "printStackTrace",      "info"),
        ]
        js_checks = [
            (re.compile(r"\beval\("),                    "eval_usage",           "warning"),
            (re.compile(r"var\s+"),                      "var_declaration",      "info"),
            (re.compile(r"==\s"),                        "loose_equality",       "info"),
        ]

        lang_map = {
            "python":     common + python_checks,
            "java":       common + java_checks,
            "javascript": common + js_checks,
            "typescript": common + js_checks,
        }
        return lang_map.get(language, common)

    # ------------------------------------------------------------------
    # Context helpers
    # ------------------------------------------------------------------

    def _find_containing_function(
        self, code: str, error_line: int, language: str
    ) -> Optional[str]:
        """Walk backwards from error_line to find the enclosing function."""
        pattern = self._function_pattern(language)
        if not pattern:
            return None
        lines = code.splitlines()
        for i in range(min(error_line - 1, len(lines) - 1), -1, -1):
            m = pattern.match(lines[i])
            if m:
                return m.group(1)
        return None

    def _find_containing_class(
        self, code: str, error_line: int, language: str
    ) -> Optional[str]:
        """Walk backwards from error_line to find the enclosing class."""
        patterns = {
            "python":     re.compile(r"^class\s+(\w+)"),
            "java":       re.compile(r"class\s+(\w+)"),
            "typescript": re.compile(r"class\s+(\w+)"),
            "javascript": re.compile(r"class\s+(\w+)"),
            "csharp":     re.compile(r"class\s+(\w+)"),
        }
        pattern = patterns.get(language)
        if not pattern:
            return None
        lines = code.splitlines()
        for i in range(min(error_line - 1, len(lines) - 1), -1, -1):
            m = pattern.match(lines[i])
            if m:
                return m.group(1)
        return None

    # ------------------------------------------------------------------
    # Utility
    # ------------------------------------------------------------------

    def _function_pattern(self, language: str) -> Optional[re.Pattern]:
        patterns = {
            "python":     re.compile(r"^\s*(?:async\s+)?def\s+(\w+)\s*\(", re.MULTILINE),
            "java":       re.compile(r"(?:public|private|protected|static|\s)+[\w<>]+\s+(\w+)\s*\(", re.MULTILINE),
            "typescript": re.compile(r"(?:async\s+)?(?:function\s+(\w+)|(\w+)\s*(?:=\s*(?:async\s+)?\())", re.MULTILINE),
            "javascript": re.compile(r"(?:async\s+)?function\s+(\w+)\s*\(|(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s+)?\(", re.MULTILINE),
            "go":         re.compile(r"^func\s+(?:\([^)]*\)\s+)?(\w+)\s*\(", re.MULTILINE),
            "rust":       re.compile(r"^(?:pub\s+)?(?:async\s+)?fn\s+(\w+)\s*", re.MULTILINE),
            "csharp":     re.compile(r"(?:public|private|protected|internal|static|\s)+[\w<>]+\s+(\w+)\s*\(", re.MULTILINE),
            "cpp":        re.compile(r"[\w:*&]+\s+(\w+)\s*\([^;]*\)\s*(?:const\s*)?\{", re.MULTILINE),
            "ruby":       re.compile(r"^\s*def\s+(\w+)", re.MULTILINE),
            "php":        re.compile(r"function\s+(\w+)\s*\(", re.MULTILINE),
        }
        return patterns.get(language)

    def _empty(self, language: str) -> Dict:
        return {
            "language":      language,
            "total_lines":   0,
            "functions":     [],
            "classes":       [],
            "imports":       [],
            "anti_patterns": [],
        }
