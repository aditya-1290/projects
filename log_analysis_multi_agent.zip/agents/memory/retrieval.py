"""
Log Retrieval - Handles retrieval strategies for past log analyses
"""

from typing import Dict, List, Optional
import re


class LogRetrieval:
    """Retrieves relevant past analyses using various strategies"""

    def __init__(self, vector_store):
        self.vector_store = vector_store

    async def find_similar(
            self,
            query: str,
            limit: int = 5,
            log_type: str = None
    ) -> List[Dict]:
        """
        Find similar past log analyses.

        Uses:
        1. Vector similarity search
        2. Error pattern matching
        3. Keyword extraction
        """
        filter_criteria = None
        if log_type:
            filter_criteria = {"log_type": log_type}

        # Vector search
        results = await self.vector_store.search(
            query=query,
            limit=limit,
            filter_criteria=filter_criteria
        )

        # Enrich results
        enriched = []
        for result in results:
            enriched.append({
                **result,
                "relevance": self._calculate_relevance(query, result),
                "error_patterns": self._extract_error_patterns(result.get("content", ""))
            })

        # Sort by relevance
        enriched.sort(key=lambda x: x.get("relevance", 0), reverse=True)

        return enriched[:limit]

    async def search_by_pattern(
            self,
            error_pattern: str,
            log_type: str = None
    ) -> List[Dict]:
        """Search specifically by error pattern"""
        # Extract key terms
        key_terms = self._extract_key_terms(error_pattern)

        if not key_terms:
            return []

        # Search with each key term
        all_results = []
        for term in key_terms[:3]:
            results = await self.vector_store.search(
                query=term,
                limit=3,
                filter_criteria={"log_type": log_type} if log_type else None
            )
            all_results.extend(results)

        # Deduplicate
        seen_ids = set()
        unique_results = []
        for result in all_results:
            if result["id"] not in seen_ids:
                seen_ids.add(result["id"])
                unique_results.append(result)

        return unique_results[:5]

    def _calculate_relevance(self, query: str, result: Dict) -> float:
        """Calculate relevance score between query and result"""
        query_lower = query.lower()
        content = result.get("content", "").lower()
        metadata = result.get("metadata", {})

        score = result.get("similarity", 0.0)

        # Boost if same log type
        if metadata.get("log_type") and metadata["log_type"] in query_lower:
            score += 0.2

        # Boost if same severity
        severity = metadata.get("severity")
        if severity and severity.lower() in query_lower:
            score += 0.1

        # Boost for keyword matches
        query_keywords = set(self._extract_key_terms(query))
        content_keywords = set(self._extract_key_terms(content))
        common = query_keywords & content_keywords

        if query_keywords:
            keyword_score = len(common) / len(query_keywords) * 0.3
            score += keyword_score

        return min(score, 1.0)

    def _extract_error_patterns(self, text: str) -> List[str]:
        """Extract error patterns from text"""
        patterns = []

        # Look for common error indicators
        error_regexes = [
            re.compile(r'(?:Error|Exception|FATAL|CRITICAL):?\s*([^\n]+)', re.IGNORECASE),
            re.compile(r'(?:failed|failure):?\s*([^\n]+)', re.IGNORECASE),
            re.compile(r'(?:null|timeout|refused|denied|not found)[^\n]*', re.IGNORECASE),
        ]

        for regex in error_regexes:
            matches = regex.findall(text)
            patterns.extend(matches)

        return patterns[:5]

    def _extract_key_terms(self, text: str) -> List[str]:
        """Extract key terms for searching"""
        # Remove common words
        stop_words = {
            'the', 'a', 'an', 'is', 'are', 'was', 'were', 'in', 'on', 'at',
            'to', 'for', 'of', 'with', 'and', 'or', 'but', 'not', 'this',
            'that', 'it', 'be', 'has', 'have', 'had', 'do', 'does', 'did'
        }

        # Extract words
        words = re.findall(r'\b[a-zA-Z]{3,}\b', text.lower())

        # Filter stop words
        terms = [w for w in words if w not in stop_words]

        # Count frequency
        from collections import Counter
        term_counts = Counter(terms)

        # Return top terms
        return [term for term, count in term_counts.most_common(10)]