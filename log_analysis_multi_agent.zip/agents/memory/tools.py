"""
Tools registered to the Memory Agent
"""

from typing import Dict, Any, List


class MemoryTools:
    """Collection of tools available to the Memory agent"""

    def __init__(self):
        self.tools = {
            "store_analysis": self.store_analysis,
            "retrieve_similar": self.retrieve_similar,
            "search_by_pattern": self.search_by_pattern,
            "get_stats": self.get_stats,
        }

    async def store_analysis(
            self, log_content: str, analysis: Dict, log_type: str
    ) -> str:
        """Store a log analysis result"""
        from agents.memory.vector_store import VectorStore
        store = VectorStore()
        await store.initialize()
        return await store.store_analysis(log_content, analysis, log_type)

    async def retrieve_similar(self, query: str, limit: int = 5) -> List[Dict]:
        """Retrieve similar past analyses"""
        from agents.memory.vector_store import VectorStore
        from agents.memory.retrieval import LogRetrieval

        store = VectorStore()
        await store.initialize()
        retrieval = LogRetrieval(store)
        return await retrieval.find_similar(query, limit=limit)

    async def search_by_pattern(self, error_pattern: str, log_type: str = None) -> List[Dict]:
        """Search by error pattern"""
        from agents.memory.vector_store import VectorStore
        from agents.memory.retrieval import LogRetrieval

        store = VectorStore()
        await store.initialize()
        retrieval = LogRetrieval(store)
        return await retrieval.search_by_pattern(error_pattern, log_type)

    async def get_stats(self) -> Dict:
        """Get memory store statistics"""
        from agents.memory.vector_store import VectorStore
        store = VectorStore()
        await store.initialize()
        return store.get_stats()

    def get_tool(self, tool_name: str):
        """Get a tool by name"""
        return self.tools.get(tool_name)
    