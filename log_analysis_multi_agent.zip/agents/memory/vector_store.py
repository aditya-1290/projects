"""
Vector Store - ChromaDB wrapper for storing log analysis embeddings
"""

import os
import uuid
from typing import Dict, List, Optional, Any
from datetime import datetime


class VectorStore:
    """Manages vector storage using ChromaDB"""

    def __init__(self, persist_directory: str = None):
        if persist_directory is None:
            from config import CHROMA_DIR
            persist_directory = str(CHROMA_DIR)

        self.persist_directory = persist_directory
        self.collection = None
        self.client = None
        self.embedding_model = None

    async def initialize(self):
        """Initialize ChromaDB client and collection"""
        try:
            import chromadb

            # Ensure directory exists
            os.makedirs(self.persist_directory, exist_ok=True)

            # New ChromaDB API (v0.4+)
            self.client = chromadb.PersistentClient(
                path=self.persist_directory,
                settings=chromadb.Settings(
                    anonymized_telemetry=False
                )
            )

            # Get or create collection
            try:
                self.collection = self.client.get_collection("log_analyses")
            except Exception:
                self.collection = self.client.create_collection(
                    name="log_analyses",
                    metadata={"description": "Log analysis results with embeddings"}
                )

            print(f"[MEMORY] Vector store initialized at {self.persist_directory}")
            print(f"[MEMORY] Collection has {self.collection.count()} documents")

        except ImportError:
            print("[MEMORY] ChromaDB not available - using in-memory mock")
            self._init_mock()
        except Exception as e:
            print(f"[MEMORY] Failed to initialize ChromaDB: {e}")
            self._init_mock()

    def _init_mock(self):
        """Initialize mock vector store for development"""
        self._mock_documents = []
        self._mock_embeddings = {}

    async def store_analysis(
            self,
            log_content: str,
            analysis: Dict,
            log_type: str,
            metadata: Dict = None
    ) -> str:
        """
        Store a log analysis in the vector store.

        Returns:
            document_id: Unique identifier for the stored document
        """
        document_id = str(uuid.uuid4())

        # Prepare metadata
        doc_metadata = {
            "log_type": log_type,
            "timestamp": datetime.now().isoformat(),
            "content_length": len(log_content),
            **(metadata or {})
        }

        # Add analysis fields to metadata
        if isinstance(analysis, dict):
            doc_metadata["root_cause"] = str(analysis.get("root_cause", {}).get("primary_cause", ""))[:200]
            doc_metadata["severity"] = str(analysis.get("root_cause", {}).get("severity", "unknown"))

        if self.collection:
            try:
                # Get embedding
                embedding = await self._get_embedding(log_content[:1000])

                self.collection.add(
                    ids=[document_id],
                    embeddings=[embedding] if embedding else None,
                    documents=[log_content[:5000]],  # Store first 5000 chars
                    metadatas=[doc_metadata]
                )

                return document_id

            except Exception as e:
                print(f"[MEMORY] Store failed: {e}")

        # Mock storage
        self._mock_documents.append({
            "id": document_id,
            "content": log_content,
            "analysis": analysis,
            "metadata": doc_metadata
        })

        return document_id

    async def search(
            self,
            query: str,
            limit: int = 5,
            filter_criteria: Dict = None
    ) -> List[Dict]:
        """
        Search for similar log analyses.

        Returns:
            List of matching documents with similarity scores
        """
        if self.collection:
            try:
                query_embedding = await self._get_embedding(query[:1000])

                results = self.collection.query(
                    query_embeddings=[query_embedding] if query_embedding else None,
                    n_results=limit,
                    where=filter_criteria
                )

                return self._format_results(results)

            except Exception as e:
                print(f"[MEMORY] Search failed: {e}")

        # Mock search
        return self._mock_search(query, limit)

    async def _get_embedding(self, text: str) -> Optional[List[float]]:
        """Get embedding for text"""
        try:
            if self.embedding_model is None:
                from sentence_transformers import SentenceTransformer
                self.embedding_model = SentenceTransformer('all-MiniLM-L6-v2')

            embedding = self.embedding_model.encode(text)
            return embedding.tolist()
        except Exception:
            return None

    def _format_results(self, results: Dict) -> List[Dict]:
        """Format ChromaDB results"""
        formatted = []

        if not results or not results.get("ids"):
            return formatted

        ids = results["ids"][0] if results["ids"] else []
        documents = results["documents"][0] if results.get("documents") else []
        metadatas = results["metadatas"][0] if results.get("metadatas") else []
        distances = results["distances"][0] if results.get("distances") else []

        for i in range(len(ids)):
            formatted.append({
                "id": ids[i],
                "content": documents[i] if i < len(documents) else "",
                "metadata": metadatas[i] if i < len(metadatas) else {},
                "similarity": 1 - distances[i] if i < len(distances) else 0.0
            })

        return formatted

    def _mock_search(self, query: str, limit: int) -> List[Dict]:
        """Mock search for development"""
        results = []
        query_lower = query.lower()

        for doc in self._mock_documents[:limit]:
            # Simple keyword matching
            content = doc.get("content", "").lower()
            score = 0.0

            # Count matching words
            query_words = set(query_lower.split())
            content_words = set(content.split())
            matches = query_words & content_words

            if query_words:
                score = len(matches) / len(query_words)

            if score > 0.1:
                results.append({
                    "id": doc["id"],
                    "content": doc["content"][:500],
                    "metadata": doc.get("metadata", {}),
                    "similarity": score
                })

        results.sort(key=lambda x: x["similarity"], reverse=True)
        return results[:limit]

    def get_stats(self) -> Dict:
        """Get vector store statistics"""
        if self.collection:
            return {
                "total_documents": self.collection.count(),
                "storage_path": self.persist_directory
            }
        return {
            "total_documents": len(self._mock_documents),
            "storage_path": "mock (in-memory)"
        }
