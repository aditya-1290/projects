"""
Solver Agent

Uses Gemma-4-E4B for root cause analysis, fix generation, and explanations.
This is the core reasoning agent in the pipeline.
"""

from typing import Dict, Any, List

from agents.base_agent import BaseAgent, A2AMessage, MessageType, AgentResponse
from agents.solver.prompts import (
    SKILL_ROOT_CAUSE_ANALYSIS,
    SKILL_FIX_GENERATION,
    SKILL_EXPLANATION_GENERATION,
    SKILL_LOG_SUMMARIZATION,
    SKILL_ERROR_SIGNATURE_MATCHING,
    SKILL_PREVENTION_RECOMMENDATION,
    SKILL_IMPACT_ASSESSMENT,
    SKILL_CASCADING_FAILURE_ANALYSIS,
    SKILL_TIMELINE_RECONSTRUCTION,
    SKILL_TECHNICAL_DEEP_DIVE,
    SKILL_EXECUTIVE_SUMMARY,
)

class SolverAgent(BaseAgent):
    """Analyzes logs and generates solutions"""

    def __init__(self):
        super().__init__("solver_v1", "agents/solver/capabilities.json")

        # ═══════════════════════════════════════════════════════════════════════════
        # ADK Integration
        # ═══════════════════════════════════════════════════════════════════════════

    def _get_model_requirements(self) -> list:
        return ["gemma-4-e4b-it"]

    def _resolve_adk_model(self) -> str:
        return "gemma-4-e4b-it"

    def _build_adk_instruction(self) -> str:
        """Build the solver's ADK instruction from skill prompts."""
        # from agents.solver.prompts import (
        #     SKILL_ROOT_CAUSE_ANALYSIS,
        #     SKILL_FIX_GENERATION,
        #     SKILL_EXPLANATION_GENERATION,
        # )

        return f"""You are the Solver Agent for a log analysis system.

    Your job is to analyze log entries and provide:
    1. ROOT CAUSE ANALYSIS — Identify the primary cause with evidence
    2. FIX SUGGESTIONS — Generate actionable, specific fixes
    3. EXPLANATIONS — Produce clear explanations at the right technical level

    When analyzing:
    - Find the FIRST error — it's usually the trigger, not the symptom
    - Separate cause from symptom — "Connection refused" is a cause, "500 error" is a symptom
    - Check dependencies first (database, network, file system)
    - Cite specific log lines as evidence
    - Provide fixes at three levels: immediate mitigation, short-term fix, long-term prevention

    Always respond with structured JSON containing root_cause, fix_suggestion, and explanation fields.
    If you're unsure about something, reduce your confidence score — don't guess.
    """

    async def _handle_summarization(self, message: A2AMessage, skill_name: str) -> A2AMessage:
        """Generate a concise log summary."""
        task = message.task or {}
        context = message.context or {}

        clean_logs = context.get("clean_logs", "") or task.get("clean_logs", "")
        log_type = context.get("log_type", "unknown")
        severity = context.get("severity", "unknown")
        technologies = context.get("technologies", "")
        entry_count = context.get("entry_count", 0)

        if not clean_logs:
            return A2AMessage(
                message_type=MessageType.ERROR,
                sender_id=self.agent_id,
                sender_type="solver",
                target_id=message.sender_id,
                correlation_id=message.message_id,
                error="No logs provided for summarization"
            )

        try:
            model = await self.get_model("gemma")
            prompt = SKILL_LOG_SUMMARIZATION.format(
                clean_logs=clean_logs[:3000],
                log_type=log_type,
                severity=severity,
                entry_count=entry_count,
                technologies=technologies,
            )

            raw = await self._generate_with_tracking(model, prompt, max_tokens=512, action_name="summarize_logs")
            raw_text = raw.text if hasattr(raw, "text") else str(raw)
            result = self._extract_json(raw_text) if hasattr(self, '_extract_json') else {}

            return A2AMessage(
                message_type=MessageType.RESPONSE,
                sender_id=self.agent_id,
                sender_type="solver",
                target_id=message.sender_id,
                correlation_id=message.message_id,
                response={
                    "summary": result.get("summary", raw[:500]),
                    "severity_counts": result.get("severity_counts", {}),
                    "top_errors": result.get("top_errors", []),
                    "affected_services": result.get("affected_services", []),
                    "overall_assessment": result.get("overall_assessment", "unknown"),
                    "recommended_action": result.get("recommended_action"),
                    "skill_used": skill_name,
                },
                confidence=result.get("confidence", 0.8),
            )

        except Exception as e:
            self.log(f"Summarization error: {e}", "ERROR")
            return A2AMessage(
                message_type=MessageType.ERROR,
                sender_id=self.agent_id,
                sender_type="solver",
                target_id=message.sender_id,
                error=f"Summarization failed: {str(e)}"
            )

    async def process(self, message: A2AMessage) -> A2AMessage:
        """Process log analysis request and generate solutions"""
        task = message.task or {}
        context = message.context or {}
        self.log_agent_event("process_start", {"input_size": len(str(message.task)), "action": message.task.get("action", "unknown")})

        action = task.get("action", "solve")

        # NEW: Handle summarization
        if action == "summarize":
            return await self._handle_summarization(message)

        if action == "analyze_root_cause":
            return await self._handle_root_cause_analysis(message)
        elif action == "generate_fix":
            return await self._handle_fix_generation(message)
        elif action == "explain":
            return await self._handle_explanation(message)
        else:
            # Full solve pipeline
            return await self._handle_full_solve(message)

    async def _handle_full_solve(self, message: A2AMessage) -> A2AMessage:
        """Run the complete solve pipeline"""
        task = message.task or {}
        context = message.context or {}

        clean_logs = context.get("clean_logs", "") or task.get("clean_logs", "")
        log_type = context.get("log_type", "unknown")
        intent = context.get("intent", "debugging")

        if not clean_logs:
            return A2AMessage(
                message_type=MessageType.ERROR,
                sender_id=self.agent_id,
                sender_type="solver",
                target_id=message.sender_id,
                correlation_id=message.message_id,
                error="No logs provided for analysis"
            )

        self.log(f"Solving: type={log_type}, intent={intent}")

        # 🔥 Extract key error line manually (improves LLM performance)
        error_line = None
        for line in clean_logs.split("\n"):
            if "Error" in line or "Exception" in line:
                error_line = line.strip()
                break

        context["error_line"] = error_line
        # Inject memory context (similar past cases) into logs for better analysis
        memory_context = context.get("memory_context") or task.get("memory_context", "")
        if memory_context:
            clean_logs = memory_context + "\n\n=== CURRENT LOGS ===\n" + clean_logs
            self.log("Memory context prepended to logs for analysis")
        # Select skills for each step
        severity = context.get("severity", "INFO")
        rca_skill, rca_skill_name = self._select_solver_skill("rca", clean_logs, log_type, severity)
        fix_skill, fix_skill_name = self._select_solver_skill("fix", clean_logs, log_type, severity)
        explain_skill, explain_skill_name = self._select_solver_skill("explain", clean_logs, log_type, severity)
        self.log(f"Solver skills: RCA={rca_skill_name}, Fix={fix_skill_name}, Explain={explain_skill_name}", "INFO")

        try:
            model = await self.get_model("gemma")

            # Step 1: Root cause analysis
            self.log("Step 1/3: Root cause analysis...")
            # 🔥 BOOST SIGNAL FROM CONTEXT
            if "NameError" in clean_logs:
                context["error_hint"] = "NameError"
            root_cause = await self._analyze_root_cause(
                clean_logs + f"\n\nKey Error Line:\n{error_line}",
                log_type,
                model
            )

            # Step 2: Generate fix
            self.log("Step 2/3: Generating fix...")
            fix = await self._generate_fix(
                clean_logs, root_cause, log_type, model
            )

            # Step 3: Generate explanation
            self.log("Step 3/3: Generating explanation...")
            explanation = await self._generate_explanation(
                root_cause, fix, intent, model
            )

            return A2AMessage(
                message_type=MessageType.RESPONSE,
                sender_id=self.agent_id,
                sender_type="solver",
                target_id=message.sender_id,
                correlation_id=message.message_id,
                response={
                    "root_cause": root_cause,
                    "fix_suggestion": fix,
                    "explanation": explanation,
                    "log_type": log_type,
                    "intent": intent,

                    # 🔥 CRITICAL ADDITION
                    "solution": {
                        "root_cause": root_cause,
                        "fix": fix,
                        "explanation": explanation
                    },

                    # 🔥 pass forward for critic
                    "analysis": context.get("analysis"),
                    "skills_used": [rca_skill_name, fix_skill_name, explain_skill_name],
                },
                confidence=self._calculate_confidence(root_cause, fix),
                caveats=self._generate_caveats(log_type),
                context=message.context
            )

        except Exception as e:
            self.log(f"Error: {e}", "ERROR")
            return A2AMessage(
                message_type=MessageType.ERROR,
                sender_id=self.agent_id,
                sender_type="solver",
                target_id=message.sender_id,
                correlation_id=message.message_id,
                error=f"Analysis failed: {str(e)}"
            )

    async def _analyze_root_cause(
            self, logs: str, log_type: str, model
    ) -> Dict:
        """Analyze logs to find root cause"""
        from agents.solver.error_analyzer import ErrorAnalyzer
        analyzer = ErrorAnalyzer()
        return await analyzer.analyze(logs, log_type, model)

    async def _generate_fix(
            self, logs: str, root_cause: Dict, log_type: str, model
    ) -> Dict:
        """Generate fix suggestions"""
        from agents.solver.fix_generator import FixGenerator
        generator = FixGenerator()
        return await generator.generate(logs, root_cause, log_type, model)

    async def _generate_explanation(
            self, root_cause: Dict, fix: Dict, intent: str, model
    ) -> str:
        """Generate human-readable explanation"""
        from agents.solver.explanation_generator import ExplanationGenerator
        generator = ExplanationGenerator()
        return await generator.generate(root_cause, fix, intent, model)

    async def _handle_root_cause_analysis(self, message: A2AMessage, skill_name: str) -> A2AMessage:
        """Handle explicit root cause analysis request"""
        # Similar to _handle_full_solve but only step 1
        task = message.task or {}
        context = message.context or {}

        clean_logs = context.get("clean_logs", "") or task.get("clean_logs", "")
        log_type = context.get("log_type", "unknown")

        model = await self.get_model("gemma")
        root_cause = await self._analyze_root_cause(clean_logs, log_type, model)

        return A2AMessage(
            message_type=MessageType.RESPONSE,
            sender_id=self.agent_id,
            sender_type="solver",
            target_id=message.sender_id,
            correlation_id=message.message_id,
            response={"root_cause": root_cause, "skill_used": skill_name,},
            confidence=root_cause.get("confidence", 0.7)
        )

    async def _handle_fix_generation(self, message: A2AMessage, skill_name: str) -> A2AMessage:
        """Handle explicit fix generation request"""
        task = message.task or {}
        context = message.context or {}

        clean_logs = context.get("clean_logs", "")
        root_cause = context.get("root_cause", task.get("root_cause", {}))
        log_type = context.get("log_type", "unknown")

        model = await self.get_model("gemma")
        fix = await self._generate_fix(clean_logs, root_cause, log_type, model)

        return A2AMessage(
            message_type=MessageType.RESPONSE,
            sender_id=self.agent_id,
            sender_type="solver",
            target_id=message.sender_id,
            correlation_id=message.message_id,
            response={"fix_suggestion": fix, "skill_used": skill_name,},
            confidence=0.8
        )

    async def _handle_explanation(self, message: A2AMessage, skill_name: str) -> A2AMessage:
        """Handle explicit explanation request"""
        task = message.task or {}
        context = message.context or {}

        root_cause = context.get("root_cause", task.get("root_cause", {}))
        fix = context.get("fix_suggestion", task.get("fix", {}))
        intent = context.get("intent", "explanation")

        model = await self.get_model("gemma")
        explanation = await self._generate_explanation(root_cause, fix, intent, model)

        return A2AMessage(
            message_type=MessageType.RESPONSE,
            sender_id=self.agent_id,
            sender_type="solver",
            target_id=message.sender_id,
            correlation_id=message.message_id,
            response={"explanation": explanation, "skill_used": skill_name,},
            confidence=0.85
        )

    def _calculate_confidence(self, root_cause: Dict, fix: Dict) -> float:
        """Calculate overall confidence score"""
        rc_conf = root_cause.get("confidence", 0.5)
        fix_conf = fix.get("confidence", 0.5)
        return round((rc_conf + fix_conf) / 2, 2)

    def _select_solver_skill(self, step: str, clean_logs: str, log_type: str, severity: str):
        """Select the best solver skill based on pipeline step and log characteristics.
        Returns (prompt_template, skill_name)."""

        has_multiple_errors = clean_logs.lower().count('error') + clean_logs.lower().count('exception') > 3
        has_timeline = any(c.isdigit() for c in clean_logs[:200])
        has_cascade = any(kw in clean_logs[:1000].lower() for kw in ['caused by', 'cascading', 'propagation', 'chain'])

        if step == "rca":
            if has_cascade:
                return SKILL_CASCADING_FAILURE_ANALYSIS, "cascading_failure_analysis"
            if has_timeline and has_multiple_errors:
                return SKILL_TIMELINE_RECONSTRUCTION, "timeline_reconstruction"
            return SKILL_ROOT_CAUSE_ANALYSIS, "root_cause_analysis"

        elif step == "fix":
            return SKILL_FIX_GENERATION, "fix_generation"

        elif step == "explain":
            if severity == "CRITICAL" or has_multiple_errors:
                return SKILL_TECHNICAL_DEEP_DIVE, "technical_deep_dive"
            return SKILL_EXPLANATION_GENERATION, "explanation_generation"

        elif step == "summary":
            return SKILL_LOG_SUMMARIZATION, "log_summarization"

        elif step == "prevent":
            return SKILL_PREVENTION_RECOMMENDATION, "prevention_recommendation"

        elif step == "impact":
            return SKILL_IMPACT_ASSESSMENT, "impact_assessment"

        elif step == "signature":
            return SKILL_ERROR_SIGNATURE_MATCHING, "error_signature_matching"

        return SKILL_EXECUTIVE_SUMMARY, "executive_summary"

    def _generate_caveats(self, log_type: str) -> List[str]:
        """Generate appropriate caveats"""
        caveats = [
            "This analysis is based on the provided logs only",
            "Verify all suggestions in a test environment first",
            "Consider system-specific configurations"
        ]

        if log_type == "database_error":
            caveats.append("Database changes should be reviewed by a DBA")
        elif log_type == "security":
            caveats.append("Security fixes may require immediate attention")
        elif log_type == "network_error":
            caveats.append("Network changes may affect connectivity")

        return caveats

