"""
Error Analyzer - Performs root cause analysis on logs
"""

import re
from typing import Dict, Any, List


class ErrorAnalyzer:
    """Analyzes logs to identify root causes"""

    # Common error patterns
    ERROR_PATTERNS = {
        "null_pointer": re.compile(r'NullPointerException|null\s+pointer', re.IGNORECASE),
        "connection_refused": re.compile(r'Connection\s+refused', re.IGNORECASE),
        "timeout": re.compile(r'timeout|timed?\s+out', re.IGNORECASE),
        "out_of_memory": re.compile(r'OutOfMemory|out\s+of\s+memory', re.IGNORECASE),
        "permission_denied": re.compile(r'Permission\s+denied|Access\s+denied', re.IGNORECASE),
        "file_not_found": re.compile(r'No\s+such\s+file|FileNotFound|file\s+not\s+found', re.IGNORECASE),
        "disk_full": re.compile(r'No\s+space\s+left|disk\s+full', re.IGNORECASE),
        "syntax_error": re.compile(r'SyntaxError|syntax\s+error', re.IGNORECASE),
        "config_error": re.compile(r'Configuration\s+error|invalid\s+config', re.IGNORECASE),
        "authentication_failed": re.compile(r'Authentication\s+failed|login\s+failed|unauthorized', re.IGNORECASE),
    }

    async def analyze(
            self, logs: str, log_type: str, model=None
    ) -> Dict[str, Any]:
        """
        Analyze logs for root cause.

        Returns:
            {
                "primary_cause": str,
                "cause_category": str,
                "confidence": float,
                "evidence": List[str],
                "possible_causes": List[str],
                "severity": str,
                "affected_components": List[str]
            }
        """
        # Pattern-based analysis
        pattern_results = self._pattern_analysis(logs)

        # If model available, do deep analysis
        if model:
            deep_results = await self._deep_analysis(logs, log_type, pattern_results, model)
            return deep_results

        return pattern_results

    def _pattern_analysis(self, logs: str) -> Dict:
        """Quick pattern-based analysis without LLM"""
        logs_lower = logs.lower()

        findings = []
        for error_type, pattern in self.ERROR_PATTERNS.items():
            matches = pattern.findall(logs)
            if matches:
                findings.append({
                    "type": error_type,
                    "count": len(matches),
                    "examples": matches[:3]
                })

        # Sort by count
        findings.sort(key=lambda x: x["count"], reverse=True)

        if not findings:
            return {
                "primary_cause": "Unknown error pattern",
                "cause_category": "unknown",
                "confidence": 0.2,
                "evidence": [],
                "possible_causes": ["Unable to identify error pattern from logs"],
                "severity": "unknown",
                "affected_components": []
            }

        primary = findings[0]

        return {
            "primary_cause": self._describe_cause(primary["type"]),
            "cause_category": primary["type"],
            "confidence": min(0.3 + (primary["count"] * 0.1), 0.7),
            "evidence": primary["examples"],
            "possible_causes": [self._describe_cause(f["type"]) for f in findings],
            "severity": self._estimate_severity(findings),
            "affected_components": self._identify_components(logs)
        }

    async def _deep_analysis(
            self, logs: str, log_type: str, pattern_results: Dict, model
    ) -> Dict:
        """Use LLM for deep root cause analysis"""
        prompt = f"""Analyze these log entries and determine the root cause.

Log Type: {log_type}

Pattern Analysis Results:
{pattern_results}

Log Entries:
{logs[:3000]}

Provide a detailed analysis in JSON format:
{{
    "primary_cause": "Main root cause identified",
    "cause_category": "category",
    "confidence": 0.0-1.0,
    "evidence": ["evidence line 1", "evidence line 2"],
    "possible_causes": ["alternative cause 1", "alternative cause 2"],
    "severity": "CRITICAL|ERROR|WARNING|INFO",
    "affected_components": ["component1", "component2"],
    "timeline": "Sequence of events",
    "impact_assessment": "What is affected",
    "recommended_actions": ["action 1", "action 2"]
}}

Analysis:"""

        try:
            import json
            response = await model.generate(prompt, max_tokens=1024)  # Token tracking: parent SolverAgent tracks

            # ADD THIS:
            print(f"[ErrorAnalyzer] LLM response length: {len(response)}")
            print(f"[ErrorAnalyzer] LLM response first 200 chars: {response[:200]}")

            json_match = re.search(r'\{.*\}', response, re.DOTALL)
            if json_match:
                try:
                    result = json.loads(json_match.group())
                    print(f"[ErrorAnalyzer] JSON parsed successfully, keys: {list(result.keys())}")
                    return result
                except json.JSONDecodeError as e:
                    print(f"[ErrorAnalyzer] JSON parse failed: {e}")
            else:
                print(f"[ErrorAnalyzer] No JSON found in LLM response")

            # Fallback: use text response
            return {
                **pattern_results,
                "primary_cause": response[:200],
                "llm_analysis": response
            }

        except Exception as e:
            print(f"[ErrorAnalyzer] Deep analysis exception: {e}")
            return pattern_results

    def _describe_cause(self, error_type: str) -> str:
        """Convert error type to human-readable description"""
        descriptions = {
            "null_pointer": "Null pointer dereference - object accessed without initialization",
            "connection_refused": "Connection refused - service is unreachable or not running",
            "timeout": "Operation timed out - service or network is too slow or unresponsive",
            "out_of_memory": "Out of memory - application exceeded available memory",
            "permission_denied": "Permission denied - insufficient access rights",
            "file_not_found": "File not found - required file is missing or path is incorrect",
            "disk_full": "Disk full - no storage space available",
            "syntax_error": "Syntax error - invalid code or configuration format",
            "config_error": "Configuration error - invalid or missing configuration",
            "authentication_failed": "Authentication failed - invalid credentials or expired session",
        }
        return descriptions.get(error_type, f"Error: {error_type}")

    def _estimate_severity(self, findings: List[Dict]) -> str:
        """Estimate severity based on error types"""
        critical_types = {"out_of_memory", "disk_full", "connection_refused"}
        error_types = {"null_pointer", "permission_denied", "authentication_failed"}

        for finding in findings:
            if finding["type"] in critical_types:
                return "CRITICAL"

        for finding in findings:
            if finding["type"] in error_types:
                return "ERROR"

        if findings:
            return "WARNING"

        return "UNKNOWN"

    def _identify_components(self, logs: str) -> List[str]:
        """Identify affected components from logs"""
        components = set()

        # Look for component indicators
        patterns = [
            re.compile(r'(?:service|component|module|application)\s+["\']?(\w+)["\']?', re.IGNORECASE),
            re.compile(r'(\w+Service)', re.IGNORECASE),
            re.compile(r'(\w+Controller)', re.IGNORECASE),
            re.compile(r'(\w+Module)', re.IGNORECASE),
            re.compile(r'at\s+\w+\.(\w+)\.', re.IGNORECASE),
        ]

        for pattern in patterns:
            matches = pattern.findall(logs)
            components.update(matches)

        return list(components)[:5]