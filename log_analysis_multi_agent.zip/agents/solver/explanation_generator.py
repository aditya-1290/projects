"""
Explanation Generator - Creates human-readable explanations
"""

from typing import Dict, Any


class ExplanationGenerator:
    """Generates clear, actionable explanations for users"""

    async def generate(
            self,
            root_cause: Dict,
            fix: Dict,
            intent: str,
            model=None
    ) -> str:
        """
        Generate a human-readable explanation.

        Tailors output based on intent:
        - debugging: Technical details + fix
        - explanation: Simple language, what happened
        - optimization: Performance focus
        """
        primary_cause = root_cause.get("primary_cause", "Unknown error")
        severity = root_cause.get("severity", "UNKNOWN")
        confidence = root_cause.get("confidence", 0.5)

        immediate_actions = fix.get("immediate_actions", [])
        prevention = fix.get("prevention_measures", [])
        risk = fix.get("risk_level", "UNKNOWN")

        # Build explanation sections
        sections = []

        # Header
        sections.append(self._build_header(severity, confidence))

        # What happened
        sections.append(self._build_what_happened(primary_cause, root_cause))

        # Root cause
        sections.append(self._build_root_cause_section(root_cause))

        # Impact
        sections.append(self._build_impact_section(root_cause))

        # Fix
        sections.append(self._build_fix_section(fix))

        # Prevention
        if prevention:
            sections.append(self._build_prevention_section(prevention))

        # Risk warning
        sections.append(self._build_risk_warning(risk))

        # If model available, enhance explanation
        if model:
            enhanced = await self._enhance_with_llm(
                '\n\n'.join(sections), intent, model
            )
            if enhanced:
                return enhanced

        return '\n\n'.join(sections)

    def _build_header(self, severity: str, confidence: float) -> str:
        """Build the header section"""
        emoji_map = {
            "CRITICAL": "🔴",
            "ERROR": "🟠",
            "WARNING": "🟡",
            "INFO": "🔵",
            "UNKNOWN": "⚪"
        }
        emoji = emoji_map.get(severity, "⚪")

        conf_pct = int(confidence * 100)

        return f"""
{'=' * 60}
{emoji} LOG ANALYSIS RESULTS
{'=' * 60}
Severity: {severity}
Confidence: {conf_pct}%
"""

    def _build_what_happened(self, primary_cause: str, root_cause: Dict) -> str:
        """Explain what happened in simple terms"""
        timeline = root_cause.get("timeline", "")

        section = f"""
📋 WHAT HAPPENED
{'─' * 40}
{primary_cause}
"""
        if timeline:
            section += f"""
Timeline:
{timeline}
"""
        return section

    def _build_root_cause_section(self, root_cause: Dict) -> str:
        """Build root cause analysis section"""
        evidence = root_cause.get("evidence", [])
        possible_causes = root_cause.get("possible_causes", [])

        section = f"""
🔍 ROOT CAUSE ANALYSIS
{'─' * 40}
Primary Cause: {root_cause.get('primary_cause', 'Unknown')}
"""

        if evidence:
            section += "\nEvidence from logs:\n"
            for i, ev in enumerate(evidence[:5], 1):
                section += f"  {i}. {ev}\n"

        if possible_causes and len(possible_causes) > 1:
            section += "\nOther possible causes:\n"
            for cause in possible_causes[1:4]:
                section += f"  • {cause}\n"

        return section

    def _build_impact_section(self, root_cause: Dict) -> str:
        """Build impact assessment section"""
        affected = root_cause.get("affected_components", [])
        impact = root_cause.get("impact_assessment", "")

        if not affected and not impact:
            return ""

        section = f"""
📊 IMPACT ASSESSMENT
{'─' * 40}
"""
        if affected:
            section += "Affected Components:\n"
            for comp in affected:
                section += f"  • {comp}\n"

        if impact:
            section += f"\n{impact}\n"

        return section

    def _build_fix_section(self, fix: Dict) -> str:
        """Build fix/solution section"""
        immediate = fix.get("immediate_actions", [])
        code_changes = fix.get("code_changes", [])
        commands = fix.get("commands_to_run", [])
        verification = fix.get("verification_steps", [])
        downtime = fix.get("estimated_downtime", "unknown")

        section = f"""
🔧 RECOMMENDED SOLUTION
{'─' * 40}
Estimated Downtime: {downtime}
"""

        if immediate:
            section += "\n⚡ Immediate Actions:\n"
            for i, action in enumerate(immediate, 1):
                section += f"  {i}. {action}\n"

        if commands:
            section += "\n💻 Commands to Run:\n"
            for cmd in commands:
                section += f"  $ {cmd}\n"

        if code_changes:
            section += "\n📝 Code Changes:\n"
            for code in code_changes:
                section += f"```\n{code}\n```\n"

        if verification:
            section += "\n✅ Verification Steps:\n"
            for i, step in enumerate(verification, 1):
                section += f"  {i}. {step}\n"

        # Rollback plan
        rollback = fix.get("rollback_plan", "")
        if rollback:
            section += f"\n🔄 Rollback Plan:\n{rollback}\n"

        return section

    def _build_prevention_section(self, prevention: list) -> str:
        """Build prevention measures section"""
        section = f"""
🛡️ PREVENTION MEASURES
{'─' * 40}
"""
        for measure in prevention:
            section += f"  • {measure}\n"

        return section

    def _build_risk_warning(self, risk: str) -> str:
        """Build risk warning section"""
        if risk in ["HIGH", "CRITICAL"]:
            return f"""
⚠️  WARNING: This fix has {risk} risk level.
   Please test in a staging environment first.
   Consider scheduling during maintenance window.
"""
        elif risk == "MEDIUM":
            return """
⚠️  NOTE: This fix has MEDIUM risk level.
   Backup configuration before proceeding.
"""
        return ""

    async def _enhance_with_llm(
            self, explanation: str, intent: str, model
    ) -> str:
        """Use LLM to enhance the explanation"""
        prompt = f"""Improve this log analysis explanation for a user.
Intent: {intent}
Make it clear, actionable, and easy to understand.
Keep all technical details but explain them.

Current explanation:
{explanation[:2000]}

Improved explanation:"""

        try:
            response = await model.generate(prompt, max_tokens=1024)  # Token tracking: parent SolverAgent tracks
            if response and len(response) > 50:
                return response
        except Exception:
            pass

        return ""