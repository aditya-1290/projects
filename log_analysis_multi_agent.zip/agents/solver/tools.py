"""
Tools registered to the Solver Agent
"""

from typing import Dict, Any


class SolverTools:
    """Collection of tools available to the Solver agent"""

    def __init__(self):
        self.tools = {
            "analyze_root_cause": self.analyze_root_cause,
            "generate_fix": self.generate_fix,
            "explain_error": self.explain_error,
        }

    async def analyze_root_cause(self, logs: str, log_type: str = "unknown") -> Dict:
        """Analyze logs to find root cause"""
        from agents.solver.error_analyzer import ErrorAnalyzer
        analyzer = ErrorAnalyzer()
        return await analyzer.analyze(logs, log_type)

    async def generate_fix(self, logs: str, root_cause: Dict, log_type: str) -> Dict:
        """Generate fix suggestions"""
        from agents.solver.fix_generator import FixGenerator
        generator = FixGenerator()
        return await generator.generate(logs, root_cause, log_type)

    async def explain_error(self, root_cause: Dict, fix: Dict, intent: str) -> str:
        """Generate human-readable explanation"""
        from agents.solver.explanation_generator import ExplanationGenerator
        generator = ExplanationGenerator()
        return await generator.generate(root_cause, fix, intent)

    def get_tool(self, tool_name: str):
        """Get a tool by name"""
        return self.tools.get(tool_name)
