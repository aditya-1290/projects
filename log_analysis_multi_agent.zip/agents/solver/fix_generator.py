"""
Fix Generator - Generates fix suggestions based on root cause analysis
"""

import re
from typing import Dict, Any, List


class FixGenerator:
    """Generates actionable fix suggestions"""

    # Known fix templates
    FIX_TEMPLATES = {
        "null_pointer": {
            "immediate": "Add null check before accessing the object",
            "code_example": """
if (object != null) {
    // access object
} else {
    // handle null case
    throw new IllegalArgumentException("Object cannot be null");
}""",
            "prevention": "Use Optional<T> or @NonNull annotations"
        },
        "connection_refused": {
            "immediate": "Verify the service is running and accessible",
            "commands": [
                "netstat -tulpn | grep <port>",
                "telnet <host> <port>",
                "systemctl status <service>"
            ],
            "prevention": "Implement health checks and connection retry logic"
        },
        "timeout": {
            "immediate": "Increase timeout values or optimize the slow operation",
            "code_example": """
// Increase timeout
client.setConnectTimeout(30000);
client.setReadTimeout(60000);
// Add retry logic
int maxRetries = 3;""",
            "prevention": "Implement circuit breaker pattern"
        },
        "out_of_memory": {
            "immediate": "Increase heap size or fix memory leak",
            "commands": [
                "jmap -heap <pid>",
                "jstat -gc <pid> 1000 10",
                "-Xmx2g -XX:+HeapDumpOnOutOfMemoryError"
            ],
            "prevention": "Profile memory usage, implement object pooling"
        },
        "permission_denied": {
            "immediate": "Check file/directory permissions",
            "commands": [
                "ls -la <path>",
                "chmod 755 <path>",
                "chown user:group <path>"
            ],
            "prevention": "Use proper user/group management"
        },
        "file_not_found": {
            "immediate": "Verify file path and existence",
            "commands": [
                "ls <path>",
                "find / -name <filename>",
                "pwd"
            ],
            "prevention": "Use absolute paths, add file existence checks"
        },
        "disk_full": {
            "immediate": "Free up disk space",
            "commands": [
                "df -h",
                "du -sh /*",
                "find /tmp -mtime +7 -delete"
            ],
            "prevention": "Set up disk monitoring and log rotation"
        },
        "authentication_failed": {
            "immediate": "Verify credentials and authentication configuration",
            "commands": [
                "Check password",
                "Verify token expiry",
                "Check auth config"
            ],
            "prevention": "Implement credential rotation and monitoring"
        }
    }

    async def generate(
            self,
            logs: str,
            root_cause: Dict,
            log_type: str,
            model=None
    ) -> Dict[str, Any]:
        """
        Generate fix suggestions.

        Returns:
            {
                "immediate_actions": List[str],
                "code_changes": List[str],
                "config_changes": List[str],
                "commands_to_run": List[str],
                "prevention_measures": List[str],
                "risk_level": str,
                "estimated_downtime": str,
                "confidence": float
            }
        """
        cause_category = root_cause.get("cause_category", "unknown")

        # Get template-based fix
        template_fix = self._get_template_fix(cause_category)

        # If model available, get intelligent fix
        if model:
            return await self._intelligent_fix(
                logs, root_cause, log_type, template_fix, model
            )

        return template_fix

    def _get_template_fix(self, cause_category: str) -> Dict:
        """Get pre-defined fix template for known error types"""
        template = self.FIX_TEMPLATES.get(cause_category, {})

        return {
            "immediate_actions": [template.get("immediate", "Analyze the specific error in logs")],
            "code_changes": [template.get("code_example", "")] if template.get("code_example") else [],
            "config_changes": [],
            "commands_to_run": template.get("commands", []),
            "prevention_measures": [template.get("prevention", "Monitor and log similar errors")],
            "risk_level": self._estimate_risk(cause_category),
            "estimated_downtime": self._estimate_downtime(cause_category),
            "confidence": 0.5 if not template else 0.7
        }

    async def _intelligent_fix(
            self,
            logs: str,
            root_cause: Dict,
            log_type: str,
            template_fix: Dict,
            model
    ) -> Dict:
        """Use LLM to generate intelligent fix suggestions"""
        prompt = f"""Based on the following log analysis, generate specific fix suggestions.

Log Type: {log_type}
Root Cause: {root_cause.get('primary_cause', 'Unknown')}
Severity: {root_cause.get('severity', 'UNKNOWN')}
Affected Components: {', '.join(root_cause.get('affected_components', []))}

Log Excerpt:
{logs[:2000]}

Provide fix suggestions in JSON format:
{{
    "immediate_actions": ["action 1", "action 2"],
    "code_changes": ["code fix 1", "code fix 2"],
    "config_changes": ["config change 1"],
    "commands_to_run": ["command 1", "command 2"],
    "prevention_measures": ["prevention 1", "prevention 2"],
    "risk_level": "LOW|MEDIUM|HIGH|CRITICAL",
    "estimated_downtime": "none|<5min|<30min|<1hr|>1hr",
    "confidence": 0.0-1.0,
    "verification_steps": ["step 1", "step 2"],
    "rollback_plan": "How to undo if fix fails"
}}

Fix Suggestions:"""

        try:
            import json
            response = await model.generate(prompt, max_tokens=1024)  # Token tracking: parent SolverAgent tracks

            # Try to parse JSON from response
            json_match = re.search(r'\{.*\}', response, re.DOTALL)
            if json_match:
                try:
                    result = json.loads(json_match.group())
                    return {**template_fix, **result}
                except json.JSONDecodeError:
                    pass

            return {**template_fix, "llm_suggestion": response}

        except Exception:
            return template_fix

    def _estimate_risk(self, cause_category: str) -> str:
        """Estimate risk level of the fix"""
        high_risk = {"out_of_memory", "disk_full", "connection_refused"}
        medium_risk = {"null_pointer", "permission_denied", "authentication_failed"}

        if cause_category in high_risk:
            return "HIGH"
        elif cause_category in medium_risk:
            return "MEDIUM"
        return "LOW"

    def _estimate_downtime(self, cause_category: str) -> str:
        """Estimate downtime needed for fix"""
        high_downtime = {"out_of_memory", "disk_full"}
        medium_downtime = {"connection_refused"}

        if cause_category in high_downtime:
            return "<30min (may require restart)"
        elif cause_category in medium_downtime:
            return "<5min (service restart)"
        return "none (hotfix possible)"