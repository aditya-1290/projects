"""
Tools registered to the Analyzer Agent
"""


class AnalyzerTools:
    def __init__(self):
        self.tools = {
            "classify_logs": self.classify_logs,
            "detect_intent": self.detect_intent,
        }

    async def classify_logs(self, logs: str) -> dict:
        """Quick pattern-based classification"""
        from agents.analyzer.agent import AnalyzerAgent
        agent = AnalyzerAgent()
        return await agent._pattern_analysis(logs)

    async def detect_intent(self, query: str, log_type: str) -> str:
        """Detect user intent"""
        query_lower = query.lower()
        if any(w in query_lower for w in ['fix', 'debug', 'solve', 'patch']):
            return "debugging"
        if any(w in query_lower for w in ['explain', 'what', 'why', 'how']):
            return "explanation"
        if any(w in query_lower for w in ['optimize', 'faster', 'slow', 'performance']):
            return "optimization"
        return "general_analysis"

    def get_tool(self, tool_name: str):
        return self.tools.get(tool_name)