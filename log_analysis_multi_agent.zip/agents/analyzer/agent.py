"""
Analyzer Agent - Classifies logs and detects user intent
"""

from agents.base_agent import BaseAgent, A2AMessage, MessageType
from typing import Dict
# import json
# import re

from agents.analyzer.prompts import (
    SKILL_NL_TO_ES_QUERY,
    SKILL_LOG_CLASSIFICATION,
    SKILL_INTENT_DETECTION,
    SKILL_SEVERITY_ASSESSMENT,
    SKILL_LOG_PATTERN_DETECTION,
    SKILL_TECHNOLOGY_IDENTIFICATION,
    SKILL_ANOMALY_FLAGGING,
    SKILL_LOG_HEALTH_SCORING,
    SKILL_TRIAGE_PRIORITIZATION,
)

class AnalyzerAgent(BaseAgent):
    """Classifies log types and determines user intent"""

    def __init__(self):
        super().__init__("analyzer_v1", "agents/analyzer/capabilities.json")

    # ═══════════════════════════════════════════════════════════════════════════
    # ADK Integration — Tool Registration
    # ═══════════════════════════════════════════════════════════════════════════

    def _get_model_requirements(self) -> list:
        return ["gemma-4-e4b-it"]

    def _resolve_adk_model(self) -> str:
        return "gemma-4-e4b-it"

    def _get_adk_tools(self) -> list:
        """Register log classification and analysis as ADK tools."""
        return [
                {
                    "name": "classify_logs",
                    "description": "Classify log entries by type, detect user intent, assess severity, and identify patterns.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "clean_logs": {
                                "type": "string",
                                "description": "Preprocessed log content to analyze"
                            }
                        },
                        "required": ["clean_logs"]
                    }
                },
                {
                    "name": "assess_severity",
                    "description": "Assess the severity level of a log incident (CRITICAL/ERROR/WARNING/INFO) with reasoning.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "clean_logs": {
                                "type": "string",
                                "description": "Log content to assess"
                            },
                            "log_type": {
                                "type": "string",
                                "description": "Detected log type for context"
                            }
                        },
                        "required": ["clean_logs"]
                    }
                },
                {
                    "name": "detect_patterns",
                    "description": "Detect recurring patterns, anomalies, and known error signatures in logs.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "clean_logs": {
                                "type": "string",
                                "description": "Log content to analyze for patterns"
                            }
                        },
                        "required": ["clean_logs"]
                    }
                }
        ]

    def _build_adk_instruction(self) -> str:
        """Build the analyzer's ADK instruction."""
        return """You are the Analyzer Agent for a log analysis system.

    Your job is to classify and analyze log entries before they go to the solver.

    TOOLS AVAILABLE:
    - classify_logs: Full classification (log type, intent, severity, patterns)
    - assess_severity: Quick severity assessment only
    - detect_patterns: Find recurring patterns and anomalies

    CLASSIFICATION TAXONOMY:
    LOG TYPES: python_traceback, java_stacktrace, js_error, go_panic,
               apache_access, apache_error, syslog_rfc5424, syslog_bsd,
               json_log, ndjson, csv, tsv, xml, kubernetes_log, docker_log,
               application_log, plain_text, unknown

    SEVERITY LEVELS:
    - CRITICAL: Service down, data loss, security breach in progress
    - ERROR: Major feature broken, cascading failures
    - WARNING: Intermittent issues, degraded performance
    - INFO: Normal operations, expected errors handled

    USER INTENTS:
    - debugging: User wants root cause + fix
    - explanation: User wants to understand what happened
    - optimization: User wants performance improvements
    - security_audit: User suspects security issue
    - health_check: User wants system status overview

    Always provide confidence scores with your classifications.
    """

    async def process(self, message: A2AMessage) -> A2AMessage:
        task = message.task or {}
        context = message.context or {}

        clean_logs = task.get("clean_logs", "") or context.get("clean_logs", "")

        if not clean_logs:
            return A2AMessage(
                message_type=MessageType.ERROR,
                sender_id=self.agent_id,
                sender_type="analyzer",
                target_id=message.sender_id,
                correlation_id=message.message_id,
                error="No clean logs provided for analysis"
            )

        try:
            model = await self.get_model("gemma")

            # 🔥 ADD THIS BEFORE LLM CALL
            if "Traceback" in clean_logs or "Error" in clean_logs:
                context["log_type_hint"] = "error_log"

            # Run classification
            analysis = await self._analyze(clean_logs, model)

            return A2AMessage(
                message_type=MessageType.RESPONSE,
                sender_id=self.agent_id,
                sender_type="analyzer",
                target_id=message.sender_id,
                correlation_id=message.message_id,
                response={
                    **analysis,
                    "analysis": analysis,  # 🔥 standardized key
                    "log_type": analysis.get("log_type"),
                    "intent": analysis.get("primary_intent"),
                },
                confidence=analysis.get("confidence", 0.7),
                context=message.context
            )

        except Exception as e:
            # Fallback: pattern-based classification
            analysis = await self._pattern_analysis(clean_logs)
            return A2AMessage(
                message_type=MessageType.RESPONSE,
                sender_id=self.agent_id,
                sender_type="analyzer",
                target_id=message.sender_id,
                correlation_id=message.message_id,
                response=analysis,
                confidence=analysis.get("confidence", 0.5)
            )

    async def _analyze(self, logs: str, model) -> Dict:
        """Use LLM with dynamic skill selection to classify logs"""

        # Detect log characteristics for skill selection
        logs_lower = logs[:1000].lower()
        has_errors = any(kw in logs_lower for kw in ['exception', 'traceback', 'error', 'fail', 'fatal', 'crash'])
        error_count = logs_lower.count('error') + logs_lower.count('exception')
        has_multiple_issues = error_count > 5
        has_warnings = any(kw in logs_lower for kw in ['warn', 'warning'])

        # Dynamic skill selection
        skill_prompt, skill_name = self._select_analyzer_skill(
            logs, has_errors, error_count, has_multiple_issues, has_warnings
        )

        self.log(f"Analyzer using skill: {skill_name}", "INFO")

        # Build prompt using the selected skill template
        prompt = self._build_analyzer_prompt(skill_prompt, logs, skill_name)

        try:
            response = await self._generate_with_tracking(model, prompt, max_tokens=1024, action_name="analyze_logs")
            response_text = str(response) if not isinstance(response, str) else response

            import json
            import re
            json_match = re.search(r'\{.*\}', response_text, re.DOTALL)
            if json_match:
                parsed = json.loads(json_match.group())

                # Validate minimum fields
                if parsed.get("log_type") or parsed.get("severity") or parsed.get("patterns_found"):
                    parsed["skill_used"] = skill_name

                    # Enrichment layer
                main_error = parsed.get("main_error", "")
                if "NameError" in response_text and "NameError" not in str(main_error):
                    match = re.search(r"NameError:\s*(.+)", logs)
                    if match:
                        parsed["main_error"] = f"NameError: {match.group(1)}"
                    else:
                        parsed["main_error"] = "NameError: undefined variable"

                return parsed

        except Exception as e:
            self.log(f"LLM analysis failed: {e}", "WARNING")

        # Fallback to pattern-based analysis
        result = await self._pattern_analysis(logs)
        result["skill_used"] = "pattern_fallback"
        return result

    def _select_analyzer_skill(self, logs, has_errors, error_count, has_multiple_issues, has_warnings):
        """Select the best analyzer skill based on log characteristics.
        Returns (prompt_template, skill_name)."""

        logs_sample = logs[:500].lower()

        # 1. Multiple issues detected → triage prioritization
        if has_multiple_issues and error_count > 10:
            return SKILL_TRIAGE_PRIORITIZATION, "triage_prioritization"

        # 2. Errors present → severity assessment
        if has_errors and error_count > 3:
            return SKILL_SEVERITY_ASSESSMENT, "severity_assessment"

        # 3. Anomalies or unusual patterns
        if any(kw in logs_sample for kw in ['unexpected', 'anomaly', 'unusual', 'spike', 'sudden']):
            return SKILL_ANOMALY_FLAGGING, "anomaly_flagging"

        # 4. Contains stack traces or deep technical content
        if any(kw in logs_sample for kw in ['traceback', 'stack trace', 'at com.', 'at org.', 'goroutine']):
            return SKILL_TECHNOLOGY_IDENTIFICATION, "technology_identification"

        # 5. Pattern detection for temporal/correlation analysis
        if len(logs) > 5000:
            return SKILL_LOG_PATTERN_DETECTION, "log_pattern_detection"

        # 6. Health scoring for quality assessment
        if has_warnings and not has_errors:
            return SKILL_LOG_HEALTH_SCORING, "log_health_scoring"

        # 7. Intent detection for user-facing queries
        if any(kw in logs_sample for kw in ['what', 'why', 'how', 'explain', 'help']):
            return SKILL_INTENT_DETECTION, "intent_detection"

        #8. NL to ES query detection
        if any(kw in logs_sample for kw in ['show me', 'find', 'search for', 'errors from', 'logs from']):
            return SKILL_NL_TO_ES_QUERY, "nl_to_es_query"

        # 9. Default: standard log classification
        return SKILL_LOG_CLASSIFICATION, "log_classification"

    def _build_analyzer_prompt(self, skill_prompt, logs, skill_name):
        """Build formatted prompt from skill template."""
        entry_count = logs.count('\n') + 1
        has_timestamps = any(c.isdigit() for c in logs[:200])

        return skill_prompt.format(
            clean_logs=logs[:3000],
            entry_count=entry_count,
            format="text",
            has_timestamps="true" if has_timestamps else "false"
        )

    async def _pattern_analysis(self, logs: str) -> Dict:
        """Pattern-based classification without LLM"""
        logs_lower = logs.lower()

        # Determine log type
        if any(word in logs_lower for word in ['database', 'sql', 'postgres', 'mysql', 'connection refused']):
            log_type = "database_log"
        elif any(word in logs_lower for word in ['http', 'apache', 'nginx', '404', '500']):
            log_type = "server_log"
        elif any(word in logs_lower for word in ['permission denied', 'unauthorized', 'forbidden', 'auth']):
            log_type = "security_log"
        elif any(word in logs_lower for word in ['timeout', 'network', 'dns', 'refused']):
            log_type = "network_log"
        elif any(word in logs_lower for word in ['exception', 'traceback', 'error']):
            log_type = "error_log"
        elif any(word in logs_lower for word in ['warn', 'warning']):
            log_type = "application_log"
        else:
            log_type = "system_log"

        # Determine severity
        if any(word in logs_lower for word in ['critical', 'fatal', 'emergency']):
            severity = "CRITICAL"
        elif any(word in logs_lower for word in ['error', 'exception', 'failed']):
            severity = "ERROR"
        elif any(word in logs_lower for word in ['warn', 'warning']):
            severity = "WARNING"
        else:
            severity = "INFO"

        # Determine intent
        if any(word in logs_lower for word in ['traceback', 'exception', 'stack trace', 'line']):
            intent = "debugging"
        elif any(word in logs_lower for word in ['what', 'why', 'explain', 'how']):
            intent = "explanation"
        else:
            intent = "debugging"

        import re
        # Extract main error
        error_pattern = re.search(r'(?:Error|Exception|FATAL|CRITICAL):?\s*([^\n]+)', logs, re.IGNORECASE)
        main_error = error_pattern.group(1).strip() if error_pattern else "Unknown error"

        # 🔥 STRONG DETECTION
        if "NameError" in logs:
            import re
            match = re.search(r"NameError:\s*(.+)", logs)
            if match:
                main_error = f"NameError: {match.group(1)}"
            else:
                main_error = "NameError: undefined variable"

        return {
            "log_type": log_type,
            "primary_intent": intent,
            "severity": severity,
            "main_error": main_error[:200],
            "affected_components": [],
            "confidence": 0.6,
            "summary": f"{severity} {log_type}: {main_error[:100]}"
        }
