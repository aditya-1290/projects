"""
Log Parser - Structures cleaned logs into organized format
"""

import re
from typing import Dict, List, Optional, Any
from datetime import datetime
import logging

from sympy.codegen.ast import continue_


class LogParser:
    """Parses cleaned logs into structured entries"""

    def __init__(self):
        self.logger = logging.getLogger("preprocessor.parser")

    def log(self, message: str, level: str = "INFO"):
        """Log a message through the preprocessor's logger"""
        if self.logger:
            getattr(self.logger, level.lower(), self.logger.info)(message)

    # Common log patterns
    LOG_PATTERNS = {
        "standard": re.compile(
            r'^\[?(?P<timestamp>\d{4}[-/]\d{2}[-/]\d{2}[T\s]\d{2}:\d{2}:\d{2}(?:\.\d+)?)\]?\s+'
            r'\[?(?P<level>DEBUG|INFO|WARN(?:ING)?|ERROR|ERR|CRIT(?:ICAL)?|FATAL|TRACE|NOTICE)\]?\s+'
            r'(?P<message>.*)',
            re.IGNORECASE
        ),
        "syslog": re.compile(
            r'^(?P<timestamp>\w{3}\s+\d+\s+\d{2}:\d{2}:\d{2})\s+'
            r'(?P<hostname>\S+)\s+'
            r'(?P<process>\S+?)(?:\[(?P<pid>\d+)\])?:\s+'
            r'(?P<message>.*)'
        ),
        "apache": re.compile(
            r'^(?P<ip>\S+)\s+\S+\s+\S+\s+'
            r'\[(?P<timestamp>\d{2}/\w{3}/\d{4}:\d{2}:\d{2}:\d{2}\s+[\+\-]\d{4})\]\s+'
            r'"(?P<method>\S+)\s+(?P<path>\S+)\s+\S+"\s+'
            r'(?P<status>\d+)\s+(?P<size>\S+)'
        ),
        "json_log": re.compile(r'^\s*\{.*\}\s*$'),
        "stack_trace": re.compile(r'^\s+at\s+|\s+\.\.\.\s+\d+\s+more|^Caused by:'),
        "timestamp_only": re.compile(
            r'^(?P<timestamp>\d{4}[-/]\d{2}[-/]\d{2}[T\s]\d{2}:\d{2}:\d{2}(?:\.\d+)?)\s+'
            r'(?P<message>.*)'
        )
    }

    async def parse(self, cleaned_logs: str, model=None) -> Dict[str, Any]:
        """
        Parse cleaned logs into structured format.

        Returns:
            {
                "format": "standard" | "syslog" | "apache" | "json" | "text",
                "entries": List of parsed log entries,
                "total_lines": int,
                "parsed_lines": int,
                "fields_found": List[str]
            }
        """
        lines = cleaned_logs.strip().split('\n')

        print(f"!!! PARSER DEBUG: Got {len(lines)} lines, first line: {lines[0][:100] if lines else 'EMPTY'}",
              flush=True)

        # Detect format
        detected_format = self._detect_format(lines)

        print(f"!!! PARSER DEBUG: Detected format: {detected_format}", flush=True)

        # Parse based on format
        if detected_format == "json":
            return await self._parse_json_format(cleaned_logs)

        entries = []
        fields_found = set()

        for line in lines:
            if not line.strip():
                continue

            entry = self._parse_line(line, detected_format)
            entries.append(entry)

            if entry.get("parsed"):
                fields_found.update(entry.keys())

        self.log(f"DEBUG PARSER: input lines={len(lines)}, output entries={len(entries)}", "INFO")
        self.log(f"DEBUG PARSER: calling _intelligent_enrich? model={model is not None}, entries={len(entries)}",
                 "INFO")

        result = {
            "format": detected_format,
            "entries": entries,
            "total_lines": len(lines),
            "parsed_lines": sum(1 for e in entries if e.get("parsed")),
            "fields_found": list(fields_found - {"raw", "parsed"})
        }

        # If model available, do intelligent enrichment
        # Skip for large files (>500 lines) to avoid excessive LLM calls
        if model and entries and len(entries) <= 500:
            result = await self._intelligent_enrich(result, model)

        return result

    def _detect_format(self, lines: List[str]) -> str:
        """Detect the log format from sample lines"""
        sample = '\n'.join(lines[:20])  # First 20 lines

        # Check for JSON
        json_lines = [l for l in lines[:10] if l.strip().startswith('{')]
        if len(json_lines) > len(lines[:10]) * 0.5:
            return "json"

        # Check Apache
        apache_matches = sum(1 for l in lines[:10] if self.LOG_PATTERNS["apache"].match(l))
        if apache_matches > len(lines[:10]) * 0.5:
            return "apache"

        # Check syslog
        syslog_matches = sum(1 for l in lines[:10] if self.LOG_PATTERNS["syslog"].match(l))
        if syslog_matches > len(lines[:10]) * 0.5:
            return "syslog"

        # Check standard
        standard_matches = sum(1 for l in lines[:10] if self.LOG_PATTERNS["standard"].match(l))
        if standard_matches > len(lines[:10]) * 0.3:
            return "standard"

        return "text"

    def _parse_line(self, line: str, format_type: str) -> Dict:
        """Parse a single log line"""
        entry = {
            "raw": line,
            "parsed": False
        }

        # Try format-specific pattern first
        if format_type in self.LOG_PATTERNS:
            pattern = self.LOG_PATTERNS[format_type]
            match = pattern.match(line)
            if match:
                entry.update(match.groupdict())
                entry["parsed"] = True
                return entry

        # Try all patterns
        for pattern_name, pattern in self.LOG_PATTERNS.items():
            if pattern_name == "json_log" or pattern_name == "stack_trace":
                continue

            match = pattern.match(line)
            if match:
                entry.update(match.groupdict())
                entry["parsed"] = True
                entry["detected_format"] = pattern_name
                return entry

        # Last resort: timestamp + message
        ts_match = self.LOG_PATTERNS["timestamp_only"].match(line)
        if ts_match:
            entry.update(ts_match.groupdict())
            entry["parsed"] = True
            entry["detected_format"] = "timestamp_only"
            return entry

        # Check if it's a stack trace line
        if self.LOG_PATTERNS["stack_trace"].match(line):
            entry["is_stack_trace"] = True
            entry["message"] = line.strip()
            entry["parsed"] = True

        return entry

    async def _parse_json_format(self, content: str) -> Dict:
        """Parse JSON formatted logs"""
        from agents.extractor.parsers.json_parser import JSONParser
        parser = JSONParser()
        return await parser.parse(content)

    async def _intelligent_enrich(self, result: Dict, model) -> Dict:
        """Use LLM to identify structure in unparsed lines. Processes ALL lines in batches."""
        unparsed = [e for e in result["entries"] if not e.get("parsed")]
        if not unparsed:
            return result

        self.log(f"DEBUG ENRICH: starting with {len(unparsed)} unparsed lines out of {len(result['entries'])} total",
                 "INFO")

        # Process ALL unparsed lines in batches of 30
        batch_size = 30
        enriched_count = 0

        for batch_start in range(0, len(unparsed), batch_size):
            batch = unparsed[batch_start:batch_start + batch_size]
            sample = '\n'.join([e["raw"] for e in batch])

            if not sample.strip():
                continue

            prompt = f"""Analyze these unparsed log lines and identify structure.

    Log lines:
    {sample[:5000]}

    For each line, identify:
    - timestamp: ISO format if present
    - level: ERROR, WARN, INFO, DEBUG, or null
    - service: component/service name or null
    - message: the main log message

    Respond with JSON:
    {{"entries": [{{"line_index": 0, "timestamp": "2024-01-15T10:23:45Z", "level": "INFO", "service": "auth-service", "message": "text"}}]}}"""

            try:
                import json
                import re
                response = await model.generate(prompt, max_tokens=1024)  # Token tracking: called from preprocessor._parse()

                # Extract JSON from response
                json_match = re.search(r'\{.*\}', response, re.DOTALL)
                if json_match:
                    try:
                        parsed = json.loads(json_match.group())
                        llm_entries = parsed.get("entries", [])

                        for llm_entry in llm_entries:
                            idx = batch_start + llm_entry.get("line_index", 0)
                            if idx < len(unparsed):
                                unparsed[idx]["timestamp"] = llm_entry.get("timestamp", "")
                                unparsed[idx]["level"] = llm_entry.get("level", "")
                                unparsed[idx]["service"] = llm_entry.get("service", "")
                                unparsed[idx]["message"] = llm_entry.get("message", unparsed[idx].get("raw", ""))
                                unparsed[idx]["parsed"] = True
                                enriched_count += 1
                    except json.JSONDecodeError:
                        pass

            except Exception:
                # If one batch fails, continue with the next batch
                pass

        # Update result stats
        result["parsed_lines"] = sum(1 for e in result["entries"] if e.get("parsed"))

        return result