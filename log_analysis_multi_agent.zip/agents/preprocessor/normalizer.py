"""
Log Normalizer - Normalizes timestamps, IPs, and other fields
"""

import re
from typing import Dict, List, Any
from datetime import datetime


class LogNormalizer:
    """Normalizes log entries for consistent processing"""

    # IP Address pattern
    IP_PATTERN = re.compile(r'\b(?:\d{1,3}\.){3}\d{1,3}\b')

    # UUID pattern
    UUID_PATTERN = re.compile(
        r'\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b',
        re.IGNORECASE
    )

    # Common timestamp formats
    TIMESTAMP_FORMATS = [
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d %H:%M:%S.%f",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%dT%H:%M:%S.%f",
        "%Y/%m/%d %H:%M:%S",
        "%d/%b/%Y:%H:%M:%S %z",
        "%b %d %H:%M:%S",
        "%d-%m-%Y %H:%M:%S",
    ]

    async def normalize(self, parsed_logs: Dict) -> Dict:
        """
        Normalize parsed logs.

        - Converts all timestamps to ISO format
        - Normalizes IP addresses (local vs public)
        - Normalizes log levels
        - Adds normalized fields
        """
        entries = parsed_logs.get("entries", [])

        normalized_entries = []
        stats = {
            "timestamps_normalized": 0,
            "ips_normalized": 0,
            "levels_normalized": 0
        }

        for entry in entries:
            normalized = entry.copy()

            # Normalize timestamp
            if entry.get("timestamp"):
                normalized["timestamp_iso"] = self._normalize_timestamp(
                    entry["timestamp"]
                )
                if normalized["timestamp_iso"]:
                    stats["timestamps_normalized"] += 1

            # Normalize IP addresses in message
            if entry.get("message"):
                ips = self.IP_PATTERN.findall(entry["message"])
                if ips:
                    normalized["ip_addresses"] = ips
                    normalized["has_local_ip"] = any(
                        ip.startswith(("10.", "172.16.", "172.17.",
                                       "172.18.", "172.19.", "172.20.",
                                       "172.21.", "172.22.", "172.23.",
                                       "172.24.", "172.25.", "172.26.",
                                       "172.27.", "172.28.", "172.29.",
                                       "172.30.", "172.31.", "192.168.", "127."))
                        for ip in ips
                    )
                    stats["ips_normalized"] += 1

            # Normalize log level
            if entry.get("level"):
                normalized["level_normalized"] = self._normalize_level(
                    entry["level"]
                )
                stats["levels_normalized"] += 1
            elif entry.get("severity"):
                normalized["level_normalized"] = entry["severity"]

            # Extract UUIDs
            if entry.get("message"):
                uuids = self.UUID_PATTERN.findall(entry["message"])
                if uuids:
                    normalized["uuids"] = uuids

            normalized_entries.append(normalized)

        result = parsed_logs.copy()
        result["entries"] = normalized_entries
        result["normalization_stats"] = stats
        result["normalized"] = True

        return result

    def _normalize_timestamp(self, timestamp: str) -> str:
        """Convert timestamp to ISO 8601 format"""
        if not timestamp:
            return None

        # Remove extra spaces
        timestamp = timestamp.strip()

        # Try each format
        for fmt in self.TIMESTAMP_FORMATS:
            try:
                dt = datetime.strptime(timestamp, fmt)
                return dt.isoformat()
            except ValueError:
                continue

        # Try with timezone removal
        try:
            # Remove timezone suffix
            ts_clean = re.sub(r'\s*[A-Z]{3,4}$', '', timestamp)
            for fmt in self.TIMESTAMP_FORMATS:
                try:
                    dt = datetime.strptime(ts_clean.strip(), fmt)
                    return dt.isoformat()
                except ValueError:
                    continue
        except Exception:
            pass

        return None

    def _normalize_level(self, level: str) -> str:
        """Normalize log level to standard format"""
        level_upper = level.upper().strip()

        level_map = {
            "DEBUG": "DEBUG",
            "INFO": "INFO",
            "INFORMATION": "INFO",
            "WARN": "WARNING",
            "WARNING": "WARNING",
            "ERROR": "ERROR",
            "ERR": "ERROR",
            "CRIT": "CRITICAL",
            "CRITICAL": "CRITICAL",
            "FATAL": "FATAL",
            "TRACE": "TRACE",
            "NOTICE": "NOTICE",
            "EMERG": "EMERGENCY",
            "EMERGENCY": "EMERGENCY",
            "ALERT": "ALERT",
        }

        return level_map.get(level_upper, level_upper)