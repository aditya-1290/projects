"""
Log Chunker — Splits large log content into LLM-friendly chunks.

Handles:
  - Full-content chunking (no sampling/truncation for large files)
  - Boundary-aware splitting (stack traces kept together)
  - Overlap between chunks for context continuity
  - Smart size limits optimized for Gemma/Qwen context windows
"""

from typing import Dict, List, Optional
import re


class LogChunker:
    """
    Splits large log content into chunks that fit LLM context windows.

    Features:
    - Processes ALL content regardless of size
    - Splits at natural boundaries (timestamps, log entry starts)
    - Keeps related content together (stack traces, multi-line errors)
    - Adds overlap between chunks for context continuity
    - Respects LLM context limits with safe margins
    """

    # Chunk sizes optimized for Gemma (8192 ctx) and Qwen (16384 ctx)
    # Using conservative 5000-8000 range to leave room for instruction + response
    DEFAULT_CHUNK_SIZE = 5000
    MAX_CHUNK_SIZE = 8000
    MIN_CHUNK_SIZE = 500
    OVERLAP_SIZE = 200  # Characters of overlap between chunks for context

    # Patterns that indicate a good chunk boundary
    BOUNDARY_PATTERNS = [
        # Timestamps (ISO, syslog, Apache)
        re.compile(r'^\d{4}-\d{2}-\d{2}[T\s]\d{2}:\d{2}:\d{2}'),
        re.compile(r'^[A-Z][a-z]{2}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2}'),
        re.compile(r'^\[\d{1,2}/[A-Z][a-z]{2}/\d{4}'),
        # Log levels at line start
        re.compile(r'^(ERROR|WARN|WARNING|INFO|DEBUG|TRACE|CRITICAL|FATAL)\b'),
        # Kubernetes log format
        re.compile(r'^[IEWF]\d{4}\s+\d{2}:\d{2}:\d{2}'),
        # Empty lines (visual separators)
        re.compile(r'^\s*$'),
    ]

    # Patterns that should NOT be split (keep with previous chunk)
    KEEP_WITH_PREVIOUS = [
        # Stack trace continuation
        re.compile(r'^\s+File\s+"'),
        re.compile(r'^\s+at\s+'),
        re.compile(r'^\s+\.\.\.'),
        re.compile(r'^\s+\^+$'),
        # Multi-line error messages
        re.compile(r'^Caused by:'),
        re.compile(r'^Suppressed:'),
        # SQL query continuation
        re.compile(r'^\s+(FROM|JOIN|WHERE|AND|OR|ORDER|GROUP|HAVING|LIMIT)\b', re.IGNORECASE),
        # JSON/XML continuation
        re.compile(r'^\s*[}\]]'),
        re.compile(r'^\s*</'),
    ]

    def __init__(self, chunk_size: int = None):
        self.chunk_size = chunk_size or self.DEFAULT_CHUNK_SIZE

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def chunk(
        self,
        parsed_logs: Dict,
        model=None
    ) -> Dict:
        """
        Split log content into manageable chunks.

        Args:
            parsed_logs: Dict with 'entries' (list) or 'content' (str)
            model: Optional LLM for semantic chunking (ignored for now)

        Returns:
            Dict with:
                - content: First chunk (for backward compatibility)
                - chunks: All chunks
                - is_chunked: Whether chunking was needed
                - chunk_count: Number of chunks
                - total_length: Total characters
        """
        # Extract content
        content = parsed_logs.get("content", "")
        if not content and parsed_logs.get("entries"):
            entries = parsed_logs["entries"]
            content = "\n".join(
                e.get("_raw", str(e)) for e in entries
                if isinstance(e, dict)
            )

        total_length = len(content)
        total_lines = content.count('\n') + 1

        # Don't chunk if already small enough
        if total_length <= self.chunk_size:
            return {
                "content": content,
                "chunks": [content],
                "is_chunked": False,
                "chunk_count": 1,
                "total_length": total_length,
                "total_lines": total_lines,
                "format": parsed_logs.get("format", "text"),
                "chunk_sizes": [total_length],
            }

        # Chunk ALL content — no sampling, no truncation
        chunks = self._boundary_chunk(content, self.chunk_size)

        # Add overlap context
        chunks = self._add_overlap(chunks)

        return {
            "content": chunks[0] if chunks else content,
            "chunks": chunks,
            "is_chunked": len(chunks) > 1,
            "chunk_count": len(chunks),
            "total_length": total_length,
            "total_lines": total_lines,
            "format": parsed_logs.get("format", "text"),
            "chunk_sizes": [len(c) for c in chunks],
        }

    # ------------------------------------------------------------------
    # Internal: Boundary-aware chunking
    # ------------------------------------------------------------------

    def _boundary_chunk(self, content: str, chunk_size: int) -> List[str]:
        """
        Split content at natural boundaries (timestamps, log entry starts).
        Keeps related lines together (stack traces, multi-line errors).
        Processes ALL content — no sampling.
        """
        lines = content.split('\n')
        chunks = []
        current_chunk_lines = []
        current_size = 0

        for i, line in enumerate(lines):
            line_size = len(line) + 1  # +1 for newline

            # Check if adding this line would exceed chunk size
            if current_size + line_size > chunk_size and current_chunk_lines:
                # Find the best split point
                if self._is_boundary(line):
                    # Good boundary — save current chunk, start new one
                    chunks.append('\n'.join(current_chunk_lines))
                    current_chunk_lines = [line]
                    current_size = line_size
                elif self._should_keep_with_previous(line):
                    # Don't split stack traces — keep with current chunk
                    current_chunk_lines.append(line)
                    current_size += line_size
                else:
                    # Neutral — start new chunk
                    chunks.append('\n'.join(current_chunk_lines))
                    current_chunk_lines = [line]
                    current_size = line_size
            else:
                # Room in current chunk — add line
                current_chunk_lines.append(line)
                current_size += line_size

        # Don't forget the last chunk
        if current_chunk_lines:
            chunks.append('\n'.join(current_chunk_lines))

        # Merge tiny chunks with neighbors
        chunks = self._merge_small_chunks(chunks)

        return chunks

    def _is_boundary(self, line: str) -> bool:
        """Check if this line is a good place to split chunks."""
        for pattern in self.BOUNDARY_PATTERNS:
            if pattern.match(line):
                return True
        return False

    def _should_keep_with_previous(self, line: str) -> bool:
        """Check if this line should stay with the previous chunk."""
        for pattern in self.KEEP_WITH_PREVIOUS:
            if pattern.match(line):
                return True
        return False

    def _merge_small_chunks(self, chunks: List[str]) -> List[str]:
        """Merge chunks smaller than MIN_CHUNK_SIZE with neighbors."""
        if len(chunks) <= 1:
            return chunks

        merged = []
        i = 0
        while i < len(chunks):
            current = chunks[i]

            # If this is the last chunk and it's small, merge with previous
            if len(current) < self.MIN_CHUNK_SIZE and i == len(chunks) - 1 and merged:
                merged[-1] = merged[-1] + '\n' + current
            # If there's a next chunk and this one is small
            elif len(current) < self.MIN_CHUNK_SIZE and i + 1 < len(chunks):
                # Merge current + next
                merged.append(current + '\n' + chunks[i + 1])
                i += 2
                continue
            else:
                merged.append(current)
            i += 1

        return merged

    def _add_overlap(self, chunks: List[str]) -> List[str]:
        """Add context overlap between chunks for continuity."""
        if len(chunks) <= 1:
            return chunks

        overlapped = []
        for i, chunk in enumerate(chunks):
            if i > 0:
                # Prepend last OVERLAP_SIZE chars of previous chunk as context
                prev = chunks[i - 1]
                overlap_text = prev[-self.OVERLAP_SIZE:] if len(prev) > self.OVERLAP_SIZE else prev
                chunk = f"[...continued from previous chunk...]\n{overlap_text}\n---\n{chunk}"

            if i < len(chunks) - 1:
                # Append first OVERLAP_SIZE chars of next chunk as preview
                next_chunk = chunks[i + 1]
                preview_text = next_chunk[:self.OVERLAP_SIZE] if len(next_chunk) > self.OVERLAP_SIZE else next_chunk
                chunk = f"{chunk}\n---\n{preview_text}\n[...continues in next chunk...]"

            overlapped.append(chunk)

        return overlapped

    # ------------------------------------------------------------------
    # Utility
    # ------------------------------------------------------------------

    def estimate_chunks(self, content: str) -> int:
        """Estimate how many chunks the content will be split into."""
        if not content:
            return 1
        return max(1, len(content) // self.chunk_size + 1)
