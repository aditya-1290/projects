"""
Tools registered to the Preprocessor Agent
"""

from typing import Dict, Any


class PreprocessorTools:
    """Collection of tools available to the Preprocessor agent"""

    def __init__(self):
        self.tools = {
            "clean_logs": self.clean_logs,
            "parse_logs": self.parse_logs,
            "normalize_logs": self.normalize_logs,
            "chunk_logs": self.chunk_logs,
        }

    async def clean_logs(self, content: str, remove_noise: bool = True) -> str:
        """Clean raw log content"""
        from agents.preprocessor.cleaner import LogCleaner
        cleaner = LogCleaner()
        return await cleaner.clean(content)

    async def parse_logs(self, content: str) -> Dict:
        """Parse logs into structured format"""
        from agents.preprocessor.parser import LogParser
        parser = LogParser()
        return await parser.parse(content)

    async def normalize_logs(self, parsed_logs: Dict) -> Dict:
        """Normalize parsed log entries"""
        from agents.preprocessor.normalizer import LogNormalizer
        normalizer = LogNormalizer()
        return await normalizer.normalize(parsed_logs)

    async def chunk_logs(self, parsed_logs: Dict, chunk_size: int = 4000) -> Dict:
        """Chunk large logs"""
        from agents.preprocessor.chunker import LogChunker
        chunker = LogChunker()
        return await chunker.chunk(parsed_logs, chunk_size=chunk_size)

    def get_tool(self, tool_name: str):
        """Get a tool by name"""
        return self.tools.get(tool_name)
