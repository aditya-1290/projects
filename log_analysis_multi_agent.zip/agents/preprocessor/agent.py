"""
Preprocessor Agent

Uses Qwen2.5-3B for intelligent log cleaning, parsing, and chunking.
This is the second step in the pipeline after extraction.
"""

from typing import Dict, Any, List

from agents.base_agent import BaseAgent, A2AMessage, MessageType
from agents.preprocessor.prompts import (
    SKILL_LOG_CLEANING,
    SKILL_NOISE_REMOVAL,
    SKILL_LOG_PARSING,
    SKILL_TIMESTAMP_NORMALIZATION,
    SKILL_IP_NORMALIZATION,
    SKILL_CHUNK_STRATEGY,
    SKILL_STRUCTURE_DETECTION,
    SKILL_LOG_FORMAT_DETECTION,
    SKILL_FIELD_EXTRACTION,
    SKILL_LOG_DEDUPLICATION,
    SKILL_MULTILINE_MERGING,
)

class PreprocessorAgent(BaseAgent):
    """Cleans, parses, and structures raw logs"""

    def __init__(self):
        super().__init__("preprocessor_v1", "agents/preprocessor/capabilities.json")

        # ═══════════════════════════════════════════════════════════════════════════
        # ADK Integration — Tool Registration
        # ═══════════════════════════════════════════════════════════════════════════

    def _get_model_requirements(self) -> list:
        return ["qwen2.5-3b-it"]

    def _resolve_adk_model(self) -> str:
        return "qwen2.5-3b-it"

    def _get_adk_tools(self) -> list:
        """Register log cleaning, parsing, and normalization as ADK tools."""
        return [
                {
                    "name": "clean_and_structure_logs",
                    "description": "Clean raw logs by removing noise, parsing into structured format, normalizing timestamps and IPs, and chunking if needed.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "raw_logs": {
                                "type": "string",
                                "description": "Raw log content to preprocess"
                            },
                            "options": {
                                "type": "object",
                                "description": "Processing options",
                                "properties": {
                                    "clean": {"type": "boolean", "default": True},
                                    "parse": {"type": "boolean", "default": True},
                                    "normalize": {"type": "boolean", "default": True},
                                    "chunk": {"type": "boolean", "default": True}
                                }
                            }
                        },
                        "required": ["raw_logs"]
                    }
                },
                {
                    "name": "detect_log_format",
                    "description": "Auto-detect the log format from content. Returns format name and confidence.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "content": {
                                "type": "string",
                                "description": "Log content sample to analyze"
                            }
                        },
                        "required": ["content"]
                    }
                }
        ]

    def _build_adk_instruction(self) -> str:
        """Build the preprocessor's ADK instruction."""
        return """You are the Preprocessor Agent for a log analysis system.

    Your job is to prepare raw logs for analysis by other agents.

    TOOLS AVAILABLE:
    - clean_and_structure_logs: Full preprocessing pipeline (clean → parse → normalize → chunk)
    - detect_log_format: Identify the log format from content

    PROCESSING STEPS:
    1. CLEAN: Remove noise (empty lines, ANSI codes, binary garbage, UI chrome)
    2. PARSE: Structure unstructured logs (extract timestamp, level, message, service)
    3. NORMALIZE: Standardize timestamps to UTC ISO-8601, normalize IP addresses
    4. CHUNK: Split large logs into LLM-friendly chunks (~5000 chars each)

    When preprocessing, preserve:
    - Exact error messages and stack traces
    - Original timestamps (normalize to UTC but keep original)
    - Service/component names
    - Log severity levels
    """

    def _select_preprocessor_skill(self, step: str, raw_logs: str, log_size: int, has_multiline: bool):
        """Select the best preprocessor skill based on pipeline step and log characteristics.
        Returns (prompt_template, skill_name)."""

        if step == "clean":
            if has_multiline:
                return SKILL_MULTILINE_MERGING, "multiline_merging"
            if log_size > 100000:
                return SKILL_NOISE_REMOVAL, "noise_removal"
            return SKILL_LOG_CLEANING, "log_cleaning"

        elif step == "parse":
            logs_sample = raw_logs[:500].lower()
            if any(kw in logs_sample for kw in ['json', '{', 'xml', '<html']):
                return SKILL_LOG_FORMAT_DETECTION, "log_format_detection"
            if log_size > 50000:
                return SKILL_STRUCTURE_DETECTION, "structure_detection"
            return SKILL_FIELD_EXTRACTION, "field_extraction"

        elif step == "normalize":
            return SKILL_TIMESTAMP_NORMALIZATION, "timestamp_normalization"

        elif step == "chunk":
            if log_size > 200000:
                return SKILL_CHUNK_STRATEGY, "chunk_strategy"
            return SKILL_LOG_DEDUPLICATION, "log_deduplication"

        return SKILL_LOG_PARSING, "log_parsing"

    async def process(self, message: A2AMessage) -> A2AMessage:
        """
        Process raw logs through the preprocessing pipeline:
        1. Clean noise
        self.log_agent_event("process_start", {"input_size": len(str(message.task)), "action": message.task.get("action", "unknown")})
        2. Parse structure
        3. Normalize
        4. Chunk if needed
        """
        task = message.task or {}
        context = message.context or {}

        # Try multiple sources for raw_logs
        raw_logs = (
                task.get("raw_logs") or
                context.get("raw_logs") or
                context.get("previous_results", {}).get("subtask_0", {}).get("response", {}).get("raw_logs") or
                context.get("previous_results", {}).get("subtask_0", {}).get("response", {}).get("content") or
                task.get("content") or
                ""
        )

        if not raw_logs or not raw_logs.strip():
            # Instead of error loop, return a graceful response
            self.log("No raw logs provided - returning empty result")
            return A2AMessage(
                message_type=MessageType.RESPONSE,  # Use RESPONSE not ERROR
                sender_id=self.agent_id,
                sender_type="preprocessor",
                target_id=message.sender_id,
                correlation_id=message.message_id,
                response={
                    "clean_logs": "",
                    "chunks": [],
                    "is_chunked": False,
                    "chunk_count": 0,
                    "warning": "No logs to preprocess - extraction may have failed"
                },
                confidence=0.0,
                caveats=["Extraction step did not provide any logs to process"]
            )

        self.log(f"Preprocessing {len(raw_logs)} characters of logs")
        has_multiline = any(kw in raw_logs[:1000] for kw in ['Traceback', 'stack trace', '\\n    at ', 'Caused by:'])
        skill_prompt, skill_name = self._select_preprocessor_skill("preprocess", raw_logs, len(raw_logs), has_multiline)
        self.log(f"Preprocessor using skill: {skill_name}", "INFO")

        try:
            # Step 1: Clean
            self.log("Step 1/4: Cleaning logs...")
            cleaned_logs = await self._clean(raw_logs)

            # Step 2: Parse
            self.log("Step 2/4: Parsing structure...")
            parsed_logs = await self._parse(cleaned_logs)

            # Step 3: Normalize
            self.log("Step 3/4: Normalizing...")
            normalized_logs = await self._normalize(parsed_logs)

            # Step 4: Chunk if needed
            self.log("Step 4/4: Checking if chunking needed...")
            result = await self._chunk_if_needed(normalized_logs)

            self.log(f"Preprocessing complete: {result['chunk_count']} chunks, "
                     f"{result['total_length']} chars total")

            return A2AMessage(
                message_type=MessageType.RESPONSE,
                sender_id=self.agent_id,
                sender_type="preprocessor",
                target_id=message.sender_id,
                correlation_id=message.message_id,
                response={
                    "clean_logs": result["content"],
                    "raw_logs": raw_logs,  # 🔥 ADD THIS
                    "chunks": result.get("chunks", []),
                    "is_chunked": result["is_chunked"],
                    "chunk_count": result["chunk_count"],
                    "original_length": len(raw_logs),
                    "cleaned_length": result["total_length"],
                    "format_detected": result.get("format", "text"),
                    "noise_removed_lines": result.get("noise_removed", 0),
                    "skill_used": skill_name,
                },
                confidence=0.9,
                context=message.context
            )

        except Exception as e:
            self.log(f"Error: {e}", "ERROR")
            return A2AMessage(
                message_type=MessageType.ERROR,
                sender_id=self.agent_id,
                sender_type="preprocessor",
                target_id=message.sender_id,
                correlation_id=message.message_id,
                error=f"Preprocessing failed: {str(e)}"
            )

    async def _clean(self, raw_logs: str) -> str:
        """Remove noise from raw logs"""
        from agents.preprocessor.cleaner import LogCleaner
        cleaner = LogCleaner()

        # Skip LLM for large inputs — regex is faster and sufficient
        if len(raw_logs) > 10000:  # CHANGED from < 500 to > 10000
            return await cleaner.clean(raw_logs, model=None)

        # Try with Qwen model only for small inputs
        try:
            model = await self.get_model("qwen_small")
            result = await cleaner.clean(raw_logs, model=model)
            result_text = result.text if hasattr(result, "text") else str(result)
            self.log_agent_event("llm_call", {
                "action": "clean_logs",
                "model": "qwen_small",
                "max_tokens_limit": 2048,
                "input_tokens": len(raw_logs) // 4,
                "output_tokens": len(result_text) // 4,
                "total_tokens": (len(raw_logs) + len(result_text)) // 4,
                "token_source": "estimated",
            })
            return result
        except Exception:
            return await cleaner.clean(raw_logs, model=None)

    async def _parse(self, cleaned_logs: str) -> Dict:
        """Parse cleaned logs into structured format"""
        from agents.preprocessor.parser import LogParser
        parser = LogParser()

        if len(cleaned_logs) < 500:
            return await parser.parse(cleaned_logs, model=None)

        try:
            model = await self.get_model("qwen_small")
            result = await parser.parse(cleaned_logs, model=model)
            result_text = result.text if hasattr(result, "text") else str(result)
            self.log_agent_event("llm_call", {
                "action": "parse_logs",
                "model": "qwen_small",
                "max_tokens_limit": 1024,
                "input_tokens": len(cleaned_logs) // 4,
                "output_tokens": len(result_text) // 4,
                "total_tokens": (len(cleaned_logs) + len(result_text)) // 4,
                "token_source": "estimated",
            })
            return result
        except Exception:
            return await parser.parse(cleaned_logs, model=None)

    async def _normalize(self, parsed_logs: Dict) -> Dict:
        """Normalize timestamps, IPs, and other fields"""
        from agents.preprocessor.normalizer import LogNormalizer
        normalizer = LogNormalizer()
        return await normalizer.normalize(parsed_logs)

    async def _chunk_if_needed(self, normalized_logs: Dict) -> Dict:
        """Chunk large logs for processing"""
        from agents.preprocessor.chunker import LogChunker
        chunker = LogChunker()

        # Use cleaned raw content instead of parsed entries
        # Parsed entries may have dropped lines during structure detection
        content = normalized_logs.get("content", "")
        if not content:
            # Fallback: reconstruct from entries
            entries = normalized_logs.get("entries", [])
            content = "\n".join(e.get("raw", e.get("_raw", str(e))) for e in entries if isinstance(e, dict))

        self.log(f"DEBUG chunker: content_len={len(content)}, entries_count={len(normalized_logs.get('entries', []))}",
                 "INFO")

        if not content or len(content) < 500:
            return await chunker.chunk(normalized_logs, model=None)

        # Build a chunk-friendly dict with the full content
        chunk_input = {
            "content": content,
            "entries": normalized_logs.get("entries", []),
            "total_lines": normalized_logs.get("total_lines", 0),
            "format": normalized_logs.get("format", "text"),
        }

        try:
            model = await self.get_model("qwen_small")
            result = await chunker.chunk(chunk_input, model=model)
            result_text = result.text if hasattr(result, "text") else str(result)
            self.log_agent_event("llm_call", {
                "action": "chunk_strategy",
                "model": "qwen_small",
                "max_tokens_limit": 2048,
                "input_tokens": len(str(chunk_input)) // 4,
                "output_tokens": len(result_text) // 4,
                "total_tokens": (len(str(chunk_input)) + len(result_text)) // 4,
                "token_source": "estimated",
            })
            return result
        except Exception:
            return await chunker.chunk(chunk_input, model=None)


