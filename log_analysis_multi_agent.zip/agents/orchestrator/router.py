"""
Agent Router - Finds the right agent for each task
Uses Communication Bus discovery, NOT direct imports
"""

from typing import Dict, Optional, List


class AgentRouter:
    """Routes tasks to capable agents via Communication Bus discovery"""

    # Action to agent type mapping (for routing, not importing)
    ACTION_AGENT_TYPE_MAP = {
        "extract": "extractor",
        "preprocess": "preprocessor",
        "analyze": "analyzer",
        "solve": "solver",
        "debug": "debugger",
        "validate": "critic",
        "store": "memory",
        "retrieve": "memory"
    }

    # Capability requirements for each task action
    ACTION_CAPABILITIES = {
        "extract": ["extract_from_text_file", "extract_from_log_file", "extract_from_pasted_text"],
        "preprocess": ["clean_logs", "parse_logs", "chunk_large_inputs"],
        "analyze": ["classify_logs", "detect_intent"],
        "solve": ["root_cause_analysis", "generate_fix_suggestions"],
        "debug": ["parse_stack_trace", "generate_code_patch"],
        "validate": ["validate_solution_quality", "detect_hallucinations"],
        "store": ["store_log_analysis"],
        "retrieve": ["retrieve_similar_cases"]
    }

    def __init__(self, comm_bus):
        self.comm_bus = comm_bus  # Only dependency is the bus
        self.agent_cache: Dict[str, str] = {}  # action -> agent_id

    def get_agent_type_for_action(self, action: str) -> Optional[str]:
        """Get the agent type for an action - no imports needed"""
        return self.ACTION_AGENT_TYPE_MAP.get(action)

    async def find_agent_for_task(self, task: Dict) -> Optional[str]:
        """
        Find the best agent via Communication Bus discovery.
        Never imports other agents directly.
        """
        action = task.get("action", "")

        # Check cache first
        if action in self.agent_cache:
            cached_id = self.agent_cache[action]
            if cached_id and await self._is_agent_available(cached_id):
                return cached_id

        # Get agent type from mapping
        agent_type = self.get_agent_type_for_action(action)
        if not agent_type:
            return None

        # Query communication bus for this agent type
        agent_id = await self.comm_bus.find_agent_by_type(agent_type)

        if agent_id:
            self.agent_cache[action] = agent_id

        return agent_id

    async def find_agents_for_pipeline(self, actions: List[str]) -> Dict[str, str]:
        """
        Find agents for an entire pipeline.

        Returns:
            Dict mapping action -> agent_id
        """
        mapping = {}

        for action in actions:
            agent_id = await self.find_agent_for_task({"action": action})
            if agent_id:
                mapping[action] = agent_id

        return mapping

    async def _is_agent_available(self, agent_id: str) -> bool:
        """Check if an agent is available"""
        try:
            status = await self.comm_bus.get_status()
            agents = status.get("agents", [])

            for agent in agents:
                if agent.get("id") == agent_id:
                    return agent.get("state") not in ["error", "unregistered"]
        except Exception:
            pass

        return False

    def clear_cache(self):
        """Clear the agent routing cache"""
        self.agent_cache.clear()

    def get_routing_stats(self) -> Dict:
        """Get routing statistics"""
        return {
            "cached_routes": len(self.agent_cache),
            "cached_actions": list(self.agent_cache.keys())
        }

    