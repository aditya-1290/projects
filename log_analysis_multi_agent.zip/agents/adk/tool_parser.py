"""
Tool Call Parser Bridge � Parses Gemma/Qwen plain-text tool calls
and manually executes the matching ADK tool.

Handles formats like:
  <|tool_call>call:full_pipeline{query:"..."}<tool_call|>
  <|tool_call>call:extract_file{path:"..."}<tool_call|>
"""

import re
import json
import asyncio
from typing import Optional, Dict, Any


def parse_tool_call(text: str) -> Optional[Dict[str, Any]]:
    """
    Parse a plain-text tool call from model output.

    Returns:
        {"tool_name": "...", "args": {...}} or None if no tool call found
    """
    if not text:
        return None

    # Pattern: <|tool_call>call:TOOL_NAME{key:value,...}<tool_call|>
    pattern = r"<\|tool_call\>\s*call:(\w+)\s*\{([^}]*(?:\{[^}]*\}[^}]*)*)\}\s*<tool_call\|>"
    match = re.search(pattern, text, re.DOTALL)

    if not match:
        return None

    tool_name = match.group(1).strip()
    args_text = match.group(2).strip()
    args = {}

    # Parse query:"value" or query:<|"|>value<|"|>
    for param in ['query', 'path', 'content', 'command', 'raw_logs', 'clean_logs',
                  'stack_trace', 'solution', 'original_logs', 'log_content',
                  'analysis', 'log_type', 'question', 'source1', 'source2', 'pattern']:
        # Try Gemma format: key:<|"|>value<|"|>
        m = re.search(rf'{param}\s*:\s*<\|"?\|?>(.+?)<\|"?\|?', args_text, re.DOTALL)
        if not m:
            # Try standard format: key:"value"
            m = re.search(rf'{param}\s*:\s*"([^"]*)"', args_text, re.DOTALL)
        if not m:
            # Try key=value
            m = re.search(rf'{param}\s*=\s*[\'"]([^\'"]*)[\'"]', args_text, re.DOTALL)
        if m:
            args[param] = m.group(1).strip()

    # Parse numeric/integer params
    for param in ['limit', 'level', 'intent', 'language']:
        m = re.search(rf'{param}["\':\s]+([^"\'}},\s]+)', args_text)
        if m:
            val = m.group(1).strip().strip('"').strip("'")
            args[param] = val

    # If no structured params found, use entire args_text as query
    if not args:
        args["query"] = args_text.strip().strip('"').strip("'")

    return {
        "tool_name": tool_name,
        "args": args,
    }


def format_tool_response(tool_name: str, result: str, max_chars: int = 5000) -> str:
    """Format a tool result back to the model."""
    if tool_name == "full_pipeline":
        max_chars = 1000000
    return f"<|tool_response>response:{tool_name}{{value:<|\"|>{result[:max_chars]}<|\"|>}}<tool_response|>"


async def execute_parsed_tool(parsed: Dict, tools_map: Dict) -> Optional[str]:
    """
    Execute a parsed tool call against the tools map.

    Args:
        parsed: {"tool_name": "...", "args": {...}}
        tools_map: {"tool_name": tool_function, ...}

    Returns:
        Tool execution result as string, or None if tool not found
    """
    tool_name = parsed["tool_name"]
    args = parsed["args"]

    tool_fn = tools_map.get(tool_name)
    if not tool_fn:
        print(f"[TOOL PARSER] Unknown tool: {tool_name}")
        return None

    try:
        print(f"[TOOL PARSER] Executing: {tool_name}({args})")

        # Create a fake tool context
        class FakeContext:
            state = {}

        ctx = FakeContext()

        # Check if the function accepts tool_context parameter
        import inspect
        try:
            sig = inspect.signature(tool_fn)
            accepts_tool_context = 'tool_context' in sig.parameters
        except Exception:
            accepts_tool_context = False

        # Call the tool function
        if asyncio.iscoroutinefunction(tool_fn):
            if accepts_tool_context:
                result = await tool_fn(tool_context=ctx, **args)
            else:
                result = await tool_fn(**args)
        else:
            if accepts_tool_context:
                result = tool_fn(tool_context=ctx, **args)
            else:
                result = tool_fn(**args)

        print(f"[TOOL PARSER] Result length: {len(str(result))}")
        return str(result)

    except Exception as e:
        import traceback
        print(f"[TOOL PARSER] Error executing {tool_name}: {e}")
        print(f"[TOOL PARSER] Traceback: {traceback.format_exc()}")
        return f"Error executing {tool_name}: {str(e)}"
