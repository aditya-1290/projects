"""Register Elasticsearch MCP tools for the ADK agent."""
import json
import inspect
from google.adk.tools.base_tool import BaseTool, ToolContext


def make_tool(fn):
    """Create an ADK tool from a function."""
    sig = inspect.signature(fn)
    params = list(sig.parameters.keys())
    user_params = [p for p in params if p != 'tool_context']

    class SimpleTool(BaseTool):
        def __init__(self, func):
            super().__init__(name=func.__name__, description=func.__doc__ or "")
            self._func = func
            self._user_params = user_params

        async def run_async(self, *, args: dict, tool_context: ToolContext) -> str:
            filtered = {k: v for k, v in args.items() if k in self._user_params}
            return await self._func(tool_context=tool_context, **filtered)

    return SimpleTool(fn)


async def es_search_mcp(query: str, tool_context=None) -> str:
    """Search Elasticsearch. Use for: es: logs-* ERROR, es: find errors from yesterday, es: show me all critical logs"""
    from agents.extractor.loaders.es_loader import ElasticsearchLoader

    if query.lower().startswith("es:"):
        query = query[3:].strip()

    loader = ElasticsearchLoader()
    if not loader.is_available():
        return json.dumps({"error": "Elasticsearch not available. Set ELASTICSEARCH_HOSTS env var."})

    try:
        result = await loader.search(
            index="logs-*",
            query={"query_string": {"query": query}},
            size=100
        )
        return result if isinstance(result, str) else json.dumps(result)
    except Exception as e:
        return json.dumps({"error": str(e)})


async def es_list_indices_mcp(pattern: str = "*", tool_context=None) -> str:
    """List available Elasticsearch indices."""
    from agents.extractor.loaders.es_loader import ElasticsearchLoader

    loader = ElasticsearchLoader()
    if not loader.is_available():
        return json.dumps({"error": "Elasticsearch not available"})

    indices = await loader.list_indices(pattern)
    return json.dumps({"indices": indices, "count": len(indices)})


async def es_health_mcp(tool_context=None) -> str:
    """Check Elasticsearch cluster health."""
    from agents.extractor.loaders.es_loader import ElasticsearchLoader

    loader = ElasticsearchLoader()
    if not loader.is_available():
        return json.dumps({"status": "unavailable"})

    health = await loader.health_check()
    return json.dumps(health)


def register_es_mcp_tools():
    """Register Elasticsearch MCP tools and return them."""
    tools = []
    for fn in [es_search_mcp, es_list_indices_mcp, es_health_mcp]:
        tools.append(make_tool(fn))
    return tools

