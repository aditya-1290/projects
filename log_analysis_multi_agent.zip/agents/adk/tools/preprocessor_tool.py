"""Preprocessor Tools — Clean, parse, normalize, and filter logs."""
import httpx
from google.adk.tools.base_tool import ToolContext

API_BASE = "http://127.0.0.1:8004"


async def _post(endpoint: str, data: dict, timeout: int = 1200) -> dict:
    async with httpx.AsyncClient(timeout=timeout) as client:
        response = await client.post(f"{API_BASE}{endpoint}", json=data)
        return response.json() if response.status_code == 200 else {"error": response.text}


async def preprocess_logs(raw_logs: str, tool_context: ToolContext) -> str:
    """
    Clean, parse, normalize, and chunk raw log entries.
    Returns structured, clean logs ready for analysis.
    """
    tool_context.state["status"] = "preprocessing"
    result = await _post("/agent/preprocessor", {"action": "preprocess","query": raw_logs})
    return result.get("response", str(result))


async def filter_logs(
        clean_logs: str,
        level: str = None,
        service: str = None,
        time_range_start: str = None,
        time_range_end: str = None,
        tool_context: ToolContext = None,
) -> str:
    """
    Filter preprocessed logs by severity level, service name, or time range.

    Args:
        clean_logs: Preprocessed log content
        level: Filter by severity (ERROR, WARN, INFO, DEBUG)
        service: Filter by service name
        time_range_start: Start time (ISO format)
        time_range_end: End time (ISO format)
    """
    if tool_context:
        tool_context.state["status"] = "filtering"

    # Build filter query
    filters = []
    if level:
        filters.append(f"level:{level}")
    if service:
        filters.append(f"service:{service}")
    if time_range_start:
        filters.append(f"from:{time_range_start}")
    if time_range_end:
        filters.append(f"to:{time_range_end}")

    query = f"filter logs: {', '.join(filters)}\n\n{clean_logs[:5000]}"
    result = await _post("/agent/preprocessor", {"action": "preprocess", "query": query})
    return result.get("response", str(result))
