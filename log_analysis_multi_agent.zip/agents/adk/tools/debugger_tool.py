"""Debugger Tools — Stack trace parsing and code patch generation."""
import httpx
from google.adk.tools.base_tool import ToolContext

API_BASE = "http://127.0.0.1:8004"


async def _post(endpoint: str, data: dict, timeout: int = 1200) -> dict:
    async with httpx.AsyncClient(timeout=timeout) as client:
        response = await client.post(f"{API_BASE}{endpoint}", json=data)
        return response.json() if response.status_code == 200 else {"error": response.text}


async def debug_trace(
        stack_trace: str,
        language: str = "auto",
        tool_context: ToolContext = None,
) -> str:
    """
    Parse a stack trace and generate code patches with language-specific analysis.

    Args:
        stack_trace: Full stack trace text to analyze
        language: Programming language (python, java, javascript, typescript, go, auto)
    """
    if tool_context: tool_context.state["status"] = "debugging"
    async with httpx.AsyncClient(timeout=1200) as client:
        response = await client.post(f"{API_BASE}/agent/debugger", json={
            "action": "debug", "stack_trace": stack_trace, "language": language
        })
        data = response.json() if response.status_code == 200 else {"error": response.text}
        return data.get("response", str(data))
