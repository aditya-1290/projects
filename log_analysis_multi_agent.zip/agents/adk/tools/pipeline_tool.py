"""Pipeline Tools — Full pipeline execution, comparison, and NL queries."""
import httpx
from google.adk.tools.base_tool import ToolContext

API_BASE = "http://127.0.0.1:8004"


async def _post(endpoint: str, data: dict, timeout: int = 3600) -> dict:
    async with httpx.AsyncClient(timeout=timeout) as client:
        response = await client.post(f"{API_BASE}{endpoint}", json=data)
        return response.json() if response.status_code == 200 else {"error": response.text}


async def full_pipeline(query: str, tool_context: ToolContext) -> str:
    """
    Run the complete log analysis pipeline.
    Handles: files, pasted text, terminal commands, images, and natural language questions.

    Pipeline: extract → preprocess → analyze → solve → validate

    Args:
        query: Log entries, file path, terminal command (command:...), or image path
    """
    tool_context.state["status"] = "running_full_pipeline"
    result = await _post("/run", {"query": query})
    return result.get("response", str(result))


async def compare_logs(source1: str, source2: str, tool_context: ToolContext) -> str:
    """
    Compare two log sources and identify differences.

    Args:
        source1: First log source (file path or pasted content)
        source2: Second log source (file path or pasted content)
    """
    tool_context.state["status"] = "comparing"
    query = f"compare these two log sources:\n\nSource 1: {source1[:3000]}\n\nSource 2: {source2[:3000]}"
    result = await _post("/run", {"query": query})
    return result.get("response", str(result))


async def natural_language_query(question: str, tool_context: ToolContext) -> str:
    """
    Handle general natural language questions about logs.

    Examples:
    - "show me all errors from auth-service"
    - "what caused the timeout yesterday"
    - "are there any security issues"
    - "summarize the production errors from today"

    Args:
        question: Natural language question about logs
    """
    tool_context.state["status"] = "processing_query"
    result = await _post("/run", {"query": question})
    return result.get("response", str(result))
