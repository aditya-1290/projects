"""
Safety Checker - Audits solutions for security and safety issues
"""

import re
from typing import Dict, List


class SafetyChecker:
    """Audits solutions for potential safety and security concerns"""

    # Dangerous patterns in commands and code
    DANGEROUS_PATTERNS = [
        (re.compile(r'rm\s+-rf\s+/'), 'DANGER: Recursive force delete from root'),
        (re.compile(r'dd\s+if='), 'WARNING: Disk operations with dd'),
        (re.compile(r'>\s*/dev/sd[a-z]'), 'DANGER: Writing directly to disk device'),
        (re.compile(r'mkfs\.'), 'WARNING: Filesystem creation'),
        (re.compile(r'chmod\s+777'), 'WARNING: Overly permissive chmod'),
        (re.compile(r'sudo\s+'), 'WARNING: sudo command usage'),
        (re.compile(r'DROP\s+TABLE', re.IGNORECASE), 'DANGER: Database table deletion'),
        (re.compile(r'DELETE\s+FROM', re.IGNORECASE), 'WARNING: Database deletion'),
        (re.compile(r'shutdown|reboot|halt'), 'WARNING: System shutdown/reboot'),
        (re.compile(r'kill\s+-9'), 'WARNING: Force kill process'),
    ]

    # Patterns that require user confirmation
    CAUTION_PATTERNS = [
        (re.compile(r'chown\s+'), 'Changing file ownership'),
        (re.compile(r'chmod\s+'), 'Changing file permissions'),
        (re.compile(r'mv\s+'), 'Moving files'),
        (re.compile(r'cp\s+'), 'Copying files'),
        (re.compile(r'systemctl\s+(stop|disable)'), 'Stopping/disabling service'),
        (re.compile(r'firewall-cmd|iptables|ufw'), 'Firewall modification'),
    ]

    async def audit(self, solution: Dict, model=None) -> Dict:
        """
        Audit a solution for safety concerns.

        Returns:
            {
                "passed": bool,
                "confidence": float,
                "issues": List[str],
                "requires_human_approval": bool,
                "dangerous_commands": List[str],
                "caution_commands": List[str]
            }
        """
        issues = []
        dangerous = []
        cautions = []

        fix = solution.get("fix_suggestion", {})
        commands = fix.get("commands_to_run", [])
        code_changes = fix.get("code_changes", [])

        # Check commands
        for command in commands:
            # Check dangerous patterns
            for pattern, description in self.DANGEROUS_PATTERNS:
                if pattern.search(str(command)):
                    issues.append(f"{description}: {command}")
                    dangerous.append(command)

            # Check caution patterns
            for pattern, description in self.CAUTION_PATTERNS:
                if pattern.search(str(command)):
                    cautions.append({"command": command, "concern": description})

        # Check code changes for dangerous operations
        for code in code_changes:
            code_str = str(code)

            # Check for dangerous patterns in code
            if re.search(r'exec\(|eval\(|system\(', code_str):
                issues.append("Code contains dangerous execution functions (exec/eval/system)")

            if re.search(r'os\.remove|os\.unlink|shutil\.rmtree', code_str):
                issues.append("Code contains file deletion operations")

        # Check if human approval is required
        requires_human = len(dangerous) > 0

        passed = len(issues) == 0

        return {
            "passed": passed,
            "confidence": 0.9 if passed else 0.2,
            "issues": issues,
            "requires_human_approval": requires_human,
            "dangerous_commands": dangerous,
            "caution_commands": cautions,
            "checks_performed": ["command_audit", "code_audit", "dangerous_pattern_check"]
        }