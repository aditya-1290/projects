"""
Critic Agent

Uses Gemma-4-E4B to validate solutions, detect hallucinations,
and ensure output quality. Acts as a safety gate before
presenting results to the user.
"""

from typing import Dict, Any, List

from agents.base_agent import BaseAgent, A2AMessage, MessageType
from agents.critic.prompts import (
    SKILL_FACTUAL_CONSISTENCY,
    SKILL_LOGICAL_COHERENCE,
    SKILL_COMPLETENESS_CHECK,
    SKILL_SAFETY_AUDIT,
    SKILL_HALLUCINATION_DETECTION,
    SKILL_CONFIDENCE_CALIBRATION,
    SKILL_RETRY_FEEDBACK,
    SKILL_SOLUTION_COMPARISON,
    SKILL_EDGE_CASE_TESTING,
    SKILL_OUTPUT_QUALITY_SCORING,
)

class CriticAgent(BaseAgent):
    """Validates solutions and ensures output quality"""

    def __init__(self):
        super().__init__("critic_v1", "agents/critic/capabilities.json")

        # ═══════════════════════════════════════════════════════════════════════════
        # ADK Integration
        # ═══════════════════════════════════════════════════════════════════════════

    def _get_model_requirements(self) -> list:
        return ["gemma-4-e4b-it"]

    def _resolve_adk_model(self) -> str:
        return "gemma-4-e4b-it"

    def _build_adk_instruction(self) -> str:
        """Build the critic's ADK instruction from skill prompts."""
        return """You are the Critic Agent for a log analysis system.

    Your job is to validate solutions produced by other agents. You check:

    1. FACTUAL CONSISTENCY — Does every claim match the log evidence?
       - No invented errors, components, timelines, or metrics
       - Every claim must be traceable to a specific log line

    2. LOGICAL COHERENCE — Does the reasoning make sense?
       - Cause → effect chain must be valid
       - No post-hoc fallacies ("A happened before B, so A caused B")
       - Alternative explanations considered

    3. COMPLETENESS — Is everything addressed?
       - Root cause identified with evidence
       - Fix suggested at multiple levels
       - Prevention recommended
       - Impact assessed

    4. SAFETY — Could the fix make things worse?
       - No data loss risk
       - No security weakening
       - Rollback plan exists
       - Appropriate approvals noted

    5. HALLUCINATION DETECTION — Is anything fabricated?
       - Flag unsupported claims
       - Flag invented metrics/numbers
       - Flag overconfident statements with thin evidence

    If validation FAILS (confidence < 0.5), provide specific retry feedback
    so the solver can improve on the next attempt.

    Respond with: validation_passed, confidence, checks, issues, suggestions,
    retry_feedback (if needed)
    """

    async def process(self, message: A2AMessage) -> A2AMessage:
        """Validate a solution against quality criteria"""
        task = message.task or {}
        context = message.context or {}

        solution = context.get("solution", task.get("solution", {}))
        original_logs = (
                context.get("raw_logs") or
                context.get("clean_logs") or
                task.get("original_logs", "")
        )

        if not solution:
            return A2AMessage(
                message_type=MessageType.ERROR,
                sender_id=self.agent_id,
                sender_type="critic",
                target_id=message.sender_id,
                correlation_id=message.message_id,
                error="No solution provided for validation"
            )

        self.log("Starting solution validation...")

        try:
            model = await self.get_model("gemma")

            # Run validation checks
            validation_results = await self._validate(solution, original_logs, model)

            passed = validation_results.get("passed", False)
            confidence = validation_results.get("overall_confidence", 0.0)

            # 🔥 TEMP: allow partial success
            if not passed and confidence > 0.6:
                passed = True

            self.log(f"Validation complete: {'PASSED' if passed else 'FAILED'} "
                     f"(confidence: {confidence:.2f})")

            return A2AMessage(
                message_type=MessageType.RESPONSE,
                sender_id=self.agent_id,
                sender_type="critic",
                target_id=message.sender_id,
                correlation_id=message.message_id,
                response={
                    "validation_passed": passed,
                    "confidence": confidence,
                    "checks": validation_results.get("checks", {}),
                    "issues": validation_results.get("issues", []),
                    "suggestions": validation_results.get("suggestions", []),
                    "requires_retry": not passed and validation_results.get("retry_recommended", False),
                    "retry_feedback": validation_results.get("retry_feedback", "")
                },
                confidence=confidence,
                context=message.context
            )

        except Exception as e:
            self.log(f"Error: {e}", "ERROR")
            return A2AMessage(
                message_type=MessageType.ERROR,
                sender_id=self.agent_id,
                sender_type="critic",
                target_id=message.sender_id,
                correlation_id=message.message_id,
                error=f"Validation failed: {str(e)}"
            )

    def _select_critic_skill(self, check_name, solution, has_multiple_solutions, previous_failed):
        """Select the best critic skill based on check type and context.
        Returns (prompt_template, skill_name)."""

        # If previous validation failed, use retry feedback
        if previous_failed:
            return SKILL_RETRY_FEEDBACK, "retry_feedback"

        # If multiple solutions to compare
        if has_multiple_solutions:
            return SKILL_SOLUTION_COMPARISON, "solution_comparison"

        # Map check names to skills
        skill_map = {
            "factual_consistency": (SKILL_FACTUAL_CONSISTENCY, "factual_consistency"),
            "logical_coherence": (SKILL_LOGICAL_COHERENCE, "logical_coherence"),
            "completeness": (SKILL_COMPLETENESS_CHECK, "completeness_check"),
            "safety": (SKILL_SAFETY_AUDIT, "safety_audit"),
            "hallucination": (SKILL_HALLUCINATION_DETECTION, "hallucination_detection"),
            "edge_case": (SKILL_EDGE_CASE_TESTING, "edge_case_testing"),
            "quality": (SKILL_OUTPUT_QUALITY_SCORING, "output_quality_scoring"),
        }

        return skill_map.get(check_name, (SKILL_FACTUAL_CONSISTENCY, "factual_consistency"))

    async def _validate(
            self, solution: Dict, original_logs: str, model
    ) -> Dict:
        """Run all validation checks"""
        from agents.critic.evaluator import SolutionEvaluator
        from agents.critic.safety_checker import SafetyChecker

        evaluator = SolutionEvaluator()
        safety_checker = SafetyChecker()

        checks = {}
        issues = []
        suggestions = []

        # Detect context for skill selection
        has_multiple_solutions = solution.get("alternative_solutions") is not None
        previous_failed = solution.get("previous_validation_failed", False)

        # Run all checks with dynamic skill selection
        checks_config = [
            ("factual_consistency", evaluator.check_factual_consistency, [solution, original_logs, model]),
            ("logical_coherence", evaluator.check_logical_coherence, [solution, model]),
            ("completeness", evaluator.check_completeness, [solution, model]),
            ("safety", safety_checker.audit, [solution, model]),
            ("hallucination", evaluator.detect_hallucinations, [solution, original_logs, model]),
        ]

        for check_name, check_fn, check_args in checks_config:
            self.log(f"Check: {check_name}...")
            skill_prompt, skill_name = self._select_critic_skill(
                check_name, solution, has_multiple_solutions, previous_failed
            )

            try:
                result = await check_fn(*check_args)
                result["skill_used"] = skill_name
            except Exception:
                result = {"passed": False, "confidence": 0.0, "issues": [f"{check_name} check failed"],
                          "skill_used": skill_name}

            checks[check_name] = result
            if not result.get("passed"):
                issues.extend(result.get("issues", []))

        # Check 1: Factual consistency
        self.log("Check 1/5: Factual consistency...")
        factual = await evaluator.check_factual_consistency(
            solution, original_logs, model
        )
        checks["factual_consistency"] = factual
        if not factual.get("passed"):
            issues.extend(factual.get("issues", []))

        # Check 2: Logical coherence
        self.log("Check 2/5: Logical coherence...")
        logical = await evaluator.check_logical_coherence(solution, model)
        checks["logical_coherence"] = logical
        if not logical.get("passed"):
            issues.extend(logical.get("issues", []))

        # Check 3: Completeness
        self.log("Check 3/5: Completeness...")
        completeness = await evaluator.check_completeness(solution, model)
        checks["completeness"] = completeness
        if not completeness.get("passed"):
            issues.extend(completeness.get("issues", []))
            suggestions.extend(completeness.get("suggestions", []))

        # Check 4: Safety
        self.log("Check 4/5: Safety audit...")
        safety = await safety_checker.audit(solution, model)
        checks["safety"] = safety
        if not safety.get("passed"):
            issues.extend(safety.get("issues", []))

        # Check 5: Hallucination detection
        self.log("Check 5/5: Hallucination detection...")
        hallucination = await evaluator.detect_hallucinations(
            solution, original_logs, model
        )
        checks["hallucination"] = hallucination
        if hallucination.get("hallucinations_detected"):
            issues.extend(hallucination.get("issues", []))

        # Calculate overall
        all_passed = all(c.get("passed", False) for c in checks.values())
        confidence_scores = [c.get("confidence", 0.5) for c in checks.values()]
        overall_confidence = sum(confidence_scores) / len(confidence_scores) if confidence_scores else 0.5

        retry_recommended = not all_passed and overall_confidence < 0.4

        return {
            "passed": all_passed,
            "overall_confidence": round(overall_confidence, 2),
            "checks": checks,
            "issues": issues,
            "suggestions": suggestions,
            "retry_recommended": retry_recommended,
            "retry_feedback": self._build_retry_feedback(issues, suggestions) if retry_recommended else ""
        }

    def _build_retry_feedback(self, issues: List[str], suggestions: List[str]) -> str:
        """Build feedback for retry"""
        feedback = "Please address the following issues:\n"
        for issue in issues[:5]:
            feedback += f"- {issue}\n"

        if suggestions:
            feedback += "\nSuggestions for improvement:\n"
            for suggestion in suggestions[:5]:
                feedback += f"- {suggestion}\n"

        return feedback