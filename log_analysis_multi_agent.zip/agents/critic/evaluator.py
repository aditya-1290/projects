"""
Solution Evaluator - Checks solution quality
"""

import re
from typing import Dict, List


class SolutionEvaluator:
    """Evaluates solution quality across multiple dimensions"""

    async def check_factual_consistency(
            self, solution: Dict, original_logs: str, model=None
    ) -> Dict:
        """
        Check if the solution is consistent with the original logs.
        Detects hallucinations and made-up facts.
        """
        root_cause = solution.get("root_cause", {})
        fix = solution.get("fix_suggestion", {})

        issues = []

        # Check 1: Does the solution reference logs that exist?
        evidence = root_cause.get("evidence", [])
        for ev in evidence:
            if isinstance(ev, str) and len(ev) > 20:
                if ev not in original_logs:
                    # Check partial match
                    if not any(word in original_logs for word in ev.split()[:5]):
                        issues.append(f"Evidence not found in logs: {ev[:100]}...")

        # Check 2: Are the affected components mentioned in logs?
        affected = root_cause.get("affected_components", [])
        for comp in affected:
            if comp and comp not in original_logs:
                issues.append(f"Component '{comp}' not found in original logs")

        # Check 3: Is the error description consistent?
        primary_cause = root_cause.get("primary_cause", "")
        if primary_cause and len(primary_cause) > 10:
            # Check for common hallucination patterns
            hallucination_indicators = [
                "I think",
                "probably",
                "might be",
                "could be",
                "possibly"
            ]
            for indicator in hallucination_indicators:
                if indicator in primary_cause.lower():
                    issues.append(f"Uncertain language detected: '{indicator}'")

        passed = len(issues) == 0
        confidence = 1.0 if passed else max(0.3, 1.0 - (len(issues) * 0.2))

        return {
            "passed": passed,
            "confidence": confidence,
            "issues": issues,
            "checks_performed": ["evidence_verification", "component_verification", "language_check"]
        }

    async def check_logical_coherence(
            self, solution: Dict, model=None
    ) -> Dict:
        """
        Check if the solution is logically coherent.
        - Cause → Effect chain is clear
        - Fix addresses the actual cause
        - No contradictory statements
        """
        root_cause = solution.get("root_cause", {})
        fix = solution.get("fix_suggestion", {})

        issues = []

        # Check 1: Is there a clear cause-effect relationship?
        primary_cause = root_cause.get("primary_cause", "")
        immediate_actions = fix.get("immediate_actions", [])

        if primary_cause and not immediate_actions:
            issues.append("Root cause identified but no actions suggested")

        # Check 2: Do prevention measures match the cause?
        prevention = fix.get("prevention_measures", [])
        cause_category = root_cause.get("cause_category", "")

        if cause_category and prevention:
            # Simple check: prevention should be relevant to cause
            pass  # Would need deeper analysis

        # Check 3: Is severity consistent with fix urgency?
        severity = root_cause.get("severity", "")
        risk = fix.get("risk_level", "")

        if severity in ["CRITICAL", "ERROR"] and risk == "LOW":
            issues.append(f"Severity is {severity} but risk level is LOW - inconsistency")

        passed = len(issues) == 0
        confidence = 0.9 if passed else 0.5

        return {
            "passed": passed,
            "confidence": confidence,
            "issues": issues,
            "checks_performed": ["cause_effect_check", "severity_risk_alignment"]
        }

    async def check_completeness(
            self, solution: Dict, model=None
    ) -> Dict:
        """
        Check if the solution is complete.
        - Has all required sections
        - Each section has meaningful content
        - Nothing critical is missing
        """
        root_cause = solution.get("root_cause", {})
        fix = solution.get("fix_suggestion", {})
        explanation = solution.get("explanation", "")

        issues = []
        suggestions = []

        # Required fields in root cause
        required_rc_fields = ["primary_cause", "severity", "confidence"]
        for field in required_rc_fields:
            if not root_cause.get(field):
                issues.append(f"Root cause missing required field: {field}")

        # Required fields in fix
        required_fix_fields = ["immediate_actions"]
        for field in required_fix_fields:
            if not fix.get(field):
                issues.append(f"Fix missing required field: {field}")
                suggestions.append(f"Add {field} to the fix suggestion")

        # Check if explanation exists
        if not explanation:
            issues.append("No explanation generated")
            suggestions.append("Generate a human-readable explanation")

        # Check for empty lists
        if fix.get("immediate_actions") == []:
            issues.append("No immediate actions specified")
            suggestions.append("Provide at least one immediate action")

        passed = len(issues) == 0

        return {
            "passed": passed,
            "confidence": 0.8 if passed else 0.4,
            "issues": issues,
            "suggestions": suggestions,
            "checks_performed": ["required_fields", "explanation_check", "empty_lists"]
        }

    async def detect_hallucinations(
            self, solution: Dict, original_logs: str, model=None
    ) -> Dict:
        """
        Detect potential hallucinations in the solution.

        Signs of hallucination:
        - References to files/systems not in logs
        - Made-up version numbers
        - Inconsistent data
        - Overly specific claims without evidence
        """
        root_cause = solution.get("root_cause", {})
        fix = solution.get("fix_suggestion", {})

        issues = []
        hallucination_detected = False

        # Check for specific patterns that indicate hallucination
        primary_cause = root_cause.get("primary_cause", "")

        # Check for made-up specific details
        specific_patterns = [
            (r'version\s+(\d+\.\d+\.\d+)', 'version number'),
            (r'port\s+(\d+)', 'port number'),
            (r'file\s+[\'\"]?(/[\w/]+)[\'\"]?', 'file path'),
        ]

        for pattern, detail_type in specific_patterns:
            matches = re.findall(pattern, primary_cause, re.IGNORECASE)
            for match in matches:
                match_str = str(match)
                if match_str not in original_logs:
                    issues.append(f"Possible hallucination: {detail_type} '{match_str}' not in original logs")
                    hallucination_detected = True

        # Check confidence claims
        confidence = root_cause.get("confidence", 0)
        if confidence > 0.95:
            issues.append("Suspiciously high confidence (>0.95) without verification")

        return {
            "hallucinations_detected": hallucination_detected,
            "issues": issues,
            "confidence": 0.3 if hallucination_detected else 0.8,
            "passed": not hallucination_detected
        }