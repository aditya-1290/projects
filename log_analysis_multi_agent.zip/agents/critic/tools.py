"""
Tools registered to the Critic Agent
"""

from typing import Dict, Any


class CriticTools:
    """Collection of tools available to the Critic agent"""

    def __init__(self):
        self.tools = {
            "validate_solution": self.validate_solution,
            "check_safety": self.check_safety,
            "detect_hallucinations": self.detect_hallucinations,
        }

    async def validate_solution(self, solution: Dict, original_logs: str) -> Dict:
        """Run full validation on a solution"""
        from agents.critic.evaluator import SolutionEvaluator
        evaluator = SolutionEvaluator()

        results = {
            "factual": await evaluator.check_factual_consistency(solution, original_logs),
            "logical": await evaluator.check_logical_coherence(solution),
            "completeness": await evaluator.check_completeness(solution),
            "hallucination": await evaluator.detect_hallucinations(solution, original_logs)
        }

        all_passed = all(r.get("passed", False) for r in results.values())
        confidence_scores = [r.get("confidence", 0.5) for r in results.values()]
        overall = sum(confidence_scores) / len(confidence_scores) if confidence_scores else 0.5

        return {
            "passed": all_passed,
            "overall_confidence": round(overall, 2),
            "checks": results
        }

    async def check_safety(self, solution: Dict) -> Dict:
        """Check solution for safety issues"""
        from agents.critic.safety_checker import SafetyChecker
        checker = SafetyChecker()
        return await checker.audit(solution)

    async def detect_hallucinations(self, solution: Dict, original_logs: str) -> Dict:
        """Detect potential hallucinations"""
        from agents.critic.evaluator import SolutionEvaluator
        evaluator = SolutionEvaluator()
        return await evaluator.detect_hallucinations(solution, original_logs)

    def get_tool(self, tool_name: str):
        """Get a tool by name"""
        return self.tools.get(tool_name)
    