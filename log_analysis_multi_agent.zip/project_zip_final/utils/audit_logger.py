"""
Audit Logger — Session-based structured JSON logging for the multi-agent system.

Groups all events by query session, tracks token usage per agent,
and writes human-readable JSON files daily.

Usage:
    from utils.audit_logger import AuditLogger

    logger = AuditLogger("memory_store/audit")
    logger.start_session(query_id, query_text, input_type, ...)
    logger.log_agent_call(query_id, agent, action, input_tokens, output_tokens, ...)
    logger.end_session(query_id, status, total_tokens, ...)
"""

import os
import json
import uuid
import threading
from datetime import datetime
from typing import Dict, Any, Optional


class AuditLogger:
    """
    Session-based JSON audit logger with daily file rotation.

    Features:
    - Sessions grouped by query_id — one session object per user query
    - Token tracking per agent call
    - Human-readable formatted JSON
    - Thread-safe with lock
    """

    def __init__(self, audit_dir: str = "memory_store/audit"):
        self.audit_dir = os.path.abspath(audit_dir)
        self._lock = threading.Lock()
        self._current_date: Optional[str] = None
        self._file_path: Optional[str] = None
        self._sessions: Dict[str, Dict] = {}  # In-memory session cache

        os.makedirs(self.audit_dir, exist_ok=True)

    # ------------------------------------------------------------------
    # Session Lifecycle
    # ------------------------------------------------------------------

    def start_session(
            self,
            query_id: str,
            query_text: str,
            input_type: str,
            input_format: str = "unknown",
            chars: int = 0,
            lines: int = 0,
    ):
        """Start a new query session."""
        session = {
            "query_id": query_id,
            "query_text": query_text[:200],
            "input_type": input_type,
            "input_format": input_format,
            "chars": chars,
            "lines": lines,
            "start_time": datetime.utcnow().isoformat() + "Z",
            "end_time": None,
            "duration_ms": None,
            "status": "running",
            "final_confidence": None,
            "total_tokens_burned": 0,
            "pipeline_stages": {},
            "messages": [],
            "agent_calls": [],
            "errors": [],
            "skills_used": [],
        }
        with self._lock:
            self._sessions[query_id] = session
        self._flush_if_needed()

    def end_session(
            self,
            query_id: str,
            status: str = "completed",
            final_confidence: Optional[float] = None,
            error: Optional[str] = None,
    ):
        """Mark a session as complete and calculate totals."""
        with self._lock:
            session = self._sessions.get(query_id)
            if not session:
                return
            session["end_time"] = datetime.utcnow().isoformat() + "Z"
            if session["start_time"]:
                start = datetime.fromisoformat(session["start_time"].replace("Z", ""))
                end = datetime.utcnow()
                session["duration_ms"] = round((end - start).total_seconds() * 1000, 2)
            session["status"] = status
            session["final_confidence"] = final_confidence
            if error:
                session["errors"].append({
                    "timestamp": datetime.utcnow().isoformat() + "Z",
                    "error": error
                })

            # Calculate total tokens
            total_tokens = sum(c.get("input_tokens", 0) + c.get("output_tokens", 0)
                             for c in session["agent_calls"])
            session["total_tokens_burned"] = total_tokens

        self._flush_if_needed()

    # ------------------------------------------------------------------
    # Pipeline Stages
    # ------------------------------------------------------------------

    def log_pipeline_stage(
            self,
            query_id: str,
            stage: str,
            status: str,
            agent_type: str,
            confidence: float,
            duration_ms: Optional[float] = None,
            input_tokens: int = 0,
            output_tokens: int = 0,
            skill_used: Optional[str] = None,
            error: Optional[str] = None,
            request_summary: Optional[Dict] = None,
            response_summary: Optional[Dict] = None,
            **kwargs):  # Accept old parameter names for backward compatibility
        """Log a pipeline stage with token counts."""
        with self._lock:
            session = self._sessions.get(query_id)
            if not session:
                return

            stage_data = {
                "status": status,
                "agent": agent_type,
                "confidence": confidence,
                "duration_ms": duration_ms,
                "tokens": {
                    "input": input_tokens,
                    "output": output_tokens,
                    "total": input_tokens + output_tokens,
                },
                "skill_used": skill_used,
                "error": error,
                "request": request_summary,
                "response": response_summary,
            }
            session["pipeline_stages"][stage] = stage_data

            if skill_used and skill_used not in session["skills_used"]:
                session["skills_used"].append(skill_used)

        self._flush_if_needed()

    # ------------------------------------------------------------------
    # Agent Calls (with token tracking)
    # ------------------------------------------------------------------

    def log_agent_call(
            self,
            query_id: str,
            agent_type: str,
            action: str,
            direction: str,  # "request" or "response"
            input_tokens: int = 0,
            output_tokens: int = 0,
            model: Optional[str] = None,
            skill_used: Optional[str] = None,
            confidence: Optional[float] = None,
            duration_ms: Optional[float] = None,
            error: Optional[str] = None,
            metadata: Optional[Dict] = None,
    ):
        """Log an individual agent LLM call with token counts."""
        with self._lock:
            session = self._sessions.get(query_id)
            if not session:
                return

            call_data = {
                "timestamp": datetime.utcnow().isoformat() + "Z",
                "agent": agent_type,
                "action": action,
                "direction": direction,
                "model": model,
                "tokens": {
                    "input": input_tokens,
                    "output": output_tokens,
                    "total": input_tokens + output_tokens,
                },
                "skill_used": skill_used,
                "confidence": confidence,
                "duration_ms": duration_ms,
                "error": error,
                "metadata": metadata or {},
            }
            session["agent_calls"].append(call_data)

            if skill_used and skill_used not in session["skills_used"]:
                session["skills_used"].append(skill_used)

        self._flush_if_needed()

    # ------------------------------------------------------------------
    # Messages (inter-agent communication)
    # ------------------------------------------------------------------

    def log_message(
            self,
            query_id: str,
            direction: str,
            from_agent: str,
            to_agent: str,
            message_type: str,
            action: Optional[str] = None,
            confidence: Optional[float] = None,
            message_size: int = 0,
            correlation_id: Optional[str] = None,
            error: Optional[str] = None,
    ):
        """Log an inter-agent message."""
        with self._lock:
            session = self._sessions.get(query_id)
            if not session:
                return

            msg_data = {
                "timestamp": datetime.utcnow().isoformat() + "Z",
                "direction": direction,
                "from": from_agent,
                "to": to_agent,
                "type": message_type,
                "action": action,
                "confidence": confidence,
                "size_bytes": message_size,
                "correlation_id": correlation_id,
                "error": error,
            }
            session["messages"].append(msg_data)

        self._flush_if_needed()

    # ------------------------------------------------------------------
    # Errors
    # ------------------------------------------------------------------

    def log_error(
            self,
            query_id: str,
            error_type: str,
            error_message: str,
            agent_type: Optional[str] = None,
    ):
        """Log an error event."""
        with self._lock:
            session = self._sessions.get(query_id)
            if not session:
                return

            session["errors"].append({
                "timestamp": datetime.utcnow().isoformat() + "Z",
                "type": error_type,
                "message": error_message,
                "agent": agent_type,
            })

        self._flush_if_needed()

    # ------------------------------------------------------------------
    # Token Summary (per-agent limits and usage)
    # ------------------------------------------------------------------

    def log_token_summary(self, query_id: str):
        """Log a summary of token usage per agent for the session."""
        with self._lock:
            session = self._sessions.get(query_id)
            if not session:
                return

            agent_tokens = {}
            for call in session["agent_calls"]:
                agent = call["agent"]
                if agent not in agent_tokens:
                    agent_tokens[agent] = {"input": 0, "output": 0, "calls": 0}
                agent_tokens[agent]["input"] += call["tokens"]["input"]
                agent_tokens[agent]["output"] += call["tokens"]["output"]
                agent_tokens[agent]["calls"] += 1

            session["token_summary"] = {
                "per_agent": agent_tokens,
                "total_tokens_burned": session["total_tokens_burned"],
                "agent_limits": {
                    "analyzer": {"max_input": 4096, "max_output": 1024},
                    "critic": {"max_input": 4096, "max_output": 1024},
                    "debugger": {"max_input": 8192, "max_output": 2048},
                    "extractor": {"max_input": 4096, "max_output": 512},
                    "memory": {"max_input": 4096, "max_output": 1024},
                    "orchestrator": {"max_input": 8192, "max_output": 8192},
                    "preprocessor": {"max_input": 4096, "max_output": 512},
                    "solver": {"max_input": 8192, "max_output": 4096},
                }
            }

        self._flush_if_needed()

    def log_event(self, event: Dict[str, Any]):
        """Route a flat event into the session structure (backward compatibility)."""
        event_type = event.get("event_type", "")
        agent_type = event.get("agent_type", event.get("agent", "unknown"))

        # Try to find query_id from event or pipeline_context
        query_id = event.get("query_id")
        if not query_id:
            pc = event.get("pipeline_context", {})
            query_id = pc.get("query_id") if isinstance(pc, dict) else None

        if not query_id:
            # No query_id — attach to the most recent active session
            if self._sessions:
                query_id = list(self._sessions.keys())[-1]
            else:
                return

        if event_type.startswith("agent_"):
            # Agent processing events
            details = {k: v for k, v in event.items() if
                       k not in ("event_type", "event_id", "timestamp", "agent_id", "agent_type")}
            self.log_agent_call(
                query_id=query_id,
                agent_type=agent_type,
                action=details.get("action", "unknown"),
                direction="response",
                input_tokens=details.get("input_tokens", 0),
                output_tokens=details.get("output_tokens", 0),
                skill_used=details.get("skill_used"),
                confidence=details.get("confidence"),
                duration_ms=details.get("duration_ms"),
                error=details.get("error"),
                metadata=details,
            )
        elif event_type.startswith("message_"):
            # Message events
            sender = event.get("sender", {})
            receiver = event.get("receiver", {})
            msg = event.get("message", {})
            self.log_message(
                query_id=query_id,
                direction="REQUEST" if "request" in event_type else "RESPONSE",
                from_agent=sender.get("agent_type", "unknown"),
                to_agent=receiver.get("agent_type", "unknown"),
                message_type=msg.get("message_type", event_type),
                action=msg.get("task_action"),
                confidence=msg.get("confidence"),
                message_size=len(str(msg)),
                correlation_id=msg.get("correlation_id"),
                error=msg.get("error"),
            )
        elif "pipeline_stage" in event_type:
            # Pipeline stage events
            self.log_pipeline_stage(
                query_id=query_id,
                stage=event.get("pipeline_stage", event.get("stage", "unknown")),
                status=event.get("status", "completed"),
                agent_type=agent_type,
                confidence=event.get("confidence", 0.0),
                duration_ms=event.get("duration_ms"),
                skill_used=event.get("skill_used"),
                error=event.get("error"),
                request_summary=event.get("request"),
                response_summary=event.get("response"),
            )
        elif event_type == "system_error" or event_type.startswith("error"):
            error_info = event.get("error", {})
            self.log_error(
                query_id=query_id,
                error_type=error_info.get("type", event_type) if isinstance(error_info, dict) else event_type,
                error_message=error_info.get("message", str(error_info)) if isinstance(error_info, dict) else str(
                    error_info),
                agent_type=agent_type,
            )

    # ------------------------------------------------------------------
    # Internal — Flush to Disk
    # ------------------------------------------------------------------

    def _flush_if_needed(self):
        """Write all sessions to the daily file, merging with existing data."""
        today = datetime.utcnow().strftime("%Y-%m-%d")
        if today != self._current_date:
            self._current_date = today
            self._file_path = os.path.join(self.audit_dir, f"pipeline_{today}.json")
            # Load existing sessions from file when date changes
            self._load_existing()

        # Merge in-memory sessions with existing file data, then write
        try:
            # Read existing file first
            existing = {}
            if os.path.exists(self._file_path):
                try:
                    with open(self._file_path, "r", encoding="utf-8") as f:
                        data = json.load(f)
                        existing = data.get("sessions", {})
                except Exception:
                    pass

            # Merge: in-memory sessions overwrite existing
            merged = {**existing, **self._sessions}

            with open(self._file_path, "w", encoding="utf-8") as f:
                output = {
                    "audit_date": today,
                    "format": "query_sessions",
                    "generated_at": datetime.utcnow().isoformat() + "Z",
                    "total_sessions": len(merged),
                    "sessions": merged,
                }
                json.dump(output, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"[AUDIT] Failed to flush: {e}")

    def _load_existing(self):
        """Load existing sessions from today's file on startup."""
        if os.path.exists(self._file_path):
            try:
                with open(self._file_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    existing = data.get("sessions", {})
                    self._sessions.update(existing)
            except Exception:
                pass


# ═══════════════════════════════════════════════════════════════
# Singleton
# ═══════════════════════════════════════════════════════════════

_audit_logger: Optional[AuditLogger] = None


def get_audit_logger(audit_dir: str = "memory_store/audit") -> AuditLogger:
    """Get or create the global audit logger instance."""
    global _audit_logger
    if _audit_logger is None:
        _audit_logger = AuditLogger(audit_dir)
    return _audit_logger



