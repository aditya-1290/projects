"""
Validators - Input validation utilities
"""

import re
from typing import Tuple, Optional


def validate_file_path(path: str) -> Tuple[bool, Optional[str]]:
    """Validate a file path"""
    if not path:
        return False, "Path is empty"

    if len(path) > 500:
        return False, "Path too long (max 500 characters)"

    # Check for dangerous patterns
    dangerous = ['..', '~', '|', ';', '&', '$', '`']
    for char in dangerous:
        if char in path:
            return False, f"Path contains dangerous character: {char}"

    return True, None


def validate_log_content(content: str) -> Tuple[bool, Optional[str]]:
    """Validate log content"""
    if not content:
        return False, "Content is empty"

    if len(content) > 50000:
        return False, "Content too large (max 50000 characters)"

    # Check for null bytes
    if '\x00' in content:
        return False, "Content contains null bytes"

    return True, None


def validate_agent_id(agent_id: str) -> bool:
    """Validate agent ID format"""
    pattern = re.compile(r'^[a-z]+_v\d+$')
    return bool(pattern.match(agent_id))


def validate_confidence(confidence: float) -> bool:
    """Validate confidence score"""
    return 0.0 <= confidence <= 1.0
