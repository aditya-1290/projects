"""
OpenTelemetry Tracing for Multi-Agent System.

Provides:
- Trace spans for every agent call
- Timing for every pipeline stage
- Bus message tracing
- Export to console (dev) or OTLP (production)

Usage:
    from utils.tracing import get_tracer, trace_agent_call, trace_bus_message

    # Decorate agent methods
    @trace_agent_call("solver")
    async def process(self, message):
        ...

    # Or use context manager
    with get_tracer().start_as_current_span("pipeline_stage"):
        ...
"""

import os
import time
import functools
from typing import Optional, Dict, Any
from contextlib import contextmanager

# Try to import OpenTelemetry — graceful degradation if not installed
try:
    from opentelemetry import trace
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import BatchSpanProcessor, ConsoleSpanExporter
    from opentelemetry.sdk.resources import SERVICE_NAME, Resource
    from opentelemetry.trace import Status, StatusCode

    _OTEL_AVAILABLE = True
except ImportError:
    _OTEL_AVAILABLE = False

# ═══════════════════════════════════════════════════════════
# Tracer setup
# ═══════════════════════════════════════════════════════════

_tracer = None


def setup_tracing(service_name: str = "log-analysis-multi-agent", export_console: bool = True):
    """Initialize OpenTelemetry tracing. Call once at startup."""
    global _tracer

    if not _OTEL_AVAILABLE:
        print("[TRACING] OpenTelemetry not installed — tracing disabled")
        return None

    resource = Resource(attributes={SERVICE_NAME: service_name})
    provider = TracerProvider(resource=resource)

    if export_console:
        # Console exporter for development
        exporter = ConsoleSpanExporter()
        provider.add_span_processor(BatchSpanProcessor(exporter))

    # Can add OTLP exporter for production:
    # from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
    # provider.add_span_processor(BatchSpanProcessor(OTLPSpanExporter()))

    trace.set_tracer_provider(provider)
    _tracer = trace.get_tracer(service_name)

    print(f"[TRACING] Initialized for {service_name}")
    return _tracer


def get_tracer():
    """Get the global tracer. Returns a no-op if tracing is disabled."""
    global _tracer

    if _tracer is not None:
        return _tracer

    if _OTEL_AVAILABLE:
        _tracer = trace.get_tracer("log-analysis-multi-agent")
        return _tracer

    # Return a no-op tracer
    return _NoOpTracer()


class _NoOpTracer:
    """No-op tracer when OpenTelemetry is not installed."""

    def start_as_current_span(self, name, attributes=None):
        return _NoOpSpan()

    def start_span(self, name, attributes=None):
        return _NoOpSpan()


class _NoOpSpan:
    """No-op span."""

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        pass

    def set_attribute(self, key, value):
        pass

    def set_status(self, status):
        pass

    def add_event(self, name, attributes=None):
        pass

    def end(self):
        pass


# ═══════════════════════════════════════════════════════════
# Decorators and helpers
# ═══════════════════════════════════════════════════════════

def trace_agent_call(agent_type: str):
    """Decorator to trace an agent's process method."""

    def decorator(func):
        @functools.wraps(func)
        async def wrapper(self, message, *args, **kwargs):
            tracer = get_tracer()
            task_action = message.task.get("action", "unknown") if message.task else "unknown"

            with tracer.start_as_current_span(
                    f"agent.{agent_type}.{task_action}",
                    attributes={
                        "agent.type": agent_type,
                        "agent.id": self.agent_id,
                        "task.action": task_action,
                        "message.type": message.message_type.value,
                    }
            ) as span:
                start_time = time.time()
                try:
                    result = await func(self, message, *args, **kwargs)
                    duration_ms = (time.time() - start_time) * 1000
                    span.set_attribute("duration_ms", duration_ms)
                    span.set_attribute("confidence", getattr(result, 'confidence', 0))
                    span.set_status(Status(StatusCode.OK))
                    return result
                except Exception as e:
                    span.set_status(Status(StatusCode.ERROR, str(e)))
                    span.record_exception(e)
                    raise

        return wrapper

    return decorator


def trace_bus_message(message_type: str):
    """Decorator to trace bus message sending."""

    def decorator(func):
        @functools.wraps(func)
        async def wrapper(self, message, *args, **kwargs):
            tracer = get_tracer()

            with tracer.start_as_current_span(
                    f"bus.{message_type}",
                    attributes={
                        "message.type": message.message_type.value if hasattr(message,
                                                                              'message_type') else message_type,
                        "sender": getattr(message, 'sender_type', 'unknown'),
                        "target": getattr(message, 'target_type', 'broadcast'),
                    }
            ):
                return await func(self, message, *args, **kwargs)

        return wrapper

    return decorator


def trace_pipeline_stage(stage: str, stage_number: str = ""):
    """Context manager for tracing a pipeline stage."""
    tracer = get_tracer()
    span_name = f"pipeline.{stage}"
    if stage_number:
        span_name += f" ({stage_number})"

    return tracer.start_as_current_span(span_name, attributes={
        "pipeline.stage": stage,
        "pipeline.stage_number": stage_number,
    })


# ═══════════════════════════════════════════════════════════
# Manual tracing helpers
# ═══════════════════════════════════════════════════════════

class TraceContext:
    """Context manager for manual tracing in non-decorator code."""

    def __init__(self, name: str, attributes: Dict[str, Any] = None):
        self.name = name
        self.attributes = attributes or {}
        self.span = None
        self.start_time = None

    def __enter__(self):
        tracer = get_tracer()
        self.span = tracer.start_span(self.name, attributes=self.attributes)
        self.start_time = time.time()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.span:
            duration_ms = (time.time() - self.start_time) * 1000
            self.span.set_attribute("duration_ms", duration_ms)
            if exc_type:
                self.span.set_status(Status(StatusCode.ERROR, str(exc_val)))
            else:
                self.span.set_status(Status(StatusCode.OK))
            self.span.end()

    async def __aenter__(self):
        return self.__enter__()

    async def __aexit__(self, *args):
        self.__exit__(*args)

    def set_attribute(self, key, value):
        if self.span:
            self.span.set_attribute(key, value)

    def add_event(self, name, attributes=None):
        if self.span:
            self.span.add_event(name, attributes)


def trace_query(query_id: str, query_preview: str):
    """Start a trace for a user query."""
    return TraceContext(
        "user_query",
        attributes={
            "query.id": query_id,
            "query.preview": query_preview[:100],
        }
    )


def trace_llm_call(model_name: str, prompt_length: int):
    """Start a trace for an LLM call."""
    return TraceContext(
        f"llm.{model_name}",
        attributes={
            "llm.model": model_name,
            "llm.prompt_length": prompt_length,
        }
    )
