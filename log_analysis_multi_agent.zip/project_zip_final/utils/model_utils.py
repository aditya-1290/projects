"""
Model Utilities - Helper functions for model management
"""

import os
from typing import Optional


def check_model_exists(model_path: str) -> bool:
    """Check if a model file exists"""
    return os.path.exists(model_path)


def get_model_size_gb(model_path: str) -> Optional[float]:
    """Get model file size in GB"""
    if not os.path.exists(model_path):
        return None

    size_bytes = os.path.getsize(model_path)
    return round(size_bytes / (1024 ** 3), 2)


def format_model_name(name: str) -> str:
    """Format model name for display"""
    return name.replace('-', ' ').replace('_', ' ').title()


def estimate_inference_time(
        prompt_length: int,
        max_tokens: int,
        model_type: str = "llm"
) -> float:
    """
    Estimate inference time in seconds.
    Very rough estimate for CPU inference.
    """
    # Rough estimate: 5-10 tokens per second on CPU
    tokens_per_second = 5 if model_type == "llm" else 3

    total_tokens = (prompt_length // 4) + max_tokens
    estimated_seconds = total_tokens / tokens_per_second

    return round(estimated_seconds, 1)
