"""
Confidence Scoring Utilities
"""

from typing import Dict, List, Any, Optional


class ConfidenceCalculator:
    """Calculates and manages confidence scores"""

    # Base confidence by agent type
    BASE_CONFIDENCE = {
        "extractor": 0.9,
        "preprocessor": 0.85,
        "analyzer": 0.8,
        "solver": 0.7,
        "debugger": 0.75,
        "critic": 0.8,
        "memory": 0.7,
        "orchestrator": 0.85
    }

    @staticmethod
    def calculate_agent_confidence(
            agent_type: str,
            task_complexity: str = "normal",
            evidence_count: int = 0,
            match_quality: float = 1.0
    ) -> float:
        """
        Calculate confidence for an agent's output.

        Factors:
        - Base confidence for agent type
        - Task complexity (simple/normal/complex)
        - Amount of evidence found
        - Match quality with known patterns
        """
        base = ConfidenceCalculator.BASE_CONFIDENCE.get(agent_type, 0.5)

        # Adjust for complexity
        complexity_factor = {
            "simple": 1.0,
            "normal": 0.9,
            "complex": 0.7
        }.get(task_complexity, 0.9)

        # Adjust for evidence
        evidence_factor = min(1.0, 0.5 + (evidence_count * 0.1))

        # Match quality
        match_factor = match_quality

        # Weighted calculation
        confidence = base * (
                0.4 * complexity_factor +
                0.3 * evidence_factor +
                0.3 * match_factor
        )

        return round(min(confidence, 1.0), 2)

    @staticmethod
    def calculate_pipeline_confidence(
            stage_confidences: List[float],
            weights: List[float] = None
    ) -> float:
        """
        Calculate overall pipeline confidence.

        Args:
            stage_confidences: Confidence scores for each stage
            weights: Optional importance weights (default: equal)
        """
        if not stage_confidences:
            return 0.0

        if weights is None:
            weights = [1.0 / len(stage_confidences)] * len(stage_confidences)

        # Weighted average
        total_weight = sum(weights)
        weighted_sum = sum(
            conf * weight
            for conf, weight in zip(stage_confidences, weights)
        )

        return round(weighted_sum / total_weight, 2)

    @staticmethod
    def get_confidence_level(score: float) -> Dict[str, str]:
        """Get human-readable confidence level"""
        if score >= 0.9:
            return {"level": "HIGH", "emoji": "🟢", "description": "Very confident"}
        elif score >= 0.7:
            return {"level": "MEDIUM", "emoji": "🟡", "description": "Moderately confident"}
        elif score >= 0.5:
            return {"level": "LOW", "emoji": "🟠", "description": "Somewhat uncertain"}
        else:
            return {"level": "VERY_LOW", "emoji": "🔴", "description": "Highly uncertain"}

    @staticmethod
    def should_retry(confidence: float, max_retries: int, current_retry: int) -> bool:
        """Determine if a retry is warranted"""
        if current_retry >= max_retries:
            return False

        if confidence < 0.3:
            return True

        if confidence < 0.5 and current_retry < max_retries - 1:
            return True

        return False