"""
Chunking Utilities - Smart text chunking strategies
"""

import re
from typing import List, Dict, Optional


class TextChunker:
    """
    Smart text chunking with various strategies.

    Strategies:
    - fixed_size: Split at exact character counts
    - sentence: Split at sentence boundaries
    - paragraph: Split at paragraph boundaries
    - semantic: Try to split at logical boundaries
    """

    # Common log entry start patterns
    LOG_ENTRY_PATTERNS = [
        re.compile(r'^\d{4}-\d{2}-\d{2}'),  # ISO timestamp
        re.compile(r'^\d{2}/\d{2}/\d{4}'),  # US date
        re.compile(r'^\w{3}\s+\d+\s+\d{2}:\d{2}'),  # Syslog timestamp
        re.compile(r'^\[\d{4}-\d{2}-\d{2}'),  # Bracketed timestamp
        re.compile(r'^ERROR|^WARN|^INFO|^DEBUG|^FATAL', re.IGNORECASE),
        re.compile(r'^Traceback|^Exception|^Caused by'),
    ]

    def __init__(
            self,
            chunk_size: int = 4000,
            overlap: int = 200,
            strategy: str = "semantic"
    ):
        self.chunk_size = chunk_size
        self.overlap = overlap
        self.strategy = strategy

    def chunk(self, text: str) -> List[Dict]:
        """
        Split text into chunks.

        Returns:
            List of dicts with 'content', 'index', 'is_first', 'is_last'
        """
        if len(text) <= self.chunk_size:
            return [{
                "content": text,
                "index": 0,
                "is_first": True,
                "is_last": True,
                "length": len(text)
            }]

        if self.strategy == "fixed_size":
            chunks = self._fixed_size_chunk(text)
        elif self.strategy == "sentence":
            chunks = self._sentence_chunk(text)
        elif self.strategy == "paragraph":
            chunks = self._paragraph_chunk(text)
        else:
            chunks = self._semantic_chunk(text)

        # Add overlap
        if self.overlap > 0 and len(chunks) > 1:
            chunks = self._add_overlap(chunks)

        # Format result
        result = []
        for i, chunk in enumerate(chunks):
            result.append({
                "content": chunk,
                "index": i,
                "is_first": i == 0,
                "is_last": i == len(chunks) - 1,
                "length": len(chunk)
            })

        return result

    def _fixed_size_chunk(self, text: str) -> List[str]:
        """Split at exact character boundaries"""
        chunks = []
        for i in range(0, len(text), self.chunk_size):
            chunks.append(text[i:i + self.chunk_size])
        return chunks

    def _sentence_chunk(self, text: str) -> List[str]:
        """Split at sentence boundaries near chunk size"""
        sentences = re.split(r'(?<=[.!?])\s+', text)

        chunks = []
        current_chunk = ""

        for sentence in sentences:
            if len(current_chunk) + len(sentence) > self.chunk_size and current_chunk:
                chunks.append(current_chunk.strip())
                current_chunk = sentence
            else:
                current_chunk += " " + sentence if current_chunk else sentence

        if current_chunk:
            chunks.append(current_chunk.strip())

        return chunks

    def _paragraph_chunk(self, text: str) -> List[str]:
        """Split at paragraph boundaries"""
        paragraphs = text.split('\n\n')

        chunks = []
        current_chunk = ""

        for paragraph in paragraphs:
            if len(current_chunk) + len(paragraph) > self.chunk_size and current_chunk:
                chunks.append(current_chunk.strip())
                current_chunk = paragraph
            else:
                current_chunk += "\n\n" + paragraph if current_chunk else paragraph

        if current_chunk:
            chunks.append(current_chunk.strip())

        return chunks

    def _semantic_chunk(self, text: str) -> List[str]:
        """Split at log entry boundaries"""
        lines = text.split('\n')

        chunks = []
        current_chunk = []
        current_size = 0

        for line in lines:
            line_size = len(line) + 1

            # Check if this line starts a new log entry
            is_new_entry = any(pattern.match(line.strip()) for pattern in self.LOG_ENTRY_PATTERNS)

            # Split if chunk would exceed size AND we're at a new entry
            if current_size + line_size > self.chunk_size and is_new_entry and current_chunk:
                chunks.append('\n'.join(current_chunk))
                current_chunk = [line]
                current_size = line_size
            else:
                current_chunk.append(line)
                current_size += line_size

        if current_chunk:
            chunks.append('\n'.join(current_chunk))

        return chunks

    def _add_overlap(self, chunks: List[str]) -> List[str]:
        """Add overlapping content between chunks"""
        overlapped = []

        for i, chunk in enumerate(chunks):
            if i > 0:
                # Add content from end of previous chunk
                prev_chunk = chunks[i - 1]
                overlap_text = prev_chunk[-self.overlap:]
                chunk = overlap_text + "\n...\n" + chunk

            if i < len(chunks) - 1:
                # Add content from start of next chunk
                next_chunk = chunks[i + 1]
                overlap_text = next_chunk[:self.overlap]
                chunk = chunk + "\n...\n" + overlap_text

            overlapped.append(chunk)

        return overlapped


def chunk_text(
        text: str,
        chunk_size: int = 4000,
        overlap: int = 200,
        strategy: str = "semantic"
) -> List[Dict]:
    """
    Convenience function for chunking text.

    Args:
        text: Text to chunk
        chunk_size: Maximum chunk size in characters
        overlap: Overlap between chunks in characters
        strategy: Chunking strategy (fixed_size, sentence, paragraph, semantic)

    Returns:
        List of chunk dicts
    """
    chunker = TextChunker(
        chunk_size=chunk_size,
        overlap=overlap,
        strategy=strategy
    )
    return chunker.chunk(text)


def estimate_chunks(text: str, chunk_size: int = 4000) -> int:
    """Estimate number of chunks needed"""
    if not text:
        return 0
    return (len(text) + chunk_size - 1) // chunk_size
