"""
Response Formatter - Formats agent outputs for CLI display
"""

from typing import Dict, Any, List
from datetime import datetime


class ResponseFormatter:
    """Formats responses for clean CLI output"""

    @staticmethod
    def format_analysis_result(results: Dict) -> str:
        """Format a complete analysis result"""
        parts = []

        # Header
        parts.append("=" * 60)
        parts.append("📊 LOG ANALYSIS RESULTS")
        parts.append("=" * 60)

        # Root cause
        root_cause = results.get("root_cause", {})
        if root_cause:
            parts.append(f"\n🔍 ROOT CAUSE: {root_cause.get('primary_cause', 'N/A')}")
            parts.append(f"   Severity: {root_cause.get('severity', 'N/A')}")
            parts.append(f"   Confidence: {int(root_cause.get('confidence', 0) * 100)}%")

        # Fix suggestion
        fix = results.get("fix_suggestion", {})
        if fix:
            parts.append("\n🔧 RECOMMENDED FIX:")

            immediate = fix.get("immediate_actions", [])
            if immediate:
                parts.append("\n⚡ Immediate Actions:")
                for i, action in enumerate(immediate[:5], 1):
                    parts.append(f"   {i}. {action}")

            commands = fix.get("commands_to_run", [])
            if commands:
                parts.append("\n💻 Commands:")
                for cmd in commands[:5]:
                    parts.append(f"   $ {cmd}")

            prevention = fix.get("prevention_measures", [])
            if prevention:
                parts.append("\n🛡️ Prevention:")
                for measure in prevention[:3]:
                    parts.append(f"   • {measure}")

        # Explanation
        explanation = results.get("explanation", "")
        if explanation:
            parts.append(f"\n📝 DETAILED EXPLANATION:")
            parts.append(explanation[:1000])

        # Validation
        if results.get("validation_passed") is not None:
            status = "✅ PASSED" if results["validation_passed"] else "⚠️ NEEDS REVIEW"
            parts.append(f"\n🔍 Validation: {status}")

        # Caveats
        caveats = results.get("caveats", [])
        if caveats:
            parts.append("\n⚠️ CAVEATS:")
            for caveat in caveats:
                parts.append(f"   • {caveat}")

        parts.append("\n" + "=" * 60)

        return '\n'.join(parts)

    @staticmethod
    def format_error(error: str) -> str:
        """Format an error message"""
        return f"""
❌ ERROR
{'─' * 40}
{error}
{'─' * 40}
"""

    @staticmethod
    def format_capability_summary(capabilities: Dict) -> str:
        """Format agent capabilities"""
        parts = ["🤖 AGENT CAPABILITIES", "=" * 40]

        for agent_name, info in capabilities.items():
            parts.append(f"\n📦 {agent_name}")
            parts.append(f"   Can: {', '.join(info.get('can', []))}")
            parts.append(f"   Cannot: {', '.join(info.get('cannot', []))}")

        return '\n'.join(parts)

    @staticmethod
    def format_progress(stage: str, status: str = "running") -> str:
        """Format a progress update"""
        emojis = {
            "running": "⏳",
            "completed": "✅",
            "failed": "❌",
            "skipped": "⏭️"
        }
        emoji = emojis.get(status, "ℹ️")

        return f"{emoji} [{status.upper()}] {stage}"

    @staticmethod
    def format_timestamp() -> str:
        """Get formatted timestamp"""
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")