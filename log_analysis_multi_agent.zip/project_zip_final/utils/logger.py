"""
Logger - Configured logging for the entire system
"""

import logging
import sys
from pathlib import Path
from datetime import datetime


def setup_logger(name: str = "log_analysis_system") -> logging.Logger:
    """
    Set up a configured logger.

    Args:
        name: Logger name

    Returns:
        Configured logger instance
    """
    logger = logging.getLogger(name)

    # Don't add handlers if already configured
    if logger.handlers:
        return logger

    logger.setLevel(logging.DEBUG)

    # Console handler (INFO and above)
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO)
    console_format = logging.Formatter(
        '%(asctime)s [%(levelname)s] %(message)s',
        datefmt='%H:%M:%S'
    )
    console_handler.setFormatter(console_format)
    logger.addHandler(console_handler)

    # File handler (DEBUG and above)
    try:
        from config import LOGS_DIR, LOG_FILE
        log_path = Path(LOG_FILE)
        log_path.parent.mkdir(parents=True, exist_ok=True)

        file_handler = logging.FileHandler(LOG_FILE)
        file_handler.setLevel(logging.DEBUG)
        file_format = logging.Formatter(
            '%(asctime)s [%(levelname)s] [%(name)s] %(message)s'
        )
        file_handler.setFormatter(file_format)
        logger.addHandler(file_handler)
    except Exception:
        pass  # File logging is optional

    return logger


class AgentLogger:
    """Logger wrapper for agents"""

    def __init__(self, agent_name: str, agent_id: str):
        self.agent_name = agent_name
        self.agent_id = agent_id
        self.logger = setup_logger(f"agent.{agent_name}")

    def info(self, message: str):
        """Log info message"""
        self.logger.info(f"[{self.agent_name}] {message}")

    def debug(self, message: str):
        """Log debug message"""
        self.logger.debug(f"[{self.agent_name}] {message}")

    def warning(self, message: str):
        """Log warning message"""
        self.logger.warning(f"[{self.agent_name}] {message}")

    def error(self, message: str):
        """Log error message"""
        self.logger.error(f"[{self.agent_name}] {message}")