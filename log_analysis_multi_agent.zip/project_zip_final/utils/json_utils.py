"""
JSON Utilities - Safe JSON parsing and extraction
"""

import json
import re
from typing import Dict, Any, Optional


def safe_json_parse(text: str) -> Optional[Dict[str, Any]]:
    """Safely parse JSON from text, handling common issues"""
    if not text:
        return None

    # Try direct parse
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # Try to extract JSON from text
    json_match = re.search(r'\{.*\}', text, re.DOTALL)
    if json_match:
        try:
            return json.loads(json_match.group())
        except json.JSONDecodeError:
            pass

    # Try to extract from markdown code blocks
    code_block = re.search(r'```(?:json)?\s*\n(.*?)\n```', text, re.DOTALL)
    if code_block:
        try:
            return json.loads(code_block.group(1))
        except json.JSONDecodeError:
            pass

    return None


def extract_json_from_llm_response(response: str) -> Optional[Dict]:
    """Extract JSON from an LLM response"""
    return safe_json_parse(response)


def dict_to_json(obj: Dict, indent: int = 2) -> str:
    """Convert dict to pretty JSON string"""
    return json.dumps(obj, indent=indent, ensure_ascii=False)


def flatten_dict(d: Dict, parent_key: str = '', sep: str = '.') -> Dict:
    """Flatten a nested dictionary"""
    items = []
    for k, v in d.items():
        new_key = f"{parent_key}{sep}{k}" if parent_key else k
        if isinstance(v, dict):
            items.extend(flatten_dict(v, new_key, sep=sep).items())
        elif isinstance(v, list):
            items.append((new_key, json.dumps(v)))
        else:
            items.append((new_key, v))
    return dict(items)
