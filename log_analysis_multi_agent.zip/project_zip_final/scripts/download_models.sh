#!/bin/bash
# ============================================
# Download Models Script
# Downloads all required models for the system
# ============================================

set -e

MODELS_DIR="../models"
LLM_DIR="${MODELS_DIR}/llm"
OCR_DIR="${MODELS_DIR}/ocr"
EMBEDDINGS_DIR="${MODELS_DIR}/embeddings"

echo "========================================"
echo "DOWNLOADING MODELS"
echo "========================================"

# Create directories
mkdir -p "${LLM_DIR}" "${OCR_DIR}" "${EMBEDDINGS_DIR}"

# Gemma-4-E4B-IT (GGUF Q4_K_M)
echo ""
echo "[1/4] Downloading Gemma-4-E4B-IT..."
echo "  This is ~3GB. Please wait..."
if [ ! -f "${LLM_DIR}/gemma-4-e4b-it-Q4_K_M.gguf" ]; then
    echo "  Placeholder: Download from Google's official release"
    echo "  URL: https://huggingface.co/google/gemma-4-4b-it-gguf"
else
    echo "  Already downloaded."
fi

# Qwen2.5-3B-Instruct (GGUF Q4_K_M)
echo ""
echo "[2/4] Downloading Qwen2.5-3B-Instruct..."
echo "  This is ~2GB. Please wait..."
if [ ! -f "${LLM_DIR}/qwen2.5-3b-instruct-Q4_K_M.gguf" ]; then
    echo "  Placeholder: Download from HuggingFace"
    echo "  URL: https://huggingface.co/Qwen/Qwen2.5-3B-Instruct-GGUF"
else
    echo "  Already downloaded."
fi

# DeepSeek-OCR2
echo ""
echo "[3/4] Setting up DeepSeek-OCR2..."
echo "  Placeholder: Clone from official repository"
echo "  Repository: https://github.com/deepseek-ai/DeepSeek-OCR"

# BGE-Small-EN Embeddings
echo ""
echo "[4/4] Downloading BGE-Small-EN embeddings..."
echo "  This is ~500MB. Please wait..."
if [ ! -d "${EMBEDDINGS_DIR}/bge-small-en-v1.5" ]; then
    python -c "
from sentence_transformers import SentenceTransformer
model = SentenceTransformer('BAAI/bge-small-en-v1.5')
model.save('${EMBEDDINGS_DIR}/bge-small-en-v1.5')
print('BGE-Small-EN downloaded successfully')
" 2>/dev/null || echo "  Will be downloaded on first run"
else
    echo "  Already downloaded."
fi

echo ""
echo "========================================"
echo "MODEL DOWNLOAD COMPLETE"
echo "========================================"
echo ""
echo "Models directory: ${MODELS_DIR}"
ls -lh "${LLM_DIR}/" 2>/dev/null || echo "  (LLM models pending)"
ls -lh "${EMBEDDINGS_DIR}/" 2>/dev/null || echo "  (Embeddings pending)"
