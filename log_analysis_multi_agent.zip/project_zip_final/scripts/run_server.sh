#!/bin/bash
# ============================================
# Run Server Script
# Starts the Log Analysis Multi-Agent System
# ============================================

echo "========================================"
echo "Log Analysis Multi-Agent System"
echo "========================================"

# Check Python version
python_version=$(python3 --version 2>&1 | awk '{print $2}')
echo "Python version: ${python_version}"

# Check if virtual environment exists
if [ -d "../venv" ]; then
    echo "Activating virtual environment..."
    source ../venv/bin/activate
fi

# Check models
echo ""
echo "Checking models..."
MODELS_DIR="../models/llm"

if [ -f "${MODELS_DIR}/gemma-4-e4b-it-Q5_K_M.gguf" ]; then
    echo "  ✅ Gemma model found"
else
    echo "  ⚠️  Gemma model not found (mock mode will be used)"
fi

if [ -f "${MODELS_DIR}/qwen2.5-3b-instruct-Q4_K_M.gguf" ]; then
    echo "  ✅ Qwen model found"
else
    echo "  ⚠️  Qwen model not found (mock mode will be used)"
fi

# Run the system
echo ""
echo "Starting system..."
cd ..
python main.py