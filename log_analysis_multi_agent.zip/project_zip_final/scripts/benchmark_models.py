#!/usr/bin/env python3
"""
Benchmark Models - Test model inference performance
"""

import time
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))


def benchmark_model(model_name: str, prompt: str, iterations: int = 3):
    """Benchmark a single model"""
    from models.model_configs import get_model_config

    config = get_model_config(model_name)
    if not config:
        print(f"Model '{model_name}' not found in config")
        return

    print(f"\nBenchmarking: {config.name}")
    print(f"  Path: {config.path}")
    print(f"  Size: {config.size_gb}GB")

    # Try to load and test
    try:
        from llama_cpp import Llama

        llm = Llama(
            model_path=config.path,
            n_ctx=config.context_size,
            n_threads=config.n_threads,
            verbose=False
        )

        times = []
        for i in range(iterations):
            start = time.time()
            output = llm(prompt, max_tokens=config.max_tokens)
            elapsed = time.time() - start
            times.append(elapsed)
            print(f"  Iteration {i + 1}: {elapsed:.2f}s ({len(output['choices'][0]['text'])} chars)")

        avg_time = sum(times) / len(times)
        print(f"  Average: {avg_time:.2f}s")
        print(f"  Tokens/sec: {config.max_tokens / avg_time:.1f}")

    except FileNotFoundError:
        print(f"  Model file not found: {config.path}")
        print(f"  Download the model first with: scripts/download_models.sh")
    except ImportError:
        print("  llama-cpp-python not installed")
        print("  Install with: pip install llama-cpp-python")
    except Exception as e:
        print(f"  Error: {e}")


def main():
    """Run benchmarks"""
    prompt = "Analyze this error log: [2024-01-15 14:32:11] ERROR database: Connection refused to 10.0.1.5:5432"

    print("=" * 50)
    print("MODEL BENCHMARK")
    print("=" * 50)

    benchmark_model("gemma", prompt)
    benchmark_model("qwen_small", prompt)


if __name__ == "__main__":
    main()
