#!/bin/bash
# ============================================
# Quantize Model Script
# Converts models to GGUF format with quantization
# ============================================

set -e

echo "========================================"
echo "MODEL QUANTIZATION SCRIPT"
echo "========================================"

# Default values
MODEL_PATH="${1}"
OUTPUT_PATH="${2}"
QUANTIZATION="${3:-Q4_K_M}"

if [ -z "$MODEL_PATH" ] || [ -z "$OUTPUT_PATH" ]; then
    echo ""
    echo "Usage: ./quantize_model.sh <input_model> <output_path> [quantization]"
    echo ""
    echo "Arguments:"
    echo "  input_model   - Path to source model (FP16/FP32)"
    echo "  output_path   - Path for quantized model"
    echo "  quantization  - Quantization type (default: Q4_K_M)"
    echo ""
    echo "Quantization Options:"
    echo "  Q2_K   - Smallest, lowest quality (~2-bit)"
    echo "  Q3_K_S - Small, low quality"
    echo "  Q3_K_M - Small-medium"
    echo "  Q4_K_S - Medium, good quality"
    echo "  Q4_K_M - Medium, better quality (recommended)"
    echo "  Q5_K_S - Large, high quality"
    echo "  Q5_K_M - Large, very high quality"
    echo "  Q6_K   - Larger, near-perfect"
    echo "  Q8_0   - Largest, almost identical to original"
    echo ""
    echo "Example:"
    echo "  ./quantize_model.sh model.gguf output-q4.gguf Q4_K_M"
    echo ""
    exit 1
fi

# Check if llama.cpp tools are available
if ! command -v llama-quantize &> /dev/null; then
    echo ""
    echo "❌ llama-quantize not found!"
    echo ""
    echo "Install llama.cpp first:"
    echo "  git clone https://github.com/ggerganov/llama.cpp"
    echo "  cd llama.cpp && make"
    echo "  sudo cp llama-quantize /usr/local/bin/"
    echo ""
    exit 1
fi

echo ""
echo "Input: $MODEL_PATH"
echo "Output: $OUTPUT_PATH"
echo "Quantization: $QUANTIZATION"
echo ""

# Check input exists
if [ ! -f "$MODEL_PATH" ]; then
    echo "❌ Input model not found: $MODEL_PATH"
    exit 1
fi

# Create output directory
mkdir -p "$(dirname "$OUTPUT_PATH")"

# Run quantization
echo "Quantizing... (this may take a while)"
llama-quantize "$MODEL_PATH" "$OUTPUT_PATH" "$QUANTIZATION"

# Check result
if [ -f "$OUTPUT_PATH" ]; then
    INPUT_SIZE=$(du -h "$MODEL_PATH" | cut -f1)
    OUTPUT_SIZE=$(du -h "$OUTPUT_PATH" | cut -f1)

    echo ""
    echo "✅ Quantization complete!"
    echo "   Input size:  $INPUT_SIZE"
    echo "   Output size: $OUTPUT_SIZE"
    echo "   Output path: $OUTPUT_PATH"
else
    echo "❌ Quantization failed!"
    exit 1
fi
