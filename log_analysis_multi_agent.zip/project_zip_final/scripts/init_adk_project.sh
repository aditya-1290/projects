#!/bin/bash
# ============================================
# Initialize ADK Project
# Sets up Google ADK for the project
# ============================================

echo "========================================"
echo "INITIALIZING ADK PROJECT"
echo "========================================"

# Check if ADK is installed
if ! python -c "import adk" 2>/dev/null; then
    echo "Installing Google ADK..."
    pip install google-adk
fi

# Initialize ADK project
echo "Initializing ADK..."
python -c "
from adk import init_project
init_project(
    project_name='log_analysis_system',
    description='Multi-agent log analysis system with A2A protocol',
    agents=[
        'extractor',
        'preprocessor',
        'analyzer',
        'solver',
        'debugger',
        'critic',
        'memory',
        'orchestrator'
    ]
)
print('ADK project initialized successfully')
" 2>/dev/null || echo "ADK initialization skipped (will use custom implementation)"

echo ""
echo "Project initialized!"
echo "Run 'python main.py' to start."
