# Log Analysis Multi-Agent System (Terminal-Based)

A **modular, decentralized multi-agent system** for analyzing logs from multiple sources (text, files, images, terminal), classifying them, debugging errors, and generating intelligent solutions using locally hosted LLMs. Built with peer-to-peer agent communication via the Agent-to-Agent (A2A) protocol.

Built with:
* 🐍 Python
* 🧠 Google ADK (Agent Development Kit)
* 🧩 MCP (Model Context Protocol)
* ⚡ Local inference via llama-cpp-python
* 🤖 LLMs: Gemma-4-E4B-IT + Qwen2.5-3B-Instruct (GGUF)
* 🖼️ OCR: DeepSeek-OCR2

---

## 🚀 Features

### 📥 Multi-Source Log Ingestion
* Files (`.log`, `.txt`, `.json`, `.csv`, `.xml`)
* Terminal commands output
* Image-based logs via OCR
* Structured log formats (syslog, Apache logs)

### 🧹 Intelligent Preprocessing
* Noise removal via Qwen2.5-3B
* Log structuring and normalization
* Smart chunking for large inputs
* Timestamp and IP normalization

### 🧠 Log Analysis (Merged Classifier + Intent)
* Error logs
* Server logs
* Application logs
* Security logs
* Intent: Debugging, Explanation, Optimization

### 🛠️ Multi-Step Reasoning Solver
* Root cause analysis
* High-level fix suggestions
* Human-readable explanation generation

### 👨‍💻 Code Debugging Agent
* Stack trace parsing
* Code context analysis
* Patch generation with validation

### ✅ Critic & Safety Agent
* Output quality validation
* Hallucination reduction
* Security audit of generated patches and commands
* Checklist-based verification

### 💾 Memory System
* Vector-based storage (ChromaDB)
* Past log & solution retrieval
* Reflexion loop for continuous improvement

### 🔄 Decentralized Agent Communication
* **A2A Protocol**: Agents communicate peer-to-peer
* **Capability Discovery**: Agents auto-discover who can handle tasks
* **Graceful Degradation**: Out-of-scope detection and handoff
* **No Central Controller**: Orchestrator is just another agent

### ⚙️ Multi-Model Strategy
* **Gemma-4-E4B-IT**: Primary reasoning (analyzer, solver, debugger, critic, orchestrator)
* **Qwen2.5-3B-Instruct**: Lightweight preprocessing and memory retrieval
* **DeepSeek-OCR2**: On-demand image text extraction
* **BGE-Small-EN**: Embeddings for memory system
* Smart model swapping to stay within 16GB RAM

### 🔒 Security-First Design
* Terminal command whitelist
* Sandboxed execution environment
* User approval gates for destructive operations
* Input sanitization pipeline
* Safety audit logging

---

## 🏗️ Architecture Overview

```text
┌─────────────────────────────────────────────────────────────────┐
│                    AGENT ECOSYSTEM (A2A Protocol)               │
│                                                                 │
│  ┌──────────┐         ┌──────────┐         ┌──────────┐       │
│  │ Extractor│◄───────►│Preprocess│◄───────►│ Analyzer │       │
│  │(OCR+File)│  A2A    │(Qwen 3B) │  A2A    │(Gemma 4B)│       │
│  └────┬─────┘         └────┬─────┘         └────┬─────┘       │
│       │                    │                    │              │
│       │              ┌─────┼────────────┐       │              │
│       │              │     │            │       │              │
│       │         ┌────▼─────┐  ┌───────▼──┐  ┌──▼────────┐    │
│       │         │ Debugger │  │  Solver  │  │  Memory   │    │
│       │         │(Gemma 4B)│  │(Gemma 4B)│  │(Qwen 3B)  │    │
│       │         └──────────┘  └──────────┘  └───────────┘    │
│       │                                                       │
│  ┌────▼──────────────────────────────────────────────────┐    │
│  │              Orchestrator Agent (Gemma 4B)             │    │
│  │   Task decomposition, coordination, user interface     │    │
│  └───────────────────────────────────────────────────────┘    │
│                            │                                   │
│                       ┌────▼─────┐                            │
│                       │  Critic  │                            │
│                       │(Gemma 4B)│                            │
│                       └──────────┘                            │
│                                                                 │
│  Communication Bus: Agent-to-Agent Protocol                     │
│  Model Manager: Smart loading/unloading of multiple LLMs        │
└─────────────────────────────────────────────────────────────────┘

Model Memory Footprint


┌─────────────────────────────────────────┐
│         SYSTEM MEMORY (16GB RAM)        │
│                                         │
│  ALWAYS LOADED:                         │
│  ├── Gemma-4-E4B-IT (Q4_K_M)   ~3.0GB  │
│  ├── Qwen2.5-3B-IT (Q4_K_M)    ~2.0GB  │
│  └── BGE Embedding Model        ~0.5GB  │
│  TOTAL BASE: ~5.5GB                     │
│                                         │
│  ON-DEMAND:                             │
│  └── DeepSeek-OCR2              ~2.0GB  │
│  PEAK TOTAL: ~7.5GB                     │
│                                         │
│  FREE FOR SYSTEM/CONTEXT: ~8.5GB        │
└─────────────────────────────────────────┘

Project Structure:

log_multi_agent/
│
├── main.py                    # Entry point (async CLI runner)
├── config.py                  # Global configs (models, paths, flags)
├── requirements.txt
├── README.md
├── pyproject.toml             # ADK project configuration
├── .env                       # Environment variables
│
├── agentos/                   # 🧠 ADK runtime system
│   ├── __init__.py
│   ├── agent_registry.py      # Central agent registration
│   ├── capability_registry.py # Global capability aggregation
│   ├── communication_bus.py   # A2A message broker
│   ├── message_protocol.py    # A2A message schemas
│   ├── model_manager.py       # Multi-model lifecycle manager
│   └── session_manager.py     # Session & context management
│
├── agents/                    # 🤖 All autonomous agents
│   ├── __init__.py
│   ├── base_agent.py          # ADK-compliant base class
│   ├── agent_config.py        # Model-to-agent assignments
│   │
│   ├── extractor/             # Multi-source log extraction
│   │   ├── __init__.py
│   │   ├── agent.py
│   │   ├── capabilities.json  # Machine-readable capability contract
│   │   ├── prompts.py
│   │   ├── tools.py
│   │   ├── loaders/           # File & terminal loaders
│   │   │   ├── __init__.py
│   │   │   ├── file_loader.py
│   │   │   ├── image_loader.py    # DeepSeek-OCR2 integration
│   │   │   └── terminal_loader.py
│   │   ├── parsers/           # Custom parsers (no LLM needed)
│   │   │   ├── __init__.py
│   │   │   ├── json_parser.py
│   │   │   ├── csv_parser.py
│   │   │   ├── xml_parser.py
│   │   │   ├── syslog_parser.py
│   │   │   └── apache_log_parser.py
│   │   └── tests/
│   │       ├── __init__.py
│   │       └── test_extractor.py
│   │
│   ├── preprocessor/          # Qwen2.5-3B: Cleaning & parsing
│   │   ├── __init__.py
│   │   ├── agent.py
│   │   ├── capabilities.json
│   │   ├── prompts.py
│   │   ├── tools.py
│   │   ├── cleaner.py
│   │   ├── parser.py
│   │   ├── chunker.py
│   │   ├── normalizer.py      # Timestamp/IP normalization
│   │   └── tests/
│   │       ├── __init__.py
│   │       └── test_preprocessor.py
│   │
│   ├── analyzer/              # Gemma-4-E4B: Classification + Intent
│   │   ├── __init__.py
│   │   ├── agent.py
│   │   ├── capabilities.json
│   │   ├── prompts.py
│   │   ├── tools.py
│   │   └── tests/
│   │       ├── __init__.py
│   │       └── test_analyzer.py
│   │
│   ├── solver/                # Gemma-4-E4B: Analysis & solutions
│   │   ├── __init__.py
│   │   ├── agent.py
│   │   ├── capabilities.json
│   │   ├── prompts.py
│   │   ├── tools.py
│   │   ├── error_analyzer.py
│   │   ├── fix_generator.py
│   │   ├── explanation_generator.py
│   │   └── tests/
│   │       ├── __init__.py
│   │       └── test_solver.py
│   │
│   ├── debugger/              # Gemma-4-E4B: Code debugging
│   │   ├── __init__.py
│   │   ├── agent.py
│   │   ├── capabilities.json
│   │   ├── prompts.py
│   │   ├── tools.py
│   │   ├── code_parser.py
│   │   ├── patch_generator.py
│   │   └── tests/
│   │       ├── __init__.py
│   │       └── test_debugger.py
│   │
│   ├── critic/                # Gemma-4-E4B: Validation & safety
│   │   ├── __init__.py
│   │   ├── agent.py
│   │   ├── capabilities.json
│   │   ├── prompts.py
│   │   ├── tools.py
│   │   ├── evaluator.py
│   │   ├── safety_checker.py
│   │   └── tests/
│   │       ├── __init__.py
│   │       └── test_critic.py
│   │
│   ├── memory/                # Qwen2.5-3B: Retrieval
│   │   ├── __init__.py
│   │   ├── agent.py
│   │   ├── capabilities.json
│   │   ├── prompts.py
│   │   ├── tools.py
│   │   ├── vector_store.py    # ChromaDB wrapper
│   │   ├── retrieval.py
│   │   └── tests/
│   │       ├── __init__.py
│   │       └── test_memory.py
│   │
│   └── orchestrator/          # Gemma-4-E4B: Coordination
│       ├── __init__.py
│       ├── agent.py
│       ├── capabilities.json
│       ├── prompts.py
│       ├── tools.py
│       ├── planner.py
│       ├── router.py
│       └── tests/
│           ├── __init__.py
│           └── test_orchestrator.py
│
├── models/                    # 🧪 Model layer
│   ├── __init__.py
│   ├── model_configs.py      # Model registry & configurations
│   ├── manager.py            # Lifecycle management
│   ├── llm/
│   │   ├── __init__.py
│   │   ├── loader.py         # llama-cpp-python loader
│   │   ├── gemma.py          # Gemma-4-E4B-IT wrapper
│   │   ├── qwen.py           # Qwen2.5-3B wrapper
│   │   ├── inference.py      # Shared inference logic
│   │   └── context_manager.py
│   ├── ocr/
│   │   ├── __init__.py
│   │   └── deepseek_ocr.py   # DeepSeek-OCR2 wrapper
│   └── embeddings/
│       ├── __init__.py
│       └── embedding_model.py
│
├── tools/                     # 🔧 MCP-compatible tools
│   ├── __init__.py
│   ├── base_tool.py
│   ├── file_tool.py
│   ├── terminal_tool.py      # Sandboxed execution
│   ├── ocr_tool.py
│   ├── search_tool.py
│   ├── code_analysis_tool.py
│   ├── registry.py           # Tool registry
│   └── sandbox.py            # Terminal sandbox
│
├── safety/                    # 🔒 Security layer
│   ├── __init__.py
│   ├── command_whitelist.py
│   ├── permission_manager.py
│   ├── input_sanitizer.py
│   └── audit_logger.py
│
├── communication/             # 📡 A2A protocol
│   ├── __init__.py
│   ├── a2a_protocol.py       # Message format definitions
│   ├── message_broker.py     # Pub/sub message routing
│   ├── discovery.py          # Agent capability discovery
│   └── schemas.py            # Message type definitions
│
├── memory_store/              # 💾 Persistent storage
│   ├── chroma_db/
│   └── logs/
│
├── prompts/                   # 🧾 Prompt templates
│   ├── extractor_ocr.txt
│   ├── preprocessor_qwen.txt
│   ├── analyzer_gemma.txt
│   ├── solver_gemma.txt
│   ├── debugger_gemma.txt
│   ├── critic_gemma.txt
│   ├── orchestrator_gemma.txt
│   └── memory_qwen.txt
│
├── utils/                     # 🧩 Utilities
│   ├── __init__.py
│   ├── logger.py
│   ├── json_utils.py
│   ├── validators.py
│   ├── chunking.py
│   ├── response_formatter.py
│   ├── confidence.py
│   └── model_utils.py
│
├── tests/                     # 🧪 Testing
│   ├── __init__.py
│   ├── conftest.py
│   ├── integration/
│   │   ├── __init__.py
│   │   ├── test_a2a_communication.py
│   │   ├── test_agent_collaboration.py
│   │   ├── test_model_switching.py
│   │   └── test_edge_cases.py
│   └── e2e/
│       ├── __init__.py
│       ├── test_full_pipeline.py
│       └── test_security_scenarios.py
│
├── scripts/                   # ⚙️ Utilities
│   ├── download_models.sh    # Download all models
│   ├── quantize_model.sh
│   ├── run_server.sh
│   ├── benchmark_models.py
│   └── init_adk_project.sh
│
└── docs/                      # 📚 Documentation
    ├── architecture.md
    ├── model_strategy.md
    ├── a2a_protocol_spec.md
    ├── agent_capabilities.md
    ├── security_model.md
    └── adk_setup_guide.md
    
log_multi_agent/
│
├── main.py                              # 👤 YOU
├── config.py                            # 👤 YOU
├── requirements.txt                     # 👤 YOU
├── pyproject.toml                       # 👤 YOU
├── .env                                 # 👤 YOU
├── README.md                            # ✅ DONE (already created)
│
├── agentos/                             # 🧠 ADK Runtime
│   ├── __init__.py                      # 👤 YOU
│   ├── agent_registry.py               # 👤 YOU
│   ├── capability_registry.py          # 👤 YOU
│   ├── communication_bus.py            # 👤 YOU
│   ├── message_protocol.py             # 👤 YOU
│   ├── model_manager.py                # 👤 YOU
│   └── session_manager.py              # 👤 YOU
│
├── agents/                              # 🤖 All Agents
│   ├── __init__.py                      # 👤 YOU
│   ├── base_agent.py                    # 👤 YOU (CRITICAL - B & C need this)
│   ├── agent_config.py                  # 👤 YOU
│   │
│   ├── extractor/                       # 👤 PERSON C
│   │   ├── __init__.py                  # 👤 C
│   │   ├── agent.py                     # 👤 C
│   │   ├── capabilities.json            # 👤 C
│   │   ├── prompts.py                   # 👤 C
│   │   ├── tools.py                     # 👤 C
│   │   ├── loaders/
│   │   │   ├── __init__.py              # 👤 C
│   │   │   ├── file_loader.py           # 👤 C
│   │   │   ├── image_loader.py          # 👤 C
│   │   │   └── terminal_loader.py       # 👤 C
│   │   └── parsers/
│   │       ├── __init__.py              # 👤 C
│   │       ├── json_parser.py           # 👤 C
│   │       ├── csv_parser.py            # 👤 C
│   │       ├── xml_parser.py            # 👤 C
│   │       ├── syslog_parser.py         # 👤 C
│   │       └── apache_log_parser.py     # 👤 C
│   │
│   ├── preprocessor/                    # 👤 YOU
│   │   ├── __init__.py
│   │   ├── agent.py
│   │   ├── capabilities.json
│   │   ├── prompts.py
│   │   ├── tools.py
│   │   ├── cleaner.py
│   │   ├── parser.py
│   │   ├── chunker.py
│   │   └── normalizer.py
│   │
│   ├── analyzer/                        # 👤 PERSON B
│   │   ├── __init__.py                  # 👤 B
│   │   ├── agent.py                     # 👤 B
│   │   ├── capabilities.json            # 👤 B
│   │   ├── prompts.py                   # 👤 B
│   │   └── tools.py                     # 👤 B
│   │
│   ├── solver/                          # 👤 YOU
│   │   ├── __init__.py
│   │   ├── agent.py
│   │   ├── capabilities.json
│   │   ├── prompts.py
│   │   ├── tools.py
│   │   ├── error_analyzer.py
│   │   ├── fix_generator.py
│   │   └── explanation_generator.py
│   │
│   ├── debugger/                        # 👤 PERSON B
│   │   ├── __init__.py                  # 👤 B
│   │   ├── agent.py                     # 👤 B
│   │   ├── capabilities.json            # 👤 B
│   │   ├── prompts.py                   # 👤 B
│   │   ├── tools.py                     # 👤 B
│   │   ├── code_parser.py               # 👤 B
│   │   └── patch_generator.py           # 👤 B
│   │
│   ├── critic/                          # 👤 YOU
│   │   ├── __init__.py
│   │   ├── agent.py
│   │   ├── capabilities.json
│   │   ├── prompts.py
│   │   ├── tools.py
│   │   ├── evaluator.py
│   │   └── safety_checker.py
│   │
│   ├── memory/                          # 👤 YOU
│   │   ├── __init__.py
│   │   ├── agent.py
│   │   ├── capabilities.json
│   │   ├── prompts.py
│   │   ├── tools.py
│   │   ├── vector_store.py
│   │   └── retrieval.py
│   │
│   └── orchestrator/                    # 👤 YOU
│       ├── __init__.py
│       ├── agent.py
│       ├── capabilities.json
│       ├── prompts.py
│       ├── tools.py
│       ├── planner.py
│       └── router.py
│
├── models/                              # 🧪 Model Layer
│   ├── __init__.py                      # 👤 YOU
│   ├── model_configs.py                # 👤 YOU
│   ├── manager.py                       # 👤 YOU
│   ├── llm/
│   │   ├── __init__.py                  # 👤 YOU
│   │   ├── loader.py                    # 👤 YOU
│   │   ├── gemma.py                     # 👤 YOU
│   │   ├── qwen.py                      # 👤 YOU
│   │   ├── inference.py                 # 👤 YOU
│   │   └── context_manager.py           # 👤 YOU
│   ├── ocr/
│   │   ├── __init__.py                  # 👤 YOU
│   │   └── deepseek_ocr.py             # 👤 YOU
│   └── embeddings/
│       ├── __init__.py                  # 👤 YOU
│       └── embedding_model.py           # 👤 YOU
│
├── tools/                               # 🔧 MCP Tools
│   ├── __init__.py                      # 👤 YOU
│   ├── base_tool.py                     # 👤 YOU
│   ├── file_tool.py                     # 👤 YOU
│   ├── terminal_tool.py                 # 👤 YOU
│   ├── ocr_tool.py                      # 👤 YOU
│   ├── search_tool.py                   # 👤 YOU
│   ├── code_analysis_tool.py            # 👤 YOU
│   ├── registry.py                      # 👤 YOU
│   └── sandbox.py                       # 👤 YOU
│
├── safety/                              # 🔒 Security
│   ├── __init__.py                      # 👤 YOU
│   ├── command_whitelist.py             # 👤 YOU
│   ├── permission_manager.py            # 👤 YOU
│   ├── input_sanitizer.py               # 👤 YOU
│   └── audit_logger.py                  # 👤 YOU
│
├── communication/                       # 📡 A2A Protocol
│   ├── __init__.py                      # 👤 YOU
│   ├── a2a_protocol.py                 # 👤 YOU
│   ├── message_broker.py               # 👤 YOU
│   ├── discovery.py                     # 👤 YOU
│   └── schemas.py                       # 👤 YOU
│
├── memory_store/                        # 💾 Storage
│   ├── chroma_db/                       # 👤 YOU
│   │   └── .gitkeep
│   └── logs/                            # 👤 YOU
│       └── .gitkeep
│
├── prompts/                             # 🧾 Templates
│   ├── extractor_ocr.txt                # 👤 C
│   ├── preprocessor_qwen.txt            # 👤 YOU
│   ├── analyzer_gemma.txt               # 👤 B
│   ├── solver_gemma.txt                 # 👤 YOU
│   ├── debugger_gemma.txt               # 👤 B
│   ├── critic_gemma.txt                 # 👤 YOU
│   ├── orchestrator_gemma.txt           # 👤 YOU
│   └── memory_qwen.txt                  # 👤 YOU
│
├── utils/                               # 🧩 Utilities
│   ├── __init__.py                      # 👤 YOU
│   ├── logger.py                        # 👤 YOU
│   ├── json_utils.py                    # 👤 YOU
│   ├── validators.py                    # 👤 YOU
│   ├── chunking.py                      # 👤 YOU
│   ├── response_formatter.py            # 👤 YOU
│   ├── confidence.py                    # 👤 YOU
│   └── model_utils.py                   # 👤 YOU
│
├── tests/                               # 🧪 Testing
│   ├── __init__.py                      # 👤 YOU
│   ├── conftest.py                      # 👤 YOU
│   ├── integration/
│   │   ├── __init__.py                  # 👤 YOU
│   │   ├── test_a2a_communication.py    # 👤 YOU
│   │   ├── test_agent_collaboration.py  # 👤 YOU
│   │   ├── test_model_switching.py      # 👤 YOU
│   │   └── test_edge_cases.py           # 👤 YOU
│   └── e2e/
│       ├── __init__.py                  # 👤 YOU
│       ├── test_full_pipeline.py        # 👤 YOU
│       └── test_security_scenarios.py   # 👤 YOU
│
├── scripts/                             # ⚙️ Scripts
│   ├── download_models.sh               # 👤 YOU
│   ├── quantize_model.sh                # 👤 YOU
│   ├── run_server.sh                    # 👤 YOU
│   ├── benchmark_models.py              # 👤 YOU
│   └── init_adk_project.sh              # 👤 YOU
│
└── docs/                                # 📚 Docs
    ├── architecture.md                  # 👤 YOU
    ├── model_strategy.md                # 👤 YOU
    ├── a2a_protocol_spec.md             # 👤 YOU
    ├── agent_capabilities.md            # 👤 YOU
    ├── security_model.md                # 👤 YOU
    └── adk_setup_guide.md               # 👤 YOU

 Agent Capabilities Overview:
 
Agent	                   Model	                                      Can Do	                                                     Cannot Do
Extractor	     Custom Parsers + DeepSeek-OCR2	  Extract from files, images, terminal; Parse JSON/CSV/XML/syslog/Apache	Handle proprietary binary formats; Fix corrupted images
Preprocessor	 Qwen2.5-3B	                      Clean noise, structure logs, normalize data, smart chunking	            Interpret log semantics; Classify errors
Analyzer	     Gemma-4-E4B	                  Classify log types, determine user intent, confidence scoring	            Generate fixes; Debug code
Solver	         Gemma-4-E4B	                  Root cause analysis, high-level fix suggestions, explanations	            Modify production code; Execute fixes
Debugger	     Gemma-4-E4B	                  Parse stack traces, analyze code context, generate patches	            Execute patches; Modify infrastructure
Critic	         Gemma-4-E4B	                  Validate output quality, detect hallucinations, security audit	        Generate new solutions; Access external data
Memory	         Qwen2.5-3B + BGE	              Store/retrieve past solutions, find similar cases	                        Generate new solutions independently
Orchestrator	 Gemma-4-E4B	                  Decompose tasks, coordinate agents, handle edge cases	                    Specialize in any single domain

Installation
1. System Requirements
    -CPU with 16GB+ RAM recommended
    -Python 3.11+
    -20GB free disk space for models

2. Create Virtual Environment
    python -m venv venv
    source venv/bin/activate   # Linux/Mac
    venv\Scripts\activate      # Windows

3. Install Dependencies
    pip install -r requirements.txt

4. Initialize ADK Project
    bash scripts/init_adk_project.sh

5. Download Models
    bash scripts/download_models.sh

This downloads:

    - gemma-4-4b-it-Q4_K_M.gguf (~3GB) → models/llm/
    - qwen2.5-3b-instruct-Q4_K_M.gguf (~2GB) → models/llm/
    - DeepSeek-OCR2 (~2GB) → models/ocr/
    - bge-small-en-v1.5 (~500MB) → models/embeddings/

Usage
Start the System

python main.py


Example Interactions
1. File Log Analysis

> Analyze the error log at logs/application_error.log

🤖 [Orchestrator] Decomposing task...
   ├── Extractor: Parsing log file...
   ├── Preprocessor: Cleaning 450 lines, 3.2KB...
   ├── Analyzer: Classified as APPLICATION_ERROR, Intent: DEBUGGING
   ├── Solver: Root cause: NullPointerException in UserService.java:142
   │   Suggested fix: Add null check before dereferencing user object
   ├── Critic: Validated (confidence: 0.89)
   └── Response generated

📋 ANALYSIS:
Root Cause: The UserService.getUser() method returns null when user ID is not found,
but UserController.java:142 directly calls user.getName() without a null check.

🔧 SUGGESTED FIX:
Add null validation before line 142:
  if (user != null) {
      String name = user.getName();
  } else {
      throw new UserNotFoundException("User not found");
  }

2. Image-Based Log

> Analyze this error screenshot: screenshots/kernel_panic.png

🤖 [Orchestrator] Decomposing task...
   ├── Extractor: Loading DeepSeek-OCR2 (on-demand)...
   ├── Extractor: Text extracted from image
   ├── Preprocessor: Normalizing kernel log format...
   ├── Analyzer: Classified as SYSTEM_CRASH, Intent: DEBUGGING
   ...


3. Direct Log Paste
> [2024-01-15 14:32:11] ERROR database: Connection refused to 10.0.1.5:5432
  [2024-01-15 14:32:12] WARN retry: Attempting reconnection (1/3)
  [2024-01-15 14:32:15] ERROR database: Connection refused to 10.0.1.5:5432
  [2024-01-15 14:32:16] FATAL application: Max retries exceeded, shutting down

🤖 [Orchestrator] Processing pasted logs...
   ├── Extractor: Parsing plain text...
   ├── Preprocessor: Structured 4 log entries
   ├── Analyzer: Classified as DATABASE_CONNECTION_ERROR
   ├── Solver: Root cause: PostgreSQL server unreachable at 10.0.1.5:5432
   │   Possible causes: Firewall blocking, PostgreSQL service down, network issue
   ├── Critic: Validated (confidence: 0.93)
   └── Response generated

4. Out-of-Scope Query
> What's the weather in Tokyo?

🤖 I'm a specialized log analysis assistant. My capabilities include:
- 📥 Log extraction from files, terminals, and images
- 🧹 Preprocessing and noise removal
- 🏷️ Log classification (error, server, application, security)
- 🔍 Root cause analysis and solution generation
- 🐛 Code debugging and patch generation
...and more related to log diagnostics.

I cannot provide weather information. How can I help with your logs?

 Model Strategy

This project uses a tiered multi-model approach optimized for 16GB RAM:

Purpose	                      Model	                          Size	        Loading
Primary Reasoning	    Gemma-4-4B-IT (GGUF, Q4_K_M)	      ~3GB	     Always loaded
Log Cleaning & Parsing	Qwen2.5-3B-Instruct (GGUF, Q4_K_M)	  ~2GB	     Always loaded
Image Extraction	    DeepSeek-OCR2	                      ~2GB	     On-demand
Embeddings	            BGE-Small-EN	                      ~0.5GB	 Always loaded

Why this strategy?
    - Gemma-4-E4B: Superior instruction following for complex reasoning
    - Qwen2.5-3B: Longer context (32K tokens), faster for cleaning tasks
    - DeepSeek-OCR2: Only loaded when processing images, unloaded after use
    - BGE-Small: Lightweight embeddings for memory retrieval


Agent-to-Agent (A2A) Protocol
Agents communicate via a standardized message protocol, not a central controller:

# Example A2A Message
{
  "message_id": "uuid-1234",
  "message_type": "REQUEST",
  "sender_id": "extractor_v1",
  "sender_type": "extractor",
  "target_type": "preprocessor",
  "task": {
    "action": "preprocess",
    "raw_log": "...",
    "options": {"remove_noise": True}
  },
  "confidence": 1.0,
  "requires_human": False
}

Communication Patterns:
Pattern                             	Use Case
Request-Response	        Direct task delegation (e.g., Extractor → Preprocessor)
Broadcast	                Capability discovery (e.g., "Who can handle this error?")
Handoff	                    Error escalation (e.g., Solver → Debugger when code analysis needed)
Pub/Sub	                    Event notifications (e.g., Critic publishes validation results)


Each agent self-evaluates incoming requests against its capability contract and responds with:

✅ Can handle → Executes and returns results
⚠️ Partial → Handles what it can, flags limitations
❌ Cannot handle → Suggests alternative agents, graceful message

Security Model:

Layer	                            Protection
Input Sanitization	    All user inputs validated before processing
Command Whitelist	    Terminal commands restricted to approved list
Sandboxed Execution	    Terminal runs in isolated container
Permission Gates	    Destructive operations require user approval
Safety Checker	        Critic agent evaluates all patches and commands
Audit Logging	        All operations logged for review


Testing:
Run All Tests
    - pytest tests/
Run Specific Test Suites
    # Agent integration tests
    pytest tests/integration/
    
    # End-to-end scenarios
    pytest tests/e2e/
    
    # A2A communication tests
    pytest tests/integration/test_a2a_communication.py
    
    # Model lifecycle tests
    pytest tests/integration/test_model_switching.py
    
    # Edge case handling
    pytest tests/integration/test_edge_cases.py

Roadmap
Phase 1 (Current)
    ✅ Core multi-agent architecture with A2A protocol
    ✅ Multi-model strategy with smart memory management
    ✅ Capability contracts and agent self-awareness
    ✅ Graceful edge case handling

Phase 2
    🔄 Streaming log support
    🔄 Reflexion loops (memory-based improvement)
    🔄 Confidence scoring enhancements

Phase 3
    🔄 Distributed agent execution
    🔄 Custom model fine-tuning for log analysis
    🔄 Web UI dashboard (optional)

Phase 4
    🔄 Plugin system for custom parsers
    🔄 Real-time log monitoring
    🔄 Multi-user session support

Limitations
    - CPU-only → Slower inference than GPU (trade-off for accessibility)
    - Large logs must be chunked → Chunking strategy may lose cross-chunk context
    - Not for real-time streaming → Batch processing only (Phase 2)
    - Single-user → One session at a time (Phase 4)
    - 16GB RAM minimum → Lower memory may cause model swapping delays

Design Principles
    - Self-Awareness: Every agent knows exactly what it can and cannot do
    - Graceful Failure: Out-of-scope requests receive helpful guidance, not hallucinations
    - Decentralization: No single controller—agents negotiate via A2A protocol
    - Memory Efficiency: Smart model loading/swapping for CPU environments
    - Security First: Every action vetted through multiple safety layers
    - Extensibility: New agents register capabilities and join the ecosystem

Contributing
    - Contributions are welcome!
    - Fork the repo
    - Create a feature branch
    - Add tests for new functionality
    - Submit a PR with documentation

Contribution Areas
    - New log format parsers
    - Additional tool integrations
    - Prompt engineering improvements
    - Performance optimizations
    - Documentation enhancements

Acknowledgements
    - Google ADK - Agent Development Kit framework
    - llama.cpp - Local LLM inference
    - Gemma - Primary reasoning model
    - Qwen - Lightweight processing model
    - DeepSeek - OCR capabilities
    - ChromaDB - Vector storage
    - MCP - Model Context Protocol

Final Note
This system is designed to be:
    
    - Modular - Each agent is independent and replaceable
    - Scalable - Add new agents by registering capabilities
    - CPU-Efficient - Multi-model strategy optimized for 16GB RAM
    - Resilient - Graceful handling of edge cases and out-of-scope requests
    - Secure - Multiple layers of safety validation
    - Start small, understand the A2A protocol, and gradually expand the ecosystem. The key is that no agent needs to know everything—just its own capabilities and how to discover others.
