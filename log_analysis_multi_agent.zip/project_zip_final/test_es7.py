import asyncio
import os
from dotenv import load_dotenv
load_dotenv()
import sys
sys.path.insert(0, 'D:/python_tasks/log_analysis_multi_agent')
from agents.extractor.loaders.es_loader import ElasticsearchLoader

async def main():
    loader = ElasticsearchLoader(verify_certs=False)
    print(f'API Key first 20: {loader.api_key[:20] if loader.api_key else "NONE"}...')
    
    # Check if client was created
    client = loader._create_client()
    print(f'Client created')
    
    try:
        info = client.info()
        print(f'Success! Cluster: {info.get("cluster_name")}')
        print(f'Version: {info.get("version", {}).get("number")}')
    except Exception as e:
        print(f'Failed: {e}')

asyncio.run(main())
