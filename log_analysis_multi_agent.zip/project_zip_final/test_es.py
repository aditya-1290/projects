import os
from dotenv import load_dotenv
load_dotenv()
from elasticsearch import Elasticsearch

cloud_id = os.getenv('ELASTICSEARCH_CLOUD_ID')
api_key = os.getenv('ELASTICSEARCH_API_KEY')
user = os.getenv('ELASTICSEARCH_USER', 'elastic')

print(f'Cloud ID: {cloud_id[:30] if cloud_id else "NOT SET"}...')
print(f'API Key: {"SET" if api_key else "NOT SET"}')
print(f'User: {user}')

# Try connecting with cloud_id + api_key
try:
    es = Elasticsearch(
        cloud_id=cloud_id,
        api_key=api_key,
        request_timeout=10
    )
    ping = es.ping()
    print(f'Ping result: {ping}')
    if ping:
        info = es.info()
        print(f'Cluster: {info.get("cluster_name")}, Version: {info.get("version", {}).get("number")}')
except Exception as e:
    print(f'Connection failed: {e}')
