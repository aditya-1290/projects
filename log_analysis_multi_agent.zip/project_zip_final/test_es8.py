import asyncio
import os
from dotenv import load_dotenv
load_dotenv()
import sys
sys.path.insert(0, 'D:/python_tasks/log_analysis_multi_agent')
from agents.extractor.loaders.es_loader import ElasticsearchLoader
import base64

async def main():
    raw_key = os.getenv('ELASTICSEARCH_API_KEY')
    es_url = "https://274d14877f1f4cfabf44b838f7b889d0.us-central1.gcp.cloud.es.io"
    
    # Try different formats
    formats = {
        "Raw key": raw_key,
        "Base64 of raw key": base64.b64encode(raw_key.encode()).decode(),
        "Bearer token (ApiKey prefix)": f"ApiKey {raw_key}",
    }
    
    for name, key in formats.items():
        try:
            from elasticsearch import Elasticsearch
            es = Elasticsearch(
                hosts=[es_url],
                api_key=key,
                verify_certs=False,
                ssl_show_warn=False,
                request_timeout=5
            )
            info = es.info()
            print(f'? {name}: SUCCESS - Cluster: {info.get("cluster_name")}')
            return
        except Exception as e:
            print(f'? {name}: {str(e)[:80]}')

asyncio.run(main())
