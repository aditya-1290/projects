import os
from dotenv import load_dotenv
load_dotenv()
from elasticsearch import Elasticsearch

api_key = os.getenv('ELASTICSEARCH_API_KEY')
es_url = "https://274d14877f1f4cfabf44b838f7b889d0.us-central1.gcp.cloud.es.io"

# Try with verify_certs=False for free tier SSL issues
try:
    es = Elasticsearch(
        hosts=[es_url],
        api_key=api_key,
        verify_certs=False,
        ssl_show_warn=False,
        request_timeout=30
    )
    ping = es.ping()
    print(f'Ping result: {ping}')
    if ping:
        info = es.info()
        print(f'Cluster: {info.get("cluster_name")}, Version: {info.get("version", {}).get("number")}')
    else:
        # Try getting cluster info anyway
        try:
            info = es.info()
            print(f'Info succeeded despite ping=False: {info.get("cluster_name")}')
        except Exception as e2:
            print(f'Info also failed: {e2}')
except Exception as e:
    print(f'Connection failed: {e}')
