"""
Communication Bus - The Central Nervous System

This is the backbone of the entire multi-agent system.
All A2A messages flow through this bus.

Responsibilities:
- Agent registration and discovery
- Message routing (direct, broadcast, pub/sub)
- Capability-based agent discovery
- Message queue management
- Delivery tracking
"""

import asyncio
import time
from typing import Dict, List, Optional, Any, Set
from collections import defaultdict
from datetime import datetime

from communication.a2a_protocol import (
    A2AMessage,
    MessageType,
    MessagePriority,
    DeliveryStatus,
    CapabilityQuery,
    CapabilityResponse,
    ErrorCodes
)


class CommunicationBus:
    """
    Central communication bus for the multi-agent system.

    All agents MUST register with this bus to communicate.
    The bus handles:
    1. Agent Registry - Who exists in the system
    2. Message Routing - Getting messages to the right agent(s)
    3. Capability Discovery - Finding agents that can handle tasks
    4. Pub/Sub - Broadcasting and subscribing to message types
    """

    def __init__(self):
        # Agent Registry
        self.agents: Dict[str, Any] = {}  # agent_id -> BaseAgent instance

        # Subscription Registry
        self.subscriptions: Dict[str, Set[MessageType]] = defaultdict(set)
        # agent_id -> set of MessageTypes they want to receive

        # Capability Index (for fast discovery)
        self.capability_index: Dict[str, List[str]] = defaultdict(list)
        # capability_name -> [agent_ids]

        # Message Queue
        self.message_queue: asyncio.Queue = asyncio.Queue()

        # Tracking
        self.pending_messages: Dict[str, A2AMessage] = {}
        self.delivery_log: List[Dict] = []
        self.is_running: bool = False

        # Statistics
        self.stats = {
            "messages_sent": 0,
            "messages_delivered": 0,
            "messages_failed": 0,
            "broadcasts_sent": 0,
            "discoveries_made": 0,
            "errors": 0
        }
        self._send_depth = 0  # <-- ADD THIS
        self.MAX_SEND_DEPTH = 10  # <-- ADD THIS

    # ============================================
    # Agent Registration
    # ============================================

    async def register_agent(self, agent: Any):
        """
        Register an agent with the bus.

        Args:
            agent: An instance of BaseAgent subclass
        """
        agent_id = agent.agent_id

        # Store agent reference
        self.agents[agent_id] = agent

        # Set up bidirectional connection
        agent.comm_bus = self

        # Index capabilities for discovery
        for capability in agent.capability.capabilities:
            self.capability_index[capability].append(agent_id)

        # Subscribe to default message types
        await self.subscribe(agent_id, MessageType.REQUEST)
        await self.subscribe(agent_id, MessageType.BROADCAST)
        await self.subscribe(agent_id, MessageType.DISCOVERY)

        self._log("REGISTRATION", f"Agent registered: {agent.capability.agent_name} ({agent_id})")

        # Print capabilities
        caps = ", ".join(agent.capability.capabilities)
        self._log("CAPABILITIES", f"  └─ Can: {caps}")

    async def unregister_agent(self, agent_id: str):
        """Remove an agent from the bus"""
        if agent_id in self.agents:
            agent = self.agents[agent_id]

            # Remove from capability index
            for capability in agent.capability.capabilities:
                if agent_id in self.capability_index[capability]:
                    self.capability_index[capability].remove(agent_id)

            # Remove subscriptions
            if agent_id in self.subscriptions:
                del self.subscriptions[agent_id]

            # Remove agent reference
            agent.comm_bus = None
            del self.agents[agent_id]

            self._log("UNREGISTER", f"Agent unregistered: {agent_id}")

    # ============================================
    # Subscription Management
    # ============================================

    async def subscribe(self, agent_id: str, message_type: MessageType):
        """Subscribe an agent to a message type"""
        if agent_id in self.agents:
            self.subscriptions[agent_id].add(message_type)

    async def unsubscribe(self, agent_id: str, message_type: MessageType):
        """Unsubscribe an agent from a message type"""
        if agent_id in self.subscriptions:
            self.subscriptions[agent_id].discard(message_type)

    # ============================================
    # Message Sending
    # ============================================

    async def send_message(self, message: A2AMessage):
        """
        Send a message to its intended target(s).

        This is the main entry point for sending messages.
        All routing logic lives here.
        """
        self._send_depth += 1
        if self._send_depth > self.MAX_SEND_DEPTH:
            self._send_depth -= 1
            self._log("BLOCK", f"Recursion limit reached, dropping message")
            return
        try:
            if not message.sender_id:
                raise ValueError("Message must have a sender_id")

            # ---- GUARD: Prevent infinite error loops ----
            if message.message_type == MessageType.ERROR:
                # Count recent errors between the same two agents
                matching_errors = [
                    msg for msg in self.pending_messages.values()
                    if msg.message_type == MessageType.ERROR
                       and msg.sender_id == message.sender_id
                       and msg.target_id == message.target_id
                ]
                if len(matching_errors) > 3:  # Lower threshold = faster cutoff
                    self._log("BLOCK",
                              f"Blocked ERROR loop between {message.sender_id} and {message.target_id} ({len(matching_errors)} pending)")
                    return  # Drop the message

                # Also block if we have too many pending ERRORs overall
                total_errors = sum(
                    1 for msg in self.pending_messages.values()
                    if msg.message_type == MessageType.ERROR
                )
                if total_errors > 15:
                    self._log("BLOCK", f"Blocked ERROR — too many pending ({total_errors})")
                    return
            # -------------------------------------------

            # Track message
            self.pending_messages[message.message_id] = message
            self.stats["messages_sent"] += 1

            # Log to audit
            try:
                from utils.audit_logger import get_audit_logger
                audit = get_audit_logger()
                audit.log_message(
                    query_id=message.correlation_id or message.message_id,
                    direction="REQUEST" if message.message_type.value.upper() == "REQUEST" else "RESPONSE",
                    from_agent=message.sender_type or "unknown",
                    to_agent=message.target_type or "broadcast",
                    message_type=message.message_type.value.upper(),
                    action=message.task.get("action") if message.task else None,
                    confidence=message.confidence,
                    message_size=len(str(message.task)) + len(str(message.response)),
                    correlation_id=message.correlation_id,
                    error=message.error,
                )
            except Exception:
                pass

            # self._log("SEND", message.to_log_string())
            try:
                log_str = message.to_log_string()
            except AttributeError:
                log_str = f"[{message.message_type}] {message.sender_type} → {message.target_type or 'ALL'}"
            self._log("SEND", log_str)

            # ===== ADD THIS: Prevent infinite error loops =====
            # Count how many ERROR messages have been exchanged
            if message.message_type == MessageType.ERROR:
                error_count = sum(
                    1 for msg in self.pending_messages.values()
                    if msg.message_type == MessageType.ERROR
                )
                if error_count > 20:  # Cap at 20 error messages total
                    self._log("BLOCK", f"Blocked ERROR message to prevent loop (count: {error_count})")
                    return  # Silently drop the message
            # =================================================

            # Route based on message type
            if message.message_type == MessageType.BROADCAST:
                await self._handle_broadcast(message)
            elif message.message_type == MessageType.DISCOVERY:
                await self._handle_discovery(message)
            elif message.target_id:
                await self._handle_direct_message(message)
            elif message.target_type:
                await self._handle_type_based_routing(message)
            else:
                # Default: treat as broadcast to subscribed agents
                await self._handle_broadcast(message)
        finally:
            self._send_depth -= 1

    async def _handle_direct_message(self, message: A2AMessage):
        """Route message to a specific agent by ID"""
        target = message.target_id

        if target in self.agents:
            message.mark_delivered()
            self.stats["messages_delivered"] += 1

            agent = self.agents[target]
            response = await agent.receive_message(message)

            if response:
                await self.send_message(response)
        else:
            self._handle_failed_delivery(message, f"Agent {target} not found")

    async def _handle_type_based_routing(self, message: A2AMessage):
        """Route message to all agents of a specific type"""
        target_type = message.target_type
        delivered = False

        for agent_id, agent in self.agents.items():
            if agent.capability.agent_name == target_type:
                # CREATE A COPY so we don't mutate the original message
                # (prevents correlation_id / target_id corruption on retries)
                import copy
                routed_message = copy.deepcopy(message)
                routed_message.target_id = agent_id

                routed_message.mark_delivered()
                self.stats["messages_delivered"] += 1
                delivered = True

                try:
                    response = await agent.receive_message(routed_message)
                    if response:
                        await self.send_message(response)
                except Exception as e:
                    self._log("ERROR", f"Agent {agent_id} failed: {e}")

        if not delivered:
            self._handle_failed_delivery(message, f"No agents of type '{target_type}' found")

    async def _handle_broadcast(self, message: A2AMessage):
        """Broadcast message to all subscribed agents"""
        self.stats["broadcasts_sent"] += 1
        delivered_count = 0

        for agent_id, agent in self.agents.items():
            # Skip sender
            if agent_id == message.sender_id:
                continue

            # Check subscription
            if message.message_type in self.subscriptions.get(agent_id, set()):
                # Create a copy for each recipient
                agent_message = A2AMessage.from_dict(message.to_dict())
                agent_message.target_id = agent_id
                agent_message.mark_delivered()

                delivered_count += 1

                # Fire and forget for broadcasts
                asyncio.create_task(agent.receive_message(agent_message))

        self.stats["messages_delivered"] += delivered_count

    async def _handle_discovery(self, message: A2AMessage):
        """
        Handle capability discovery requests.

        The message task should contain:
        - required_capabilities: List[str]
        - optional_capabilities: List[str] (optional)
        - context: Dict (optional)
        """
        self.stats["discoveries_made"] += 1

        task = message.task or {}
        required_capabilities = task.get("required_capabilities", [])
        optional_capabilities = task.get("optional_capabilities", [])

        self._log("DISCOVERY", f"Looking for: {required_capabilities}")

        # Find capable agents
        capable_agents = await self.discover_agents(required_capabilities)

        # Build response
        response_data = {
            "query": {
                "required_capabilities": required_capabilities,
                "optional_capabilities": optional_capabilities
            },
            "results": []
        }

        for agent_id, score in capable_agents:
            agent = self.agents[agent_id]

            # Check which capabilities match
            matching = [c for c in required_capabilities if c in agent.capability.capabilities]
            missing = [c for c in required_capabilities if c not in agent.capability.capabilities]

            response_data["results"].append({
                "agent_id": agent_id,
                "agent_type": agent.capability.agent_name,
                "can_handle": len(missing) == 0,
                "partial": len(missing) > 0 and len(matching) > 0,
                "matching_capabilities": matching,
                "missing_capabilities": missing,
                "confidence": 1.0 if len(missing) == 0 else len(matching) / len(required_capabilities)
            })

        # Send response back to requester
        response = A2AMessage(
            message_type=MessageType.RESPONSE,
            sender_id="communication_bus",
            sender_type="infrastructure",
            target_id=message.sender_id,
            correlation_id=message.message_id,
            response=response_data
        )

        await self.send_message(response)

    # ============================================
    # Agent Discovery
    # ============================================

    async def discover_agents(
            self,
            required_capabilities: List[str],
            limit: int = 10
    ) -> List[tuple]:
        """
        Discover agents that have the required capabilities.

        Returns:
            List of (agent_id, match_score) tuples sorted by score descending
        """
        scores: Dict[str, float] = defaultdict(float)

        for capability in required_capabilities:
            if capability in self.capability_index:
                for agent_id in self.capability_index[capability]:
                    scores[agent_id] += 1

        # Normalize scores
        max_score = len(required_capabilities)
        scored_agents = [
            (agent_id, score / max_score)
            for agent_id, score in scores.items()
        ]

        # Sort by score descending
        scored_agents.sort(key=lambda x: x[1], reverse=True)

        return scored_agents[:limit]

    async def find_agent_by_type(self, agent_type: str) -> Optional[str]:
        """Find an agent by its type name"""
        for agent_id, agent in self.agents.items():
            if agent.capability.agent_name == agent_type:
                return agent_id
        return None

    async def find_agent_by_capability(self, capability: str) -> Optional[str]:
        """Find first agent with a specific capability"""
        if capability in self.capability_index:
            agents = self.capability_index[capability]
            if agents:
                return agents[0]
        return None

    # ============================================
    # Error Handling
    # ============================================

    def _handle_failed_delivery(self, message: A2AMessage, reason: str):
        """Handle failed message delivery"""
        message.mark_failed(reason)
        self.stats["messages_failed"] += 1
        self.stats["errors"] += 1

        self._log("FAILED", f"Message {message.message_id}: {reason}")

    # ============================================
    # System Management
    # ============================================

    async def start(self):
        """Start the communication bus"""
        self.is_running = True
        self._log("SYSTEM", "Communication Bus started")
        self._log("SYSTEM", f"Registered agents: {len(self.agents)}")

        # Print agent summary
        for agent_id, agent in self.agents.items():
            caps = ", ".join(agent.capability.capabilities)
            self._log("AGENT", f"  {agent.capability.agent_name} ({agent_id}): {caps}")

    async def stop(self):
        """Stop the communication bus"""
        self.is_running = False

        # Send shutdown to all agents
        shutdown_msg = A2AMessage(
            message_type=MessageType.SHUTDOWN,
            sender_id="communication_bus",
            sender_type="infrastructure"
        )
        await self._handle_broadcast(shutdown_msg)

        self._log("SYSTEM", "Communication Bus stopped")

    async def get_status(self) -> Dict:
        """Get current status of the bus"""
        return {
            "is_running": self.is_running,
            "registered_agents": len(self.agents),
            "pending_messages": len(self.pending_messages),
            "capability_index_size": len(self.capability_index),
            "stats": self.stats,
            "agents": [
                {
                    "id": agent_id,
                    "type": agent.capability.agent_name,
                    "capabilities": agent.capability.capabilities,
                    "state": agent.state.value if hasattr(agent, 'state') else "unknown"
                }
                for agent_id, agent in self.agents.items()
            ]
        }

    def print_status(self):
        """Pretty print the bus status"""
        status = asyncio.get_event_loop().run_until_complete(self.get_status())

        print("\n" + "=" * 60)
        print("COMMUNICATION BUS STATUS")
        print("=" * 60)
        print(f"Running: {status['is_running']}")
        print(f"Registered Agents: {status['registered_agents']}")
        print(f"Pending Messages: {status['pending_messages']}")
        print(f"Indexed Capabilities: {status['capability_index_size']}")
        print("\nStatistics:")
        for key, value in status['stats'].items():
            print(f"  {key}: {value}")
        print("\nAgents:")
        for agent in status['agents']:
            caps = ", ".join(agent['capabilities'])
            print(f"  [{agent['state']}] {agent['type']} ({agent['id']})")
            print(f"    └─ {caps}")
        print("=" * 60 + "\n")

    # ============================================
    # Logging
    # ============================================

    def _log(self, category: str, message: str):
        """Internal logging"""
        timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        print(f"[{timestamp}] [BUS] [{category}] {message}")

        self.delivery_log.append({
            "timestamp": timestamp,
            "category": category,
            "message": message
        })
