"""Simple test — calls your MCP server from Python."""
import asyncio
from mcp.client.stdio import stdio_client
from mcp import ClientSession, StdioServerParameters

async def main():
    params = StdioServerParameters(
        command="python",
        args=["mcp_server_deprecated.py"],
        cwd="D:/python_tasks/log_analysis_multi_agent"
    )

    print("Connecting to MCP server...")
    async with stdio_client(params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()

            # 1. List all available tools (agents)
            tools = await session.list_tools()
            print(f"\nAvailable tools ({len(tools.tools)}):")
            for tool in tools.tools:
                print(f"  • {tool.name}")

            # 2. Test the orchestrator (full pipeline)
            print("\n--- Testing orchestrator_analyze ---")
            result = await session.call_tool("orchestrator_analyze", {
                "query": "memory_store/logs/error.log"
            })
            print(f"Response ({len(result.content[0].text)} chars):")
            print(result.content[0].text[:1000])
            print("...")

            # 3. Test individual extractor
            print("\n--- Testing extractor_extract ---")
            result = await session.call_tool("extractor_extract", {
                "source_type": "file",
                "file_path": "memory_store/logs/app.json"
            })
            print(f"Response ({len(result.content[0].text)} chars):")
            print(result.content[0].text[:500])

asyncio.run(main())
