import os
from dotenv import load_dotenv
load_dotenv()
from elasticsearch import Elasticsearch

api_key = os.getenv('ELASTICSEARCH_API_KEY')

# Try with the direct endpoint URL (get this from your deployment page)
# It looks like: https://my-deployment.es.us-east-1.aws.elastic.cloud:443
es_url = input("Enter your Elasticsearch endpoint URL: ").strip()

try:
    es = Elasticsearch(
        hosts=[es_url],
        api_key=api_key,
        request_timeout=10
    )
    ping = es.ping()
    print(f'Ping result: {ping}')
    if ping:
        info = es.info()
        print(f'Cluster: {info.get("cluster_name")}, Version: {info.get("version", {}).get("number")}')
except Exception as e:
    print(f'Connection failed: {e}')
