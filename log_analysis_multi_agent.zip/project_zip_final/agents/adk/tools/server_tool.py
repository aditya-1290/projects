# adk/tools/server_tool.py
import requests

def call_adk_server(query: str) -> str:
    """
    Call external adk_server API for full pipeline execution.
    """
    print("Tool Called: call_adk_server")
    print("[ADK WEB] query:", query)
    try:
        res = requests.post(
            "http://127.0.0.1:9000/run",
            json={"query": query}
        )

        print("[ADK WEB] Server status:", res.status_code)
        print("[ADK WEB] Server response:", res.text[:500])


        return res.json().get("response", "No response")

    except Exception as e:
        print("[ADK WEB] Server call failed:", e)
        return f"ERROR: Failed to call adk_server: {str(e)}"



