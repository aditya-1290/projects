"""Critic Tools — Validate solution quality and safety."""
import httpx
from google.adk.tools.base_tool import ToolContext

API_BASE = "http://127.0.0.1:8000"


async def _post(endpoint: str, data: dict, timeout: int = 1200) -> dict:
    async with httpx.AsyncClient(timeout=timeout) as client:
        response = await client.post(f"{API_BASE}{endpoint}", json=data)
        return response.json() if response.status_code == 200 else {"error": response.text}


async def validate_solution(
        solution: str,
        original_logs: str = "",
        tool_context: ToolContext = None,
) -> str:
    """
    Validate a proposed solution for factual consistency, logical coherence,
    completeness, safety, and hallucinations.

    Args:
        solution: The proposed solution to validate
        original_logs: Original log content for evidence checking
    """
    if tool_context: tool_context.state["status"] = "validating"
    async with httpx.AsyncClient(timeout=1200) as client:
        response = await client.post(f"{API_BASE}/agent/critic", json={
            "action": "validate", "solution": solution, "original_logs": original_logs
        })
        data = response.json() if response.status_code == 200 else {"error": response.text}
        return data.get("response", str(data))
