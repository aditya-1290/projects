"""
ADK Root Agent — Entry point for the Log Analysis Multi-Agent System.
Uses Gemma GGUF as the router model with parser bridge for tool execution.
"""
import sys
import os

# ═══════════════════════════════════════════════════════════
# PATCH: Fix LiteLLMClient serialization bug in ADK 1.31.1
# ═══════════════════════════════════════════════════════════
import pydantic

_original_dump = pydantic.TypeAdapter.dump_json

def _patched_dump(self, obj, **kwargs):
    from google.adk.models.lite_llm import LiteLLMClient as LLC
    def _fix(v):
        if isinstance(v, LLC): return str(v)
        if isinstance(v, dict): return {kk: _fix(vv) for kk, vv in v.items()}
        if isinstance(v, list): return [_fix(vv) for vv in v]
        return v
    return _original_dump(self, _fix(obj), **kwargs)

pydantic.TypeAdapter.dump_json = _patched_dump
print("[ADK PATCH] Pydantic serialization patched for LiteLLMClient")

# ═══════════════════════════════════════════════════════════
# Imports
# ═══════════════════════════════════════════════════════════
from google.adk.agents import LlmAgent
from google.adk.models import LiteLlm
from google.adk.tools.base_tool import BaseTool, ToolContext

from agents.adk.server import start_model_server, get_model_url
from agents.adk.tool_parser import parse_tool_call, execute_parsed_tool, format_tool_response

# All 18 tools
from agents.adk.tools.pipeline_tool import full_pipeline, natural_language_query, compare_logs
from agents.adk.tools.extractor_tools import extract_file, extract_text, run_terminal, ocr_image
from agents.adk.tools.preprocessor_tool import preprocess_logs, filter_logs
from agents.adk.tools.analyzer_tool import analyze_logs
from agents.adk.tools.solver_tool import solve_error, explain_error, summarize_logs
from agents.adk.tools.debugger_tool import debug_trace
from agents.adk.tools.critic_tool import validate_solution
from agents.adk.tools.memory_tool import search_memory, store_analysis, trend_analysis
from agents.adk.tools import ALL_TOOLS
from agents.adk.instructions import ORCHESTRATOR_INSTRUCTION
# from google.genai.types import GenerationConfig

# ═══════════════════════════════════════════════════════════
# Model Server
# ═══════════════════════════════════════════════════════════
start_model_server()

# ═══════════════════════════════════════════════════════════
# Tool Wrapper
# ═══════════════════════════════════════════════════════════
def make_tool(fn):
    import inspect
    sig = inspect.signature(fn)
    params = list(sig.parameters.keys())
    user_params = [p for p in params if p != 'tool_context']

    class SimpleTool(BaseTool):
        def __init__(self, func):
            super().__init__(name=func.__name__, description=func.__doc__ or "")
            self._func = func
            self._user_params = user_params

        async def run_async(self, *, args: dict, tool_context: ToolContext) -> str:
            filtered = {k: v for k, v in args.items() if k in self._user_params}
            return await self._func(tool_context=tool_context, **filtered)

    return SimpleTool(fn)

all_tools = [make_tool(f) for f in [
    extract_file, extract_text, run_terminal, ocr_image,
    preprocess_logs, filter_logs,
    analyze_logs,
    solve_error, explain_error, summarize_logs,
    debug_trace,
    validate_solution,
    search_memory, store_analysis, trend_analysis,
    full_pipeline, natural_language_query, compare_logs,
]]

# Build tools map for parser bridge
# Register MCP tools for Elasticsearch
try:
    from agents.adk.tools.es_mcp_tools import register_es_mcp_tools
    es_tools = register_es_mcp_tools()
    all_tools.extend(es_tools)
    print(f"[ADK BRIDGE] Registered {len(es_tools)} Elasticsearch MCP tools")
except ImportError:
    print("[ADK BRIDGE] ES MCP tools not available")

# Build tools map for parser bridge
_tools_map = {t.name: t._func for t in all_tools if hasattr(t, '_func')}
print(f"[ADK BRIDGE] Registered {len(_tools_map)} tools for parser bridge")

# ═══════════════════════════════════════════════════════════
# ADK Agent
# ═══════════════════════════════════════════════════════════
root_agent = LlmAgent(
    name="log_analysis_orchestrator",
    description=(
        "Multi-agent log analysis system powered by local Gemma model. "
        "Analyze logs from files, images, terminal output, or pasted text. "
        "Provides root cause analysis, fix suggestions, code patches, "
        "summaries, comparisons, and trend analysis."
    ),
    model=LiteLlm(
        model="openai/gemma-4-e4b-it",
        api_base="http://127.0.0.1:8083/v1",
        api_key="not-needed",
        max_tokens=2048,
    ),
    instruction="""You are a tool router. NEVER chat. ALWAYS call a tool.

    RULES:
    - File path → call full_pipeline with the path
    - Pasted logs/errors/tracebacks → call full_pipeline with the content
    - "es:" query → call es_search_mcp
    - "hello"/"hi" only → reply: "Send me a log file or paste logs."
    - EVERYTHING else → call full_pipeline

    TOOLS:
    full_pipeline, extract_file, preprocess_logs, analyze_logs, solve_error, debug_trace, natural_language_query, es_search_mcp, es_list_indices_mcp, es_health_mcp

    EXAMPLES:
    User: "D:/logs/error.log"
    <|tool_call>call:full_pipeline{query:<|"|>D:/logs/error.log<|"|>}<tool_call|>

    User: "es: ERROR from yesterday"
    <|tool_call>call:es_search_mcp{query:<|"|>ERROR from yesterday<|"|>}<tool_call|>

    User: "hi"
    Send me a log file or paste logs.

    NEVER explain. NEVER ask questions. JUST CALL THE TOOL.
    """,
    tools=all_tools,
    # generation_config=GenerationConfig(
    #     temperature=0.7,
    #     max_output_tokens=8192,  # allows full reports
    # ),
)

# ═══════════════════════════════════════════════════════════
# PARSER BRIDGE: Intercept Gemma's text tool calls
# ═══════════════════════════════════════════════════════════
from google.adk.agents.llm_agent import LlmAgent as _LlmAgent
_original_run = _LlmAgent._run_async_impl

async def _patched_run_async_impl(self, ctx):
    """Intercept text responses, parse tool calls, execute them manually."""
    async for event in _original_run(self, ctx):
        # Check if event has text content with a tool call
        if hasattr(event, 'content') and event.content:
            parts = getattr(event.content, 'parts', [])
            for part in parts:
                text = getattr(part, 'text', '')
                if text:
                    parsed = parse_tool_call(text)
                    if parsed:
                        print(f"[ADK BRIDGE] Detected tool call: {parsed['tool_name']}")
                        result = await execute_parsed_tool(parsed, _tools_map)
                        if result:
                            # Replace the text with the tool result
                            from google.genai.types import Content, Part
                            tool_response = format_tool_response(parsed['tool_name'], result)
                            event.content = Content(
                                role="user",
                                parts=[Part(text=tool_response)]
                            )
                            yield event
                            break
                else:
                    yield event
                    break
            else:
                yield event
        else:
            yield event

_LlmAgent._run_async_impl = _patched_run_async_impl
print("[ADK BRIDGE] Parser bridge activated — intercepting Gemma tool calls")

