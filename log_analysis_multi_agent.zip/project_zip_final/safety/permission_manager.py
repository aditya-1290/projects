"""
Permission Manager - Controls user approval for sensitive operations
"""

from typing import Dict, List, Optional, Callable
from datetime import datetime


class PermissionManager:
    """Manages user approval for potentially dangerous operations"""

    # Operations requiring user approval
    APPROVAL_REQUIRED = [
        "file_write",
        "file_delete",
        "file_modify",
        "service_restart",
        "service_stop",
        "config_change",
        "database_write",
        "database_delete",
        "network_change",
        "code_patch_apply",
    ]

    # Callback for user approval prompts
    _approval_callback: Optional[Callable] = None

    @classmethod
    def set_approval_callback(cls, callback: Callable):
        """Set the function called to request user approval"""
        cls._approval_callback = callback

    @classmethod
    def requires_approval(cls, operation_type: str) -> bool:
        """Check if an operation type requires user approval"""
        return operation_type in cls.APPROVAL_REQUIRED

    @classmethod
    async def request_approval(
            cls,
            operation: str,
            details: str = "",
            risk_level: str = "MEDIUM"
    ) -> bool:
        """
        Request user approval for an operation.

        Args:
            operation: Description of the operation
            details: Additional details about what will happen
            risk_level: LOW, MEDIUM, HIGH, CRITICAL

        Returns:
            True if approved, False if denied
        """
        risk_emoji = {
            "LOW": "🟢",
            "MEDIUM": "🟡",
            "HIGH": "🟠",
            "CRITICAL": "🔴"
        }

        emoji = risk_emoji.get(risk_level, "⚪")

        print(f"""
{emoji} PERMISSION REQUIRED [{risk_level} RISK]
{'─' * 50}
Operation: {operation}
{details}
{'─' * 50}
""")

        if cls._approval_callback:
            return await cls._approval_callback(operation, details, risk_level)

        # Default: CLI prompt
        while True:
            response = input("Approve this operation? (y/n): ").lower().strip()
            if response in ['y', 'yes']:
                return True
            elif response in ['n', 'no']:
                return False
            print("Please answer 'y' or 'n'")

    @classmethod
    def log_approval(
            cls,
            operation: str,
            approved: bool,
            user: str = "cli_user"
    ):
        """Log an approval decision"""
        from safety.audit_logger import AuditLogger
        AuditLogger.log(
            event_type="permission_check",
            details={
                "operation": operation,
                "approved": approved,
                "user": user,
                "timestamp": datetime.now().isoformat()
            }
        )


class OperationRisk:
    """Risk assessment for operations"""

    RISK_LEVELS = {
        "file_read": "LOW",
        "file_list": "LOW",
        "system_info": "LOW",
        "log_read": "LOW",
        "network_diag": "LOW",
        "file_write": "MEDIUM",
        "config_change": "MEDIUM",
        "service_restart": "MEDIUM",
        "code_patch_apply": "MEDIUM",
        "file_delete": "HIGH",
        "database_write": "HIGH",
        "service_stop": "HIGH",
        "network_change": "HIGH",
        "database_delete": "CRITICAL",
    }

    @classmethod
    def get_risk_level(cls, operation_type: str) -> str:
        """Get risk level for an operation type"""
        return cls.RISK_LEVELS.get(operation_type, "MEDIUM")