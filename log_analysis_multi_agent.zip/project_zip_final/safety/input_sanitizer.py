"""
Input Sanitizer - Sanitizes user inputs for safety
"""

import re
from typing import Tuple


class InputSanitizer:
    """Sanitizes all user inputs before processing"""

    # Maximum input sizes
    MAX_QUERY_LENGTH = 10000
    MAX_FILE_PATH_LENGTH = 500
    MAX_LOG_PASTE_LENGTH = 50000

    # Patterns to detect
    SQL_INJECTION_PATTERNS = [
        re.compile(r'(?i)(\bSELECT\b.*\bFROM\b)|(\bDROP\b\s+\bTABLE\b)|(\bDELETE\b\s+\bFROM\b)'),
        re.compile(r'(?i)(\bINSERT\b\s+\bINTO\b)|(\bUPDATE\b\s+\bSET\b)'),
        re.compile(r'(?i)(\bUNION\b\s+\bSELECT\b)|(\bEXEC\b\s*\()'),
    ]

    COMMAND_INJECTION_PATTERNS = [
        re.compile(r'[;&|`$]'),
        re.compile(r'\$\(.*\)'),
        re.compile(r'`.*`'),
    ]

    PATH_TRAVERSAL_PATTERNS = [
        re.compile(r'\.\./'),
        re.compile(r'\.\.\\'),
        re.compile(r'~'),
    ]

    @classmethod
    def sanitize_query(cls, query: str) -> Tuple[str, bool, str]:
        """
        Sanitize a user query.

        Returns:
            (sanitized_query, is_safe, warning_message)
        """
        if not query:
            return query, True, ""

        warnings = []

        # Check length
        if len(query) > cls.MAX_QUERY_LENGTH:
            query = query[:cls.MAX_QUERY_LENGTH]
            warnings.append(f"Query truncated to {cls.MAX_QUERY_LENGTH} characters")

        # Check for SQL injection
        for pattern in cls.SQL_INJECTION_PATTERNS:
            if pattern.search(query):
                warnings.append("Potential SQL injection patterns detected - these will be ignored")

        # Check for command injection
        for pattern in cls.COMMAND_INJECTION_PATTERNS:
            if pattern.search(query):
                warnings.append("Command injection characters detected - these will be sanitized")
                query = re.sub(r'[;&|`$]', '', query)

        is_safe = len(warnings) == 0 or all("will be" in w for w in warnings)
        warning_msg = "; ".join(warnings) if warnings else ""

        return query, is_safe, warning_msg

    @classmethod
    def sanitize_file_path(cls, path: str) -> Tuple[str, bool, str]:
        """
        Sanitize a file path.

        Returns:
            (sanitized_path, is_safe, warning_message)
        """
        if not path:
            return path, True, ""

        warnings = []

        # Check length
        if len(path) > cls.MAX_FILE_PATH_LENGTH:
            return path, False, "File path too long"

        # Check for path traversal
        for pattern in cls.PATH_TRAVERSAL_PATTERNS:
            if pattern.search(path):
                warnings.append("Path traversal detected - sanitizing")
                path = re.sub(r'\.\./', '', path)
                path = re.sub(r'\.\.\\', '', path)

        # Remove command injection characters
        path = re.sub(r'[;&|`$]', '', path)

        is_safe = len(warnings) == 0
        warning_msg = "; ".join(warnings) if warnings else ""

        return path, is_safe, warning_msg

    @classmethod
    def sanitize_log_content(cls, content: str) -> Tuple[str, bool, str]:
        """
        Sanitize pasted log content.

        Returns:
            (sanitized_content, is_safe, warning_message)
        """
        if not content:
            return content, True, ""

        warnings = []

        # Check length
        if len(content) > cls.MAX_LOG_PASTE_LENGTH:
            content = content[:cls.MAX_LOG_PASTE_LENGTH]
            warnings.append(f"Log content truncated to {cls.MAX_LOG_PASTE_LENGTH} characters")

        # Strip null bytes
        if '\x00' in content:
            content = content.replace('\x00', '')
            warnings.append("Null bytes removed from content")

        is_safe = True
        warning_msg = "; ".join(warnings) if warnings else ""

        return content, is_safe, warning_msg