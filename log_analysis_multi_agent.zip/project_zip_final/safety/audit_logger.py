"""
Audit Logger - Tracks all security-relevant operations
"""

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional


class AuditLogger:
    """Logs all security-relevant operations for audit trail"""

    _log_file: Optional[Path] = None
    _enabled: bool = True

    @classmethod
    def initialize(cls, log_dir: str = "memory_store/logs"):
        """Initialize the audit logger"""
        cls._log_file = Path(log_dir) / "audit.log"
        cls._log_file.parent.mkdir(parents=True, exist_ok=True)

        cls.log(
            event_type="audit_system_start",
            details={"message": "Audit logging initialized"}
        )

    @classmethod
    def log(
            cls,
            event_type: str,
            details: Dict[str, Any],
            severity: str = "INFO"
    ):
        """
        Log an audit event.

        Args:
            event_type: Type of event (e.g., 'permission_check', 'command_executed')
            details: Event details
            severity: INFO, WARNING, ERROR, CRITICAL
        """
        if not cls._enabled:
            return

        entry = {
            "timestamp": datetime.now().isoformat(),
            "event_type": event_type,
            "severity": severity,
            "details": details
        }

        # Always print to console for visibility
        emoji = {"INFO": "ℹ️", "WARNING": "⚠️", "ERROR": "❌", "CRITICAL": "🔴"}
        print(f"{emoji.get(severity, '📝')} [AUDIT] [{event_type}] {details.get('message', '')}")

        # Write to file if available
        if cls._log_file:
            try:
                with open(cls._log_file, 'a') as f:
                    f.write(json.dumps(entry) + '\n')
            except Exception:
                pass

    @classmethod
    def log_command_execution(cls, command: str, approved: bool, result: str = ""):
        """Log a command execution"""
        cls.log(
            event_type="command_execution",
            details={
                "command": command[:200],
                "approved": approved,
                "result": result[:200] if result else "N/A"
            },
            severity="WARNING" if not approved else "INFO"
        )

    @classmethod
    def log_permission_denied(cls, operation: str, reason: str):
        """Log a permission denial"""
        cls.log(
            event_type="permission_denied",
            details={
                "operation": operation,
                "reason": reason
            },
            severity="WARNING"
        )

    @classmethod
    def log_safety_violation(cls, violation_type: str, details: str):
        """Log a safety violation"""
        cls.log(
            event_type="safety_violation",
            details={
                "violation_type": violation_type,
                "details": details
            },
            severity="ERROR"
        )

    @classmethod
    def get_recent_events(cls, limit: int = 50) -> list:
        """Get recent audit events"""
        if not cls._log_file or not cls._log_file.exists():
            return []

        events = []
        try:
            with open(cls._log_file, 'r') as f:
                lines = f.readlines()

            for line in lines[-limit:]:
                try:
                    events.append(json.loads(line.strip()))
                except json.JSONDecodeError:
                    continue
        except Exception:
            pass

        return events
