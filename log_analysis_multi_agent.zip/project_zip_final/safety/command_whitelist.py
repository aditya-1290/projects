"""
Command Whitelist - Controls which terminal commands are allowed
"""

import re
from typing import List, Dict, Optional


class CommandWhitelist:
    """
    Whitelist system for terminal commands.
    Only explicitly allowed commands can be executed.
    """

    # Allowed commands with their safe parameter patterns
    ALLOWED_COMMANDS = {
        # File reading
        "cat": {"args_pattern": r'^[\w\.\-_/]+$', "description": "Read file contents"},
        "head": {"args_pattern": r'^[\w\.\-_/\s\-n\d]+$', "description": "Read first lines of file"},
        "tail": {"args_pattern": r'^[\w\.\-_/\s\-n\d]+$', "description": "Read last lines of file"},
        "less": {"args_pattern": r'^[\w\.\-_/]+$', "description": "View file (read-only)"},

        # File listing
        "ls": {"args_pattern": r'^[\w\.\-_/\s\-lahtr]*$', "description": "List directory contents"},
        "find": {"args_pattern": r'^[\w\.\-_/\s\-name\s\"\w+\"]*$', "description": "Find files by name"},

        # System information (read-only)
        "df": {"args_pattern": r'^[\s\-h]*$', "description": "Disk space usage"},
        "du": {"args_pattern": r'^[\w\.\-_/\s\-sh]*$', "description": "Directory size"},
        "free": {"args_pattern": r'^[\s\-h]*$', "description": "Memory usage"},
        "ps": {"args_pattern": r'^[\s\-aux]*$', "description": "Process list"},
        "top": {"args_pattern": r'^[\s\-bn1]*$', "description": "Process monitor (one iteration)"},
        "netstat": {"args_pattern": r'^[\s\-tulpn]*$', "description": "Network statistics"},
        "ss": {"args_pattern": r'^[\s\-tulpn]*$', "description": "Socket statistics"},
        "lsof": {"args_pattern": r'^[\w\.\-_/\s\-i]*$', "description": "List open files"},

        # Process management (limited)
        "systemctl": {
            "args_pattern": r'^(status|is-active|is-enabled|list-units)\s+[\w\.\-_]+$',
            "description": "Service status (read-only)"
        },
        "journalctl": {
            "args_pattern": r'^[\s\-u\-n\d\-f\-r\-b]*$',
            "description": "Journal logs (read-only)"
        },

        # Network diagnostics
        "ping": {"args_pattern": r'^[\s\-c\d]+\s+[\w\.\-_]+$', "description": "Network connectivity test"},
        "traceroute": {"args_pattern": r'^[\w\.\-_]+$', "description": "Trace network route"},
        "nslookup": {"args_pattern": r'^[\w\.\-_]+$', "description": "DNS lookup"},
        "dig": {"args_pattern": r'^[\w\.\-_]+$', "description": "DNS query"},
        "curl": {"args_pattern": r'^[\s\-sIXGET]+\s+[\w\.\-_/:]+$', "description": "HTTP request (GET/HEAD only)"},

        # Text processing (read operations)
        "grep": {"args_pattern": r'^[\w\.\-_/\s\-inrv]*$', "description": "Search text"},
        "wc": {"args_pattern": r'^[\s\-lwc]+\s+[\w\.\-_/]+$', "description": "Count lines/words"},
        "sort": {"args_pattern": r'^[\w\.\-_/]+$', "description": "Sort output"},
        "uniq": {"args_pattern": r'^[\s\-cd]+\s+[\w\.\-_/]+$', "description": "Unique lines"},
    }

    # Explicitly blocked commands (even if they match patterns)
    BLOCKED_COMMANDS = [
        "rm", "mv", "cp", "dd", "mkfs", "fdisk",
        "kill", "pkill", "killall",
        "shutdown", "reboot", "halt", "poweroff",
        "chmod", "chown", "chgrp",
        "sudo", "su",
        "wget", "nc", "telnet",
        "iptables", "ufw", "firewall-cmd",
    ]

    @classmethod
    def is_allowed(cls, command: str) -> tuple[bool, str]:
        """
        Check if a command is allowed.

        Args:
            command: Full command string

        Returns:
            (is_allowed, reason)
        """
        if not command or not command.strip():
            return False, "Empty command"

        # Extract command name
        parts = command.strip().split()
        cmd_name = parts[0].lower()

        # Check if command is in allowed list
        if cmd_name not in cls.ALLOWED_COMMANDS:
            if cmd_name in cls.BLOCKED_COMMANDS:
                return False, f"Command '{cmd_name}' is explicitly blocked for safety"
            return False, f"Command '{cmd_name}' is not in the allowed list"

        # Get command config
        cmd_config = cls.ALLOWED_COMMANDS[cmd_name]

        # Check arguments
        args = ' '.join(parts[1:]) if len(parts) > 1 else ''
        args_pattern = cmd_config.get("args_pattern", "")

        if args_pattern and not re.match(args_pattern, args):
            return False, f"Arguments for '{cmd_name}' do not match allowed pattern"

        # Check for blocked subcommands in args
        for blocked in cls.BLOCKED_COMMANDS:
            if blocked in command.lower():
                return False, f"Command contains blocked operation: {blocked}"

        return True, f"Command '{cmd_name}' is allowed"

    @classmethod
    def get_allowed_commands(cls) -> List[Dict]:
        """Get list of all allowed commands with descriptions"""
        return [
            {
                "command": cmd,
                "description": config["description"] if isinstance(config, dict) else config
            }
            for cmd, config in cls.ALLOWED_COMMANDS.items()
        ]

    @classmethod
    def get_blocked_commands(cls) -> List[str]:
        """Get list of explicitly blocked commands"""
        return cls.BLOCKED_COMMANDS.copy()