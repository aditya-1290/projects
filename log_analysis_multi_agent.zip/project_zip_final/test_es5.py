import os
from dotenv import load_dotenv
load_dotenv()
from elasticsearch import Elasticsearch

api_key = os.getenv('ELASTICSEARCH_API_KEY')
es_url = "https://274d14877f1f4cfabf44b838f7b889d0.us-central1.gcp.cloud.es.io"

print(f'API Key length: {len(api_key) if api_key else 0}')
print(f'API Key first 10 chars: {api_key[:10] if api_key else "N/A"}...')

# API keys should be base64 encoded "id:api_key"
# Check if it contains a colon
if ':' in api_key:
    print('API Key format: id:api_key ?')
else:
    print('API Key format: single string (may be wrong format) ??')
    print('Elastic Cloud API keys should be in format: id:api_key')

# Try with just API key
try:
    es = Elasticsearch(
        hosts=[es_url],
        api_key=api_key,
        verify_certs=False,
        ssl_show_warn=False,
        request_timeout=30
    )
    # Try a simple request instead of ping
    try:
        info = es.info()
        print(f'Success! Cluster: {info.get("cluster_name")}')
    except Exception as e:
        print(f'Info failed: {e}')
except Exception as e:
    print(f'Connection failed: {e}')
