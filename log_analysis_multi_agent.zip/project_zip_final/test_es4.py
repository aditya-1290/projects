import os
from dotenv import load_dotenv
load_dotenv()
from elasticsearch import Elasticsearch

user = os.getenv('ELASTICSEARCH_USER', 'elastic')
password = os.getenv('ELASTICSEARCH_PASSWORD')
es_url = "https://274d14877f1f4cfabf44b838f7b889d0.us-central1.gcp.cloud.es.io"

print(f'User: {user}')
print(f'Password: {"SET" if password else "NOT SET"}')

# Try with basic auth (username/password)
try:
    es = Elasticsearch(
        hosts=[es_url],
        basic_auth=(user, password),
        verify_certs=False,
        ssl_show_warn=False,
        request_timeout=30
    )
    ping = es.ping()
    print(f'Ping result: {ping}')
    if ping:
        info = es.info()
        print(f'Cluster: {info.get("cluster_name")}, Version: {info.get("version", {}).get("number")}')
        # List indices
        indices = es.cat.indices(format="json")
        print(f'Indices: {len(indices)} found')
        for idx in indices[:5]:
            print(f'  - {idx.get("index")}')
except Exception as e:
    print(f'Connection failed: {e}')
