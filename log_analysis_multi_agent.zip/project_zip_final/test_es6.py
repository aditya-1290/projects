import os
from dotenv import load_dotenv
load_dotenv()
import sys
sys.path.insert(0, 'D:/python_tasks/log_analysis_multi_agent')
from agents.extractor.loaders.es_loader import ElasticsearchLoader

loader = ElasticsearchLoader(verify_certs=False)
print(f'Hosts: {loader.hosts}')
print(f'Cloud ID: {"SET" if loader.cloud_id else "NOT SET"}')
print(f'API Key: {"SET" if loader.api_key else "NOT SET"}')

available = loader.is_available()
print(f'is_available: {available}')

if available:
    indices = await loader.list_indices()
    print(f'Indices: {indices}')
else:
    print('ES not available � trying direct info call...')
    try:
        client = loader._create_client()
        info = client.info()
        print(f'Success! Cluster: {info.get("cluster_name")}')
    except Exception as e:
        print(f'Still failed: {e}')
