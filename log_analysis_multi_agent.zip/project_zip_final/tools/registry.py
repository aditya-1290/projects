"""
Tool Registry - Central registry for all tools
"""

from typing import Dict, Any, Optional, List
from tools.base_tool import BaseTool
from tools.file_tool import FileTool
from tools.terminal_tool import TerminalTool
from tools.ocr_tool import OCRTool
from tools.search_tool import SearchTool
from tools.code_analysis_tool import CodeAnalysisTool


class ToolRegistry:
    """Central registry for all MCP-compatible tools"""

    def __init__(self):
        self._tools: Dict[str, BaseTool] = {}
        self._initialize_default_tools()

    def _initialize_default_tools(self):
        """Register default tools"""
        default_tools = [
            FileTool(),
            TerminalTool(),
            OCRTool(),
            SearchTool(),
            CodeAnalysisTool(),
        ]

        for tool in default_tools:
            self.register(tool)

    def register(self, tool: BaseTool):
        """Register a tool"""
        if tool.name in self._tools:
            raise ValueError(f"Tool '{tool.name}' already registered")
        self._tools[tool.name] = tool

    def get(self, name: str) -> Optional[BaseTool]:
        """Get a tool by name"""
        return self._tools.get(name)

    def list_tools(self) -> List[str]:
        """List all registered tool names"""
        return list(self._tools.keys())

    def get_all_schemas(self) -> List[Dict]:
        """Get schemas for all tools"""
        return [tool.get_schema() for tool in self._tools.values()]

    def get_stats(self) -> Dict[str, Any]:
        """Get statistics for all tools"""
        return {
            name: tool.get_stats()
            for name, tool in self._tools.items()
        }

    async def execute(self, tool_name: str, **kwargs) -> Dict[str, Any]:
        """Execute a tool by name"""
        tool = self.get(tool_name)
        if not tool:
            return {"success": False, "error": f"Tool '{tool_name}' not found"}

        return await tool.execute(**kwargs)


# Global registry instance
_registry: Optional[ToolRegistry] = None


def get_registry() -> ToolRegistry:
    """Get the global tool registry"""
    global _registry
    if _registry is None:
        _registry = ToolRegistry()
    return _registry
