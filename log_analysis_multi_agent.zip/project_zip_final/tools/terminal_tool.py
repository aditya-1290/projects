"""
Terminal Tool - Safe terminal command execution
"""

import asyncio
from typing import Dict, Any
from tools.base_tool import BaseTool
from safety.command_whitelist import CommandWhitelist
from safety.audit_logger import AuditLogger


class TerminalTool(BaseTool):
    """Executes terminal commands safely with whitelist checks"""

    def __init__(self):
        super().__init__(
            name="terminal_exec",
            description="Execute safe terminal commands (whitelist-restricted)"
        )

    async def execute(self, **kwargs) -> Dict[str, Any]:
        """Execute a terminal command"""
        command = kwargs.get("command", "")
        timeout = kwargs.get("timeout", 30)

        if not command:
            return {"success": False, "error": "No command provided"}

        # Check whitelist
        allowed, reason = CommandWhitelist.is_allowed(command)
        if not allowed:
            AuditLogger.log_command_execution(command, False, reason)
            return {"success": False, "error": reason}

        self.call_count += 1

        # Execute
        try:
            process = await asyncio.create_subprocess_shell(
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )

            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(),
                    timeout=timeout
                )
            except asyncio.TimeoutError:
                process.kill()
                self.error_count += 1
                return {"success": False, "error": f"Command timed out after {timeout}s"}

            output = stdout.decode('utf-8', errors='replace')
            error_output = stderr.decode('utf-8', errors='replace')

            AuditLogger.log_command_execution(command, True, "Success")

            return {
                "success": True,
                "command": command,
                "output": output.strip(),
                "error_output": error_output.strip(),
                "exit_code": process.returncode
            }

        except Exception as e:
            self.error_count += 1
            AuditLogger.log_command_execution(command, True, str(e))
            return {"success": False, "error": str(e)}

    def _get_parameters(self) -> Dict:
        return {
            "command": {
                "type": "string",
                "description": "Shell command to execute (whitelist-restricted)"
            },
            "timeout": {
                "type": "integer",
                "description": "Timeout in seconds (default: 30)",
                "default": 30
            }
        }