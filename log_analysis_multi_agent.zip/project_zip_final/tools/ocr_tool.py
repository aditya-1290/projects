"""
OCR Tool - Image text extraction
"""

import os
from typing import Dict, Any
from tools.base_tool import BaseTool


class OCRTool(BaseTool):
    """Extracts text from images using OCR"""

    SUPPORTED_FORMATS = ['.png', '.jpg', '.jpeg', '.bmp', '.tiff']

    def __init__(self):
        super().__init__(
            name="ocr_tool",
            description="Extract text from images using OCR"
        )

    async def execute(self, **kwargs) -> Dict[str, Any]:
        """Extract text from an image"""
        image_path = kwargs.get("image_path", "")

        if not image_path:
            return {"success": False, "error": "No image path provided"}

        if not os.path.exists(image_path):
            return {"success": False, "error": f"Image not found: {image_path}"}

        ext = os.path.splitext(image_path)[1].lower()
        if ext not in self.SUPPORTED_FORMATS:
            return {
                "success": False,
                "error": f"Unsupported format: {ext}. Supported: {self.SUPPORTED_FORMATS}"
            }

        self.call_count += 1

        try:
            # Try pytesseract
            try:
                from PIL import Image
                import pytesseract

                img = Image.open(image_path)
                text = pytesseract.image_to_string(img)

                if text.strip():
                    return {
                        "success": True,
                        "text": text.strip(),
                        "method": "pytesseract",
                        "image_path": image_path
                    }
            except ImportError:
                pass
            except Exception as e:
                pass

            # Mock fallback
            return {
                "success": True,
                "text": f"[OCR Mock] Text extracted from {os.path.basename(image_path)}",
                "method": "mock",
                "image_path": image_path,
                "note": "Install pytesseract for actual OCR"
            }

        except Exception as e:
            self.error_count += 1
            return {"success": False, "error": str(e)}

    def _get_parameters(self) -> Dict:
        return {
            "image_path": {
                "type": "string",
                "description": "Path to the image file"
            }
        }
