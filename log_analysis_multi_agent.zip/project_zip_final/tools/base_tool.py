"""
Base Tool - Foundation class for all tools
"""

from typing import Dict, Any, Optional
from abc import ABC, abstractmethod


class BaseTool(ABC):
    """Base class for all tools in the system"""

    def __init__(self, name: str, description: str):
        self.name = name
        self.description = description
        self.call_count = 0
        self.error_count = 0

    @abstractmethod
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """Execute the tool with given parameters"""
        pass

    def get_schema(self) -> Dict:
        """Get the tool's parameter schema"""
        return {
            "name": self.name,
            "description": self.description,
            "parameters": self._get_parameters()
        }

    @abstractmethod
    def _get_parameters(self) -> Dict:
        """Get parameter definitions"""
        pass

    def validate_params(self, **kwargs) -> tuple[bool, Optional[str]]:
        """Validate parameters before execution"""
        return True, None

    def get_stats(self) -> Dict:
        """Get tool usage statistics"""
        return {
            "name": self.name,
            "calls": self.call_count,
            "errors": self.error_count,
            "success_rate": (
                    (self.call_count - self.error_count) / max(self.call_count, 1) * 100
            )
        }