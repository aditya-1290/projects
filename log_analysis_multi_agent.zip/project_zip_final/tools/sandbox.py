"""
Sandbox - Isolated execution environment
"""

import os
import tempfile
from typing import Dict, Any, Optional


class Sandbox:
    """
    Provides an isolated execution environment for untrusted operations.

    In production, this should use Docker or a similar container system.
    For development, it uses a temporary directory.
    """

    def __init__(self):
        self.temp_dir = None
        self.is_active = False

    async def create(self) -> str:
        """Create a sandbox environment"""
        self.temp_dir = tempfile.mkdtemp(prefix="log_agent_sandbox_")
        self.is_active = True
        return self.temp_dir

    async def execute(self, command: str, timeout: int = 30) -> Dict[str, Any]:
        """
        Execute a command in the sandbox.
        """
        if not self.is_active:
            return {"success": False, "error": "Sandbox not active"}

        import subprocess

        try:
            result = subprocess.run(
                command,
                shell=True,
                cwd=self.temp_dir,
                capture_output=True,
                text=True,
                timeout=timeout
            )

            return {
                "success": True,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "exit_code": result.returncode
            }

        except subprocess.TimeoutExpired:
            return {"success": False, "error": f"Command timed out after {timeout}s"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    async def cleanup(self):
        """Clean up the sandbox"""
        if self.temp_dir and os.path.exists(self.temp_dir):
            import shutil
            shutil.rmtree(self.temp_dir, ignore_errors=True)
        self.is_active = False
        self.temp_dir = None

    async def __aenter__(self):
        await self.create()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.cleanup()
