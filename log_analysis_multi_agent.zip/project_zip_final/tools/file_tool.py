"""
File Tool - Safe file operations for agents
"""

import os
from typing import Dict, Any
from tools.base_tool import BaseTool
from safety.permission_manager import PermissionManager
from safety.input_sanitizer import InputSanitizer


class FileTool(BaseTool):
    """Provides safe file read/write operations"""

    def __init__(self):
        super().__init__(
            name="file_reader",
            description="Read and write files safely with permission checks"
        )

    async def execute(self, **kwargs) -> Dict[str, Any]:
        """Execute file operation"""
        operation = kwargs.get("operation", "read")
        path = kwargs.get("path", "")

        # Sanitize path
        path, is_safe, warning = InputSanitizer.sanitize_file_path(path)
        if not is_safe:
            return {"success": False, "error": warning}

        if operation == "read":
            return await self._read_file(path)
        elif operation == "write":
            content = kwargs.get("content", "")
            return await self._write_file(path, content)
        elif operation == "list":
            return await self._list_directory(path)
        elif operation == "info":
            return await self._file_info(path)
        else:
            return {"success": False, "error": f"Unknown operation: {operation}"}

    async def _read_file(self, path: str) -> Dict[str, Any]:
        """Read a file"""
        self.call_count += 1

        try:
            if not os.path.exists(path):
                return {"success": False, "error": f"File not found: {path}"}

            if not os.path.isfile(path):
                return {"success": False, "error": f"Not a file: {path}"}

            # Size check
            size = os.path.getsize(path)
            if size > 100 * 1024 * 1024:  # 100MB
                return {"success": False, "error": f"File too large: {size} bytes"}

            with open(path, 'r', encoding='utf-8') as f:
                content = f.read()

            return {
                "success": True,
                "content": content,
                "size": size,
                "path": path
            }

        except UnicodeDecodeError:
            # Try other encodings
            for encoding in ['latin-1', 'cp1252']:
                try:
                    with open(path, 'r', encoding=encoding) as f:
                        content = f.read()
                    return {
                        "success": True,
                        "content": content,
                        "encoding": encoding,
                        "path": path
                    }
                except Exception:
                    continue

            self.error_count += 1
            return {"success": False, "error": "Cannot decode file"}

        except Exception as e:
            self.error_count += 1
            return {"success": False, "error": str(e)}

    async def _write_file(self, path: str, content: str) -> Dict[str, Any]:
        """Write to a file (requires permission)"""
        self.call_count += 1

        # Check permission
        if PermissionManager.requires_approval("file_write"):
            approved = await PermissionManager.request_approval(
                operation=f"Write to file: {path}",
                details=f"Content length: {len(content)} characters",
                risk_level="MEDIUM"
            )
            if not approved:
                return {"success": False, "error": "User denied write permission"}

        try:
            os.makedirs(os.path.dirname(path) or '.', exist_ok=True)

            with open(path, 'w', encoding='utf-8') as f:
                f.write(content)

            return {
                "success": True,
                "path": path,
                "bytes_written": len(content)
            }

        except Exception as e:
            self.error_count += 1
            return {"success": False, "error": str(e)}

    async def _list_directory(self, path: str) -> Dict[str, Any]:
        """List directory contents"""
        self.call_count += 1

        try:
            if not os.path.exists(path):
                return {"success": False, "error": f"Directory not found: {path}"}

            if not os.path.isdir(path):
                return {"success": False, "error": f"Not a directory: {path}"}

            items = []
            for item in os.listdir(path):
                item_path = os.path.join(path, item)
                items.append({
                    "name": item,
                    "type": "directory" if os.path.isdir(item_path) else "file",
                    "size": os.path.getsize(item_path) if os.path.isfile(item_path) else None
                })

            return {"success": True, "path": path, "items": items, "count": len(items)}

        except Exception as e:
            self.error_count += 1
            return {"success": False, "error": str(e)}

    async def _file_info(self, path: str) -> Dict[str, Any]:
        """Get file information"""
        try:
            if not os.path.exists(path):
                return {"success": False, "error": f"Not found: {path}"}

            stat = os.stat(path)

            return {
                "success": True,
                "path": path,
                "size": stat.st_size,
                "is_file": os.path.isfile(path),
                "is_directory": os.path.isdir(path),
                "modified": stat.st_mtime
            }

        except Exception as e:
            return {"success": False, "error": str(e)}

    def _get_parameters(self) -> Dict:
        return {
            "operation": {
                "type": "string",
                "enum": ["read", "write", "list", "info"],
                "description": "File operation to perform"
            },
            "path": {
                "type": "string",
                "description": "File or directory path"
            },
            "content": {
                "type": "string",
                "description": "Content to write (for write operation)"
            }
        }