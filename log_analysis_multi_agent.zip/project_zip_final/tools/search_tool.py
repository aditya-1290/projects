"""
Search Tool - Text search and pattern matching in logs
"""

import re
from typing import Dict, Any, List, Optional
from tools.base_tool import BaseTool


class SearchTool(BaseTool):
    """Searches within log content with various strategies"""

    def __init__(self):
        super().__init__(
            name="search_tool",
            description="Search for patterns, keywords, and regex in log content"
        )

    async def execute(self, **kwargs) -> Dict[str, Any]:
        """Execute search"""
        content = kwargs.get("content", "")
        query = kwargs.get("query", "")
        pattern = kwargs.get("pattern", "")
        search_type = kwargs.get("search_type", "keyword")  # keyword, regex, fuzzy
        case_sensitive = kwargs.get("case_sensitive", False)
        max_results = kwargs.get("max_results", 50)
        context_lines = kwargs.get("context_lines", 2)

        if not content:
            return {"success": False, "error": "No content provided"}

        if not query and not pattern:
            return {"success": False, "error": "No query or pattern provided"}

        self.call_count += 1

        try:
            search_pattern = pattern or re.escape(query)

            if search_type == "keyword":
                results = await self._keyword_search(
                    content, query, case_sensitive, max_results, context_lines
                )
            elif search_type == "regex":
                results = await self._regex_search(
                    content, search_pattern, case_sensitive, max_results, context_lines
                )
            elif search_type == "fuzzy":
                results = await self._fuzzy_search(
                    content, query, max_results, context_lines
                )
            else:
                results = await self._keyword_search(
                    content, query, case_sensitive, max_results, context_lines
                )

            return {
                "success": True,
                "search_type": search_type,
                "query": query or pattern,
                "total_matches": results["total"],
                "results": results["matches"],
                "truncated": results["total"] > max_results
            }

        except re.error as e:
            self.error_count += 1
            return {"success": False, "error": f"Invalid regex pattern: {e}"}
        except Exception as e:
            self.error_count += 1
            return {"success": False, "error": str(e)}

    async def _keyword_search(
            self, content: str, query: str, case_sensitive: bool,
            max_results: int, context_lines: int
    ) -> Dict:
        """Simple keyword search"""
        lines = content.split('\n')
        matches = []

        search_term = query if case_sensitive else query.lower()

        for i, line in enumerate(lines):
            line_to_check = line if case_sensitive else line.lower()

            if search_term in line_to_check:
                # Get context
                start = max(0, i - context_lines)
                end = min(len(lines), i + context_lines + 1)
                context = '\n'.join(lines[start:end])

                matches.append({
                    "line_number": i + 1,
                    "line": line.strip(),
                    "position": line_to_check.find(search_term),
                    "context": context
                })

                if len(matches) >= max_results:
                    break

        return {"total": len(matches), "matches": matches}

    async def _regex_search(
            self, content: str, pattern: str, case_sensitive: bool,
            max_results: int, context_lines: int
    ) -> Dict:
        """Regex pattern search"""
        flags = 0 if case_sensitive else re.IGNORECASE
        lines = content.split('\n')
        matches = []
        total = 0

        for i, line in enumerate(lines):
            found = list(re.finditer(pattern, line, flags))

            for match in found:
                total += 1

                if len(matches) < max_results:
                    start = max(0, i - context_lines)
                    end = min(len(lines), i + context_lines + 1)

                    matches.append({
                        "line_number": i + 1,
                        "match": match.group(),
                        "start": match.start(),
                        "end": match.end(),
                        "line": line.strip(),
                        "context": '\n'.join(lines[start:end])
                    })

        return {"total": total, "matches": matches}

    async def _fuzzy_search(
            self, content: str, query: str,
            max_results: int, context_lines: int
    ) -> Dict:
        """Simple fuzzy search (contains-based)"""
        # Basic fuzzy: split query into words and find lines containing most words
        query_words = query.lower().split()
        lines = content.split('\n')
        scored_lines = []

        for i, line in enumerate(lines):
            line_lower = line.lower()
            score = sum(1 for word in query_words if word in line_lower)

            if score > 0:
                scored_lines.append({
                    "line_number": i + 1,
                    "line": line.strip(),
                    "score": score / len(query_words),
                    "matching_words": [w for w in query_words if w in line_lower]
                })

        # Sort by score
        scored_lines.sort(key=lambda x: x["score"], reverse=True)

        # Add context to top results
        top_results = scored_lines[:max_results]
        for result in top_results:
            i = result["line_number"] - 1
            start = max(0, i - context_lines)
            end = min(len(lines), i + context_lines + 1)
            result["context"] = '\n'.join(lines[start:end])

        return {"total": len(scored_lines), "matches": top_results}

    def _get_parameters(self) -> Dict:
        return {
            "content": {
                "type": "string",
                "description": "Text content to search in"
            },
            "query": {
                "type": "string",
                "description": "Search query (keyword or pattern)"
            },
            "pattern": {
                "type": "string",
                "description": "Regex pattern (alternative to query)"
            },
            "search_type": {
                "type": "string",
                "enum": ["keyword", "regex", "fuzzy"],
                "description": "Type of search to perform",
                "default": "keyword"
            },
            "case_sensitive": {
                "type": "boolean",
                "description": "Case sensitive search",
                "default": False
            },
            "max_results": {
                "type": "integer",
                "description": "Maximum results to return",
                "default": 50
            },
            "context_lines": {
                "type": "integer",
                "description": "Number of context lines around match",
                "default": 2
            }
        }
    