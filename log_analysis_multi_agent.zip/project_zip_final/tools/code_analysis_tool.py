"""
Code Analysis Tool - Analyzes source code for debugging
"""

import re
from typing import Dict, Any, List
from tools.base_tool import BaseTool


class CodeAnalysisTool(BaseTool):
    """Analyzes source code for debugging purposes"""

    SUPPORTED_LANGUAGES = {
        '.py': 'python',
        '.java': 'java',
        '.js': 'javascript',
        '.ts': 'typescript',
        '.go': 'go',
        '.rs': 'rust',
        '.cpp': 'cpp',
        '.c': 'c',
        '.rb': 'ruby',
        '.php': 'php',
    }

    def __init__(self):
        super().__init__(
            name="code_analysis",
            description="Analyze source code for debugging"
        )

    async def execute(self, **kwargs) -> Dict[str, Any]:
        """Analyze source code"""
        action = kwargs.get("action", "analyze")
        code = kwargs.get("code", "")
        file_path = kwargs.get("file_path", "")

        if action == "extract_functions":
            return await self._extract_functions(code)
        elif action == "find_line":
            line_number = kwargs.get("line_number", 0)
            return await self._find_line_context(code, line_number)
        elif action == "detect_language":
            return await self._detect_language(file_path, code)
        else:
            return await self._analyze(code)

    async def _analyze(self, code: str) -> Dict[str, Any]:
        """General code analysis"""
        self.call_count += 1

        lines = code.split('\n')

        return {
            "success": True,
            "total_lines": len(lines),
            "total_characters": len(code),
            "functions": self._find_functions(code),
            "imports": self._find_imports(code),
            "classes": self._find_classes(code)
        }

    async def _extract_functions(self, code: str) -> Dict[str, Any]:
        """Extract function definitions"""
        self.call_count += 1
        return {
            "success": True,
            "functions": self._find_functions(code)
        }

    async def _find_line_context(self, code: str, line_number: int) -> Dict[str, Any]:
        """Get context around a specific line"""
        self.call_count += 1

        lines = code.split('\n')

        if line_number < 1 or line_number > len(lines):
            return {"success": False, "error": f"Line {line_number} out of range (1-{len(lines)})"}

        # Get 5 lines before and after
        start = max(0, line_number - 6)
        end = min(len(lines), line_number + 5)

        context = []
        for i in range(start, end):
            context.append({
                "line_number": i + 1,
                "is_target": i + 1 == line_number,
                "content": lines[i]
            })

        return {
            "success": True,
            "target_line": line_number,
            "target_content": lines[line_number - 1],
            "context": context
        }

    async def _detect_language(self, file_path: str, code: str) -> Dict[str, Any]:
        """Detect programming language"""
        if file_path:
            ext = '.' + file_path.split('.')[-1] if '.' in file_path else ''
            if ext in self.SUPPORTED_LANGUAGES:
                return {
                    "success": True,
                    "language": self.SUPPORTED_LANGUAGES[ext],
                    "detection_method": "file_extension"
                }

        # Simple detection from code
        if 'def ' in code and 'import ' in code:
            return {"success": True, "language": "python", "detection_method": "content"}
        elif 'public class' in code:
            return {"success": True, "language": "java", "detection_method": "content"}
        elif 'function ' in code and 'const ' in code:
            return {"success": True, "language": "javascript", "detection_method": "content"}

        return {"success": True, "language": "unknown", "detection_method": "none"}

    def _find_functions(self, code: str) -> List[Dict]:
        """Find function definitions"""
        patterns = [
            (re.compile(r'def\s+(\w+)\s*\(', re.MULTILINE), 'python'),
            (re.compile(r'(?:public|private|protected)?\s*(?:static)?\s*\w+\s+(\w+)\s*\(', re.MULTILINE), 'java'),
            (re.compile(r'function\s+(\w+)\s*\(', re.MULTILINE), 'javascript'),
            (re.compile(r'func\s+(\w+)\s*\(', re.MULTILINE), 'go'),
        ]

        functions = []
        for pattern, language in patterns:
            matches = pattern.finditer(code)
            for match in matches:
                line_num = code[:match.start()].count('\n') + 1
                functions.append({
                    "name": match.group(1),
                    "language": language,
                    "line": line_num
                })

        return functions

    def _find_imports(self, code: str) -> List[str]:
        """Find import statements"""
        imports = []
        for line in code.split('\n'):
            line = line.strip()
            if line.startswith(('import ', 'from ', 'require ', 'include ', '#include')):
                imports.append(line)
        return imports

    def _find_classes(self, code: str) -> List[Dict]:
        """Find class definitions"""
        pattern = re.compile(r'class\s+(\w+)', re.MULTILINE)
        classes = []
        for match in pattern.finditer(code):
            line_num = code[:match.start()].count('\n') + 1
            classes.append({
                "name": match.group(1),
                "line": line_num
            })
        return classes

    def _get_parameters(self) -> Dict:
        return {
            "action": {
                "type": "string",
                "enum": ["analyze", "extract_functions", "find_line", "detect_language"],
                "description": "Analysis action to perform"
            },
            "code": {
                "type": "string",
                "description": "Source code to analyze"
            },
            "file_path": {
                "type": "string",
                "description": "Optional file path for language detection"
            },
            "line_number": {
                "type": "integer",
                "description": "Line number for context lookup"
            }
        }
