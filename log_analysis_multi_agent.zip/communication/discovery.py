"""
Discovery - Agent capability discovery service
"""

from typing import Dict, List, Any, Optional
from communication.a2a_protocol import CapabilityQuery, CapabilityResponse


class DiscoveryService:
    """
    Handles agent capability discovery.

    Agents use this to find other agents that can handle specific tasks.
    """

    def __init__(self, capability_registry=None):
        self._registry = capability_registry
        self._discovery_cache: Dict[str, List[CapabilityResponse]] = {}
        self._cache_ttl = 30  # seconds

    async def discover(
            self,
            required_capabilities: List[str],
            optional_capabilities: List[str] = None,
            limit: int = 10
    ) -> List[CapabilityResponse]:
        """
        Discover agents with specific capabilities.

        Args:
            required_capabilities: Must-have capabilities
            optional_capabilities: Nice-to-have capabilities
            limit: Maximum results

        Returns:
            List of CapabilityResponse objects
        """
        optional_capabilities = optional_capabilities or []

        # Check cache
        cache_key = f"{','.join(sorted(required_capabilities))}|{','.join(sorted(optional_capabilities))}"
        if cache_key in self._discovery_cache:
            return self._discovery_cache[cache_key][:limit]

        responses = []

        if self._registry:
            # Find agents with all required capabilities
            agent_ids = self._registry.find_agents_with_all_capabilities(
                required_capabilities
            )

            for agent_id in agent_ids:
                agent_capabilities = self._registry.get_agent_capabilities(agent_id)

                # Calculate match score
                matching = set(required_capabilities) & set(agent_capabilities)
                optional_matching = set(optional_capabilities) & set(agent_capabilities)

                responses.append(CapabilityResponse(
                    agent_id=agent_id,
                    agent_type=self._registry.get_agent_metadata(agent_id, {}).get("type", "unknown"),
                    can_handle=len(matching) == len(required_capabilities),
                    partial_capability=len(matching) > 0 and len(matching) < len(required_capabilities),
                    matching_capabilities=list(matching),
                    missing_capabilities=list(set(required_capabilities) - matching),
                    confidence=len(matching) / len(required_capabilities) if required_capabilities else 1.0
                ))

        # Sort by confidence
        responses.sort(key=lambda r: r.confidence, reverse=True)

        # Cache results
        self._discovery_cache[cache_key] = responses

        return responses[:limit]

    def clear_cache(self):
        """Clear the discovery cache"""
        self._discovery_cache.clear()

    def get_stats(self) -> Dict:
        """Get discovery service statistics"""
        return {
            "cache_size": len(self._discovery_cache),
            "cache_ttl": self._cache_ttl
        }
    