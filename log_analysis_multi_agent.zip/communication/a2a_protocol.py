"""
Agent-to-Agent (A2A) Protocol

Defines the standard message format, types, and routing rules
for all inter-agent communication in the Log Analysis Multi-Agent System.

This is the SINGLE SOURCE OF TRUTH for how agents talk to each other.
"""

import uuid
from datetime import datetime
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from enum import Enum


# ============================================
# Message Type Enum
# ============================================

class MessageType(Enum):
    """All valid message types in the A2A protocol"""

    # Request-Response pattern
    REQUEST = "request"  # Agent requests another to do work
    RESPONSE = "response"  # Response to a request

    # Discovery pattern
    DISCOVERY = "discovery"  # "Who can handle this task?"
    CAPABILITY_QUERY = "capability_query"
    CAPABILITY_RESPONSE = "capability_response"

    # Pub-Sub pattern
    BROADCAST = "broadcast"  # Send to all agents
    SUBSCRIBE = "subscribe"  # Subscribe to message types
    UNSUBSCRIBE = "unsubscribe"  # Unsubscribe from message types

    # Error & Recovery
    ERROR = "error"  # Something went wrong
    RETRY = "retry"  # Please retry the last task
    HANDOFF = "handoff"  # Transfer task to another agent

    # Human-in-the-Loop
    HUMAN_INPUT_REQUEST = "human_input_request"
    HUMAN_INPUT_RESPONSE = "human_input_response"

    # System
    HEARTBEAT = "heartbeat"  # Are you alive?
    STATUS = "status"  # What's your status?
    SHUTDOWN = "shutdown"  # Prepare to shutdown


class MessagePriority(Enum):
    """Priority levels for message routing"""
    LOW = 1
    NORMAL = 2
    HIGH = 3
    CRITICAL = 4


class DeliveryStatus(Enum):
    """Status of message delivery"""
    PENDING = "pending"
    DELIVERED = "delivered"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    EXPIRED = "expired"
    REJECTED = "rejected"


# ============================================
# Core Message Data Class
# ============================================

@dataclass
class A2AMessage:
    """
    Standard A2A Message Envelope

    Every message in the system uses this format.
    Agents communicate ONLY through this message type.
    """

    # Identity
    message_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    correlation_id: Optional[str] = None  # For linking request-response pairs

    # Sender
    sender_id: str = ""
    sender_type: str = ""  # "extractor", "analyzer", "debugger", etc.

    # Target
    target_id: Optional[str] = None  # Specific agent ID (None = broadcast)
    target_type: Optional[str] = None  # Specific agent type (None = all types)

    # Content
    message_type: MessageType = MessageType.REQUEST
    priority: MessagePriority = MessagePriority.NORMAL

    # Payload
    task: Optional[Dict[str, Any]] = None  # What to do
    response: Optional[Dict[str, Any]] = None  # Result of task
    context: Dict[str, Any] = field(default_factory=dict)  # Shared context

    # Quality
    confidence: float = 1.0  # How confident (0.0 to 1.0)
    caveats: List[str] = field(default_factory=list)  # Warnings/notes

    # Human Interaction
    requires_human: bool = False
    human_question: Optional[str] = None

    # Error
    error: Optional[str] = None
    error_code: Optional[str] = None

    # Routing
    ttl: int = 10  # Time-to-live (max hops)
    max_retries: int = 3
    retry_count: int = 0
    route_history: List[str] = field(default_factory=list)  # Agents visited

    # Timing
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    expires_at: Optional[str] = None
    delivered_at: Optional[str] = None
    completed_at: Optional[str] = None

    # Status
    delivery_status: DeliveryStatus = DeliveryStatus.PENDING

    # ============================================
    # Serialization
    # ============================================

    def to_dict(self) -> Dict:
        """Convert to dictionary for JSON serialization"""
        return {
            "message_id": self.message_id,
            "correlation_id": self.correlation_id,
            "sender_id": self.sender_id,
            "sender_type": self.sender_type,
            "target_id": self.target_id,
            "target_type": self.target_type,
            "message_type": self.message_type.value,
            "priority": self.priority.value,
            "task": self.task,
            "response": self.response,
            "context": self.context,
            "confidence": self.confidence,
            "caveats": self.caveats,
            "requires_human": self.requires_human,
            "human_question": self.human_question,
            "error": self.error,
            "error_code": self.error_code,
            "ttl": self.ttl,
            "max_retries": self.max_retries,
            "retry_count": self.retry_count,
            "route_history": self.route_history,
            "created_at": self.created_at,
            "expires_at": self.expires_at,
            "delivery_status": self.delivery_status.value
        }

    @classmethod
    def from_dict(cls, data: Dict) -> "A2AMessage":
        """Create an A2AMessage from a dictionary"""
        msg = cls()

        # Identity
        msg.message_id = data.get("message_id", msg.message_id)
        msg.correlation_id = data.get("correlation_id")

        # Sender
        msg.sender_id = data.get("sender_id", "")
        msg.sender_type = data.get("sender_type", "")

        # Target
        msg.target_id = data.get("target_id")
        msg.target_type = data.get("target_type")

        # Content
        msg.message_type = MessageType(data.get("message_type", "request"))
        msg.priority = MessagePriority(data.get("priority", 2))

        # Payload
        msg.task = data.get("task")
        msg.response = data.get("response")
        msg.context = data.get("context", {})

        # Quality
        msg.confidence = data.get("confidence", 1.0)
        msg.caveats = data.get("caveats", [])

        # Human
        msg.requires_human = data.get("requires_human", False)
        msg.human_question = data.get("human_question")

        # Error
        msg.error = data.get("error")
        msg.error_code = data.get("error_code")

        # Routing
        msg.ttl = data.get("ttl", 10)
        msg.max_retries = data.get("max_retries", 3)
        msg.retry_count = data.get("retry_count", 0)
        msg.route_history = data.get("route_history", [])

        # Timing
        msg.created_at = data.get("created_at", msg.created_at)
        msg.expires_at = data.get("expires_at")
        msg.delivered_at = data.get("delivered_at")
        msg.completed_at = data.get("completed_at")

        # Status
        msg.delivery_status = DeliveryStatus(data.get("delivery_status", "pending"))

        return msg

    # ============================================
    # Factory Methods
    # ============================================

    @classmethod
    def create_request(
            cls,
            sender_id: str,
            sender_type: str,
            target_type: str,
            task: Dict,
            context: Dict = None,
            priority: MessagePriority = MessagePriority.NORMAL
    ) -> "A2AMessage":
        """Create a request message"""
        return cls(
            sender_id=sender_id,
            sender_type=sender_type,
            target_type=target_type,
            message_type=MessageType.REQUEST,
            task=task,
            context=context or {},
            priority=priority
        )

    @classmethod
    def create_response(
            cls,
            original_message: "A2AMessage",
            response_data: Dict,
            confidence: float = 1.0,
            caveats: List[str] = None
    ) -> "A2AMessage":
        """Create a response to a request"""
        return cls(
            sender_id=original_message.target_id or "",
            sender_type="",
            target_id=original_message.sender_id,
            message_type=MessageType.RESPONSE,
            correlation_id=original_message.message_id,
            response=response_data,
            confidence=confidence,
            caveats=caveats or [],
            context=original_message.context
        )

    @classmethod
    def create_error(
            cls,
            original_message: "A2AMessage",
            sender_id: str,
            sender_type: str,
            error: str,
            error_code: str = None
    ) -> "A2AMessage":
        """Create an error response"""
        return cls(
            sender_id=sender_id,
            sender_type=sender_type,
            target_id=original_message.sender_id,
            message_type=MessageType.ERROR,
            correlation_id=original_message.message_id,
            error=error,
            error_code=error_code,
            confidence=0.0
        )

    @classmethod
    def create_discovery(
            cls,
            sender_id: str,
            sender_type: str,
            required_capabilities: List[str],
            context: Dict = None
    ) -> "A2AMessage":
        """Create a discovery broadcast"""
        return cls(
            sender_id=sender_id,
            sender_type=sender_type,
            message_type=MessageType.DISCOVERY,
            task={
                "action": "discover",
                "required_capabilities": required_capabilities,
                "context": context or {}
            },
            priority=MessagePriority.HIGH
        )

    @classmethod
    def create_broadcast(
            cls,
            sender_id: str,
            sender_type: str,
            task: Dict
    ) -> "A2AMessage":
        """Create a broadcast to all agents"""
        return cls(
            sender_id=sender_id,
            sender_type=sender_type,
            message_type=MessageType.BROADCAST,
            task=task
        )

    @classmethod
    def create_human_request(
            cls,
            sender_id: str,
            sender_type: str,
            question: str,
            context: Dict = None
    ) -> "A2AMessage":
        """Create a human input request"""
        return cls(
            sender_id=sender_id,
            sender_type=sender_type,
            message_type=MessageType.HUMAN_INPUT_REQUEST,
            requires_human=True,
            human_question=question,
            context=context or {}
        )

    # ============================================
    # Utility Methods
    # ============================================

    def is_expired(self) -> bool:
        """Check if message has expired (based on TTL)"""
        return self.ttl <= 0

    def can_retry(self) -> bool:
        """Check if message can be retried"""
        return self.retry_count < self.max_retries

    def mark_delivered(self):
        """Mark message as delivered"""
        self.delivery_status = DeliveryStatus.DELIVERED
        self.delivered_at = datetime.now().isoformat()

    def mark_completed(self):
        """Mark message as completed"""
        self.delivery_status = DeliveryStatus.COMPLETED
        self.completed_at = datetime.now().isoformat()

    def mark_failed(self, error: str):
        """Mark message as failed"""
        self.delivery_status = DeliveryStatus.FAILED
        self.error = error

    def add_to_route(self, agent_id: str):
        """Add agent to route history"""
        self.route_history.append(agent_id)
        self.ttl -= 1

    def get_route_summary(self) -> str:
        """Get a human-readable route summary"""
        return " → ".join(self.route_history)

    def to_log_string(self) -> str:
        """Convert to a log-friendly string"""
        return (
            f"[{self.message_type.value.upper()}] "
            f"{self.sender_type}:{self.sender_id} → "
            f"{self.target_type or 'ALL'}:{self.target_id or 'broadcast'} "
            f"(conf:{self.confidence:.2f}, ttl:{self.ttl})"
        )


# ============================================
# Capability Discovery
# ============================================

@dataclass
class CapabilityQuery:
    """Query to discover agents with specific capabilities"""
    query_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    required_domain: Optional[str] = None
    required_capabilities: List[str] = field(default_factory=list)
    optional_capabilities: List[str] = field(default_factory=list)
    context: Dict[str, Any] = field(default_factory=dict)
    max_results: int = 10
    timeout_seconds: float = 5.0

    def to_dict(self) -> Dict:
        return {
            "query_id": self.query_id,
            "required_domain": self.required_domain,
            "required_capabilities": self.required_capabilities,
            "optional_capabilities": self.optional_capabilities,
            "context": self.context,
            "max_results": self.max_results,
            "timeout_seconds": self.timeout_seconds
        }


@dataclass
class CapabilityResponse:
    """Response from an agent about its capabilities"""
    agent_id: str
    agent_type: str
    can_handle: bool
    partial_capability: bool = False
    matching_capabilities: List[str] = field(default_factory=list)
    missing_capabilities: List[str] = field(default_factory=list)
    confidence: float = 1.0
    estimated_time_seconds: float = 0.0
    additional_info: str = ""

    def to_dict(self) -> Dict:
        return {
            "agent_id": self.agent_id,
            "agent_type": self.agent_type,
            "can_handle": self.can_handle,
            "partial_capability": self.partial_capability,
            "matching_capabilities": self.matching_capabilities,
            "missing_capabilities": self.missing_capabilities,
            "confidence": self.confidence,
            "estimated_time_seconds": self.estimated_time_seconds,
            "additional_info": self.additional_info
        }


# ============================================
# Protocol Constants
# ============================================

# Standard task actions that agents understand
class TaskActions:
    EXTRACT = "extract"
    PREPROCESS = "preprocess"
    ANALYZE = "analyze"
    SOLVE = "solve"
    DEBUG = "debug"
    VALIDATE = "validate"
    RETRIEVE = "retrieve"
    STORE = "store"
    DECOMPOSE = "decompose"
    COORDINATE = "coordinate"
    CHECK_SAFETY = "check_safety"
    AUDIT = "audit"


# Standard context keys shared between agents
class ContextKeys:
    RAW_LOG = "raw_log"
    CLEAN_LOG = "clean_log"
    LOG_TYPE = "log_type"
    INTENT = "intent"
    ROOT_CAUSE = "root_cause"
    SOLUTION = "solution"
    CODE_PATCH = "code_patch"
    VALIDATION_RESULT = "validation_result"
    CONFIDENCE = "confidence"
    ERROR = "error"
    CAVEATS = "caveats"
    SOURCE_FILE = "source_file"
    STACK_TRACE = "stack_trace"


# Error codes
class ErrorCodes:
    OUT_OF_SCOPE = "OUT_OF_SCOPE"
    MODEL_UNAVAILABLE = "MODEL_UNAVAILABLE"
    TOOL_UNAVAILABLE = "TOOL_UNAVAILABLE"
    INVALID_INPUT = "INVALID_INPUT"
    PROCESSING_FAILED = "PROCESSING_FAILED"
    TIMEOUT = "TIMEOUT"
    LOOP_DETECTED = "LOOP_DETECTED"
    PERMISSION_DENIED = "PERMISSION_DENIED"
    HUMAN_APPROVAL_REQUIRED = "HUMAN_APPROVAL_REQUIRED"