"""
Message Broker - Pub/Sub message routing system
"""

import asyncio
from typing import Dict, List, Callable, Any, Optional
from collections import defaultdict
from communication.a2a_protocol import A2AMessage, MessageType


class MessageBroker:
    """
    Pub/Sub message broker for agent communication.

    Handles:
    - Message queuing
    - Topic-based routing
    - Subscription management
    - Message persistence
    """

    def __init__(self):
        # topic -> list of subscriber callbacks
        self._subscribers: Dict[str, List[Callable]] = defaultdict(list)

        # Message queue
        self._queue: asyncio.Queue = asyncio.Queue()

        # Message history
        self._history: List[A2AMessage] = []
        self._max_history = 1000

        # Processing state
        self._is_running = False
        self._processor_task: Optional[asyncio.Task] = None

    def subscribe(self, topic: str, callback: Callable):
        """
        Subscribe to a topic.

        Args:
            topic: Message type or custom topic
            callback: Async function to call when message arrives
        """
        if callback not in self._subscribers[topic]:
            self._subscribers[topic].append(callback)

    def unsubscribe(self, topic: str, callback: Callable):
        """Unsubscribe from a topic"""
        if callback in self._subscribers[topic]:
            self._subscribers[topic].remove(callback)

    async def publish(self, message: A2AMessage):
        """Publish a message to subscribers"""
        topic = message.message_type.value if hasattr(message.message_type, 'value') else str(message.message_type)

        # Add to queue
        await self._queue.put((topic, message))

        # Store in history
        self._history.append(message)
        if len(self._history) > self._max_history:
            self._history = self._history[-self._max_history:]

    async def start(self):
        """Start the message broker"""
        self._is_running = True
        self._processor_task = asyncio.create_task(self._process_queue())

    async def stop(self):
        """Stop the message broker"""
        self._is_running = False
        if self._processor_task:
            self._processor_task.cancel()
            try:
                await self._processor_task
            except asyncio.CancelledError:
                pass

    async def _process_queue(self):
        """Process messages from the queue"""
        while self._is_running:
            try:
                topic, message = await asyncio.wait_for(
                    self._queue.get(),
                    timeout=1.0
                )

                # Deliver to subscribers
                subscribers = self._subscribers.get(topic, [])
                for callback in subscribers:
                    try:
                        await callback(message)
                    except Exception as e:
                        print(f"[BROKER] Error delivering to subscriber: {e}")

                # Also deliver to wildcard subscribers
                wildcard_subscribers = self._subscribers.get("*", [])
                for callback in wildcard_subscribers:
                    try:
                        await callback(message)
                    except Exception:
                        pass

            except asyncio.TimeoutError:
                continue
            except asyncio.CancelledError:
                break
            except Exception as e:
                print(f"[BROKER] Error processing message: {e}")

    def get_history(self, limit: int = 100) -> List[A2AMessage]:
        """Get recent message history"""
        return self._history[-limit:]

    def get_stats(self) -> Dict:
        """Get broker statistics"""
        return {
            "subscribers": {
                topic: len(callbacks)
                for topic, callbacks in self._subscribers.items()
            },
            "queue_size": self._queue.qsize(),
            "history_size": len(self._history),
            "is_running": self._is_running
        }