"""
Schemas - Message type definitions and validation schemas
"""

from typing import Dict, Any, List
from enum import Enum


class TaskAction(Enum):
    """Standard task actions that agents understand"""
    EXTRACT = "extract"
    PREPROCESS = "preprocess"
    ANALYZE = "analyze"
    SOLVE = "solve"
    DEBUG = "debug"
    VALIDATE = "validate"
    RETRIEVE = "retrieve"
    STORE = "store"
    DECOMPOSE = "decompose"
    COORDINATE = "coordinate"
    HEARTBEAT = "heartbeat"
    STATUS = "status"


class LogType(Enum):
    """Types of logs the system can handle"""
    ERROR_LOG = "error_log"
    SERVER_LOG = "server_log"
    APPLICATION_LOG = "application_log"
    SECURITY_LOG = "security_log"
    NETWORK_LOG = "network_log"
    DATABASE_LOG = "database_log"
    SYSTEM_LOG = "system_log"
    UNKNOWN = "unknown"


class IntentType(Enum):
    """Types of user intent"""
    DEBUGGING = "debugging"
    EXPLANATION = "explanation"
    OPTIMIZATION = "optimization"
    SECURITY_AUDIT = "security_audit"
    GENERAL_ANALYSIS = "general_analysis"


class SeverityLevel(Enum):
    """Severity levels for errors"""
    EMERGENCY = "EMERGENCY"
    ALERT = "ALERT"
    CRITICAL = "CRITICAL"
    ERROR = "ERROR"
    WARNING = "WARNING"
    NOTICE = "NOTICE"
    INFO = "INFO"
    DEBUG = "DEBUG"


# Task schemas for validation
TASK_SCHEMAS = {
    "extract": {
        "required": ["action"],
        "optional": ["source_type", "file_path", "content", "image_path"]
    },
    "preprocess": {
        "required": ["action", "raw_logs"],
        "optional": ["options"]
    },
    "analyze": {
        "required": ["action", "clean_logs"],
        "optional": ["log_type"]
    },
    "solve": {
        "required": ["action", "clean_logs"],
        "optional": ["log_type", "intent", "root_cause"]
    },
    "debug": {
        "required": ["action", "stack_trace"],
        "optional": ["source_code", "error_log"]
    },
    "validate": {
        "required": ["action", "solution"],
        "optional": ["original_logs"]
    },
    "store": {
        "required": ["action", "log_content"],
        "optional": ["analysis", "log_type"]
    },
    "retrieve": {
        "required": ["action", "query"],
        "optional": ["limit", "log_type"]
    }
}


def validate_task(action: str, task: Dict) -> tuple[bool, str]:
    """
    Validate a task against its schema.

    Returns:
        (is_valid, error_message)
    """
    if action not in TASK_SCHEMAS:
        return False, f"Unknown action: {action}"

    schema = TASK_SCHEMAS[action]

    # Check required fields
    for field in schema["required"]:
        if field not in task:
            return False, f"Missing required field '{field}' for action '{action}'"

    return True, ""


def get_task_schema(action: str) -> Dict:
    """Get the schema for a task action"""
    return TASK_SCHEMAS.get(action, {})
