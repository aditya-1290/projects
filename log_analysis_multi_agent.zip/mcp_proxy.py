"""
MCP Proxy — Lightweight MCP server that forwards to FastAPI.

Starts instantly (no models), forwards all calls to the running
FastAPI server at http://127.0.0.1:8000.

Usage:
    # Terminal 1: Start the FastAPI server (models load once)
    python adk_server.py

    # Terminal 2: Start the MCP proxy (instant)
    python mcp_proxy.py
"""

import asyncio
import sys
import json
import httpx
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

API_BASE = "http://127.0.0.1:8000"

app = Server("log-analysis-mcp-proxy")


@app.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="analyze_logs",
            description="Run the full log analysis pipeline. Provide logs, file path, terminal command, or image path.",
            inputSchema={
                "type": "object",
                "properties": {"query": {"type": "string"}},
                "required": ["query"]
            }
        ),
        Tool(
            name="get_health",
            description="Check system health — models loaded, agents active, uptime.",
            inputSchema={"type": "object", "properties": {}}
        ),
        Tool(
            name="list_agents",
            description="List all registered agents with their capabilities.",
            inputSchema={"type": "object", "properties": {}}
        ),
    ]


@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    try:
        async with httpx.AsyncClient(timeout=600.0) as client:

            if name == "analyze_logs":
                response = await client.post(
                    f"{API_BASE}/run",
                    json={"query": arguments.get("query", "")}
                )
                if response.status_code == 200:
                    data = response.json()
                    return [TextContent(type="text", text=data.get("response", json.dumps(data, indent=2)))]
                return [TextContent(type="text", text=f"❌ Error ({response.status_code}): {response.text[:300]}")]

            elif name == "get_health":
                response = await client.get(f"{API_BASE}/health")
                return [TextContent(type="text", text=json.dumps(response.json(), indent=2))]

            elif name == "list_agents":
                response = await client.get(f"{API_BASE}/agents")
                data = response.json()
                # Format agent list nicely
                agents = [f"• {a['name']} — {a['description'][:80]}" for a in data]
                return [TextContent(type="text", text="\n".join(agents))]

            return [TextContent(type="text", text=f"❌ Unknown tool: {name}")]

    except httpx.ConnectError:
        return [TextContent(type="text", text=f"❌ Cannot connect to {API_BASE}. Run: python adk_server.py")]
    except Exception as e:
        return [TextContent(type="text", text=f"❌ {str(e)}")]


async def main():
    async with stdio_server() as (read_stream, write_stream):
        await app.run(read_stream, write_stream, app.create_initialization_options())


if __name__ == "__main__":
    asyncio.run(main())
