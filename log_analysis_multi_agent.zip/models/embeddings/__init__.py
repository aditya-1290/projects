"""
Embeddings Package - Text embedding models

Provides:
- BGE-Small-EN wrapper
- Sentence transformer integration
- Mock embeddings for development
"""