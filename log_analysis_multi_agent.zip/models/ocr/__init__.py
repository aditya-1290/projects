"""
OCR Package - Optical Character Recognition

Provides:
- DeepSeek-OCR2 wrapper
- Fallback OCR (pytesseract)
- Mock OCR for development
"""

from models.ocr.deepseek_ocr import DeepSeekOCR
