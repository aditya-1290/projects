"""
DeepSeek-OCR2 Wrapper

Provides a clean .extract_text(path) interface for the image_loader.
Loads the custom DeepseekOCR2ForCausalLM model from local files.
"""

import os
import sys
from typing import Optional


class DeepSeekOCR:
    """
    Wrapper around DeepSeek-OCR-2 custom HuggingFace model.

    Usage:
        ocr = DeepSeekOCR("D:/python_tasks/models/DeepSeek-OCR-2")
        text = await ocr.extract_text("path/to/image.jpg")
    """

    def __init__(self, model_path: str):
        self.model_path = model_path
        self._model = None
        self._tokenizer = None
        self._loaded = False

    async def extract_text(self, image_path: str) -> str:
        if not self._loaded:
            await self._load_model()

        try:
            import tempfile
            import os

            # Create a temp directory for OCR output
            with tempfile.TemporaryDirectory() as tmpdir:
                result = self._model.infer(
                    tokenizer=self._tokenizer,
                    prompt='<image>\nExtract all text from this image.',
                    image_file=image_path,
                    output_path=tmpdir,  # ← Use temp dir instead of ''
                    base_size=1024,
                    image_size=640,
                    crop_mode=True,
                    test_compress=False,
                    save_results=False,
                    eval_mode=True
                )

            if isinstance(result, str):
                return result.strip()

            return await self._generate_text(image_path)

        except Exception as e:
            raise RuntimeError(f"DeepSeek-OCR2 inference failed: {e}")

    async def _load_model(self):
        """Load the DeepSeek-OCR2 model and tokenizer."""
        try:
            import torch
            import sys
            import os

            # Force CPU
            os.environ["CUDA_VISIBLE_DEVICES"] = ""

            print(f"[DeepSeekOCR] Loading model from {self.model_path}...")

            # Load tokenizer
            from transformers import AutoTokenizer
            self._tokenizer = AutoTokenizer.from_pretrained(
                self.model_path,
                trust_remote_code=True,
                local_files_only=True
            )

            # Add parent directory to sys.path for relative imports
            parent_dir = os.path.dirname(os.path.abspath(self.model_path))
            if parent_dir not in sys.path:
                sys.path.insert(0, parent_dir)

            model_folder = os.path.basename(os.path.abspath(self.model_path))
            modeling_module = __import__(f"{model_folder}.modeling_deepseekocr2", fromlist=["DeepseekOCR2ForCausalLM"])
            DeepseekOCR2ForCausalLM = getattr(modeling_module, "DeepseekOCR2ForCausalLM")

            self._model = DeepseekOCR2ForCausalLM.from_pretrained(
                self.model_path,
                torch_dtype=torch.float32,
                device_map="cpu",
                trust_remote_code=True,
                local_files_only=True
            )

            # MONKEY-PATCH: Replace torch.autocast("cuda") with a CPU-safe version
            # MONKEY-PATCH: Make CPU-only torch pretend CUDA is available
            import torch.cuda
            if not torch.cuda.is_available():
                # Create a dummy CUDA module that routes to CPU
                class DummyCuda:
                    def is_available(self):
                        return True

                    def empty_cache(self):
                        pass

                    def synchronize(self):
                        pass

                    def current_device(self):
                        return 0

                    def set_device(self, device):
                        pass

                    class Stream:
                        def __init__(self, *args, **kwargs):
                            pass

                        def wait_stream(self, *args, **kwargs):
                            pass

                    Stream = Stream

                # Replace the real cuda module with our dummy
                torch.cuda = DummyCuda()
                torch.cuda.is_available = lambda: True

                # Also patch autocast to use CPU
                original_autocast = torch.autocast

                def cpu_safe_autocast(device_type=None, *args, **kwargs):
                    if device_type == "cuda":
                        device_type = "cpu"
                    return original_autocast(device_type, *args, **kwargs)

                torch.autocast = cpu_safe_autocast

            self._model.eval()
            self._loaded = True

            print("[DeepSeekOCR] Model loaded successfully")

        except Exception as e:
            raise RuntimeError(f"Failed to load DeepSeek-OCR2 model: {e}")


    async def _generate_text(self, image_path: str) -> str:
        """Alternative: use generate() with image as input."""
        import torch
        from PIL import Image

        image = Image.open(image_path).convert("RGB")

        # This is a fallback — the exact API depends on how infer() works
        # For now, return placeholder since infer() likely handles everything
        return ""
