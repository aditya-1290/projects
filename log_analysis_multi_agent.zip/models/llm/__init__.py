"""
LLM Package - Language Model wrappers

Provides:
- llama.cpp loader
- Gemma-4-E4B-IT wrapper
- Qwen2.5-3B wrapper
- Shared inference logic
- Context management
"""