"""ADK Entry Point."""
from agents.adk.root_agent import root_agent
