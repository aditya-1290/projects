"""
MCP Server — Exposes all 8 agents as MCP tools.

Each agent is a separate tool callable via MCP protocol.
Agents communicate through the existing Communication Bus.

Usage:
    python mcp_server_deprecated.py

MCP Tools (1 per agent):
    orchestrator_analyze    — Full pipeline analysis
    extractor_extract       — Extract logs from any source
    preprocessor_process    — Clean, parse, normalize logs
    analyzer_analyze        — Classify logs, detect intent
    solver_solve            — Root cause analysis + fixes
    debugger_debug          — Stack trace parsing + patches
    critic_validate         — Validate solution quality
    memory_search           — Store/retrieve past cases
"""
import os, sys
sys.stdout = sys.stderr
import asyncio
import json
from pathlib import Path
from typing import Optional

sys.path.insert(0, str(Path(__file__).parent))

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent


# ═══════════════════════════════════════════════════════════
# Lazy-loaded system
# ═══════════════════════════════════════════════════════════

_system = None
_init_lock = asyncio.Lock()


async def _get_system():
    """Initialize the system once. Skips OCR and embedding for faster MCP startup."""
    global _system
    if _system is not None:
        return _system

    async with _init_lock:
        if _system is not None:
            return _system

        from models.manager import ModelManager
        from agentos.communication_bus import CommunicationBus
        from main import SystemBootstrap

        print("[MCP] Loading system (LLMs only, skipping OCR/embedding)...", file=sys.stderr)

        # Load only LLMs — set OCR and embedding to load_on_startup=False
        from models.model_configs import MODELS
        original_ocr = MODELS["deepseek_ocr"].load_on_startup
        original_emb = MODELS["embedding"].load_on_startup
        MODELS["deepseek_ocr"].load_on_startup = False
        MODELS["embedding"].load_on_startup = False

        model_manager = ModelManager(max_memory_gb=15.0)
        await model_manager.initialize()

        # Restore original settings
        MODELS["deepseek_ocr"].load_on_startup = original_ocr
        MODELS["embedding"].load_on_startup = original_emb

        bus = CommunicationBus()
        agents, orchestrator = await SystemBootstrap.create_all_agents(model_manager, bus)
        await bus.start()

        if orchestrator:
            await orchestrator.initialize()

        _system = {
            "model_manager": model_manager,
            "bus": bus,
            "agents": agents,
            "orchestrator": orchestrator,
        }

        print(f"[MCP] Ready — {len(agents)} agents loaded", file=sys.stderr)
        return _system


def _get_agent(agent_type: str):
    """Get a specific agent by type name from the bus."""
    if _system is None:
        return None
    bus = _system["bus"]
    for agent_id, agent in bus.agents.items():
        if agent.capability.agent_name == agent_type:
            return agent
    return None


# ═══════════════════════════════════════════════════════════
# MCP Server
# ═══════════════════════════════════════════════════════════

app = Server("log-analysis-multi-agent")


@app.list_tools()
async def list_tools() -> list[Tool]:
    """List all 8 agents as MCP tools."""
    return [
        Tool(
            name="orchestrator_analyze",
            description="Run the full log analysis pipeline. Provide logs, a file path, "
                        "terminal command, or image path. Returns root cause analysis, "
                        "fix suggestions, and confidence scores.",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Log entries, file path, terminal command (command:...), image path, or ES query (es:...)"
                    }
                },
                "required": ["query"]
            }
        ),
        Tool(
            name="extractor_extract",
            description="Extract log content from files, images, terminal output, pasted text, or Elasticsearch.",
            inputSchema={
                "type": "object",
                "properties": {
                    "source_type": {
                        "type": "string",
                        "enum": ["auto", "file", "image", "terminal", "text", "elasticsearch"],
                        "description": "Type of source to extract from"
                    },
                    "file_path": {
                        "type": "string",
                        "description": "Path to file or image"
                    },
                    "command": {
                        "type": "string",
                        "description": "Terminal command to execute"
                    },
                    "content": {
                        "type": "string",
                        "description": "Pasted log text"
                    },
                    "es_query": {
                        "type": "string",
                        "description": "Elasticsearch Lucene query string"
                    }
                }
            }
        ),
        Tool(
            name="preprocessor_process",
            description="Clean, parse, normalize, and chunk raw log entries.",
            inputSchema={
                "type": "object",
                "properties": {
                    "raw_logs": {
                        "type": "string",
                        "description": "Raw log content to preprocess"
                    }
                },
                "required": ["raw_logs"]
            }
        ),
        Tool(
            name="analyzer_analyze",
            description="Classify log type, detect user intent, assess severity, and identify patterns.",
            inputSchema={
                "type": "object",
                "properties": {
                    "clean_logs": {
                        "type": "string",
                        "description": "Preprocessed log content to analyze"
                    }
                },
                "required": ["clean_logs"]
            }
        ),
        Tool(
            name="solver_solve",
            description="Analyze logs to find root cause, generate fix suggestions, and explain the error.",
            inputSchema={
                "type": "object",
                "properties": {
                    "clean_logs": {
                        "type": "string",
                        "description": "Preprocessed log content"
                    },
                    "log_type": {
                        "type": "string",
                        "description": "Detected log type for context"
                    },
                    "intent": {
                        "type": "string",
                        "enum": ["debugging", "explanation", "optimization", "security_audit", "health_check"],
                        "description": "User intent"
                    }
                },
                "required": ["clean_logs"]
            }
        ),
        Tool(
            name="debugger_debug",
            description="Parse stack traces and generate code patches with language-specific analysis.",
            inputSchema={
                "type": "object",
                "properties": {
                    "stack_trace": {
                        "type": "string",
                        "description": "Stack trace text to parse and analyze"
                    },
                    "source_code": {
                        "type": "string",
                        "description": "Optional source code for context-aware debugging"
                    },
                    "language": {
                        "type": "string",
                        "enum": ["python", "java", "javascript", "typescript", "go", "auto"],
                        "description": "Programming language"
                    }
                },
                "required": ["stack_trace"]
            }
        ),
        Tool(
            name="critic_validate",
            description="Validate a proposed solution for factual consistency, logical coherence, completeness, safety, and hallucinations.",
            inputSchema={
                "type": "object",
                "properties": {
                    "solution": {
                        "type": "object",
                        "description": "Solution dict with root_cause, fix_suggestion, and explanation fields"
                    },
                    "original_logs": {
                        "type": "string",
                        "description": "Original log content for evidence checking"
                    }
                },
                "required": ["solution"]
            }
        ),
        Tool(
            name="memory_search",
            description="Search for past log analyses similar to the current case using vector search.",
            inputSchema={
                "type": "object",
                "properties": {
                    "action": {
                        "type": "string",
                        "enum": ["retrieve", "store", "search"],
                        "description": "What to do: retrieve similar, store new, or search by pattern"
                    },
                    "query": {
                        "type": "string",
                        "description": "Search query or error text"
                    },
                    "log_content": {
                        "type": "string",
                        "description": "Log content to store (for store action)"
                    },
                    "analysis": {
                        "type": "object",
                        "description": "Analysis results to store (for store action)"
                    },
                    "log_type": {
                        "type": "string",
                        "description": "Detected log type"
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Max results for retrieval",
                        "default": 5
                    }
                },
                "required": ["action"]
            }
        ),
    ]


@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    """Route tool calls to the appropriate agent."""

    sys = await _get_system()
    if not sys:
        return [TextContent(type="text", text="❌ System failed to initialize.")]

    bus = sys["bus"]
    orchestrator = sys["orchestrator"]

    try:
        # ---- Orchestrator ----
        if name == "orchestrator_analyze":
            query = arguments.get("query", "")
            if not query:
                return [TextContent(type="text", text="❌ No query provided.")]
            result = await orchestrator.handle_user_query(query)
            return [TextContent(type="text", text=result)]

        # ---- Extractor ----
        elif name == "extractor_extract":
            from agents.base_agent import A2AMessage, MessageType

            agent = _get_agent("extractor")
            if not agent:
                return [TextContent(type="text", text="❌ Extractor agent not found.")]

            task = {k: v for k, v in arguments.items() if v}
            task["action"] = "extract"

            msg = A2AMessage(
                message_type=MessageType.REQUEST,
                sender_id="mcp_server",
                sender_type="external",
                target_id=agent.agent_id,
                task=task,
            )

            response = await agent.process(msg)
            return [TextContent(type="text", text=json.dumps(response.response, indent=2, default=str))]

        # ---- Preprocessor ----
        elif name == "preprocessor_process":
            from agents.base_agent import A2AMessage, MessageType

            agent = _get_agent("preprocessor")
            if not agent:
                return [TextContent(type="text", text="❌ Preprocessor agent not found.")]

            msg = A2AMessage(
                message_type=MessageType.REQUEST,
                sender_id="mcp_server",
                sender_type="external",
                target_id=agent.agent_id,
                task={"action": "preprocess", "raw_logs": arguments.get("raw_logs", "")},
            )

            response = await agent.process(msg)
            return [TextContent(type="text", text=json.dumps(response.response, indent=2, default=str))]

        # ---- Analyzer ----
        elif name == "analyzer_analyze":
            from agents.base_agent import A2AMessage, MessageType

            agent = _get_agent("analyzer")
            if not agent:
                return [TextContent(type="text", text="❌ Analyzer agent not found.")]

            msg = A2AMessage(
                message_type=MessageType.REQUEST,
                sender_id="mcp_server",
                sender_type="external",
                target_id=agent.agent_id,
                task={"action": "analyze", "clean_logs": arguments.get("clean_logs", "")},
            )

            response = await agent.process(msg)
            return [TextContent(type="text", text=json.dumps(response.response, indent=2, default=str))]

        # ---- Solver ----
        elif name == "solver_solve":
            from agents.base_agent import A2AMessage, MessageType

            agent = _get_agent("solver")
            if not agent:
                return [TextContent(type="text", text="❌ Solver agent not found.")]

            msg = A2AMessage(
                message_type=MessageType.REQUEST,
                sender_id="mcp_server",
                sender_type="external",
                target_id=agent.agent_id,
                task={
                    "action": "solve",
                    "clean_logs": arguments.get("clean_logs", ""),
                    "log_type": arguments.get("log_type", "unknown"),
                    "intent": arguments.get("intent", "debugging"),
                },
            )

            response = await agent.process(msg)
            return [TextContent(type="text", text=json.dumps(response.response, indent=2, default=str))]

        # ---- Debugger ----
        elif name == "debugger_debug":
            from agents.base_agent import A2AMessage, MessageType

            agent = _get_agent("debugger")
            if not agent:
                return [TextContent(type="text", text="❌ Debugger agent not found.")]

            msg = A2AMessage(
                message_type=MessageType.REQUEST,
                sender_id="mcp_server",
                sender_type="external",
                target_id=agent.agent_id,
                task={
                    "action": "debug",
                    "stack_trace": arguments.get("stack_trace", ""),
                    "source_code": arguments.get("source_code", ""),
                    "language": arguments.get("language", "auto"),
                },
            )

            response = await agent.process(msg)
            return [TextContent(type="text", text=json.dumps(response.response, indent=2, default=str))]

        # ---- Critic ----
        elif name == "critic_validate":
            from agents.base_agent import A2AMessage, MessageType

            agent = _get_agent("critic")
            if not agent:
                return [TextContent(type="text", text="❌ Critic agent not found.")]

            msg = A2AMessage(
                message_type=MessageType.REQUEST,
                sender_id="mcp_server",
                sender_type="external",
                target_id=agent.agent_id,
                task={
                    "action": "validate",
                    "solution": arguments.get("solution", {}),
                    "original_logs": arguments.get("original_logs", ""),
                },
            )

            response = await agent.process(msg)
            return [TextContent(type="text", text=json.dumps(response.response, indent=2, default=str))]

        # ---- Memory ----
        elif name == "memory_search":
            from agents.base_agent import A2AMessage, MessageType

            agent = _get_agent("memory")
            if not agent:
                return [TextContent(type="text", text="❌ Memory agent not found.")]

            msg = A2AMessage(
                message_type=MessageType.REQUEST,
                sender_id="mcp_server",
                sender_type="external",
                target_id=agent.agent_id,
                task={
                    "action": arguments.get("action", "retrieve"),
                    "query": arguments.get("query", ""),
                    "log_content": arguments.get("log_content", ""),
                    "analysis": arguments.get("analysis", {}),
                    "log_type": arguments.get("log_type", "unknown"),
                    "limit": arguments.get("limit", 5),
                },
            )

            response = await agent.process(msg)
            return [TextContent(type="text", text=json.dumps(response.response, indent=2, default=str))]

        return [TextContent(type="text", text=f"❌ Unknown tool: {name}")]

    except Exception as e:
        import traceback
        return [TextContent(type="text", text=f"❌ {name} failed: {str(e)}\n{traceback.format_exc()}")]


# ═══════════════════════════════════════════════════════════
# Entry point
# ═══════════════════════════════════════════════════════════

async def main():
    async with stdio_server() as (read_stream, write_stream):
        await app.run(read_stream, write_stream, app.create_initialization_options())


if __name__ == "__main__":
    asyncio.run(main())
