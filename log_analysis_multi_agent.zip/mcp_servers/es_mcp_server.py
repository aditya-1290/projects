"""
MCP Server for Elasticsearch � Exposes ES capabilities as MCP tools.
Uses the Model Context Protocol (MCP) for standardized tool discovery.
"""
import json
import os
from typing import Any, Dict, List, Optional

try:
    from mcp.server import Server
    from mcp.server.stdio import stdio_server
    from mcp.types import Tool, TextContent
    MCP_AVAILABLE = True
except ImportError:
    MCP_AVAILABLE = False
    print("[ES MCP] MCP SDK not installed. Run: pip install mcp")


class ElasticsearchMCP:
    """MCP Server that wraps the Elasticsearch loader for dynamic tool discovery."""

    def __init__(self):
        self.server = Server("elasticsearch-mcp")
        self._setup_tools()

    def _setup_tools(self):
        """Register all ES tools with MCP."""
        
        @self.server.tool()
        async def es_search(
            index: str = "logs-*",
            query_string: str = "",
            time_range: str = "now-1h",
            size: int = 100
        ) -> str:
            """
            Search Elasticsearch for log entries.
            
            Args:
                index: Index pattern (e.g., "logs-*", "prod-2024-*")
                query_string: Lucene query string or JSON Query DSL
                time_range: Time range (e.g., "now-1h", "now-1d", "now-1w")
                size: Maximum number of results (default 100, max 5000)
            """
            from agents.extractor.loaders.es_loader import ElasticsearchLoader
            
            loader = ElasticsearchLoader()
            if not loader.is_available():
                return json.dumps({"error": "Elasticsearch not available"})
            
            # Parse query
            query = None
            if query_string:
                try:
                    query = json.loads(query_string) if query_string.startswith("{") else {"query_string": {"query": query_string}}
                except json.JSONDecodeError:
                    query = {"query_string": {"query": query_string}}
            
            result = await loader.search(
                index=index,
                query=query,
                time_range=(time_range, "now") if not time_range.endswith("/now") else time_range,
                size=min(size, 5000)
            )
            
            return result if isinstance(result, str) else json.dumps(result)

        @self.server.tool()
        async def es_list_indices(pattern: str = "*") -> str:
            """List available Elasticsearch indices."""
            from agents.extractor.loaders.es_loader import ElasticsearchLoader
            
            loader = ElasticsearchLoader()
            if not loader.is_available():
                return json.dumps({"error": "Elasticsearch not available"})
            
            indices = await loader.list_indices(pattern)
            return json.dumps({"indices": indices, "count": len(indices)})

        @self.server.tool()
        async def es_get_mapping(index: str) -> str:
            """Get field mappings for an Elasticsearch index."""
            from agents.extractor.loaders.es_loader import ElasticsearchLoader
            
            loader = ElasticsearchLoader()
            if not loader.is_available():
                return json.dumps({"error": "Elasticsearch not available"})
            
            mapping = await loader.get_mapping(index)
            return json.dumps(mapping)

        @self.server.tool()
        async def es_health_check() -> str:
            """Check Elasticsearch cluster health."""
            from agents.extractor.loaders.es_loader import ElasticsearchLoader
            
            loader = ElasticsearchLoader()
            if not loader.is_available():
                return json.dumps({"status": "unavailable"})
            
            health = await loader.health_check()
            return json.dumps(health)

    async def run(self):
        """Start the MCP server."""
        if not MCP_AVAILABLE:
            print("[ES MCP] Cannot start � MCP SDK not installed")
            return
        
        async with stdio_server() as (read_stream, write_stream):
            await self.server.run(read_stream, write_stream, self.server.create_initialization_options())


# Standalone entry point
if __name__ == "__main__":
    import asyncio
    server = ElasticsearchMCP()
    asyncio.run(server.run())
