"""
Session Manager - Manages user sessions and context
"""

import uuid
from typing import Dict, Any, Optional, List
from datetime import datetime


class Session:
    """Represents a single user session"""

    def __init__(self, session_id: str = None):
        self.session_id = session_id or str(uuid.uuid4())
        self.created_at = datetime.now().isoformat()
        self.last_activity = self.created_at
        self.context: Dict[str, Any] = {}
        self.history: List[Dict] = []
        self.is_active = True

    def update_activity(self):
        """Update last activity timestamp"""
        self.last_activity = datetime.now().isoformat()

    def add_to_history(self, entry: Dict):
        """Add an entry to session history"""
        self.history.append({
            **entry,
            "timestamp": datetime.now().isoformat()
        })
        self.update_activity()

    def set_context(self, key: str, value: Any):
        """Set a context value"""
        self.context[key] = value
        self.update_activity()

    def get_context(self, key: str, default: Any = None) -> Any:
        """Get a context value"""
        return self.context.get(key, default)

    def to_dict(self) -> Dict:
        """Convert to dictionary"""
        return {
            "session_id": self.session_id,
            "created_at": self.created_at,
            "last_activity": self.last_activity,
            "context_keys": list(self.context.keys()),
            "history_count": len(self.history),
            "is_active": self.is_active
        }


class SessionManager:
    """Manages multiple user sessions"""

    def __init__(self, max_sessions: int = 10, session_timeout_minutes: int = 30):
        self.max_sessions = max_sessions
        self.session_timeout_minutes = session_timeout_minutes
        self._sessions: Dict[str, Session] = {}
        self._current_session_id: Optional[str] = None

    def create_session(self) -> Session:
        """Create a new session"""
        # Cleanup old sessions
        self._cleanup_expired()

        # Check max sessions
        if len(self._sessions) >= self.max_sessions:
            # Remove oldest session
            oldest_id = min(
                self._sessions.keys(),
                key=lambda sid: self._sessions[sid].last_activity
            )
            del self._sessions[oldest_id]

        session = Session()
        self._sessions[session.session_id] = session
        self._current_session_id = session.session_id
        return session

    def get_session(self, session_id: str = None) -> Optional[Session]:
        """Get a session by ID"""
        if session_id:
            session = self._sessions.get(session_id)
        else:
            session = self._sessions.get(self._current_session_id)

        if session:
            session.update_activity()

        return session

    def get_current_session(self) -> Optional[Session]:
        """Get the current active session"""
        return self.get_session()

    def end_session(self, session_id: str = None):
        """End a session"""
        sid = session_id or self._current_session_id
        if sid and sid in self._sessions:
            self._sessions[sid].is_active = False
            del self._sessions[sid]
            if self._current_session_id == sid:
                self._current_session_id = None

    def _cleanup_expired(self):
        """Remove expired sessions"""
        now = datetime.now()
        expired = []

        for sid, session in self._sessions.items():
            last_activity = datetime.fromisoformat(session.last_activity)
            minutes_inactive = (now - last_activity).total_seconds() / 60

            if minutes_inactive > self.session_timeout_minutes:
                expired.append(sid)

        for sid in expired:
            del self._sessions[sid]

    def get_active_sessions(self) -> List[Dict]:
        """Get list of active sessions"""
        self._cleanup_expired()
        return [
            session.to_dict()
            for session in self._sessions.values()
            if session.is_active
        ]

    def get_stats(self) -> Dict:
        """Get session statistics"""
        return {
            "active_sessions": len(self._sessions),
            "max_sessions": self.max_sessions,
            "timeout_minutes": self.session_timeout_minutes,
            "current_session": self._current_session_id
        }


# Global instance
_session_manager: Optional[SessionManager] = None


def get_session_manager() -> SessionManager:
    """Get the global session manager"""
    global _session_manager
    if _session_manager is None:
        _session_manager = SessionManager()
    return _session_manager
