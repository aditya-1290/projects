"""
Agent Registry - Central registry of all agents in the system
"""

from typing import Dict, List, Optional, Any


class AgentRegistry:
    """
    Central registry for all agents.

    Tracks:
    - Agent instances
    - Agent status
    - Agent metadata
    """

    def __init__(self):
        self._agents: Dict[str, Any] = {}  # agent_id -> agent instance
        self._agent_types: Dict[str, List[str]] = {}  # agent_type -> [agent_ids]
        self._agent_status: Dict[str, str] = {}  # agent_id -> status

    def register(self, agent: Any):
        """
        Register an agent.

        Args:
            agent: BaseAgent instance
        """
        agent_id = agent.agent_id
        agent_type = agent.capability.agent_name

        # Store agent
        self._agents[agent_id] = agent

        # Index by type
        if agent_type not in self._agent_types:
            self._agent_types[agent_type] = []
        if agent_id not in self._agent_types[agent_type]:
            self._agent_types[agent_type].append(agent_id)

        # Set status
        self._agent_status[agent_id] = "idle"

    def unregister(self, agent_id: str):
        """Remove an agent from the registry"""
        agent = self._agents.pop(agent_id, None)
        if agent:
            agent_type = agent.capability.agent_name
            if agent_type in self._agent_types:
                self._agent_types[agent_type].remove(agent_id)
                if not self._agent_types[agent_type]:
                    del self._agent_types[agent_type]
        self._agent_status.pop(agent_id, None)

    def get_agent(self, agent_id: str) -> Optional[Any]:
        """Get an agent by ID"""
        return self._agents.get(agent_id)

    def get_agents_by_type(self, agent_type: str) -> List[Any]:
        """Get all agents of a specific type"""
        agent_ids = self._agent_types.get(agent_type, [])
        return [self._agents[aid] for aid in agent_ids if aid in self._agents]

    def get_first_agent_by_type(self, agent_type: str) -> Optional[Any]:
        """Get the first available agent of a type"""
        agents = self.get_agents_by_type(agent_type)
        return agents[0] if agents else None

    def get_all_agents(self) -> List[Any]:
        """Get all registered agents"""
        return list(self._agents.values())

    def get_agent_ids(self) -> List[str]:
        """Get all agent IDs"""
        return list(self._agents.keys())

    def get_agent_types(self) -> List[str]:
        """Get all agent types"""
        return list(self._agent_types.keys())

    def update_status(self, agent_id: str, status: str):
        """Update an agent's status"""
        self._agent_status[agent_id] = status

    def get_status(self, agent_id: str) -> str:
        """Get an agent's status"""
        return self._agent_status.get(agent_id, "unknown")

    def get_all_statuses(self) -> Dict[str, str]:
        """Get all agent statuses"""
        return self._agent_status.copy()

    def count(self) -> int:
        """Get total number of registered agents"""
        return len(self._agents)

    def count_by_type(self, agent_type: str) -> int:
        """Get number of agents of a specific type"""
        return len(self._agent_types.get(agent_type, []))

    def clear(self):
        """Clear the registry"""
        self._agents.clear()
        self._agent_types.clear()
        self._agent_status.clear()


# Global instance
_registry: Optional[AgentRegistry] = None


def get_agent_registry() -> AgentRegistry:
    """Get the global agent registry"""
    global _registry
    if _registry is None:
        _registry = AgentRegistry()
    return _registry
