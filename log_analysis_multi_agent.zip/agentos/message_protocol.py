"""
Message Protocol - A2A message handling and validation
"""

from typing import Dict, Any, Optional
from communication.a2a_protocol import (
    A2AMessage, MessageType, MessagePriority, DeliveryStatus
)


class MessageProtocol:
    """
    Handles A2A message protocol operations.

    Responsibilities:
    - Message validation
    - Message creation helpers
    - Message routing rules
    """

    @staticmethod
    def validate_message(message: A2AMessage) -> tuple[bool, Optional[str]]:
        """
        Validate a message before sending.

        Returns:
            (is_valid, error_message)
        """
        # Must have sender
        if not message.sender_id:
            return False, "Message must have a sender_id"

        # Must have message type
        if not message.message_type:
            return False, "Message must have a message_type"

        # REQUEST must have a task
        if message.message_type == MessageType.REQUEST and not message.task:
            return False, "REQUEST messages must have a task"

        # RESPONSE must have either response or error
        if message.message_type == MessageType.RESPONSE:
            if not message.response and not message.error:
                return False, "RESPONSE messages must have response or error"

        # Check TTL
        if message.ttl <= 0:
            return False, "Message TTL expired"

        # Validate confidence
        if not (0.0 <= message.confidence <= 1.0):
            return False, "Confidence must be between 0.0 and 1.0"

        return True, None

    @staticmethod
    def get_routing_targets(message: A2AMessage, registered_agents: Dict) -> list:
        """
        Determine routing targets for a message.

        Returns:
            List of agent_ids to route to
        """
        targets = []

        # Direct message to specific agent
        if message.target_id:
            if message.target_id in registered_agents:
                targets.append(message.target_id)
            return targets

        # Route by agent type
        if message.target_type:
            for agent_id, agent in registered_agents.items():
                if hasattr(agent, 'capability') and agent.capability.agent_name == message.target_type:
                    targets.append(agent_id)
            return targets

        # Broadcast to all
        if message.message_type == MessageType.BROADCAST:
            targets = [
                aid for aid in registered_agents.keys()
                if aid != message.sender_id
            ]
            return targets

        return targets

    @staticmethod
    def create_ack_message(original: A2AMessage, agent_id: str, agent_type: str) -> A2AMessage:
        """Create an acknowledgment message"""
        return A2AMessage(
            message_type=MessageType.RESPONSE,
            sender_id=agent_id,
            sender_type=agent_type,
            target_id=original.sender_id,
            correlation_id=original.message_id,
            response={"acknowledged": True, "original_message_id": original.message_id},
            confidence=1.0
        )

    @staticmethod
    def create_heartbeat(agent_id: str, agent_type: str) -> A2AMessage:
        """Create a heartbeat message"""
        return A2AMessage(
            message_type=MessageType.REQUEST,
            sender_id=agent_id,
            sender_type=agent_type,
            task={"action": "heartbeat", "timestamp": __import__('datetime').datetime.now().isoformat()},
            # message_type=MessageType.REQUEST
        )