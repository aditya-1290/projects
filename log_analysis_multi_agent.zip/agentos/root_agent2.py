"""
ADK Root Agent — Entry point for the Log Analysis Multi-Agent System.
"""
"""
ADK Root Agent — Entry point for the Log Analysis Multi-Agent System.
"""
import sys
import os

# PATCH: Fix LiteLLMClient serialization bug in ADK 1.31.1
# This allows all 18 tools to work with the LiteLlm model
from google.adk.models.lite_llm import LiteLLMClient
import pydantic

from google.adk.agents import LlmAgent
from google.adk.models import LiteLlm
from google.adk.tools.base_tool import BaseTool, ToolContext
from agents.adk.tool_parser import parse_tool_call, execute_parsed_tool, format_tool_response

from agents.adk.server import start_model_server, get_model_url
from agents.adk.tools.pipeline_tool import full_pipeline, natural_language_query
from agents.adk.tools.extractor_tools import extract_file, extract_text, run_terminal, ocr_image
from agents.adk.tools.preprocessor_tool import preprocess_logs, filter_logs
from agents.adk.tools.analyzer_tool import analyze_logs
from agents.adk.tools.solver_tool import solve_error, explain_error, summarize_logs
from agents.adk.tools.debugger_tool import debug_trace
from agents.adk.tools.critic_tool import validate_solution
from agents.adk.tools.memory_tool import search_memory, store_analysis, trend_analysis

# Register a serializer for LiteLLMClient so Pydantic doesn't crash
_original_dump = pydantic.TypeAdapter.dump_json


def _patched_dump(self, obj, **kwargs):
    """Replace LiteLLMClient objects with their string representation."""
    from google.adk.models.lite_llm import LiteLLMClient as LLC

    def _fix(v):
        if isinstance(v, LLC):
            return str(v)
        if isinstance(v, dict):
            return {kk: _fix(vv) for kk, vv in v.items()}
        if isinstance(v, list):
            return [_fix(vv) for vv in v]
        return v

    obj = _fix(obj)
    return _original_dump(self, obj, **kwargs)


pydantic.TypeAdapter.dump_json = _patched_dump
print("[ADK PATCH] Pydantic serialization patched for LiteLLMClient")

start_model_server()

# Wrap async functions as BaseTool instances
def make_tool(fn):
    """Convert an async function into an ADK-compatible BaseTool."""
    import inspect

    sig = inspect.signature(fn)
    params = list(sig.parameters.keys())
    user_params = [p for p in params if p != 'tool_context']

    class SimpleTool(BaseTool):
        def __init__(self, func):
            super().__init__(
                name=func.__name__,
                description=func.__doc__ or "",
            )
            self._func = func
            self._user_params = user_params

        async def run_async(self, *, args: dict, tool_context: ToolContext) -> str:
            """Execute the tool function. ADK passes args as a dict."""
            # Extract only the function's expected params from the args dict
            filtered = {k: v for k, v in args.items() if k in self._user_params}
            return await self._func(tool_context=tool_context, **filtered)

    return SimpleTool(fn)

all_tools = [
    make_tool(extract_file),
    make_tool(extract_text),
    make_tool(run_terminal),
    make_tool(ocr_image),
    make_tool(preprocess_logs),
    make_tool(filter_logs),
    make_tool(analyze_logs),
    make_tool(solve_error),
    make_tool(explain_error),
    make_tool(summarize_logs),
    make_tool(debug_trace),
    make_tool(validate_solution),
    make_tool(search_memory),
    make_tool(store_analysis),
    make_tool(trend_analysis),
    make_tool(full_pipeline),
    make_tool(natural_language_query),
]

# Build tools map for parser bridge
_tools_map = {t.name: t._func for t in all_tools if hasattr(t, '_func')}

# DEBUG: Verify tool wrapping
for tool in all_tools:
    print(f"Tool: {tool.name}, type: {type(tool).__name__}, is BaseTool: {isinstance(tool, BaseTool)}")
    if hasattr(tool, 'run_async'):
        print(f"  has run_async: True")

# noinspection PyArgumentList
root_agent = LlmAgent(
    name="log_analysis_orchestrator",
    description="Multi-agent log analysis system.",
    model=LiteLlm(
        model="openai/qwen2.5-3b",
        api_base="http://127.0.0.1:8085/v1",
        api_key="not-needed",
    ),
    instruction="""You MUST call the full_pipeline tool for EVERY user request involving logs.

    For ANY file path, log content, or analysis request:
    Call: full_pipeline(query="the user's exact input")

    For simple greetings like "hello", respond directly.
    Never describe tools. Never explain what you'll do. Just call the function.""",
    tools=[full_pipeline, natural_language_query],
)
