"""
Capability Registry - Global index of all agent capabilities
"""

from typing import Dict, List, Set, Optional
from collections import defaultdict


class CapabilityRegistry:
    """
    Central registry of all agent capabilities.

    Enables fast capability-based agent discovery
    without querying each agent individually.
    """

    def __init__(self):
        # capability_name -> set of agent_ids
        self._capability_index: Dict[str, Set[str]] = defaultdict(set)

        # agent_id -> list of capabilities
        self._agent_capabilities: Dict[str, List[str]] = defaultdict(list)

        # agent_id -> agent metadata
        self._agent_metadata: Dict[str, Dict] = {}

    def register_agent(
            self, agent_id: str, capabilities: List[str], metadata: Dict = None
    ):
        """
        Register an agent's capabilities.

        Args:
            agent_id: Unique agent identifier
            capabilities: List of capability strings
            metadata: Optional agent metadata
        """
        # Remove old entries if re-registering
        self.unregister_agent(agent_id)

        # Index each capability
        for capability in capabilities:
            self._capability_index[capability].add(agent_id)

        # Store agent capabilities
        self._agent_capabilities[agent_id] = capabilities

        # Store metadata
        if metadata:
            self._agent_metadata[agent_id] = metadata

    def unregister_agent(self, agent_id: str):
        """Remove an agent from the registry"""
        # Remove from capability index
        for capability in self._capability_index:
            self._capability_index[capability].discard(agent_id)

        # Remove agent capabilities
        self._agent_capabilities.pop(agent_id, None)
        self._agent_metadata.pop(agent_id, None)

        # Clean up empty capability entries
        empty_caps = [
            cap for cap, agents in self._capability_index.items()
            if not agents
        ]
        for cap in empty_caps:
            del self._capability_index[cap]

    def find_agents_with_capability(self, capability: str) -> List[str]:
        """Find agents that have a specific capability"""
        return list(self._capability_index.get(capability, set()))

    def find_agents_with_all_capabilities(self, capabilities: List[str]) -> List[str]:
        """Find agents that have ALL specified capabilities"""
        if not capabilities:
            return []

        # Start with agents for first capability
        result = set(self._capability_index.get(capabilities[0], set()))

        # Intersect with remaining capabilities
        for capability in capabilities[1:]:
            result &= self._capability_index.get(capability, set())

        return list(result)

    def find_agents_with_any_capability(self, capabilities: List[str]) -> List[str]:
        """Find agents that have ANY of the specified capabilities"""
        result = set()
        for capability in capabilities:
            result.update(self._capability_index.get(capability, set()))
        return list(result)

    def get_agent_capabilities(self, agent_id: str) -> List[str]:
        """Get capabilities for a specific agent"""
        return self._agent_capabilities.get(agent_id, [])

    def has_capability(self, agent_id: str, capability: str) -> bool:
        """Check if an agent has a specific capability"""
        return agent_id in self._capability_index.get(capability, set())

    def get_all_capabilities(self) -> List[str]:
        """Get list of all registered capabilities"""
        return list(self._capability_index.keys())

    def get_stats(self) -> Dict:
        """Get registry statistics"""
        return {
            "total_capabilities": len(self._capability_index),
            "total_agents": len(self._agent_capabilities),
            "capabilities": dict(self._capability_index),
            "agents": dict(self._agent_capabilities)
        }

    def clear(self):
        """Clear the entire registry"""
        self._capability_index.clear()
        self._agent_capabilities.clear()
        self._agent_metadata.clear()


# Global instance
_registry: Optional[CapabilityRegistry] = None


def get_capability_registry() -> CapabilityRegistry:
    """Get the global capability registry"""
    global _registry
    if _registry is None:
        _registry = CapabilityRegistry()
    return _registry
