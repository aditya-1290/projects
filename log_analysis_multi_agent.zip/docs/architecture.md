# Architecture Documentation

## System Overview

The Log Analysis Multi-Agent System is a decentralized, peer-to-peer multi-agent system designed for analyzing logs from multiple sources. Built on Google ADK with an Agent-to-Agent (A2A) protocol.

## Layered Architecture

┌─────────────────────────────────────────┐
│ LAYER 1: CLI / User Interface │
│ main.py - Rich CLI │
└─────────────────────────────────────────┘
│
┌─────────────────────────────────────────┐
│ LAYER 2: Orchestrator │
│ Task decomposition & routing │
└─────────────────────────────────────────┘
│
┌─────────────────────────────────────────┐
│ LAYER 3: Communication Bus │
│ A2A Protocol, Pub/Sub │
└─────────────────────────────────────────┘
│
┌─────────────────────────────────────────┐
│ LAYER 4: Agents (Workers) │
│ Extractor, Preprocessor, Analyzer, │
│ Solver, Debugger, Critic, Memory │
└─────────────────────────────────────────┘
│
┌─────────────────────────────────────────┐
│ LAYER 5: Model Manager │
│ Gemma-4-E4B, Qwen2.5-3B, OCR │
└─────────────────────────────────────────┘
│
┌─────────────────────────────────────────┐
│ LAYER 6: Tools + Safety │
│ MCP Tools, Sandbox, Permissions │
└─────────────────────────────────────────┘
│
┌─────────────────────────────────────────┐
│ LAYER 7: Memory Store │
│ ChromaDB, Log Storage │
└─────────────────────────────────────────┘


## Agent Communication Flow

1. **User Input** → Orchestrator receives query
2. **Task Decomposition** → Orchestrator breaks into subtasks
3. **Agent Discovery** → Communication Bus finds capable agents
4. **Task Execution** → Agents process subtasks independently
5. **Result Aggregation** → Orchestrator combines results
6. **Validation** → Critic validates before output
7. **Memory Storage** → Results stored for future retrieval

## Key Design Decisions

- **Decentralized**: No single controller, agents communicate peer-to-peer
- **Capability Contracts**: Each agent declares what it can/cannot do
- **Multi-Model**: Different models for different tasks (Gemma for reasoning, Qwen for preprocessing)
- **CPU-Optimized**: Models loaded/unloaded based on memory pressure
- **Safety-First**: Multiple validation layers, command whitelist, sandbox

## Quick Start

1. Install dependencies: `pip install -r requirements.txt`
2. Download models: `bash scripts/download_models.sh`
3. Run system: `python main.py`

## Development

### Adding a New Agent

1. Create folder in `agents/`
2. Create `capabilities.json`
3. Create `agent.py` inheriting from `BaseAgent`
4. Implement `process()` method
5. Register in `main.py`

### Adding a New Tool

1. Create file in `tools/`
2. Inherit from `BaseTool`
3. Implement `execute()` method
4. Register in `tools/registry.py`