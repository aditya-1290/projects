
---

## FILE 82: `docs/agent_capabilities.md`

```markdown
# Agent Capabilities Reference

## Extractor Agent
- **Model**: Custom parsers + DeepSeek-OCR2
- **Can Do**: Extract from files (.log, .txt, .json, .csv, .xml), images (OCR), terminal output, pasted text
- **Cannot Do**: Proprietary binary formats, encrypted files, password-protected archives

## Preprocessor Agent
- **Model**: Qwen2.5-3B
- **Can Do**: Clean noise, parse structure, normalize timestamps/IPs, chunk large inputs
- **Cannot Do**: Interpret semantics, classify errors, generate solutions

## Analyzer Agent
- **Model**: Gemma-4-E4B
- **Can Do**: Classify log types, detect user intent, confidence scoring
- **Cannot Do**: Generate fixes, debug code, access external data

## Solver Agent
- **Model**: Gemma-4-E4B
- **Can Do**: Root cause analysis, high-level fix suggestions, explanations
- **Cannot Do**: Modify production code, execute fixes, access external systems

## Debugger Agent
- **Model**: Gemma-4-E4B
- **Can Do**: Parse stack traces, analyze code context, generate patches
- **Cannot Do**: Execute patches, modify infrastructure, analyze binary code

## Critic Agent
- **Model**: Gemma-4-E4B
- **Can Do**: Validate solutions, detect hallucinations, safety audit
- **Cannot Do**: Generate new solutions, access external data

## Memory Agent
- **Model**: Qwen2.5-3B + BGE-Small
- **Can Do**: Store analyses, retrieve similar cases, search by pattern
- **Cannot Do**: Generate new solutions independently

## Orchestrator Agent
- **Model**: Gemma-4-E4B
- **Can Do**: Decompose queries, discover agents, coordinate pipeline, handle edge cases
- **Cannot Do**: Perform specialized agent tasks directly
