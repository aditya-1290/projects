# Model Strategy

## Model Selection Rationale

### Gemma-4-E4B-IT (4B parameters, ~3GB Q4_K_M)
- **Purpose**: Primary reasoning engine
- **Used by**: Analyzer, Solver, Debugger, Critic, Orchestrator
- **Why**: Superior instruction following, good reasoning for analysis tasks
- **Context**: 8K tokens
- **Loading**: Always loaded

### Qwen2.5-3B-Instruct (3B parameters, ~2GB Q4_K_M)
- **Purpose**: Log preprocessing and memory retrieval
- **Used by**: Preprocessor, Memory Agent
- **Why**: Longer context (32K), faster inference for cleaning tasks
- **Context**: 32K tokens
- **Loading**: Always loaded

### DeepSeek-OCR2 (~2GB)
- **Purpose**: Image text extraction
- **Used by**: Extractor (image loader)
- **Why**: Specialized OCR model
- **Loading**: On-demand only

### BGE-Small-EN (~500MB)
- **Purpose**: Text embeddings
- **Used by**: Memory Agent (vector store)
- **Why**: Lightweight, good enough for log similarity
- **Loading**: Always loaded

## Memory Budget

| State | Models Loaded | Memory |
|-------|--------------|--------|
| Base | Gemma + Qwen + BGE | ~5.5GB |
| Peak | Base + DeepSeek-OCR2 | ~7.5GB |
| Free | - | ~8.5GB |

## Model Manager

- LRU eviction for on-demand models
- Automatic memory pressure detection
- Mock models for development without real models
- Graceful fallback when models unavailable