# ADK Setup Guide

## What is Google ADK?

Google Agent Development Kit (ADK) is a framework for building multi-agent systems. It provides:
- Agent lifecycle management
- Tool integration
- Message routing
- State management

## How We Use ADK

Our system uses ADK concepts but implements them custom for:
1. **A2A Protocol** - Custom message-based communication
2. **Capability Contracts** - Agent self-awareness
3. **Communication Bus** - Pub/sub message routing
4. **Model Manager** - Multi-model lifecycle

## Setup Steps

### 1. Install ADK
```bash
pip install google-adk

2. Project Structure
Our project follows ADK conventions:

log_multi_agent/
├── agents/          # All agent implementations
├── agentos/         # ADK runtime (custom)
├── tools/           # MCP-compatible tools
├── communication/   # A2A protocol
└── models/          # Model layer

3. Agent Registration
Agents register with the Communication Bus:
bus = CommunicationBus()
agent = ExtractorAgent()
await bus.register_agent(agent)

4. Running
python main.py

Development Without ADK
The system works without ADK installed. We use:

Custom BaseAgent class
Custom CommunicationBus
Custom A2A protocol

ADK concepts guide the architecture but are not required dependencies.