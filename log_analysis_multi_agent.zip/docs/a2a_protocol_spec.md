# A2A Protocol Specification

## Message Format

```json
{
  "message_id": "uuid",
  "correlation_id": "uuid (for request-response)",
  "sender_id": "agent_id",
  "sender_type": "extractor|preprocessor|analyzer|solver|debugger|critic|memory|orchestrator",
  "target_id": "agent_id or null",
  "target_type": "agent_type or null",
  "message_type": "request|response|broadcast|discovery|error|handoff|human_input_request",
  "priority": "low|normal|high|critical",
  "task": {},
  "response": {},
  "context": {},
  "confidence": 0.0-1.0,
  "caveats": [],
  "requires_human": false,
  "human_question": null,
  "error": null,
  "ttl": 10,
  "route_history": []
}

Message Types
REQUEST
Direct task delegation to a specific agent.

RESPONSE
Response to a REQUEST with results.

BROADCAST
Send to all subscribed agents.

DISCOVERY
Query to find agents with specific capabilities.

ERROR
Error notification.

HANDOFF
Transfer task to another agent.

HUMAN_INPUT_REQUEST
Request input from the human user.

Communication Patterns
Request-Response
Agent A → REQUEST → Agent B
Agent B → RESPONSE → Agent A

Discovery
Agent A → DISCOVERY → CommunicationBus
CommunicationBus → CAPABILITY_RESPONSE → Agent A
Agent A → REQUEST → Agent B (most capable)

Pub/Sub:
Agent A → BROADCAST → All subscribed agents

Capability Discovery
Agents discover each other by querying the Communication Bus with required capabilities:
{
  "required_capabilities": ["parse_stack_trace", "generate_code_patch"],
  "optional_capabilities": ["explain_code_changes"]
}

The bus returns ranked results based on capability match score.

