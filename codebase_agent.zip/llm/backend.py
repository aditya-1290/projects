"""
llm/backend.py - LlamaCpp backend wrapper optimized for Gemma 4.
"""

import multiprocessing
from typing import List, Dict, Any, Optional, Generator

from llama_cpp import Llama

from config.settings import settings
from utils.logger import log


class GemmaBackend:
    """
    LlamaCpp backend optimized for Gemma 4 E4B Instruct.

    Gemma 4 uses the same architecture as Gemma 3 but with:
    - 128K context window (E4B variant)
    - Improved instruction following
    - Better multilingual support
    - Enhanced reasoning capabilities
    """

    # Gemma 4 special tokens
    SPECIAL_TOKENS = {
        "bos": "<bos>",
        "eos": "<eos>",
        "user": "<start_of_turn>user",
        "model": "<start_of_turn>model",
        "system": "<start_of_turn>system",
        "end_turn": "<end_of_turn>",
    }

    def __init__(self, model_path: Optional[str] = None):
        """
        Initialize Gemma 4 backend.

        Args:
            model_path: Path to GGUF model file (uses settings.MODEL_PATH if None)
        """
        self.model_path = model_path or settings.MODEL_PATH

        log.info(f"Loading Gemma 4 model from {self.model_path}")

        # Load model with Gemma-optimized settings
        self.llm = Llama(
            model_path=self.model_path,
            n_ctx=settings.N_CTX,
            n_threads=settings.N_THREADS or multiprocessing.cpu_count(),
            n_batch=settings.N_BATCH,
            n_gpu_layers=settings.N_GPU_LAYERS,
            use_mmap=True,
            use_mlock=False,
            verbose=False,
        )

        self.context_size = settings.N_CTX
        self.reserved_tokens = 512
        self.max_input_tokens = self.context_size - self.reserved_tokens

        log.info(f"Gemma 4 loaded ✅")
        log.info(f"  Context: {self.context_size} tokens")
        log.info(f"  Max input: {self.max_input_tokens} tokens")
        log.info(f"  Threads: {settings.N_THREADS or multiprocessing.cpu_count()}")

        self.stats = {
            "total_requests": 0,
            "total_tokens": 0,
            "truncations": 0,
        }

    def _format_gemma_messages(self, messages: List[Dict[str, str]]) -> str:
        """
        Format messages for Gemma 4 chat template.

        Gemma 4 expects:
        <start_of_turn>user
        {message}
        <end_of_turn>
        <start_of_turn>model
        {response}
        <end_of_turn>
        """
        formatted = []

        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")

            if role == "system":
                formatted.append(f"{self.SPECIAL_TOKENS['system']}\n{content}{self.SPECIAL_TOKENS['end_turn']}")
            elif role == "user":
                formatted.append(f"{self.SPECIAL_TOKENS['user']}\n{content}{self.SPECIAL_TOKENS['end_turn']}")
            elif role == "assistant":
                formatted.append(f"{self.SPECIAL_TOKENS['model']}\n{content}{self.SPECIAL_TOKENS['end_turn']}")

        # Add final model turn for generation
        formatted.append(f"{self.SPECIAL_TOKENS['model']}\n")

        return "\n".join(formatted)

    def _estimate_tokens(self, text: str) -> int:
        """Rough token estimation for Gemma (similar to other LLMs)."""
        if not text:
            return 0
        # Gemma uses SentencePiece tokenizer - roughly 4 chars per token for English
        return len(text) // 4

    def _truncate_messages(self, messages: List[Dict[str, str]], max_tokens: int) -> List[Dict[str, str]]:
        """Truncate messages to fit context window."""
        if not messages:
            return messages

        total_text = self._format_gemma_messages(messages)
        estimated_tokens = self._estimate_tokens(total_text)

        if estimated_tokens <= max_tokens:
            return messages

        self.stats["truncations"] += 1
        log.warning(f"[Gemma] Truncating: ~{estimated_tokens} → {max_tokens} tokens")

        # Keep system messages, truncate oldest user/assistant messages
        system_msgs = [m for m in messages if m.get("role") == "system"]
        other_msgs = [m for m in messages if m.get("role") != "system"]

        # Keep most recent messages
        truncated = system_msgs.copy()
        remaining = max_tokens - self._estimate_tokens(self._format_gemma_messages(system_msgs))

        for msg in reversed(other_msgs[-10:]):  # Check last 10 messages
            msg_tokens = self._estimate_tokens(msg.get("content", ""))
            if remaining - msg_tokens > 0:
                truncated.insert(len(system_msgs), msg)
                remaining -= msg_tokens
            else:
                break

        return truncated

    def chat(
            self,
            messages: List[Dict[str, str]],
            temperature: Optional[float] = None,
            max_tokens: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Generate chat completion using Gemma 4.

        Args:
            messages: List of message dicts with 'role' and 'content'
            temperature: Sampling temperature (uses settings.TEMPERATURE if None)
            max_tokens: Max tokens to generate (uses settings.MAX_TOKENS if None)
        """
        self.stats["total_requests"] += 1

        temp = temperature if temperature is not None else settings.TEMPERATURE
        max_tok = max_tokens if max_tokens is not None else settings.MAX_TOKENS

        # Truncate if needed
        safe_messages = self._truncate_messages(messages, self.max_input_tokens)

        # Format for Gemma
        prompt = self._format_gemma_messages(safe_messages)

        try:
            response = self.llm(
                prompt,
                max_tokens=max_tok,
                temperature=temp,
                top_p=settings.TOP_P,
                top_k=settings.TOP_K,
                repeat_penalty=settings.REPEAT_PENALTY,
                echo=False,
                stop=[self.SPECIAL_TOKENS["end_turn"], "<end_of_turn>"],
            )

            content = response["choices"][0]["text"].strip()
            self.stats["total_tokens"] += response.get("usage", {}).get("total_tokens", 0)

            return {
                "role": "assistant",
                "content": content,
            }

        except Exception as e:
            log.error(f"[Gemma] Chat error: {e}")
            return {
                "role": "assistant",
                "content": "I encountered an error processing your request. Please try again.",
            }

    def stream_chat(
            self,
            messages: List[Dict[str, str]],
            temperature: Optional[float] = None,
            max_tokens: Optional[int] = None,
    ) -> Generator[str, None, None]:
        """
        Stream chat completion tokens.

        Args:
            messages: List of message dicts
            temperature: Sampling temperature
            max_tokens: Max tokens to generate

        Yields:
            String tokens as they're generated
        """
        self.stats["total_requests"] += 1

        temp = temperature if temperature is not None else settings.TEMPERATURE
        max_tok = max_tokens if max_tokens is not None else settings.MAX_TOKENS

        safe_messages = self._truncate_messages(messages, self.max_input_tokens)
        prompt = self._format_gemma_messages(safe_messages)

        try:
            stream = self.llm(
                prompt,
                max_tokens=max_tok,
                temperature=temp,
                top_p=settings.TOP_P,
                top_k=settings.TOP_K,
                repeat_penalty=settings.REPEAT_PENALTY,
                echo=False,
                stream=True,
                stop=[self.SPECIAL_TOKENS["end_turn"], "<end_of_turn>"],
            )

            for chunk in stream:
                token = chunk["choices"][0].get("text", "")
                if token:
                    yield token

        except Exception as e:
            log.error(f"[Gemma] Stream error: {e}")
            yield "Error generating response."

    def get_stats(self) -> Dict[str, Any]:
        """Get backend statistics."""
        return {
            **self.stats,
            "context_size": self.context_size,
            "model_path": self.model_path,
        }


# Singleton instance
_backend: Optional[GemmaBackend] = None


def get_llm() -> GemmaBackend:
    """Get or create the LLM backend singleton."""
    global _backend
    if _backend is None:
        _backend = GemmaBackend()
    return _backend