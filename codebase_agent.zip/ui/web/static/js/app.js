/**
 * app.js - Main application JavaScript for CodeBase Agent Web UI
 */

// Configuration
const API_BASE = '/api';
let sessionId = null;
let isProcessing = false;
let messages = [];
let activities = [];

// DOM Elements
const messagesContainer = document.getElementById('messages');
const chatInput = document.getElementById('chat-input');
const sendBtn = document.getElementById('send-btn');
const activityFeed = document.getElementById('activity-feed');
const connectionStatus = document.getElementById('connection-status');

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    initSession();
    setupEventListeners();
    startStatusPolling();
    setWelcomeTime();
});

function setWelcomeTime() {
    const timeEl = document.getElementById('welcome-time');
    if (timeEl) {
        timeEl.textContent = new Date().toLocaleTimeString();
    }
}

function setupEventListeners() {
    chatInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });

    chatInput.addEventListener('input', autoResize);
}

function autoResize() {
    chatInput.style.height = 'auto';
    chatInput.style.height = Math.min(chatInput.scrollHeight, 200) + 'px';
}

async function initSession() {
    try {
        const res = await fetch(`${API_BASE}/chat`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: 'Hello', stream: false })
        });
        const data = await res.json();
        sessionId = data.session_id;
        addActivity('Session initialized', 'success');
    } catch (e) {
        console.error('Session init error:', e);
        addActivity('Failed to initialize session', 'error');
    }
}

async function sendMessage() {
    const message = chatInput.value.trim();
    if (!message || isProcessing) return;

    // Add user message
    addMessage('user', message, 'You');
    chatInput.value = '';
    chatInput.style.height = 'auto';

    // Show processing state
    isProcessing = true;
    sendBtn.disabled = true;
    updateConnectionStatus('busy', 'Processing...');

    // Add thinking placeholder
    const thinkingId = addMessage('agent', '🤔 Thinking...', 'Orchestrator', true);

    try {
        const res = await fetch(`${API_BASE}/chat`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message, session_id: sessionId, stream: false })
        });

        const data = await res.json();

        // Update the thinking message with actual response
        updateMessage(thinkingId, data.answer, 'Orchestrator');

        addActivity(`Response generated in ${data.time_taken}s`, 'info');
        updateConnectionStatus('online', 'Connected');

        // Update stats
        updateStats();
    } catch (e) {
        updateMessage(thinkingId, `Error: ${e.message}`, 'Orchestrator');
        addActivity(`Error: ${e.message}`, 'error');
        updateConnectionStatus('error', 'Error');
    } finally {
        isProcessing = false;
        sendBtn.disabled = false;
        chatInput.focus();
    }
}

function addMessage(type, text, sender, isPlaceholder = false) {
    const id = 'msg-' + Date.now() + '-' + Math.random().toString(36).substr(2, 5);

    const msgDiv = document.createElement('div');
    msgDiv.className = `message ${type}`;
    msgDiv.id = id;

    const avatar = type === 'user' ? '👤' : getAgentAvatar(sender);
    const time = new Date().toLocaleTimeString();

    msgDiv.innerHTML = `
        <div class="message-avatar">${avatar}</div>
        <div class="message-content">
            <div class="message-header">
                <span class="message-sender">${sender}</span>
                <span class="message-time">${time}</span>
            </div>
            <div class="message-text">${isPlaceholder ? text : formatMessage(text)}</div>
        </div>
    `;

    messagesContainer.appendChild(msgDiv);
    scrollToBottom();

    messages.push({ id, type, text, sender, time });

    return id;
}

function updateMessage(id, text, sender) {
    const msgDiv = document.getElementById(id);
    if (msgDiv) {
        const textDiv = msgDiv.querySelector('.message-text');
        textDiv.innerHTML = formatMessage(text);

        const senderSpan = msgDiv.querySelector('.message-sender');
        if (senderSpan) {
            senderSpan.textContent = sender;
        }

        const avatarDiv = msgDiv.querySelector('.message-avatar');
        if (avatarDiv) {
            avatarDiv.textContent = getAgentAvatar(sender);
        }
    }
}

function getAgentAvatar(sender) {
    const avatars = {
        'Orchestrator': '🎭',
        'CodeAgent': '💻',
        'SearchAgent': '🔍',
        'DataAgent': '📊',
        'GitHubAgent': '🐙',
        'UtilityAgent': '🔧',
        'ReviewAgent': '✅',
    };
    return avatars[sender] || '🤖';
}

function formatMessage(text) {
    if (!text) return '';

    // Escape HTML
    text = text.replace(/</g, '&lt;').replace(/>/g, '&gt;');

    // Code blocks
    text = text.replace(/```(\w*)\n([\s\S]*?)```/g, (match, lang, code) => {
        return `<pre><code class="language-${lang}">${escapeHtml(code.trim())}</code></pre>`;
    });

    // Inline code
    text = text.replace(/`([^`]+)`/g, '<code>$1</code>');

    // Bold
    text = text.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');

    // Italic
    text = text.replace(/\*([^*]+)\*/g, '<em>$1</em>');

    // Links
    text = text.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank">$1</a>');

    // Line breaks
    text = text.replace(/\n/g, '<br>');

    return text;
}

function escapeHtml(text) {
    return text.replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function addActivity(text, type = 'info') {
    const time = new Date().toLocaleTimeString();

    const activityItem = document.createElement('div');
    activityItem.className = 'activity-item';
    activityItem.innerHTML = `
        <span class="activity-time">${time}</span>
        <span class="activity-text">${getActivityIcon(type)} ${text}</span>
    `;

    activityFeed.insertBefore(activityItem, activityFeed.firstChild);

    // Keep only last 20 activities
    while (activityFeed.children.length > 20) {
        activityFeed.removeChild(activityFeed.lastChild);
    }

    activities.unshift({ time, text, type });
}

function getActivityIcon(type) {
    const icons = {
        'success': '✅',
        'error': '❌',
        'warning': '⚠️',
        'info': 'ℹ️',
        'tool': '⚙️',
        'agent': '🤖',
    };
    return icons[type] || '•';
}

function updateConnectionStatus(status, text) {
    const statusDot = connectionStatus.querySelector('.status-dot');
    statusDot.className = `status-dot ${status}`;

    const statusText = connectionStatus.querySelector('span:last-child');
    if (statusText) {
        statusText.textContent = text;
    }
}

function scrollToBottom() {
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

async function updateStats() {
    try {
        const res = await fetch(`${API_BASE}/system/status`);
        const data = await res.json();

        document.getElementById('stat-sessions').textContent = data.session_count || 0;
        document.getElementById('stat-cache').textContent = data.cache?.tool_cache?.hit_rate || '0%';
        document.getElementById('stat-tools').textContent = data.tool_count || 24;
        document.getElementById('stat-memory').textContent = data.memory?.main || 0;

        // Update agent statuses
        updateAgentStatuses(data);
    } catch (e) {
        console.error('Stats error:', e);
    }
}

function updateAgentStatuses(data) {
    // This will be implemented in agents.js
    if (typeof updateAgentCards === 'function') {
        updateAgentCards(data);
    }
}

function startStatusPolling() {
    updateStats();
    setInterval(updateStats, 5000);
}

function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    sidebar.classList.toggle('collapsed');
}

function clearChat() {
    messagesContainer.innerHTML = '';
    messages = [];
    addMessage('agent', 'Chat cleared. How can I help you?', 'Orchestrator');
}