/**
 * agents.js - Multi-agent management for Web UI
 */

// Agent configurations
const agents = [
    { id: 'orchestrator', name: 'Orchestrator', icon: '🎭', role: 'orchestrator', elementId: null },
    { id: 'code-agent', name: 'Code Agent', icon: '💻', role: 'code', elementId: 'code-agent' },
    { id: 'search-agent', name: 'Search Agent', icon: '🔍', role: 'search', elementId: 'search-agent' },
    { id: 'data-agent', name: 'Data Agent', icon: '📊', role: 'data', elementId: 'data-agent' },
    { id: 'github-agent', name: 'GitHub Agent', icon: '🐙', role: 'github', elementId: 'github-agent' },
    { id: 'utility-agent', name: 'Utility Agent', icon: '🔧', role: 'utility', elementId: 'utility-agent' },
    { id: 'review-agent', name: 'Review Agent', icon: '✅', role: 'review', elementId: 'review-agent' },
];

// Task queue
let taskQueue = [];
let activeAgents = new Map();

// Initialize agent UI
document.addEventListener('DOMContentLoaded', () => {
    initializeAgentCards();
    startTaskPolling();
});

function initializeAgentCards() {
    // Set initial status for all agents
    agents.forEach(agent => {
        updateAgentStatus(agent.id, 'idle', 'Ready for tasks');
    });

    // Orchestrator is always online
    updateAgentStatus('orchestrator', 'online', 'Coordinating tasks...');

    // Add click handlers to agent cards
    agents.forEach(agent => {
        const card = document.getElementById(agent.elementId);
        if (card) {
            card.style.cursor = 'pointer';
            card.addEventListener('click', () => onAgentClick(agent));
        }
    });
}

function onAgentClick(agent) {
    // Show agent details in activity feed
    addActivity(`👆 Clicked on ${agent.name}`, 'info');

    // Highlight the agent card briefly
    const card = document.getElementById(agent.elementId);
    if (card) {
        card.style.transition = 'border 0.3s ease';
        card.style.border = '2px solid var(--accent)';
        setTimeout(() => {
            card.style.border = '1px solid var(--border)';
        }, 500);
    }

    // Show agent capabilities
    const capabilities = getAgentCapabilities(agent.role);
    addActivity(`${agent.name} capabilities: ${capabilities.join(', ')}`, 'agent');
}

function getAgentCapabilities(role) {
    const caps = {
        'code': ['File operations', 'Code analysis', 'Command execution', 'Git operations'],
        'search': ['Web search', 'News fetching', 'Timeline building', 'Research'],
        'data': ['Weather', 'Stocks', 'Currency', 'Time/Date', 'Gold price'],
        'github': ['Repo indexing', 'Code search', 'User info', 'File retrieval'],
        'utility': ['Calculations', 'Unit conversion', 'Math operations'],
        'review': ['Answer evaluation', 'Quality scoring', 'Refinement'],
        'orchestrator': ['Task decomposition', 'Agent routing', 'Result synthesis'],
    };
    return caps[role] || ['General tasks'];
}

function updateAgentStatus(agentId, status, message) {
    // Find the agent card - either by specific elementId or by agent id
    let card;
    const agent = agents.find(a => a.id === agentId);

    if (agent && agent.elementId) {
        card = document.getElementById(agent.elementId);
    } else {
        card = document.getElementById(agentId);
    }

    if (!card) return;

    const statusEl = card.querySelector('.status');
    const descEl = card.querySelector('.agent-desc');

    if (statusEl) {
        statusEl.className = `status ${status}`;
        statusEl.textContent = status === 'online' ? '●' : '●';
    }

    if (descEl) {
        descEl.textContent = message;
    }

    activeAgents.set(agentId, { status, message, lastUpdated: Date.now() });
}

function updateAgentCards(systemData) {
    // This is called from app.js with system status data

    // Orchestrator is always online
    updateAgentStatus('orchestrator', 'online', 'Coordinating tasks...');

    // Update other agents based on system data if available
    if (systemData && systemData.agents) {
        // Future: use real agent status from API
    }

    // Keep idle agents as idle if no recent activity
    agents.forEach(agent => {
        if (agent.id !== 'orchestrator') {
            const info = activeAgents.get(agent.id);
            if (!info || Date.now() - info.lastUpdated > 30000) {
                updateAgentStatus(agent.id, 'idle', 'Ready for tasks');
            }
        }
    });
}

function addTask(task) {
    task.id = 'task-' + Date.now() + '-' + Math.random().toString(36).substr(2, 5);
    task.status = task.status || 'pending';
    taskQueue.push(task);
    renderTaskList();

    // Add activity
    addActivity(`📋 New task: ${task.description}`, 'tool');

    return task.id;
}

function updateTask(taskId, updates) {
    const task = taskQueue.find(t => t.id === taskId);
    if (task) {
        const oldStatus = task.status;
        Object.assign(task, updates);
        renderTaskList();

        // Update agent status based on task
        if (updates.agent) {
            const agentId = getAgentIdFromName(updates.agent);
            if (updates.status === 'running') {
                updateAgentStatus(agentId, 'busy', `Working on: ${task.description}`);
            } else if (updates.status === 'completed') {
                updateAgentStatus(agentId, 'online', 'Task completed');
                setTimeout(() => {
                    updateAgentStatus(agentId, 'idle', 'Ready for tasks');
                }, 2000);
            } else if (updates.status === 'failed') {
                updateAgentStatus(agentId, 'idle', `Failed: ${task.description}`);
            }
        }

        // Add activity for status change
        if (oldStatus !== updates.status) {
            addActivity(`🔄 Task ${taskId}: ${oldStatus} → ${updates.status}`, 'info');
        }
    }
}

function getAgentIdFromName(agentName) {
    const mapping = {
        'Orchestrator': 'orchestrator',
        'CodeAgent': 'code-agent',
        'SearchAgent': 'search-agent',
        'DataAgent': 'data-agent',
        'GitHubAgent': 'github-agent',
        'UtilityAgent': 'utility-agent',
        'ReviewAgent': 'review-agent',
    };
    return mapping[agentName] || 'orchestrator';
}

function removeTask(taskId) {
    const index = taskQueue.findIndex(t => t.id === taskId);
    if (index !== -1) {
        const task = taskQueue[index];
        taskQueue.splice(index, 1);
        renderTaskList();
        addActivity(`✅ Task completed: ${task.description}`, 'success');
    }
}

function renderTaskList() {
    const taskList = document.getElementById('task-list');
    if (!taskList) return;

    if (taskQueue.length === 0) {
        taskList.innerHTML = '<div class="empty-state">No active tasks</div>';
        return;
    }

    // Show only pending and running tasks
    const activeTasks = taskQueue.filter(t => t.status === 'pending' || t.status === 'running');

    if (activeTasks.length === 0) {
        taskList.innerHTML = '<div class="empty-state">No active tasks</div>';
        return;
    }

    taskList.innerHTML = activeTasks.map(task => `
        <div class="task-item" id="${task.id}">
            <div class="task-header">
                <span class="task-agent">${task.agent || 'Pending'}</span>
                <span class="task-status ${task.status}">${task.status || 'pending'}</span>
            </div>
            <div class="task-desc">${task.description.substring(0, 50)}${task.description.length > 50 ? '...' : ''}</div>
            ${task.progress !== undefined ? `
                <div class="task-progress">
                    <div class="progress-bar" style="width: ${task.progress}%"></div>
                </div>
            ` : ''}
        </div>
    `).join('');
}

async function startTaskPolling() {
    // Poll for agent status from API
    setInterval(async () => {
        try {
            const res = await fetch('/api/agents/status');
            if (res.ok) {
                const data = await res.json();
                if (data.agents) {
                    data.agents.forEach(agentStatus => {
                        const agentId = getAgentIdFromName(agentStatus.name);
                        if (agentStatus.current_task) {
                            updateAgentStatus(agentId, 'busy', agentStatus.current_task);
                        } else {
                            updateAgentStatus(agentId, 'idle', 'Ready for tasks');
                        }
                    });
                }
            }
        } catch (e) {
            // Silently fail - API might not be ready
            console.debug('Agent status poll failed:', e);
        }
    }, 5000);
}

function showDelegation(fromAgent, toAgent, task) {
    addActivity(`${fromAgent} → ${toAgent}: ${task}`, 'agent');
}

// Helper function to add activity (calls app.js function if available)
function addActivity(text, type = 'info') {
    if (typeof window.addActivity === 'function') {
        window.addActivity(text, type);
    } else {
        console.log(`[Activity] ${type}: ${text}`);
    }
}

// Export for use in app.js
window.updateAgentCards = updateAgentCards;
window.showDelegation = showDelegation;
window.addTask = addTask;
window.updateTask = updateTask;
window.removeTask = removeTask;
window.updateAgentStatus = updateAgentStatus;