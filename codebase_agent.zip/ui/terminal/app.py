"""
ui/terminal/app.py - Rich terminal UI for the agent.
"""

import os
import sys
from typing import Optional
from datetime import datetime

try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.syntax import Syntax
    from rich.markdown import Markdown
    from rich.table import Table
    from rich.progress import Progress, SpinnerColumn, TextColumn
    from rich.prompt import Prompt, Confirm
    from rich.layout import Layout
    from rich.live import Live
    from rich.tree import Tree

    RICH_AVAILABLE = True
except ImportError:
    print("⚠️ Rich not installed. Install with: pip install rich")
    RICH_AVAILABLE = False
    Console = object

try:
    from prompt_toolkit import PromptSession
    from prompt_toolkit.history import FileHistory
    from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
    from prompt_toolkit.styles import Style

    PROMPT_TOOLKIT_AVAILABLE = True
except ImportError:
    PROMPT_TOOLKIT_AVAILABLE = False

from core.orchestrator import AgentOrchestrator
from core.session import get_session_manager
from memory.cache import tool_cache
from config.settings import settings
from tools import list_tools, get_tools_by_category
from utils.logger import log


class TerminalAgent:
    """Rich terminal-based agent interface."""

    def __init__(self, config_path: Optional[str] = None):
        if not RICH_AVAILABLE:
            print("Rich library required. Install with: pip install rich")
            sys.exit(1)

        self.console = Console()
        self.session_mgr = get_session_manager()
        self.session_id = self.session_mgr.create_session()
        self.orchestrator = AgentOrchestrator(self.session_id)
        self.conversation_history = []
        self.running = True

        # Prompt toolkit session
        if PROMPT_TOOLKIT_AVAILABLE:
            history_path = os.path.expanduser("~/.agent_history")
            self.prompt_session = PromptSession(
                history=FileHistory(history_path),
                auto_suggest=AutoSuggestFromHistory(),
            )
        else:
            self.prompt_session = None

    def _print_banner(self):
        """Print welcome banner."""
        banner = f"""
╔══════════════════════════════════════════════════════════════════╗
║                                                                  ║
║   ██████╗  ██████╗ ██████╗ ███████╗██████╗  █████╗ ███████╗██╗ ║
║   ██╔════╝ ██╔═══██╗██╔══██╗██╔════╝██╔══██╗██╔══██╗██╔════╝██║ ║
║   ██║      ██║   ██║██║  ██║█████╗  ██████╔╝███████║███████╗██║ ║
║   ██║      ██║   ██║██║  ██║██╔══╝  ██╔══██╗██╔══██║╚════██║╚═╝ ║
║   ╚██████╗ ╚██████╔╝██████╔╝███████╗██████╔╝██║  ██║███████║██╗ ║
║    ╚═════╝  ╚═════╝ ╚═════╝ ╚══════╝╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝ ║
║                                                                  ║
║                    CodeBase Agent Terminal                        ║
║                         Version 2.0.0                              ║
╠══════════════════════════════════════════════════════════════════╣
║  Session: {self.session_id[:8]}...                                            ║
║  Type /help for commands • Ctrl+C to interrupt • Ctrl+D to exit   ║
╚══════════════════════════════════════════════════════════════════╝
        """
        self.console.print(banner, style="bold cyan")

    def _print_help(self):
        """Print help message."""
        help_text = """
╔══════════════════════════════════════════════════════════════════╗
║                         AVAILABLE COMMANDS                         ║
╠══════════════════════════════════════════════════════════════════╣
║ /help          Show this help message                             ║
║ /clear         Clear the screen                                   ║
║ /history       Show conversation history                          ║
║ /tools         List available tools                               ║
║ /cache         Show cache statistics                              ║
║ /stats         Show session statistics                            ║
║ /theme         Change color theme                                 ║
║ /exit, /quit   Exit the agent                                     ║
╠══════════════════════════════════════════════════════════════════╣
║ Keyboard Shortcuts:                                                ║
║   Ctrl+C       Interrupt current operation                        ║
║   Ctrl+D       Exit (on empty line)                               ║
║   Ctrl+L       Clear screen                                       ║
║   ↑/↓          Navigate history                                   ║
╚══════════════════════════════════════════════════════════════════╝
        """
        self.console.print(help_text, style="bold blue")

    def _print_tools(self):
        """List available tools."""
        categories = get_tools_by_category()

        tree = Tree("🔧 Available Tools", guide_style="bold bright_blue")

        for category, tools in categories.items():
            cat_node = tree.add(f"[bold yellow]{category.replace('_', ' ').title()}[/bold yellow]")
            for tool in sorted(tools):
                cat_node.add(f"[green]{tool}[/green]")

        self.console.print(tree)
        self.console.print(f"\n[dim]Total: {len(list_tools())} tools available[/dim]")

    def _print_stats(self):
        """Print session statistics."""
        stats = self.session_mgr.get_stats()
        cache_stats = tool_cache.stats()

        table = Table(title="Session Statistics", box=None)
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="yellow")

        table.add_row("Session ID", self.session_id[:16] + "...")
        table.add_row("Messages", str(len(self.conversation_history)))
        table.add_row("Cache Entries", str(cache_stats["entries"]))
        table.add_row("Cache Hit Rate", cache_stats["hit_rate"])
        table.add_row("Active Sessions", str(stats["active_sessions"]))

        self.console.print(table)

    def _progress_callback(self, event_type: str, message: str):
        """Handle progress updates."""
        icons = {
            "thinking": "🤔",
            "tool_start": "⚙️",
            "tool_complete": "✅",
            "generating": "📝",
            "refining": "🔄",
        }
        icon = icons.get(event_type, "•")
        self.console.print(f"  {icon} {message}", style="dim")

    def _handle_command(self, user_input: str) -> bool:
        """Handle slash commands. Returns True if command was handled."""
        cmd = user_input.lower().strip()

        if cmd in ["/help", "/h"]:
            self._print_help()
            return True

        if cmd in ["/clear", "/cls"]:
            os.system('cls' if os.name == 'nt' else 'clear')
            self._print_banner()
            return True

        if cmd == "/history":
            if not self.conversation_history:
                self.console.print("[dim]No conversation history[/dim]")
            else:
                for i, entry in enumerate(self.conversation_history[-10:], 1):
                    role = entry["role"].upper()
                    content = entry["content"][:100]
                    self.console.print(f"[cyan]{i}. {role}:[/cyan] {content}...")
            return True

        if cmd == "/tools":
            self._print_tools()
            return True

        if cmd == "/cache":
            stats = tool_cache.stats()
            self.console.print(f"[cyan]Cache Entries:[/cyan] {stats['entries']}")
            self.console.print(f"[cyan]Hits/Misses:[/cyan] {stats['hits']}/{stats['misses']}")
            self.console.print(f"[cyan]Hit Rate:[/cyan] {stats['hit_rate']}")
            return True

        if cmd == "/stats":
            self._print_stats()
            return True

        if cmd in ["/exit", "/quit", "/q"]:
            self.running = False
            return True

        return False

    def _get_input(self) -> Optional[str]:
        """Get user input."""
        try:
            if self.prompt_session:
                return self.prompt_session.prompt("You: ")
            else:
                return input("You: ")
        except KeyboardInterrupt:
            return None
        except EOFError:
            return None

    def run(self):
        """Main loop."""
        self._print_banner()

        while self.running:
            try:
                user_input = self._get_input()

                if user_input is None:
                    self.console.print("\n[yellow]Goodbye![/yellow]")
                    break

                user_input = user_input.strip()
                if not user_input:
                    continue

                # Handle commands
                if user_input.startswith("/"):
                    self._handle_command(user_input)
                    continue

                # Process query
                self.conversation_history.append({"role": "user", "content": user_input})

                with Progress(
                        SpinnerColumn(),
                        TextColumn("[progress.description]{task.description}"),
                        transient=True,
                ) as progress:
                    task = progress.add_task("[cyan]Thinking...", total=None)

                    try:
                        answer = self.orchestrator.run(
                            user_input,
                            progress_callback=self._progress_callback
                        )
                    except Exception as e:
                        progress.update(task, description=f"[red]Error: {e}")
                        answer = f"Error: {e}"

                self.conversation_history.append({"role": "assistant", "content": answer})

                # Display response
                self.console.print()
                self.console.print("[bold green]Agent:[/bold green]", end=" ")

                # Format with markdown if it looks like markdown
                if "```" in answer or "**" in answer or "#" in answer:
                    md = Markdown(answer)
                    self.console.print(md)
                else:
                    self.console.print(answer)

                self.console.print()

            except KeyboardInterrupt:
                self.console.print("\n[yellow]Use /exit to quit[/yellow]")
                continue
            except Exception as e:
                self.console.print(f"[red]Error: {e}[/red]")
                log.error(f"Terminal error: {e}")
                continue

        self.console.print("\n[green]👋 Goodbye![/green]\n")


def main():
    """Entry point for terminal UI."""
    agent = TerminalAgent()
    agent.run()


if __name__ == "__main__":
    main()
