"""
config/settings.py - Centralized configuration management.
Optimized for Gemma 4 E4B Instruct model.
"""

import os
from pathlib import Path
from typing import Optional, Dict, Any
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Base paths
BASE_DIR = Path(__file__).parent.parent
DATA_DIR = BASE_DIR / "data"
MODELS_DIR = BASE_DIR / "D:/python_tasks/models"

# Ensure directories exist
DATA_DIR.mkdir(parents=True, exist_ok=True)
(DATA_DIR / "chroma_db").mkdir(parents=True, exist_ok=True)
(DATA_DIR / "cache").mkdir(parents=True, exist_ok=True)
(DATA_DIR / "sessions").mkdir(parents=True, exist_ok=True)


class Settings:
    """Centralized settings for the entire application."""

    # =========================================================================
    # LLM Settings - OPTIMIZED FOR GEMMA 4 E4B
    # =========================================================================
    MODEL_PATH: str = os.getenv("MODEL_PATH", str(MODELS_DIR / "gemma-4-E4B-it-Q5_K_M.gguf"))

    # Gemma 4 Context Settings
    # The E4B variant supports up to 128K context, but Q5_K_M is optimized for 32K
    N_CTX: int = int(os.getenv("N_CTX", "32768"))  # 32K context window
    N_THREADS: Optional[int] = int(os.getenv("N_THREADS", "0")) or None  # Auto-detect CPU cores
    N_BATCH: int = int(os.getenv("N_BATCH", "512"))  # Batch size for processing
    N_GPU_LAYERS: int = int(os.getenv("N_GPU_LAYERS", "0"))  # Set >0 for GPU offloading

    # Generation Settings
    TEMPERATURE: float = float(os.getenv("TEMPERATURE", "0.7"))
    TOP_P: float = float(os.getenv("TOP_P", "0.95"))
    TOP_K: int = int(os.getenv("TOP_K", "40"))
    MAX_TOKENS: int = int(os.getenv("MAX_TOKENS", "1024"))  # Gemma can generate longer responses
    REPEAT_PENALTY: float = float(os.getenv("REPEAT_PENALTY", "1.1"))

    # Gemma 4 specific chat template settings
    CHAT_TEMPLATE: str = """
{%- for message in messages %}
<start_of_turn>{{ message['role'] }}
{{ message['content'] }}
<end_of_turn>
{%- endfor %}
<start_of_turn>model
""".strip()

    # System prompt wrapper for Gemma
    SYSTEM_PROMPT_WRAPPER: str = "<start_of_turn>system\n{content}<end_of_turn>\n"

    # =========================================================================
    # API Keys
    # =========================================================================
    API_NINJAS_KEY: Optional[str] = os.getenv("API_NINJAS_KEY")
    EXCHANGERATE_KEY: Optional[str] = os.getenv("EXCHANGERATE_KEY")
    NEWS_API_KEY: Optional[str] = os.getenv("NEWS_DATA_API_KEY")
    GITHUB_TOKEN: Optional[str] = os.getenv("GITHUB_TOKEN")

    # =========================================================================
    # Agent Settings
    # =========================================================================
    MAX_REACT_CYCLES: int = int(os.getenv("MAX_REACT_CYCLES", "5"))
    CONFIDENCE_THRESHOLD: float = float(os.getenv("CONFIDENCE_THRESHOLD", "0.6"))
    TOOL_RETRY_COUNT: int = int(os.getenv("TOOL_RETRY_COUNT", "2"))
    TOOL_TIMEOUT: int = int(os.getenv("TOOL_TIMEOUT", "15"))
    MAX_REFINEMENTS: int = int(os.getenv("MAX_REFINEMENTS", "2"))

    # =========================================================================
    # Cache Settings
    # =========================================================================
    TOOL_CACHE_TTL: Dict[str, int] = {
        "get_current_time": 60,
        "get_date_info": 60,
        "get_world_clock": 60,
        "get_weather": 600,
        "get_stock_price": 300,
        "get_gold_price": 300,
        "convert_currency": 3600,
        "get_news": 1800,
        "web_search": 300,
        "calculate": 86400,
        "convert_units": 86400,
    }
    DEFAULT_TOOL_TTL: int = 300
    RESPONSE_CACHE_TTL: int = 3600

    # =========================================================================
    # Memory Settings
    # =========================================================================
    CHROMA_DB_PATH: str = str(DATA_DIR / "chroma_db")
    MAX_MEMORY_ITEMS: int = 500
    MAX_FAILURE_ITEMS: int = 200
    MEMORY_FILE: str = str(DATA_DIR / "memory.json")

    # =========================================================================
    # Session Settings
    # =========================================================================
    SESSION_DIR: str = str(DATA_DIR / "sessions")
    SESSION_HISTORY_SIZE: int = 20
    SESSION_CLEANUP_HOURS: int = 24

    # =========================================================================
    # API Settings
    # =========================================================================
    API_HOST: str = os.getenv("API_HOST", "0.0.0.0")
    API_PORT: int = int(os.getenv("API_PORT", "8080"))
    API_RELOAD: bool = os.getenv("API_RELOAD", "true").lower() == "true"
    CORS_ORIGINS: list = ["*"]

    # =========================================================================
    # Logging Settings
    # =========================================================================
    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")
    LOG_FILE: str = str(BASE_DIR / "agent.log")
    LOG_FORMAT: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

    @classmethod
    def as_dict(cls) -> Dict[str, Any]:
        """Return settings as dictionary (excluding private/sensitive)."""
        return {
            k: v for k, v in cls.__dict__.items()
            if not k.startswith("_") and not k.endswith("_KEY") and not k.endswith("_TOKEN")
        }

    @classmethod
    def validate(cls) -> list:
        """Validate required settings. Returns list of missing items."""
        missing = []

        if not Path(cls.MODEL_PATH).exists():
            missing.append(f"Model file not found: {cls.MODEL_PATH}")

        # Check API keys (warn but don't fail)
        api_keys = ["API_NINJAS_KEY", "EXCHANGERATE_KEY", "NEWS_API_KEY"]
        for key in api_keys:
            if not getattr(cls, key):
                print(f"⚠️ Warning: {key} not set. Some tools will not work.")

        return missing


# Create singleton instance
settings = Settings()