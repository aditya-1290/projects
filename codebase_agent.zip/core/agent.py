"""
core/agent.py - Core agent with Gemma 4 optimized prompts.
"""

from typing import Optional, List, Dict, Any
from llm.backend import get_llm
from config.settings import settings
from utils.logger import log

# Gemma 4 optimized system prompt
SYSTEM_PROMPT = """You are CodeBase Agent, an AI assistant with access to real-time tools.

Your capabilities:
- Answer questions using provided tool results
- Write and analyze code
- Search the web and GitHub
- Perform calculations and conversions

IMPORTANT RULES:
1. ALWAYS use tool results when provided - they are ground truth
2. Never say you cannot access tools or data
3. Write in clear, natural language
4. For code, use proper formatting and explain your changes
5. Be concise but thorough

When answering:
- Use full sentences, not raw data dumps
- For weather: "The temperature in Mumbai is 34°C with 43% humidity"
- For stocks: "Apple (AAPL) is trading at $175.23 on NASDAQ"
- For time: "It's 2:41 PM on Saturday in Mumbai"
- For code: Provide working solutions with explanations"""


class Agent:
    """Core agent that interfaces with Gemma 4."""

    def __init__(self, session_id: Optional[str] = None):
        self.llm = get_llm()
        self.session_id = session_id
        self.conversation_history: List[Dict[str, str]] = []

    def _build_messages(
            self,
            user_input: str,
            tool_results: Optional[List[Dict]] = None,
    ) -> List[Dict[str, str]]:
        """Build message list with proper priority order."""
        messages = [{"role": "system", "content": SYSTEM_PROMPT}]

        # Add conversation history (last 6 turns)
        if self.conversation_history:
            messages.extend(self.conversation_history[-6:])

        # Add tool results as system context
        if tool_results:
            tool_text = "TOOL RESULTS (use this data):\n\n"
            for tr in tool_results:
                tool_text += f"[{tr.get('tool')}] {tr.get('result')}\n"
            messages.append({"role": "system", "content": tool_text})

        # Add current query
        messages.append({"role": "user", "content": user_input})

        return messages

    def chat(self, user_input: str, tool_results: Optional[List[Dict]] = None) -> str:
        """Generate response using Gemma 4."""
        messages = self._build_messages(user_input, tool_results)

        response = self.llm.chat(messages)
        content = response.get("content", "")

        # Update history
        self.conversation_history.append({"role": "user", "content": user_input})
        self.conversation_history.append({"role": "assistant", "content": content})

        # Trim history
        if len(self.conversation_history) > settings.SESSION_HISTORY_SIZE:
            self.conversation_history = self.conversation_history[-settings.SESSION_HISTORY_SIZE:]

        return content

    def stream_chat(self, user_input: str, tool_results: Optional[List[Dict]] = None):
        """Stream response tokens."""
        messages = self._build_messages(user_input, tool_results)
        full_response = ""

        for token in self.llm.stream_chat(messages):
            full_response += token
            yield token

        # Update history
        self.conversation_history.append({"role": "user", "content": user_input})
        self.conversation_history.append({"role": "assistant", "content": full_response})

    def clear_history(self):
        """Clear conversation history."""
        self.conversation_history = []

    def get_stats(self) -> Dict[str, Any]:
        """Get agent statistics."""
        return {
            "session_id": self.session_id,
            "history_length": len(self.conversation_history),
            "llm_stats": self.llm.get_stats(),
        }