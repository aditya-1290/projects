"""
core/classifier.py - Zero-LLM intent classifier.
"""

import re
from typing import Dict, Optional

from utils.constants import QueryType, COMMON_TICKERS, CURRENCY_CODES
from utils.logger import log


class IntentClassifier:
    """
    Zero-LLM intent classifier using pattern matching.

    Classifies queries into:
    - CONVERSATIONAL: Greetings, small talk, general knowledge
    - SIMPLE_TOOL: Single tool with extractable arguments
    - COMPLEX: Multi-step or ambiguous queries
    """

    # Add this at the top with other patterns
    _MULTI_INTENT_PATTERNS = re.compile(
        r"\b(and|also|plus|along with|as well as|together with)\b.*\b(weather|time|gold|stock|price|news|search)\b"
        r"|\b(weather|time|gold|stock).*?(weather|time|gold|stock)",
        re.IGNORECASE
    )

    # Conversational patterns
    GREETING_PATTERNS = re.compile(
        r"\b(hi+|hello+|hey+|howdy|good\s*(morning|afternoon|evening|night)"
        r"|how are you|how's it going|what's up"
        r"|thanks?|thank you|bye|goodbye|see you)\b",
        re.IGNORECASE
    )

    IDENTITY_PATTERNS = re.compile(
        r"\b(who (are|built|made|created) you"
        r"|what are you|what can you do|what('s| is) your name"
        r"|tell me about yourself|introduce yourself)\b",
        re.IGNORECASE
    )

    GENERAL_KNOWLEDGE_PATTERNS = re.compile(
        r"\b(explain|describe|what is|what are|what('s| is) the difference"
        r"|differentiate|compare|define|tell me about|how does|why is|why are)\b",
        re.IGNORECASE
    )

    # Tool triggers
    TOOL_OVERRIDE = re.compile(
        r"\b(weather|temperature|time|date|stock|price|gold|currency|convert|news|calculate)\b",
        re.IGNORECASE
    )

    WEATHER_TRIGGERS = re.compile(
        r"\b(weather|temperature|temp|humid|rain|forecast|hot|cold|climate)\b",
        re.IGNORECASE
    )

    TIME_TRIGGERS = re.compile(
        r"\b(time|clock|timezone|what time|current time)\b",
        re.IGNORECASE
    )

    DATE_TRIGGERS = re.compile(
        r"\b(date|day|what day|which day|today'?s?\s+date)\b",
        re.IGNORECASE
    )

    STOCK_TRIGGERS = re.compile(
        r"\b(stock|share|price of|ticker|market cap|nifty|sensex)\b",
        re.IGNORECASE
    )

    GOLD_TRIGGERS = re.compile(
        r"\b(gold price|price of gold|gold today|gold rate|xau)\b",
        re.IGNORECASE
    )

    CURRENCY_TRIGGERS = re.compile(
        r"\b(convert|conversion|exchange|rate)\b.*\b(usd|inr|eur|gbp|jpy|aed|currency)\b"
        r"|\b(usd|inr|eur|gbp)\b.*\b(to|in|into)\b",
        re.IGNORECASE
    )

    NEWS_TRIGGERS = re.compile(
        r"\b(news|headlines|latest news|news updates?)\b",
        re.IGNORECASE
    )

    CALC_TRIGGERS = re.compile(
        r"\b(calculate|compute|how much is|result of|solve|sqrt|square root)\b|[\d]+\s*[\+\-\*\/]\s*[\d]",
        re.IGNORECASE
    )

    # City ignore list
    CITY_IGNORE = {
        "Hello", "Hey", "Hi", "What", "How", "The", "Can", "Tell", "Show", "Get",
        "Current", "Today", "Latest", "Now", "Recent", "Please", "Help", "Find",
        "Check", "News", "Stock", "Price", "Weather", "Time", "Date", "Gold",
    }

    # Add this method to IntentClassifier class
    def _has_multiple_intents(self, text: str) -> bool:
        """Check if query has multiple distinct intents."""
        intent_count = 0

        if self.WEATHER_TRIGGERS.search(text):
            intent_count += 1
        if self.TIME_TRIGGERS.search(text) or self.DATE_TRIGGERS.search(text):
            intent_count += 1
        if self.STOCK_TRIGGERS.search(text):
            intent_count += 1
        if self.GOLD_TRIGGERS.search(text):
            intent_count += 1
        if self.CURRENCY_TRIGGERS.search(text):
            intent_count += 1
        if self.NEWS_TRIGGERS.search(text):
            intent_count += 1

        return intent_count >= 2

    def classify(self, text: str) -> Dict:
        """
        Classify user input.

        Returns:
            Dictionary with 'type' and optional 'plan' for simple tools
        """
        text = text.strip()

        # Check for tool keywords first
        has_tool_keyword = bool(self.TOOL_OVERRIDE.search(text))

        # Conversational check
        if not has_tool_keyword:
            if (self.GREETING_PATTERNS.search(text) or
                    self.IDENTITY_PATTERNS.search(text) or
                    self.GENERAL_KNOWLEDGE_PATTERNS.search(text)):
                log.debug(f"[Classifier] Conversational: {text[:50]}...")
                return {"type": QueryType.CONVERSATIONAL}

        # Check for multiple intents first
        if self._has_multiple_intents(text):
            log.debug(f"[Classifier] Multiple intents detected")
            return {"type": QueryType.COMPLEX}

        # Gold price
        if self.GOLD_TRIGGERS.search(text):
            return {
                "type": QueryType.SIMPLE_TOOL,
                "plan": {
                    "steps": [{
                        "task": "Get current gold price",
                        "agent": "finance",
                        "tool": "get_gold_price",
                        "args": {}
                    }]
                }
            }

        # Weather
        if self.WEATHER_TRIGGERS.search(text):
            city = self._extract_city(text)
            if city:
                return {
                    "type": QueryType.SIMPLE_TOOL,
                    "plan": {
                        "steps": [{
                            "task": f"Get weather in {city}",
                            "agent": "weather",
                            "tool": "get_weather",
                            "args": {"city": city, "unit": "celsius"}
                        }]
                    }
                }

        # Time
        if self.TIME_TRIGGERS.search(text) and not self.DATE_TRIGGERS.search(text):
            city = self._extract_city(text)
            if city:
                return {
                    "type": QueryType.SIMPLE_TOOL,
                    "plan": {
                        "steps": [{
                            "task": f"Get current time in {city}",
                            "agent": "time",
                            "tool": "get_current_time",
                            "args": {"city": city}
                        }]
                    }
                }

        # Date
        if self.DATE_TRIGGERS.search(text):
            city = self._extract_city(text)
            if city:
                return {
                    "type": QueryType.SIMPLE_TOOL,
                    "plan": {
                        "steps": [{
                            "task": f"Get date info for {city}",
                            "agent": "time",
                            "tool": "get_date_info",
                            "args": {"city": city}
                        }]
                    }
                }

        # Stock
        if self.STOCK_TRIGGERS.search(text):
            ticker = self._extract_ticker(text)
            if ticker:
                return {
                    "type": QueryType.SIMPLE_TOOL,
                    "plan": {
                        "steps": [{
                            "task": f"Get stock price for {ticker}",
                            "agent": "finance",
                            "tool": "get_stock_price",
                            "args": {"ticker": ticker}
                        }]
                    }
                }

        # Currency
        if self.CURRENCY_TRIGGERS.search(text):
            args = self._extract_currency_args(text)
            if args:
                return {
                    "type": QueryType.SIMPLE_TOOL,
                    "plan": {
                        "steps": [{
                            "task": f"Convert {args['amount']} {args['from_currency']} to {args['to_currency']}",
                            "agent": "finance",
                            "tool": "convert_currency",
                            "args": args
                        }]
                    }
                }

        # News
        if self.NEWS_TRIGGERS.search(text):
            topic = self._extract_news_topic(text)
            return {
                "type": QueryType.SIMPLE_TOOL,
                "plan": {
                    "steps": [{
                        "task": f"Get {topic} news",
                        "agent": "search",
                        "tool": "web_search",
                        "args": {"query": text}
                    }]
                }
            }

        # Calculator
        if self.CALC_TRIGGERS.search(text):
            expr = self._extract_math_expression(text)
            if expr:
                return {
                    "type": QueryType.SIMPLE_TOOL,
                    "plan": {
                        "steps": [{
                            "task": f"Calculate: {expr}",
                            "agent": "general",
                            "tool": "calculate",
                            "args": {"expression": expr}
                        }]
                    }
                }

        # Default: complex query
        log.debug(f"[Classifier] Complex: {text[:50]}...")
        return {"type": QueryType.COMPLEX}



    def _extract_city(self, text: str) -> Optional[str]:
        """Extract city from text."""
        # Pattern: "in/for/at/of <City>"
        match = re.search(r"\b(?:in|for|at|of)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)", text)
        if match:
            candidate = match.group(1).strip()
            if candidate not in self.CITY_IGNORE:
                return candidate

        # Last capitalised word(s)
        matches = re.findall(r"\b([A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})?)\b", text)
        cities = [m for m in matches if m not in self.CITY_IGNORE]

        return cities[-1] if cities else None

    def _extract_ticker(self, text: str) -> Optional[str]:
        """Extract stock ticker from text."""
        text_lower = text.lower()

        for name, ticker in sorted(COMMON_TICKERS.items(), key=lambda x: -len(x[0])):
            if name in text_lower:
                return ticker

        match = re.search(r"\b([A-Z]{2,5}(?:\.[A-Z]{2})?|\^[A-Z]{2,5})\b", text)
        return match.group(1) if match else None

    def _extract_currency_args(self, text: str) -> Optional[Dict]:
        """Extract currency conversion arguments."""
        amount_match = re.search(r"(\d+(?:\.\d+)?)", text)
        if not amount_match:
            return None

        amount = float(amount_match.group(1))
        text_lower = text.lower()

        # Find currency codes
        currencies = []
        for code in CURRENCY_CODES:
            if code.lower() in text_lower:
                currencies.append(code.upper())

        if len(currencies) >= 2:
            return {
                "amount": amount,
                "from_currency": currencies[0],
                "to_currency": currencies[1]
            }

        return None

    def _extract_news_topic(self, text: str) -> str:
        """Extract news topic from text."""
        topics = ["technology", "business", "sports", "politics", "science", "health", "world"]

        text_lower = text.lower()
        for topic in topics:
            if topic in text_lower:
                return topic

        return "top"

    def _extract_math_expression(self, text: str) -> Optional[str]:
        """Extract math expression from text."""
        # Look for mathematical patterns
        match = re.search(r"([\d\s\+\-\*\/\(\)\.]+)", text)
        if match:
            expr = match.group(1).strip()
            if any(op in expr for op in ["+", "-", "*", "/"]):
                return expr

        # Handle sqrt
        sqrt_match = re.search(r"sqrt\s+(?:of\s+)?(\d+(?:\.\d+)?)", text, re.IGNORECASE)
        if sqrt_match:
            return f"sqrt({sqrt_match.group(1)})"

        return None


# Singleton
_classifier: Optional[IntentClassifier] = None


def get_classifier() -> IntentClassifier:
    """Get or create classifier singleton."""
    global _classifier
    if _classifier is None:
        _classifier = IntentClassifier()
    return _classifier


def classify(text: str) -> Dict:
    """Classify user input."""
    return get_classifier().classify(text)