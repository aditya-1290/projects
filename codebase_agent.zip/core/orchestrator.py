"""
core/orchestrator.py - Multi-Agent Orchestrator (Updated to use specialist agents).

This is the bridge between the legacy system and the new multi-agent system.
It delegates tool-using queries to the appropriate specialist agents.
"""

import json
import time
from typing import Optional, Dict, List, Any, Callable

from core.agent import Agent
from core.classifier import classify
from core.evaluator import evaluate
from core.session import get_session_manager
from memory.cache import tool_cache, response_cache
from utils.logger import log
from utils.constants import QueryType, ProgressEvent


class ProgressTracker:
    """Track and stream progress updates."""

    def __init__(self, callback: Optional[Callable[[str, str], None]] = None):
        self.callback = callback
        self.current_step = 0

    def emit(self, event: str, message: str):
        """Emit a progress event."""
        if self.callback:
            self.callback(event, message)
        log.debug(f"[Progress] {event}: {message}")

    def thinking(self, message: str = "Analyzing..."):
        self.emit(ProgressEvent.THINKING, message)

    def tool_start(self, tool_name: str):
        self.emit(ProgressEvent.TOOL_START, f"Running {tool_name}...")

    def tool_complete(self, tool_name: str, success: bool):
        status = "✅" if success else "❌"
        self.emit(ProgressEvent.TOOL_COMPLETE, f"{status} {tool_name} complete")

    def generating(self):
        self.emit(ProgressEvent.GENERATING, "Writing response...")


class AgentOrchestrator:
    """
    Multi-Agent Orchestrator that delegates to specialist agents.

    This is the main entry point for the API and terminal UI.
    It bridges the legacy system with the new multi-agent system.
    """

    def __init__(self, session_id: Optional[str] = None):
        self.session_id = session_id
        self.agent = Agent(session_id)

        # Lazy load the multi-agent orchestrator
        self._multi_agent_orchestrator = None
        self.max_cycles = 5
        self.confidence_threshold = 0.6

    @property
    def multi_agent(self):
        """Lazy load the multi-agent orchestrator."""
        if self._multi_agent_orchestrator is None:
            from agents import get_orchestrator
            self._multi_agent_orchestrator = get_orchestrator(self.session_id)
        return self._multi_agent_orchestrator

    def run(self, user_input: str, progress_callback: Optional[Callable] = None) -> str:
        """
        Run orchestrator on user input.

        Pipeline:
        1. Check response cache
        2. Classify query
        3. Conversational → Direct agent
        4. Tool-using → Delegate to multi-agent system
        """
        progress = ProgressTracker(progress_callback)

        # Check response cache
        cached = response_cache.get(user_input)
        if cached:
            log.info(f"[Orchestrator] Response cache hit")
            return cached

        # Classify query
        classification = classify(user_input)
        query_type = classification["type"]

        log.info(f"[Orchestrator] Query type: {query_type.value}")

        # Route based on type
        if query_type == QueryType.CONVERSATIONAL:
            answer = self._handle_conversational(user_input, progress)
        else:
            # For all tool-using queries, delegate to multi-agent system
            answer = self._delegate_to_multi_agent(user_input, classification, progress)

        # Cache and return
        if answer:
            response_cache.set(user_input, answer)

        return answer or "I couldn't process your request. Please try rephrasing."

    def _handle_conversational(self, user_input: str, progress: ProgressTracker) -> str:
        """Handle conversational queries directly."""
        progress.thinking("Processing conversation...")
        return self.agent.chat(user_input)

    def _delegate_to_multi_agent(
        self,
        user_input: str,
        classification: Dict,
        progress: ProgressTracker
    ) -> Optional[str]:
        """
        Delegate the query to the multi-agent system.

        The multi-agent orchestrator will:
        1. Decompose the query if needed
        2. Route to appropriate specialist agents (DataAgent, CodeAgent, etc.)
        3. Synthesize the response
        """
        progress.thinking("Analyzing query and routing to specialist agents...")

        try:
            # Use the multi-agent orchestrator
            log.info(f"[Orchestrator] Delegating to multi-agent system")
            answer = self.multi_agent.process_query(user_input)

            # Evaluate quality
            eval_result = evaluate(user_input, answer)
            confidence = eval_result.get("confidence", 0.5)
            log.info(f"[Orchestrator] Response confidence: {confidence:.2f}")

            return answer

        except Exception as e:
            log.error(f"[Orchestrator] Multi-agent delegation error: {e}")

            # Fallback to direct tool execution for simple queries
            if classification["type"] == QueryType.SIMPLE_TOOL:
                log.warning("[Orchestrator] Falling back to direct tool execution")
                return self._fallback_simple_tool(user_input, classification, progress)

            return None

    def _fallback_simple_tool(
        self,
        user_input: str,
        classification: Dict,
        progress: ProgressTracker
    ) -> Optional[str]:
        """Fallback: Execute simple tool directly if multi-agent fails."""
        plan = classification.get("plan", {})
        steps = plan.get("steps", [])

        if not steps:
            return None

        step = steps[0]
        tool_name = step.get("tool")
        args = step.get("args", {})
        task = step.get("task", user_input)

        if not tool_name:
            return None

        log.info(f"[Orchestrator] Fallback: Direct execution of {tool_name}")
        progress.tool_start(tool_name)

        try:
            from tools import get_tool

            # Check cache first
            cached = tool_cache.get(tool_name, args)
            if cached:
                result = cached
                progress.tool_complete(tool_name, True)
            else:
                tool_fn = get_tool(tool_name)
                result = tool_fn(**args)

                if result.get("status") == "success":
                    tool_cache.set(tool_name, args, result)
                    progress.tool_complete(tool_name, True)
                else:
                    progress.tool_complete(tool_name, False)
                    return None

            # Summarize
            progress.generating()
            tool_results = [{"tool": tool_name, "task": task, "result": result}]
            return self.agent.chat(user_input, tool_results=tool_results)

        except Exception as e:
            log.error(f"[Orchestrator] Fallback tool error: {e}")
            progress.tool_complete(tool_name, False)
            return None

    def process_query(self, user_input: str) -> str:
        """Alias for run() - used by terminal UI."""
        return self.run(user_input)
    