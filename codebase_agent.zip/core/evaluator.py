"""
core/evaluator.py - Response evaluator with confidence scoring.
"""

import json
import re
from typing import Dict, Optional

from llm.backend import get_llm
from utils.logger import log
from utils.helpers import extract_json

EVALUATOR_PROMPT = """You are an evaluator scoring answer quality.

Goal: {goal}

Answer: {answer}

Score the answer from 0.0 to 1.0:
- 1.0: Perfect, directly answers with specific data
- 0.8: Good, minor gaps or approximations
- 0.6: Partial, some information missing
- 0.4: Weak, mostly missing or vague
- 0.2: Poor, barely related
- 0.0: Wrong or harmful

Return JSON:
{{"status": "COMPLETE" or "INCOMPLETE", "confidence": 0.0-1.0, "reason": "brief explanation"}}

COMPLETE means the answer provides actual data. INCOMPLETE means it says "I don't know" or deflects."""


class ResponseEvaluator:
    """Evaluates agent responses with confidence scoring."""

    def __init__(self):
        self.llm = get_llm()

    def evaluate(self, goal: str, answer: str) -> Dict:
        """
        Evaluate how well the answer satisfies the goal.

        Returns:
            Dictionary with 'status', 'confidence', 'reason'
        """
        try:
            prompt = EVALUATOR_PROMPT.format(goal=goal, answer=answer[:2000])

            messages = [
                {"role": "system", "content": "You are an evaluation assistant. Return only JSON."},
                {"role": "user", "content": prompt}
            ]

            response = self.llm.chat(messages, temperature=0.3, max_tokens=200)
            raw = response.get("content", "")

            result = self._parse_response(raw)

            # Ensure valid values
            confidence = float(result.get("confidence", 0.5))
            confidence = max(0.0, min(1.0, confidence))

            status = result.get("status", "INCOMPLETE")
            if status not in ("COMPLETE", "INCOMPLETE"):
                status = "COMPLETE" if confidence >= 0.5 else "INCOMPLETE"

            log.info(f"[Evaluator] {status} (confidence={confidence:.2f})")

            return {
                "status": status,
                "confidence": round(confidence, 2),
                "reason": result.get("reason", "No reason provided"),
            }

        except Exception as e:
            log.error(f"[Evaluator] Error: {e}")
            return {
                "status": "INCOMPLETE",
                "confidence": 0.5,
                "reason": f"Evaluation error: {e}",
            }

    def _parse_response(self, raw: str) -> Dict:
        """Parse evaluator response."""
        # Try extract JSON
        result = extract_json(raw)
        if result:
            return result

        # Fallback: infer from text
        log.warning(f"[Evaluator] Could not parse JSON, inferring from: {raw[:100]}")

        status = "COMPLETE" if "COMPLETE" in raw.upper() else "INCOMPLETE"
        confidence = 0.8 if status == "COMPLETE" else 0.3

        # Try to extract confidence number
        match = re.search(r"confidence[:\s]*([\d.]+)", raw, re.IGNORECASE)
        if match:
            try:
                confidence = float(match.group(1))
            except ValueError:
                pass

        return {
            "status": status,
            "confidence": confidence,
            "reason": raw[:200],
        }


# Singleton
_evaluator: Optional[ResponseEvaluator] = None


def get_evaluator() -> ResponseEvaluator:
    """Get or create evaluator singleton."""
    global _evaluator
    if _evaluator is None:
        _evaluator = ResponseEvaluator()
    return _evaluator


def evaluate(goal: str, answer: str) -> Dict:
    """Evaluate answer quality."""
    return get_evaluator().evaluate(goal, answer)