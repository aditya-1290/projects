"""
core/session.py - Session management for multi-user support.
"""

import uuid
import json
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, List, Any

from config.settings import settings
from utils.logger import log


class Session:
    """Individual user session."""

    def __init__(self, session_id: str, metadata: Optional[Dict] = None):
        self.id = session_id
        self.created_at = datetime.now()
        self.last_active = datetime.now()
        self.metadata = metadata or {}
        self.conversation_history: List[Dict[str, str]] = []
        self.message_count = 0

    def add_exchange(self, user_msg: str, assistant_msg: str) -> None:
        """Add a conversation exchange."""
        self.conversation_history.append({"role": "user", "content": user_msg})
        self.conversation_history.append({"role": "assistant", "content": assistant_msg})
        self.message_count += 2
        self.last_active = datetime.now()

        # Trim history
        if len(self.conversation_history) > settings.SESSION_HISTORY_SIZE:
            self.conversation_history = self.conversation_history[-settings.SESSION_HISTORY_SIZE:]

    def get_history(self, limit: int = 6) -> List[Dict[str, str]]:
        """Get recent conversation history."""
        return self.conversation_history[-limit:] if self.conversation_history else []

    def clear_history(self) -> None:
        """Clear conversation history."""
        self.conversation_history = []

    def to_dict(self) -> Dict[str, Any]:
        """Convert session to dictionary."""
        return {
            "id": self.id[:8] + "...",
            "created_at": self.created_at.isoformat(),
            "last_active": self.last_active.isoformat(),
            "message_count": self.message_count,
            "metadata": self.metadata,
        }

    def is_stale(self, max_age_hours: int = None) -> bool:
        """Check if session is stale."""
        max_age = max_age_hours or settings.SESSION_CLEANUP_HOURS
        age = (datetime.now() - self.last_active).total_seconds() / 3600
        return age > max_age


class SessionManager:
    """Manages multiple user sessions."""

    def __init__(self, persist_path: Optional[str] = None):
        self.persist_path = persist_path or settings.SESSION_DIR
        self._sessions: Dict[str, Session] = {}

        # Ensure directory exists
        Path(self.persist_path).mkdir(parents=True, exist_ok=True)

        # Load existing sessions
        self._load_sessions()

    def create_session(self, metadata: Optional[Dict] = None) -> str:
        """Create a new session."""
        session_id = str(uuid.uuid4())
        self._sessions[session_id] = Session(session_id, metadata)

        log.info(f"[Session] Created session {session_id[:8]}...")
        self._save_session(session_id)

        return session_id

    def get_session(self, session_id: str) -> Optional[Session]:
        """Get session by ID."""
        session = self._sessions.get(session_id)

        if session:
            session.last_active = datetime.now()

        return session

    def get_or_create_session(self, session_id: Optional[str] = None) -> tuple:
        """Get existing session or create new one."""
        if session_id and session_id in self._sessions:
            return session_id, self._sessions[session_id]

        new_id = self.create_session()
        return new_id, self._sessions[new_id]

    def add_exchange(self, session_id: str, user_msg: str, assistant_msg: str) -> None:
        """Add exchange to session."""
        session = self.get_session(session_id)
        if session:
            session.add_exchange(user_msg, assistant_msg)
            self._save_session(session_id)

    def get_history(self, session_id: str, limit: int = 6) -> List[Dict[str, str]]:
        """Get session conversation history."""
        session = self.get_session(session_id)
        return session.get_history(limit) if session else []

    def clear_session(self, session_id: str) -> bool:
        """Clear a specific session."""
        if session_id in self._sessions:
            self._sessions[session_id].clear_history()
            self._save_session(session_id)

            log.info(f"[Session] Cleared session {session_id[:8]}...")
            return True
        return False

    def delete_session(self, session_id: str) -> bool:
        """Delete a session."""
        if session_id in self._sessions:
            del self._sessions[session_id]

            # Remove persisted file
            session_file = Path(self.persist_path) / f"{session_id}.json"
            if session_file.exists():
                session_file.unlink()

            log.info(f"[Session] Deleted session {session_id[:8]}...")
            return True
        return False

    def cleanup_stale_sessions(self, max_age_hours: int = None) -> int:
        """Remove stale sessions."""
        stale_sessions = [
            sid for sid, session in self._sessions.items()
            if session.is_stale(max_age_hours)
        ]

        for sid in stale_sessions:
            self.delete_session(sid)

        if stale_sessions:
            log.info(f"[Session] Cleaned up {len(stale_sessions)} stale sessions")

        return len(stale_sessions)

    def get_stats(self) -> Dict[str, Any]:
        """Get session statistics."""
        return {
            "active_sessions": len(self._sessions),
            "total_messages": sum(s.message_count for s in self._sessions.values()),
            "sessions": [s.to_dict() for s in self._sessions.values()],
        }

    def _save_session(self, session_id: str) -> None:
        """Persist session to disk."""
        session = self._sessions.get(session_id)
        if not session:
            return

        try:
            session_file = Path(self.persist_path) / f"{session_id}.json"

            data = {
                "id": session.id,
                "created_at": session.created_at.isoformat(),
                "last_active": session.last_active.isoformat(),
                "message_count": session.message_count,
                "metadata": session.metadata,
                "conversation_history": session.conversation_history,
            }

            with open(session_file, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)

        except Exception as e:
            log.error(f"[Session] Failed to save session {session_id}: {e}")

    def _load_sessions(self) -> None:
        """Load persisted sessions from disk."""
        try:
            session_dir = Path(self.persist_path)

            for session_file in session_dir.glob("*.json"):
                try:
                    with open(session_file, "r", encoding="utf-8") as f:
                        data = json.load(f)

                    session_id = data["id"]
                    session = Session(session_id, data.get("metadata", {}))
                    session.created_at = datetime.fromisoformat(data["created_at"])
                    session.last_active = datetime.fromisoformat(data["last_active"])
                    session.message_count = data.get("message_count", 0)
                    session.conversation_history = data.get("conversation_history", [])

                    self._sessions[session_id] = session

                except Exception as e:
                    log.warning(f"[Session] Failed to load {session_file}: {e}")

            log.info(f"[Session] Loaded {len(self._sessions)} sessions")

        except Exception as e:
            log.error(f"[Session] Failed to load sessions: {e}")


# Global singleton
_session_manager: Optional[SessionManager] = None


def get_session_manager() -> SessionManager:
    """Get or create the session manager singleton."""
    global _session_manager
    if _session_manager is None:
        _session_manager = SessionManager()
    return _session_manager