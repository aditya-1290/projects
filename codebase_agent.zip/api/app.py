"""
api/app.py - FastAPI application setup with multi-agent support.
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import RedirectResponse, HTMLResponse

from config.settings import settings
from api.routes import chat, tools, cache, memory, github, system, agents
from utils.logger import log


def create_app() -> FastAPI:
    """Create and configure FastAPI application."""

    app = FastAPI(
        title="CodeBase Agent API",
        description="""
        Multi-Agent AI-powered coding assistant with specialist agents:
        - 🎭 Orchestrator - Coordinates tasks across agents
        - 💻 Code Agent - File operations, code analysis, execution
        - 🔍 Search Agent - Web search, news, timelines
        - 📊 Data Agent - Weather, stocks, currency, time
        - 🐙 GitHub Agent - Repository indexing, code search
        - 🔧 Utility Agent - Calculations, unit conversions
        - ✅ Review Agent - Quality evaluation and refinement
        """,
        version="3.0.0",
        docs_url="/docs",
        redoc_url="/redoc",
    )

    # CORS middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.CORS_ORIGINS,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Include routers
    app.include_router(chat.router, prefix="/api/chat", tags=["Chat"])
    app.include_router(tools.router, prefix="/api/tools", tags=["Tools"])
    app.include_router(cache.router, prefix="/api/cache", tags=["Cache"])
    app.include_router(memory.router, prefix="/api/memory", tags=["Memory"])
    app.include_router(github.router, prefix="/api/github_tools", tags=["GitHub"])
    app.include_router(system.router, prefix="/api/system", tags=["System"])
    app.include_router(agents.router, prefix="/api/agents", tags=["Agents"])  # NEW

    # Static files for web UI
    try:
        app.mount("/static", StaticFiles(directory="ui/web/static"), name="static")
    except Exception as e:
        log.warning(f"[API] Static files not found: {e}")

    @app.get("/", include_in_schema=False)
    async def root():
        """Redirect to web UI or docs."""
        try:
            return HTMLResponse(content=open("ui/web/static/index.html").read())
        except:
            return RedirectResponse(url="/docs")

    @app.get("/health", tags=["Health"])
    async def health():
        """Health check endpoint."""
        from agents import get_orchestrator
        orchestrator = get_orchestrator()

        return {
            "status": "healthy",
            "version": "3.0.0",
            "model": settings.MODEL_PATH,
            "agents": {
                "orchestrator": "online",
                "specialists": list(orchestrator.specialists.keys()),
            },
        }

    @app.get("/dashboard", include_in_schema=False)
    async def dashboard():
        """Agent dashboard."""
        try:
            return HTMLResponse(content=open("ui/web/static/index.html").read())
        except:
            return HTMLResponse(content="<h1>Dashboard not found</h1>", status_code=404)

    return app


# Create app instance
app = create_app()