"""
api/routes/chat.py - Chat endpoints.
"""

import time
import json
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse

from api.models.requests import ChatRequest
from api.models.responses import ChatResponse
from core.orchestrator import AgentOrchestrator
from core.session import get_session_manager
from utils.logger import log

router = APIRouter()


@router.post("", response_model=ChatResponse)
async def chat(request: ChatRequest):
    """
    Send a message to the agent.

    Supports all query types:
    - Conversational: "Hello", "How are you?"
    - Weather: "Weather in Mumbai"
    - Finance: "Stock price of AAPL", "Convert 100 USD to INR"
    - News: "Latest tech news"
    - Code: "Read file app.py", "Search for 'function' in src/"
    - GitHub: "Index repo https://github.com/user/repo"
    """
    if not request.message.strip():
        raise HTTPException(status_code=400, detail="Message cannot be empty")

    log.info(f"[API] Chat: {request.message[:100]}...")
    start_time = time.time()

    try:
        session_mgr = get_session_manager()
        session_id, _ = session_mgr.get_or_create_session(request.session_id)

        orchestrator = AgentOrchestrator(session_id)
        answer = orchestrator.run(request.message)

        elapsed = round(time.time() - start_time, 2)
        log.info(f"[API] Chat completed in {elapsed}s")

        return ChatResponse(
            message=request.message,
            answer=answer,
            time_taken=elapsed,
            session_id=session_id[:8] + "...",
        )

    except Exception as e:
        log.error(f"[API] Chat error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/stream")
async def chat_stream(request: ChatRequest):
    """
    Stream agent response via Server-Sent Events.

    SSE format:
        data: {"token": "hello"}\n\n
        data: {"progress": {"type": "thinking", "message": "..."}}\n\n
        data: {"done": true}\n\n
    """
    if not request.message.strip():
        raise HTTPException(status_code=400, detail="Message cannot be empty")

    log.info(f"[API] Stream: {request.message[:100]}...")

    async def event_generator():
        try:
            session_mgr = get_session_manager()
            session_id, _ = session_mgr.get_or_create_session(request.session_id)

            orchestrator = AgentOrchestrator(session_id)

            # Progress callback
            def progress_callback(event_type: str, message: str):
                return f"data: {json.dumps({'progress': {'type': event_type, 'message': message}})}\n\n"

            # For streaming, we need to modify orchestrator to yield
            # For now, run normally and stream the result
            answer = orchestrator.run(request.message, progress_callback=progress_callback)

            # Stream answer token by token
            for char in answer:
                yield f"data: {json.dumps({'token': char})}\n\n"
                import asyncio
                await asyncio.sleep(0.01)

            yield f"data: {json.dumps({'done': True})}\n\n"

        except Exception as e:
            log.error(f"[API] Stream error: {e}")
            yield f"data: {json.dumps({'error': str(e)})}\n\n"

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        }
    )