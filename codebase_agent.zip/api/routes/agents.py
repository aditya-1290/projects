"""
api/routes/agents.py - Multi-agent management endpoints.
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional, List, Dict, Any

from agents import get_orchestrator
from agents.base import Task, AgentRole
from utils.logger import log

router = APIRouter()


class AgentTaskRequest(BaseModel):
    """Request to delegate a task to an agent."""
    description: str
    role: Optional[str] = None
    tool: Optional[str] = None
    args: Dict[str, Any] = {}


class AgentStatusResponse(BaseModel):
    """Agent status response."""
    agents: List[Dict[str, Any]]
    active_tasks: int
    completed_tasks: int
    failed_tasks: int


@router.get("/status")
async def get_agents_status():
    """Get status of all agents."""
    try:
        orchestrator = get_orchestrator()

        agents_status = []
        for role, specialist in orchestrator.specialists.items():
            agents_status.append({
                "name": specialist.name,
                "role": role.value,
                "capabilities": specialist.capabilities,
                "current_task": specialist.current_task.description if specialist.current_task else None,
                "tasks_completed": len([t for t in specialist.task_history if t.status.value == "completed"]),
                "tasks_failed": len([t for t in specialist.task_history if t.status.value == "failed"]),
            })

        # Add orchestrator
        agents_status.append({
            "name": orchestrator.name,
            "role": "orchestrator",
            "capabilities": orchestrator.capabilities,
            "current_task": orchestrator.current_task.description if orchestrator.current_task else None,
            "tasks_completed": len([t for t in orchestrator.task_history if t.status.value == "completed"]),
            "tasks_failed": len([t for t in orchestrator.task_history if t.status.value == "failed"]),
        })

        return {
            "agents": agents_status,
            "total_agents": len(agents_status),
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/delegate")
async def delegate_task(request: AgentTaskRequest):
    """Delegate a task to the appropriate agent."""
    try:
        orchestrator = get_orchestrator()

        # Create task
        role = AgentRole[request.role.upper()] if request.role else None

        task = Task(
            description=request.description,
            role=role,
            tool=request.tool,
            args=request.args,
        )

        # Route and execute
        specialist = orchestrator._route_task(task)

        if specialist:
            log.info(f"[API] Delegating to {specialist.name}: {request.description}")
            task = specialist.execute(task, orchestrator.context)
        else:
            log.info(f"[API] Handling directly: {request.description}")
            task = orchestrator._handle_directly(task)

        return {
            "task_id": task.id,
            "description": task.description,
            "agent": specialist.name if specialist else "orchestrator",
            "status": task.status.value,
            "result": task.result,
            "error": task.error,
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/tasks")
async def list_tasks(limit: int = 20):
    """List recent tasks."""
    try:
        orchestrator = get_orchestrator()

        all_tasks = orchestrator.task_history[-limit:]

        return {
            "tasks": [t.to_dict() for t in all_tasks],
            "count": len(all_tasks),
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/capabilities")
async def get_capabilities():
    """Get capabilities of all agents."""
    try:
        orchestrator = get_orchestrator()

        capabilities = {
            "orchestrator": orchestrator.capabilities,
        }

        for role, specialist in orchestrator.specialists.items():
            capabilities[role.value] = specialist.capabilities

        return {
            "capabilities": capabilities,
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))