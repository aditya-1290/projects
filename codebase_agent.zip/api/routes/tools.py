"""
api/routes/tools.py - Tool endpoints.
"""

from fastapi import APIRouter, HTTPException

from api.models.requests import *
from tools.__init__ import TOOL_REGISTRY, get_tool
from utils.logger import log

router = APIRouter()


@router.get("")
async def list_tools():
    """List all available tools."""
    return {
        "tools": list(TOOL_REGISTRY.keys()),
        "count": len(TOOL_REGISTRY),
    }


# =============================================================================
# Weather & Time Tools
# =============================================================================

@router.post("/weather")
async def get_weather_endpoint(request: WeatherRequest):
    """Get weather for a city."""
    try:
        tool = get_tool("get_weather")
        return tool(request.city, request.unit)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/time")
async def get_time_endpoint(request: TimeRequest):
    """Get current time for a city."""
    try:
        tool = get_tool("get_current_time")
        return tool(request.city)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/date")
async def get_date_endpoint(request: TimeRequest):
    """Get date info for a city."""
    try:
        tool = get_tool("get_date_info")
        return tool(request.city)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# =============================================================================
# Finance Tools
# =============================================================================

@router.post("/stock")
async def get_stock_endpoint(request: StockRequest):
    """Get stock price."""
    try:
        tool = get_tool("get_stock_price")
        return tool(request.ticker)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/gold")
async def get_gold_endpoint():
    """Get gold price."""
    try:
        tool = get_tool("get_gold_price")
        return tool()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/currency")
async def convert_currency_endpoint(request: CurrencyRequest):
    """Convert currency."""
    try:
        tool = get_tool("convert_currency")
        return tool(request.amount, request.from_currency, request.to_currency)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# =============================================================================
# Search & News Tools
# =============================================================================

@router.post("/news")
async def get_news_endpoint(request: NewsRequest):
    """Get news headlines."""
    try:
        tool = get_tool("get_news")
        return tool(request.topic, request.limit)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/web_search")
async def web_search_endpoint(request: WebSearchRequest):
    """Search the web."""
    try:
        tool = get_tool("web_search")
        return tool(request.query, request.num_results, request.time_filter)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/timed_news")
async def timed_news_endpoint(request: TimedNewsRequest):
    """Search time-filtered news."""
    try:
        tool = get_tool("search_timed_news")
        return tool(request.query, request.months_back, request.limit)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/timeline")
async def timeline_endpoint(request: TimelineRequest):
    """Get entity timeline."""
    try:
        tool = get_tool("get_entity_timeline")
        return tool(request.entity, request.months_back)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# =============================================================================
# Utility Tools
# =============================================================================

@router.post("/calculate")
async def calculate_endpoint(request: CalculatorRequest):
    """Calculate math expression."""
    try:
        tool = get_tool("calculate")
        return tool(request.expression)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/convert")
async def convert_units_endpoint(request: ConverterRequest):
    """Convert units."""
    try:
        tool = get_tool("convert_units")
        return tool(request.value, request.from_unit, request.to_unit)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# =============================================================================
# CodeBase Tools
# =============================================================================

@router.post("/read_file")
async def read_file_endpoint(request: ReadFileRequest):
    """Read a file."""
    try:
        tool = get_tool("read_file")
        return tool(request.path, request.start_line, request.end_line)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/write_file")
async def write_file_endpoint(request: WriteFileRequest):
    """Write a file."""
    try:
        tool = get_tool("write_file")
        return tool(request.path, request.content, request.append)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/list_directory")
async def list_directory_endpoint(request: ListDirectoryRequest):
    """List directory contents."""
    try:
        tool = get_tool("list_directory")
        return tool(request.path, request.pattern)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/search_code")
async def search_code_endpoint(request: SearchCodeRequest):
    """Search code in directory."""
    try:
        tool = get_tool("search_code")
        return tool(request.directory, request.query, request.file_pattern)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/analyze_code")
async def analyze_code_endpoint(request: AnalyzeCodeRequest):
    """Analyze Python file."""
    try:
        tool = get_tool("analyze_code")
        return tool(request.file_path)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/execute")
async def execute_command_endpoint(request: ExecuteCommandRequest):
    """Execute safe shell command."""
    try:
        tool = get_tool("execute_command")
        return tool(request.command, request.timeout)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/git")
async def git_operation_endpoint(request: GitOperationRequest):
    """Perform git operation."""
    try:
        tool = get_tool("git_operation")
        return tool(request.repo_path, request.operation)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))