"""
api/routes/github_tools.py - GitHub endpoints.
"""

from fastapi import APIRouter, HTTPException

from api.models.requests import *
from tools.github_tools import (
    get_github_user_info,
    list_github_user_repos,
    get_repo_contents,
    get_file_content,
    index_github_repo,
    index_all_user_repos,
    search_indexed_code,
    list_indexed_repos,
)
from utils.logger import log

router = APIRouter()


@router.post("/user")
async def github_user_endpoint(request: GitHubUserRequest):
    """Get GitHub user information."""
    try:
        return get_github_user_info(request.username)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/repos")
async def github_repos_endpoint(request: GitHubUserRequest):
    """List GitHub user repositories."""
    try:
        return list_github_user_repos(request.username)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/contents")
async def github_contents_endpoint(repo_full_name: str, path: str = ""):
    """Get repository contents."""
    try:
        return get_repo_contents(repo_full_name, path)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/file")
async def github_file_endpoint(repo_full_name: str, file_path: str):
    """Get file content from repository."""
    try:
        return get_file_content(repo_full_name, file_path)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/index")
async def github_index_endpoint(request: GitHubIndexRequest):
    """Index a GitHub repository."""
    try:
        log.info(f"[API] Indexing GitHub repo: {request.repo_url}")
        return index_github_repo(request.repo_url, request.github_token)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/index_all")
async def github_index_all_endpoint(request: GitHubIndexAllRequest):
    """Index all repositories for a user."""
    try:
        log.info(f"[API] Indexing all repos for: {request.github_username}")
        return index_all_user_repos(request.github_username, request.github_token)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/search")
async def github_search_endpoint(request: GitHubSearchRequest):
    """Search indexed GitHub code."""
    try:
        return search_indexed_code(request.query, request.repo_name, request.limit)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/list")
async def github_list_endpoint():
    """List indexed repositories."""
    try:
        return list_indexed_repos()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))