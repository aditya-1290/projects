"""
api/routes/cache.py - Cache management endpoints.
"""

from fastapi import APIRouter, HTTPException

from api.models.requests import ClearCacheRequest
from api.models.responses import CacheStatsResponse
from memory.cache import tool_cache, response_cache
from utils.logger import log

router = APIRouter()


@router.get("/stats")
async def get_cache_stats():
    """Get cache statistics."""
    try:
        tool_stats = tool_cache.stats()
        resp_stats = response_cache.stats()

        return {
            "tool_cache": tool_stats,
            "response_cache": resp_stats,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/entries")
async def list_cache_entries():
    """List all cached tool results."""
    try:
        return {
            "entries": tool_cache.list_entries(),
            "count": len(tool_cache.list_entries()),
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("")
async def clear_cache(request: ClearCacheRequest = None):
    """Clear cache entries."""
    try:
        tool_name = request.tool if request else None
        count = tool_cache.invalidate(tool_name)

        log.info(f"[API] Cleared cache: {count} entries")

        return {
            "status": "success",
            "cleared": count,
            "tool": tool_name or "all",
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/response")
async def clear_response_cache():
    """Clear response cache."""
    try:
        count = response_cache.clear()
        return {
            "status": "success",
            "cleared": count,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/cleanup")
async def cleanup_expired():
    """Remove expired cache entries."""
    try:
        count = tool_cache.cleanup_expired()
        return {
            "status": "success",
            "removed": count,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))