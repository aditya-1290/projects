"""
api/routes/memory.py - Vector memory endpoints.
"""

import os
from fastapi import APIRouter, HTTPException, Query

from api.models.requests import ClearMemoryRequest
from api.models.responses import MemoryStatsResponse
from memory.vector_store import get_vector_store
from config.settings import settings
from utils.logger import log

router = APIRouter()


@router.get("/stats")
async def get_memory_stats():
    """Get vector memory statistics."""
    try:
        vector_store = get_vector_store()
        stats = vector_store.stats()

        return {
            "status": "success",
            "collections": stats,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/failures")
async def get_failures(
        query: str = Query(None, description="Search for similar failures"),
        limit: int = Query(10, ge=1, le=50)
):
    """Get past failure records."""
    try:
        vector_store = get_vector_store()

        if query:
            failures = vector_store.query(query, n_results=limit, collection="failure")
        else:
            failures = vector_store.get_recent_failures(limit=limit)

        return {
            "status": "success",
            "failures": failures,
            "count": len(failures),
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/clear")
async def clear_memory(confirm: str = Query("no", description="Must be 'yes' to confirm")):
    """Clear all vector memory."""
    if confirm != "yes":
        return {"status": "cancelled", "message": "Add ?confirm=yes to clear memory"}

    try:
        vector_store = get_vector_store()
        counts = vector_store.clear("all")

        # Clear memory.json file
        memory_file = settings.MEMORY_FILE
        json_cleared = False
        if os.path.exists(memory_file):
            os.remove(memory_file)
            json_cleared = True

        log.info(f"[API] Memory cleared: {counts}")

        return {
            "status": "success",
            "cleared": {
                "main": counts.get("main", 0),
                "failure": counts.get("failure", 0),
                "memory_json": json_cleared,
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/search")
async def search_memory(
        query: str,
        limit: int = Query(5, ge=1, le=20),
        collection: str = Query("main", pattern="^(main|failure)$")
):
    """Search for memories."""
    try:
        vector_store = get_vector_store()
        results = vector_store.query(query, n_results=limit, collection=collection)

        return {
            "status": "success",
            "query": query,
            "collection": collection,
            "results": results,
            "count": len(results),
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))