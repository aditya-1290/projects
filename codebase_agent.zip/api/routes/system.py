"""
api/routes/system.py - System status endpoints.
"""

from fastapi import APIRouter, HTTPException

from api.models.responses import SystemStatusResponse
from config.settings import settings
from tools import list_tools
from core.session import get_session_manager
from memory.cache import tool_cache, response_cache
from memory.vector_store import get_vector_store
from llm.backend import get_llm
from utils.logger import log

router = APIRouter()


@router.get("/status")
async def system_status():
    """Get full system status."""
    try:
        session_mgr = get_session_manager()
        session_stats = session_mgr.get_stats()

        vector_store = get_vector_store()
        memory_stats = vector_store.stats()

        tool_cache_stats = tool_cache.stats()
        response_cache_stats = response_cache.stats()

        llm = get_llm()
        llm_stats = llm.get_stats()

        tools = list_tools()

        return {
            "status": "running",
            "version": "2.0.0",
            "memory_available": True,
            "cache": {
                "tool_cache": tool_cache_stats,
                "response_cache": response_cache_stats,
            },
            "memory": {
                "main": memory_stats.get("main", {}).get("count", 0),
                "failures": memory_stats.get("failure", {}).get("count", 0),
            },
            "llm": llm_stats,
            "tools_available": tools,
            "tool_count": len(tools),
            "session_count": session_stats.get("active_sessions", 0),
            "config": {
                "model": settings.MODEL_PATH,
                "context_size": settings.N_CTX,
                "max_react_cycles": settings.MAX_REACT_CYCLES,
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/config")
async def system_config():
    """Get current configuration (safe values only)."""
    try:
        return {
            "llm": {
                "model_path": settings.MODEL_PATH,
                "context_size": settings.N_CTX,
                "temperature": settings.TEMPERATURE,
                "max_tokens": settings.MAX_TOKENS,
            },
            "agent": {
                "max_react_cycles": settings.MAX_REACT_CYCLES,
                "confidence_threshold": settings.CONFIDENCE_THRESHOLD,
                "tool_retry_count": settings.TOOL_RETRY_COUNT,
            },
            "cache": {
                "tool_cache_ttl": settings.TOOL_CACHE_TTL,
                "default_ttl": settings.DEFAULT_TOOL_TTL,
                "response_cache_ttl": settings.RESPONSE_CACHE_TTL,
            },
            "memory": {
                "max_items": settings.MAX_MEMORY_ITEMS,
                "max_failures": settings.MAX_FAILURE_ITEMS,
            },
            "session": {
                "history_size": settings.SESSION_HISTORY_SIZE,
                "cleanup_hours": settings.SESSION_CLEANUP_HOURS,
            },
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/sessions")
async def list_sessions():
    """List active sessions."""
    try:
        session_mgr = get_session_manager()
        stats = session_mgr.get_stats()

        return {
            "status": "success",
            "sessions": stats.get("sessions", []),
            "active_count": stats.get("active_sessions", 0),
            "total_messages": stats.get("total_messages", 0),
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/sessions/cleanup")
async def cleanup_sessions(max_age_hours: int = 24):
    """Clean up stale sessions."""
    try:
        session_mgr = get_session_manager()
        count = session_mgr.cleanup_stale_sessions(max_age_hours)

        log.info(f"[API] Cleaned up {count} stale sessions")

        return {
            "status": "success",
            "cleaned": count,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))