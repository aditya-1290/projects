"""
api/models/responses.py - Pydantic response models.
"""

from typing import Optional, List, Dict, Any
from pydantic import BaseModel


class ChatResponse(BaseModel):
    """Chat response model."""
    message: str
    answer: str
    time_taken: float
    session_id: Optional[str] = None


class ToolResponse(BaseModel):
    """Generic tool response."""
    status: str
    data: Optional[Dict[str, Any]] = None
    message: Optional[str] = None


class CacheStatsResponse(BaseModel):
    """Cache statistics response."""
    entries: int
    hits: int
    misses: int
    hit_rate: str
    tools_cached: List[str]


class MemoryStatsResponse(BaseModel):
    """Memory statistics response."""
    main_collection: Dict[str, Any]
    failure_collection: Dict[str, Any]
    stats: Dict[str, Any]


class SystemStatusResponse(BaseModel):
    """System status response."""
    status: str
    version: str
    memory_available: bool
    cache: Dict[str, Any]
    memory: Dict[str, Any]
    tools_available: List[str]
    tool_count: int
    session_count: int


class GitHubRepoResponse(BaseModel):
    """GitHub repository response."""
    name: str
    full_name: str
    description: Optional[str] = None
    html_url: str
    language: Optional[str] = None
    stars: int
    files_indexed: Optional[int] = None
    chunks_stored: Optional[int] = None


class ErrorResponse(BaseModel):
    """Error response model."""
    error: str
    detail: Optional[str] = None
    status_code: int