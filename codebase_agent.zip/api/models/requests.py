"""
api/models/requests.py - Pydantic request models.
"""

from typing import Optional, List
from pydantic import BaseModel, Field


class ChatRequest(BaseModel):
    """Chat request model."""
    message: str = Field(..., description="User message")
    session_id: Optional[str] = Field(None, description="Session ID for conversation continuity")
    stream: bool = Field(False, description="Stream response")


class WeatherRequest(BaseModel):
    """Weather tool request."""
    city: str = Field(..., description="City name")
    unit: str = Field("celsius", description="Temperature unit (celsius/fahrenheit)")


class TimeRequest(BaseModel):
    """Time tool request."""
    city: str = Field(..., description="City name")


class StockRequest(BaseModel):
    """Stock price request."""
    ticker: str = Field(..., description="Stock ticker symbol")


class CurrencyRequest(BaseModel):
    """Currency conversion request."""
    amount: float = Field(..., description="Amount to convert")
    from_currency: str = Field(..., description="Source currency code")
    to_currency: str = Field(..., description="Target currency code")


class NewsRequest(BaseModel):
    """News request."""
    topic: str = Field("technology", description="News topic")
    limit: int = Field(5, ge=1, le=10, description="Number of articles")


class WebSearchRequest(BaseModel):
    """Web search request."""
    query: str = Field(..., description="Search query")
    num_results: int = Field(5, ge=1, le=10, description="Number of results")
    time_filter: Optional[str] = Field(None, description="Time filter (d/w/m/y)")


class TimedNewsRequest(BaseModel):
    """Time-filtered news request."""
    query: str = Field(..., description="Search query")
    months_back: int = Field(6, ge=1, le=24, description="Months to look back")
    limit: int = Field(5, ge=1, le=10, description="Number of articles")


class TimelineRequest(BaseModel):
    """Entity timeline request."""
    entity: str = Field(..., description="Entity name")
    months_back: int = Field(12, ge=1, le=24, description="Months to look back")


class CalculatorRequest(BaseModel):
    """Calculator request."""
    expression: str = Field(..., description="Math expression")


class ConverterRequest(BaseModel):
    """Unit converter request."""
    value: float = Field(..., description="Value to convert")
    from_unit: str = Field(..., description="Source unit")
    to_unit: str = Field(..., description="Target unit")


class ReadFileRequest(BaseModel):
    """Read file request."""
    path: str = Field(..., description="File path")
    start_line: int = Field(0, description="Start line (0-indexed)")
    end_line: Optional[int] = Field(None, description="End line (exclusive)")


class WriteFileRequest(BaseModel):
    """Write file request."""
    path: str = Field(..., description="File path")
    content: str = Field(..., description="Content to write")
    append: bool = Field(False, description="Append instead of overwrite")


class ListDirectoryRequest(BaseModel):
    """List directory request."""
    path: str = Field(".", description="Directory path")
    pattern: Optional[str] = Field(None, description="Glob pattern")


class SearchCodeRequest(BaseModel):
    """Search code request."""
    directory: str = Field(..., description="Directory to search")
    query: str = Field(..., description="Search query")
    file_pattern: str = Field("*", description="File pattern")


class ExecuteCommandRequest(BaseModel):
    """Execute command request."""
    command: str = Field(..., description="Command to execute")
    timeout: int = Field(30, description="Timeout in seconds")


class AnalyzeCodeRequest(BaseModel):
    """Analyze code request."""
    file_path: str = Field(..., description="Python file path")


class GitOperationRequest(BaseModel):
    """Git operation request."""
    repo_path: str = Field(..., description="Repository path")
    operation: str = Field(..., description="Operation (status/log/diff/branch/remote)")


class GitHubIndexRequest(BaseModel):
    """GitHub index request."""
    repo_url: str = Field(..., description="GitHub repository URL")
    github_token: Optional[str] = Field(None, description="GitHub token")


class GitHubSearchRequest(BaseModel):
    """GitHub search request."""
    query: str = Field(..., description="Search query")
    repo_name: Optional[str] = Field(None, description="Filter by repository")
    limit: int = Field(10, ge=1, le=50, description="Number of results")


class GitHubIndexAllRequest(BaseModel):
    """GitHub index all request."""
    github_username: str = Field(..., description="GitHub username")
    github_token: str = Field(..., description="GitHub token")


class GitHubUserRequest(BaseModel):
    """GitHub user info request."""
    username: Optional[str] = Field(None, description="GitHub username")


class ClearCacheRequest(BaseModel):
    """Clear cache request."""
    tool: Optional[str] = Field(None, description="Specific tool to clear")


class ClearMemoryRequest(BaseModel):
    """Clear memory request."""
    confirm: str = Field("no", description="Must be 'yes' to confirm")