#!/usr/bin/env python3
"""
run.py - Main entry point for the CodeBase Multi-Agent System.
"""

import sys
import argparse
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from config.settings import settings
from utils.logger import setup_logging


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="CodeBase Agent - Multi-Agent AI System",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s --query "What is the weather in Mumbai?"
  %(prog)s --interactive
  %(prog)s --server --port 8080
  %(prog)s --terminal
  %(prog)s --agents  # Show agent status
        """
    )

    parser.add_argument("--query", "-q", help="Run a single query and exit")
    parser.add_argument("--interactive", "-i", action="store_true",
                        help="Start interactive CLI mode")
    parser.add_argument("--terminal", "-t", action="store_true",
                        help="Start rich terminal UI")
    parser.add_argument("--server", "-s", action="store_true",
                        help="Start FastAPI server with Web UI")
    parser.add_argument("--port", "-p", type=int, default=settings.API_PORT,
                        help=f"Server port (default: {settings.API_PORT})")
    parser.add_argument("--host", default=settings.API_HOST,
                        help=f"Server host (default: {settings.API_HOST})")
    parser.add_argument("--agents", "-a", action="store_true",
                        help="Show agent status and exit")
    parser.add_argument("--validate", action="store_true",
                        help="Validate configuration and exit")

    args = parser.parse_args()

    # Setup logging
    setup_logging()

    # Validate settings
    if args.validate:
        missing = settings.validate()
        if missing:
            print("❌ Configuration issues:")
            for m in missing:
                print(f"  - {m}")
            sys.exit(1)
        print("✅ Configuration valid")
        sys.exit(0)

    # Show agent status
    if args.agents:
        _show_agent_status()
        sys.exit(0)

    # Route to appropriate mode
    if args.server:
        _run_server(args.host, args.port)
    elif args.terminal:
        _run_terminal(args)
    elif args.query:
        _run_query(args.query)
    elif args.interactive:
        _run_interactive()
    else:
        parser.print_help()


def _show_agent_status():
    """Show status of all agents."""
    from agents import get_orchestrator

    print("\n🤖 CodeBase Multi-Agent System\n")
    print("=" * 50)

    orchestrator = get_orchestrator()

    print(f"\n🎭 Orchestrator: {orchestrator.name}")
    print(f"   Capabilities: {', '.join(orchestrator.capabilities)}")

    print("\n📋 Specialist Agents:")
    for role, agent in orchestrator.specialists.items():
        print(f"   {agent.name} ({role.value})")
        print(f"      Capabilities: {', '.join(agent.capabilities[:3])}...")

    print("\n" + "=" * 50)

    # Show shared memory stats
    from agents.memory import get_shared_memory, get_message_bus

    memory = get_shared_memory()
    bus = get_message_bus()

    print(f"\n💾 Shared Memory: {len(memory.get_all_keys())} keys")
    print(f"📨 Message Bus: {bus.get_stats()['pending_messages']}")
    print()


def _run_server(host: str, port: int):
    """Run FastAPI server with Web UI."""
    import uvicorn
    from api.app import app

    print(f"""
╔══════════════════════════════════════════════════════════════════╗
║              CodeBase Multi-Agent System Server                    ║
╠══════════════════════════════════════════════════════════════════╣
║  Server:   http://{host}:{port}                                  ║
║  API Docs: http://{host}:{port}/docs                             ║
║  Web UI:   http://{host}:{port}/dashboard                        ║
║  Agents:   http://{host}:{port}/api/agents/status                ║
╠══════════════════════════════════════════════════════════════════╣
║  Active Agents: Orchestrator + 6 Specialists                       ║
╚══════════════════════════════════════════════════════════════════╝
    """)

    uvicorn.run(
        "api.app:app",
        host=host,
        port=port,
        reload=settings.API_RELOAD,
    )


def _run_terminal(args):
    """Run rich terminal UI."""
    from ui.terminal.app import TerminalAgent

    agent = TerminalAgent(config_path=args.config if hasattr(args, 'config') else None)
    agent.run()


def _run_query(query: str):
    """Run single query through multi-agent system."""
    from agents import get_orchestrator

    print(f"\n🤖 Processing: {query}\n")
    print("=" * 50)

    orchestrator = get_orchestrator()
    answer = orchestrator.process_query(query)

    print(f"\n{answer}\n")
    print("=" * 50)


def _run_interactive():
    """Run interactive CLI mode with multi-agent support."""
    from agents import get_orchestrator
    from core.session import get_session_manager

    session_mgr = get_session_manager()
    session_id = session_mgr.create_session()
    orchestrator = get_orchestrator(session_id)

    print("""
╔══════════════════════════════════════════════════════════════════╗
║           CodeBase Multi-Agent System - Interactive               ║
╠══════════════════════════════════════════════════════════════════╣
║  Active Agents: Orchestrator, Code, Search, Data, GitHub,         ║
║                 Utility, Review                                   ║
║                                                                   ║
║  Type 'exit' to quit, 'agents' to see status, 'help' for commands ║
╚══════════════════════════════════════════════════════════════════╝
    """)

    while True:
        try:
            user_input = input("\nYou: ").strip()

            if not user_input:
                continue

            if user_input.lower() == "exit":
                print("Goodbye!")
                break

            if user_input.lower() == "agents":
                _show_agent_status()
                continue

            if user_input.lower() == "help":
                print("""
Commands:
  exit     - Quit the agent
  agents   - Show agent status
  clear    - Clear session history
  tools    - List available tools
  memory   - Show shared memory stats
                """)
                continue

            if user_input.lower() == "clear":
                session_mgr.clear_session(session_id)
                print("Session cleared.")
                continue

            if user_input.lower() == "tools":
                from tools import list_tools
                tools = list_tools()
                print(f"\nAvailable tools ({len(tools)}):")
                for t in sorted(tools):
                    print(f"  - {t}")
                continue

            if user_input.lower() == "memory":
                from agents.memory import get_shared_memory
                memory = get_shared_memory()
                keys = memory.get_all_keys()
                print(f"\nShared Memory ({len(keys)} keys):")
                for key in keys[:10]:
                    entry = memory.read_with_metadata(key)
                    print(f"  - {key}: from {entry.agent}")
                continue

            print("\n🤔 Processing...", end="", flush=True)
            answer = orchestrator.process_query(user_input)
            print(f"\r✅ Agent: {answer}\n")

        except KeyboardInterrupt:
            print("\nGoodbye!")
            break


if __name__ == "__main__":
    main()