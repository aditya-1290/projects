"""
agents/specialists/utility_agent.py - Utility specialist agent.
"""

from typing import Dict
from agents.base import BaseAgent, Task, AgentContext, AgentRole
from tools.utility import calculate, convert_units


class UtilityAgent(BaseAgent):
    """Specialist agent for utility operations."""

    def __init__(self, llm=None):
        super().__init__(
            name="UtilityAgent",
            role=AgentRole.UTILITY,
            capabilities=[
                "calculations", "unit_conversion", "math_operations",
                "formatting", "data_transformation",
            ],
            llm=llm,
        )

        self.tools = {
            "calculate": calculate,
            "convert_units": convert_units,
        }

    def can_handle(self, task: Task) -> bool:
        """Check if task is utility-related."""
        if task.role and task.role != AgentRole.UTILITY:
            return False

        if task.tool and task.tool in self.tools:
            return True

        utility_keywords = [
            "calculate", "compute", "math", "equation", "formula",
            "convert", "conversion", "units", "km", "miles", "kg", "pounds",
            "celsius", "fahrenheit", "liters", "gallons",
            "sqrt", "square root", "percentage", "percent",
        ]

        desc_lower = task.description.lower()
        return any(kw in desc_lower for kw in utility_keywords)

    def execute(self, task: Task, context: AgentContext) -> Task:
        """Execute a utility task."""
        self.current_task = task
        task.mark_running()
        self.log(f"Processing utility: {task.description}")

        try:
            if task.tool and task.tool in self.tools:
                result = self._execute_tool(task.tool, task.args)
                task.mark_completed(result)
            else:
                result = self._auto_execute(task)
                task.mark_completed(result)

        except Exception as e:
            self.log(f"Error: {e}", "error")
            task.mark_failed(str(e))

        self.task_history.append(task)
        return task

    def _execute_tool(self, tool_name: str, args: Dict) -> Dict:
        """Execute a specific utility tool."""
        tool_fn = self.tools[tool_name]
        return tool_fn(**args)

    def _auto_execute(self, task: Task) -> Dict:
        """Auto-detect and execute appropriate utility."""
        desc = task.description.lower()

        # Unit conversion
        conversion_keywords = ["convert", "to", "in"]
        unit_keywords = ["km", "miles", "kg", "lbs", "celsius", "fahrenheit", "liters", "gallons"]

        if any(kw in desc for kw in conversion_keywords) and any(kw in desc for kw in unit_keywords):
            args = self._extract_conversion_args(task.description)
            if args:
                return convert_units(**args)

        # Calculation
        math_keywords = ["+", "-", "*", "/", "**", "sqrt", "calculate", "compute", "="]
        if any(kw in desc for kw in math_keywords) or self._has_math_expression(task.description):
            expr = self._extract_expression(task.description)
            if expr:
                return calculate(expr)

        return {"status": "error", "message": "Could not determine appropriate utility operation"}

    def _has_math_expression(self, text: str) -> bool:
        """Check if text contains math expression."""
        import re
        return bool(re.search(r'\d+\s*[\+\-\*\/]\s*\d+', text))

    def _extract_expression(self, text: str) -> str:
        """Extract math expression from text."""
        import re

        # Look for expression pattern
        match = re.search(r'([\d\s\+\-\*\/\(\)\.]+)', text)
        if match:
            expr = match.group(1).strip()
            if any(op in expr for op in ['+', '-', '*', '/']):
                return expr

        # Handle sqrt
        sqrt_match = re.search(r'sqrt\s*(?:of)?\s*(\d+)', text, re.IGNORECASE)
        if sqrt_match:
            return f"sqrt({sqrt_match.group(1)})"

        # Handle percentage
        pct_match = re.search(r'(\d+)\s*%\s*of\s*(\d+)', text, re.IGNORECASE)
        if pct_match:
            return f"{pct_match.group(1)} / 100 * {pct_match.group(2)}"

        return None

    def _extract_conversion_args(self, text: str) -> Dict:
        """Extract unit conversion arguments."""
        import re

        # Pattern: "X unit1 to unit2"
        match = re.search(r'(\d+(?:\.\d+)?)\s*([a-zA-Z]+)\s+(?:to|in|into)\s+([a-zA-Z]+)', text, re.IGNORECASE)
        if match:
            return {
                "value": float(match.group(1)),
                "from_unit": match.group(2),
                "to_unit": match.group(3),
            }

        # Pattern: "convert X from unit1 to unit2"
        match = re.search(r'convert\s+(\d+(?:\.\d+)?)\s*(?:from)?\s*([a-zA-Z]+)\s+(?:to|into)?\s*([a-zA-Z]+)', text,
                          re.IGNORECASE)
        if match:
            return {
                "value": float(match.group(1)),
                "from_unit": match.group(2),
                "to_unit": match.group(3),
            }

        return None