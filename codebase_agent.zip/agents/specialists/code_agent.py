"""
agents/specialists/code_agent.py - Code specialist agent.
"""

from typing import Dict, List
from agents.base import BaseAgent, Task, AgentContext, AgentRole
from tools.codebase import (
    read_file, write_file, list_directory,
    analyze_code, search_code, execute_command, git_operation
)


class CodeAgent(BaseAgent):
    """Specialist agent for code operations."""

    def __init__(self, llm=None):
        super().__init__(
            name="CodeAgent",
            role=AgentRole.CODE,
            capabilities=[
                "file_reading", "file_writing", "directory_listing",
                "code_analysis", "code_search", "command_execution",
                "git_operations", "debugging", "refactoring",
            ],
            llm=llm,
        )

        # Tool mapping
        self.tools = {
            "read_file": read_file,
            "write_file": write_file,
            "list_directory": list_directory,
            "analyze_code": analyze_code,
            "search_code": search_code,
            "execute_command": execute_command,
            "git_operation": git_operation,
        }

    def can_handle(self, task: Task) -> bool:
        """Check if task is code-related."""
        if task.role and task.role != AgentRole.CODE:
            return False

        if task.tool and task.tool in self.tools:
            return True

        # Check description for code keywords
        code_keywords = [
            "code", "file", "directory", "function", "class", "debug",
            "refactor", "git", "commit", "branch", "python", "javascript",
            "read", "write", "analyze", "search", "execute", "command",
        ]

        desc_lower = task.description.lower()
        return any(kw in desc_lower for kw in code_keywords)

    def execute(self, task: Task, context: AgentContext) -> Task:
        """Execute a code-related task."""
        self.current_task = task
        task.mark_running()
        self.log(f"Executing: {task.description}")

        try:
            # If specific tool requested, use it
            if task.tool and task.tool in self.tools:
                result = self._execute_tool(task.tool, task.args)
                task.mark_completed(result)
                self.log(f"Completed tool: {task.tool}")

            # Otherwise, use LLM to determine action
            elif self.llm:
                result = self._think_and_execute(task, context)
                task.mark_completed(result)
            else:
                task.mark_failed("No tool specified and no LLM available")

        except Exception as e:
            self.log(f"Error: {e}", "error")
            task.mark_failed(str(e))

        self.task_history.append(task)
        return task

    def _execute_tool(self, tool_name: str, args: Dict) -> Dict:
        """Execute a specific tool."""
        tool_fn = self.tools[tool_name]
        return tool_fn(**args)

    def _think_and_execute(self, task: Task, context: AgentContext) -> Dict:
        """Use LLM to decide what tool to use."""
        prompt = f"""
Task: {task.description}

Available tools:
- read_file(path, start_line?, end_line?): Read a file
- write_file(path, content, append?): Write to a file
- list_directory(path, pattern?): List directory contents
- analyze_code(file_path): Analyze Python file structure
- search_code(directory, query, file_pattern?): Search code
- execute_command(command, timeout?): Run safe shell command
- git_operation(repo_path, operation): Git operations

Context:
{context.shared_memory.get('relevant_files', [])}

Return JSON with tool and args:
{{"tool": "tool_name", "args": {{...}}}}
"""

        response = self.think(prompt, context)

        import json
        import re
        match = re.search(r'\{.*\}', response, re.DOTALL)
        if match:
            try:
                decision = json.loads(match.group())
                tool_name = decision.get("tool")
                args = decision.get("args", {})

                if tool_name in self.tools:
                    return self._execute_tool(tool_name, args)
            except json.JSONDecodeError:
                pass

        return {
            "status": "error",
            "message": "Could not determine appropriate action",
            "suggestion": "Try specifying a specific tool or rephrasing",
        }

    def _get_system_prompt(self) -> str:
        return """You are CodeAgent, a specialist in code operations and analysis.
You can read, write, search, and analyze code files.
You can execute safe shell commands and perform git operations.
Always provide clear, actionable responses about code-related tasks."""