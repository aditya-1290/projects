"""
agents/specialists/data_agent.py - Data specialist agent for API-based tools.
"""

from typing import Dict
from agents.base import BaseAgent, Task, AgentContext, AgentRole
from tools.weather import get_weather, get_current_time, get_date_info, get_world_clock
from tools.finance import get_stock_price, get_gold_price, convert_currency


class DataAgent(BaseAgent):
    """Specialist agent for data/API operations."""

    def __init__(self, llm=None):
        super().__init__(
            name="DataAgent",
            role=AgentRole.DATA,
            capabilities=[
                "weather_data", "time_data", "date_info", "world_clock",
                "stock_prices", "gold_prices", "currency_conversion",
                "real_time_data", "financial_information",
            ],
            llm=llm,
        )

        self.tools = {
            "get_weather": get_weather,
            "get_current_time": get_current_time,
            "get_date_info": get_date_info,
            "get_world_clock": get_world_clock,
            "get_stock_price": get_stock_price,
            "get_gold_price": get_gold_price,
            "convert_currency": convert_currency,
        }

    def can_handle(self, task: Task) -> bool:
        """Check if task is data-related."""
        if task.role and task.role != AgentRole.DATA:
            return False

        if task.tool and task.tool in self.tools:
            return True

        data_keywords = [
            "weather", "temperature", "forecast", "climate",
            "time", "clock", "timezone", "date", "calendar",
            "stock", "share", "price", "ticker", "market",
            "gold", "silver", "commodity", "precious metal",
            "currency", "exchange", "convert", "rate", "usd", "eur", "inr",
        ]

        desc_lower = task.description.lower()
        return any(kw in desc_lower for kw in data_keywords)

    def execute(self, task: Task, context: AgentContext) -> Task:
        """Execute a data-related task."""
        self.current_task = task
        task.mark_running()
        self.log(f"Fetching data: {task.description}")

        try:
            if task.tool and task.tool in self.tools:
                result = self._execute_tool(task.tool, task.args)
                task.mark_completed(result)
                self.log(f"Completed: {task.tool}")
            else:
                # Auto-detect appropriate tool
                result = self._auto_execute(task)
                task.mark_completed(result)

        except Exception as e:
            self.log(f"Error: {e}", "error")
            task.mark_failed(str(e))

        self.task_history.append(task)
        return task

    def _execute_tool(self, tool_name: str, args: Dict) -> Dict:
        """Execute a specific data tool."""
        tool_fn = self.tools[tool_name]
        return tool_fn(**args)

    def _auto_execute(self, task: Task) -> Dict:
        """Auto-detect and execute appropriate tool."""
        desc = task.description.lower()

        # Extract city for location-based tools
        city = self._extract_city(task.description)

        # Weather
        if any(kw in desc for kw in ["weather", "temperature", "forecast", "climate"]):
            if city:
                return get_weather(city, task.args.get("unit", "celsius"))
            return {"status": "error", "message": "City not specified for weather"}

        # Time
        if any(kw in desc for kw in ["time", "clock"]) and "world" not in desc:
            if city:
                return get_current_time(city)
            return {"status": "error", "message": "City not specified for time"}

        # Date
        if any(kw in desc for kw in ["date", "day", "today"]):
            if city:
                return get_date_info(city)
            return get_date_info("London")  # Default

        # World clock
        if "world clock" in desc or "multiple" in desc:
            cities = self._extract_cities(task.description)
            if cities:
                return get_world_clock(cities)
            return {"status": "error", "message": "No cities specified for world clock"}

        # Stock
        if any(kw in desc for kw in ["stock", "share", "ticker"]):
            ticker = self._extract_ticker(task.description)
            if ticker:
                return get_stock_price(ticker)
            return {"status": "error", "message": "Ticker symbol not found"}

        # Gold
        if any(kw in desc for kw in ["gold", "xau"]):
            return get_gold_price()

        # Currency
        if any(kw in desc for kw in ["currency", "convert", "exchange"]):
            args = self._extract_currency_args(task.description)
            if args:
                return convert_currency(**args)
            return {"status": "error", "message": "Could not parse currency conversion"}

        return {"status": "error", "message": "Could not determine appropriate data tool"}

    def _extract_city(self, text: str) -> str:
        """Extract city from text."""
        import re

        # Common cities
        cities = [
            "Mumbai", "Delhi", "Bangalore", "Kolkata", "Chennai", "Hyderabad",
            "London", "New York", "Tokyo", "Paris", "Sydney", "Dubai", "Singapore",
            "Los Angeles", "Chicago", "Toronto", "Berlin", "Rome", "Madrid",
        ]

        for city in cities:
            if city.lower() in text.lower():
                return city

        # Pattern: "in City" or "for City"
        match = re.search(r'\b(?:in|for|at|of)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)', text)
        if match:
            return match.group(1)

        return None

    def _extract_cities(self, text: str) -> list:
        """Extract multiple cities from text."""
        import re
        cities = []

        common_cities = ["London", "New York", "Tokyo", "Paris", "Sydney", "Dubai", "Mumbai", "Delhi"]
        for city in common_cities:
            if city.lower() in text.lower():
                cities.append(city)

        return cities[:5] if cities else ["London", "New York", "Tokyo"]

    def _extract_ticker(self, text: str) -> str:
        """Extract stock ticker from text."""
        import re
        from utils.constants import COMMON_TICKERS

        text_lower = text.lower()
        for name, ticker in COMMON_TICKERS.items():
            if name in text_lower:
                return ticker

        match = re.search(r'\b([A-Z]{2,5}(?:\.[A-Z]{2})?)\b', text)
        return match.group(1) if match else None

    def _extract_currency_args(self, text: str) -> Dict:
        """Extract currency conversion arguments."""
        import re

        amount_match = re.search(r'(\d+(?:\.\d+)?)', text)
        if not amount_match:
            return None

        amount = float(amount_match.group(1))

        currencies = ["USD", "EUR", "GBP", "JPY", "INR", "AUD", "CAD", "CHF", "CNY"]
        found = []

        text_upper = text.upper()
        for currency in currencies:
            if currency in text_upper:
                found.append(currency)

        if len(found) >= 2:
            return {
                "amount": amount,
                "from_currency": found[0],
                "to_currency": found[1]
            }

        return None