"""
agents/specialists/review_agent.py - Review/Quality specialist agent.
"""

from typing import Dict
from agents.base import BaseAgent, Task, AgentContext, AgentRole
from core.evaluator import evaluate


class ReviewAgent(BaseAgent):
    """Specialist agent for reviewing and quality control."""

    def __init__(self, llm=None):
        super().__init__(
            name="ReviewAgent",
            role=AgentRole.REVIEW,
            capabilities=[
                "answer_evaluation", "quality_scoring", "fact_checking",
                "refinement_suggestions", "completeness_check",
            ],
            llm=llm,
        )

    def can_handle(self, task: Task) -> bool:
        """Check if task is review-related."""
        if task.role and task.role != AgentRole.REVIEW:
            return False

        review_keywords = [
            "review", "evaluate", "check", "verify", "validate",
            "quality", "score", "rate", "assess", "refine",
        ]

        desc_lower = task.description.lower()
        return any(kw in desc_lower for kw in review_keywords)

    def execute(self, task: Task, context: AgentContext) -> Task:
        """Execute a review task."""
        self.current_task = task
        task.mark_running()
        self.log(f"Reviewing: {task.description}")

        try:
            # Get the answer to review from context
            answer = context.shared_memory.get("pending_review", task.args.get("answer", ""))
            original_query = context.shared_memory.get("original_query", task.args.get("query", ""))

            if not answer:
                task.mark_failed("No answer provided for review")
                return task

            # Evaluate
            eval_result = evaluate(original_query, answer)

            # Check if refinement needed
            confidence = eval_result.get("confidence", 0.5)

            if confidence < 0.6:
                # Need refinement
                refined = self._refine_answer(original_query, answer, eval_result)
                task.mark_completed({
                    "status": "refined",
                    "original_confidence": confidence,
                    "evaluation": eval_result,
                    "refined_answer": refined,
                })
            else:
                task.mark_completed({
                    "status": "approved",
                    "confidence": confidence,
                    "evaluation": eval_result,
                })

            self.log(f"Review complete: confidence={confidence:.2f}")

        except Exception as e:
            self.log(f"Error: {e}", "error")
            task.mark_failed(str(e))

        self.task_history.append(task)
        return task

    def _refine_answer(self, query: str, answer: str, eval_result: Dict) -> str:
        """Refine a low-quality answer."""
        if not self.llm:
            return answer

        prompt = f"""
Original query: {query}

Current answer: {answer}

Evaluation: {eval_result.get('reason', 'Needs improvement')}

Please provide a refined answer that:
1. Directly addresses the query
2. Is more specific and detailed
3. Corrects any inaccuracies

Refined answer:"""

        response = self.llm.chat([
            {"role": "system", "content": "You are a review specialist. Provide refined, accurate answers."},
            {"role": "user", "content": prompt}
        ])

        return response.get("content", answer)

    def review_task_result(self, task: Task, context: AgentContext) -> Dict:
        """Review a completed task's result."""
        if task.status != task.status.COMPLETED:
            return {"status": "skipped", "reason": "Task not completed"}

        result = task.result or {}

        # Check for error indicators in result
        if isinstance(result, dict):
            if result.get("status") == "error":
                return {
                    "status": "failed",
                    "reason": result.get("message", "Unknown error"),
                    "suggestion": "Retry with different parameters",
                }

        return {
            "status": "passed",
            "reason": "Task completed successfully",
        }