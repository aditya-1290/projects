"""
agents/specialists/search_agent.py - Search specialist agent.
"""

from typing import Dict
from agents.base import BaseAgent, Task, AgentContext, AgentRole
from tools.search import web_search, get_news, search_timed_news, get_entity_timeline


class SearchAgent(BaseAgent):
    """Specialist agent for web search and news."""

    def __init__(self, llm=None):
        super().__init__(
            name="SearchAgent",
            role=AgentRole.SEARCH,
            capabilities=[
                "web_search", "news_fetching", "timeline_building",
                "fact_checking", "research", "information_gathering",
            ],
            llm=llm,
        )

        self.tools = {
            "web_search": web_search,
            "get_news": get_news,
            "search_timed_news": search_timed_news,
            "get_entity_timeline": get_entity_timeline,
        }

    def can_handle(self, task: Task) -> bool:
        """Check if task is search-related."""
        if task.role and task.role != AgentRole.SEARCH:
            return False

        if task.tool and task.tool in self.tools:
            return True

        search_keywords = [
            "search", "find", "news", "information", "latest", "timeline",
            "research", "look up", "web", "internet", "article",
        ]

        desc_lower = task.description.lower()
        return any(kw in desc_lower for kw in search_keywords)

    def execute(self, task: Task, context: AgentContext) -> Task:
        """Execute a search-related task."""
        self.current_task = task
        task.mark_running()
        self.log(f"Searching: {task.description}")

        try:
            if task.tool and task.tool in self.tools:
                result = self._execute_tool(task.tool, task.args)
                task.mark_completed(result)
            elif self.llm:
                result = self._smart_search(task, context)
                task.mark_completed(result)
            else:
                # Default to web search
                result = web_search(task.description, num_results=5)
                task.mark_completed(result)

        except Exception as e:
            self.log(f"Error: {e}", "error")
            task.mark_failed(str(e))

        self.task_history.append(task)
        return task

    def _execute_tool(self, tool_name: str, args: Dict) -> Dict:
        """Execute a specific search tool."""
        tool_fn = self.tools[tool_name]
        return tool_fn(**args)

    def _smart_search(self, task: Task, context: AgentContext) -> Dict:
        """Perform intelligent search based on task description."""
        # Detect if time-sensitive
        time_keywords = ["last", "recent", "past", "month", "year", "today", "latest"]
        desc_lower = task.description.lower()

        if any(kw in desc_lower for kw in time_keywords):
            # Use timed news
            months = self._extract_months(task.description)
            return search_timed_news(task.description, months_back=months, limit=5)

        # Check if entity timeline needed
        entity_keywords = ["history", "timeline", "development", "progress", "evolution"]
        if any(kw in desc_lower for kw in entity_keywords):
            entity = self._extract_entity(task.description)
            if entity:
                return get_entity_timeline(entity, months_back=12)

        # Default to web search
        return web_search(task.description, num_results=5)

    def _extract_months(self, text: str) -> int:
        """Extract number of months from text."""
        import re
        patterns = [
            r'last\s+(\d+)\s+months?',
            r'past\s+(\d+)\s+months?',
            r'(\d+)\s+months?\s+(?:ago|back)',
        ]
        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                return int(match.group(1))
        return 6  # Default

    def _extract_entity(self, text: str) -> str:
        """Extract entity name from text."""
        # Simple heuristic: proper nouns after "of" or before keywords
        import re
        patterns = [
            r'(?:of|for|about)\s+([A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+)*)',
            r'([A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+)*)\s+(?:timeline|history|development)',
        ]
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                return match.group(1)
        return text[:50]