"""
agents/specialists/github_agent.py - GitHub specialist agent.
"""

from typing import Dict
from agents.base import BaseAgent, Task, AgentContext, AgentRole
# Updated import path
from tools.github_tools import (
    get_github_user_info,
    list_github_user_repos,
    get_repo_contents,
    get_file_content,
    index_github_repo,
    index_all_user_repos,
    search_indexed_code,
    list_indexed_repos,
)


class GitHubAgent(BaseAgent):
    """Specialist agent for GitHub operations."""

    def __init__(self, llm=None):
        super().__init__(
            name="GitHubAgent",
            role=AgentRole.GITHUB,
            capabilities=[
                "repo_indexing", "code_search", "user_info",
                "repo_listing", "file_retrieval", "bulk_indexing",
            ],
            llm=llm,
        )

        self.tools = {
            "get_github_user_info": get_github_user_info,
            "list_github_user_repos": list_github_user_repos,
            "get_repo_contents": get_repo_contents,
            "get_file_content": get_file_content,
            "index_github_repo": index_github_repo,
            "index_all_user_repos": index_all_user_repos,
            "search_indexed_code": search_indexed_code,
            "list_indexed_repos": list_indexed_repos,
        }

    def can_handle(self, task: Task) -> bool:
        """Check if task is GitHub-related."""
        if task.role and task.role != AgentRole.GITHUB:
            return False

        if task.tool and task.tool in self.tools:
            return True

        github_keywords = [
            "github_tools", "repo", "repository", "git", "pull request", "issue",
            "index repo", "search code", "github_tools user", "clone",
        ]

        desc_lower = task.description.lower()

        # Also check for GitHub URLs
        if "github_tools.com" in desc_lower:
            return True

        return any(kw in desc_lower for kw in github_keywords)

    def execute(self, task: Task, context: AgentContext) -> Task:
        """Execute a GitHub-related task."""
        self.current_task = task
        task.mark_running()
        self.log(f"Executing GitHub task: {task.description}")

        try:
            if task.tool and task.tool in self.tools:
                result = self._execute_tool(task.tool, task.args)
                task.mark_completed(result)
            else:
                result = self._auto_execute(task)
                task.mark_completed(result)

        except Exception as e:
            self.log(f"Error: {e}", "error")
            task.mark_failed(str(e))

        self.task_history.append(task)
        return task

    def _execute_tool(self, tool_name: str, args: Dict) -> Dict:
        """Execute a specific GitHub tool."""
        tool_fn = self.tools[tool_name]
        return tool_fn(**args)

    def _auto_execute(self, task: Task) -> Dict:
        """Auto-detect and execute appropriate GitHub operation."""
        desc = task.description.lower()

        # Check for GitHub URL
        url = self._extract_github_url(task.description)

        # Index repository
        if url and ("index" in desc or "analyze" in desc or "scan" in desc):
            return index_github_repo(url, task.args.get("github_token"))

        # Search indexed code
        if "search" in desc and ("code" in desc or "repository" in desc):
            query = task.description.replace("search", "").replace("code", "").strip()
            repo = self._extract_repo_name(task.description)
            return search_indexed_code(query, repo, limit=10)

        # List indexed repos
        if "list" in desc and ("indexed" in desc or "repositories" in desc):
            return list_indexed_repos()

        # Get user info
        if "user" in desc or "profile" in desc:
            username = self._extract_username(task.description)
            return get_github_user_info(username)

        # List user repos
        if "repositories" in desc or "repos" in desc:
            username = self._extract_username(task.description)
            return list_github_user_repos(username)

        # Get file content
        if url and "file" in desc:
            file_path = self._extract_file_path(task.description)
            if file_path:
                repo_name = self._extract_repo_from_url(url)
                return get_file_content(repo_name, file_path)

        # Default: if URL provided, get repo contents
        if url:
            repo_name = self._extract_repo_from_url(url)
            return get_repo_contents(repo_name, "")

        return {"status": "error", "message": "Could not determine appropriate GitHub operation"}

    def _extract_github_url(self, text: str) -> str:
        """Extract GitHub URL from text."""
        import re
        match = re.search(r'https?://github_tools\.com/[^\s<>"\']+', text)
        return match.group(0) if match else None

    def _extract_repo_from_url(self, url: str) -> str:
        """Extract repo full name from URL."""
        import re
        match = re.search(r'github_tools\.com/([^/]+/[^/\s]+)', url)
        if match:
            return match.group(1).replace('.git', '')
        return None

    def _extract_username(self, text: str) -> str:
        """Extract GitHub username from text."""
        import re

        # Pattern: @username or username after "user"
        match = re.search(r'@([a-zA-Z0-9-]+)', text)
        if match:
            return match.group(1)

        match = re.search(r'(?:user|profile|of)\s+([a-zA-Z0-9-]+)', text, re.IGNORECASE)
        if match:
            return match.group(1)

        return None

    def _extract_repo_name(self, text: str) -> str:
        """Extract repository name from text."""
        import re
        match = re.search(r'(?:repo|repository)\s+([a-zA-Z0-9_.-]+/[a-zA-Z0-9_.-]+)', text)
        if match:
            return match.group(1)
        return None

    def _extract_file_path(self, text: str) -> str:
        """Extract file path from text."""
        import re
        match = re.search(r'(?:file|path)\s+([a-zA-Z0-9_/. -]+\.\w+)', text)
        if match:
            return match.group(1).strip()
        return None