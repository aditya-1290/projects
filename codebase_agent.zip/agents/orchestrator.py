"""
agents/orchestrator.py - Main orchestrator agent that coordinates specialists.
"""

from typing import Optional, Dict, List, Any
from dataclasses import dataclass, field
import json
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

from agents.base import BaseAgent, Task, AgentContext, AgentRole, TaskStatus
from agents.specialists import (
    CodeAgent, SearchAgent, DataAgent,
    GitHubAgent, UtilityAgent, ReviewAgent
)
from llm.backend import get_llm
from utils.logger import log


@dataclass
class OrchestrationPlan:
    """Plan for executing a complex query."""
    original_query: str
    tasks: List[Task] = field(default_factory=list)
    current_task_index: int = 0
    completed: bool = False

    def next_task(self) -> Optional[Task]:
        if self.current_task_index < len(self.tasks):
            task = self.tasks[self.current_task_index]
            self.current_task_index += 1
            return task
        return None

    def has_more(self) -> bool:
        return self.current_task_index < len(self.tasks)

    def add_task(self, task: Task):
        self.tasks.append(task)


class OrchestratorAgent(BaseAgent):
    """
    Main orchestrator that coordinates specialist agents.
    """

    def __init__(self, session_id: Optional[str] = None):
        super().__init__(
            name="Orchestrator",
            role=AgentRole.ORCHESTRATOR,
            capabilities=[
                "task_decomposition", "agent_routing", "result_synthesis",
                "quality_control", "multi_step_reasoning",
            ],
            llm=get_llm(),
        )

        self.session_id = session_id
        self.context = AgentContext(
            session_id=session_id or "default",
            conversation_history=[],
            shared_memory={},
        )

        # Initialize ALL specialist agents
        self.specialists = {
            AgentRole.CODE: CodeAgent(self.llm),
            AgentRole.SEARCH: SearchAgent(self.llm),
            AgentRole.DATA: DataAgent(self.llm),
            AgentRole.GITHUB: GitHubAgent(self.llm),
            AgentRole.UTILITY: UtilityAgent(self.llm),
            AgentRole.REVIEW: ReviewAgent(self.llm),
        }

        # Task history
        self.plans: List[OrchestrationPlan] = []
        self.task_history: List[Task] = []
        self.max_parallel_tools = 5  # Max concurrent tool executions

    def can_handle(self, task: Task) -> bool:
        """Orchestrator can handle any task by delegating."""
        return True

    def execute(self, task: Task, context: AgentContext) -> Task:
        """Execute a task by delegating or handling directly."""
        task.mark_running()

        # Route to specialist
        specialist = self._route_task(task)

        if specialist:
            self.log(f"Delegating to {specialist.name}: {task.description}")
            task = specialist.execute(task, context)
        else:
            self.log(f"Handling directly: {task.description}")
            task = self._handle_directly(task)

        self.task_history.append(task)
        return task

    def process_query(self, user_query: str) -> str:
        """
        Process a user query through the multi-agent system.
        """
        self.log(f"Processing: {user_query[:100]}...")

        # Step 1: Classify the query
        try:
            from core.classifier import classify
            from utils.constants import QueryType

            classification = classify(user_query)
            query_type = classification["type"]
        except Exception as e:
            self.log(f"Classification error: {e}", "warning")
            return self._fallback_web_search(user_query)

        self.log(f"Classified as: {query_type.value}")

        # Step 2: Route based on type
        if query_type == QueryType.CONVERSATIONAL:
            task = Task(description=user_query)
            result = self._handle_directly(task)
            return result.result.get("response", "I couldn't process that.")

        # Step 3: For tool-using queries, determine the right agent
        plan = classification.get("plan", {})
        steps = plan.get("steps", [])

        if steps:
            # Single step - direct delegation
            return self._execute_single_step(user_query, steps[0])

        # Complex/multi-step query
        return self._process_complex_query(user_query)

    def _execute_single_step(self, query: str, step: Dict) -> str:
        """Execute a single tool step - FIXED to prevent recursion."""
        tool_name = step.get("tool")
        args = step.get("args", {})
        task_desc = step.get("task", query)

        if not tool_name:
            return f"I understand you're asking about: {task_desc}"

        self.log(f"Executing single step: {tool_name} with args: {args}")

        # Execute tool directly without going through specialist agents
        # This avoids the recursion issue
        try:
            from tools import get_tool

            # Fix common argument name issues
            if tool_name == "get_weather" and "location" in args:
                args["city"] = args.pop("location")
            if tool_name == "get_current_time" and "location" in args:
                args["city"] = args.pop("location")

            tool_fn = get_tool(tool_name)
            result = tool_fn(**args)

            self.log(f"Tool result: {result.get('status', 'unknown')}")

            if result.get("status") == "success":
                # Create a mock task for formatting
                mock_task = Task(
                    description=task_desc,
                    tool=tool_name,
                    args=args,
                )
                mock_task.result = result
                return self._format_tool_result(query, mock_task)
            else:
                return f"Could not complete: {result.get('message', 'Unknown error')}"

        except Exception as e:
            self.log(f"Tool execution error: {e}", "error")
            return f"Error executing {tool_name}: {str(e)}"

    def _extract_cities(self, query: str) -> List[str]:
        """Extract city names from query."""
        cities = []
        query_lower = query.lower()

        common_cities = ["mumbai", "delhi", "bangalore", "kolkata", "chennai", "hyderabad",
                         "london", "tokyo", "new york", "paris", "sydney", "dubai", "singapore"]

        for city in common_cities:
            if city in query_lower:
                cities.append(city.title())

        return cities if cities else ["Mumbai"]  # Default to Mumbai

    def _extract_ticker(self, query: str) -> Optional[str]:
        """Extract stock ticker from query."""
        query_lower = query.lower()

        ticker_map = {
            "apple": "AAPL",
            "tesla": "TSLA",
            "google": "GOOGL",
            "microsoft": "MSFT",
            "amazon": "AMZN",
            "meta": "META",
            "nvidia": "NVDA",
        }

        for name, ticker in ticker_map.items():
            if name in query_lower:
                return ticker

        return None

    def _extract_all_tools(self, query: str) -> List[Dict]:
        """Extract ALL tool calls from a multi-intent query."""
        tools = []
        query_lower = query.lower()

        # Extract all cities mentioned
        cities = self._extract_cities(query)

        # Weather intents
        if "weather" in query_lower:
            for city in cities:
                tools.append({
                    "tool": "get_weather",
                    "args": {"city": city},
                    "desc": f"Weather in {city}"
                })

        # Time intents
        if "time" in query_lower:
            for city in cities:
                if not any(t["tool"] == "get_current_time" and t["args"].get("city") == city for t in tools):
                    tools.append({
                        "tool": "get_current_time",
                        "args": {"city": city},
                        "desc": f"Time in {city}"
                    })

        # Gold intent
        if "gold" in query_lower:
            tools.append({
                "tool": "get_gold_price",
                "args": {},
                "desc": "Gold price"
            })

        # Stock intents
        tickers = self._extract_all_tickers(query)
        for ticker in tickers:
            tools.append({
                "tool": "get_stock_price",
                "args": {"ticker": ticker},
                "desc": f"Stock price for {ticker}"
            })

        # Currency conversion intent (if gold needs INR conversion)
        if "gold" in query_lower and ("inr" in query_lower or "rupee" in query_lower):
            tools.append({
                "tool": "convert_currency",
                "args": {"amount": 1, "from_currency": "USD", "to_currency": "INR"},
                "desc": "USD to INR conversion rate"
            })

        return tools

    def _extract_all_tickers(self, query: str) -> List[str]:
        """Extract all stock tickers from query."""
        tickers = []
        query_lower = query.lower()

        ticker_map = {
            "apple": "AAPL", "tesla": "TSLA", "google": "GOOGL",
            "microsoft": "MSFT", "amazon": "AMZN", "meta": "META",
            "nvidia": "NVDA", "netflix": "NFLX",
        }

        for name, ticker in ticker_map.items():
            if name in query_lower:
                tickers.append(ticker)

        return tickers

    def _extract_cities(self, query: str) -> List[str]:
        """Extract all city names from query."""
        cities = []
        query_lower = query.lower()

        common_cities = [
            "mumbai", "delhi", "bangalore", "kolkata", "chennai", "hyderabad",
            "london", "tokyo", "new york", "paris", "sydney", "dubai", "singapore",
            "pune", "ahmedabad", "jaipur", "lucknow", "kanpur", "nagpur",
        ]

        for city in common_cities:
            if city in query_lower:
                cities.append(city.title())

        return cities if cities else ["Mumbai"]

    def _execute_single_tool(self, tool_info: Dict) -> Optional[Dict]:
        """Execute a single tool and return result."""
        try:
            from tools import get_tool
            tool_fn = get_tool(tool_info["tool"])
            result = tool_fn(**tool_info["args"])

            if result.get("status") == "success":
                return result
            return None
        except Exception as e:
            self.log(f"Tool {tool_info['tool']} error: {e}", "warning")
            return None

    def _process_complex_query(self, query: str) -> str:
        """Process complex query with PARALLEL tool execution."""
        self.log(f"Processing complex query: {query[:100]}...")

        # Extract all required tools
        tools_to_run = self._extract_all_tools(query)

        if not tools_to_run:
            return self._fallback_web_search(query)

        self.log(f"Executing {len(tools_to_run)} tools in PARALLEL")

        # Execute all tools simultaneously
        results = []
        with ThreadPoolExecutor(max_workers=min(len(tools_to_run), self.max_parallel_tools)) as executor:
            futures = {}
            for tool_info in tools_to_run:
                future = executor.submit(self._execute_single_tool, tool_info)
                futures[future] = tool_info

            for future in as_completed(futures):
                tool_info = futures[future]
                try:
                    result = future.result(timeout=30)
                    if result:
                        results.append(result)
                except Exception as e:
                    self.log(f"Tool {tool_info['tool']} failed: {e}", "warning")

        if results:
            return self._synthesize_results(query, results)

        return self._fallback_web_search(query)

    def _decompose_with_llm(self, query: str) -> Optional[Dict]:
        """Use LLM to decompose complex query."""
        prompt = f"""
Break down this query into individual tool calls:

Query: {query}

Available tools:
- get_weather(city) - Get weather for a city
- get_current_time(city) - Get current time for a city
- web_search(query) - Search the web
- get_stock_price(ticker) - Get stock price
- convert_currency(amount, from_currency, to_currency) - Convert currency
- calculate(expression) - Calculate math expression

Return JSON with steps:
{{"steps": [{{"task": "description", "tool": "tool_name", "args": {{...}}}}]}}

Example for "weather in Mumbai and time in Tokyo":
{{"steps": [
    {{"task": "Get Mumbai weather", "tool": "get_weather", "args": {{"city": "Mumbai"}}}},
    {{"task": "Get Tokyo time", "tool": "get_current_time", "args": {{"city": "Tokyo"}}}}
]}}
"""

        response = self.think(prompt, self.context)

        try:
            match = re.search(r'\{.*\}', response, re.DOTALL)
            if match:
                return json.loads(match.group())
        except:
            pass

        return None

    def _fallback_web_search(self, query: str) -> str:
        """Fallback to web search - NO LLM CALLS."""
        try:
            from tools.search.web_search import web_search
            result = web_search(query, num_results=5)

            if result.get("status") == "success":
                results = result.get("results", [])
                if results:
                    summary = "\n".join([f"• {r.get('title', '')}" for r in results[:3]])
                    return f"Here's what I found from the web:\n{summary}"

            return "I couldn't find relevant information for your query. Please try rephrasing."
        except Exception as e:
            self.log(f"Web search fallback error: {e}", "error")
            return "I encountered an error while searching. Please try again."

    def _synthesize_results(self, query: str, results: List[Dict]) -> str:
        """Synthesize multiple parallel results into one response."""
        if not results:
            return "I couldn't get the information you requested."

        parts = []

        for result in results:
            # Weather
            if "temperature" in result:
                city = result.get("city", "the city")
                temp = result.get("temperature", "N/A")
                feels = result.get("feels_like", "N/A")
                humidity = result.get("humidity", "N/A")
                parts.append(f"🌤️ **{city}**: {temp}°C (feels like {feels}°C), {humidity}% humidity")

            # Time
            elif "datetime" in result and "timezone" in result:
                city = result.get("city", "the city")
                dt = result.get("datetime", "N/A")
                parts.append(f"🕐 **{city}**: {dt}")

            # Gold
            elif "price_per_troy_oz" in result:
                price = result.get("price_per_troy_oz", "N/A")
                parts.append(f"🥇 **Gold**: ${price} USD per troy ounce")

            # Stock
            elif "price" in result and result.get("ticker"):
                ticker = result.get("ticker", "")
                name = result.get("name", ticker)
                price = result.get("price", "N/A")
                currency = result.get("currency", "USD")
                parts.append(f"📈 **{name}** ({ticker}): {price} {currency}")

            # Currency conversion
            elif "converted_amount" in result:
                rate = result.get("exchange_rate", "N/A")
                parts.append(f"💱 **USD to INR**: 1 USD = {rate} INR")

        if parts:
            return "Here's the information you requested:\n\n" + "\n".join(parts)

        return f"I found {len(results)} pieces of information but couldn't format them properly."

    def _format_results_simple(self, results: List[Dict]) -> str:
        """Simple formatting of multiple results."""
        parts = []
        for r in results:
            if "temperature" in r:
                parts.append(f"Weather in {r.get('city', 'city')}: {r.get('temperature')}°C")
            if "datetime" in r:
                parts.append(f"Time in {r.get('city', 'city')}: {r.get('datetime')}")
            if "price" in r:
                parts.append(f"Price: {r.get('price')}")
        return "\n".join(parts) if parts else "Information retrieved."

    def _get_role_for_tool(self, tool_name: str) -> AgentRole:
        """Determine which agent role should handle a tool."""
        tool_role_map = {
            # Data Agent
            "get_weather": AgentRole.DATA,
            "get_current_time": AgentRole.DATA,
            "get_date_info": AgentRole.DATA,
            "get_world_clock": AgentRole.DATA,
            "get_stock_price": AgentRole.DATA,
            "get_gold_price": AgentRole.DATA,
            "convert_currency": AgentRole.DATA,
            # Search Agent
            "web_search": AgentRole.SEARCH,
            "get_news": AgentRole.SEARCH,
            "search_timed_news": AgentRole.SEARCH,
            "get_entity_timeline": AgentRole.SEARCH,
            # Code Agent
            "read_file": AgentRole.CODE,
            "write_file": AgentRole.CODE,
            "list_directory": AgentRole.CODE,
            "analyze_code": AgentRole.CODE,
            "search_code": AgentRole.CODE,
            "execute_command": AgentRole.CODE,
            "git_operation": AgentRole.CODE,
            # GitHub Agent
            "index_github_repo": AgentRole.GITHUB,
            "search_indexed_code": AgentRole.GITHUB,
            "list_indexed_repos": AgentRole.GITHUB,
            # Utility Agent
            "calculate": AgentRole.UTILITY,
            "convert_units": AgentRole.UTILITY,
        }
        return tool_role_map.get(tool_name, AgentRole.SEARCH)

    def _execute_tool_directly(self, query: str, tool_name: str, args: Dict, task_desc: str) -> str:
        """Execute a tool directly without specialist agent."""
        try:
            from tools import get_tool
            tool_fn = get_tool(tool_name)
            result = tool_fn(**args)

            if result.get("status") == "success":
                if tool_name == "get_weather":
                    return f"Weather in {args.get('city', 'city')}: {result.get('temperature')}°C, feels like {result.get('feels_like')}°C with {result.get('humidity')}% humidity."
                elif tool_name == "get_current_time":
                    return f"Current time in {args.get('city', 'city')}: {result.get('datetime')} ({result.get('timezone')})"
                else:
                    return json.dumps(result, indent=2)
            else:
                return f"Could not complete: {result.get('message', 'Unknown error')}"
        except Exception as e:
            self.log(f"Direct tool execution error: {e}", "error")
            return f"Error executing {tool_name}: {str(e)}"

    def _format_tool_result(self, query: str, task: Task) -> str:
        """Format a tool result into a natural response - NO LLM CALLS."""
        if not task.result:
            return "I couldn't get that information."

        result = task.result

        # Direct formatting without LLM to prevent recursion
        if task.tool == "get_weather":
            city = task.args.get("city", "the city")
            temp = result.get("temperature", "N/A")
            humidity = result.get("humidity", "N/A")
            feels_like = result.get("feels_like", "N/A")
            return f"The current weather in {city} is {temp}°C with {humidity}% humidity. It feels like {feels_like}°C."

        elif task.tool == "get_current_time":
            city = task.args.get("city", "the city")
            dt = result.get("datetime", "N/A")
            tz = result.get("timezone", "")
            return f"The current time in {city} is {dt} ({tz})."

        elif task.tool == "get_gold_price":
            price_usd = result.get("price_per_troy_oz", "N/A")
            return f"The current gold price is ${price_usd} USD per troy ounce."

        elif task.tool == "get_stock_price":
            ticker = task.args.get("ticker", "")
            price = result.get("price", "N/A")
            currency = result.get("currency", "USD")
            name = result.get("name", ticker)
            return f"{name} ({ticker}) is trading at {price} {currency}."

        elif task.tool == "convert_currency":
            amount = task.args.get("amount", 0)
            from_cur = task.args.get("from_currency", "")
            to_cur = task.args.get("to_currency", "")
            converted = result.get("converted_amount", "N/A")
            return f"{amount} {from_cur} converts to {converted} {to_cur}."

        elif task.tool == "web_search":
            results = result.get("results", [])
            if results:
                summary = "\n".join([f"• {r.get('title', '')}" for r in results[:3]])
                return f"Here's what I found:\n{summary}"
            return "I couldn't find relevant information for your search."

        else:
            # Generic formatting
            if isinstance(result, dict):
                # Remove status field for cleaner output
                clean_result = {k: v for k, v in result.items() if k != "status"}
                if clean_result:
                    return json.dumps(clean_result, indent=2)[:500]
            return str(result)[:500]

    def _route_task(self, task: Task) -> Optional[BaseAgent]:
        """Find the best specialist for a task."""
        if task.role and task.role in self.specialists:
            return self.specialists[task.role]

        for specialist in self.specialists.values():
            if specialist.can_handle(task):
                return specialist

        return None

    def _handle_directly(self, task: Task) -> Task:
        """Handle a task without delegation."""
        task.mark_running()

        prompt = f"Answer this query conversationally: {task.description}"
        response = self.think(prompt, self.context)

        task.mark_completed({
            "status": "success",
            "response": response or f"I understand you're asking about: {task.description}",
        })

        return task

    def get_status(self) -> Dict:
        """Get orchestrator status for UI."""
        return {
            "name": self.name,
            "role": self.role.value,
            "specialists": {
                role.value: {
                    "name": agent.name,
                    "current_task": agent.current_task.description if agent.current_task else None,
                    "tasks_completed": len([t for t in agent.task_history if t.status == TaskStatus.COMPLETED]),
                }
                for role, agent in self.specialists.items()
            },
            "task_history": len(self.task_history),
        }


# =============================================================================
# Global orchestrator instance
# =============================================================================

_orchestrator: Optional[OrchestratorAgent] = None


def get_orchestrator(session_id: Optional[str] = None) -> OrchestratorAgent:
    """
    Get or create the orchestrator instance.

    Args:
        session_id: Optional session ID for the orchestrator

    Returns:
        OrchestratorAgent instance
    """
    global _orchestrator

    if _orchestrator is None:
        _orchestrator = OrchestratorAgent(session_id)
        log.info("[Orchestrator] Created new orchestrator instance")

    return _orchestrator


def reset_orchestrator():
    """Reset the global orchestrator instance."""
    global _orchestrator
    if _orchestrator:
        _orchestrator.shutdown()
    _orchestrator = None
    log.info("[Orchestrator] Reset orchestrator instance")
