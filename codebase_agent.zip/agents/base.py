"""
agents/base.py - Updated base agent with messaging support.
"""

from abc import ABC, abstractmethod
from typing import Optional, Dict, List, Any, Callable
from dataclasses import dataclass, field
from enum import Enum
import uuid
import time
import threading

from utils.logger import log
from agents.memory import get_shared_memory, get_message_bus, Message, MessageType, MessagePriority


class AgentRole(Enum):
    """Agent roles in the system."""
    ORCHESTRATOR = "orchestrator"
    CODE = "code"
    SEARCH = "search"
    GITHUB = "github_tools"
    DATA = "data"
    UTILITY = "utility"
    REVIEW = "review"


class TaskStatus(Enum):
    """Task execution status."""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    DELEGATED = "delegated"


@dataclass
class Task:
    """Task to be executed by an agent."""
    description: str
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    role: Optional[AgentRole] = None
    tool: Optional[str] = None
    args: Dict[str, Any] = field(default_factory=dict)
    status: TaskStatus = TaskStatus.PENDING
    result: Optional[Dict] = None
    error: Optional[str] = None
    created_at: float = field(default_factory=time.time)
    completed_at: Optional[float] = None
    parent_task: Optional[str] = None
    dependencies: List[str] = field(default_factory=list)

    def mark_running(self):
        self.status = TaskStatus.RUNNING

    def mark_completed(self, result: Dict):
        self.status = TaskStatus.COMPLETED
        self.result = result
        self.completed_at = time.time()

    def mark_failed(self, error: str):
        self.status = TaskStatus.FAILED
        self.error = error
        self.completed_at = time.time()

    def mark_delegated(self):
        self.status = TaskStatus.DELEGATED

    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "description": self.description,
            "role": self.role.value if self.role else None,
            "tool": self.tool,
            "args": self.args,
            "status": self.status.value,
            "result": self.result,
            "error": self.error,
        }


@dataclass
class AgentContext:
    """Context passed to agents during execution."""
    session_id: str
    conversation_history: List[Dict] = field(default_factory=list)
    shared_memory: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)


class BaseAgent(ABC):
    """Base class for all agents with messaging support."""

    def __init__(
        self,
        name: str,
        role: AgentRole,
        capabilities: List[str],
        llm=None,
    ):
        self.name = name
        self.role = role
        self.capabilities = capabilities
        self.llm = llm
        self.current_task: Optional[Task] = None
        self.task_history: List[Task] = []

        # Messaging support
        self.shared_memory = get_shared_memory()
        self.message_bus = get_message_bus()
        self.message_bus.register_agent(self.name)

        # Background message processing
        self._running = True
        self._message_thread = threading.Thread(target=self._process_messages, daemon=True)
        self._message_thread.start()

        # Register message handlers
        self._register_handlers()

    def _register_handlers(self):
        """Register message handlers."""
        self.message_bus.register_handler(self.name, MessageType.TASK_REQUEST, self._handle_task_request)
        self.message_bus.register_handler(self.name, MessageType.QUERY, self._handle_query)
        self.message_bus.register_handler(self.name, MessageType.BROADCAST, self._handle_broadcast)

    def _process_messages(self):
        """Background thread to process incoming messages."""
        while self._running:
            try:
                message = self.message_bus.receive(self.name, timeout=1.0)
                if message:
                    self._handle_message(message)
            except Exception as e:
                log.error(f"[{self.name}] Message processing error: {e}")

    def _handle_message(self, message: Message):
        """Handle an incoming message."""
        log.debug(f"[{self.name}] Received {message.type.value} from {message.sender}")

        # Default handling - can be overridden
        if message.type == MessageType.RESPONSE:
            self._handle_response(message)

    def _handle_task_request(self, message: Message):
        """Handle a task request message."""
        task_data = message.content
        task = Task(
            description=task_data.get("description", ""),
            role=task_data.get("role"),
            tool=task_data.get("tool"),
            args=task_data.get("args", {}),
        )

        if self.can_handle(task):
            context = AgentContext(
                session_id=message.metadata.get("session_id", "default"),
                shared_memory=self.shared_memory.get_by_prefix(f"session_{message.metadata.get('session_id')}"),
            )
            result = self.execute(task, context)

            self.message_bus.respond(message, result.to_dict(), self.name)
        else:
            self.message_bus.respond(message, {"error": "Cannot handle this task"}, self.name)

    def _handle_query(self, message: Message):
        """Handle a query message."""
        # Default: respond with capabilities
        self.message_bus.respond(message, {
            "name": self.name,
            "role": self.role.value,
            "capabilities": self.capabilities,
        }, self.name)

    def _handle_broadcast(self, message: Message):
        """Handle a broadcast message."""
        # Store in shared memory
        key = f"broadcast_{message.id}"
        self.shared_memory.write(key, message.content, message.sender, ttl=300)

    def _handle_response(self, message: Message):
        """Handle a response message."""
        # Store in shared memory
        key = f"response_{message.correlation_id}"
        self.shared_memory.write(key, message.content, message.sender, ttl=3600)

    def send_task_request(self, recipient: str, task: Task, session_id: str) -> Optional[Dict]:
        """Send a task request to another agent and wait for response."""
        message = Message(
            type=MessageType.TASK_REQUEST,
            sender=self.name,
            recipient=recipient,
            content={
                "description": task.description,
                "role": task.role.value if task.role else None,
                "tool": task.tool,
                "args": task.args,
            },
            priority=MessagePriority.NORMAL,
            metadata={"session_id": session_id},
        )

        response = self.message_bus.request(message, timeout=30.0)
        return response.content if response else None

    def query_agent(self, recipient: str, query: str) -> Optional[Dict]:
        """Query another agent for information."""
        message = Message(
            type=MessageType.QUERY,
            sender=self.name,
            recipient=recipient,
            content=query,
        )

        response = self.message_bus.request(message, timeout=10.0)
        return response.content if response else None

    def broadcast_status(self, status: str, metadata: Dict = None):
        """Broadcast status update to all agents."""
        self.message_bus.broadcast(
            self.name,
            {"status": status, "metadata": metadata or {}},
            priority=MessagePriority.LOW,
        )

    @abstractmethod
    def can_handle(self, task: Task) -> bool:
        """Check if this agent can handle the task."""
        pass

    @abstractmethod
    def execute(self, task: Task, context: AgentContext) -> Task:
        """Execute the task and return updated task."""
        pass

    def think(self, prompt: str, context: AgentContext) -> str:
        """Think step - analyze and plan."""
        if self.llm:
            messages = [
                {"role": "system", "content": self._get_system_prompt()},
                {"role": "user", "content": prompt}
            ]
            response = self.llm.chat(messages)
            return response.get("content", "")
        return ""

    def _get_system_prompt(self) -> str:
        """Get the system prompt for this agent."""
        return f"""You are {self.name}, a {self.role.value} specialist agent.
Your capabilities: {', '.join(self.capabilities)}.
Focus on your specialty and provide accurate, actionable responses."""

    def log(self, message: str, level: str = "info"):
        """Log a message with agent context."""
        log_msg = f"[{self.name}] {message}"
        if level == "debug":
            log.debug(log_msg)
        elif level == "warning":
            log.warning(log_msg)
        elif level == "error":
            log.error(log_msg)
        else:
            log.info(log_msg)

    def shutdown(self):
        """Shutdown the agent."""
        self._running = False
        self.message_bus.unregister_agent(self.name)
        self.broadcast_status("offline")

    def __repr__(self) -> str:
        return f"{self.name}({self.role.value})"