"""
agents/memory/shared_memory.py - Shared blackboard for inter-agent communication.
"""

from typing import Dict, Any, Optional, List
from datetime import datetime
from dataclasses import dataclass, field
import json


@dataclass
class MemoryEntry:
    """An entry in shared memory."""
    key: str
    value: Any
    agent: str
    timestamp: datetime = field(default_factory=datetime.now)
    ttl: Optional[int] = None  # Time-to-live in seconds
    metadata: Dict[str, Any] = field(default_factory=dict)

    def is_expired(self) -> bool:
        """Check if entry has expired."""
        if self.ttl is None:
            return False
        age = (datetime.now() - self.timestamp).total_seconds()
        return age > self.ttl


class SharedMemory:
    """
    Shared blackboard for inter-agent communication.

    Agents can:
    - Write results for other agents to read
    - Read context from previous tasks
    - Subscribe to specific keys
    """

    def __init__(self):
        self._store: Dict[str, MemoryEntry] = {}
        self._subscribers: Dict[str, List[str]] = {}
        self._session_data: Dict[str, Dict] = {}

    def write(self, key: str, value: Any, agent: str, ttl: Optional[int] = None, metadata: Dict = None) -> None:
        """Write a value to shared memory."""
        entry = MemoryEntry(
            key=key,
            value=value,
            agent=agent,
            ttl=ttl,
            metadata=metadata or {},
        )
        self._store[key] = entry

        # Notify subscribers
        if key in self._subscribers:
            for subscriber in self._subscribers[key]:
                self._notify(subscriber, key, value)

    def read(self, key: str, default: Any = None) -> Any:
        """Read a value from shared memory."""
        entry = self._store.get(key)

        if entry is None:
            return default

        if entry.is_expired():
            del self._store[key]
            return default

        return entry.value

    def read_with_metadata(self, key: str) -> Optional[MemoryEntry]:
        """Read entry with metadata."""
        entry = self._store.get(key)

        if entry and entry.is_expired():
            del self._store[key]
            return None

        return entry

    def delete(self, key: str) -> bool:
        """Delete a key from shared memory."""
        if key in self._store:
            del self._store[key]
            return True
        return False

    def subscribe(self, agent: str, key: str) -> None:
        """Subscribe an agent to a key."""
        if key not in self._subscribers:
            self._subscribers[key] = []
        if agent not in self._subscribers[key]:
            self._subscribers[key].append(agent)

    def unsubscribe(self, agent: str, key: str) -> None:
        """Unsubscribe an agent from a key."""
        if key in self._subscribers and agent in self._subscribers[key]:
            self._subscribers[key].remove(agent)

    def _notify(self, agent: str, key: str, value: Any) -> None:
        """Notify an agent of a key update."""
        # This could trigger a callback or add to agent's queue
        pass

    def get_all_keys(self) -> List[str]:
        """Get all keys in shared memory."""
        # Clean expired entries
        expired = [k for k, v in self._store.items() if v.is_expired()]
        for k in expired:
            del self._store[k]

        return list(self._store.keys())

    def get_by_agent(self, agent: str) -> List[MemoryEntry]:
        """Get all entries written by a specific agent."""
        return [e for e in self._store.values() if e.agent == agent and not e.is_expired()]

    def get_by_prefix(self, prefix: str) -> Dict[str, Any]:
        """Get all entries with a key prefix."""
        return {
            k: v.value for k, v in self._store.items()
            if k.startswith(prefix) and not v.is_expired()
        }

    def clear(self) -> None:
        """Clear all shared memory."""
        self._store.clear()

    def clear_expired(self) -> int:
        """Clear expired entries."""
        expired = [k for k, v in self._store.items() if v.is_expired()]
        for k in expired:
            del self._store[k]
        return len(expired)

    def set_session_data(self, session_id: str, key: str, value: Any) -> None:
        """Store session-specific data."""
        if session_id not in self._session_data:
            self._session_data[session_id] = {}
        self._session_data[session_id][key] = value

    def get_session_data(self, session_id: str, key: str, default: Any = None) -> Any:
        """Get session-specific data."""
        return self._session_data.get(session_id, {}).get(key, default)

    def clear_session(self, session_id: str) -> None:
        """Clear session data."""
        if session_id in self._session_data:
            del self._session_data[session_id]

    def export_state(self) -> str:
        """Export shared memory state as JSON."""
        state = {
            "store": {
                k: {
                    "value": v.value if isinstance(v.value, (str, int, float, bool, list, dict)) else str(v.value),
                    "agent": v.agent,
                    "timestamp": v.timestamp.isoformat(),
                    "ttl": v.ttl,
                    "metadata": v.metadata,
                }
                for k, v in self._store.items() if not v.is_expired()
            },
            "sessions": self._session_data,
        }
        return json.dumps(state, default=str)

    def import_state(self, state_json: str) -> None:
        """Import shared memory state from JSON."""
        try:
            state = json.loads(state_json)

            for k, v in state.get("store", {}).items():
                entry = MemoryEntry(
                    key=k,
                    value=v["value"],
                    agent=v["agent"],
                    timestamp=datetime.fromisoformat(v["timestamp"]),
                    ttl=v.get("ttl"),
                    metadata=v.get("metadata", {}),
                )
                self._store[k] = entry

            self._session_data = state.get("sessions", {})
        except Exception as e:
            raise ValueError(f"Failed to import state: {e}")


# Global shared memory instance
_shared_memory: Optional[SharedMemory] = None


def get_shared_memory() -> SharedMemory:
    """Get or create shared memory instance."""
    global _shared_memory
    if _shared_memory is None:
        _shared_memory = SharedMemory()
    return _shared_memory