"""
agents/memory/message_bus.py - Inter-agent messaging system.
"""

from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import uuid
import queue
import threading


class MessageType(Enum):
    """Types of messages between agents."""
    TASK_REQUEST = "task_request"
    TASK_RESPONSE = "task_response"
    QUERY = "query"
    RESPONSE = "response"
    BROADCAST = "broadcast"
    ERROR = "error"
    STATUS = "status"
    DELEGATION = "delegation"


class MessagePriority(Enum):
    """Message priority levels."""
    LOW = 0
    NORMAL = 1
    HIGH = 2
    CRITICAL = 3


@dataclass
class Message:
    """Message between agents."""
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    type: MessageType = MessageType.QUERY
    sender: str = "unknown"
    recipient: Optional[str] = None  # None = broadcast
    content: Any = None
    priority: MessagePriority = MessagePriority.NORMAL
    timestamp: datetime = field(default_factory=datetime.now)
    reply_to: Optional[str] = None
    correlation_id: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "type": self.type.value,
            "sender": self.sender,
            "recipient": self.recipient,
            "content": self.content,
            "priority": self.priority.value,
            "timestamp": self.timestamp.isoformat(),
            "reply_to": self.reply_to,
            "correlation_id": self.correlation_id,
            "metadata": self.metadata,
        }

    def create_reply(self, content: Any, sender: str) -> 'Message':
        """Create a reply message."""
        return Message(
            type=MessageType.RESPONSE,
            sender=sender,
            recipient=self.sender,
            content=content,
            priority=self.priority,
            reply_to=self.id,
            correlation_id=self.correlation_id or self.id,
        )


class MessageBus:
    """
    Asynchronous message bus for inter-agent communication.

    Features:
    - Point-to-point messaging
    - Broadcast to all agents
    - Priority queues
    - Request-response pattern
    - Correlation IDs for tracking
    """

    def __init__(self):
        # Queues for each agent
        self._queues: Dict[str, queue.PriorityQueue] = {}

        # Broadcast listeners
        self._broadcast_listeners: List[str] = []

        # Handlers for message types
        self._handlers: Dict[str, Dict[MessageType, Callable]] = {}

        # Message history for debugging
        self._history: List[Message] = []
        self._max_history = 1000

        # Lock for thread safety
        self._lock = threading.Lock()

        # Correlation tracking
        self._pending_requests: Dict[str, queue.Queue] = {}

    def register_agent(self, agent_name: str) -> None:
        """Register an agent with the message bus."""
        with self._lock:
            if agent_name not in self._queues:
                self._queues[agent_name] = queue.PriorityQueue()
                self._broadcast_listeners.append(agent_name)

    def unregister_agent(self, agent_name: str) -> None:
        """Unregister an agent."""
        with self._lock:
            if agent_name in self._queues:
                del self._queues[agent_name]
            if agent_name in self._broadcast_listeners:
                self._broadcast_listeners.remove(agent_name)

    def register_handler(self, agent_name: str, message_type: MessageType, handler: Callable) -> None:
        """Register a handler for a message type."""
        if agent_name not in self._handlers:
            self._handlers[agent_name] = {}
        self._handlers[agent_name][message_type] = handler

    def send(self, message: Message) -> None:
        """Send a message."""
        with self._lock:
            # Add to history
            self._history.append(message)
            if len(self._history) > self._max_history:
                self._history = self._history[-self._max_history:]

        if message.recipient:
            # Point-to-point
            if message.recipient in self._queues:
                # Priority: higher value = higher priority (negate for queue)
                priority = -message.priority.value
                self._queues[message.recipient].put((priority, message))
        else:
            # Broadcast
            for agent in self._broadcast_listeners:
                if agent != message.sender and agent in self._queues:
                    priority = -message.priority.value
                    self._queues[agent].put((priority, message))

    def receive(self, agent_name: str, timeout: Optional[float] = None) -> Optional[Message]:
        """Receive a message for an agent."""
        if agent_name not in self._queues:
            self.register_agent(agent_name)

        try:
            priority, message = self._queues[agent_name].get(timeout=timeout)

            # Check for registered handler
            if agent_name in self._handlers:
                handler = self._handlers[agent_name].get(message.type)
                if handler:
                    handler(message)

            return message
        except queue.Empty:
            return None

    def request(self, message: Message, timeout: Optional[float] = 10.0) -> Optional[Message]:
        """
        Send a request and wait for response.

        Args:
            message: Request message
            timeout: Timeout in seconds

        Returns:
            Response message or None if timeout
        """
        # Create response queue
        response_queue = queue.Queue()
        self._pending_requests[message.id] = response_queue

        try:
            # Send request
            self.send(message)

            # Wait for response
            response = response_queue.get(timeout=timeout)
            return response
        except queue.Empty:
            return None
        finally:
            del self._pending_requests[message.id]

    def respond(self, request_message: Message, content: Any, sender: str) -> None:
        """Send a response to a request."""
        response = request_message.create_reply(content, sender)

        # Check if there's a pending request waiting
        if request_message.id in self._pending_requests:
            self._pending_requests[request_message.id].put(response)
        else:
            # Send normally
            self.send(response)

    def broadcast(self, sender: str, content: Any, priority: MessagePriority = MessagePriority.NORMAL) -> None:
        """Broadcast a message to all agents."""
        message = Message(
            type=MessageType.BROADCAST,
            sender=sender,
            content=content,
            priority=priority,
        )
        self.send(message)

    def get_pending_count(self, agent_name: str) -> int:
        """Get number of pending messages for an agent."""
        if agent_name in self._queues:
            return self._queues[agent_name].qsize()
        return 0

    def clear_agent_queue(self, agent_name: str) -> None:
        """Clear all messages for an agent."""
        if agent_name in self._queues:
            while not self._queues[agent_name].empty():
                try:
                    self._queues[agent_name].get_nowait()
                except queue.Empty:
                    break

    def get_history(self, limit: int = 50) -> List[Dict]:
        """Get recent message history."""
        return [m.to_dict() for m in self._history[-limit:]]

    def get_stats(self) -> Dict[str, Any]:
        """Get message bus statistics."""
        return {
            "agents": list(self._queues.keys()),
            "pending_messages": {name: q.qsize() for name, q in self._queues.items()},
            "broadcast_listeners": len(self._broadcast_listeners),
            "history_size": len(self._history),
            "pending_requests": len(self._pending_requests),
        }


# Global message bus instance
_message_bus: Optional[MessageBus] = None


def get_message_bus() -> MessageBus:
    """Get or create message bus instance."""
    global _message_bus
    if _message_bus is None:
        _message_bus = MessageBus()
    return _message_bus