"""
agents/__init__.py - Multi-agent system exports.
"""

from agents.base import BaseAgent, Task, AgentContext, AgentRole, TaskStatus
from agents.orchestrator import OrchestratorAgent, get_orchestrator
from agents.specialists.code_agent import CodeAgent
from agents.specialists.search_agent import SearchAgent
from agents.specialists.data_agent import DataAgent
from agents.specialists.github_agent import GitHubAgent
from agents.specialists.utility_agent import UtilityAgent
from agents.specialists.review_agent import ReviewAgent

__all__ = [
    # Base
    "BaseAgent",
    "Task",
    "AgentContext",
    "AgentRole",
    "TaskStatus",
    # Orchestrator
    "OrchestratorAgent",
    "get_orchestrator",
    # Specialists
    "CodeAgent",
    "SearchAgent",
    "DataAgent",
    "GitHubAgent",
    "UtilityAgent",
    "ReviewAgent",
]