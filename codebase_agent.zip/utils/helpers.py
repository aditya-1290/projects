"""
utils/helpers.py - Helper utility functions.
"""

import re
import json
import hashlib
import time
from pathlib import Path
from typing import Optional, Dict, Any, List
from datetime import datetime, timedelta


def extract_json(text: str) -> Optional[Dict[str, Any]]:
    """
    Extract JSON from text that may contain markdown or extra content.

    Args:
        text: Text that contains JSON

    Returns:
        Parsed JSON dict or None if extraction fails
    """
    if not text:
        return None

    # Try direct parse
    try:
        return json.loads(text.strip())
    except json.JSONDecodeError:
        pass

    # Try extracting from ```json blocks
    match = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.DOTALL)
    if match:
        try:
            return json.loads(match.group(1))
        except json.JSONDecodeError:
            pass

    # Try finding first { ... } block
    match = re.search(r"(\{.*\})", text, re.DOTALL)
    if match:
        try:
            return json.loads(match.group(1))
        except json.JSONDecodeError:
            pass

    return None


def truncate_string(text: str, max_length: int = 500, suffix: str = "...") -> str:
    """Truncate a string to max_length."""
    if len(text) <= max_length:
        return text
    return text[:max_length - len(suffix)] + suffix


def generate_cache_key(*args, **kwargs) -> str:
    """Generate a consistent cache key from arguments."""
    data = {"args": args, "kwargs": kwargs}
    normalized = json.dumps(data, sort_keys=True, ensure_ascii=False)
    return hashlib.md5(normalized.encode()).hexdigest()


def parse_time_expression(text: str) -> Optional[timedelta]:
    """
    Parse time expressions like '2 hours', '3 days', '1 week'.

    Args:
        text: Time expression string

    Returns:
        timedelta object or None
    """
    patterns = [
        (r"(\d+)\s*seconds?", "seconds"),
        (r"(\d+)\s*minutes?", "minutes"),
        (r"(\d+)\s*hours?", "hours"),
        (r"(\d+)\s*days?", "days"),
        (r"(\d+)\s*weeks?", "weeks"),
        (r"(\d+)\s*months?", "months"),
        (r"(\d+)\s*years?", "years"),
    ]

    text_lower = text.lower()

    for pattern, unit in patterns:
        match = re.search(pattern, text_lower)
        if match:
            value = int(match.group(1))
            if unit == "months":
                return timedelta(days=value * 30)
            elif unit == "years":
                return timedelta(days=value * 365)
            else:
                return timedelta(**{unit: value})

    return None


def safe_filename(filename: str) -> str:
    """Convert string to safe filename."""
    # Remove invalid characters
    safe = re.sub(r'[<>:"/\\|?*]', '_', filename)
    # Limit length
    if len(safe) > 200:
        name, ext = Path(safe).stem, Path(safe).suffix
        safe = name[:200 - len(ext)] + ext
    return safe


def format_timestamp(timestamp: Optional[datetime] = None) -> str:
    """Format timestamp for display."""
    if timestamp is None:
        timestamp = datetime.now()
    return timestamp.strftime("%Y-%m-%d %H:%M:%S")


def parse_date_string(date_str: str) -> Optional[datetime]:
    """Parse various date string formats."""
    formats = [
        "%Y-%m-%d",
        "%Y/%m/%d",
        "%d-%m-%Y",
        "%d/%m/%Y",
        "%b %d, %Y",
        "%B %d, %Y",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%d %H:%M:%S",
    ]

    for fmt in formats:
        try:
            return datetime.strptime(date_str.strip(), fmt)
        except ValueError:
            continue

    return None


def chunk_text(text: str, chunk_size: int = 2000, overlap: int = 200) -> List[str]:
    """
    Split text into overlapping chunks.

    Args:
        text: Text to chunk
        chunk_size: Maximum chunk size
        overlap: Overlap between chunks

    Returns:
        List of text chunks
    """
    if len(text) <= chunk_size:
        return [text]

    chunks = []
    start = 0

    while start < len(text):
        end = start + chunk_size

        if end >= len(text):
            chunks.append(text[start:])
            break

        # Try to break at newline
        chunk = text[start:end]
        last_newline = chunk.rfind('\n')

        if last_newline > chunk_size // 2:
            end = start + last_newline + 1

        chunks.append(text[start:end])
        start = end - overlap

    return chunks


def extract_urls(text: str) -> List[str]:
    """Extract URLs from text."""
    url_pattern = r'https?://[^\s<>"\')\]]+'
    return re.findall(url_pattern, text)


def is_github_url(url: str) -> bool:
    """Check if URL is a GitHub URL."""
    patterns = [
        r'github_tools\.com/[^/]+/[^/\s]+',
        r'github_tools\.com/[^/]+',
    ]
    return any(re.search(p, url, re.IGNORECASE) for p in patterns)


def parse_github_url(url: str) -> Optional[tuple]:
    """
    Parse GitHub URL to extract owner and repo.

    Returns:
        (owner, repo) tuple or None
    """
    patterns = [
        r'github_tools\.com/([^/]+)/([^/\s]+?)(?:\.git)?(?:/.*)?$',
        r'github_tools\.com/([^/]+)/?$',
    ]

    for pattern in patterns:
        match = re.search(pattern, url, re.IGNORECASE)
        if match:
            groups = match.groups()
            if len(groups) == 2:
                return groups[0], groups[1].rstrip('/')
            elif len(groups) == 1:
                return groups[0], None

    return None


def retry_with_backoff(
        func,
        max_retries: int = 3,
        base_delay: float = 1.0,
        max_delay: float = 10.0,
        exponential: bool = True,
):
    """
    Retry a function with exponential backoff.

    Args:
        func: Function to retry
        max_retries: Maximum number of retries
        base_delay: Initial delay in seconds
        max_delay: Maximum delay in seconds
        exponential: Whether to use exponential backoff

    Returns:
        Function result

    Raises:
        Last exception if all retries fail
    """
    last_exception = None

    for attempt in range(max_retries):
        try:
            return func()
        except Exception as e:
            last_exception = e

            if attempt < max_retries - 1:
                if exponential:
                    delay = min(base_delay * (2 ** attempt), max_delay)
                else:
                    delay = min(base_delay, max_delay)

                time.sleep(delay)

    raise last_exception