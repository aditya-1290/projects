"""
utils/constants.py - Application-wide constants.
"""

from enum import Enum


# =============================================================================
# Query Types
# =============================================================================
class QueryType(str, Enum):
    """Query classification types."""
    CONVERSATIONAL = "conversational"
    SIMPLE_TOOL = "simple_tool"
    COMPLEX = "complex"


# =============================================================================
# Tool Categories
# =============================================================================
class ToolCategory(str, Enum):
    """Tool categories for organization."""
    WEATHER_TIME = "weather_time"
    FINANCE = "finance"
    SEARCH_NEWS = "search_news"
    CODEBASE = "codebase"
    GITHUB = "github_tools"
    UTILITY = "utility"


# =============================================================================
# Response Status
# =============================================================================
class ResponseStatus(str, Enum):
    """Response status types."""
    SUCCESS = "success"
    ERROR = "error"
    PENDING = "pending"
    COMPLETE = "COMPLETE"
    INCOMPLETE = "INCOMPLETE"


# =============================================================================
# Progress Event Types
# =============================================================================
class ProgressEvent(str, Enum):
    """Progress event types for streaming."""
    THINKING = "thinking"
    SEARCHING = "searching"
    TOOL_START = "tool_start"
    TOOL_COMPLETE = "tool_complete"
    GENERATING = "generating"
    REFINING = "refining"
    ERROR = "error"


# =============================================================================
# Currency Codes
# =============================================================================
CURRENCY_CODES = {
    "USD", "EUR", "GBP", "JPY", "INR", "AUD", "CAD", "CHF", "CNY",
    "HKD", "NZD", "SEK", "KRW", "SGD", "NOK", "MXN", "BRL", "ZAR",
}

# Currency name to code mapping
CURRENCY_NAMES = {
    "dollar": "USD", "dollars": "USD",
    "euro": "EUR", "euros": "EUR",
    "pound": "GBP", "pounds": "GBP",
    "yen": "JPY",
    "rupee": "INR", "rupees": "INR",
    "yuan": "CNY", "renminbi": "CNY",
}

# =============================================================================
# Stock Tickers
# =============================================================================
COMMON_TICKERS = {
    # US Stocks
    "apple": "AAPL",
    "microsoft": "MSFT",
    "google": "GOOGL",
    "alphabet": "GOOGL",
    "amazon": "AMZN",
    "meta": "META",
    "facebook": "META",
    "tesla": "TSLA",
    "nvidia": "NVDA",
    "netflix": "NFLX",
    "amd": "AMD",
    "intel": "INTC",

    # Indices
    "dow jones": "^DJI",
    "dow": "^DJI",
    "s&p 500": "^GSPC",
    "s&p": "^GSPC",
    "nasdaq": "^IXIC",

    # Indian Stocks
    "tcs": "TCS.NS",
    "infosys": "INFY.NS",
    "wipro": "WIPRO.NS",
    "reliance": "RELIANCE.NS",
    "hdfc": "HDFCBANK.NS",
    "icici": "ICICIBANK.NS",
    "nifty": "^NSEI",
    "sensex": "^BSESN",
}

# =============================================================================
# News Topics
# =============================================================================
NEWS_TOPICS = {
    "technology", "business", "sports", "politics", "science",
    "health", "entertainment", "world", "environment", "food",
    "tourism", "top", "education", "finance",
}

NEWS_TOPIC_ALIASES = {
    "tech": "technology",
    "finance": "business",
    "financial": "business",
    "economy": "business",
    "sport": "sports",
    "general": "top",
    "latest": "top",
    "breaking": "top",
}

# =============================================================================
# Unit Conversions
# =============================================================================
LENGTH_UNITS = {
    "mm": 0.001, "cm": 0.01, "m": 1.0, "km": 1000.0,
    "in": 0.0254, "inch": 0.0254, "inches": 0.0254,
    "ft": 0.3048, "foot": 0.3048, "feet": 0.3048,
    "yd": 0.9144, "yard": 0.9144, "yards": 0.9144,
    "mi": 1609.344, "mile": 1609.344, "miles": 1609.344,
}

WEIGHT_UNITS = {
    "mg": 0.000001, "g": 0.001, "kg": 1.0, "t": 1000.0,
    "oz": 0.0283495, "ounce": 0.0283495, "ounces": 0.0283495,
    "lb": 0.453592, "pound": 0.453592, "pounds": 0.453592, "lbs": 0.453592,
    "st": 6.35029, "stone": 6.35029,
}

VOLUME_UNITS = {
    "ml": 0.001, "l": 1.0, "liter": 1.0, "litre": 1.0, "liters": 1.0,
    "tsp": 0.00492892, "teaspoon": 0.00492892,
    "tbsp": 0.0147868, "tablespoon": 0.0147868,
    "fl_oz": 0.0295735, "cup": 0.236588,
    "pt": 0.473176, "pint": 0.473176,
    "qt": 0.946353, "quart": 0.946353,
    "gal": 3.78541, "gallon": 3.78541,
}

# =============================================================================
# Allowed Shell Commands
# =============================================================================
ALLOWED_COMMANDS = {
    "ls", "pwd", "echo", "cat", "head", "tail", "grep", "find", "wc",
    "date", "which", "python", "python3", "pip", "git", "node", "npm",
    "cargo", "go", "rustc", "javac", "java",
}

DANGEROUS_PATTERNS = [
    "rm -rf", "sudo", "su", "chmod", "chown", "mkfs", "dd", "format",
    ":(){", "wget", "curl", "> /dev", "/etc/passwd", "/etc/shadow",
    "del /f", "format c:", "shutdown", "reboot",
]