"""
utils/logger.py - Logging setup for the entire application.
"""

import logging
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional

from config.settings import settings


class ColoredFormatter(logging.Formatter):
    """Formatter with colored output for terminal."""

    COLORS = {
        logging.DEBUG: "\033[36m",  # Cyan
        logging.INFO: "\033[32m",  # Green
        logging.WARNING: "\033[33m",  # Yellow
        logging.ERROR: "\033[31m",  # Red
        logging.CRITICAL: "\033[35m",  # Magenta
    }
    RESET = "\033[0m"

    def format(self, record):
        color = self.COLORS.get(record.levelno, self.RESET)
        time_str = datetime.now().strftime("%H:%M:%S")
        level = record.levelname.ljust(8)
        message = super().format(record)
        return f"{color}[{time_str}] [{level}] {message}{self.RESET}"


class PlainFormatter(logging.Formatter):
    """Plain formatter for log files."""

    def format(self, record):
        time_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        level = record.levelname.ljust(8)
        return f"[{time_str}] [{level}] {record.getMessage()}"


_logger: Optional[logging.Logger] = None


def setup_logging(
        name: str = "agent",
        level: str = None,
        log_file: str = None,
) -> logging.Logger:
    """
    Setup and configure logging.

    Args:
        name: Logger name
        level: Log level (uses settings.LOG_LEVEL if None)
        log_file: Log file path (uses settings.LOG_FILE if None)

    Returns:
        Configured logger instance
    """
    global _logger

    if _logger is not None:
        return _logger

    log_level = level or settings.LOG_LEVEL
    log_path = log_file or settings.LOG_FILE

    logger = logging.getLogger(name)
    logger.setLevel(getattr(logging, log_level.upper(), logging.INFO))
    logger.propagate = False

    # Clear existing handlers
    logger.handlers.clear()

    # Console handler with colors
    console = logging.StreamHandler(sys.stdout)
    console.setLevel(logging.DEBUG)
    console.setFormatter(ColoredFormatter())
    logger.addHandler(console)

    # File handler
    try:
        Path(log_path).parent.mkdir(parents=True, exist_ok=True)
        file_handler = logging.FileHandler(log_path, encoding="utf-8")
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(PlainFormatter())
        logger.addHandler(file_handler)
    except Exception as e:
        print(f"Warning: Could not create log file: {e}")

    _logger = logger
    return logger


def get_logger(name: str = "agent") -> logging.Logger:
    """Get or create a logger instance."""
    global _logger
    if _logger is None:
        _logger = setup_logging()
    return _logger


# Default logger instance
log = get_logger()