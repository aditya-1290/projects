"""
memory/vector_store.py - ChromaDB vector memory for the agent.
"""

import json
import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional

import chromadb
from chromadb.utils import embedding_functions

from config.settings import settings
from utils.logger import log


class VectorStore:
    """
    ChromaDB-based vector memory for the agent.

    Stores:
    - Successful interactions (main collection)
    - Failed tool calls (failure collection)
    """

    def __init__(self, persist_path: Optional[str] = None):
        """
        Initialize vector store.

        Args:
            persist_path: Path to persist ChromaDB (uses settings if None)
        """
        self.persist_path = persist_path or settings.CHROMA_DB_PATH

        # Initialize ChromaDB client
        self.client = chromadb.PersistentClient(path=self.persist_path)

        # Embedding function
        self.embedding_fn = embedding_functions.DefaultEmbeddingFunction()

        # Main memory collection
        self.collection = self.client.get_or_create_collection(
            name="agent_memory",
            embedding_function=self.embedding_fn,
            metadata={"description": "Successful interactions and tool calls"}
        )

        # Failure memory collection
        self.failure_collection = self.client.get_or_create_collection(
            name="failure_memory",
            embedding_function=self.embedding_fn,
            metadata={"description": "Failed tool calls to avoid repeating"}
        )

        log.info(f"[VectorStore] Initialized at {self.persist_path}")

    def store(
            self,
            text: str,
            metadata: Optional[Dict[str, Any]] = None,
            collection: str = "main",
    ) -> bool:
        """
        Store a memory in the vector store.

        Args:
            text: Text content to store
            metadata: Additional metadata
            collection: 'main' or 'failure'

        Returns:
            True if stored successfully
        """
        if not text or not text.strip():
            return False

        coll = self.collection if collection == "main" else self.failure_collection

        # Sanitize metadata - ChromaDB only accepts str, int, float, bool
        sanitized = {}
        if metadata:
            for k, v in metadata.items():
                if isinstance(v, (str, int, float, bool)):
                    sanitized[k] = v
                elif v is None:
                    sanitized[k] = ""
                else:
                    sanitized[k] = json.dumps(v)[:500]

        sanitized["timestamp"] = datetime.now().isoformat()
        sanitized["collection"] = collection

        try:
            coll.add(
                documents=[text[:5000]],  # Limit text length
                metadatas=[sanitized],
                ids=[str(uuid.uuid4())]
            )
            log.debug(f"[VectorStore] Stored in {collection}: {text[:50]}...")

            # Trim if needed
            self._trim_collection(coll)

            return True
        except Exception as e:
            log.error(f"[VectorStore] Store error: {e}")
            return False

    def store_success(self, text: str, metadata: Optional[Dict] = None) -> bool:
        """Store a successful interaction."""
        return self.store(text, metadata, "main")

    def store_failure(
            self,
            query: str,
            tool_name: str,
            error: str,
            metadata: Optional[Dict] = None,
    ) -> bool:
        """Store a failed tool call."""
        meta = metadata or {}
        meta.update({
            "type": "failure",
            "tool": tool_name,
            "query": query[:200],
            "error": error[:200],
        })
        text = f"FAILED: {tool_name} | Query: {query} | Error: {error}"
        return self.store(text, meta, "failure")

    def query(
            self,
            query_text: str,
            n_results: int = 5,
            collection: str = "main",
            where: Optional[Dict] = None,
    ) -> List[Dict[str, Any]]:
        """
        Query the vector store.

        Args:
            query_text: Search query
            n_results: Number of results
            collection: 'main' or 'failure'
            where: Filter conditions

        Returns:
            List of matching memories
        """
        if not query_text:
            return []

        coll = self.collection if collection == "main" else self.failure_collection

        try:
            results = coll.query(
                query_texts=[query_text],
                n_results=n_results,
                where=where,
            )

            if not results.get("documents") or not results["documents"][0]:
                return []

            memories = []
            for doc, meta, dist in zip(
                    results["documents"][0],
                    results["metadatas"][0],
                    results["distances"][0]
            ):
                memories.append({
                    "text": doc,
                    "metadata": meta,
                    "relevance": 1 - dist,  # Convert distance to similarity
                })

            return memories

        except Exception as e:
            log.error(f"[VectorStore] Query error: {e}")
            return []

    def get_recent_failures(self, tool_name: Optional[str] = None, limit: int = 10) -> List[Dict]:
        """Get recent failure records."""
        where = {"tool": tool_name} if tool_name else None
        return self.query("failure", n_results=limit, collection="failure", where=where)

    def should_avoid_tool(self, tool_name: str, query: str) -> tuple:
        """
        Check if a tool should be avoided based on past failures.

        Returns:
            (should_avoid, reason) tuple
        """
        failures = self.query(query, n_results=3, collection="failure")

        for failure in failures:
            if failure.get("metadata", {}).get("tool") == tool_name:
                timestamp = failure.get("metadata", {}).get("timestamp")
                if timestamp:
                    try:
                        failure_time = datetime.fromisoformat(timestamp)
                        age = (datetime.now() - failure_time).total_seconds()
                        if age < 3600:  # Within last hour
                            return True, f"Tool '{tool_name}' failed recently"
                    except (ValueError, TypeError):
                        pass

                error = failure.get("metadata", {}).get("error", "Unknown error")
                return True, f"Tool '{tool_name}' previously failed: {error}"

        return False, None

    def _trim_collection(self, collection, max_items: int = None):
        """Trim collection to prevent unbounded growth."""
        max_items = max_items or settings.MAX_MEMORY_ITEMS

        try:
            results = collection.get()

            if not results or len(results.get("ids", [])) <= max_items:
                return

            excess = len(results["ids"]) - max_items
            ids_to_delete = results["ids"][:excess]

            if ids_to_delete:
                collection.delete(ids=ids_to_delete)
                log.debug(f"[VectorStore] Trimmed {len(ids_to_delete)} items")

        except Exception as e:
            log.error(f"[VectorStore] Trim error: {e}")

    def clear(self, collection: str = "all") -> Dict[str, int]:
        """Clear collections."""
        counts = {}

        if collection in ("all", "main"):
            try:
                results = self.collection.get()
                ids = results.get("ids", [])
                if ids:
                    self.collection.delete(ids=ids)
                counts["main"] = len(ids)
            except Exception as e:
                log.error(f"[VectorStore] Clear main error: {e}")
                counts["main"] = -1

        if collection in ("all", "failure"):
            try:
                results = self.failure_collection.get()
                ids = results.get("ids", [])
                if ids:
                    self.failure_collection.delete(ids=ids)
                counts["failure"] = len(ids)
            except Exception as e:
                log.error(f"[VectorStore] Clear failure error: {e}")
                counts["failure"] = -1

        log.info(f"[VectorStore] Cleared: {counts}")
        return counts

    def stats(self) -> Dict[str, Any]:
        """Get collection statistics."""
        stats = {}

        for name, coll in [("main", self.collection), ("failure", self.failure_collection)]:
            try:
                results = coll.get()
                stats[name] = {
                    "count": len(results.get("ids", [])),
                    "has_data": bool(results.get("ids")),
                }
            except Exception as e:
                stats[name] = {"count": -1, "error": str(e)}

        return stats


# Global singleton
_vector_store: Optional[VectorStore] = None


def get_vector_store() -> VectorStore:
    """Get or create the vector store singleton."""
    global _vector_store
    if _vector_store is None:
        _vector_store = VectorStore()
    return _vector_store