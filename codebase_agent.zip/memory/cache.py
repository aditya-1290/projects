"""
memory/cache.py - TTL-based cache for tool results.
"""

import hashlib
import json
import time
from typing import Optional, Dict, Any, List

from config.settings import settings
from utils.logger import log


class ToolCache:
    """
    In-memory TTL cache for tool results.

    Each tool has configurable TTL based on data freshness requirements.
    """

    def __init__(self):
        self._store: Dict[str, Dict[str, Any]] = {}
        self._hits = 0
        self._misses = 0

    def _make_key(self, tool_name: str, args: Dict) -> str:
        """Create a stable cache key."""
        normalized = json.dumps(args, sort_keys=True, ensure_ascii=False)
        raw = f"{tool_name}:{normalized}"
        return hashlib.md5(raw.encode()).hexdigest()

    def get(self, tool_name: str, args: Dict) -> Optional[Dict]:
        """
        Get cached result if not expired.

        Returns:
            Cached result dict or None
        """
        key = self._make_key(tool_name, args)
        entry = self._store.get(key)

        if entry is None:
            self._misses += 1
            return None

        ttl = settings.TOOL_CACHE_TTL.get(tool_name, settings.DEFAULT_TOOL_TTL)
        age = time.time() - entry["stored_at"]

        if age > ttl:
            del self._store[key]
            self._misses += 1
            log.debug(f"[Cache] EXPIRED: {tool_name} (age: {age:.0f}s > {ttl}s)")
            return None

        self._hits += 1
        log.info(f"[Cache] ✅ HIT: {tool_name} (age: {age:.0f}s, remaining: {ttl - age:.0f}s)")
        return entry["result"]

    def set(self, tool_name: str, args: Dict, result: Dict) -> None:
        """
        Store tool result in cache.

        Only caches successful results.
        """
        if result.get("status") != "success":
            log.debug(f"[Cache] Skipping failed result: {tool_name}")
            return

        key = self._make_key(tool_name, args)
        ttl = settings.TOOL_CACHE_TTL.get(tool_name, settings.DEFAULT_TOOL_TTL)

        self._store[key] = {
            "result": result,
            "stored_at": time.time(),
            "tool": tool_name,
            "args": args,
        }

        log.info(f"[Cache] 💾 STORED: {tool_name} (TTL: {ttl}s)")

    def invalidate(self, tool_name: Optional[str] = None) -> int:
        """
        Invalidate cache entries.

        Args:
            tool_name: Specific tool to invalidate (None for all)

        Returns:
            Number of entries removed
        """
        if tool_name is None:
            count = len(self._store)
            self._store.clear()
            log.info(f"[Cache] Cleared all {count} entries")
            return count

        keys = [k for k, v in self._store.items() if v.get("tool") == tool_name]
        for k in keys:
            del self._store[k]

        log.info(f"[Cache] Invalidated {len(keys)} entries for '{tool_name}'")
        return len(keys)

    def stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        total = self._hits + self._misses
        hit_rate = round(self._hits / total * 100, 1) if total > 0 else 0.0

        return {
            "entries": len(self._store),
            "hits": self._hits,
            "misses": self._misses,
            "hit_rate": f"{hit_rate}%",
            "tools_cached": list({v["tool"] for v in self._store.values()}),
        }

    def list_entries(self) -> List[Dict]:
        """List all cached entries with TTL info."""
        now = time.time()
        entries = []

        for entry in self._store.values():
            tool = entry["tool"]
            ttl = settings.TOOL_CACHE_TTL.get(tool, settings.DEFAULT_TOOL_TTL)
            age = now - entry["stored_at"]

            entries.append({
                "tool": tool,
                "args": entry["args"],
                "age_s": round(age, 0),
                "ttl_s": ttl,
                "remaining": max(0, round(ttl - age, 0)),
                "expired": age > ttl,
            })

        return sorted(entries, key=lambda x: x["tool"])

    def cleanup_expired(self) -> int:
        """Remove all expired entries."""
        now = time.time()
        expired_keys = []

        for key, entry in self._store.items():
            tool = entry["tool"]
            ttl = settings.TOOL_CACHE_TTL.get(tool, settings.DEFAULT_TOOL_TTL)
            age = now - entry["stored_at"]

            if age > ttl:
                expired_keys.append(key)

        for key in expired_keys:
            del self._store[key]

        if expired_keys:
            log.debug(f"[Cache] Cleaned up {len(expired_keys)} expired entries")

        return len(expired_keys)


class ResponseCache:
    """TTL cache for final agent responses."""

    def __init__(self):
        self._store: Dict[str, Dict[str, Any]] = {}
        self._hits = 0
        self._misses = 0

    def _make_key(self, query: str) -> str:
        """Create cache key from query."""
        return hashlib.md5(query.lower().strip().encode()).hexdigest()

    def get(self, query: str) -> Optional[str]:
        """Get cached response."""
        key = self._make_key(query)
        entry = self._store.get(key)

        if entry is None:
            self._misses += 1
            return None

        age = time.time() - entry["stored_at"]
        if age > settings.RESPONSE_CACHE_TTL:
            del self._store[key]
            self._misses += 1
            return None

        self._hits += 1
        log.info(f"[ResponseCache] ✅ HIT: {query[:50]}...")
        return entry["response"]

    def set(self, query: str, response: str, ttl: Optional[int] = None) -> None:
        """Store response in cache."""
        key = self._make_key(query)
        self._store[key] = {
            "query": query,
            "response": response,
            "stored_at": time.time(),
            "ttl": ttl or settings.RESPONSE_CACHE_TTL,
        }
        log.info(f"[ResponseCache] 💾 STORED: {query[:50]}...")

    def stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        total = self._hits + self._misses
        hit_rate = round(self._hits / total * 100, 1) if total > 0 else 0.0

        return {
            "entries": len(self._store),
            "hits": self._hits,
            "misses": self._misses,
            "hit_rate": f"{hit_rate}%",
        }

    def clear(self) -> int:
        """Clear all cached responses."""
        count = len(self._store)
        self._store.clear()
        return count


# Global singletons
tool_cache = ToolCache()
response_cache = ResponseCache()