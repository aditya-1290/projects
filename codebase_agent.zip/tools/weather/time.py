"""
tools/weather/time.py - Time and date tools.
"""

import pytz
from datetime import datetime
from typing import Dict, List

from tools.weather.geocoding import get_city_timezone
from utils.logger import log


def get_current_time(city: str) -> Dict:
    """
    Get current time for a city.

    Args:
        city: City name

    Returns:
        Time data dictionary
    """
    try:
        tz_name = get_city_timezone(city)
        if not tz_name:
            return {
                "status": "error",
                "message": f"Could not determine timezone for '{city}'. Use a city name, not a country."
            }

        timezone = pytz.timezone(tz_name)
        now = datetime.now(timezone)

        return {
            "status": "success",
            "city": city.title(),
            "datetime": now.strftime("%Y-%m-%d %H:%M:%S"),
            "time": now.strftime("%H:%M:%S"),
            "timezone": tz_name,
            "day_of_week": now.strftime("%A"),
            "hour": now.hour,
            "minute": now.minute,
            "utc_offset": now.strftime("%z"),
        }

    except Exception as e:
        log.error(f"[Time] Error for '{city}': {e}")
        return {"status": "error", "message": str(e)}


def get_date_info(city: str) -> Dict:
    """
    Get date information for a city.

    Args:
        city: City name

    Returns:
        Date data dictionary
    """
    try:
        tz_name = get_city_timezone(city)
        if not tz_name:
            return {
                "status": "error",
                "message": f"Could not determine timezone for '{city}'."
            }

        timezone = pytz.timezone(tz_name)
        now = datetime.now(timezone)

        return {
            "status": "success",
            "city": city.title(),
            "date": now.strftime("%Y-%m-%d"),
            "time": now.strftime("%H:%M:%S"),
            "day_of_week": now.strftime("%A"),
            "day_of_month": now.day,
            "month": now.strftime("%B"),
            "year": now.year,
            "timezone": tz_name,
            "utc_offset": now.strftime("%z"),
            "is_dst": bool(now.dst()),
        }

    except Exception as e:
        log.error(f"[DateInfo] Error for '{city}': {e}")
        return {"status": "error", "message": str(e)}


def get_world_clock(cities: List[str]) -> Dict:
    """
    Get current time for multiple cities.

    Args:
        cities: List of city names

    Returns:
        World clock data dictionary
    """
    results = []
    errors = []

    for city in cities:
        result = get_current_time(city)
        if result["status"] == "success":
            results.append(result)
        else:
            errors.append({"city": city, "error": result.get("message", "Unknown error")})

    return {
        "status": "success",
        "clock_count": len(results),
        "world_clock": results,
        "errors": errors if errors else None,
    }