"""
tools/weather/geocoding.py - Geocoding utilities for weather/time tools.
"""

from typing import Optional, Tuple, Dict
import requests

from config.settings import settings
from utils.logger import log

# Geocoding cache
_geocode_cache: Dict[str, Tuple[float, float]] = {}

# City to timezone overrides for accuracy
CITY_TZ_OVERRIDES = {
    "mumbai": ("Asia/Kolkata", 19.0760, 72.8777),
    "delhi": ("Asia/Kolkata", 28.6139, 77.2090),
    "bangalore": ("Asia/Kolkata", 12.9716, 77.5946),
    "chennai": ("Asia/Kolkata", 13.0827, 80.2707),
    "kolkata": ("Asia/Kolkata", 22.5726, 88.3639),
    "hyderabad": ("Asia/Kolkata", 17.3850, 78.4867),
    "pune": ("Asia/Kolkata", 18.5204, 73.8567),
    "ahmedabad": ("Asia/Kolkata", 23.0225, 72.5714),
    "new york": ("America/New_York", 40.7128, -74.0060),
    "london": ("Europe/London", 51.5074, -0.1278),
    "tokyo": ("Asia/Tokyo", 35.6762, 139.6503),
    "paris": ("Europe/Paris", 48.8566, 2.3522),
    "sydney": ("Australia/Sydney", -33.8688, 151.2093),
    "dubai": ("Asia/Dubai", 25.2048, 55.2708),
    "singapore": ("Asia/Singapore", 1.3521, 103.8198),
}


def get_city_coords(city: str) -> Optional[Tuple[float, float]]:
    """
    Get latitude and longitude for a city.

    Args:
        city: City name

    Returns:
        (latitude, longitude) tuple or None
    """
    city_key = city.lower().strip()

    # Check cache
    if city_key in _geocode_cache:
        return _geocode_cache[city_key]

    # Check overrides
    if city_key in CITY_TZ_OVERRIDES:
        _, lat, lon = CITY_TZ_OVERRIDES[city_key]
        _geocode_cache[city_key] = (lat, lon)
        log.debug(f"[Geocoding] ✅ '{city}' → override: lat={lat}, lon={lon}")
        return (lat, lon)

    # Check API key
    if not settings.API_NINJAS_KEY:
        log.warning(f"[Geocoding] No API key for '{city}'")
        return None

    try:
        response = requests.get(
            "https://api.api-ninjas.com/v1/geocoding",
            headers={"X-Api-Key": settings.API_NINJAS_KEY},
            params={"city": city},
            timeout=10
        )
        response.raise_for_status()
        data = response.json()

        if not data:
            log.warning(f"[Geocoding] No results for '{city}'")
            return None

        # Prefer results from the correct country for known cities
        selected = data[0]
        city_lower = city.lower()

        if city_lower in ["mumbai", "delhi", "bangalore", "kolkata", "chennai"]:
            for loc in data:
                if loc.get("country") == "IN":
                    selected = loc
                    break

        lat = selected.get("latitude")
        lon = selected.get("longitude")

        if lat is None or lon is None:
            return None

        _geocode_cache[city_key] = (lat, lon)
        log.debug(f"[Geocoding] ✅ '{city}' → lat={lat}, lon={lon}")
        return (lat, lon)

    except Exception as e:
        log.error(f"[Geocoding] Failed for '{city}': {e}")
        return None


# Timezone cache
_timezone_cache: Dict[str, str] = {}


def get_city_timezone(city: str) -> Optional[str]:
    """
    Get timezone for a city.

    Args:
        city: City name

    Returns:
        Timezone string or None
    """
    city_key = city.lower().strip()

    # Check cache
    if city_key in _timezone_cache:
        return _timezone_cache[city_key]

    # Check overrides
    if city_key in CITY_TZ_OVERRIDES:
        tz, _, _ = CITY_TZ_OVERRIDES[city_key]
        _timezone_cache[city_key] = tz
        return tz

    # Use timezonefinder
    try:
        from timezonefinder import TimezoneFinder
        tf = TimezoneFinder()

        coords = get_city_coords(city)
        if not coords:
            return None

        lat, lon = coords
        tz = tf.timezone_at(lat=lat, lng=lon)

        if tz:
            _timezone_cache[city_key] = tz
            log.debug(f"[Timezone] ✅ '{city}' → {tz}")
            return tz

        log.warning(f"[Timezone] No timezone for '{city}'")
        return None

    except Exception as e:
        log.error(f"[Timezone] Failed for '{city}': {e}")
        return None


def clear_geocoding_cache() -> None:
    """Clear geocoding and timezone caches."""
    _geocode_cache.clear()
    _timezone_cache.clear()
    log.debug("[Geocoding] Caches cleared")