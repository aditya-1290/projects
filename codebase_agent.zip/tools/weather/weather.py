"""
tools/weather/weather.py - Weather tool.
"""

import requests
from typing import Dict

from config.settings import settings
from tools.weather.geocoding import get_city_coords
from utils.logger import log


def get_weather(city: str, unit: str = "celsius") -> Dict:
    """
    Get current weather for a city.

    Args:
        city: City name (e.g., 'Mumbai', 'London')
        unit: 'celsius' or 'fahrenheit'

    Returns:
        Weather data dictionary
    """
    if not settings.API_NINJAS_KEY:
        return {"status": "error", "message": "Weather API key not configured"}

    try:
        coords = get_city_coords(city)
        if not coords:
            return {
                "status": "error",
                "message": f"Could not find coordinates for '{city}'. Use a city name, not a country."
            }

        lat, lon = coords

        response = requests.get(
            "https://api.api-ninjas.com/v1/weather",
            headers={"X-Api-Key": settings.API_NINJAS_KEY},
            params={"lat": lat, "lon": lon},
            timeout=10
        )
        response.raise_for_status()
        data = response.json()

        temp = data.get("temp")
        feels_like = data.get("feels_like")

        if unit == "fahrenheit":
            temp = round((temp * 9 / 5) + 32, 1) if temp is not None else None
            feels_like = round((feels_like * 9 / 5) + 32, 1) if feels_like is not None else None
            unit_symbol = "°F"
        else:
            unit_symbol = "°C"

        return {
            "status": "success",
            "city": city.title(),
            "temperature": temp,
            "temperature_unit": unit_symbol,
            "feels_like": feels_like,
            "humidity": data.get("humidity"),
            "wind_speed": data.get("wind_speed"),
            "wind_direction": data.get("wind_degrees"),
            "cloud_pct": data.get("cloud_pct"),
            "min_temp": data.get("min_temp"),
            "max_temp": data.get("max_temp"),
        }

    except requests.exceptions.RequestException as e:
        log.error(f"[Weather] API error: {e}")
        return {"status": "error", "message": f"Weather service unavailable: {e}"}
    except Exception as e:
        log.error(f"[Weather] Unexpected error: {e}")
        return {"status": "error", "message": str(e)}