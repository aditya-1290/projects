"""
tools/search/news.py - News tools with time-based filtering.
"""

import requests
from datetime import datetime, timedelta
from typing import Dict, Optional

from config.settings import settings
from utils.constants import NEWS_TOPICS, NEWS_TOPIC_ALIASES
from utils.logger import log


def _normalize_topic(topic: str) -> str:
    """Normalize topic to valid news category."""
    topic_lower = topic.lower().strip()

    if topic_lower in NEWS_TOPIC_ALIASES:
        return NEWS_TOPIC_ALIASES[topic_lower]

    if topic_lower in NEWS_TOPICS:
        return topic_lower

    return "technology"


def get_news(topic: str = "technology", limit: int = 5) -> Dict:
    """
    Get latest news headlines for a topic.

    Args:
        topic: News category (technology, business, sports, etc.)
        limit: Number of articles (default 5, max 10)

    Returns:
        News articles dictionary
    """
    if not settings.NEWS_API_KEY:
        return {"status": "error", "message": "News API key not configured"}

    try:
        normalized_topic = _normalize_topic(topic)
        limit = min(limit, 10)

        params = {
            "apikey": settings.NEWS_API_KEY,
            "category": normalized_topic,
            "language": "en",
            "size": limit,
        }

        response = requests.get(
            "https://newsdata.io/api/1/latest",
            params=params,
            timeout=15
        )
        response.raise_for_status()
        data = response.json()

        articles = []
        for item in data.get("results", [])[:limit]:
            articles.append({
                "title": item.get("title"),
                "description": item.get("description"),
                "source": item.get("source_id"),
                "url": item.get("link"),
                "published": item.get("pubDate"),
                "category": item.get("category", [normalized_topic]),
            })

        log.info(f"[News] Topic '{normalized_topic}' → {len(articles)} articles")

        return {
            "status": "success",
            "topic": normalized_topic,
            "article_count": len(articles),
            "articles": articles,
        }

    except requests.exceptions.RequestException as e:
        log.error(f"[News] API error: {e}")
        return {"status": "error", "message": f"News service unavailable: {e}"}
    except Exception as e:
        log.error(f"[News] Error: {e}")
        return {"status": "error", "message": str(e)}


def search_timed_news(query: str, months_back: int = 6, limit: int = 5) -> Dict:
    """
    Search for news within a specific time window.

    Args:
        query: Search query (company, topic, etc.)
        months_back: Number of months to look back
        limit: Number of articles to return

    Returns:
        Time-filtered news articles
    """
    if not settings.NEWS_API_KEY:
        return {"status": "error", "message": "News API key not configured"}

    try:
        # Calculate date range
        end_date = datetime.now()
        start_date = end_date - timedelta(days=months_back * 30)

        from_date = start_date.strftime("%Y-%m-%d")
        to_date = end_date.strftime("%Y-%m-%d")

        params = {
            "apikey": settings.NEWS_API_KEY,
            "q": query,
            "language": "en",
            "from_date": from_date,
            "to_date": to_date,
            "size": limit,
        }

        response = requests.get(
            "https://newsdata.io/api/1/news",
            params=params,
            timeout=15
        )
        response.raise_for_status()
        data = response.json()

        articles = []
        for item in data.get("results", [])[:limit]:
            articles.append({
                "title": item.get("title"),
                "description": item.get("description"),
                "source": item.get("source_id"),
                "url": item.get("link"),
                "published": item.get("pubDate"),
            })

        log.info(f"[TimedNews] '{query}' ({months_back} months) → {len(articles)} articles")

        return {
            "status": "success",
            "query": query,
            "time_range": f"Last {months_back} months",
            "from_date": from_date,
            "to_date": to_date,
            "article_count": len(articles),
            "articles": articles,
        }

    except requests.exceptions.RequestException as e:
        log.error(f"[TimedNews] API error: {e}")
        return {"status": "error", "message": f"News service unavailable: {e}"}
    except Exception as e:
        log.error(f"[TimedNews] Error: {e}")
        return {"status": "error", "message": str(e)}