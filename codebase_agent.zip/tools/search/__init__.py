"""
tools/search/__init__.py - Search and news tools.
"""

from tools.search.web_search import web_search
from tools.search.news import get_news, search_timed_news
from tools.search.timeline import get_entity_timeline

__all__ = [
    "web_search",
    "get_news",
    "search_timed_news",
    "get_entity_timeline",
]