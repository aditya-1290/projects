"""
tools/search/timeline.py - Entity timeline tool.
"""

from typing import Dict, List

from tools.search.news import search_timed_news
from utils.logger import log

# Event categories and their keywords
EVENT_CATEGORIES = {
    "launch": ["launch", "release", "announced", "unveiled", "introduces", "debut"],
    "update": ["update", "upgrade", "version", "feature", "improves", "enhances"],
    "partnership": ["partners", "collaboration", "deal", "agreement", "alliance"],
    "achievement": ["achieves", "milestone", "record", "surpasses", "reaches"],
    "acquisition": ["acquires", "buys", "merger", "purchase", "takeover"],
    "funding": ["raises", "funding", "investment", "valuation", "series"],
    "leadership": ["ceo", "appoints", "hires", "executive", "leadership"],
}


def _categorize_event(title: str, description: str) -> str:
    """Categorize an event based on title and description."""
    text = (title + " " + description).lower()

    for category, keywords in EVENT_CATEGORIES.items():
        if any(kw in text for kw in keywords):
            return category

    return "general"


def get_entity_timeline(entity: str, months_back: int = 12) -> Dict:
    """
    Get a timeline of major events/developments for an entity.

    Args:
        entity: Company, product, or topic name
        months_back: How far back to look (default 12 months)

    Returns:
        Timeline of events categorized by type
    """
    try:
        log.info(f"[Timeline] Building timeline for '{entity}' over {months_back} months")

        # Search for different types of events
        searches = [
            (f"{entity} development milestone", 10),
            (f"{entity} launch release announced", 5),
            (f"{entity} update version new feature", 5),
            (f"{entity} funding investment acquisition", 5),
        ]

        all_articles: List[Dict] = []
        seen_urls = set()

        for query, limit in searches:
            result = search_timed_news(query, months_back, limit)
            if result.get("status") == "success":
                for article in result.get("articles", []):
                    url = article.get("url", "")
                    if url and url not in seen_urls:
                        seen_urls.add(url)
                        all_articles.append(article)

        # Sort by date (newest first)
        all_articles.sort(key=lambda x: x.get("published", ""), reverse=True)

        # Categorize events
        timeline_events = []
        category_counts = {cat: 0 for cat in EVENT_CATEGORIES.keys()}
        category_counts["general"] = 0

        for article in all_articles[:20]:
            category = _categorize_event(
                article.get("title", ""),
                article.get("description", "")
            )
            category_counts[category] += 1

            timeline_events.append({
                "date": article.get("published"),
                "title": article.get("title"),
                "description": article.get("description", "")[:200],
                "category": category,
                "source": article.get("source"),
                "url": article.get("url"),
            })

        log.info(f"[Timeline] Found {len(timeline_events)} events for '{entity}'")

        return {
            "status": "success",
            "entity": entity,
            "time_period": f"Last {months_back} months",
            "event_count": len(timeline_events),
            "timeline": timeline_events[:15],
            "categories": category_counts,
        }

    except Exception as e:
        log.error(f"[Timeline] Error: {e}")
        return {"status": "error", "message": str(e)}