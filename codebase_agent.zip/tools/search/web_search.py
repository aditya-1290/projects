"""
tools/search/web_search.py - Web search tool with date filtering.
"""

import re
import requests
from datetime import datetime
from typing import Dict, Optional

from utils.logger import log


def web_search(query: str, num_results: int = 5, time_filter: Optional[str] = None) -> Dict:
    """
    Search the web using DuckDuckGo with optional date filtering.

    Args:
        query: Search query
        num_results: Number of results (default 5, max 10)
        time_filter: 'd' (day), 'w' (week), 'm' (month), 'y' (year)

    Returns:
        Search results dictionary
    """
    try:
        # Detect time constraints in query
        time_patterns = {
            r'last\s+(\d+)\s+days?': lambda m: f"after:{int(m.group(1))}d",
            r'last\s+(\d+)\s+weeks?': lambda m: f"after:{int(m.group(1))}w",
            r'last\s+(\d+)\s+months?': lambda m: f"after:{int(m.group(1))}m",
            r'past\s+(\d+)\s+days?': lambda m: f"after:{int(m.group(1))}d",
            r'in\s+the\s+last\s+(\d+)\s+months?': lambda m: f"after:{int(m.group(1))}m",
            r'this\s+year': lambda m: f"after:{datetime.now().month - 1}m",
            r'this\s+month': lambda m: f"after:30d",
            r'this\s+week': lambda m: f"after:7d",
        }

        enhanced_query = query

        # Skip date parsing for URLs
        if not (query.startswith("https://") or query.startswith("https://")):
            for pattern, formatter in time_patterns.items():
                match = re.search(pattern, query, re.IGNORECASE)
                if match:
                    date_suffix = formatter(match)
                    enhanced_query = f"{query} {date_suffix}"
                    log.debug(f"[WebSearch] Added date filter: {date_suffix}")
                    break

        if time_filter:
            filter_map = {'d': 'day', 'w': 'week', 'm': 'month', 'y': 'year'}
            time_str = filter_map.get(time_filter, '')
            enhanced_query = f"{query} (past {time_str})"

        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }

        response = requests.post(
            "https://lite.duckduckgo.com/lite/",
            data={"q": enhanced_query},
            headers=headers,
            timeout=15
        )
        response.raise_for_status()
        html = response.text

        results = []

        # Extract results
        link_pat = re.compile(
            r'<a[^>]+class="result-link"[^>]*href="([^"]+)"[^>]*>(.*?)</a>',
            re.DOTALL | re.IGNORECASE
        )
        snip_pat = re.compile(
            r'<td[^>]+class="result-snippet"[^>]*>(.*?)</td>',
            re.DOTALL | re.IGNORECASE
        )

        # Extract dates
        date_pat = re.compile(
            r'(\d{1,2}\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{4})|'
            r'(\d{4}-\d{2}-\d{2})|'
            r'((?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{1,2},\s+\d{4})',
            re.IGNORECASE
        )

        links = link_pat.findall(html)
        snippets = [re.sub(r'<.*?>', '', s).strip() for s in snip_pat.findall(html)]

        for i, (url, title) in enumerate(links[:num_results]):
            clean_title = re.sub(r'<.*?>', '', title).strip()
            if clean_title:
                snippet = snippets[i] if i < len(snippets) else ""
                date_match = date_pat.search(snippet) or date_pat.search(clean_title)
                extracted_date = date_match.group(0) if date_match else None

                results.append({
                    "title": clean_title,
                    "url": url,
                    "snippet": snippet[:300],
                    "date": extracted_date,
                })

        log.info(f"[WebSearch] '{query[:50]}...' → {len(results)} results")

        return {
            "status": "success",
            "query": query,
            "count": len(results),
            "results": results,
        }

    except requests.exceptions.RequestException as e:
        log.error(f"[WebSearch] Network error: {e}")
        return {"status": "error", "message": f"Search service unavailable: {e}"}
    except Exception as e:
        log.error(f"[WebSearch] Error: {e}")
        return {"status": "error", "message": str(e)}