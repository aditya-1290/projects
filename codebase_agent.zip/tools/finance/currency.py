"""
tools/finance/currency.py - Currency conversion tool.
"""

import requests
from typing import Dict

from config.settings import settings
from utils.constants import CURRENCY_NAMES
from utils.logger import log


def _normalize_currency(currency: str) -> str:
    """Normalize currency code or name to 3-letter code."""
    currency_upper = currency.upper().strip()

    if currency_upper in settings.CURRENCY_CODES if hasattr(settings, 'CURRENCY_CODES') else CURRENCY_NAMES:
        return currency_upper

    currency_lower = currency.lower()
    if currency_lower in CURRENCY_NAMES:
        return CURRENCY_NAMES[currency_lower]

    return currency_upper


def convert_currency(amount: float, from_currency: str, to_currency: str) -> Dict:
    """
    Convert amount between currencies.

    Args:
        amount: Amount to convert
        from_currency: Source currency (e.g., 'USD', 'dollars')
        to_currency: Target currency (e.g., 'INR', 'rupees')

    Returns:
        Conversion result dictionary
    """
    if not settings.EXCHANGERATE_KEY:
        return {"status": "error", "message": "Currency API key not configured"}

    try:
        src = _normalize_currency(from_currency)
        tgt = _normalize_currency(to_currency)

        response = requests.get(
            f"https://v6.exchangerate-api.com/v6/{settings.EXCHANGERATE_KEY}/pair/{src}/{tgt}/{amount}",
            timeout=10
        )
        response.raise_for_status()
        data = response.json()

        if data.get("result") != "success":
            return {
                "status": "error",
                "message": data.get("error-type", "Unknown error")
            }

        return {
            "status": "success",
            "from": src,
            "to": tgt,
            "original_amount": amount,
            "converted_amount": round(data["conversion_result"], 4),
            "exchange_rate": data["conversion_rate"],
            "last_updated": data.get("time_last_update_utc", "N/A"),
        }

    except requests.exceptions.RequestException as e:
        log.error(f"[Currency] API error: {e}")
        return {"status": "error", "message": f"Currency service unavailable: {e}"}
    except Exception as e:
        log.error(f"[Currency] Error: {e}")
        return {"status": "error", "message": str(e)}