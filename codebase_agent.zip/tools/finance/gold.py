"""
tools/finance/gold.py - Gold price tool.
"""

import requests
from typing import Dict

from utils.logger import log


def get_gold_price() -> Dict:
    """
    Get current gold price per troy ounce in USD.

    Returns:
        Gold price data dictionary
    """
    try:
        response = requests.get(
            "https://api.gold-api.com/price/XAU",
            timeout=10
        )
        response.raise_for_status()
        data = response.json()

        if not data or "price" not in data:
            return {"status": "error", "message": "No gold price data returned"}

        return {
            "status": "success",
            "commodity": "Gold",
            "symbol": "XAU",
            "price_per_troy_oz": data.get("price"),
            "currency": data.get("currency", "USD"),
            "name": data.get("name", "Gold"),
            "updated_at": data.get("updatedAt"),
            "note": "Price per troy ounce in USD. Source: gold-api.com",
        }

    except requests.exceptions.RequestException as e:
        log.error(f"[Gold] API error: {e}")
        return {"status": "error", "message": f"Gold API unavailable: {e}"}
    except Exception as e:
        log.error(f"[Gold] Error: {e}")
        return {"status": "error", "message": str(e)}