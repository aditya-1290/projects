"""
tools/finance/stocks.py - Stock price tool.
"""

import requests
from typing import Dict

from config.settings import settings
from utils.constants import COMMON_TICKERS
from utils.logger import log


def get_stock_price(ticker: str) -> Dict:
    """
    Get current stock price for a ticker symbol.

    Args:
        ticker: Stock ticker symbol (e.g., 'AAPL', 'TSLA', 'TCS.NS')

    Returns:
        Stock price data dictionary
    """
    if not settings.API_NINJAS_KEY:
        return {"status": "error", "message": "Stock API key not configured"}

    # Check common ticker mappings
    ticker_lower = ticker.lower()
    if ticker_lower in COMMON_TICKERS:
        ticker = COMMON_TICKERS[ticker_lower]

    try:
        response = requests.get(
            "https://api.api-ninjas.com/v1/stockprice",
            headers={"X-Api-Key": settings.API_NINJAS_KEY},
            params={"ticker": ticker.upper()},
            timeout=10
        )
        response.raise_for_status()
        data = response.json()

        if not data or "price" not in data:
            return {
                "status": "error",
                "message": f"No data found for ticker '{ticker}'. Check the symbol."
            }

        return {
            "status": "success",
            "ticker": data.get("ticker"),
            "name": data.get("name"),
            "price": data.get("price"),
            "exchange": data.get("exchange"),
            "currency": data.get("currency", "USD"),
            "volume": data.get("volume"),
            "change": data.get("change"),
            "change_percent": data.get("change_percent"),
            "note": "Price delayed ~15 minutes on free plan.",
        }

    except requests.exceptions.RequestException as e:
        log.error(f"[Stock] API error for '{ticker}': {e}")
        return {"status": "error", "message": f"Stock service unavailable: {e}"}
    except Exception as e:
        log.error(f"[Stock] Error for '{ticker}': {e}")
        return {"status": "error", "message": str(e)}