"""
tools/utility/converter.py - Unit conversion tool.
"""

from typing import Dict, Optional

from utils.constants import LENGTH_UNITS, WEIGHT_UNITS, VOLUME_UNITS

# Unit categories
UNIT_CATEGORIES = {
    "length": set(LENGTH_UNITS.keys()),
    "weight": set(WEIGHT_UNITS.keys()),
    "volume": set(VOLUME_UNITS.keys()),
    "temperature": {"c", "f", "k", "celsius", "fahrenheit", "kelvin"},
}

# Unit aliases
UNIT_ALIASES = {
    # Length
    "millimeter": "mm", "centimeter": "cm", "meter": "m", "kilometer": "km",
    "inch": "in", "inches": "in", "foot": "ft", "feet": "ft",
    "yard": "yd", "yards": "yd", "mile": "mi", "miles": "mi",
    # Weight
    "milligram": "mg", "gram": "g", "kilogram": "kg", "tonne": "t", "ton": "t",
    "ounce": "oz", "ounces": "oz", "pound": "lb", "pounds": "lb", "lbs": "lb",
    "stone": "st",
    # Volume
    "milliliter": "ml", "millilitre": "ml", "liter": "l", "litre": "l",
    "teaspoon": "tsp", "tablespoon": "tbsp",
    "fluid ounce": "fl_oz", "cup": "cup",
    "pint": "pt", "quart": "qt", "gallon": "gal",
    # Temperature
    "celsius": "c", "fahrenheit": "f", "kelvin": "k",
}


def _normalize_unit(unit: str) -> str:
    """Convert user-friendly unit names to standard codes."""
    unit_lower = unit.lower().strip()

    if unit_lower in UNIT_ALIASES:
        return UNIT_ALIASES[unit_lower]

    for category_units in UNIT_CATEGORIES.values():
        if unit_lower in category_units:
            return unit_lower

    return unit_lower


def _get_unit_category(unit: str) -> Optional[str]:
    """Determine which category a unit belongs to."""
    unit_norm = _normalize_unit(unit)

    for category, units in UNIT_CATEGORIES.items():
        if unit_norm in units:
            return category

    return None


def convert_units(value: float, from_unit: str, to_unit: str) -> Dict:
    """
    Convert between units of length, weight, volume, and temperature.

    Args:
        value: Numeric value to convert
        from_unit: Source unit (e.g., 'km', 'miles', 'kg', 'pounds', 'celsius')
        to_unit: Target unit

    Returns:
        Conversion result dictionary
    """
    try:
        from_norm = _normalize_unit(from_unit)
        to_norm = _normalize_unit(to_unit)

        from_cat = _get_unit_category(from_norm)
        to_cat = _get_unit_category(to_norm)

        if not from_cat or not to_cat:
            return {
                "status": "error",
                "message": f"Unknown unit(s): from='{from_unit}', to='{to_unit}'"
            }

        if from_cat != to_cat:
            return {
                "status": "error",
                "message": f"Cannot convert between {from_cat} and {to_cat}"
            }

        # Temperature requires special formulas
        if from_cat == "temperature":
            # Convert to Celsius first
            if from_norm in ("c", "celsius"):
                celsius = value
            elif from_norm in ("f", "fahrenheit"):
                celsius = (value - 32) * 5 / 9
            elif from_norm in ("k", "kelvin"):
                celsius = value - 273.15
            else:
                celsius = value

            # Convert from Celsius to target
            if to_norm in ("c", "celsius"):
                result = celsius
                to_symbol = "°C"
            elif to_norm in ("f", "fahrenheit"):
                result = (celsius * 9 / 5) + 32
                to_symbol = "°F"
            elif to_norm in ("k", "kelvin"):
                result = celsius + 273.15
                to_symbol = "K"
            else:
                result = celsius
                to_symbol = to_norm

            unit_symbols = {"c": "°C", "f": "°F", "k": "K"}
            from_symbol = unit_symbols.get(from_norm, from_norm)

        else:
            # Length, weight, volume - use conversion factors
            if from_cat == "length":
                factors = LENGTH_UNITS
            elif from_cat == "weight":
                factors = WEIGHT_UNITS
            else:
                factors = VOLUME_UNITS

            base_value = value * factors[from_norm]
            result = base_value / factors[to_norm]
            from_symbol = from_norm
            to_symbol = to_norm

        return {
            "status": "success",
            "category": from_cat,
            "from": {
                "value": value,
                "unit": from_unit,
                "normalized": from_norm,
            },
            "to": {
                "value": round(result, 6),
                "unit": to_unit,
                "normalized": to_norm,
            },
            "formatted": f"{value} {from_unit} = {round(result, 4)} {to_unit}",
        }

    except Exception as e:
        return {"status": "error", "message": str(e)}