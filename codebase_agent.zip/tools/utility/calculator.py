"""
tools/utility/calculator.py - Safe mathematical expression evaluator.
"""

import math
import re
from typing import Dict

# Safe math functions
_SAFE_MATH = {
    "sqrt": math.sqrt,
    "abs": abs,
    "round": round,
    "pow": pow,
    "log": math.log,
    "log10": math.log10,
    "log2": math.log2,
    "ceil": math.ceil,
    "floor": math.floor,
    "sin": math.sin,
    "cos": math.cos,
    "tan": math.tan,
    "asin": math.asin,
    "acos": math.acos,
    "atan": math.atan,
    "pi": math.pi,
    "e": math.e,
    "tau": math.tau,
}


def calculate(expression: str) -> Dict:
    """
    Safely evaluate a mathematical expression.

    Supports: +, -, *, /, **, %, (), and math functions:
    sqrt, abs, round, pow, log, log10, ceil, floor, sin, cos, tan, pi, e

    Args:
        expression: Math expression to evaluate

    Returns:
        Calculation result dictionary
    """
    try:
        # Sanitize expression
        allowed_letters = set("sqrtabsroundpowlogceilfloorsincostanpie")
        clean = re.sub(
            r"[^0-9+\-*/().%\s]",
            lambda m: m.group() if m.group() in allowed_letters else "",
            expression
        )
        clean = clean.strip()

        if not clean:
            return {"status": "error", "message": "Expression is empty after sanitization"}

        # Handle percentage
        if "%" in clean:
            clean = clean.replace("%", "/100")

        # Evaluate safely
        result = eval(clean, {"__builtins__": {}}, _SAFE_MATH)

        # Round to avoid floating point noise
        if isinstance(result, float):
            result = round(result, 10)

        return {
            "status": "success",
            "expression": expression,
            "evaluated": clean,
            "result": result,
            "value": result,
        }

    except ZeroDivisionError:
        return {"status": "error", "message": "Division by zero"}
    except SyntaxError:
        return {"status": "error", "message": "Invalid expression syntax"}
    except Exception as e:
        return {"status": "error", "message": f"Could not evaluate: {e}"}