"""
tools/codebase/analyzer.py - Code analysis tools.
"""

from pathlib import Path
from typing import Dict, List


def analyze_code(file_path: str) -> Dict:
    """
    Analyze a Python file for structure and complexity.

    Args:
        file_path: Path to Python file

    Returns:
        Code analysis dictionary
    """
    try:
        path = Path(file_path).resolve()

        if not path.exists():
            return {"status": "error", "message": f"File not found: {file_path}"}

        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()

        lines = content.split('\n')

        imports = []
        functions = []
        classes = []

        for line in lines:
            stripped = line.strip()
            if stripped.startswith('import ') or stripped.startswith('from '):
                imports.append(stripped)
            elif stripped.startswith('def '):
                func_name = stripped.split('def ')[1].split('(')[0]
                functions.append(func_name)
            elif stripped.startswith('class '):
                class_name = stripped.split('class ')[1].split('(')[0].split(':')[0]
                classes.append(class_name)

        return {
            "status": "success",
            "file": str(path),
            "total_lines": len(lines),
            "non_empty_lines": len([l for l in lines if l.strip()]),
            "imports": imports[:20],
            "import_count": len(imports),
            "functions": functions,
            "function_count": len(functions),
            "classes": classes,
            "class_count": len(classes),
            "language": path.suffix.lstrip('.'),
        }

    except Exception as e:
        return {"status": "error", "message": str(e)}


def search_code(directory: str, query: str, file_pattern: str = "*") -> Dict:
    """
    Search for text in files within a directory.

    Args:
        directory: Directory to search in
        query: Text to search for
        file_pattern: File pattern to match (e.g., "*.py")

    Returns:
        Search results dictionary
    """
    try:
        dir_path = Path(directory).resolve()

        if not dir_path.exists():
            return {"status": "error", "message": f"Directory not found: {directory}"}

        results = []
        files_searched = 0
        query_lower = query.lower()

        for file_path in dir_path.rglob(file_pattern):
            if file_path.is_file():
                if file_path.stat().st_size > 1024 * 1024:  # Skip >1MB
                    continue

                files_searched += 1
                if files_searched > 50:
                    break

                try:
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        lines = f.readlines()

                    for line_num, line in enumerate(lines):
                        if query_lower in line.lower():
                            results.append({
                                "file": str(file_path.relative_to(dir_path)),
                                "line": line_num + 1,
                                "content": line.strip()[:200],
                            })

                            if len(results) >= 50:
                                break
                except Exception:
                    continue

                if len(results) >= 50:
                    break

        return {
            "status": "success",
            "query": query,
            "directory": str(dir_path),
            "files_searched": files_searched,
            "matches": len(results),
            "results": results[:50],
        }

    except Exception as e:
        return {"status": "error", "message": str(e)}