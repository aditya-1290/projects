"""
tools/codebase/file_ops.py - File operations tools.
"""

from pathlib import Path
from typing import Optional, Dict, List


def read_file(path: str, start_line: int = 0, end_line: Optional[int] = None) -> Dict:
    """
    Read a file from the filesystem with optional line range.

    Args:
        path: Path to the file
        start_line: Starting line number (0-indexed)
        end_line: Ending line number (exclusive, None for all)

    Returns:
        File content dictionary
    """
    try:
        file_path = Path(path).resolve()

        # Security: Prevent reading sensitive files
        sensitive_patterns = ['.env', '.git', 'secrets', 'password', 'private', 'key']
        path_str = str(file_path).lower()
        if any(p in path_str for p in sensitive_patterns):
            return {
                "status": "error",
                "message": "Cannot read sensitive files for security reasons."
            }

        if not file_path.exists():
            return {"status": "error", "message": f"File not found: {path}"}

        if file_path.stat().st_size > 5 * 1024 * 1024:  # 5MB limit
            return {"status": "error", "message": "File too large (>5MB)"}

        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            lines = f.readlines()

        total_lines = len(lines)

        if end_line is None:
            end_line = total_lines

        selected_lines = lines[start_line:end_line]
        content = ''.join(selected_lines)

        return {
            "status": "success",
            "path": str(file_path),
            "total_lines": total_lines,
            "start_line": start_line,
            "end_line": min(end_line, total_lines),
            "content": content[:50000],
            "language": file_path.suffix.lstrip('.'),
        }

    except Exception as e:
        return {"status": "error", "message": str(e)}


def write_file(path: str, content: str, append: bool = False) -> Dict:
    """
    Write content to a file.

    Args:
        path: Path to the file
        content: Content to write
        append: If True, append instead of overwrite

    Returns:
        Write result dictionary
    """
    try:
        file_path = Path(path).resolve()

        # Create parent directories if needed
        file_path.parent.mkdir(parents=True, exist_ok=True)

        mode = 'a' if append else 'w'
        with open(file_path, mode, encoding='utf-8') as f:
            f.write(content)

        return {
            "status": "success",
            "path": str(file_path),
            "written": len(content),
            "mode": "append" if append else "write",
        }

    except Exception as e:
        return {"status": "error", "message": str(e)}


def list_directory(path: str = ".", pattern: Optional[str] = None) -> Dict:
    """
    List files and directories.

    Args:
        path: Directory path
        pattern: Optional glob pattern (e.g., "*.py")

    Returns:
        Directory listing dictionary
    """
    try:
        dir_path = Path(path).resolve()

        if not dir_path.exists():
            return {"status": "error", "message": f"Directory not found: {path}"}

        if not dir_path.is_dir():
            return {"status": "error", "message": f"Not a directory: {path}"}

        if pattern:
            items = list(dir_path.glob(pattern))
        else:
            items = list(dir_path.iterdir())

        items = items[:100]  # Limit results

        files = []
        dirs = []

        for item in items:
            info = {
                "name": item.name,
                "path": str(item),
                "size": item.stat().st_size if item.is_file() else 0,
                "modified": item.stat().st_mtime,
            }
            if item.is_dir():
                dirs.append(info)
            else:
                files.append(info)

        return {
            "status": "success",
            "path": str(dir_path),
            "files": sorted(files, key=lambda x: x["name"]),
            "directories": sorted(dirs, key=lambda x: x["name"]),
            "total_files": len(files),
            "total_dirs": len(dirs),
        }

    except Exception as e:
        return {"status": "error", "message": str(e)}