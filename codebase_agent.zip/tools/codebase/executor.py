"""
tools/codebase/executor.py - Command execution tools.
"""

import os
import subprocess
from pathlib import Path
from typing import Dict

from utils.constants import ALLOWED_COMMANDS, DANGEROUS_PATTERNS


def execute_command(command: str, timeout: int = 30) -> Dict:
    """
    Execute a safe shell command.

    Args:
        command: Command to execute
        timeout: Timeout in seconds

    Returns:
        Command execution result
    """
    # Security checks
    command_lower = command.lower()

    for pattern in DANGEROUS_PATTERNS:
        if pattern.lower() in command_lower:
            return {
                "status": "error",
                "message": f"Dangerous command blocked: contains '{pattern}'"
            }

    first_word = command.split()[0] if command.split() else ""
    if first_word not in ALLOWED_COMMANDS:
        return {
            "status": "error",
            "message": f"Command not allowed: '{first_word}'"
        }

    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=os.getcwd(),
        )

        return {
            "status": "success",
            "command": command,
            "stdout": result.stdout[:5000],
            "stderr": result.stderr[:1000],
            "return_code": result.returncode,
        }

    except subprocess.TimeoutExpired:
        return {"status": "error", "message": f"Command timed out after {timeout}s"}
    except Exception as e:
        return {"status": "error", "message": str(e)}


def git_operation(repo_path: str, operation: str) -> Dict:
    """
    Perform git operations.

    Args:
        repo_path: Path to git repository
        operation: 'status', 'log', 'diff', 'branch', 'remote'

    Returns:
        Git operation result
    """
    try:
        path = Path(repo_path).resolve()

        if not path.exists():
            return {"status": "error", "message": f"Path not found: {repo_path}"}

        allowed_ops = {
            'status': ['git', 'status', '--porcelain'],
            'log': ['git', 'log', '--oneline', '-n', '20'],
            'diff': ['git', 'diff', '--stat'],
            'branch': ['git', 'branch', '-a'],
            'remote': ['git', 'remote', '-v'],
        }

        if operation not in allowed_ops:
            return {"status": "error", "message": f"Unknown operation: {operation}"}

        cmd = allowed_ops[operation]

        result = subprocess.run(
            cmd,
            cwd=str(path),
            capture_output=True,
            text=True,
            timeout=30,
        )

        return {
            "status": "success",
            "operation": operation,
            "repo": str(path),
            "output": result.stdout[:5000],
            "error": result.stderr[:1000] if result.stderr else None,
        }

    except subprocess.TimeoutExpired:
        return {"status": "error", "message": "Operation timed out"}
    except FileNotFoundError:
        return {"status": "error", "message": "Git is not installed or not in PATH"}
    except Exception as e:
        return {"status": "error", "message": str(e)}