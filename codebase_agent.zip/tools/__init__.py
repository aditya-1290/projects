"""
tools/__init__.py - Tool registry that imports and exposes all tools.
"""

from typing import Dict, Callable, List

# Weather & Time Tools
from tools.weather.weather import get_weather
from tools.weather.time import get_current_time, get_date_info, get_world_clock

# Finance Tools
from tools.finance.stocks import get_stock_price
from tools.finance.gold import get_gold_price
from tools.finance.currency import convert_currency

# Search & News Tools
from tools.search.web_search import web_search
from tools.search.news import get_news, search_timed_news
from tools.search.timeline import get_entity_timeline

# CodeBase Tools
from tools.codebase.file_ops import read_file, write_file, list_directory
from tools.codebase.analyzer import analyze_code, search_code
from tools.codebase.executor import execute_command, git_operation

# GitHub Tools - Updated import path
from tools.github_tools.client import (
    get_github_user_info,
    list_github_user_repos,
    get_repo_contents,
    get_file_content,
)
from tools.github_tools.indexer import index_github_repo, index_all_user_repos
from tools.github_tools.searcher import search_indexed_code, list_indexed_repos

# Utility Tools
from tools.utility.calculator import calculate
from tools.utility.converter import convert_units


ALL_TOOLS: List[Callable] = [
    # Weather & Time
    get_weather, get_current_time, get_date_info, get_world_clock,
    # Finance
    get_stock_price, get_gold_price, convert_currency,
    # Search & News
    web_search, get_news, search_timed_news, get_entity_timeline,
    # CodeBase
    read_file, write_file, list_directory, analyze_code, search_code,
    execute_command, git_operation,
    # GitHub
    get_github_user_info, list_github_user_repos, get_repo_contents,
    get_file_content, index_github_repo, index_all_user_repos,
    search_indexed_code, list_indexed_repos,
    # Utility
    calculate, convert_units,
]

TOOL_REGISTRY: Dict[str, Callable] = {fn.__name__: fn for fn in ALL_TOOLS}


def get_tool(name: str) -> Callable:
    """Get a tool by name."""
    if name not in TOOL_REGISTRY:
        raise ValueError(f"Unknown tool: {name}")
    return TOOL_REGISTRY[name]


def list_tools() -> List[str]:
    """List all available tool names."""
    return list(TOOL_REGISTRY.keys())


def get_tools_by_category() -> Dict[str, List[str]]:
    """Get tools organized by category."""
    return {
        "weather_time": ["get_weather", "get_current_time", "get_date_info", "get_world_clock"],
        "finance": ["get_stock_price", "get_gold_price", "convert_currency"],
        "search_news": ["web_search", "get_news", "search_timed_news", "get_entity_timeline"],
        "codebase": ["read_file", "write_file", "list_directory", "analyze_code",
                     "search_code", "execute_command", "git_operation"],
        "github": ["get_github_user_info", "list_github_user_repos", "get_repo_contents",
                   "get_file_content", "index_github_repo", "index_all_user_repos",
                   "search_indexed_code", "list_indexed_repos"],
        "utility": ["calculate", "convert_units"],
    }