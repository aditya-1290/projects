"""
tools/github_tools/client.py - GitHub API client using PyGithub.
No Git CLI required!
"""

from typing import Optional, List, Dict, Any
from github import Github, Auth  # Now correctly imports from PyGithub
from github.GithubException import GithubException, RateLimitExceededException

from config.settings import settings
from utils.logger import log


class GitHubClient:
    """GitHub API client wrapper using PyGithub."""

    def __init__(self, token: Optional[str] = None):
        """
        Initialize GitHub client.

        Args:
            token: GitHub personal access token (uses settings.GITHUB_TOKEN if not provided)
        """
        self.token = token or settings.GITHUB_TOKEN

        if self.token:
            auth = Auth.Token(self.token)
            self.github = Github(auth=auth)
            log.debug("[GitHub] Authenticated with token")
        else:
            self.github = Github()
            log.warning("[GitHub] No token - rate limited to 60 requests/hour")

        self._user = None

    @property
    def user(self):
        """Get authenticated user (lazy loaded)."""
        if self._user is None and self.token:
            try:
                self._user = self.github.get_user()
            except GithubException:
                pass
        return self._user

    def get_rate_limit(self) -> Dict[str, Any]:
        """Get current rate limit status."""
        try:
            rate_limit = self.github.get_rate_limit()
            return {
                "core_limit": rate_limit.core.limit,
                "core_remaining": rate_limit.core.remaining,
                "core_reset": rate_limit.core.reset.isoformat() if rate_limit.core.reset else None,
                "search_limit": rate_limit.search.limit,
                "search_remaining": rate_limit.search.remaining,
            }
        except GithubException as e:
            return {"error": str(e)}

    def get_user(self, username: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """
        Get GitHub user information.

        Args:
            username: GitHub username (uses authenticated user if None)
        """
        try:
            if username:
                user = self.github.get_user(username)
            else:
                user = self.github.get_user()

            return {
                "login": user.login,
                "name": user.name,
                "bio": user.bio,
                "company": user.company,
                "location": user.location,
                "email": user.email,
                "public_repos": user.public_repos,
                "public_gists": user.public_gists,
                "followers": user.followers,
                "following": user.following,
                "created_at": user.created_at.isoformat() if user.created_at else None,
                "updated_at": user.updated_at.isoformat() if user.updated_at else None,
                "avatar_url": user.avatar_url,
                "html_url": user.html_url,
                "blog": user.blog,
            }
        except GithubException as e:
            log.error(f"[GitHub] Failed to get user '{username}': {e}")
            return None

    def list_repos(self, username: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        List repositories for a user.

        Args:
            username: GitHub username (uses authenticated user if None)
        """
        try:
            if username:
                user = self.github.get_user(username)
            else:
                user = self.github.get_user()

            repos = []
            for repo in user.get_repos():
                repos.append({
                    "name": repo.name,
                    "full_name": repo.full_name,
                    "description": repo.description,
                    "html_url": repo.html_url,
                    "clone_url": repo.clone_url,
                    "language": repo.language,
                    "stargazers_count": repo.stargazers_count,
                    "forks_count": repo.forks_count,
                    "open_issues_count": repo.open_issues_count,
                    "watchers_count": repo.watchers_count,
                    "size": repo.size,
                    "private": repo.private,
                    "fork": repo.fork,
                    "archived": repo.archived,
                    "default_branch": repo.default_branch,
                    "created_at": repo.created_at.isoformat() if repo.created_at else None,
                    "updated_at": repo.updated_at.isoformat() if repo.updated_at else None,
                    "pushed_at": repo.pushed_at.isoformat() if repo.pushed_at else None,
                    "topics": repo.get_topics(),
                    "license": repo.license.name if repo.license else None,
                })

            log.info(f"[GitHub] Found {len(repos)} repositories for {username or 'authenticated user'}")
            return repos

        except GithubException as e:
            log.error(f"[GitHub] Failed to list repos: {e}")
            return []

    def get_repo(self, repo_full_name: str):
        """Get a repository by full name (e.g., 'user/repo')."""
        try:
            return self.github.get_repo(repo_full_name)
        except GithubException as e:
            log.error(f"[GitHub] Failed to get repo '{repo_full_name}': {e}")
            return None

    def get_contents(self, repo_full_name: str, path: str = "") -> List[Dict[str, Any]]:
        """
        Get contents of a repository directory.

        Args:
            repo_full_name: Repository full name (e.g., 'user/repo')
            path: Directory path within repository
        """
        try:
            repo = self.github.get_repo(repo_full_name)
            contents = repo.get_contents(path)

            if not isinstance(contents, list):
                contents = [contents]

            files = []
            for content in contents:
                files.append({
                    "name": content.name,
                    "path": content.path,
                    "type": content.type,
                    "size": content.size,
                    "html_url": content.html_url,
                    "download_url": content.download_url,
                    "sha": content.sha,
                })

            return files

        except GithubException as e:
            log.error(f"[GitHub] Failed to get contents for '{repo_full_name}/{path}': {e}")
            return []

    def get_file_content(self, repo_full_name: str, file_path: str) -> Optional[str]:
        """
        Get the content of a specific file.

        Args:
            repo_full_name: Repository full name (e.g., 'user/repo')
            file_path: Path to file within repository
        """
        try:
            repo = self.github.get_repo(repo_full_name)
            content = repo.get_contents(file_path)

            if content.type == "file":
                import base64
                return base64.b64decode(content.content).decode('utf-8', errors='ignore')

            return None

        except GithubException as e:
            log.error(f"[GitHub] Failed to get file content '{repo_full_name}/{file_path}': {e}")
            return None

    def search_code(self, query: str, language: Optional[str] = None,
                    repo: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Search GitHub code.

        Args:
            query: Search query
            language: Filter by programming language
            repo: Filter by repository (e.g., 'user/repo')
        """
        try:
            search_query = query
            if language:
                search_query += f" language:{language}"
            if repo:
                search_query += f" repo:{repo}"

            results = self.github.search_code(search_query)

            items = []
            for item in results[:20]:  # Limit to 20 results
                items.append({
                    "name": item.name,
                    "path": item.path,
                    "repository": item.repository.full_name,
                    "html_url": item.html_url,
                    "sha": item.sha,
                })

            return items

        except GithubException as e:
            log.error(f"[GitHub] Code search failed: {e}")
            return []

    def close(self):
        """Close GitHub connection."""
        self.github.close()


# =============================================================================
# Tool Functions (exposed to agent)
# =============================================================================

def get_github_user_info(username: Optional[str] = None) -> dict:
    """Get GitHub user profile information."""
    client = GitHubClient()
    try:
        info = client.get_user(username)
        client.close()

        if info:
            return {"status": "success", **info}
        return {"status": "error", "message": f"User '{username}' not found"}
    except Exception as e:
        return {"status": "error", "message": str(e)}


def list_github_user_repos(username: Optional[str] = None) -> dict:
    """List all repositories for a GitHub user."""
    client = GitHubClient()
    try:
        repos = client.list_repos(username)
        client.close()

        return {
            "status": "success",
            "username": username or "authenticated user",
            "repositories": repos,
            "count": len(repos),
        }
    except Exception as e:
        return {"status": "error", "message": str(e)}


def get_repo_contents(repo_full_name: str, path: str = "") -> dict:
    """Get contents of a repository directory."""
    client = GitHubClient()
    try:
        contents = client.get_contents(repo_full_name, path)
        client.close()

        return {
            "status": "success",
            "repo": repo_full_name,
            "path": path,
            "contents": contents,
            "count": len(contents),
        }
    except Exception as e:
        return {"status": "error", "message": str(e)}


def get_file_content(repo_full_name: str, file_path: str) -> dict:
    """Get the content of a specific file."""
    client = GitHubClient()
    try:
        content = client.get_file_content(repo_full_name, file_path)
        client.close()

        if content:
            return {
                "status": "success",
                "repo": repo_full_name,
                "path": file_path,
                "content": content[:10000],  # Limit size
                "size": len(content),
            }
        return {"status": "error", "message": f"File not found or is binary: {file_path}"}
    except Exception as e:
        return {"status": "error", "message": str(e)}