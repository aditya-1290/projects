"""
tools/github_tools/indexer.py - GitHub repository indexing using PyGithub.
No Git CLI required!
"""

import uuid
from typing import Optional, Dict, List, Any
from pathlib import Path

from tools.github_tools.client import GitHubClient
from memory.vector_store import get_vector_store
from utils.logger import log


class GitHubIndexer:
    """
    GitHub repository indexer using PyGithub API.
    No cloning required - works purely through API.
    """

    # File extensions that can be indexed (text files)
    INDEXABLE_EXTENSIONS = {
        '.py', '.js', '.ts', '.jsx', '.tsx', '.java', '.go', '.rs',
        '.c', '.cpp', '.h', '.hpp', '.cs', '.rb', '.php', '.swift',
        '.kt', '.scala', '.sh', '.bash', '.yaml', '.yml', '.json',
        '.xml', '.html', '.css', '.scss', '.sql', '.md', '.txt',
        '.toml', '.ini', '.cfg', '.conf', '.env.example',
    }

    SKIP_DIRS = {
        'node_modules', '__pycache__', '.git', '.venv', 'venv',
        'target', 'build', 'dist', '.next', '.cache', 'coverage',
    }

    MAX_FILE_SIZE = 1024 * 1024  # 1MB

    def __init__(self, github_token: Optional[str] = None):
        self.client = GitHubClient(github_token)
        self.vector_store = get_vector_store()
        self.parsed_files = 0
        self.skipped_files = 0

    def index_repository(self, repo_full_name: str) -> Dict[str, Any]:
        """Index a GitHub repository by fetching files via API."""
        try:
            repo = self.client.get_repo(repo_full_name)
            if not repo:
                return {"status": "error", "message": f"Repository not found: {repo_full_name}"}

            log.info(f"[GitHub] Indexing {repo_full_name} via API")

            all_chunks = []

            try:
                contents = repo.get_contents("")
                files_to_process = self._traverse_repo(repo, contents)
            except Exception as e:
                log.error(f"[GitHub] Failed to get repository tree: {e}")
                return {"status": "error", "message": str(e)}

            log.info(f"[GitHub] Found {len(files_to_process)} indexable files")

            for file_info in files_to_process:
                try:
                    content = self.client.get_file_content(repo_full_name, file_info["path"])
                    if content:
                        chunks = self._chunk_file(
                            content, file_info["path"], file_info["name"], repo_full_name
                        )
                        all_chunks.extend(chunks)
                        self.parsed_files += 1
                    else:
                        self.skipped_files += 1
                except Exception as e:
                    log.debug(f"[GitHub] Skipped {file_info['path']}: {e}")
                    self.skipped_files += 1

            total_stored = self._store_chunks(all_chunks, repo_full_name)

            log.info(f"[GitHub] Indexed {repo_full_name}: {self.parsed_files} files, {total_stored} chunks")

            return {
                "status": "success",
                "repo_name": repo.name,
                "full_name": repo.full_name,
                "description": repo.description,
                "html_url": repo.html_url,
                "files_indexed": self.parsed_files,
                "files_skipped": self.skipped_files,
                "chunks_stored": total_stored,
                "language": repo.language,
                "stars": repo.stargazers_count,
            }

        except Exception as e:
            log.error(f"[GitHub] Index error: {e}")
            return {"status": "error", "message": str(e)}

    def _traverse_repo(self, repo, contents, depth: int = 0) -> List[Dict]:
        """Recursively traverse repository contents."""
        if depth > 5:
            return []

        files = []

        for content in contents:
            if content.type == "dir":
                if content.name in self.SKIP_DIRS:
                    continue
                try:
                    sub_contents = repo.get_contents(content.path)
                    files.extend(self._traverse_repo(repo, sub_contents, depth + 1))
                except Exception:
                    continue
            else:
                if self._should_index(content):
                    files.append({
                        "name": content.name,
                        "path": content.path,
                        "size": content.size,
                    })

        return files

    def _should_index(self, content) -> bool:
        """Check if a file should be indexed."""
        if content.size > self.MAX_FILE_SIZE:
            return False
        ext = Path(content.name).suffix.lower()
        return ext in self.INDEXABLE_EXTENSIONS

    def _get_language(self, file_name: str) -> str:
        """Get programming language from file extension."""
        ext = Path(file_name).suffix.lower()
        language_map = {
            '.py': 'python', '.js': 'javascript', '.ts': 'typescript',
            '.java': 'java', '.go': 'go', '.rs': 'rust', '.c': 'c',
            '.cpp': 'cpp', '.cs': 'csharp', '.rb': 'ruby', '.php': 'php',
            '.swift': 'swift', '.kt': 'kotlin', '.sh': 'bash',
            '.yaml': 'yaml', '.yml': 'yaml', '.json': 'json',
            '.html': 'html', '.css': 'css', '.sql': 'sql', '.md': 'markdown',
        }
        return language_map.get(ext, 'text')

    def _chunk_file(self, content: str, file_path: str, file_name: str, repo_name: str) -> List[Dict]:
        """Split file content into semantic chunks."""
        chunks = []
        language = self._get_language(file_name)
        lines = content.split('\n')
        chunk_size = 100
        overlap = 10

        for i in range(0, len(lines), chunk_size - overlap):
            chunk_lines = lines[i:i + chunk_size]
            chunk_text = '\n'.join(chunk_lines)

            if chunk_text.strip():
                chunks.append({
                    "content": chunk_text[:5000],
                    "metadata": {
                        "repo": repo_name,
                        "file_path": file_path,
                        "file_name": file_name,
                        "language": language,
                        "extension": Path(file_name).suffix,
                        "start_line": i,
                        "end_line": min(i + chunk_size, len(lines)),
                    }
                })

        return chunks

    def _store_chunks(self, chunks: List[Dict], repo_name: str) -> int:
        """Store chunks in vector store."""
        total_stored = 0

        for chunk in chunks:
            text = f"[{chunk['metadata']['file_path']}]\n{chunk['content']}"
            success = self.vector_store.store_success(
                text,
                metadata={"type": "github_code", "repo": repo_name, **chunk["metadata"]}
            )
            if success:
                total_stored += 1

        return total_stored

    def close(self):
        """Close connections."""
        self.client.close()


def index_github_repo(repo_url: str, github_token: Optional[str] = None) -> Dict:
    """Index a GitHub repository."""
    from utils.helpers import parse_github_url

    try:
        parsed = parse_github_url(repo_url)
        if not parsed:
            return {"status": "error", "message": f"Invalid GitHub URL: {repo_url}"}

        owner, repo = parsed
        if not repo:
            return {"status": "error", "message": f"Repository name required: {repo_url}"}

        repo_full_name = f"{owner}/{repo}".replace('.git', '')

        indexer = GitHubIndexer(github_token)
        result = indexer.index_repository(repo_full_name)
        indexer.close()

        return result

    except Exception as e:
        return {"status": "error", "message": str(e)}


def index_all_user_repos(github_username: str, github_token: str) -> Dict:
    """Index all repositories for a GitHub user."""
    try:
        client = GitHubClient(github_token)
        repos = client.list_repos(github_username)
        client.close()

        if not repos:
            return {"status": "error", "message": f"No repositories found for {github_username}"}

        indexed = []
        failed = []

        for repo in repos:
            try:
                indexer = GitHubIndexer(github_token)
                result = indexer.index_repository(repo['full_name'])
                indexer.close()

                if result.get("status") == "success":
                    indexed.append(repo['name'])
                else:
                    failed.append({"name": repo['name'], "error": result.get("message")})
            except Exception as e:
                failed.append({"name": repo['name'], "error": str(e)})

        return {
            "status": "success",
            "username": github_username,
            "total_repos": len(repos),
            "indexed": indexed,
            "indexed_count": len(indexed),
            "failed": failed,
            "failed_count": len(failed),
        }

    except Exception as e:
        return {"status": "error", "message": str(e)}
    