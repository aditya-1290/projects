"""
tools/github_tools/searcher.py - Search indexed GitHub code.
"""

from typing import Optional, Dict
from memory.vector_store import get_vector_store
from utils.logger import log


def search_indexed_code(query: str, repo_name: Optional[str] = None, limit: int = 10) -> Dict:
    """Search indexed GitHub code for relevant snippets."""
    try:
        vector_store = get_vector_store()

        where_filter = {"type": "github_code"}
        if repo_name:
            where_filter["repo"] = repo_name

        results = vector_store.query(
            query, n_results=limit, collection="main", where=where_filter
        )

        matches = []
        for r in results:
            matches.append({
                "content": r["text"][:500],
                "metadata": r["metadata"],
                "relevance": round(r.get("relevance", 0), 3),
                "file": r["metadata"].get("file_path", "unknown"),
                "repo": r["metadata"].get("repo", "unknown"),
                "language": r["metadata"].get("language", "text"),
            })

        log.info(f"[GitHub Search] '{query[:50]}...' → {len(matches)} results")

        return {
            "status": "success",
            "query": query,
            "repo_filter": repo_name,
            "results": matches,
            "count": len(matches),
        }

    except Exception as e:
        log.error(f"[GitHub Search] Error: {e}")
        return {"status": "error", "message": str(e)}


def list_indexed_repos() -> Dict:
    """List all indexed GitHub repositories."""
    try:
        vector_store = get_vector_store()

        results = vector_store.query(
            "github repository", n_results=100, collection="main", where={"type": "github_code"}
        )

        repos = {}
        for r in results:
            repo = r["metadata"].get("repo")
            if repo and repo not in repos:
                repos[repo] = {"name": repo, "files": 0, "languages": set()}
            if repo:
                repos[repo]["files"] += 1
                lang = r["metadata"].get("language")
                if lang:
                    repos[repo]["languages"].add(lang)

        repo_list = []
        for repo, info in repos.items():
            repo_list.append({
                "name": repo,
                "file_count": info["files"],
                "languages": list(info["languages"]),
            })

        return {
            "status": "success",
            "repositories": repo_list,
            "count": len(repo_list),
        }

    except Exception as e:
        log.error(f"[GitHub List] Error: {e}")
        return {"status": "error", "message": str(e)}