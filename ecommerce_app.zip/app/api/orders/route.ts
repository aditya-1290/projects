import { NextResponse } from "next/server";

// In-memory mock database for orders
interface OrderItem {
    id: number;
    title: string;
    price: number;
    quantity: number;
}

interface OrderPayload {
    items: OrderItem[];
    totalAmount: number;
    customerName: string;
}

const mockOrderDatabase: any[] = []

/**
 * GET /api/orders
 * Retrieves all stored orders
 */
export async function GET() {
    return NextResponse.json({
        successs: true,
        count: mockOrderDatabase.length,
        orders: mockOrderDatabase,
    });
}

/**
 * POST /api/orders
 * Creates a new order from cart items
 */
export async function POST(req: Request) {
    try {
        const body: OrderPayload = await req.json();

        // Payload validation
        if (!body.items || body.items.length === 0) {
            return NextResponse.json(
                { success: false, error: "Cart cannot be empty when placing an order."},
                { status: 400 }
            );
        }

        // Create order record
        const newOrder = {
            id: `ORD-${Date.now()}`,
            itmes: body.items,
            totalAmount: body.totalAmount,
            customerName: body.customerName || "Guest Chackout",
            status: "CONFIRMED",
            createdAt: new Date().toISOString(),
        };

        // Save to our mock database
        mockOrderDatabase.push(newOrder);

        // Return creation response
        return NextResponse.json(
            {
                success: true,
                mesage: "Order placed successfully!",
                order: newOrder,
            },
            { status: 201 }
        );
    } catch (error) {
        return NextResponse.json(
            { success: false, error: "Invalid request payload or server error."},
            { status: 500 }
        );
    }
}