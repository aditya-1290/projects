import Header from "@/components/Header";
import Footer from "@/components/Footer";

export default function HomePage() {
  return (
    <div className="min-h-screen flex flex-col bg-slate-900 text-white">
      <Header />
      
      <main className="flex-1 p-8 max-w-4xl mx-auto">
        <h2 className="text-3xl font-bold mb-4">Welcome to Phase 2: Core React & Architecture!</h2>
        <p className="text-slate-300">
          Day 8 Deliverable complete! Your Next.js app is officially rendering modular UI components live in the browser.
        </p>
      </main>

      <Footer />
    </div>
  );
}
