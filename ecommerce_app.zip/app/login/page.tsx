"use client";

import React, { useState, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";

export function LoginForm() {
    const router = useRouter();
    const searchParams = useSearchParams();
    const callbackUrl = searchParams.get("callbackUrl") || "/products";
    const [loading, setLoading] = useState(false);

    const handleSimulatedLogin = () => {
        setLoading(true);

        // Simulate setting an auth cookie for 1 day
        document.cookie = "auth_token=simulated_jwt_token_12345; path=/; max-age=86400;";

        // Redirect user back to where they were headed
        setTimeout(() => {
            router.push(callbackUrl);
            router.refresh();
        }, 500);
    };

    return (
        <div className="max-w-md mx-auto py-16 text-center space-y-6">
            <div className="bg-slate-800 border border-slate-700 p-8 rounded-xl shadow-xl">
                <h1 className="text-2xl font-bold text-white mb-2">Login Required</h1>
                <p className="text-slate-400 text-sm mb-6">
                    You must be logged in to access protected routes like checkout or account details.
                </p>

                <button
                    onClick={handleSimulatedLogin}
                    disabled={loading}
                    className="w-full py-3 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-medium rounded-lg transition-all cursor-pointer shadow-lg disabled:opacity-50"
                >
                    {loading ? "Logging in..." : "Simulate Quick Login"}
                </button>
            </div>
        </div>
    );
}

// Default export wrapped in a Suspense boundary
export default function LoginPage() {
  return (
    <Suspense fallback={<div className="text-center py-20 text-slate-400">Loading...</div>}>
      <LoginForm />
    </Suspense>
  );
}