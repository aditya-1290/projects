import Link from "next/link";

export default function HomePage() {
  return (
    <div className="space-y-6">
      <h1 className="text-4xl font-bold">Welcome to TechStore</h1>
      <p className="text-slate-300 teext-lg">
        Day 14 Deliverable: App Router Navigation and Shared Layouts.  
      </p>        

      <div className="p-66 bg-slate-800 border border-slate-700 rounded-lg">
        <h2 className="text-2xl font-semibold mb-2">Explore Our Store</h2>
        <p className="text-slate-400 mb-4">
          Click below or use the top navigation bar to view our products catalog without full-page refreshes.
        </p>
        <Link
          href="/products"
          className="inline-block px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors"
        >
          Browse Products Catalog →         
        </Link>
      </div>
    </div>
  );
}
