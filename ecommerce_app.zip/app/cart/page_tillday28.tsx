"use client";

import React, { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { useCart } from "@/context/CartContext";

export default function CartPage() {
    const { cart, removeFromCart, updateQuantity, clearCart, totalAmount } = useCart();
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [orderSuccess, setOrderSuccess] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);

    const handleCheckout = async () => {
        if (cart.length === 0) return;

        setIsSubmitting(true);
        setError(null);

        try {
            const response = await fetch("api/orders", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    items: cart.map((item) => ({
                        id: item.id,
                        title: item.title,
                        price: item.price,
                        quantity: item.quantity,
                    })),
                    totalAmount,
                    customerName: "Alex Smith",
                }),
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.error || "Checkout failed");
            }

            setOrderSuccess(data.order.id);
            clearCart();
        } catch (err: any) {
            setError(err.message || "Something went wrong during checkout.");
        } finally {
            setIsSubmitting(false);
        }
    };

    if (orderSuccess) {
        return (
      <div className="max-w-xl mx-auto py-16 text-center space-y-4">
        <div className="w-16 h-16 bg-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto text-3xl font-bold">
          ✓
        </div>
        <h1 className="text-3xl font-bold text-white">Order Confirmed!</h1>
        <p className="text-slate-300">
          Your order ID is <span className="font-mono text-emerald-400 font-bold">{orderSuccess}</span>.
        </p>
        <Link
          href="/products"
          onClick={() => setOrderSuccess(null)}
          className="inline-block mt-4 px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors"
        >
          Continue Shopping
        </Link>
      </div>
    );
  }

  if (cart.length === 0) {
    return (
      <div className="text-center py-20 space-y-4">
        <h1 className="text-3xl font-bold text-white">Your Cart is Empty</h1>
        <p className="text-slate-400 text-sm">Explore our products and add items to your cart.</p>
        <Link
          href="/products"
          className="inline-block px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors"
        >
          View Catalogue
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold text-white">Shopping Cart</h1>

      {error && (
        <div className="bg-red-950/50 border border-red-800 text-red-300 p-4 rounded-xl text-sm">
          {error}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Cart Items List */}
        <div className="lg:col-span-2 space-y-4">
          {cart.map((item) => (
            <div
              key={item.id}
              className="bg-slate-800 border border-slate-700 p-4 rounded-xl flex items-center gap-4"
            >
              <div className="relative w-16 h-16 bg-slate-900 rounded-lg p-2 flex-shrink-0">
                <Image
                  src={item.image}
                  alt={item.title}
                  fill
                  className="object-contain p-1"
                />
              </div>

              <div className="flex-1 min-w-0">
                <h3 className="text-sm font-semibold text-white truncate">{item.title}</h3>
                <p className="text-xs text-emerald-400 font-bold mt-1">
                  ${item.price.toFixed(2)}
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => updateQuantity(item.id, item.quantity - 1)}
                  className="w-7 h-7 bg-slate-700 hover:bg-slate-600 rounded text-white font-bold flex items-center justify-center text-sm"
                >
                  -
                </button>
                <span className="text-sm font-semibold w-6 text-center">{item.quantity}</span>
                <button
                  onClick={() => updateQuantity(item.id, item.quantity + 1)}
                  className="w-7 h-7 bg-slate-700 hover:bg-slate-600 rounded text-white font-bold flex items-center justify-center text-sm"
                >
                  +
                </button>
              </div>

              <button
                onClick={() => removeFromCart(item.id)}
                className="text-slate-400 hover:text-red-400 text-sm p-1 transition-colors"
                title="Remove Item"
              >
                ✕
              </button>
            </div>
          ))}
        </div>

        {/* Order Summary */}
        <div className="bg-slate-800 border border-slate-700 p-6 rounded-xl h-fit space-y-4">
          <h2 className="text-lg font-bold text-white border-b border-slate-700 pb-3">
            Summary
          </h2>

          <div className="space-y-2 text-sm">
            <div className="flex justify-between text-slate-300">
              <span>Subtotal</span>
              <span>${totalAmount.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-slate-300">
              <span>Shipping</span>
              <span className="text-emerald-400 font-medium">FREE</span>
            </div>
            <div className="border-t border-slate-700 pt-3 flex justify-between text-base font-bold text-white">
              <span>Total</span>
              <span className="text-emerald-400">${totalAmount.toFixed(2)}</span>
            </div>
          </div>

          <button
            onClick={handleCheckout}
            disabled={isSubmitting}
            className="w-full py-3 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-medium rounded-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg cursor-pointer"
          >
            {isSubmitting ? "Processing Order..." : "Proceed to Checkout"}
          </button>
        </div>
      </div>
    </div>
  );
}
