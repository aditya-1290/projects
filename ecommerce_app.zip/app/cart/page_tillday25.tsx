"use client";

import React from "react";
import Link from "next/link";
import { useCart } from "@/context/CartContext";

export default function CartPage() {
    const { cart, removeFromCart, totalPrice, totalItems } = useCart();

    return (
        <div className="max-w-4xl mx-auto">
            <h1 className="text-3xl font-bold mb-6">Your Shopping Cart ({totalItems} items)</h1>

            {cart.length === 0 ? (
                /* Empty Cart View */
                <div className="bg-slate-800 border border-slate-700 rounded-lg p-12 text-center">
                    <p className="text-xl text-slate-300 mb-4">Your cart is currently empty.</p>
                    <Link
                        href="/products"
                        className="inline-block px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors"
                    >
                        Browse Products Catalogue →
                    </Link>
                </div>
            ) : (
                /* Populated Cart View */
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    {/* Cart Items List */}
                    <div className="lg:col-span-2 space-y-4">
                        {cart.map((item) => (
                            <div
                                key={item.id}
                                className="bg-slate-800  border border-slate-700 round-lg p-4 flex items-center justify-between  gap-4 shadow-md"
                            >
                                <div className="w-16 h-16 bg-slate-900 rounded p-1 flex-shrink-0 flex items-center justify-center">
                                    <img
                                        src={item.image}
                                        alt={item.title}
                                        className="max-h-full object-contain"
                                    />
                                </div>

                                <div className="flex-1 min-w-0">
                                    <h4 className="font-medium text-slate-100 truncate">{item.title}</h4>
                                    <p className="text-sm text-slate-400">
                                        ${item.price.toFixed(2)} x {item.quantity}
                                    </p>
                                </div>

                                <div className="text-right flex-shrink-0">
                                    <p className="font-bold text-emarald-400 text-lg">
                                        ${(item.price * item.quantity).toFixed(2)}
                                    </p>
                                    <button 
                                        onClick={() => removeFromCart(item.id)}
                                        className="text-xs text-red-400 hover:text-red-300 underline mt-1 cursor-pointer"
                                    >
                                        Remove
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>

                    {/* Order Summary Box */}
                    <div className="bg-slate-800 border border-slate-700 rounded-lg p-6 h-fit shadow-md">
                        <h3 className="text-xl font-semibold mb-4 border-b border-slate-700 pb-2">
                            Order Summary
                        </h3>

                        <div className="space-y-2 text-slate-300 mb-4">
                            <div className="flex justify-between">
                                <span>Items Subtotal:</span>
                                <span>${totalPrice.toFixed(2)}</span>
                            </div>
                            <div className="flex justify-between">
                                <span>Shipping:</span>
                                <span className="text-emarald-400 font-medium">FREE</span>
                            </div>
                        </div>

                        <div className="border-t border-slate-700 pt-3 flex justify-between text-xl font-bold text-white mb-6">
                            <span>Total:</span>
                            <span className="text-emarald-400">${totalPrice.toFixed(2)}</span>
                        </div>

                        <Link
                            href="/checkout"
                            className="block w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg transition-colors text-center"
                            >
                            Proceed to Checkout →
                        </Link>
                    </div>
                </div>
            )}
        </div>
    );
}
