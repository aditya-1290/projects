"use client";

import React, { useReducer } from "react";
import {
  ProductFilter,
  filterReducer,
  initialFilterState,
} from "@/components/ProductFilter";
import { useFetch } from "@/hooks/useFetch";

export interface Product {
  id: number;
  title: string;
  price: number;
  category: string;
  image: string;
}

export default function ProductsPage() {
  const { data: products, loading, error } = useFetch<Product[]>(
    "https://fakestoreapi.com/products?limit=20"
  );

  // 1. Manage filter state at page level
  const [filterState, dispatch] = useReducer(filterReducer, initialFilterState);

  // 2. Derive filtered & sorted product list in real-time
  const filteredProducts = (products || [])
    .filter((product) => {
      // Search filter
      const matchesSearch = product.title
        .toLowerCase()
        .includes(filterState.searchQuery.toLowerCase());

      // Category filter
      const matchesCategory =
        filterState.category === "all" ||
        product.category.toLowerCase() === filterState.category.toLowerCase();

      return matchesSearch && matchesCategory;
    })
    .sort((a, b) => {
      // Sorting filter
      if (filterState.sortBy === "price-asc") {
        return a.price - b.price;
      } else {
        return b.price - a.price;
      }
    });

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Products Catalogue</h1>

      {/* Pass state and dispatch to control the filters */}
      <ProductFilter state={filterState} dispatch={dispatch} />

      <section className="mt-8">
        {loading && (
          <div className="p-8 text-center text-blue-400 font-medium bg-slate-800 rounded-lg border border-slate-700 animate-pulse">
            Loading products...
          </div>
        )}

        {error && (
          <div className="p-6 text-center text-red-400 font-medium bg-red-950/40 rounded-lg border border-red-800">
            ❌ Failed to load products: {error}
          </div>
        )}

        {!loading && !error && (
          <>
            <p className="text-slate-400 mb-4 text-sm">
              Showing <span className="text-emerald-400 font-bold">{filteredProducts.length}</span> of {products?.length || 0} products
            </p>

            {filteredProducts.length === 0 ? (
              <div className="p-8 text-center text-slate-400 bg-slate-800/50 rounded-lg border border-slate-700">
                No products match your search or category filter.
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredProducts.map((product) => (
                  <div
                    key={product.id}
                    className="bg-slate-800 border border-slate-700 rounded-lg p-5 flex flex-col justify-between shadow-md"
                  >
                    <div>
                      <div className="h-40 w-full bg-slate-900 rounded-md mb-4 flex items-center justify-center p-2">
                        <img
                          src={product.image}
                          alt={product.title}
                          className="max-h-full object-contain"
                        />
                      </div>
                      <span className="text-xs uppercase font-bold text-blue-400 tracking-wider">
                        {product.category}
                      </span>
                      <h4 className="text-lg font-medium text-slate-100 mt-1 line-clamp-2">
                        {product.title}
                      </h4>
                    </div>
                    <div className="mt-4 pt-3 border-t border-slate-700 flex justify-between items-center">
                      <span className="text-xl font-bold text-emerald-400">
                        ${product.price.toFixed(2)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </section>
    </div>
  );
}
