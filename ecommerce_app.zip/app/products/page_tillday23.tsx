"use client";

import React, { useReducer, useMemo, useCallback } from "react";
import {
  ProductFilter,
  filterReducer,
  initialFilterState,
} from "@/components/ProductFilter";
import ProductCard  from "@/components/ProductCard";
import { useFetch } from "@/hooks/useFetch";
import { useCart } from "@/context/CartContext";

export interface Product {
  id: number;
  title: string;
  price: number;
  category: string;
  image: string;
}

export default function ProductsPage() {
  const { data: products, loading, error } = useFetch<Product[]>(
    "https://fakestoreapi.com/products?limit=20"
  );

  const { addToCart } = useCart();
  const [filterState, dispatch] = useReducer(filterReducer, initialFilterState);

  // 1. useCallback: Memoize the function reference passed down to ProductCard
  const handleAddToCart = useCallback(
    (product: Product) => {
      // addToCart(product);
    },
    [addToCart]
  );

  // 2. useMemo: Recalculate filtered & sorted products ONLY when products or filterState changes
  const filteredProducts = useMemo(() => {
    return (products || [])
      .filter((product) => {
        const matchesSearch = product.title
          .toLowerCase()
          .includes(filterState.searchQuery.toLowerCase());

        const matchesCategory =
          filterState.category === "all" ||
          product.category.toLowerCase() === filterState.category.toLowerCase();

        return matchesSearch && matchesCategory;
      })
      .sort((a, b) => {
        if (filterState.sortBy === "price-asc") {
          return a.price - b.price;
        } else {
          return b.price - a.price;
        }
      });
  }, [products, filterState]); // Dependencies

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">
        Products Catalogue <span className="text-xs text-emerald-400 font-normal border border-emerald-500/40 bg-emerald-950/40 px-2 py-1 rounded">Optimized with useMemo & useCallback</span>
      </h1>

      <ProductFilter state={filterState} dispatch={dispatch} />

      <section className="mt-8">
        {loading && (
          <div className="p-8 text-center text-blue-400 font-medium bg-slate-800 rounded-lg border border-slate-700 animate-pulse">
            Loading products...
          </div>
        )}

        {error && (
          <div className="p-6 text-center text-red-400 font-medium bg-red-950/40 rounded-lg border border-red-800">
            ❌ Failed to load products: {error}
          </div>
        )}

        {!loading && !error && (
          <>
            <p className="text-slate-400 mb-4 text-sm">
              Showing{" "}
              <span className="text-emerald-400 font-bold">
                {filteredProducts.length}
              </span>{" "}
              of {products?.length || 0} products
            </p>

            {filteredProducts.length === 0 ? (
              <div className="p-8 text-center text-slate-400 bg-slate-800/50 rounded-lg border border-slate-700">
                No products match your search or category filter.
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {/* {filteredProducts.map((product) => (
                  // <ProductCard
                    // key={product.id}
                    // product={product}
                    // onAddToCart={handleAddToCart}
                  />
                ))} */}
              </div>
            )}
          </>
        )}
      </section>
    </div>
  );
}
