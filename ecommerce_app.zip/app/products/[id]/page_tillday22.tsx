"use client";

import React from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { useFetch } from "@/hooks/useFetch";
import { useCart } from "@/context/CartContext";

// Detailed Product Interface (includes description & rating)
interface ProductDetail {
  id: number;
  title: string;
  price: number;
  category: string;
  description: string;
  image: string;
  rating?: {
    rate: number;
    count: number;
  };
}

export default function ProductDetailPage() {
  const params = useParams();
  const productId = params?.id;

  // Fetch individual product by ID
  const { data: product, loading, error } = useFetch<ProductDetail>(
    `https://fakestoreapi.com/products/${productId}`
  );

  const { addToCart } = useCart();

  return (
    <div className="max-w-4xl mx-auto">
      {/* Back Button */}
      <Link
        href="/products"
        className="inline-flex items-center text-sm font-medium text-blue-400 hover:text-blue-300 mb-6 transition-colors"
      >
        ← Back to Catalogue
      </Link>

      {/* Loading State */}
      {loading && (
        <div className="p-12 text-center text-blue-400 font-medium bg-slate-800 rounded-lg border border-slate-700 animate-pulse">
          Loading product details...
        </div>
      )}

      {/* Error State */}
      {error && (
        <div className="p-6 text-center text-red-400 font-medium bg-red-950/40 rounded-lg border border-red-800">
          ❌ Failed to load product: {error}
        </div>
      )}

      {/* Product Detail Card */}
      {!loading && !error && product && (
        <div className="bg-slate-800 border border-slate-700 rounded-xl p-8 grid grid-cols-1 md:grid-cols-2 gap-8 shadow-xl">
          {/* Product Image */}
          <div className="bg-slate-900 rounded-lg p-6 flex items-center justify-center h-80">
            <img
              src={product.image}
              alt={product.title}
              className="max-h-full max-w-full object-contain"
            />
          </div>

          {/* Product Info */}
          <div className="flex flex-col justify-between">
            <div>
              <span className="text-xs font-bold uppercase tracking-widest text-blue-400 bg-blue-950/60 border border-blue-800/50 px-2.5 py-1 rounded-full">
                {product.category}
              </span>

              <h1 className="text-2xl md:text-3xl font-bold text-white mt-3 mb-2">
                {product.title}
              </h1>

              {/* Rating badge if available */}
              {product.rating && (
                <div className="flex items-center gap-2 mb-4 text-sm text-slate-300">
                  <span className="text-amber-400 font-bold">★ {product.rating.rate}</span>
                  <span className="text-slate-500">•</span>
                  <span className="text-slate-400">({product.rating.count} reviews)</span>
                </div>
              )}

              <p className="text-slate-300 text-sm leading-relaxed mb-6">
                {product.description}
              </p>
            </div>

            {/* Price & Action */}
            <div className="pt-4 border-t border-slate-700 flex items-center justify-between">
              <div>
                <span className="text-xs text-slate-400 block">Price</span>
                <span className="text-3xl font-bold text-emerald-400">
                  ${product.price.toFixed(2)}
                </span>
              </div>

              <button
                onClick={() => addToCart(product)}
                className="px-6 py-3 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-medium rounded-lg transition-all cursor-pointer shadow-lg"
              >
                + Add to Cart
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
