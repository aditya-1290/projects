import { Metadata } from "next";
import { notFound } from "next/navigation";
import ProductDetailClient, { ProductDetail } from "@/components/ProductDetailClient";

interface PageProps {
  params: Promise<{ id: string }>;
}

// 1. Dynamic SEO & OpenGraph Metadata
export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { id } = await params;
  
  try {
    const res = await fetch(`https://fakestoreapi.com/products/${id}`);
    if (!res.ok) return { title: "Product Not Found | TechStore" };

    const product: ProductDetail = await res.json();

    return {
      title: `${product.title} | TechStore`,
      description: product.description.substring(0, 160),
      openGraph: {
        title: product.title,
        description: product.description,
        images: [{ url: product.image }],
      },
    };
  } catch {
    return { title: "TechStore Product" };
  }
}

// 2. Server Page Component
export default async function ProductDetailPage({ params }: PageProps) {
  const { id } = await params;

  const res = await fetch(`https://fakestoreapi.com/products/${id}`);

  // Trigger 404 page if product doesn't exist
  if (!res.ok) {
    notFound();
  }

  const product: ProductDetail = await res.json();

  return <ProductDetailClient product={product} />;
}