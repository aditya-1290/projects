"use client";

import React from "react";
import { ProductFilter } from "@/components/ProductFilter";
import { useFetch } from "@/hooks/useFetch";

export interface Product {
  id: number;
  title: string;
  price: number;
  category: string;
  image: string;
}

export default function ProductsPage() {
  const { data: products, loading, error } = useFetch<Product[]>(
    "https://fakestoreapi.com/products?limit=10"
  );

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Products Catalogue</h1>

      {/* <ProductFilter /> */}

      <section className="mt-8">
        {loading && (
          <div className="p-8 text-center text-blue-400 font-medium bg-slate-800 rounded-lg border border-slate-700 animate-pulse">
            Loading products using `useFetch` custom hook...
          </div>
        )}

        {error && (
          <div className="p-6 text-center text-red-400 font-medium bg-red-950/40 rounded-lg border border-red-800">
            ❌ Failed to load products: {error}
          </div>
        )}

        {!loading && !error && products && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((product) => (
              <div
                key={product.id}
                className="bg-slate-800 border border-slate-700 rounded-lg p-5 flex flex-col justify-between shadow-md"
              >
                <div>
                  <div className="h-40 w-full bg-slate-900 rounded-md mb-4 flex items-center justify-center p-2">
                    <img
                      src={product.image}
                      alt={product.title}
                      className="max-h-full object-contain"
                    />
                  </div>
                  <span className="text-xs uppercase font-bold text-blue-400 tracking-wider">
                    {product.category}
                  </span>
                  <h4 className="text-lg font-medium text-slate-100 mt-1 line-clamp-2">
                    {product.title}
                  </h4>
                </div>
                <div className="mt-4 pt-3 border-t border-slate-700 flex justify-between items-center">
                  <span className="text-xl font-bold text-emerald-400">
                    ${product.price.toFixed(2)}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
