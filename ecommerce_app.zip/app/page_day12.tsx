"use client";

import React, { useState, useEffect } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { ProductFilter } from "@/components/ProductFilter";

// Strict Typescript interface for API product object
interface Product {
  id: number;
  title: string;
  price: number;
  category: string;
  image: string;
}

export default function HomePage() {
  // 1. Declare state variables for Data, Loading, and Error
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null); // Union type (string or null)

  // 2. Fetch data inside useeffect on component mount
  useEffect(() => {
    let isMounted = true; // Cleanup flag to prevent state updates on unmounted component
    setLoading(true);

    fetch("https://fakestoreapi.com/products?limit=10")
      .then((res) => {
        if (!res.ok) {
          throw new Error(`HTTP Error! Status: ${res.status}`);
        }
        return res.json();
      })
      .then((data: Product[]) => {
        if (isMounted) {
          setProducts(data);
          setError(null);
        }
      })
      .catch((err: Error) => {
        if (isMounted) {
          if (isMounted) {
            setError(err.message);
          }
        }
      })
      .finally(() => {
        if (isMounted) {
          setLoading(false);
        }
      });
      // Cleanup function
      return () => {
        isMounted =  false;
      };
  }, []); // Empty dependency array = runs ON MOUNT ONLY
  return (
    <div className="min-h-screen flex flex-col bg-slate-900 text-white">
      <Header />

      <main className="flex-1 p-8 max-w-4xl mx-auto w-full">
        <h2 className="text-3xl font-bold mb-6">Day 12: TypeScript with Hooks.</h2>

        {/* Existing day 10 filter component */}
        {/* <ProductFilter /> */}

        {/* Dynamic state rendering */}
        <section className="mt-8">
          <h3 className="text-2xl font-semifold mb-4 text-slate-100">Product List</h3>

          {/* 1. Loading State */}
          {loading && (
            <div className="p-8 text-center tex-blue-400 font-medium bg-slate-800 rounded-lg border border-slate-700 animate-pulse">
              Loading products from External API...
            </div>
          )}

          {/* 2. Error State */}
          {error && (
            <div className="p-6 text-center text-red-400 font-medium bg-red-950/40 rounded-lg border border-red-800">
              ❌ Failed to load products: {error}
            </div>
          )}

          {/* 3. Success State (Rendered Grid) */}
          {!loading && !error && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {products.map((product) => (
                <div
                  key={product.id}
                  className="bg-slate-800 border border-slate-700 rounded-lg p-5 flex flex-col justify-between shadow-md hover:border-slate-500 transition-all"
                >
                  <div>
                    <div className="h-40 w-full bg-slate-900 rounded-md mb-4 flex items-center justify-center p-2">
                      <img  
                        src={product.image}
                        alt={product.title}
                        className="max-h-full object-contain"
                      />
                    </div>
                    <span className="text-xs upercase font-bold text-blue-400 tracking-wider">
                      {product.category}
                    </span>
                    <h4 className="text-lg font-medium text-slate-100 mt-1 line-clamp-2">
                      {product.title}
                    </h4>
                  </div>
                  <div className="mt-4 pt-3 border-t border-slate-700 flex justify-between items-center">
                    <span className="text-xl font-bold text-emerald-400">
                      {product.price.toFixed(2)}
                    </span>
                    <button className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded transition-colors">
                      View
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      </main>

      <Footer />
    </div>
  );
}
