"use client";

import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { ProductFilter } from "@/components/ProductFilter";


export default function HomePage() {
  return (
    <div className="min-h-screen flex flex-col bg-slate-900 text-white">
      <Header />

      <main className="flex-1 p-8 max-w-4xl mx-auto w-full">
        <h2 className="text-3xl font-bold mb-6">Day 10: Controlled Components & State</h2>

        {/* Render our interactive filter component */}
        {/* <ProductFilter /> */}
      </main>

      <Footer />
    </div>
  );
}
