"use client";

import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/Button";
import { Wrapper } from "@/components/Wrapper";

export default function HomePage() {
  const handleSave = () => alert("Changes saved successfully!");
  const handleDelete = () => alert("Item deleted!");

  return (
    <div className="min-h-screen flex flex-col bg-slate-900 text-white">
      <Header />

      <main className="flex-1 p-8 max-w-4xl mx-auto w-full">
        <h2 className="text-3xl font-bold mb-6">Day 9: Props & Component Composition</h2>

        {/* Using the Wrapper component to compose children inside */}
        <Wrapper title="Action Controls Container">
          <p className="text-slate-300 mb-4">
            This paragraph is passed dynamically into the <code className="text-emerald-400">Wrapper</code> component via the <code className="text-emerald-400">children</code> prop.
          </p>

          <div className="flex gap-4 flex-wrap">
            <Button label="Save Changes" onClick={handleSave} variant="primary" />
            <Button label="Cancel" onClick={() => alert("Cancelled")} variant="secondary" />
            <Button label="Delete Item" onClick={handleDelete} variant="danger" />
            <Button label="Disabled Button" onClick={() => {}} disabled={true} />
          </div>
        </Wrapper>
      </main>

      <Footer />
    </div>
  );
}
