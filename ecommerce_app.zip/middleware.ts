import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

export function middleware(request: NextRequest) {
    // Retrievee simulated auth cookie
    const authToken = request.cookies.get("auth_token")?.value;
    const {  pathname } = request.nextUrl;

    // Define protected routes
    const protectedRoutes = ["/checkout", "/account", "/admin"];
    const isPathProtected = protectedRoutes.some((route) => 
        pathname.startsWith(route)
    );

    // Handle Unouthorized Access
    if (isPathProtected && !authToken) {
        const loginUrl = new URL("/login", request.url);
        // Pass the original URL as a redirect parameter after logging in
        loginUrl.searchParams.set("callbackUrl", pathname);
        return NextResponse.redirect(loginUrl);
    }

    // If logged in, prevent visiting the login page again
    if (pathname === "/login" && authToken) {
        return NextResponse.redirect(new URL("/products", request.url));
    }

    // pass request through normally
    return NextResponse.next();
}

/**
 * Matcher configuration:
 * Restricts middleware execution to specific paths only (improves performance).
 */

export const config = {
    matcher: [
        "/:path*",
        "/checkout/:path*",
        "/account/:path*",
        "/admin/:path*",
        "/login",
    ],
};
