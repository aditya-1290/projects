"use client";

import React, { createContext, useContext, useState, ReactNode} from "react";
import { Product } from "@/app/products/page";

// Define Cart Item Structure (Product + Quantity)
export interface CartItem extends Product {
    quantity: number;
}

// Define Context Interface
interface CartContextType {
    cart: CartItem[];
    addToCart: (product: Product) => void;
    removeFromCart: (productId: number) => void;
    totalItems: number;
    totalPrice: number;
}

// Create context
const CartContext = createContext<CartContextType | undefined>(undefined);

// create provider component
export const CartProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [cart, setCart] = useState<CartItem[]>([]);

    // Add item to cart (increments quantity if already exists)
    const addToCart = (product: Product) => {
        setCart((prevCart) => {
            const existingIndex = prevCart.findIndex((item) => item.id === product.id);
            if (existingIndex > -1) {
                const updated = [...prevCart];
                updated[existingIndex].quantity += 1;
                return updated;
            }
            return [...prevCart, { ...product, quantity: 1 }];
        });
    };

    // Remove item from cart completely
    const removeFromCart = (productId: number) => {
        setCart((prevCart) => prevCart.filter((item) => item.id !== productId));
    };

    // Derived Values
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    const totalPrice = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

    return (
        <CartContext.Provider
            value={{ cart, addToCart, removeFromCart, totalItems, totalPrice }}
        >
            {children}
        </CartContext.Provider>
    );
};

// custom hook for consuming cartcontext safely
export const useCart = () => {
    const context = useContext(CartContext);
    if (!context) {
        throw new Error("useCart must be used within a CartProvider");
    }
    return context;
};
