"use client";

import React, { useState, useEffect, useRef } from "react";

export const ProductFilter: React.FC = () => {
    // Declare state variables with explicict string types
    const [searchQuery, setSearchQuery] = useState<string>("");
    const [category, setCategory] = useState<string>("all");

    // Generic useRef typed for HTMLInputElement
    const inputRef = useRef<HTMLInputElement>(null);

    // Auto-focus the input element on component mount
    useEffect(() => {
        // Optional chaining ensures we don't crash if current is null
        inputRef.current?.focus();
    }, []);

    // Explicitly type event parameters for inputs and selects
    const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setSearchQuery(e.target.value);

    };

    const handleCategoryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        setCategory(e.target.value);
    };
    
    return (
        <div className="bg-slate-800 border-slate-700 rounded-lg p-6 my-4 shadow-md">
            <h3 className="text-xl font-semibold mb-4 text-slate-100 border-b corder-slate-700 pb-2">
                Product Filter
            </h3>

            <div className="flex flex-col md: flex-row gap-4">
                {/* Search Input Field with Ref Attached */}
                <div className="flex-1">
                    <label className="block text-sm font-medium text-slate-300 mb-1">
                        Search Products <span className="text-xs text-blue-400">(Auto-Focused via useRef)</span>
                    </label>
                    <input
                        ref={inputRef} // Attaching DOM reference
                        type="text"
                        placeholder="Search by title..."
                        value={searchQuery}
                        onChange={handleSearchChange}
                        className="w-full bg-slate-900 border border-slate-700 rounded-md px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                </div>

                {/* Category Dropdown */}
                <div className="w-full md: w-48">
                    <label className="block text-sm font-medium text-slate-300 mb-1">
                        Category
                    </label>
                    <select 
                        value={category}
                        onChange={handleCategoryChange}
                        className="w-full bg-slate-900 border border-slate-700 rounded-md px-3 py-2 text-white focus:outline-none focus:ring-blue-500"
                        >
                            <option value="all">All Categories</option>
                            <option value="electronics">Electronics</option>  
                            <option value="clothing">Clothing</option>
                            <option value="jewelery">Jewelery</option>
                    </select>
                </div>
            </div>

            {/* Live State Debug Output */}
            <div className="mt-4 p-3 bg-slate-900/50 rounded border border-slate-700/50 text-sm text-slate-400">
                <p><strong>Live State Monitor</strong></p>
                <p>Search Query: <span className="text-emarald-400">{searchQuery || "(empty)"}</span></p>
                <p>Category: <span className="text-emarald-400">{category}</span></p>
            </div>
        </div>
    );
};
