"use client";

import React from "react";
import { Product } from "@/app/products/page";

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
}

// React.memo prevents re-renders if product and onAddToCart props stay identical
export const ProductCard = React.memo<ProductCardProps>(({ product, onAddToCart }) => {
  return (
    <div className="bg-slate-800 border border-slate-700 rounded-lg p-5 flex flex-col justify-between shadow-md hover:border-slate-600 transition-all">
      <div>
        <div className="h-40 w-full bg-slate-900 rounded-md mb-4 flex items-center justify-center p-2">
          <img
            src={product.image}
            alt={product.title}
            className="max-h-full object-contain"
          />
        </div>
        <span className="text-xs uppercase font-bold text-blue-400 tracking-wider">
          {product.category}
        </span>
        <h4 className="text-lg font-medium text-slate-100 mt-1 line-clamp-2">
          {product.title}
        </h4>
      </div>

      <div className="mt-4 pt-3 border-t border-slate-700 flex justify-between items-center gap-2">
        <span className="text-xl font-bold text-emerald-400">
          ${product.price.toFixed(2)}
        </span>
        <button
          onClick={() => onAddToCart(product)}
          className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white text-sm font-medium rounded transition-all cursor-pointer"
        >
          + Add to Cart
        </button>
      </div>
    </div>
  );
});

ProductCard.displayName = "ProductCard";
