"use client";

import Link from "next/link";
import { useCart } from "@/context/CartContext";

export default function Navbar() {
    const { totalItems } = useCart();

    return (
        <nav className="bg-slate-950 norder-b border-slate-800 px-6 py-4 flex justify-between items-center text-white">
            <Link href="/" className="text-xl font-bold text-blue-400 hover:text-blue-300 transition-colors">
                TechStore
            </Link>

            <div className="space-x-6">
                <Link href="/" className="hover:text-blue-400 transition-colors">
                    Home
                </Link>
                <Link href="/products" className="hover:text-blue-400 transition-colors">
                    Products
                </Link>
                <Link href="/about" className="hover:text-blue-400 transition-colors">
                    About
                </Link>

                {/* CLICKABLE Cart Indicator Link */}
                <Link
                    href="/cart"
                    className="relative bg-slate-800 border border-slate-700 hover:border-slate-500 px-3 py-1.5 rounded-full flex items-center gap-2 transition-all cursor-pointer"
                    >
                    <span className="text-sm font-medium">🛒 Cart</span>
                    <span className="bg-blue-600 text-white text-xs font-bold px-2 py-0.5 rounded-full">
                        {totalItems}
                    </span>
                </Link>
            </div>
        </nav>
    );
}
