"use client";

import React, { act, useReducer } from "react";

// Define State Interface
export interface FilterState {
    searchQuery: string;
    category: string;
    sortBy: "price-asc" | "price-desc";
}

// Define Action Types using TypeScript Discriminated Unions
export type FilterAction =
    | { type: "SET_SEARCH"; payload: string }
    | { type: "SET_CATEGORY"; payload: string }
    | { type: "SET_SORT"; payload: "price-asc" | "price-desc" }
    | { type: "RESET_FILTERS" };

// Initial State Constant 
const initialState : FilterState = {
    searchQuery: "",
    category: "all",
    sortBy: "price-asc",
}

// Pure Reducer Function
function filterReducer(state: FilterState, action: FilterAction): FilterState {
    switch (action.type) {
        case "SET_SEARCH":
            return { ...state, searchQuery: action.payload };
        case "SET_CATEGORY":
            return { ...state, category: action.payload };
        case "SET_SORT":
            return { ...state, sortBy: action.payload };
        case "RESET_FILTERS":
            return initialState;
        default:
            return state;
    }
}

export const ProductFilter: React.FC = () => {
    // setup suereducer
    const [state, dispatch] = useReducer(filterReducer, initialState);
    
    return (
        <div className="bg-slate-800 border-slate-700 rounded-lg p-6 my-4 shadow-md">
            <h3 className="text-xl font-semibold mb-4 text-slate-100 border-b corder-slate-700 pb-2">
                Product Filter (Managed via <code className="text-blue-400">useReducer</code>)
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Search Input */}
                <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">
                        Search
                    </label>
                    <input 
                        type="text"
                        value={state.searchQuery}
                        onChange={(e) =>
                            dispatch({ type: "SET_SEARCH", payload: e.target.value })
                        }
                        placeholder="Search Products..."
                        className="w-full bg-slate-900 border border-slate-700 rounded-md px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:ring-blue-500"
                    />
                </div>
                
                {/* Category Selection */}
                <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">
                        Category
                    </label>
                    <select
                        value={state.category}
                        onChange={(e) =>
                            dispatch({ type: "SET_CATEGORY", payload: e.target.value })
                        }
                        className="w-full bg-slate-900 border border-slate-700 rounded-md px-3 py-2 text-white focus:outline-none focus:ring-blue-500"
                    >
                        <option value="all">All Categories</option>
                        <option value="electronics">Electronics</option>
                        <option value="jewelery">Jewelery</option>
                        <option value="women's clothing">Women's Clothing</option>
                    </select>
                </div>

                {/* Sort Order Selection */}
                <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">
                        Sort Price
                    </label>
                    <select
                        value={state.sortBy}
                        onChange={(e) =>
                            dispatch({
                                type: "SET_SORT",
                                payload: e.target.value as "price-asc" | "price-desc",
                            })
                        }
                        className="w-full bg-slate-900 border border-slate-700 rounded-md px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                        >
                            <option value="price-asc">Price: Low to High</option>
                            <option value="price-desc">Price: High to Low</option>
                    </select>
                </div>
            </div>

            {/* Action Controls & Debug Output */}
            <div className="mt-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 border-t border-slate-700/60 pt-3 text-sm">
                <div className="text-slate-400">
                    State Output: <code className="text-emarald-400">{JSON.stringify(state)}</code>
                </div>
                <button
                    onClick={() => dispatch({ type: "RESET_FILTERS" })}
                    className="px-3 py-1 bg-slate-700 hover:bg-slate-600 text-slate-200 text-sm rounded transition-colors"
                >
                    Reset All Filters
                </button>
            </div>
        </div>
    );
};
