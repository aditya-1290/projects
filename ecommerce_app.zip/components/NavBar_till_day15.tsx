import Link from "next/link";

export default function Navbar() {
    return (
        <nav className="bg-slate-950 norder-b border-slate-800 px-6 py-4 flex justify-between items-center text-white">
            <Link href="/" className="text-xl font-bold text-blue-400 hover:text-blue-300 transition-colors">
                TechStore
            </Link>

            <div className="space-x-6">
                <Link href="/" className="hover:text-blue-400 transition-colors">
                    Home
                </Link>
                <Link href="/products" className="hover:text-blue-400 transition-colors">
                    Products
                </Link>
                <Link href="/about" className="hover:text-blue-400 transition-colors">
                    About
                </Link>
            </div>
        </nav>
    );
}
