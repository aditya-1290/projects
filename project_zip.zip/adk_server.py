"""
ADK Server — FastAPI server exposing the Log Analysis Multi-Agent System
as Google ADK-compatible endpoints.

Usage:
    python adk_server.py
    python adk_server.py --port 8080 --host 0.0.0.0

Endpoints:
    POST /run          — Run a query and get the full response
    POST /run_stream   — Run a query and stream the response
    GET  /agents       — List all registered agents with their ADK cards
    GET  /tools        — List all available tools
    GET  /health       — Health check
"""

import asyncio
import sys
import os
import argparse
from pathlib import Path
from datetime import datetime
import json

from agents.base_agent import A2AMessage, MessageType

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from fastapi import FastAPI, HTTPException
from fastapi.responses import StreamingResponse, JSONResponse
from pydantic import BaseModel, Field
from typing import Optional, Dict, Any, List
import uvicorn


# ═══════════════════════════════════════════════════════════════════════════════
# Request / Response Models
# ═══════════════════════════════════════════════════════════════════════════════

class RunRequest(BaseModel):
    query: str = Field(..., description="Log entries, file path, or question to analyze")
    session_id: Optional[str] = Field(None, description="Session ID for multi-turn conversations")


class RunResponse(BaseModel):
    response: str = Field(..., description="Analysis results")
    session_id: str = Field(..., description="Session ID for follow-up queries")
    pipeline_stages: List[str] = Field(default_factory=list, description="Stages completed")
    confidence: float = Field(0.0, description="Overall confidence 0.0-1.0")
    agent_used: str = Field("orchestrator", description="Primary agent that handled the query")
    timestamp: str = Field(default_factory=lambda: datetime.utcnow().isoformat())


class AgentCardResponse(BaseModel):
    name: str
    description: str
    capabilities: List[str]
    tools: List[Dict]
    model_requirements: List[str]


class HealthResponse(BaseModel):
    status: str = "healthy"
    agents_loaded: int = 0
    models_loaded: int = 0
    uptime_seconds: float = 0.0


# ═══════════════════════════════════════════════════════════════════════════════
# FastAPI Application
# ═══════════════════════════════════════════════════════════════════════════════

app = FastAPI(
    title="Log Analysis Multi-Agent System",
    description="ADK-compatible API for log analysis with specialized agents",
    version="2.0.0"
)

# Global references (set during startup)
orchestrator = None
model_manager = None
communication_bus = None
startup_time = None


# ═══════════════════════════════════════════════════════════════════════════════
# Startup
# ═══════════════════════════════════════════════════════════════════════════════

@app.on_event("startup")
async def startup():
    """Initialize the multi-agent system."""
    global orchestrator, model_manager, communication_bus, startup_time

    from config import MAX_MEMORY_GB
    from models.manager import ModelManager
    from agentos.communication_bus import CommunicationBus

    print("[ADK Server] Initializing...")

    # 1. Model Manager
    print("[ADK Server] Loading models...")
    model_manager = ModelManager(max_memory_gb=MAX_MEMORY_GB)
    await model_manager.initialize()

    # 2. Communication Bus
    print("[ADK Server] Starting communication bus...")
    communication_bus = CommunicationBus()

    # 3. Load all agents
    print("[ADK Server] Loading agents...")
    from main import SystemBootstrap
    agents, orchestrator = await SystemBootstrap.create_all_agents(
        model_manager, communication_bus
    )

    await communication_bus.start()

    if orchestrator:
        await orchestrator.initialize()

    startup_time = datetime.utcnow()

    print(f"[ADK Server] Ready — {len(agents)} agents loaded")
    print(f"[ADK Server] Endpoints: /run, /run_stream, /agents, /tools, /health")


@app.on_event("shutdown")
async def shutdown():
    """Shutdown the system."""
    global communication_bus
    if communication_bus:
        await communication_bus.stop()
    print("[ADK Server] Shutdown complete")

# ═══════════════════════════════════════════════════════════════════════════════
# Agent Helper
# ═══════════════════════════════════════════════════════════════════════════════

def _get_agent(agent_type: str):
    """Get a specific agent by type from the communication bus."""
    global communication_bus
    if not communication_bus:
        return None
    for agent_id, agent in communication_bus.agents.items():
        if agent.capability.agent_name == agent_type:
            return agent
    return None

# ═══════════════════════════════════════════════════════════════════════════════
# Endpoints
# ═══════════════════════════════════════════════════════════════════════════════

@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint."""
    global orchestrator, model_manager, communication_bus, startup_time

    if not orchestrator:
        raise HTTPException(status_code=503, detail="System not initialized")

    model_status = model_manager.get_status() if model_manager else {}
    bus_status = await communication_bus.get_status() if communication_bus else {}

    uptime = (datetime.utcnow() - startup_time).total_seconds() if startup_time else 0

    return HealthResponse(
        status="healthy",
        agents_loaded=bus_status.get("registered_agents", 0),
        models_loaded=model_status.get("total_loads", 0),
        uptime_seconds=uptime
    )


@app.get("/agents", response_model=List[AgentCardResponse])
async def list_agents():
    """List all registered agents with their ADK cards."""
    global communication_bus

    if not communication_bus:
        raise HTTPException(status_code=503, detail="Communication bus not initialized")

    bus_status = await communication_bus.get_status()
    agents = []

    for agent_info in bus_status.get("agents", []):
        agent_id = agent_info.get("id")
        agent = communication_bus.agents.get(agent_id)

        if agent:
            card = agent.adk_card
            agents.append(AgentCardResponse(
                name=card.name,
                description=card.description,
                capabilities=card.capabilities,
                tools=card.tools,
                model_requirements=card.model_requirements
            ))

    return agents


@app.get("/tools")
async def list_tools():
    """List all available tools across all agents."""
    global communication_bus

    if not communication_bus:
        raise HTTPException(status_code=503, detail="Communication bus not initialized")

    all_tools = []

    for agent_id, agent in communication_bus.agents.items():
        card = agent.adk_card
        for tool in card.tools:
            tool["provided_by"] = card.name
            all_tools.append(tool)

    return {"tools": all_tools, "count": len(all_tools)}


@app.post("/run", response_model=RunResponse)
async def run_query(request: RunRequest):
    """
    Run a log analysis query and return the full response.

    Accepts:
    - Pasted log entries
    - File paths (e.g., "logs/error.log")
    - Terminal commands (e.g., "command:dir")
    - Image paths (e.g., "screenshots/error.png")
    - Questions about errors
    """
    global orchestrator

    if not orchestrator:
        raise HTTPException(status_code=503, detail="Orchestrator not initialized")

    try:
        response = await orchestrator.handle_user_query(request.query)

        # Extract confidence from the orchestrator's last execution
        confidence = 0.8  # Default
        pipeline_stages = ["extract", "preprocess", "analyze", "solve", "validate"]

        if orchestrator.execution_history:
            last = orchestrator.execution_history[-1]
            if isinstance(last, dict):
                confidence = last.get("confidence", 0.8)

        return RunResponse(
            response=response,
            session_id=request.session_id or "default",
            pipeline_stages=pipeline_stages,
            confidence=confidence
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Analysis failed: {str(e)}")


@app.post("/run_stream")
async def run_query_stream(request: RunRequest):
    """
    Run a log analysis query and stream the response as it's generated.

    This uses Server-Sent Events (SSE) for real-time streaming.
    """
    global orchestrator

    if not orchestrator:
        raise HTTPException(status_code=503, detail="Orchestrator not initialized")

    async def generate():
        """Stream the response."""
        try:
            # Send start event
            yield f"data: {json.dumps({'type': 'start', 'query': request.query[:100]})}\n\n"

            # Run the analysis
            response = await orchestrator.handle_user_query(request.query)

            # Stream the response in chunks
            chunks = response.split('\n')
            for chunk in chunks:
                if chunk.strip():
                    yield f"data: {json.dumps({'type': 'content', 'text': chunk})}\n\n"
                    await asyncio.sleep(0.1)  # Small delay for streaming effect

            # Send end event
            yield f"data: {json.dumps({'type': 'end', 'status': 'complete'})}\n\n"

        except Exception as e:
            yield f"data: {json.dumps({'type': 'error', 'message': str(e)})}\n\n"

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no"
        }
    )

@app.post("/agent/extractor")
async def extractor_endpoint(request: dict):
    """Extract logs from files, images, terminal, or text."""
    agent = _get_agent("extractor")
    msg = A2AMessage(
        message_type=MessageType.REQUEST,
        sender_id="adk_server",
        sender_type="external",
        target_id=agent.agent_id,
        task={"action": "extract", **request},
    )
    response = await agent.process(msg)
    return {"response": json.dumps(response.response, default=str)}


@app.post("/agent/preprocessor")
async def preprocessor_endpoint(request: dict):
    """Clean and structure raw logs."""
    agent = _get_agent("preprocessor")
    msg = A2AMessage(
        message_type=MessageType.REQUEST,
        sender_id="adk_server",
        sender_type="external",
        target_id=agent.agent_id,
        task={"action": "preprocess", **request},
    )
    response = await agent.process(msg)
    return {"response": json.dumps(response.response, default=str)}


@app.post("/agent/analyzer")
async def analyzer_endpoint(request: dict):
    """Classify logs, detect intent, assess severity."""
    agent = _get_agent("analyzer")
    msg = A2AMessage(
        message_type=MessageType.REQUEST,
        sender_id="adk_server",
        sender_type="external",
        target_id=agent.agent_id,
        task={"action": "analyze", **request},
    )
    response = await agent.process(msg)
    return {"response": json.dumps(response.response, default=str)}


@app.post("/agent/solver")
async def solver_endpoint(request: dict):
    """Root cause analysis and fix generation."""
    agent = _get_agent("solver")
    msg = A2AMessage(
        message_type=MessageType.REQUEST,
        sender_id="adk_server",
        sender_type="external",
        target_id=agent.agent_id,
        task={"action": "solve", **request},
    )
    response = await agent.process(msg)
    return {"response": json.dumps(response.response, default=str)}


@app.post("/agent/debugger")
async def debugger_endpoint(request: dict):
    """Parse stack traces and generate patches."""
    agent = _get_agent("debugger")
    msg = A2AMessage(
        message_type=MessageType.REQUEST,
        sender_id="adk_server",
        sender_type="external",
        target_id=agent.agent_id,
        task={"action": "debug", **request},
    )
    response = await agent.process(msg)
    return {"response": json.dumps(response.response, default=str)}


@app.post("/agent/critic")
async def critic_endpoint(request: dict):
    """Validate solution quality."""
    agent = _get_agent("critic")
    msg = A2AMessage(
        message_type=MessageType.REQUEST,
        sender_id="adk_server",
        sender_type="external",
        target_id=agent.agent_id,
        task={"action": "validate", **request},
    )
    response = await agent.process(msg)
    return {"response": json.dumps(response.response, default=str)}


@app.post("/agent/memory")
async def memory_endpoint(request: dict):
    """Search and store past analyses."""
    agent = _get_agent("memory")
    msg = A2AMessage(
        message_type=MessageType.REQUEST,
        sender_id="adk_server",
        sender_type="external",
        target_id=agent.agent_id,
        task={"action": request.get("action", "retrieve"), **request},
    )
    response = await agent.process(msg)
    return {"response": json.dumps(response.response, default=str)}

# ═══════════════════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="ADK Server for Log Analysis Multi-Agent System")
    parser.add_argument("--host", default="127.0.0.1", help="Host to bind to")
    parser.add_argument("--port", type=int, default=8000, help="Port to listen on")
    parser.add_argument("--reload", action="store_true", help="Enable auto-reload")

    args = parser.parse_args()

    print(f"""
╔══════════════════════════════════════════════════════════════╗
║     LOG ANALYSIS MULTI-AGENT SYSTEM — ADK Server            ║
╚══════════════════════════════════════════════════════════════╝

Starting server at http://{args.host}:{args.port}

Endpoints:
  GET  /health      — Health check
  GET  /agents      — List registered agents
  GET  /tools       — List available tools
  POST /run         — Run analysis
  POST /run_stream  — Stream analysis results

Docs: http://{args.host}:{args.port}/docs
""")

    uvicorn.run(
        "adk_server:app",
        host=args.host,
        port=args.port,
        reload=args.reload
    )
