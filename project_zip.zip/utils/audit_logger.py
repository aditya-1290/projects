"""
Audit Logger — Structured JSON logging for the multi-agent system.

Logs every agent interaction, pipeline stage, and message passing through
the communication bus as structured JSON events in daily rotating files.

Usage:
    from utils.audit_logger import AuditLogger

    logger = AuditLogger("memory_store/audit")
    logger.log_event({
        "event_type": "pipeline_stage_complete",
        "agent": "extractor",
        "confidence": 0.97
    })
"""

import os
import json
import uuid
import asyncio
import threading
from datetime import datetime
from typing import Dict, Any, Optional


class AuditLogger:
    """
    Thread-safe structured JSON event logger with daily file rotation.

    Features:
    - Async-safe: uses a lock for concurrent writes
    - Daily rotation: new file per day in memory_store/audit/
    - Minimal overhead: appends single JSON line per event
    - Queryable: each file is valid JSON Lines format
    """

    def __init__(self, audit_dir: str = "memory_store/audit"):
        self.audit_dir = os.path.abspath(audit_dir)
        self._lock = threading.Lock()
        self._current_date: Optional[str] = None
        self._file_path: Optional[str] = None

        # Ensure audit directory exists
        os.makedirs(self.audit_dir, exist_ok=True)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def log_event(self, event: Dict[str, Any]):
        """
        Log a structured event to the daily audit file.

        Args:
            event: Dictionary with event data. Should include:
                - event_type: str (message_sent, pipeline_stage, error, etc.)
                - timestamp: ISO format (auto-generated if missing)
                - event_id: uuid (auto-generated if missing)
        """
        # Auto-generate fields if missing
        if "event_id" not in event:
            event["event_id"] = str(uuid.uuid4())
        if "timestamp" not in event:
            event["timestamp"] = datetime.utcnow().isoformat() + "Z"

        # Ensure daily rotation
        today = datetime.utcnow().strftime("%Y-%m-%d")
        if today != self._current_date:
            self._rotate(today)

        # Write event as single JSON line
        with self._lock:
            try:
                with open(self._file_path, "a", encoding="utf-8") as f:
                    f.write(json.dumps(event, ensure_ascii=False) + "\n")
            except Exception as e:
                print(f"[AUDIT] Failed to write event: {e}")

    def log_message(
            self,
            message_type: str,
            sender_id: str,
            sender_type: str,
            receiver_id: Optional[str],
            receiver_type: Optional[str],
            message_id: str,
            correlation_id: Optional[str],
            confidence: float,
            task_action: Optional[str] = None,
            error_message: Optional[str] = None,
            response_summary: Optional[Dict] = None,
            query_id: Optional[str] = None,
            pipeline_stage: Optional[str] = None,
            ttl: int = 10,
    ):
        """
        Convenience method for logging a message passing through the bus.

        Args:
            message_type: REQUEST, RESPONSE, ERROR
            sender_id: Agent ID of sender
            sender_type: Agent type of sender
            receiver_id: Agent ID of receiver (or None for broadcast)
            receiver_type: Agent type of receiver (or ALL for broadcast)
            message_id: Unique message ID
            correlation_id: Correlation ID linking request-response pairs
            confidence: Confidence score (0.0-1.0)
            task_action: Action being requested (extract, preprocess, etc.)
            error_message: Error message if message_type is ERROR
            response_summary: Brief summary of response data
            query_id: Parent query session ID
            pipeline_stage: Current pipeline stage name
            ttl: Time-to-live remaining
        """
        event = {
            "event_type": f"message_{message_type.lower()}",
            "sender": {
                "agent_id": sender_id,
                "agent_type": sender_type,
            },
            "receiver": {
                "agent_id": receiver_id or "broadcast",
                "agent_type": receiver_type or "ALL",
            },
            "message": {
                "message_id": message_id,
                "correlation_id": correlation_id,
                "message_type": message_type,
                "task_action": task_action,
                "confidence": confidence,
                "error": error_message,
                "response_summary": response_summary,
                "ttl_remaining": ttl,
            },
        }

        if query_id:
            event["pipeline_context"] = {
                "query_id": query_id,
                "pipeline_stage": pipeline_stage,
            }

        self.log_event(event)

    def log_pipeline_stage(
            self,
            stage: str,
            status: str,
            agent_type: str,
            confidence: float,
            duration_ms: Optional[float] = None,
            query_id: Optional[str] = None,
            query_preview: Optional[str] = None,
            input_type: Optional[str] = None,
            stage_number: Optional[str] = None,
            retry_attempt: int = 0,
            error: Optional[str] = None,
            summary: Optional[Dict] = None,
    ):
        """
        Convenience method for logging a pipeline stage completion.

        Args:
            stage: Stage name (extract, preprocess, analyze, solve, validate)
            status: completed, completed_with_error, skipped, failed
            agent_type: Type of agent that executed the stage
            confidence: Confidence score from the agent
            duration_ms: Time taken in milliseconds
            query_id: Parent query session ID
            query_preview: First 80 chars of user query
            input_type: Detected input type (file, pasted_log, terminal, image)
            stage_number: "1/5", "2/5", etc.
            retry_attempt: 0 for first attempt, 1+ for retries
            error: Error message if status is not completed
            summary: Brief summary dict of stage output
        """
        event = {
            "event_type": f"pipeline_stage_{status}",
            "pipeline_stage": stage,
            "stage_number": stage_number,
            "status": status,
            "agent_type": agent_type,
            "confidence": confidence,
            "retry_attempt": retry_attempt,
            "error": error,
            "summary": summary,
        }

        if duration_ms is not None:
            event["performance"] = {"duration_ms": round(duration_ms, 2)}

        if query_id:
            event["pipeline_context"] = {
                "query_id": query_id,
                "query_preview": query_preview[:80] if query_preview else None,
                "input_type": input_type,
            }

        self.log_event(event)

    def log_query_start(
            self,
            query_id: str,
            query_text: str,
            input_type: str,
            input_format: str,
            detection_layer: int,
            detection_confidence: str,
            chars: int,
            lines: int,
    ):
        """
        Log the start of a new user query session.

        Args:
            query_id: Unique session ID for this query
            query_text: First 200 chars of user input
            input_type: Detected input type
            input_format: Detected log format
            detection_layer: Which detection layer (1, 2, or 3)
            detection_confidence: high, medium, low
            chars: Character count
            lines: Line count
        """
        self.log_event({
            "event_type": "query_start",
            "pipeline_context": {
                "query_id": query_id,
                "query_preview": query_text[:200],
                "input_type": input_type,
                "input_format": input_format,
                "detection_layer": detection_layer,
                "detection_confidence": detection_confidence,
                "chars": chars,
                "lines": lines,
            },
        })

    def log_query_end(
            self,
            query_id: str,
            total_duration_ms: float,
            pipeline_completed: bool,
            final_confidence: Optional[float] = None,
            error: Optional[str] = None,
    ):
        """
        Log the end of a query session.

        Args:
            query_id: Unique session ID
            total_duration_ms: Total time from query start to response
            pipeline_completed: Whether all stages completed
            final_confidence: Overall confidence score
            error: Error message if pipeline failed
        """
        self.log_event({
            "event_type": "query_end",
            "pipeline_context": {"query_id": query_id},
            "performance": {"total_duration_ms": round(total_duration_ms, 2)},
            "pipeline_completed": pipeline_completed,
            "final_confidence": final_confidence,
            "error": error,
        })

    def log_error(
            self,
            error_type: str,
            error_message: str,
            agent_type: Optional[str] = None,
            query_id: Optional[str] = None,
            context: Optional[Dict] = None,
    ):
        """
        Log a system error or exception.

        Args:
            error_type: Category of error
            error_message: Error description
            agent_type: Which agent encountered the error
            query_id: Related query session
            context: Additional context dict
        """
        self.log_event({
            "event_type": "system_error",
            "error": {
                "type": error_type,
                "message": error_message,
            },
            "agent_type": agent_type,
            "pipeline_context": {"query_id": query_id} if query_id else None,
            "context": context,
        })

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _rotate(self, today: str):
        """Rotate to a new daily log file."""
        self._current_date = today
        self._file_path = os.path.join(
            self.audit_dir,
            f"pipeline_{today}.json"
        )

        # Create file with header if it doesn't exist
        if not os.path.exists(self._file_path):
            with open(self._file_path, "w", encoding="utf-8") as f:
                f.write(
                    json.dumps({
                        "audit_log_start": today,
                        "created_at": datetime.utcnow().isoformat() + "Z",
                        "format": "json_lines",
                        "description": "One JSON object per line. Each line is a complete event."
                    }) + "\n"
                )

    def get_stats(self) -> Dict:
        """Get audit logger statistics."""
        total_size = 0
        file_count = 0
        if os.path.exists(self.audit_dir):
            for f in os.listdir(self.audit_dir):
                if f.endswith(".json"):
                    total_size += os.path.getsize(os.path.join(self.audit_dir, f))
                    file_count += 1

        return {
            "audit_dir": self.audit_dir,
            "current_file": self._file_path,
            "total_files": file_count,
            "total_size_bytes": total_size,
            "total_size_mb": round(total_size / (1024 * 1024), 2),
        }


# ═══════════════════════════════════════════════════════════════════════════════
# Singleton
# ═══════════════════════════════════════════════════════════════════════════════

_audit_logger: Optional[AuditLogger] = None


def get_audit_logger(audit_dir: str = "memory_store/audit") -> AuditLogger:
    """Get or create the global audit logger instance."""
    global _audit_logger
    if _audit_logger is None:
        _audit_logger = AuditLogger(audit_dir)
    return _audit_logger
