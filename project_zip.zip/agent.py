"""ADK Entry Point."""\nfrom agents.adk.root_agent import root_agent
