"""
Extractor Agent - Multi-source log extraction.

Handles:
  - Pasted raw text  (syslog, Apache, JSON, CSV, XML, plain)
  - Text files       (.log, .txt, .json, .csv, .xml, .jsonl, .gz, …)
  - Image files      (.png, .jpg, .jpeg, .bmp, .tiff) via OCR
  - Terminal output  (runs a shell command and captures stdout/stderr)

The agent always returns a RESPONSE (never an ERROR) so downstream agents
can handle the "nothing extracted" case gracefully.
"""

import os
import re
import sys

# ── Make sure base_agent is importable regardless of how the project is run ──
_HERE = os.path.dirname(os.path.abspath(__file__))
_AGENTS_ROOT = os.path.dirname(_HERE)
if _AGENTS_ROOT not in sys.path:
    sys.path.insert(0, _AGENTS_ROOT)

from agents.base_agent import BaseAgent, A2AMessage, MessageType
from typing import Any, Dict, Optional, Tuple

# ── Internal imports (loaders / parsers live next to this file) ──────────────
from agents.extractor.loaders.file_loader     import FileLoader
from agents.extractor.loaders.image_loader    import ImageLoader
from agents.extractor.loaders.terminal_loader import TerminalLoader
from agents.extractor.loaders.es_loader import ElasticsearchLoader

from agents.extractor.parsers.json_parser        import JSONParser
from agents.extractor.parsers.csv_parser         import CSVParser
from agents.extractor.parsers.xml_parser         import XMLParser
from agents.extractor.parsers.syslog_parser      import SyslogParser
from agents.extractor.parsers.apache_log_parser  import ApacheLogParser
# from agents.extractor.prompts import (
#     FORMAT_DISAMBIGUATION_PROMPT,
#     CONTENT_REPAIR_PROMPT,
#     METADATA_EXTRACTION_PROMPT,
# )

# ── Supported image extensions ────────────────────────────────────────────────
_IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".tiff", ".tif", ".gif", ".webp"}

# ── Supported file extensions (text-based) ────────────────────────────────────
_FILE_EXTS = {
    ".log", ".txt", ".out", ".err",
    ".json", ".jsonl", ".ndjson",
    ".csv", ".tsv",
    ".xml",
    ".gz", ".bz2", ".xz",
    ".syslog", ".access", ".error",
}


class ExtractorAgent(BaseAgent):
    """
    Extracts raw log content from any supported source and (optionally)
    parses it into structured entries.

    Task fields recognised:
      source_type  : "auto" | "text" | "file" | "image" | "terminal"
      content      : raw pasted text  (for "text" and "auto" modes)
      raw_logs     : alias for content
      file_path    : absolute/relative path to a file or image
      command      : shell command to run (for "terminal" mode)
      parse        : bool — if True, also return parsed structured entries
                     (default False; parsing adds latency)

    Context fields also checked (lower priority than task):
      raw_logs, query, original_query
    """

    def __init__(self):
        super().__init__("extractor_v1", "agents/extractor/capabilities.json")
        self._file_loader     = FileLoader()
        self._image_loader    = ImageLoader()
        self._terminal_loader = TerminalLoader()
        self._es_loader = ElasticsearchLoader()

        # ═══════════════════════════════════════════════════════════════════════════
        # ADK Integration — Tool Registration
        # ═══════════════════════════════════════════════════════════════════════════

        def _get_model_requirements(self) -> list:
            """Extractor doesn't require an LLM for most operations.
            OCR mode uses DeepSeek, but most extractions are pure code."""
            return []

    def _resolve_adk_model(self) -> str:
        return "deepseek-ocr2"  # Only used for image extraction

    def _get_adk_tools(self) -> list:
        """Register file loading, terminal execution, and OCR as ADK tools."""
        return [
                {
                    "name": "extract_from_file",
                    "description": "Extract log content from a file on disk. Supports .log, .txt, .json, .csv, .xml, .gz, and more.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "file_path": {
                                "type": "string",
                                "description": "Absolute or relative path to the log file"
                            },
                            "parse": {
                                "type": "boolean",
                                "description": "Whether to parse into structured entries (JSON/CSV/XML)",
                                "default": False
                            }
                        },
                        "required": ["file_path"]
                    }
                },
                {
                    "name": "extract_from_terminal",
                    "description": "Execute a terminal command and capture its output safely. Dangerous commands are blocked.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "command": {
                                "type": "string",
                                "description": "Shell command to execute (e.g., 'dir', 'type file.log', 'cat /var/log/syslog')"
                            }
                        },
                        "required": ["command"]
                    }
                },
                {
                    "name": "extract_from_image",
                    "description": "Extract text from an image using OCR. Supports .png, .jpg, .jpeg, .bmp.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "image_path": {
                                "type": "string",
                                "description": "Path to the image file containing log text"
                            }
                        },
                        "required": ["image_path"]
                    }
                },
                {
                    "name": "extract_from_text",
                    "description": "Parse and structure pasted log text. Auto-detects format (Python traceback, JSON, syslog, Apache, plain text).",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "content": {
                                "type": "string",
                                "description": "Raw log content pasted by the user"
                            },
                            "parse": {
                                "type": "boolean",
                                "description": "Whether to parse into structured entries",
                                "default": False
                            }
                        },
                        "required": ["content"]
                    }
                },
                {
                    "name": "extract_from_elasticsearch",
                    "description": "Search Elasticsearch for log entries by index, query, and time range.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "index": {
                                "type": "string",
                                "description": "Elasticsearch index pattern (e.g., 'logs-*')",
                                "default": "logs-*"
                            },
                            "query_string": {
                                "type": "string",
                                "description": "Lucene query string (e.g., 'level:ERROR AND service:auth')"
                            },
                            "time_range_start": {
                                "type": "string",
                                "description": "Start time (ISO format or 'now-1h')",
                                "default": "now-1h"
                            },
                            "time_range_end": {
                                "type": "string",
                                "description": "End time (ISO format or 'now')",
                                "default": "now"
                            },
                            "size": {
                                "type": "integer",
                                "description": "Max results",
                                "default": 100
                            }
                        }
                    }
                }
            ]

    def _build_adk_instruction(self) -> str:
        """Build the extractor's ADK instruction from skill prompts."""
        return f"""You are the Extractor Agent for a log analysis system.

    Your job is to extract log content from any source:

    TOOLS AVAILABLE:
    - extract_from_file: Read log files from disk (.log, .txt, .json, .csv, .xml, .gz, etc.)
    - extract_from_terminal: Run shell commands and capture output (dangerous commands blocked)
    - extract_from_image: Extract text from screenshots using OCR
    - extract_from_text: Parse and structure pasted log entries

    EXTRACTION RULES:
    1. Always auto-detect the log format (Python traceback, JSON, CSV, XML, syslog, Apache, plain text)
    2. Return raw log text PLUS structured metadata (format, entry count, time range, severity counts)
    3. For images: pre-process with OCR cleanup (fix common OCR errors like l→1, O→0)
    4. For large files (>10MB): sample head + tail + error lines
    5. For mixed formats: split into sections by format
    6. Always validate that the content is actually log data (not source code or config files)

    FORMAT DETECTION:
    - "Traceback (most recent call last)" → python_traceback
    - "at com." or "at org." → java_stacktrace  
    - Lines starting with {{ → JSON/NDJSON
    - IP + [timestamp] + "METHOD /path" → apache_access
    - <digit> + timestamp → syslog_rfc5424

    Never invent log entries — only extract what's actually there.
    """

    # =========================================================================
    # Main entry point
    # =========================================================================

    async def process(self, message: A2AMessage) -> A2AMessage:
        task    = message.task    or {}
        context = message.context or {}

        self.log(f"Incoming task: {message.task}", "DEBUG")
        self.log("Reached extractor processing", "DEBUG")
        # ── 1. Gather inputs ──────────────────────────────────────────────────
        # Don't use context query as content when we have a file_path
        has_file_path = bool(task.get("file_path", "").strip())

        raw_content = (
                task.get("content")
                or task.get("raw_logs")
                or context.get("raw_logs")
                or ("" if has_file_path else context.get("query"))
                or ("" if has_file_path else context.get("original_query"))
                or message.task.get("content")
                or ""
        )

        # ALWAYS log what we received (not just DEBUG)
        self.log(
            f"Extract: task keys={list(task.keys())}, content_present={bool(task.get('content'))}, query_present={bool(context.get('query'))}",
            "INFO")
        self.log(f"raw_content length: {len(raw_content)}", "INFO")

        file_path   : str  = task.get("file_path", "").strip()
        command     : str  = task.get("command", "").strip()
        source_type : str  = task.get("source_type", "auto").lower()
        do_parse    : bool = bool(task.get("parse", False))

        # ── 2. Resolve source type ────────────────────────────────────────────
        if source_type == "auto":
            source_type = self._detect_source(file_path, command, raw_content)

        # ── 3. Extract raw text ───────────────────────────────────────────────
        raw_logs, warning = await self._extract(
            source_type, file_path, command, raw_content
        )

        # ── 4. Handle empty result ────────────────────────────────────────────
        if not raw_logs or not raw_logs.strip():
            self.log(f"Extraction failed: {warning or 'no usable content'}", "ERROR")

            # Return ERROR with the actual warning, not a generic message
            return A2AMessage(
                message_type=MessageType.ERROR,
                sender_id=self.agent_id,
                sender_type="extractor",
                target_id=message.sender_id,
                correlation_id=message.message_id,
                error=warning or "No content could be extracted",
                confidence=0.0,
            )

        # ── 5. Optionally parse into structured entries ───────────────────────
        parsed_result: Optional[Dict] = None
        if do_parse:
            parsed_result = await self._parse(raw_logs, file_path, source_type)

        return self._make_response(
            message=message,
            raw_logs=raw_logs,
            source_type=source_type,
            warning=warning,
            parsed=parsed_result,
            confidence=0.97 if not warning else 0.75,
        )

    # =========================================================================
    # Source detection
    # =========================================================================

    def _detect_source(self, file_path: str, command: str, content: str) -> str:
        """Infer source type from available inputs."""
        if command:
            return "terminal"
        if file_path:
            ext = os.path.splitext(file_path)[1].lower()
            if ext in _IMAGE_EXTS:
                return "image"
            if ext in _FILE_EXTS:
                return "file"
            # Unknown extension — check if path exists and is readable
            if os.path.isfile(file_path):
                return "file"
        if content and len(content.strip()) > 10:
            return "text"

        # Logging
        self.log(f"[DETECT] file_path={file_path}, content_len={len(content)}, command={command}", "INFO")

        return "text"

    # =========================================================================
    # Extraction dispatcher
    # =========================================================================

    async def _extract(
        self,
        source_type: str,
        file_path: str,
        command: str,
        raw_content: str,
    ) -> Tuple[str, Optional[str]]:
        """
        Extract raw text from the appropriate source.

        Returns (raw_logs, warning_message_or_None).
        Never raises — all exceptions are caught and surfaced as warnings.
        """
        warning: Optional[str] = None

        # ── Terminal ──────────────────────────────────────────────────────────
        if source_type == "terminal":
            if not command:
                return "", "source_type='terminal' but no command provided"
            try:
                text = await self._terminal_loader.capture(command)
                return text, None
            except Exception as exc:
                return "", f"Terminal capture failed: {exc}"

        # ── Image (OCR) ───────────────────────────────────────────────────────
        if source_type == "image":
            path = file_path or raw_content.strip()

            if not path:
                return "", "source_type='image' but no file_path provided"

            try:
                ocr_model = await self._get_ocr_model()
                text = await self._image_loader.extract(path, ocr_model=ocr_model)

                # 🔥 ADD THIS VALIDATION
                if not text or len(text.strip()) < 30:
                    return "", "OCR failed to extract meaningful text"

                return text, None

            except FileNotFoundError as exc:
                return "", str(exc)

            except ValueError as exc:
                return "", str(exc)

            except Exception as exc:
                return "", f"Image OCR failed: {exc}"

        # ── File ──────────────────────────────────────────────────────────────
        if source_type == "file":
            path = file_path or raw_content.strip()
            if not path:
                return "", "source_type='file' but no file_path provided"
            try:
                text = await self._file_loader.load(path)
                return text, None
            except FileNotFoundError as exc:
                return "", str(exc)
            except IsADirectoryError as exc:
                return "", str(exc)
            except ValueError as exc:
                return "", str(exc)
            except Exception as exc:
                return "", f"File read failed: {exc}"

        # ── Pasted / raw text (default) ───────────────────────────────────────
        if raw_content.strip():
            return raw_content.strip(), None

        # Logging
        self.log(f"[EXTRACT] source_type={source_type}", "INFO")

        # Nothing matched
        return "", "No content, file path, or command provided"

    # =========================================================================
    # Format detection & parsing
    # =========================================================================

    async def _parse(
        self,
        raw_logs: str,
        file_path: str,
        source_type: str,
    ) -> Optional[Dict[str, Any]]:
        """
        Auto-detect the log format and parse into structured entries.
        Returns None on failure (raw_logs is still returned to the caller).
        """
        fmt = self._detect_format(raw_logs, file_path)
        try:
            if fmt == "json":
                return await JSONParser().parse(raw_logs)
            if fmt == "csv":
                return await CSVParser().parse(raw_logs)
            if fmt == "xml":
                return await XMLParser().parse(raw_logs)
            if fmt == "apache_access":
                return await ApacheLogParser().parse(raw_logs)
            if fmt == "syslog":
                return await SyslogParser().parse(raw_logs)
            # Plain text / unknown — still return minimal structure
            lines = [l for l in raw_logs.splitlines() if l.strip()]
            return {
                "format":  "plain_text",
                "entries": [{"_line": i + 1, "_raw": l} for i, l in enumerate(lines)],
                "count":   len(lines),
                "errors":  [],
            }
        except Exception as exc:
            return {"format": fmt, "entries": [], "count": 0, "errors": [str(exc)]}

    def _detect_format(self, content: str, file_path: str) -> str:
        """
        Infer log format from file extension and/or content heuristics.
        Content heuristics are checked when the extension is absent/ambiguous.
        """
        # Extension-based detection (fast path)
        if file_path:
            ext = os.path.splitext(file_path)[1].lower()
            if ext in (".json", ".jsonl", ".ndjson"):
                return "json"
            if ext in (".csv", ".tsv"):
                return "csv"
            if ext == ".xml":
                return "xml"

        # Content heuristics
        sample = content[:2000].strip()

        if sample.startswith("{") or sample.startswith("["):
            return "json"

        if sample.startswith("<") and ">" in sample:
            return "xml"

        # Apache access: starts with an IP and contains [timestamp] METHOD
        if re.match(r'^\d{1,3}(?:\.\d{1,3}){3}\s', sample) and '"GET ' in sample or '"POST ' in sample:
            return "apache_access"

        # Apache error: starts with [weekday month
        if re.match(r'^\[(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun)\s', sample):
            return "apache_error"

        # Syslog with priority: <digits>
        if re.match(r'^<\d+>', sample):
            return "syslog"

        # BSD syslog: Jan 15 10:23:45 host tag:
        if re.match(r'^(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d', sample):
            return "syslog"

        # CSV: uniform delimiter presence across multiple lines
        lines = [l for l in content.splitlines()[:5] if l.strip()]
        if len(lines) >= 2:
            for delim in [",", "\t", "|", ";"]:
                counts = [l.count(delim) for l in lines]
                if min(counts) > 0 and max(counts) - min(counts) <= 2:
                    return "csv"

        # NDJSON: multiple lines each starting with {
        json_lines = [l.strip() for l in content.splitlines() if l.strip().startswith("{")]
        if len(json_lines) >= 2:
            return "json"

        return "plain_text"

    # =========================================================================
    # Response builder
    # =========================================================================

    def _make_response(
        self,
        message: A2AMessage,
        raw_logs: str,
        source_type: str,
        warning: Optional[str],
        parsed: Optional[Dict],
        confidence: float,
    ) -> A2AMessage:
        resp: Dict[str, Any] = {
            "raw_logs":    raw_logs,
            "source_type": source_type,
            "length":      len(raw_logs),
        }
        if warning:
            resp["warning"] = warning
        if parsed is not None:
            resp["parsed"] = parsed

        return A2AMessage(
            message_type=MessageType.RESPONSE,
            sender_id=self.agent_id,
            sender_type="extractor",
            target_id=message.sender_id,
            correlation_id=message.message_id,
            response=resp,
            confidence=confidence,
        )

    # =========================================================================
    # Helpers
    # =========================================================================

    async def _get_ocr_model(self):
        """Try to load the OCR model; return None if unavailable."""
        try:
            return await self.get_model("deepseek_ocr")
        except Exception:
            return None
