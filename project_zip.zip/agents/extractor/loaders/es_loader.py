"""
Elasticsearch Loader — Pulls logs directly from Elasticsearch clusters.

Supports:
  - Index pattern matching (e.g., "logs-*", "prod-2024-*")
  - Time range queries
  - Lucene query strings AND structured Query DSL
  - Field selection for relevant log fields
  - Automatic timestamp detection and sorting
  - Size limits with sampling for large result sets

Security:
  - Read-only (only _search endpoint, no writes)
  - Connection via environment variables or direct config
  - SSL/TLS support with certificate verification
"""

import os
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any


class ElasticsearchLoader:
    """
    Pulls log entries from an Elasticsearch cluster.

    Usage:
        loader = ElasticsearchLoader(hosts=["http://localhost:9200"])
        logs = await loader.search(
            index="logs-*",
            query={"match": {"level": "ERROR"}},
            time_range=("now-1h", "now"),
            size=100
        )
    """

    # Default fields to return from ES (avoids returning massive _source blobs)
    DEFAULT_FIELDS = [
        "@timestamp", "timestamp", "level", "severity", "message",
        "logger", "service", "host", "pod", "container",
        "trace_id", "span_id", "error", "exception", "stack_trace"
    ]

    def __init__(
            self,
            hosts: List[str] = None,
            cloud_id: str = None,
            api_key: str = None,
            username: str = None,
            password: str = None,
            verify_certs: bool = True,
            timeout: int = 30,
            max_size: int = 5000,
    ):
        """
        Initialize the Elasticsearch loader.

        Args:
            hosts: List of ES hosts (e.g., ["http://localhost:9200"])
                   Default: from ELASTICSEARCH_HOSTS env var or ["http://localhost:9200"]
            cloud_id: Elastic Cloud ID (overrides hosts)
            api_key: API key for authentication (from ELASTICSEARCH_API_KEY env var)
            username: Username for basic auth (from ELASTICSEARCH_USER env var)
            password: Password for basic auth (from ELASTICSEARCH_PASSWORD env var)
            verify_certs: Verify SSL certificates
            timeout: Request timeout in seconds
            max_size: Maximum number of log entries to return
        """
        self.hosts = hosts or self._env_list("ELASTICSEARCH_HOSTS", ["http://localhost:9200"])
        self.cloud_id = cloud_id or os.getenv("ELASTICSEARCH_CLOUD_ID")
        self.api_key = api_key or os.getenv("ELASTICSEARCH_API_KEY")
        self.username = username or os.getenv("ELASTICSEARCH_USER", "elastic")
        self.password = password or os.getenv("ELASTICSEARCH_PASSWORD")
        self.verify_certs = verify_certs
        self.timeout = timeout
        self.max_size = max_size
        self._client = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def search(
            self,
            index: str = "logs-*",
            query: Optional[Dict] = None,
            query_string: Optional[str] = None,
            time_range: Optional[tuple] = None,
            time_field: str = "@timestamp",
            fields: Optional[List[str]] = None,
            size: int = 100,
            sort: str = "desc",
    ) -> str:
        """
        Search Elasticsearch and return formatted log entries.

        Args:
            index: Index pattern (e.g., "logs-*", "prod-2024-01-*")
            query: Elasticsearch Query DSL dict (e.g., {"match": {"level": "ERROR"}})
            query_string: Lucene query string (e.g., "level:ERROR AND service:auth")
            time_range: (start, end) tuple. Use "now-1h" format or ISO timestamps.
            time_field: Timestamp field name
            fields: Fields to return (default: DEFAULT_FIELDS)
            size: Max results (capped at self.max_size)
            sort: Sort order ("asc" or "desc")

        Returns:
            Formatted log entries as a string, ready for preprocessing
        """
        if not self._client:
            self._client = self._create_client()

        # Build the ES search body
        body = self._build_search_body(
            query=query,
            query_string=query_string,
            time_range=time_range,
            time_field=time_field,
            fields=fields or self.DEFAULT_FIELDS,
            size=min(size, self.max_size),
            sort=sort,
        )

        try:
            from elasticsearch import AsyncElasticsearch

            if isinstance(self._client, AsyncElasticsearch):
                response = await self._client.search(
                    index=index,
                    body=body,
                    request_timeout=self.timeout
                )
            else:
                # Sync fallback
                response = self._client.search(
                    index=index,
                    body=body,
                    request_timeout=self.timeout
                )

            return self._format_response(response)

        except Exception as e:
            error_msg = str(e)
            if "index_not_found" in error_msg:
                raise ValueError(f"Elasticsearch index not found: {index}")
            elif "ConnectionError" in str(type(e).__name__):
                raise ConnectionError(
                    f"Cannot connect to Elasticsearch at {self.hosts}. "
                    "Check that ES is running and accessible."
                )
            raise RuntimeError(f"Elasticsearch search failed: {e}")

    async def list_indices(self, pattern: str = "*") -> List[str]:
        """List available indices matching a pattern."""
        if not self._client:
            self._client = self._create_client()

        try:
            response = self._client.cat.indices(
                index=pattern,
                format="json",
                h="index"
            )
            return [idx["index"] for idx in response]
        except Exception as e:
            raise RuntimeError(f"Failed to list indices: {e}")

    async def get_mapping(self, index: str) -> Dict:
        """Get field mappings for an index."""
        if not self._client:
            self._client = self._create_client()

        try:
            response = self._client.indices.get_mapping(index=index)
            return response.body if hasattr(response, 'body') else response
        except Exception as e:
            raise RuntimeError(f"Failed to get mapping: {e}")

    async def health_check(self) -> Dict:
        """Quick health check — returns cluster info."""
        if not self._client:
            self._client = self._create_client()

        try:
            health = self._client.cluster.health()
            return {
                "status": health.get("status", "unknown"),
                "nodes": health.get("number_of_nodes", 0),
                "indices": health.get("number_of_indices", 0),
            }
        except Exception as e:
            return {"status": "error", "error": str(e)}

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _create_client(self):
        """Create Elasticsearch client with appropriate auth."""
        try:
            from elasticsearch import Elasticsearch
        except ImportError:
            raise ImportError(
                "elasticsearch package is required. Install with: pip install elasticsearch"
            )

        if self.cloud_id:
            return Elasticsearch(
                cloud_id=self.cloud_id,
                api_key=self.api_key,
                verify_certs=self.verify_certs,
                request_timeout=self.timeout,
            )

        auth = None
        if self.username and self.password:
            auth = (self.username, self.password)

        return Elasticsearch(
            hosts=self.hosts,
            basic_auth=auth,
            api_key=self.api_key,
            verify_certs=self.verify_certs,
            request_timeout=self.timeout,
        )

    def _build_search_body(
            self,
            query: Optional[Dict],
            query_string: Optional[str],
            time_range: Optional[tuple],
            time_field: str,
            fields: List[str],
            size: int,
            sort: str,
    ) -> Dict:
        """Build the ES search request body."""
        must_clauses = []

        # Add structured query
        if query:
            must_clauses.append(query)

        # Add Lucene query string
        if query_string:
            must_clauses.append({
                "query_string": {
                    "query": query_string,
                    "default_operator": "AND"
                }
            })

        # Add time range
        if time_range:
            start, end = time_range
            must_clauses.append({
                "range": {
                    time_field: {
                        "gte": start,
                        "lte": end
                    }
                }
            })

        body = {
            "size": size,
            "sort": [
                {time_field: {"order": sort}}
            ],
            "_source": fields,
            "track_total_hits": min(size, 10000),  # Don't count beyond what we need
        }

        if must_clauses:
            body["query"] = {
                "bool": {
                    "must": must_clauses
                }
            }

        return body

    def _format_response(self, response) -> str:
        """Format ES response into a log string the pipeline can process."""
        hits = response.get("hits", {}).get("hits", [])
        total = response.get("hits", {}).get("total", {})
        total_count = total.get("value", 0) if isinstance(total, dict) else total

        if not hits:
            return (
                f"# Elasticsearch Query Results\n"
                f"# Total hits: 0\n"
                f"# No log entries found matching the query.\n"
            )

        lines = [
            f"# Elasticsearch Query Results",
            f"# Total hits: {total_count} (returned: {len(hits)})",
            f"# {'=' * 60}",
            ""
        ]

        for hit in hits:
            source = hit.get("_source", {})
            index = hit.get("_index", "")
            hit_id = hit.get("_id", "")

            # Try to format as a log line
            timestamp = source.get("@timestamp") or source.get("timestamp", "")
            level = source.get("level") or source.get("severity", "")
            message = source.get("message", "")
            service = source.get("service", "")

            if timestamp and level and message:
                # Structured log format
                line = f"{timestamp} [{level}] "
                if service:
                    line += f"[{service}] "
                line += message

                # Add error/exception if present
                error = source.get("error") or source.get("exception", "")
                stack = source.get("stack_trace", "")
                if error:
                    line += f"\n  Error: {error}"
                if stack:
                    line += f"\n  Stack: {stack[:500]}"
            else:
                # Fallback: dump the whole source as JSON
                line = json.dumps(source, default=str)

            lines.append(line)

        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Utility
    # ------------------------------------------------------------------

    @staticmethod
    def _env_list(env_var: str, default: List[str]) -> List[str]:
        """Parse a comma-separated env var into a list."""
        value = os.getenv(env_var)
        if not value:
            return default
        return [h.strip() for h in value.split(",") if h.strip()]

    def is_available(self) -> bool:
        """Check if Elasticsearch is configured and reachable."""
        try:
            if not self._client:
                self._client = self._create_client()
            return self._client.ping()
        except Exception:
            return False
