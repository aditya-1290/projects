"""
Analyzer Agent - Classifies logs and detects user intent
"""

from agents.base_agent import BaseAgent, A2AMessage, MessageType
from typing import Dict, Any
import json
import re


class AnalyzerAgent(BaseAgent):
    """Classifies log types and determines user intent"""

    def __init__(self):
        super().__init__("analyzer_v1", "agents/analyzer/capabilities.json")

    # ═══════════════════════════════════════════════════════════════════════════
    # ADK Integration — Tool Registration
    # ═══════════════════════════════════════════════════════════════════════════

    def _get_model_requirements(self) -> list:
        return ["gemma-4-e4b-it"]

    def _resolve_adk_model(self) -> str:
        return "gemma-4-e4b-it"

    def _get_adk_tools(self) -> list:
        """Register log classification and analysis as ADK tools."""
        return [
                {
                    "name": "classify_logs",
                    "description": "Classify log entries by type, detect user intent, assess severity, and identify patterns.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "clean_logs": {
                                "type": "string",
                                "description": "Preprocessed log content to analyze"
                            }
                        },
                        "required": ["clean_logs"]
                    }
                },
                {
                    "name": "assess_severity",
                    "description": "Assess the severity level of a log incident (CRITICAL/ERROR/WARNING/INFO) with reasoning.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "clean_logs": {
                                "type": "string",
                                "description": "Log content to assess"
                            },
                            "log_type": {
                                "type": "string",
                                "description": "Detected log type for context"
                            }
                        },
                        "required": ["clean_logs"]
                    }
                },
                {
                    "name": "detect_patterns",
                    "description": "Detect recurring patterns, anomalies, and known error signatures in logs.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "clean_logs": {
                                "type": "string",
                                "description": "Log content to analyze for patterns"
                            }
                        },
                        "required": ["clean_logs"]
                    }
                }
        ]

    def _build_adk_instruction(self) -> str:
        """Build the analyzer's ADK instruction."""
        return """You are the Analyzer Agent for a log analysis system.

    Your job is to classify and analyze log entries before they go to the solver.

    TOOLS AVAILABLE:
    - classify_logs: Full classification (log type, intent, severity, patterns)
    - assess_severity: Quick severity assessment only
    - detect_patterns: Find recurring patterns and anomalies

    CLASSIFICATION TAXONOMY:
    LOG TYPES: python_traceback, java_stacktrace, js_error, go_panic,
               apache_access, apache_error, syslog_rfc5424, syslog_bsd,
               json_log, ndjson, csv, tsv, xml, kubernetes_log, docker_log,
               application_log, plain_text, unknown

    SEVERITY LEVELS:
    - CRITICAL: Service down, data loss, security breach in progress
    - ERROR: Major feature broken, cascading failures
    - WARNING: Intermittent issues, degraded performance
    - INFO: Normal operations, expected errors handled

    USER INTENTS:
    - debugging: User wants root cause + fix
    - explanation: User wants to understand what happened
    - optimization: User wants performance improvements
    - security_audit: User suspects security issue
    - health_check: User wants system status overview

    Always provide confidence scores with your classifications.
    """

    async def process(self, message: A2AMessage) -> A2AMessage:
        task = message.task or {}
        context = message.context or {}

        clean_logs = task.get("clean_logs", "") or context.get("clean_logs", "")

        if not clean_logs:
            return A2AMessage(
                message_type=MessageType.ERROR,
                sender_id=self.agent_id,
                sender_type="analyzer",
                target_id=message.sender_id,
                correlation_id=message.message_id,
                error="No clean logs provided for analysis"
            )

        try:
            model = await self.get_model("gemma")

            # 🔥 ADD THIS BEFORE LLM CALL
            if "Traceback" in clean_logs or "Error" in clean_logs:
                context["log_type_hint"] = "error_log"

            # Run classification
            analysis = await self._analyze(clean_logs, model)

            return A2AMessage(
                message_type=MessageType.RESPONSE,
                sender_id=self.agent_id,
                sender_type="analyzer",
                target_id=message.sender_id,
                correlation_id=message.message_id,
                response={
                    **analysis,
                    "analysis": analysis,  # 🔥 standardized key
                    "log_type": analysis.get("log_type"),
                    "intent": analysis.get("primary_intent"),
                },
                confidence=analysis.get("confidence", 0.7),
                context=message.context
            )

        except Exception as e:
            # Fallback: pattern-based classification
            analysis = await self._pattern_analysis(clean_logs)
            return A2AMessage(
                message_type=MessageType.RESPONSE,
                sender_id=self.agent_id,
                sender_type="analyzer",
                target_id=message.sender_id,
                correlation_id=message.message_id,
                response=analysis,
                confidence=analysis.get("confidence", 0.5)
            )

    async def _analyze(self, logs: str, model) -> Dict:
        """Use LLM to classify logs"""
        prompt = f"""
        You are a senior debugging expert.

        Analyze the following logs carefully.

        LOGS:
        {logs[:3000]}

        Your job is to extract precise debugging information.

        Return STRICT JSON:

        {{
          "log_type": "error_log | server_log | application_log | unknown",
          "primary_intent": "debugging | explanation | optimization",
          "severity": "CRITICAL | ERROR | WARNING | INFO",
          "main_error": "exact exception or error message",
          "error_line": "the exact line where error occurs (if visible)",
          "root_cause": "why this error occurred (very specific)",
          "affected_components": ["list of components"],
          "confidence": 0.0-1.0,
          "summary": "short summary"
        }}

        IMPORTANT:
        - Extract the EXACT exception (e.g., NameError)
        - Identify the root cause from the traceback
        - Do NOT return generic answers
        """

        response = await model.generate(prompt, max_tokens=512)

        import re
        # Extract JSON
        json_match = re.search(r'\{.*\}', response, re.DOTALL)
        if json_match:
            try:
                parsed = json.loads(json_match.group())

                main_error = parsed.get("main_error", "")

                # 🔥 STRONG VALIDATION (NEW)
                if (
                        not main_error
                        or "unknown" in main_error.lower()
                        or "not specified" in main_error.lower()
                        or len(main_error) < 10  # too vague
                ):
                    self.log("LLM output weak → fallback to pattern", "WARNING")
                    return await self._pattern_analysis(logs)

                # 🔥 ENRICHMENT LAYER (VERY IMPORTANT)
                if "NameError" in logs and "NameError" not in main_error:
                    import re
                    match = re.search(r"NameError:\s*(.+)", logs)
                    if match:
                        parsed["main_error"] = f"NameError: {match.group(1)}"
                    else:
                        parsed["main_error"] = "NameError: undefined variable"

                return parsed

            except json.JSONDecodeError:
                pass

        # Fallback
        return await self._pattern_analysis(logs)

    async def _pattern_analysis(self, logs: str) -> Dict:
        """Pattern-based classification without LLM"""
        logs_lower = logs.lower()

        # Determine log type
        if any(word in logs_lower for word in ['database', 'sql', 'postgres', 'mysql', 'connection refused']):
            log_type = "database_log"
        elif any(word in logs_lower for word in ['http', 'apache', 'nginx', '404', '500']):
            log_type = "server_log"
        elif any(word in logs_lower for word in ['permission denied', 'unauthorized', 'forbidden', 'auth']):
            log_type = "security_log"
        elif any(word in logs_lower for word in ['timeout', 'network', 'dns', 'refused']):
            log_type = "network_log"
        elif any(word in logs_lower for word in ['exception', 'traceback', 'error']):
            log_type = "error_log"
        elif any(word in logs_lower for word in ['warn', 'warning']):
            log_type = "application_log"
        else:
            log_type = "system_log"

        # Determine severity
        if any(word in logs_lower for word in ['critical', 'fatal', 'emergency']):
            severity = "CRITICAL"
        elif any(word in logs_lower for word in ['error', 'exception', 'failed']):
            severity = "ERROR"
        elif any(word in logs_lower for word in ['warn', 'warning']):
            severity = "WARNING"
        else:
            severity = "INFO"

        # Determine intent
        if any(word in logs_lower for word in ['traceback', 'exception', 'stack trace', 'line']):
            intent = "debugging"
        elif any(word in logs_lower for word in ['what', 'why', 'explain', 'how']):
            intent = "explanation"
        else:
            intent = "debugging"

        import re
        # Extract main error
        error_pattern = re.search(r'(?:Error|Exception|FATAL|CRITICAL):?\s*([^\n]+)', logs, re.IGNORECASE)
        main_error = error_pattern.group(1).strip() if error_pattern else "Unknown error"

        # 🔥 STRONG DETECTION
        if "NameError" in logs:
            import re
            match = re.search(r"NameError:\s*(.+)", logs)
            if match:
                main_error = f"NameError: {match.group(1)}"
            else:
                main_error = "NameError: undefined variable"

        return {
            "log_type": log_type,
            "primary_intent": intent,
            "severity": severity,
            "main_error": main_error[:200],
            "affected_components": [],
            "confidence": 0.6,
            "summary": f"{severity} {log_type}: {main_error[:100]}"
        }
