"""
Orchestrator Agent

The first point of contact for users. Decomposes queries, discovers
capable agents, coordinates the pipeline, and aggregates results.

Uses Gemma-4-E4B for intelligent task decomposition.

IMPORTANT: This agent NEVER imports other agents directly.
All communication happens through the Communication Bus via A2A messages.
"""

import asyncio
from typing import Dict, List, Any, Optional
from datetime import datetime
import os
import re

from agents.orchestrator.approval_gate import ApprovalGate
from utils.tracing import trace_pipeline_stage
from agents.orchestrator.input_detector import detect_input
from agents.base_agent import BaseAgent, A2AMessage, MessageType, AgentState
from agents.orchestrator.prompts import (
            SKILL_TASK_DECOMPOSITION,
            SKILL_AGENT_SELECTION,
            SKILL_PIPELINE_PLANNING,
            SKILL_EDGE_CASE_DETECTION,
            SKILL_SCOPE_VALIDATION,
            SKILL_RESULT_AGGREGATION,
        )


def _merge_results(results):
    """
    Flatten previous agent outputs into context
    """
    merged = {}

    for key, step in results.items():   # ✅ FIX HERE
        if not step or not isinstance(step, dict):
            continue

        response = step.get("response", {})
        if isinstance(response, dict):
            merged.update(response)

    return merged


class OrchestratorAgent(BaseAgent):
    """
    ADK-powered Central coordinator for the multi-agent system.

    ALL inter-agent communication goes through the Communication Bus.
    This agent discovers other agents by querying the bus, not by importing them.

    ADK Integration:
    - Exposes as an ADK LlmAgent with sub-agents for solver, debugger, critic
    - Supports streaming responses
    - Maintains session state across multi-turn conversations
    """

    def __init__(self):
        super().__init__("orchestrator_v1", "agents/orchestrator/capabilities.json")
        self.planner = None
        self.router = None
        self.execution_history: List[Dict] = []
        self._adk_agent = None
        self._adk_sub_agents = {}
        self._session_store: Dict[str, List[Dict]] = {}  # NEW: session state
        self._current_session_id: Optional[str] = None
        self.approval_gate = ApprovalGate(auto_approve_threshold=0.95)

    async def initialize(self):
        """Initialize planner and router - no agent imports needed"""
        from agents.orchestrator.planner import TaskPlanner
        from agents.orchestrator.router import AgentRouter

        self.planner = TaskPlanner()
        self.router = AgentRouter(self.comm_bus)
        self.log("Orchestrator initialized")

    # �══════════════════════════════════════════════════════════════════════════
    # ADK Integration — Full LlmAgent Conversion
    # ═══════════════════════════════════════════════════════════════════════════

    @property
    def adk_card(self) -> "ADKAgentCard":
        """ADK agent card for the orchestrator."""
        from agents.base_agent import ADKAgentCard
        # from agents.orchestrator.prompts import SKILL_TASK_DECOMPOSITION

        return ADKAgentCard(
            name=self.capability.agent_name,
            description="Orchestrates multi-agent log analysis pipeline",
            capabilities=self.capability.capabilities,
            input_schema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Log entries, file path, or question to analyze"
                    }
                },
                "required": ["query"]
            },
            output_schema={
                "type": "object",
                "properties": {
                    "response": {"type": "string", "description": "Analysis results"},
                    "pipeline_stages": {"type": "array", "description": "Stages completed"},
                    "confidence": {"type": "number", "description": "Overall confidence"}
                }
            },
            model_requirements=["gemma-4-e4b-it"],
            agent_type="orchestrator",
        )

    def _get_model_requirements(self) -> List[str]:
        return ["gemma-4-e4b-it"]

    def _resolve_adk_model(self) -> str:
        return "gemma-4-e4b-it"

    def _build_adk_instruction(self) -> str:
        """Build comprehensive ADK instruction from skill prompts."""

        return f"""You are the Orchestrator Agent for a log analysis multi-agent system.
    Your responsibilities:
    1. Detect the type of log input (file path, pasted text, terminal command, image)
    2. Decompose complex queries into subtasks
    3. Route tasks to the appropriate specialized agents
    4. Aggregate results into a coherent response

    Pipeline stages you can delegate:
    - extract: Extract logs from files, images, terminal output, or pasted text
    - preprocess: Clean, parse, normalize, and chunk raw logs
    - analyze: Classify log type, detect user intent, assess severity
    - solve: Perform root cause analysis and generate fix suggestions
    - debug: Parse stack traces and generate code patches
    - validate: Check solution quality, factual consistency, and safety

    Available agents:
    - extractor: Handles file I/O, image OCR, terminal commands (non-LLM)
    - preprocessor: Cleans and structures raw logs (Qwen-powered)
    - analyzer: Classifies logs and detects patterns (Gemma-powered)
    - solver: Root cause analysis and fix generation (Gemma-powered)
    - debugger: Code-level debugging and patch generation (Gemma-powered)
    - critic: Validates solutions and detects hallucinations (Gemma-powered)
    - memory: Stores and retrieves past analyses (ChromaDB + Qwen)

    {{TASK_DECOMPOSITION_GUIDE}}

    {{AGENT_SELECTION_GUIDE}}

    {{PIPELINE_PLANNING_GUIDE}}

    {{EDGE_CASE_GUIDE}}

    {{SCOPE_VALIDATION_GUIDE}}

    {{RESULT_AGGREGATION_GUIDE}}

    Always respond with structured results showing:
    - What was detected
    - Which agents were used
    - The analysis confidence
    - Actionable recommendations
    """
    # Format with actual skill prompts
    # return instruction

    def create_adk_agent(self, model: str = None, instruction: str = None):
        """
        Create the ADK LlmAgent for the orchestrator with sub-agents.

        This creates a fully functional ADK agent that can:
        - Accept user queries
        - Delegate to solver, debugger, critic as sub-agents
        - Stream responses
        - Maintain session state
        """
        try:
            from google.adk.agents import LlmAgent
        except ImportError:
            raise ImportError(
                "google-adk is required for ADK integration. "
                "Install with: pip install google-adk"
            )

        if self._adk_agent is not None:
            return self._adk_agent

        # Build sub-agents (solver, debugger, critic)
        sub_agents = self._build_adk_sub_agents()

        # Build the ADK orchestrator
        self._adk_agent = LlmAgent(
            name=self.capability.agent_name,
            description="Orchestrates multi-agent log analysis with specialized sub-agents",
            model=model or self._resolve_adk_model(),
            instruction=instruction or self._build_adk_instruction(),
            sub_agents=sub_agents,
            output_schema=self.adk_card.output_schema,
            before_agent_callback=self._adk_before_callback,
            after_agent_callback=self._adk_after_callback,
        )

        self.log("ADK orchestrator agent created with sub-agents: " +
                 ", ".join(a.name for a in sub_agents))

        return self._adk_agent

    def _build_adk_sub_agents(self) -> List:
        """
        Build ADK sub-agents from the bus-registered agents.

        This dynamically discovers agents from the communication bus
        and wraps them as ADK LlmAgents.
        """
        sub_agents = []

        # The sub-agents we want to expose via ADK
        adk_agent_types = ["solver", "debugger", "critic", "memory"]

        if self.comm_bus:
            for agent_type in adk_agent_types:
                try:
                    agent = self._get_bus_agent(agent_type)
                    if agent:
                        adk_sub = agent.create_adk_agent()
                        if adk_sub:
                            sub_agents.append(adk_sub)
                            self._adk_sub_agents[agent_type] = adk_sub
                            self.log(f"  ↳ Registered ADK sub-agent: {agent_type}")
                except Exception as e:
                    self.log(f"  ↳ Could not create ADK sub-agent for {agent_type}: {e}")

        return sub_agents

    def _get_bus_agent(self, agent_type: str) -> Optional[BaseAgent]:
        """Get a registered agent from the communication bus by type."""
        if not self.comm_bus:
            return None

        for agent_id, agent in self.comm_bus.agents.items():
            if agent.capability.agent_name == agent_type:
                return agent

        return None

    # ═══════════════════════════════════════════════════════════════════════════
    # ADK Callbacks
    # ═══════════════════════════════════════════════════════════════════════════

    async def _adk_before_callback(self, context, request=None) -> Optional[Any]:
        """ADK callback: before processing."""
        self.state = AgentState.PROCESSING
        self.log(f"ADK orchestrator processing request", "DEBUG")
        return None

    async def _adk_after_callback(self, context, response) -> Optional[Any]:
        """ADK callback: after processing — store in memory."""
        if self.state != AgentState.ERROR:
            self.state = AgentState.IDLE

        # Store interaction in memory
        try:
            await self._store_in_memory(
                query=str(context)[:500],
                results={"adk_response": str(response)[:1000]}
            )
        except Exception:
            pass

        return None

# Session Management for adk session state

    def _get_session_context(self, session_id: str, max_turns: int = 5) -> str:
        """Build conversation context from previous turns in this session."""
        if session_id not in self._session_store:
            return ""

        history = self._session_store[session_id][-max_turns:]
        if not history:
            return ""

        context = "\n=== PREVIOUS CONVERSATION ===\n"
        for i, turn in enumerate(history):
            context += f"\nTurn {i + 1}:\n"
            context += f"  Query: {turn.get('query', '')[:200]}\n"
            if turn.get('root_cause'):
                context += f"  Root Cause: {turn['root_cause']}\n"
            if turn.get('fix'):
                context += f"  Fix: {turn['fix']}\n"
            if turn.get('log_type'):
                context += f"  Log Type: {turn['log_type']}\n"
        context += "\n=== END PREVIOUS CONVERSATION ===\n"

        return context

    def _store_in_session(self, session_id: str, query: str, results: Dict):
        """Store the current analysis in session history."""
        if session_id not in self._session_store:
            self._session_store[session_id] = []

        # Extract key info from results
        solver_result = results.get("subtask_3", {}).get("response", {})

        self._session_store[session_id].append({
            "query": query,
            "timestamp": datetime.now().isoformat(),
            "root_cause": str(solver_result.get("root_cause", {}).get("primary_cause", "")),
            "fix": str(solver_result.get("fix_suggestion", {}).get("code_fix", {}).get("change_description", "")),
            "log_type": str(solver_result.get("log_type", "")),
            "confidence": results.get("subtask_3", {}).get("confidence", 0),
        })

        # Keep only last 10 turns
        if len(self._session_store[session_id]) > 10:
            self._session_store[session_id] = self._session_store[session_id][-10:]

    def _is_followup_query(self, query: str) -> bool:
        """Detect if this is a follow-up question referencing previous analysis."""
        followup_indicators = [
            "what was the", "what caused", "suggest a fix", "how to fix",
            "explain that", "what about", "and then", "why did",
            "can you elaborate", "tell me more", "go deeper",
            "what else", "anything else", "summarize", "what did you find",
            "summarize", "summary", "give me overview", "what's in these logs",
            "break down", "breakdown", "tl;dr", "tldr"
        ]
        query_lower = query.lower()
        return any(indicator in query_lower for indicator in followup_indicators)

    def _answer_from_session(self, query: str, last_turn: Dict) -> str:
        """Answer a follow-up question directly from session context."""
        query_lower = query.lower()

        if "root cause" in query_lower:
            return f"The root cause was: {last_turn.get('root_cause', 'not recorded')}"

        if "fix" in query_lower or "how to fix" in query_lower:
            return f"The suggested fix was: {last_turn.get('fix', 'not recorded')}"

        if "log type" in query_lower:
            return f"The log type was: {last_turn.get('log_type', 'unknown')}"

        if "confidence" in query_lower:
            return f"The confidence score was: {last_turn.get('confidence', 0):.0%}"

        # Generic follow-up — return summary
        return f"""From our previous analysis:
    • Root Cause: {last_turn.get('root_cause', 'N/A')}
    • Fix: {last_turn.get('fix', 'N/A')}
    • Log Type: {last_turn.get('log_type', 'N/A')}
    • Confidence: {last_turn.get('confidence', 0):.0%}"""

    async def receive_message(self, message: A2AMessage) -> Optional[A2AMessage]:
        """
        Override to resolve pending futures when responses arrive.
        This is the CRITICAL fix — without this, _send_and_wait always times out.
        """
        # Check if this is a response to a pending request we're waiting for
        if hasattr(self, '_pending_responses') and message.correlation_id:
            future = self._pending_responses.get(message.correlation_id)
            if future and not future.done():
                future.set_result(message)
                self.log(
                    f"Resolved pending future for {message.correlation_id[:8]}... "
                    f"(type={message.message_type.value}, conf={message.confidence:.2f})",
                    "DEBUG"
                )
                return None  # Don't process further — the waiter in _send_and_wait handles it

        # For ERROR messages without a matching future, log and drop to avoid loops
        if message.message_type == MessageType.ERROR and not (
                hasattr(self, '_pending_responses') and
                message.correlation_id in self._pending_responses
        ):
            self.log(f"Dropping orphaned ERROR: {message.error}", "WARNING")
            return None

        # NEW: Drop RESPONSE's without matching future (fire-and-forget like memory store)
        if message.message_type == MessageType.RESPONSE and not (
            hasattr(self, '_pending_responses') and
            message.correlation_id in self._pending_responses
        ):
            self.log(f"Dropping unsolicited RESPONSE from {message.sender_type}", "DEBUG")
            return None

        # Otherwise, let BaseAgent handle it normally
        return await super().receive_message(message)

    async def _retrieve_similar_cases(self, query: str, clean_logs: str, log_type: str) -> Optional[str]:
        """
        Query memory agent for similar past cases and return formatted context.
        Returns None if retrieval fails or no similar cases found.
        """

        # Skip if no meaningful content to search with
        if not clean_logs or len(clean_logs.strip()) < 20:
            return None

        try:
            # Send retrieval request to memory agent
            retrieve_msg = A2AMessage.create_request(
                sender_id=self.agent_id,
                sender_type="orchestrator",
                target_type="memory",
                task={
                    "action": "retrieve_similar_cases",
                    "query": query,
                    "log_type": log_type,
                    "limit": 3
                },
                context={
                    "clean_logs": clean_logs,
                    "log_type": log_type
                }
            )

            result = await self._send_and_wait(retrieve_msg, timeout=30.0)

            if result and result.message_type == MessageType.RESPONSE:
                response = result.response or {}
                past_cases = response.get("results", [])

                if past_cases and len(past_cases) > 0:
                    self.log(f"Retrieved {len(past_cases)} similar past cases from memory")

                    # Format as context for solver
                    context = "\n=== SIMILAR PAST CASES (for reference) ===\n"
                    for i, case in enumerate(past_cases[:3]):
                        similarity = case.get("similarity", 0.0)
                        metadata = case.get("metadata", {})
                        content = case.get("content", "")[:500]

                        context += f"\nPast Case #{i + 1} (similarity: {similarity:.0%}):\n"
                        context += f"  Root Cause: {metadata.get('root_cause', 'N/A')}\n"
                        context += f"  Severity: {metadata.get('severity', 'unknown')}\n"
                        context += f"  Log Type: {metadata.get('log_type', 'unknown')}\n"
                        if content:
                            context += f"  Excerpt: {content[:200]}...\n"

                    context += "\nNOTE: These are past cases for reference only. The current error may have a different root cause.\n"
                    context += "=== END PAST CASES ===\n"

                    return context

            return None

        except Exception as e:
            self.log(f"Memory retrieval failed (non-critical): {e}", "DEBUG")
            return None

    async def handle_user_query(self, query: str, session_id: str = None) -> str:
        """Main entry point for user queries - NO agent imports"""
        import time
        import uuid

        # Use existing or new session
        if session_id is None:
            session_id = self._current_session_id or str(uuid.uuid4())
        self._current_session_id = session_id

        # input_info = detect_input(query)
        # print(f"\n⏳ {input_info['display_message']}")

        # NEW: Check if this is a follow-up question
        is_followup = self._is_followup_query(query)
        if is_followup:
            # Inject previous conversation context
            # session_context = self._get_session_context(session_id)
            # if session_context:
            last_turn = self._session_store.get(session_id, [{}])[-1] if self._session_store.get(session_id) else {}
            if last_turn.get("root_cause"):
                return self._answer_from_session(query, last_turn)
                # query = session_context + "\nCurrent question: " + query
                # self.log("Injected session context into follow-up query", "DEBUG")

        # NEW: Detect summarization requests
        if any(word in query.lower() for word in ["summarize", "summary", "tl;dr", "tldr", "overview"]):
            # Force intent to summarization
            # query_type = "summarize"
            self.log("Summarization requested", "DEBUG")
            # The solver will pick up this flag from the plan context

        # NEW: Detect input type first, before any processing
        input_info = detect_input(query)
        print(f"\n⏳ {input_info['display_message']}")

        # NEW: Handle NL queries by searching session + memory
        if input_info.get("input_type") == "nl_query":
            # First check if there's a recent session with logs
            if self._session_store.get(session_id):
                last_turn = self._session_store[session_id][-1]
                if last_turn.get("root_cause"):
                    # Answer from session context
                    return self._answer_from_session(query, last_turn)

            # If no session, check memory for past analyses
            try:
                memory_context = await self._retrieve_similar_cases(
                    query=query,
                    clean_logs=query,
                    log_type="unknown"
                )
                if memory_context:
                    # Run analysis on retrieved memory context
                    plan = await self.planner.decompose(query, None)
                    plan["original_query"] = memory_context + "\n\nUser question: " + query
                    results = await self._execute_plan(plan)
                    final = await self._aggregate_results(results, query)
                    return final
            except Exception:
                pass

            return "I couldn't find any logs to answer your question. Please provide logs or a file path first."

        # Generate unique query session ID
        query_id = str(uuid.uuid4())
        query_start_time = time.time()

        self.log(f"Processing query: {query[:100]}...")
        self.log(
            f"Detected: {input_info['input_type']}/{input_info['format']} (layer {input_info['detection_layer']}, confidence: {input_info['confidence']})",
            "INFO")

        # Log query start to audit
        try:
            from utils.audit_logger import get_audit_logger
            audit = get_audit_logger()
            audit.log_query_start(
                query_id=query_id,
                query_text=query,
                input_type=input_info["input_type"],
                input_format=input_info["format"],
                detection_layer=input_info["detection_layer"],
                detection_confidence=input_info["confidence"],
                chars=input_info["chars"],
                lines=input_info["lines"],
            )
        except Exception:
            audit = None

        try:
            # Step 1: Check if in scope
            if not await self._is_in_scope(query):
                return self._get_capability_summary()

            # Step 2: Decompose query
            self.log("Decomposing query...")
            model = None
            try:
                model = await self.get_model("gemma")
            except Exception:
                pass
            plan = await self.planner.decompose(query, model)

            # Inject query_id and input_info into plan for downstream logging
            plan["query_id"] = query_id
            plan["detected_input"] = input_info

            # Step 3: Execute plan via Communication Bus
            self.log(f"Executing plan with {len(plan['subtasks'])} subtasks")
            results = await self._execute_plan(plan)

            # Step 4: Aggregate results
            self.log("Aggregating results...")
            final_response = await self._aggregate_results(results, query)

            # Step 5: Store in memory via Communication Bus
            await self._store_in_memory(query, results)
            # At the end, after _store_in_memory, add:
            self._store_in_session(session_id, query, results)
            return final_response
            # Log query end to audit
            # if audit:
            #     total_duration_ms = (time.time() - query_start_time) * 1000
            #     final_confidence = results.get("subtask_4", {}).get("confidence", 0.0)
            #     audit.log_query_end(
            #         query_id=query_id,
            #         total_duration_ms=total_duration_ms,
            #         pipeline_completed=True,
            #         final_confidence=final_confidence,
            #     )
            #
            # return final_response

        except Exception as e:
            self.log(f"Error: {e}", "ERROR")
            # Log failure to audit
            if audit:
                total_duration_ms = (time.time() - query_start_time) * 1000
                audit.log_query_end(
                    query_id=query_id,
                    total_duration_ms=total_duration_ms,
                    pipeline_completed=False,
                    error=str(e),
                )
            return f"I encountered an error: {str(e)}\n\nPlease try again."

    async def process(self, message: A2AMessage) -> A2AMessage:
        """Process incoming messages"""
        if not self.planner:
            await self.initialize()

        task = message.task or {}
        action = task.get("action", "handle_query")

        if action == "handle_query":
            return await self._handle_user_query(message)
        elif action == "aggregate_results":
            return await self._handle_aggregation(message)
        else:
            return await self._handle_user_query(message)

    async def _is_in_scope(self, query: str) -> bool:
        """Check if query is within system capabilities"""
        query_lower = query.lower()

        # NEW: Terminal commands are always in scope
        if query_lower.startswith("command:") or query_lower.startswith("cmd:"):
            return True

        # Clearly out-of-scope
        out_of_scope = [
            'weather', 'news', 'sport', 'recipe', 'cook',
            'movie', 'song', 'game', 'play', 'joke', 'what is your name',
            'who are you', 'how old are you',
            'how are you',     # ← ADD
            'how do you do',   # ← ADD
        ]

        for keyword in out_of_scope:
            if keyword in query_lower:
                return False

        # Log-related keywords
        log_keywords = [
            'log', 'error', 'debug', 'fix', 'crash', 'exception',
            'stack trace', 'analyze', 'issue', 'problem', 'failed',
            'failure', 'warning', 'critical', 'trace', 'fatal',
            'null', 'timeout', 'refused', 'denied', 'not found',
            'permission', 'memory', 'disk', 'network', 'database'
        ]

        for keyword in log_keywords:
            if keyword in query_lower:
                return True

        # Python error patterns
        python_errors = [
            'traceback', 'nameerror', 'typeerror', 'valueerror',
            'keyerror', 'indexerror', 'attributeerror', 'importerror',
            'modulenotfounderror', 'syntaxerror', 'indentationerror',
            'filenotfounderror', 'permissionerror', 'connectionerror',
            'timeouterror', 'runtimeerror', 'notimplementederror'
        ]

        for error in python_errors:
            if error in query_lower:
                return True

        # Contains file paths
        if any(ext in query_lower for ext in ['.py', '.log', '.txt', '.json', '.xml', '.csv']):
            return True

        # Contains line numbers (common in stack traces)
        if 'line' in query_lower and any(char.isdigit() for char in query):
            return True

        # Contains error patterns like "Error:" or "Exception:"
        if 'error:' in query_lower or 'exception:' in query_lower:
            return True

        # Has timestamp patterns
        import re
        if re.search(r'\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}', query):
            return True

        # Default: check if it looks like a technical question
        technical_words = ['what', 'why', 'how', 'fix', 'help', 'check', 'find', 'cause']
        return any(word in query_lower for word in technical_words)

    async def _retry_with_feedback(self, plan, results, retry_count=0, max_retries=3):
        """
        Multi-step reasoning: if critic confidence is low, retry solver
        with constructive feedback.
        """
        if retry_count >= max_retries:
            self.log(f"Max retries ({max_retries}) reached, proceeding with current results")
            return results

        # Get critic's result
        critic_key = "subtask_4"  # validate is subtask 5 (index 4)
        critic_result = results.get(critic_key, {})

        if not critic_result or critic_result.get("status") != "completed":
            return results

        critic_response = critic_result.get("response", {})

        # Check if retry is needed
        needs_retry = (
                not critic_response.get("validation_passed", True) or
                critic_result.get("confidence", 1.0) < 0.5
        )

        if not needs_retry:
            self.log(f"Critic confidence {critic_result.get('confidence', 0):.2f} — no retry needed")
            return results

        retry_feedback = critic_response.get("retry_feedback", "")
        if not retry_feedback:
            return results

        self.log(
            f"Critic confidence {critic_result.get('confidence', 0):.2f} — retrying solver with feedback (attempt {retry_count + 1}/{max_retries})")

        # Get solver's original task and add feedback
        solver_key = "subtask_3"  # solve is subtask 4 (index 3)
        original_solver_result = results.get(solver_key, {})

        # Build retry subtask
        retry_subtask = {
            "action": "solve",
            "retry_count": retry_count + 1,
            "retry_feedback": retry_feedback,
            "previous_attempt": original_solver_result.get("response", {}),
            "intent": plan.get("subtasks", [{}])[3].get("intent", "debugging")
        }

        # Send retry to solver
        request = A2AMessage.create_request(
            sender_id=self.agent_id,
            sender_type="orchestrator",
            target_type="solver",
            task=retry_subtask,
            context={
                "query": plan.get("original_query", ""),
                "clean_logs": results.get("subtask_2", {}).get("response", {}).get("clean_logs", ""),
                "log_type": results.get("subtask_2", {}).get("response", {}).get("log_type", "unknown"),
                "retry_feedback": retry_feedback
            }
        )

        retry_result = await self._send_and_wait(request, timeout=60.0)

        if retry_result and retry_result.message_type != MessageType.ERROR:
            # Update solver result
            results["subtask_3"] = {
                "status": "completed",
                "agent_type": "solver",
                "response": retry_result.response if retry_result.response else {},
                "confidence": retry_result.confidence,
                "retry_attempt": retry_count + 1
            }

            # Re-validate
            validate_subtask = {
                "action": "validate",
                "solution": retry_result.response if retry_result.response else {},
                "original_logs": results.get("subtask_0", {}).get("response", {}).get("raw_logs", "")
            }

            validate_request = A2AMessage.create_request(
                sender_id=self.agent_id,
                sender_type="orchestrator",
                target_type="critic",
                task=validate_subtask,
                context={"query": plan.get("original_query", "")}
            )

            validate_result = await self._send_and_wait(validate_request, timeout=60.0)

            if validate_result and validate_result.message_type != MessageType.ERROR:
                results["subtask_4"] = {
                    "status": "completed",
                    "agent_type": "critic",
                    "response": validate_result.response if validate_result.response else {},
                    "confidence": validate_result.confidence
                }

                # Recursive retry if still low confidence
                return await self._retry_with_feedback(plan, results, retry_count + 1, max_retries)

        return results

    async def _cross_agent_debate(self, plan, results, merged_context):
        """
        Run solver and debugger in parallel, let critic pick the winner.
        Only triggers when the pipeline has both solve AND debug stages.
        """
        # subtasks = plan.get("subtasks", [])
        # has_debug = any(s.get("action") == "debug" for s in subtasks)
        #
        # if not has_debug:
        #     return None  # No debug stage, skip debate

        self.log("Starting cross-agent debate: solver vs debugger")

        # Prepare context for both agents
        query = plan.get("original_query", "")
        clean_logs = merged_context.get("clean_logs", "")
        log_type = merged_context.get("log_type", "unknown")

        # Build solver request
        solver_task = {
            "action": "solve",
            "intent": "debugging"
        }
        solver_context = {
            "query": query,
            "clean_logs": clean_logs,
            "log_type": log_type,
        }

        # Build debugger request
        debugger_task = {
            "action": "debug",
        }
        debugger_context = {
            "query": query,
            "clean_logs": clean_logs,
            "stack_trace": merged_context.get("raw_logs", clean_logs),
        }

        # Send to both in parallel
        solver_request = A2AMessage.create_request(
            sender_id=self.agent_id,
            sender_type="orchestrator",
            target_type="solver",
            task=solver_task,
            context=solver_context
        )

        debugger_request = A2AMessage.create_request(
            sender_id=self.agent_id,
            sender_type="orchestrator",
            target_type="debugger",
            task=debugger_task,
            context=debugger_context
        )

        # Fire both simultaneously
        # import asyncio
        # solver_future = self._send_and_wait(solver_request, timeout=60.0)
        # debugger_future = self._send_and_wait(debugger_request, timeout=60.0)
        #
        # solver_result, debugger_result = await asyncio.gather(
        #     solver_future, debugger_future, return_exceptions=True
        # )

        # Fire sequentially to avoid GGML concurrency crash
        solver_result = await self._send_and_wait(solver_request, timeout=60.0)
        debugger_result = await self._send_and_wait(debugger_request, timeout=60.0)

        # ADD THESE DEBUG LINES:
        if isinstance(solver_result, Exception):
            self.log(f"Debate: Solver failed with exception: {solver_result}", "DEBUG")
        elif not solver_result:
            self.log("Debate: Solver returned None", "DEBUG")
        else:
            self.log(
                f"Debate: Solver returned type={solver_result.message_type.value}, conf={solver_result.confidence:.2f}",
                "DEBUG")

        if isinstance(debugger_result, Exception):
            self.log(f"Debate: Debugger failed with exception: {debugger_result}", "DEBUG")
        elif not debugger_result:
            self.log("Debate: Debugger returned None", "DEBUG")
        else:
            self.log(
                f"Debate: Debugger returned type={debugger_result.message_type.value}, conf={debugger_result.confidence:.2f}",
                "DEBUG")

        # Ask critic to compare
        critic_task = {
            "action": "validate",
            "solution": {
                "solver": solver_result.response if solver_result.response else {},
                "debugger": debugger_result.response if debugger_result.response else {},
            },
            "original_logs": clean_logs,
        }

        critic_request = A2AMessage.create_request(
            sender_id=self.agent_id,
            sender_type="orchestrator",
            target_type="critic",
            task=critic_task,
            context={"query": query, "debate_mode": True}
        )

        critic_result = await self._send_and_wait(critic_request, timeout=60.0)

        if critic_result and critic_result.message_type != MessageType.ERROR:
            critic_response = critic_result.response or {}
            winner = critic_response.get("winner", "solver")

            self.log(f"Cross-agent debate complete — winner: {winner}")

            # Return the winner's result to be used as the solve output
            if winner == "debugger" and debugger_result.response:
                debug_response = debugger_result.response
                return {
                    "status": "completed",
                    "agent_type": "debugger",
                    "response": {
                        "root_cause": debug_response.get("parsed_trace", {}),
                        "fix_suggestion": debug_response.get("patch", {}),
                        "explanation": debug_response.get("patch", {}).get("fix_description", ""),
                        "log_type": merged_context.get("log_type", "unknown"),
                        "debate_winner": "debugger",
                    },
                    "confidence": debugger_result.confidence,
                }
            else:
                # Default: use solver result
                solver_response = solver_result.response if solver_result.response else {}
                return {
                    "status": "completed",
                    "agent_type": "solver",
                    "response": solver_response,
                    "confidence": solver_result.confidence,
                }

        # If critic failed, fall back to solver
        if solver_result and solver_result.response:
            return {
                "status": "completed",
                "agent_type": "solver",
                "response": solver_result.response,
                "confidence": solver_result.confidence,
            }

        return None        # Debate inconclusive — use solver as default

    def _has_stack_trace(self, text: str) -> bool:
        """Check if log content contains a stack trace worth debugging."""
        if not text:
            return False

        # Python traceback
        if "Traceback (most recent call last)" in text:
            return True
        if 'File "' in text and 'line ' in text:
            return True

        # Java stack trace
        if "Exception in thread" in text:
            return True
        if "at com." in text or "at org." in text:
            return True

        # JavaScript/Node.js
        if "at " in text and (".js:" in text or ".ts:" in text):
            return True

        # Go panic
        if "panic:" in text and ".go:" in text:
            return True

        # Generic error with file:line references
        if re.search(r'\w+\.\w+:\d+', text):
            return True

        return False

    async def _execute_plan(self, plan: Dict) -> Dict:
        """Execute plan by sending A2A messages - skip if previous step failed critically"""
        import os
        import time

        subtasks = plan.get("subtasks", [])
        results = {}
        pipeline_broken = False

        # Get audit context from plan
        query_id = plan.get("query_id", "unknown")
        input_info = plan.get("detected_input", {})

        try:
            from utils.audit_logger import get_audit_logger
            audit = get_audit_logger()
        except Exception:
            audit = None

        for i, subtask in enumerate(subtasks):
            action = subtask.get("action", "unknown")
            stage_start_time = time.time()

            # Skip if pipeline is broken
            if pipeline_broken:
                self.log(f"Skipping subtask {i + 1}: {action} (pipeline broken)")
                results[f"subtask_{i}"] = {
                    "status": "skipped",
                    "reason": "Previous critical step failed"
                }
                # Log skipped stage
                if audit:
                    audit.log_pipeline_stage(
                        stage=action,
                        status="skipped",
                        agent_type="none",
                        confidence=0.0,
                        query_id=query_id,
                        query_preview=plan.get("original_query", ""),
                        input_type=input_info.get("input_type"),
                        stage_number=f"{i + 1}/{len(subtasks)}",
                    )
                continue

            if action == "extract" and plan.get("query_type") == "nl_query":
                # NL queries without logs — skip pipeline, return guidance
                results[f"subtask_{i}"] = {
                    "status": "skipped",
                    "reason": "No logs provided for NL query"
                }
                continue

            # ---- Fix extract subtask ----
            if action == "extract":
                import os

                original_query = plan.get("original_query", "")

                # NEW: Strip summarization prefixes before resolving path
                for prefix in ["summarize ", "summarize this file_path: ", "summarize file_path: ", "summary ",
                               "overview "]:
                    if original_query.lower().startswith(prefix):
                        original_query = original_query[len(prefix):]
                        break

                # NEW: Detect Elasticsearch query prefix
                if original_query.lower().startswith("es:") or original_query.lower().startswith("elasticsearch:"):
                    query_part = original_query.split(":", 1)[1].strip()
                    subtask["source_type"] = "elasticsearch"
                    subtask["es_query"] = query_part
                    subtask["content"] = None
                    subtask["file_path"] = ""
                    self.log(f"Detected Elasticsearch query: {query_part}", "DEBUG")

                # NEW: Detect terminal command prefix
                elif original_query.lower().startswith("command:") or original_query.lower().startswith("cmd:"):
                    command = original_query.split(":", 1)[1].strip()
                    if command:
                        subtask["command"] = command
                        subtask["source_type"] = "terminal"
                        subtask["content"] = None
                        subtask["file_path"] = ""
                        self.log(f"Detected terminal command: {command}", "DEBUG")

                # If query looks like a file path, resolve it directly
                elif original_query and not subtask.get("file_path"):
                    if any(original_query.endswith(ext) for ext in
                           ['.log', '.txt', '.json', '.csv', '.xml', '.jpg', '.png']):
                        abs_path = os.path.abspath(original_query)
                        subtask["file_path"] = abs_path
                        subtask["content"] = None
                        self.log(f"Resolved file path: {abs_path}", "DEBUG")

                # If still no file_path, check options and plan
                if not subtask.get("file_path") and not subtask.get("command"):
                    file_path = subtask.get("options", {}).get("path") or plan.get("file_path")
                    if file_path:
                        if not os.path.isabs(file_path):
                            file_path = os.path.abspath(file_path)
                        subtask["file_path"] = file_path
                        subtask["content"] = None

                # Last resort: use query as pasted text
                if not subtask.get("content") and not subtask.get("file_path") and not subtask.get("command"):
                    subtask["content"] = original_query
            # ---------------------------------

            # ---- Inject memory context before solve ----
            if action == "solve":
                # 1. Memory retrieval (always)
                memory_context = await self._retrieve_similar_cases(
                    query=plan.get("original_query", ""),
                    clean_logs=merged_context.get("clean_logs", ""),
                    log_type=merged_context.get("log_type", "unknown")
                )
                if memory_context:
                    subtask["memory_context"] = memory_context
                    self.log("Injected memory context into solve task", "DEBUG")

                # 2. Cross-agent debate (only when stack trace detected)
                raw_logs = merged_context.get("raw_logs", "") or merged_context.get("clean_logs", "")
                if self._has_stack_trace(raw_logs):
                    self.log("Stack trace detected — starting cross-agent debate", "DEBUG")
                    debate_result = await self._cross_agent_debate(plan, results, merged_context)
                    if debate_result:
                        # Check if ANY agent generated a fix worth approving
                        response = debate_result.get("response", {})
                        fix_suggestion = response.get("fix_suggestion", {})

                        if fix_suggestion:
                            # Get fix details from solver response
                            code_fix = fix_suggestion.get("code_fix", {})
                            root_cause_data = response.get("root_cause", {})

                            if code_fix.get("change_description"):
                                try:
                                    approval_request = self.approval_gate.create_request(
                                        query=plan.get("original_query", ""),
                                        root_cause=str(root_cause_data.get("primary_cause", "Unknown")),
                                        fix_description=code_fix.get("change_description", "Fix suggested by solver"),
                                        code_before=code_fix.get("code_before", ""),
                                        code_after=code_fix.get("code_after", ""),
                                        file_path=code_fix.get("file", ""),
                                        confidence=debate_result.get("confidence", 0),
                                    )
                                    approved = await self.approval_gate.request_approval(approval_request)
                                    debate_result["approved"] = approved
                                    debate_result["approval_id"] = approval_request.request_id
                                except Exception as e:
                                    self.log(f"Approval gate error: {e}", "WARNING")

                        # Check for fix that needs approval BEFORE storing result
                        response = debate_result.get("response", {})
                        fix_suggestion = response.get("fix_suggestion", {})

                        # self.log(
                        #     f"DEBUG fix_suggestion keys: {list(fix_suggestion.keys()) if isinstance(fix_suggestion, dict) else type(fix_suggestion)}",
                        #     "DEBUG")
                        # self.log(f"DEBUG fix_suggestion: {str(fix_suggestion)[:300]}", "DEBUG")

                        # Check for actionable fix needing approval
                        response = debate_result.get("response", {})
                        fix_suggestion = response.get("fix_suggestion", {})

                        if fix_suggestion:
                            # Try code_changes first, then immediate_actions
                            code_changes = fix_suggestion.get("code_changes", [])
                            immediate_actions = fix_suggestion.get("immediate_actions", [])
                            root_cause_data = response.get("root_cause", {})

                            has_code_fix = code_changes and len(code_changes) > 0
                            has_action = immediate_actions and len(immediate_actions) > 0

                            if has_code_fix or has_action:
                                try:
                                    # Build fix description from whichever is available
                                    if has_code_fix:
                                        fix_desc = code_changes[0] if isinstance(code_changes[0], str) else \
                                        code_changes[0].get("description", str(code_changes[0]))
                                    else:
                                        fix_desc = immediate_actions[0]

                                    approval_request = self.approval_gate.create_request(
                                        query=plan.get("original_query", ""),
                                        root_cause=str(root_cause_data.get("primary_cause", "Unknown")),
                                        fix_description=str(fix_desc),
                                        code_before="",
                                        code_after="",
                                        file_path="",
                                        risk_level=fix_suggestion.get("risk_level", "low"),
                                        confidence=debate_result.get("confidence", 0),
                                    )
                                    approved = await self.approval_gate.request_approval(approval_request)
                                    debate_result["approved"] = approved
                                    debate_result["approval_id"] = approval_request.request_id
                                except Exception as e:
                                    self.log(f"Approval gate error: {e}", "WARNING")

                        results[f"subtask_{i}"] = debate_result
                        self.log(
                            f"Cross-agent debate: using {debate_result.get('agent_type', 'solver')} (winner: {debate_result.get('debate_winner', 'solver')})",
                            "INFO")
                        continue
                    # if debate_result:
                    #     # After debugger result in cross-agent debate
                    #     if debate_result.get("response", {}).get("patch"):  # Any patch available?
                    #         patch = debate_result.get("response", {}).get("patch", {})
                    #         if patch and patch.get("code_after"):
                    #             approval_request = self.approval_gate.create_request(
                    #                 query=plan.get("original_query", ""),
                    #                 root_cause=str(
                    #                     debate_result.get("response", {}).get("parsed_trace", {}).get("error_message", "")),
                    #                 fix_description=patch.get("fix_description", ""),
                    #                 code_before=patch.get("code_before", ""),
                    #                 code_after=patch.get("code_after", ""),
                    #                 file_path=patch.get("file", ""),
                    #                 confidence=debate_result.get("confidence", 0),
                    #             )
                    #
                    #             approved = await self.approval_gate.request_approval(approval_request)
                    #             debate_result["approved"] = approved
                    #             debate_result["approval_id"] = approval_request.request_id
                    #         continue  # Skip normal solver — debate already produced result
                    else:
                        self.log("Debate inconclusive — proceeding with normal solver", "DEBUG")
                else:
                    self.log("No stack trace detected — using solver only", "DEBUG")

            # ---------------------------------------------

            self.log(f"Subtask {i + 1}/{len(subtasks)}: {action}")

            target_type = self.router.get_agent_type_for_action(action)

            if not target_type:
                self.log(f"No agent type for: {action}", "WARNING")
                results[f"subtask_{i}"] = {"status": "failed", "error": "No capable agent"}
                if audit:
                    audit.log_pipeline_stage(
                        stage=action,
                        status="failed",
                        agent_type="none",
                        confidence=0.0,
                        query_id=query_id,
                        query_preview=plan.get("original_query", ""),
                        input_type=input_info.get("input_type"),
                        stage_number=f"{i + 1}/{len(subtasks)}",
                        error="No capable agent found",
                    )
                if action in ["extract", "preprocess"]:
                    pipeline_broken = True
                continue

            # Merge all previous results into context for downstream agents
            merged_context = _merge_results(results)
            merged_context["query"] = plan.get("original_query", "")

            request = A2AMessage.create_request(
                sender_id=self.agent_id,
                sender_type="orchestrator",
                target_type=target_type,
                task=subtask,
                context=merged_context
            )

            # Before sending each request:
            with trace_pipeline_stage(action, f"{i + 1}/{len(subtasks)}"):
                result = await self._send_and_wait(request, timeout=60.0)
            duration_ms = (time.time() - stage_start_time) * 1000

            if result:
                if result.message_type == MessageType.ERROR:
                    results[f"subtask_{i}"] = {
                        "status": "completed_with_error",
                        "response": {"raw_logs": "", "warning": getattr(result, 'error', str(result))},
                        "confidence": 0.0
                    }
                    self.log(f"Subtask {action} returned ERROR: {getattr(result, 'error', 'unknown')}", "WARNING")
                    # Log error stage
                    if audit:
                        audit.log_pipeline_stage(
                            stage=action,
                            status="completed_with_error",
                            agent_type=target_type,
                            confidence=0.0,
                            duration_ms=duration_ms,
                            query_id=query_id,
                            query_preview=plan.get("original_query", ""),
                            input_type=input_info.get("input_type"),
                            stage_number=f"{i + 1}/{len(subtasks)}",
                            error=getattr(result, 'error', str(result)),
                        )
                else:
                    results[f"subtask_{i}"] = {
                        "status": "completed",
                        "agent_type": target_type,
                        "response": result.response if result.response else {"raw_logs": ""},
                        "confidence": result.confidence
                    }
                    # Log completed stage
                    if audit:
                        response_summary = {}
                        if result.response:
                            resp = result.response
                            response_summary = {
                                "has_raw_logs": bool(resp.get("raw_logs")),
                                "log_length": len(resp.get("raw_logs", "")),
                                "has_clean_logs": bool(resp.get("clean_logs")),
                                "log_type": resp.get("log_type"),
                                "format_detected": resp.get("format_detected"),
                            }
                        audit.log_pipeline_stage(
                            stage=action,
                            status="completed",
                            agent_type=target_type,
                            confidence=result.confidence,
                            duration_ms=duration_ms,
                            query_id=query_id,
                            query_preview=plan.get("original_query", ""),
                            input_type=input_info.get("input_type"),
                            stage_number=f"{i + 1}/{len(subtasks)}",
                            summary=response_summary,
                        )

                    if not result.response or not result.response.get("raw_logs"):
                        if result.confidence < 0.3:
                            self.log(f"Low confidence ({result.confidence}) and empty data — breaking pipeline",
                                     "WARNING")
                            pipeline_broken = True
            else:
                results[f"subtask_{i}"] = {
                    "status": "failed",
                    "error": "No response from agent"
                }
                if audit:
                    audit.log_pipeline_stage(
                        stage=action,
                        status="failed",
                        agent_type=target_type,
                        confidence=0.0,
                        duration_ms=duration_ms,
                        query_id=query_id,
                        query_preview=plan.get("original_query", ""),
                        input_type=input_info.get("input_type"),
                        stage_number=f"{i + 1}/{len(subtasks)}",
                        error="No response from agent",
                    )
                if action in ["extract", "preprocess"]:
                    pipeline_broken = True

        # Multi-step reasoning: retry solve if critic confidence is low
        if not pipeline_broken:
            results = await self._retry_with_feedback(plan, results)

        return results

    async def _send_and_wait(
        self, message: A2AMessage, timeout: float = 60.0
    ) -> Optional[A2AMessage]:
        """Send message via bus and wait for response"""
        response_future = asyncio.Future()

        if not hasattr(self, '_pending_responses'):
            self._pending_responses = {}
        self._pending_responses[message.message_id] = response_future

        # Send through Communication Bus (not direct call)
        await self.send_message(message)

        try:
            response = await asyncio.wait_for(response_future, timeout=timeout)
            return response
        except asyncio.TimeoutError:
            return None
        finally:
            self._pending_responses.pop(message.message_id, None)

    async def _aggregate_results(self, results: Dict, query: str) -> str:
        """Aggregate results from multiple agents"""
        summary_parts = []

        for key, result in results.items():
            try:
                if result.get("status") == "completed":
                    response = result.get("response", {})
                    if isinstance(response, dict):
                        if "root_cause" in response:
                            root_cause = response["root_cause"]
                            if isinstance(root_cause, dict):
                                summary_parts.append(
                                    f"Root Cause: {root_cause.get('primary_cause', 'N/A')}"
                                )
                            elif isinstance(root_cause, str):
                                summary_parts.append(f"Root Cause: {root_cause[:500]}")
                        if "fix_suggestion" in response:
                            fix = response["fix_suggestion"]
                            if isinstance(fix, dict):
                                actions = fix.get('immediate_actions', [])
                                if actions:
                                    summary_parts.append(f"Fix: {actions[0]}")
                            elif isinstance(fix, str):
                                summary_parts.append(f"Fix: {fix[:500]}")
                        if "explanation" in response:
                            explanation = response["explanation"]
                            if isinstance(explanation, str):
                                summary_parts.append(str(explanation[:1000]))
                        if "log_type" in response:
                            summary_parts.append(f"Type: {response['log_type']}")
                        if "severity" in response:
                            summary_parts.append(f"Severity: {response['severity']}")
                        if "summary" in response:
                            summary_parts.append(str(response["summary"])[:500])
                    elif isinstance(response, str):
                        summary_parts.append(response[:500])
                elif result.get("status") == "completed_with_error":
                    summary_parts.append(
                        f"Step completed with warning: {result.get('response', {}).get('warning', 'Unknown warning')}")
                elif result.get("status") == "skipped":
                    summary_parts.append(f"Step skipped: {result.get('reason', 'Previous step failed')}")
                else:
                    summary_parts.append(f"Step incomplete: {result.get('error', 'Unknown')}")
            except Exception as e:
                summary_parts.append(f"Error processing result {key}: {e}")

        # Try LLM aggregation if model available
        try:
            model = await self.get_model("gemma")
            if model and summary_parts:
                prompt = f"""Create a helpful response from these analysis results.

                    Query: {query}
                    Results: {chr(10).join(summary_parts[:10])}
                
                    Response:"""
                final = await model.generate(prompt, max_tokens=1024)
                if final and len(final) > 50:
                    return final
        except Exception:
            pass

        return '\n\n'.join(summary_parts) if summary_parts else "Analysis complete."

    async def _store_in_memory(self, query: str, results: Dict):
        """Store in memory via A2A message, not direct call"""
        try:
            store_msg = A2AMessage.create_request(
                sender_id=self.agent_id,
                sender_type="orchestrator",
                target_type="memory",  # Discover memory agent by type
                task={
                    "action": "store_log_analysis",
                    "query": query,
                    "results": results
                }
            )
            await self.send_message(store_msg)
        except Exception:
            pass

    async def _request_human_input(self, question: str) -> str:
        """Request input from human user"""
        print(f"\n🤔 {question}")
        return input("> ")

    def _get_capability_summary(self) -> str:
        """Get system capability summary"""
        return """
                🤖 I'm a specialized log analysis assistant. I can help with:
                
                📥 LOG EXTRACTION - Files, images (OCR), terminal output
                🧹 LOG PREPROCESSING - Clean, parse, structure logs
                🔍 LOG ANALYSIS - Classify errors, detect intent
                🔧 PROBLEM SOLVING - Root cause analysis, fix suggestions
                🛡️ VALIDATION - Quality checks, safety audits
                💾 MEMORY - Store and retrieve past analyses
                
                How can I help with your logs today?
                """
