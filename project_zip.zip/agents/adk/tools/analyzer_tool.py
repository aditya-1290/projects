"""Analyzer Tools — Classify logs, detect intent, assess severity."""
import httpx
from google.adk.tools import ToolContext

API_BASE = "http://127.0.0.1:8000"


async def _post(endpoint: str, data: dict, timeout: int = 600) -> dict:
    async with httpx.AsyncClient(timeout=timeout) as client:
        response = await client.post(f"{API_BASE}{endpoint}", json=data)
        return response.json() if response.status_code == 200 else {"error": response.text}


async def analyze_logs(clean_logs: str, tool_context: ToolContext) -> str:
    """
    Classify log type, detect user intent, assess severity, and identify patterns.

    Returns:
        Analysis including log_type, severity, intent, patterns, and affected components.
    """
    tool_context.state["status"] = "analyzing"
    result = await _post("/run", {"query": clean_logs})
    return result.get("response", str(result))
