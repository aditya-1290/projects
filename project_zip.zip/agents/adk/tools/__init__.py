"""ADK Tools for Log Analysis Multi-Agent System."""
from agents.adk.tools.extractor_tools import extract_file, extract_text, run_terminal, ocr_image
from agents.adk.tools.preprocessor_tool import preprocess_logs, filter_logs
from agents.adk.tools.analyzer_tool import analyze_logs
from agents.adk.tools.solver_tool import solve_error, explain_error, summarize_logs
from agents.adk.tools.debugger_tool import debug_trace
from agents.adk.tools.critic_tool import validate_solution
from agents.adk.tools.memory_tool import search_memory, store_analysis, trend_analysis
from agents.adk.tools.pipeline_tool import full_pipeline, compare_logs, natural_language_query

ALL_TOOLS = [
    extract_file, extract_text, run_terminal, ocr_image,
    preprocess_logs, filter_logs,
    analyze_logs,
    solve_error, explain_error, summarize_logs,
    debug_trace,
    validate_solution,
    search_memory, store_analysis, trend_analysis,
    full_pipeline, compare_logs, natural_language_query,
]