"""Debugger Tools — Stack trace parsing and code patch generation."""
import httpx
from google.adk.tools import ToolContext

API_BASE = "http://127.0.0.1:8000"


async def _post(endpoint: str, data: dict, timeout: int = 600) -> dict:
    async with httpx.AsyncClient(timeout=timeout) as client:
        response = await client.post(f"{API_BASE}{endpoint}", json=data)
        return response.json() if response.status_code == 200 else {"error": response.text}


async def debug_trace(
        stack_trace: str,
        language: str = "auto",
        tool_context: ToolContext = None,
) -> str:
    """
    Parse a stack trace and generate code patches with language-specific analysis.

    Args:
        stack_trace: Full stack trace text to analyze
        language: Programming language (python, java, javascript, typescript, go, auto)
    """
    if tool_context:
        tool_context.state["status"] = "debugging"

    query = f"debug this {language} stack trace:\n\n{stack_trace[:5000]}"
    result = await _post("/run", {"query": query})
    return result.get("response", str(result))