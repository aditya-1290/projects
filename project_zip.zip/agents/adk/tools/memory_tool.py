"""Memory Tools — Search past analyses, store results, detect trends."""
import httpx
from google.adk.tools import ToolContext

API_BASE = "http://127.0.0.1:8000"


async def _post(endpoint: str, data: dict, timeout: int = 600) -> dict:
    async with httpx.AsyncClient(timeout=timeout) as client:
        response = await client.post(f"{API_BASE}{endpoint}", json=data)
        return response.json() if response.status_code == 200 else {"error": response.text}


async def search_memory(query: str, limit: int = 5, tool_context: ToolContext = None) -> str:
    """
    Search for past log analyses similar to the current case using vector search.

    Args:
        query: Error message or log text to find similar past cases for
        limit: Maximum number of results to return
    """
    if tool_context:
        tool_context.state["status"] = "searching_memory"

    result = await _post("/run", {"query": f"search memory for: {query}"})
    return result.get("response", str(result))


async def store_analysis(
        log_content: str,
        analysis: str = "",
        log_type: str = "unknown",
        tool_context: ToolContext = None,
) -> str:
    """
    Save a completed log analysis for future retrieval.

    Args:
        log_content: Original log text that was analyzed
        analysis: The analysis results to store
        log_type: Detected log type for categorization
    """
    if tool_context:
        tool_context.state["status"] = "storing"

    result = await _post("/run", {
        "query": f"store this analysis (type: {log_type}):\n\nLogs: {log_content[:2000]}\n\nAnalysis: {analysis[:2000]}"
    })
    return result.get("response", str(result))


async def trend_analysis(
        error_type: str = "",
        time_range_start: str = "",
        time_range_end: str = "",
        tool_context: ToolContext = None,
) -> str:
    """
    Detect trends in stored error patterns over time.

    Args:
        error_type: Specific error type to analyze (e.g., "ConnectionRefused")
        time_range_start: Start of time range (ISO format)
        time_range_end: End of time range (ISO format)
    """
    if tool_context:
        tool_context.state["status"] = "analyzing_trends"

    query = f"analyze trends for {error_type}" if error_type else "analyze error trends"
    if time_range_start:
        query += f" from {time_range_start}"
    if time_range_end:
        query += f" to {time_range_end}"

    result = await _post("/run", {"query": query})
    return result.get("response", str(result))
