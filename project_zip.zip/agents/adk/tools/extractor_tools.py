"""Extractor Tools — File, text, terminal, and OCR extraction."""
import httpx
from google.adk.tools import ToolContext

API_BASE = "http://127.0.0.1:8000"


async def _post(endpoint: str, data: dict, timeout: int = 600) -> dict:
    """Helper to post to FastAPI server."""
    async with httpx.AsyncClient(timeout=timeout) as client:
        response = await client.post(f"{API_BASE}{endpoint}", json=data)
        return response.json() if response.status_code == 200 else {"error": response.text}


async def extract_file(path: str, tool_context: ToolContext) -> str:
    """Extract log content from a file on disk."""
    tool_context.state["status"] = "extracting_file"
    result = await _post("/run", {"query": path})
    return result.get("response", str(result))


async def extract_text(content: str, tool_context: ToolContext) -> str:
    """Parse and structure pasted log entries."""
    tool_context.state["status"] = "extracting_text"
    result = await _post("/run", {"query": content})
    return result.get("response", str(result))


async def run_terminal(command: str, tool_context: ToolContext) -> str:
    """Execute a terminal command safely."""
    tool_context.state["status"] = "running_command"
    result = await _post("/run", {"query": f"command:{command}"})
    return result.get("response", str(result))


async def ocr_image(path: str, tool_context: ToolContext) -> str:
    """Extract text from a log screenshot using OCR (no LLM needed)."""
    tool_context.state["status"] = "ocr_processing"

    print(f"[ADK TOOL] ocr_image CALLED with path: {path}", flush=True)  # ADD THIS

    async with httpx.AsyncClient(timeout=300.0) as client:
        response = await client.post(
            f"{API_BASE}/agent/extractor",
            json={
                "action": "extract",
                "source_type": "image",
                "file_path": path
            }
        )
        print(f"[ADK TOOL] Response status: {response.status_code}", flush=True)  # ADD THIS

        if response.status_code == 200:
            data = response.json()
            raw_text = data.get("response", "")
            print(f"[ADK TOOL] Extracted text length: {len(raw_text)}", flush=True)  # ADD THIS
            return raw_text
        else:
            return f"OCR extraction failed: {response.text}"
