"""Solver Tools — Root cause analysis, fix generation, explanations, summaries."""
import httpx
from google.adk.tools import ToolContext

API_BASE = "http://127.0.0.1:8000"


async def _post(endpoint: str, data: dict, timeout: int = 600) -> dict:
    async with httpx.AsyncClient(timeout=timeout) as client:
        response = await client.post(f"{API_BASE}{endpoint}", json=data)
        return response.json() if response.status_code == 200 else {"error": response.text}


async def solve_error(
        clean_logs: str,
        log_type: str = "unknown",
        intent: str = "debugging",
        tool_context: ToolContext = None,
) -> str:
    """
    Find root cause and generate fix suggestions for log errors.

    Args:
        clean_logs: Preprocessed log content
        log_type: Detected log type for context
        intent: User intent (debugging, explanation, optimization, security_audit, health_check)
    """
    if tool_context:
        tool_context.state["status"] = "solving"

    query = f"solve this error (type: {log_type}, intent: {intent}):\n\n{clean_logs[:5000]}"
    result = await _post("/run", {"query": query})
    return result.get("response", str(result))


async def explain_error(clean_logs: str, tool_context: ToolContext) -> str:
    """
    Explain what log entries mean in plain, easy-to-understand language.
    """
    tool_context.state["status"] = "explaining"
    query = f"explain this error in simple terms:\n\n{clean_logs[:5000]}"
    result = await _post("/run", {"query": query})
    return result.get("response", str(result))


async def summarize_logs(clean_logs: str, tool_context: ToolContext) -> str:
    """
    Generate a concise summary of log entries.
    Returns overview with severity breakdown, top errors, and affected services.
    """
    tool_context.state["status"] = "summarizing"
    query = f"summarize these logs:\n\n{clean_logs[:5000]}"
    result = await _post("/run", {"query": query})
    return result.get("response", str(result))
