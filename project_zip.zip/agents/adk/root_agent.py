"""
ADK Root Agent — Entry point for the Log Analysis Multi-Agent System.
Defines the orchestrator agent with all available tools.
"""
from google.adk.agents import LlmAgent
from google.adk.models import LiteLlm

from agents.adk.server import start_model_server, get_model_url
from agents.adk.instructions import ORCHESTRATOR_INSTRUCTION
from agents.adk.tools import ALL_TOOLS


# Start model server before creating agent
start_model_server()

# Create the ADK orchestrator agent
root_agent = LlmAgent(
    name="log_analysis_orchestrator",
    description=(
        "Multi-agent log analysis system powered by local Gemma model. "
        "Analyze logs from files, images, terminal output, or pasted text. "
        "Provides root cause analysis, fix suggestions, code patches, "
        "summaries, comparisons, and trend analysis."
    ),
    model=LiteLlm(
        model="openai/gemma-4-e4b-it",
        api_base=get_model_url(),
        api_key="not-needed",
    ),
    instruction=ORCHESTRATOR_INSTRUCTION,
    tools=ALL_TOOLS,
)
