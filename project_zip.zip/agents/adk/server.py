"""
Model Server Manager for ADK.
Handles starting/stopping the Gemma model server for ADK web UI.
"""
import subprocess
import sys
import time
import requests

MODEL_PATH = "D:/python_tasks/models/gemma-4-E4B-it-Q5_K_M.gguf"
MODEL_PORT = 8083
MODEL_URL = f"http://127.0.0.1:{MODEL_PORT}/v1"
_server_process = None


def start_model_server():
    """Start llama-cpp server if not already running."""
    global _server_process

    try:
        r = requests.get(f"http://127.0.0.1:{MODEL_PORT}/health", timeout=2)
        if r.status_code == 200:
            print("[ADK] Model server already running")
            return True
    except Exception:
        pass

    print("[ADK] Starting local model server...")
    _server_process = subprocess.Popen(
        [
            sys.executable, "-m", "llama_cpp.server",
            "--model", MODEL_PATH,
            "--n_ctx", "16384",
            "--host", "127.0.0.1",
            "--port", str(MODEL_PORT),
        ],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )

    for _ in range(30):
        try:
            r = requests.get(f"http://127.0.0.1:{MODEL_PORT}/health", timeout=2)
            if r.status_code == 200:
                print("[ADK] Model server ready")
                return True
        except Exception:
            time.sleep(1)

    print("[ADK] WARNING: Model server may not be ready")
    return False


def get_model_url():
    return MODEL_URL
