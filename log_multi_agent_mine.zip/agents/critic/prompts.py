"""
Skill Prompts for the Critic Agent.

The Critic validates solutions, detects hallucinations, checks factual
consistency, and ensures output quality before presenting results to users.

Uses Gemma-4-E4B (primary reasoning model).

Skill catalogue:
  SKILL_FACTUAL_CONSISTENCY    — Verify solution facts match log evidence
  SKILL_LOGICAL_COHERENCE      — Check reasoning chain is logically sound
  SKILL_COMPLETENESS_CHECK     — Ensure all aspects of the problem are addressed
  SKILL_SAFETY_AUDIT           — Audit solution for security/safety issues
  SKILL_HALLUCINATION_DETECTION— Detect fabricated or unsupported claims
  SKILL_CONFIDENCE_CALIBRATION — Validate and adjust confidence scores
  SKILL_RETRY_FEEDBACK         — Generate constructive feedback for retry
  SKILL_SOLUTION_COMPARISON    — Compare multiple solutions and pick best
  SKILL_OUTPUT_QUALITY_SCORING — Score overall response quality
  SKILL_EDGE_CASE_TESTING      — Test solution against edge cases
"""


# =============================================================================
# SKILL: Factual Consistency
# Used by: Check 1/5 — Verify solution facts match log evidence
# =============================================================================

SKILL_FACTUAL_CONSISTENCY = """You are a fact-checking specialist validating a log analysis solution.

Original log evidence:
{original_logs}

Proposed solution:
{solution}

Verify every factual claim in the solution against the log evidence:

1. CLAIM EXTRACTION
   → Extract every factual claim from the solution
   → Claims about: error type, affected component, timeline, root cause, severity
   → Claims about: what happened, when it happened, why it happened

2. EVIDENCE MATCHING
   → For each claim, find supporting evidence in the logs
   → If evidence exists → mark as CONFIRMED
   → If evidence contradicts → mark as CONTRADICTED with the contradicting log line
   → If no evidence exists → mark as UNSUPPORTED (potential hallucination)

3. TIMELINE VERIFICATION
   → Check that timestamps in the solution match log timestamps
   → Check that the sequence of events is correct
   → Check that duration claims are reasonable

4. COMPONENT VERIFICATION
   → Check that mentioned services/components actually appear in the logs
   → Check that error types match what's in the logs
   → Check that severity assessment is consistent with log levels

Respond ONLY with valid JSON:
{{
  "passed": true,
  "claims_checked": [
    {{
      "claim": "The auth-service failed due to database connection refused",
      "status": "confirmed|contradicted|unsupported",
      "evidence": "log line supporting or contradicting this claim",
      "confidence": 0.95
    }}
  ],
  "confirmed_count": 5,
  "contradicted_count": 0,
  "unsupported_count": 1,
  "overall_confidence": 0.85,
  "issues": ["any factual issues found"],
  "recommendation": "accept|revise|reject"
}}"""


# =============================================================================
# SKILL: Logical Coherence
# Used by: Check 2/5 — Verify reasoning chain is logical
# =============================================================================

SKILL_LOGICAL_COHERENCE = """You are a logical reasoning validator.

Proposed solution with reasoning chain:
{solution}

Evaluate the logical coherence of the analysis:

1. CAUSE → EFFECT CHAIN
   → Does the identified root cause logically lead to the observed symptoms?
   → Are there gaps in the causal chain? ("A happened, then... B happened" — why?)
   → Are alternative explanations dismissed without reason?

2. REASONING FALLACIES TO CHECK
   → Post hoc ergo propter hoc: "A happened before B, therefore A caused B"
   → Correlation vs causation: just because two things happened together doesn't mean one caused the other
   → Single cause assumption: complex failures often have multiple contributing factors
   → Circular reasoning: "The database failed because it wasn't working"

3. EVIDENCE → CONCLUSION
   → Does the evidence actually support the conclusion?
   → Is the evidence sufficient to draw this conclusion?
   → Are there alternative conclusions that also fit the evidence?

4. FIX → PROBLEM ALIGNMENT
   → Does the proposed fix actually address the identified root cause?
   → Could the fix make things worse?
   → Is the fix proportional to the problem?

Respond ONLY with valid JSON:
{{
  "passed": true,
  "logical_issues": [
    {{
      "type": "causal_gap|fallacy|insufficient_evidence|mismatched_fix",
      "description": "what the logical issue is",
      "location": "which part of the solution has the issue",
      "severity": "critical|major|minor"
    }}
  ],
  "causal_chain_valid": true,
  "alternative_explanations_considered": false,
  "fix_aligned_with_cause": true,
  "overall_confidence": 0.85,
  "recommendation": "accept|revise|reject"
}}"""


# =============================================================================
# SKILL: Completeness Check
# Used by: Check 3/5 — Ensure all aspects addressed
# =============================================================================

SKILL_COMPLETENESS_CHECK = """You are a completeness validator for incident analysis.

Proposed solution:
{solution}

User query / intent: {intent}
Severity: {severity}

Check if the solution addresses everything it should:

1. REQUIRED ELEMENTS (for debugging/root cause analysis)
   ✓ Root cause identified
   ✓ Evidence cited
   ✓ Timeline of events
   ✓ Affected components listed
   ✓ Severity assessed
   ✓ Fix suggested
   ✓ Prevention recommended

2. REQUIRED ELEMENTS (for explanation)
   ✓ Plain-language summary
   ✓ Technical details
   ✓ What users experienced
   ✓ Current status

3. MISSING INFORMATION
   → Are there obvious questions the solution doesn't answer?
   → Is there critical information in the logs that wasn't addressed?
   → Does the solution explain what to do if the fix doesn't work?

4. ACTIONABILITY
   → Can someone act on this solution immediately?
   → Are the steps specific enough? (not just "check the database")
   → Are owners/roles identified for each action?

Respond ONLY with valid JSON:
{{
  "passed": true,
  "missing_elements": [
    {{
      "element": "prevention_recommendation",
      "importance": "high|medium|low",
      "suggested_addition": "what should be added"
    }}
  ],
  "completeness_score": 0-100,
  "actionable": true,
  "actionability_issues": ["steps that are too vague"],
  "suggestions": ["specific things to add"],
  "overall_confidence": 0.85,
  "recommendation": "accept|revise|reject"
}}"""


# =============================================================================
# SKILL: Safety Audit
# Used by: Check 4/5 — Audit solution for safety issues
# =============================================================================

SKILL_SAFETY_AUDIT = """You are a safety auditor for technical solutions.

Proposed solution:
{solution}

Context: {context}

Audit the solution for safety and security issues:

1. FIX SAFETY
   → Could the fix cause data loss?
   → Could the fix cause a service outage?
   → Could the fix affect users not currently impacted?
   → Is the fix reversible? (rollback plan exists?)

2. SECURITY IMPLICATIONS
   → Does the fix weaken security? (disable auth, open firewall)
   → Does the fix expose sensitive information? (log credentials, PII in output)
   → Does the fix create new attack vectors?
   → Are recommended commands safe? (no rm -rf, no SQL without WHERE)

3. RESOURCE SAFETY
   → Does the fix risk resource exhaustion? (unbounded retries, no timeout)
   → Could the fix cause cascading failures?
   → Is there a circuit breaker or rate limit?

4. OPERATIONAL SAFETY
   → Is there a rollback plan?
   → Is the change window appropriate? (not during peak hours)
   → Are the right approvals in place?
   → Is there monitoring to confirm the fix worked?

5. INFORMATION DISCLOSURE
   → Does the solution expose internal architecture details?
   → Does the solution expose credentials, tokens, or keys?
   → Does the solution expose customer data?

Respond ONLY with valid JSON:
{{
  "passed": true,
  "safety_issues": [
    {{
      "type": "data_loss_risk|security_weakening|resource_exhaustion|no_rollback|information_disclosure",
      "severity": "CRITICAL|HIGH|MEDIUM|LOW",
      "description": "what the safety issue is",
      "location": "which part of the solution",
      "mitigation": "how to make it safe"
    }}
  ],
  "rollback_plan_exists": true,
  "security_impact": "none|minor|moderate|significant",
  "data_loss_risk": "none|low|medium|high",
  "safe_for_production": true,
  "required_approvals": ["SRE", "Security"],
  "overall_confidence": 0.85,
  "recommendation": "approve|approve_with_changes|reject"
}}"""


# =============================================================================
# SKILL: Hallucination Detection
# Used by: Check 5/5 — Detect fabricated information
# =============================================================================

SKILL_HALLUCINATION_DETECTION = """You are a hallucination detection specialist for LLM outputs.

Proposed solution:
{solution}

Original log evidence:
{original_logs}

Detect hallucinations (fabricated information not present in the logs):

HALLUCINATION CATEGORIES:

1. INVENTED ERRORS
   → Mentioning error types that don't appear in the logs
   → Example: "NullPointerException" when logs only show "ConnectionError"
   → Check: Does this exact error appear in the original logs?

2. INVENTED COMPONENTS
   → Mentioning services/systems not in the logs
   → Example: "Redis cache failure" when no Redis is mentioned
   → Check: Is this component referenced in the logs?

3. INVENTED TIMELINES
   → Creating timestamps or sequences not in the logs
   → Example: "The failure started at 10:15" when no 10:15 entries exist
   → Check: Are all timestamps traceable to actual log entries?

4. INVENTED METRICS
   → Quoting specific numbers not in the logs
   → Example: "CPU was at 95%" when no CPU data is in the logs
   → Check: Is this metric actually present in the evidence?

5. INVENTED FIXES
   → Suggesting configuration changes for systems not in scope
   → Example: "Update nginx.conf" when nginx isn't involved
   → Check: Is the fix target actually part of the system?

6. OVERCONFIDENCE
   → Claiming high confidence when evidence is thin
   → Example: "Definitively, the root cause is..." with only 2 log lines
   → Check: Is the confidence proportional to the evidence?

Respond ONLY with valid JSON:
{{
  "hallucinations_detected": [
    {{
      "type": "invented_error|invented_component|invented_timeline|invented_metric|invented_fix|overconfidence",
      "claim": "what the solution claimed",
      "evidence_status": "no_evidence|contradicted_by_evidence",
      "contradicting_evidence": "specific log line if exists",
      "severity": "critical|major|minor"
    }}
  ],
  "total_hallucinations": 0,
  "critical_hallucinations": 0,
  "overall_truthfulness": 0-100,
  "confidence_in_assessment": 0.9,
  "recommendation": "accept|revise|reject"
}}"""


# =============================================================================
# SKILL: Confidence Calibration
# Used by: Validate and adjust confidence scores
# =============================================================================

SKILL_CONFIDENCE_CALIBRATION = """You are a confidence calibration specialist.

Solution with self-reported confidence:
{solution}

Claims made: {claim_count}
Evidence items: {evidence_count}
Original confidence: {original_confidence}

Recalibrate the confidence score based on:

1. EVIDENCE QUANTITY
   → < 3 log lines as evidence → reduce confidence by 0.2
   → 3-10 log lines → neutral
   → > 10 log lines with clear pattern → increase by 0.1

2. EVIDENCE QUALITY
   → Exact error messages with stack traces → high quality
   → Generic error messages without details → medium quality
   → Only INFO/WARN logs (no actual errors) → low quality
   → Timestamp gaps in evidence → reduce confidence

3. CAUSAL CLARITY
   → Clear cause → effect chain → high confidence
   → "Might be", "could be", "possibly" → reduce confidence
   → Multiple possible causes listed → reduce confidence by 0.1 per alternative

4. SOLUTION SPECIFICITY
   → Specific file:line:change → high confidence
   → General advice ("check the database") → reduce confidence
   → No rollback plan → reduce confidence

5. HISTORICAL PATTERNS
   → Error class seen before in memory → increase confidence
   → First occurrence of this error pattern → reduce confidence

Recalibrated confidence formula:
  BASE = evidence_support × 0.4 + causal_clarity × 0.3 + solution_specificity × 0.2 + historical_match × 0.1

Respond ONLY with valid JSON:
{{
  "original_confidence": 0.85,
  "calibrated_confidence": 0.72,
  "adjustment_reasons": [
    {{
      "factor": "evidence_quantity",
      "direction": "decrease",
      "amount": 0.1,
      "reason": "Only 2 log lines support the primary conclusion"
    }}
  ],
  "confidence_level": "high|medium|low|very_low",
  "uncertainty_sources": ["what we're unsure about"],
  "would_benefit_from": ["additional logs that would increase confidence"]
}}"""


# =============================================================================
# SKILL: Retry Feedback
# Used by: Generate constructive feedback for retry when solution fails
# =============================================================================

SKILL_RETRY_FEEDBACK = """You are a constructive feedback specialist helping improve a failed analysis.

Failed solution:
{solution}

Failure reasons:
{issues}

Original logs:
{original_logs}

Generate constructive feedback for a retry:

1. WHAT WAS GOOD
   → Acknowledge correct parts of the analysis
   → Don't just list failures — build on strengths
   → Example: "The component identification was correct, but..."

2. WHAT TO FOCUS ON
   → Be specific about what to look at in the retry
   → Point to specific log lines that were missed
   → Suggest a different analytical approach

3. HOW TO IMPROVE
   → Specific questions the retry should answer
   → Alternative hypotheses to consider
   → Evidence to look for

4. RETRY PARAMETERS
   → Should the retry use a different skill prompt?
   → Should the context window be expanded?
   → Should more log lines be included?

Respond ONLY with valid JSON:
{{
  "retry_recommended": true,
  "feedback": "specific constructive feedback",
  "strengths": ["what was correct in the original analysis"],
  "focus_areas": ["what to focus on in the retry"],
  "specific_questions": ["questions the retry should answer"],
  "alternative_hypotheses": ["other possibilities to consider"],
  "suggested_skill": "which skill prompt to use for retry",
  "context_adjustment": "include_more_lines|filter_for_errors|expand_time_range|none",
  "retry_priority": "high|medium|low"
}}"""


# =============================================================================
# SKILL: Solution Comparison
# Used by: Compare multiple solutions and select the best
# =============================================================================

SKILL_SOLUTION_COMPARISON = """You are a solution evaluation specialist comparing multiple analyses.

Solution A (Solver):
{solution_a}

Solution B (Debugger):
{solution_b}

Original logs:
{original_logs}

Compare solutions across these dimensions (score each 1-10):

1. ACCURACY
   → Which solution better matches the log evidence?
   → Which has fewer factual errors?

2. COMPLETENESS
   → Which addresses more aspects of the problem?
   → Which provides better actionability?

3. CLARITY
   → Which is easier to understand?
   → Which explains the reasoning better?

4. CONFIDENCE
   → Which has more realistic confidence?
   → Which acknowledges uncertainty better?

5. SAFETY
   → Which solution is safer to implement?
   → Which has better rollback/risk assessment?

Select the winner and explain why. If both are good, you can merge them.

Respond ONLY with valid JSON:
{{
  "winner": "solution_a|solution_b|merged",
  "scores": {{
    "solution_a": {{"accuracy": 8, "completeness": 7, "clarity": 9, "confidence": 7, "safety": 8}},
    "solution_b": {{"accuracy": 9, "completeness": 8, "clarity": 6, "confidence": 8, "safety": 7}}
  }},
  "reasoning": "why the winner was selected",
  "best_parts_of_loser": ["what to take from the losing solution"],
  "merged_solution": "if merged, the combined solution",
  "confidence": 0.85
}}"""


# =============================================================================
# SKILL: Output Quality Scoring
# Used by: Score the overall quality of the final response
# =============================================================================

SKILL_OUTPUT_QUALITY_SCORING = """You are a response quality evaluator.

Final response:
{response}

Score the response across quality dimensions (each 0-100):

1. CORRECTNESS (40% weight)
   → Are the facts correct?
   → Is the root cause accurately identified?
   → Are fix suggestions appropriate?

2. COMPLETENESS (20% weight)
   → Are all aspects of the problem addressed?
   → Is there actionable next steps?
   → Is prevention covered?

3. CLARITY (20% weight)
   → Is the response well-structured?
   → Is it easy to understand?
   → Is the language appropriate for the audience?

4. ACTIONABILITY (15% weight)
   → Can the user take immediate action?
   → Are steps specific and ordered?
   → Are owners/roles clear?

5. SAFETY (5% weight)
   → Is the response safe to act on?
   → Are risks acknowledged?
   → Is there a fallback plan?

Overall = 0.4×correctness + 0.2×completeness + 0.2×clarity + 0.15×actionability + 0.05×safety

Grade scale:
  A: 90-100  — Excellent, ready for production
  B: 80-89   — Good, minor improvements needed
  C: 70-79   — Adequate, needs revision
  D: 60-69   — Poor, significant revision needed
  F: < 60    — Unacceptable, complete redo

Respond ONLY with valid JSON:
{{
  "overall_score": 85,
  "grade": "B",
  "scores": {{
    "correctness": 88,
    "completeness": 82,
    "clarity": 90,
    "actionability": 78,
    "safety": 85
  }},
  "strengths": ["what's good about this response"],
  "weaknesses": ["what could be improved"],
  "improvement_suggestions": ["specific ways to improve"]
}}"""


# =============================================================================
# SKILL: Edge Case Testing
# Used by: Test the solution against common edge cases
# =============================================================================

SKILL_EDGE_CASE_TESTING = """You are a quality assurance specialist testing a solution against edge cases.

Proposed solution:
{solution}

Original error context:
{context}

Test the solution against these edge cases:

1. WORST CASE
   → What if the root cause is actually worse? (e.g., data corruption, not just connection issue)
   → Would the fix still help or make things worse?

2. RECURRENCE
   → What if the same error happens again 5 minutes after the fix?
   → Does the solution include monitoring to detect this?

3. SCALE
   → What if this error affects 100x more users?
   → Does the solution scale?

4. DEPENDENCY
   → What if a dependency of the fix is also broken?
   → Example: fix requires restarting a service, but the restart script is also broken

5. TIMING
   → What if the fix is applied during peak traffic?
   → What if the fix takes longer than expected?

6. PARTIAL FIX
   → What if the fix only partially resolves the issue?
   → How would you know? What's the next step?

Respond ONLY with valid JSON:
{{
  "edge_cases_handled": [
    {{
      "edge_case": "recurrence",
      "handled": true,
      "how": "monitoring alert will detect repeated failures",
      "gap": null
    }}
  ],
  "edge_cases_missed": [
    {{
      "edge_case": "scale",
      "handled": false,
      "risk": "fix works for 100 users but not 10,000",
      "recommendation": "add load testing before full rollout"
    }}
  ],
  "robustness_score": 0-100,
  "recommended_tests": ["specific tests to run before deploying"],
  "overall_readiness": "production_ready|needs_testing|needs_rework"
}}"""
