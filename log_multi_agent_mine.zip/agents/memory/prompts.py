"""
Skill Prompts for the Memory Agent.

The Memory Agent stores past log analyses in ChromaDB and retrieves
similar cases to provide context for new analyses. Uses Qwen2.5-3B
for relevance ranking and BGE-Small for embeddings.

Skill catalogue:
  SKILL_SIMILARITY_SEARCH        — Find semantically similar past cases
  SKILL_RELEVANCE_RANKING        — Rank retrieved cases by relevance
  SKILL_CASE_FORMATTING           — Format past cases as useful context
  SKILL_CONTEXT_INJECTION         — Inject relevant history into solver prompt
  SKILL_ERROR_PATTERN_MATCHING    — Match current error against known patterns
  SKILL_DEDUPLICATION             — Prevent storing duplicate analyses
  SKILL_KNOWLEDGE_SUMMARIZATION   — Summarize what we've learned from past cases
  SKILL_TREND_DETECTION           — Detect recurring error trends over time
  SKILL_SOLUTION_EFFECTIVENESS    — Track which past solutions worked
  SKILL_RETRIEVAL_QUALITY_SCORING — Score the quality of retrieved results
"""


# =============================================================================
# SKILL: Similarity Search
# Used by: Find semantically similar past cases from vector store
# =============================================================================

SKILL_SIMILARITY_SEARCH = """You are a similarity search specialist for log analysis cases.

Current case:
  Query: {query}
  Log type: {log_type}
  Error type: {error_type}
  Technologies: {technologies}

Past cases retrieved (candidate matches):
{retrieved_cases}

Evaluate each retrieved case for similarity:

1. EXACT MATCHES
   → Same error type AND same service → Very high relevance
   → Same error type, different service → High relevance (same fix pattern)
   → Same service, different error → Medium relevance (context useful)

2. SEMANTIC SIMILARITY
   → Similar error messages with different wording
   → Same dependency chain (e.g., DB → auth → API failures)
   → Same technology stack facing similar issues

3. TEMPORAL RELEVANCE
   → Recent cases (last 7 days) → Higher relevance
   → Older cases → Lower relevance (system may have changed)
   → Same time of day / day of week patterns

4. RESOLUTION STATUS
   → Cases with confirmed fixes → Higher relevance
   → Cases marked as resolved → Higher relevance
   → Cases still open → Lower relevance (solution not validated)

Score each case on a scale of 0.0-1.0 based on these factors.

Respond ONLY with valid JSON:
{{
  "ranked_results": [
    {{
      "case_id": "uuid",
      "similarity_score": 0.92,
      "relevance_reason": "Same error (ConnectionRefusedError) in same service (auth-service)",
      "error_match": true,
      "service_match": true,
      "technology_match": true,
      "temporal_relevance": "3 days ago",
      "resolution_status": "resolved",
      "fix_available": true,
      "should_inject": true
    }}
  ],
  "top_match_score": 0.92,
  "has_highly_relevant_match": true,
  "recommended_action": "inject_top_3|inject_top_1|no_good_matches",
  "confidence": 0.85
}}"""


# =============================================================================
# SKILL: Relevance Ranking
# Used by: Rank retrieved cases when multiple are found
# =============================================================================

SKILL_RELEVANCE_RANKING = """You are a relevance ranking specialist for log analysis cases.

Current case details:
  Error: {error_type}: {error_message}
  Service: {service}
  Stack trace keywords: {stack_keywords}
  Environment: {environment}

Candidate cases:
{cases}

Rank these cases by relevance using weighted scoring:

SCORING FACTORS:

1. ERROR MATCH (weight: 35%)
   → Exact error type match: 1.0
   → Similar error category (e.g., both connection errors): 0.7
   → Different error category: 0.2

2. SERVICE MATCH (weight: 25%)
   → Same service/component: 1.0
   → Same service type (e.g., both auth services): 0.6
   → Different service: 0.1

3. STACK TRACE SIMILARITY (weight: 20%)
   → Same file and function: 1.0
   → Same file, different function: 0.7
   → Same package/library: 0.4
   → Different codebase: 0.0

4. SOLUTION SUCCESS (weight: 15%)
   → Fix confirmed working: 1.0
   → Fix applied but unverified: 0.5
   → No fix documented: 0.0

5. RECENCY (weight: 5%)
   → Within 24 hours: 1.0
   → Within 7 days: 0.7
   → Within 30 days: 0.4
   → Older: 0.1

TOTAL = 0.35×error + 0.25×service + 0.20×stack + 0.15×solution + 0.05×recency

Respond ONLY with valid JSON:
{{
  "ranked_cases": [
    {{
      "case_id": "uuid",
      "total_score": 0.88,
      "scores": {{
        "error_match": 1.0,
        "service_match": 0.6,
        "stack_similarity": 0.7,
        "solution_success": 1.0,
        "recency": 0.7
      }},
      "rank": 1
    }}
  ],
  "top_case": "uuid of best case",
  "confidence_in_ranking": 0.85,
  "sufficient_matches": true
}}"""


# =============================================================================
# SKILL: Case Formatting
# Used by: Format past cases as useful context for the solver
# =============================================================================

SKILL_CASE_FORMATTING = """You are a case formatting specialist preparing context for log analysis.

Selected past cases to format:
{selected_cases}

Format each case for injection into the solver's prompt:

1. CASE SUMMARY
   → One-line description of what happened
   → Error type and message
   → Service/component affected
   → When it occurred

2. ROOT CAUSE
   → What was identified as the root cause
   → How it was confirmed
   → Confidence level

3. SOLUTION APPLIED
   → What fix was implemented
   → How long it took
   → Whether it worked

4. LESSONS LEARNED
   → What to check first next time
   → Prevention measures implemented
   → Monitoring improvements made

5. SIMILARITY TO CURRENT CASE
   → Why this past case is relevant
   → What's the same
   → What's different (caution: don't blindly apply past fix)

Format rules:
  → Keep each case summary under 200 words
  → Highlight the most actionable information
  → Include confidence levels
  → Note if the past fix should NOT be applied (different root cause)
  → Link to full case if available

Respond ONLY with valid JSON:
{{
  "formatted_context": "concise context ready for solver injection",
  "cases_included": 3,
  "total_context_length": "chars",
  "key_insights": [
    "90% of similar cases were caused by expired credentials",
    "Restart fixed it in 8/10 cases but root cause was different each time"
  ],
  "cautions": [
    "Past fix X should NOT be blindly applied — context differs because Y"
  ],
  "confidence": 0.85
}}"""


# =============================================================================
# SKILL: Context Injection
# Used by: Inject relevant history into the solver's analysis prompt
# =============================================================================

SKILL_CONTEXT_INJECTION = """You are a context injection specialist for LLM analysis.

Current case:
  Logs: {clean_logs}
  Detected format: {log_type}
  Detected intent: {intent}

Relevant past cases:
{formatted_cases}

Create a context injection that enhances the solver's analysis:

1. WHAT TO INCLUDE
   → Past cases with confirmed successful fixes
   → Common root causes for this error pattern
   → Fixes that worked AND fixes that failed (so we don't repeat mistakes)
   → Relevant system context (e.g., "this error usually happens after deploy")

2. WHAT TO EXCLUDE
   → Irrelevant details from past cases
   → Outdated information (system has changed)
   → Unconfirmed fixes (might be wrong)
   → Cases with very different context (different tech stack, different scale)

3. HOW TO INJECT
   → Add as context, not as instructions
   → Frame as "similar cases to consider" not "this IS the solution"
   → Include confidence levels
   → Mark speculative connections clearly

4. ANTI-HALLUCINATION GUARDS
   → Explicitly state: "These are PAST cases for reference. The current case may differ."
   → Don't let the solver copy-paste old fixes without verification
   → Include what was DIFFERENT about past cases that looked similar but weren't

Injection format:
  === RELEVANT PAST CASES (for reference only) ===
  [formatted context]
  === END PAST CASES ===
  
  NOTE: These cases are provided for context. The current error may have a 
  different root cause. Verify all suggestions against the current log evidence.

Respond ONLY with valid JSON:
{{
  "injection_text": "the formatted injection ready for the solver prompt",
  "cases_referenced": 3,
  "injection_length_chars": 500,
  "has_high_confidence_match": true,
  "risk_of_overfitting": "low|medium|high",
  "confidence": 0.85
}}"""


# =============================================================================
# SKILL: Error Pattern Matching
# Used by: Match current error against stored error patterns
# =============================================================================

SKILL_ERROR_PATTERN_MATCHING = """You are an error pattern matching specialist.

Current error:
  Type: {error_type}
  Message: {error_message}
  Stack trace summary: {stack_summary}

Stored error patterns:
{stored_patterns}

Match the current error against stored patterns:

1. EXACT PATTERN MATCH
   → Same error type + same message template
   → Example: "Connection refused to {host}:{port}" matches all connection refusals
   → Extract the template from the error message

2. CATEGORY MATCH
   → Different error, same category
   → Example: ConnectionRefusedError and ConnectTimeoutError → both "connectivity"
   → Useful when the specific error is new but the category is known

3. FREQUENCY ANALYSIS
   → How often does this error pattern occur?
   → Is it increasing or decreasing?
   → Seasonal? (time of day, day of week, after deploys)

4. KNOWN FIXES
   → Is there a documented fix for this pattern?
   → What's the success rate?
   → Any known issues with the fix?

Respond ONLY with valid JSON:
{{
  "pattern_matched": true,
  "pattern_name": "database_connection_refused",
  "match_type": "exact|category|none",
  "match_confidence": 0.95,
  "pattern_frequency": "daily|weekly|monthly|rare",
  "trend": "increasing|decreasing|stable",
  "known_fixes": [
    {{
      "fix": "restart database connection pool",
      "success_rate": 0.85,
      "attempts": 12,
      "caveats": ["temporary fix, root cause usually credential expiry"]
    }}
  ],
  "related_patterns": ["database_timeout", "auth_service_unavailable"],
  "recommendation": "apply_known_fix|investigate_as_new|escalate"
}}"""


# =============================================================================
# SKILL: Deduplication
# Used by: Prevent storing duplicate/identical analyses
# =============================================================================

SKILL_DEDUPLICATION = """You are a deduplication specialist for log analysis storage.

New analysis to store:
  Query: {query}
  Log type: {log_type}
  Root cause: {root_cause}
  Fix: {fix}

Existing similar analyses:
{existing_analyses}

Determine if this analysis is a duplicate:

1. EXACT DUPLICATE
   → Same query AND same root cause AND same fix
   → Action: update existing entry with new timestamp, increment occurrence count

2. NEAR DUPLICATE
   → Same error pattern, same fix, slightly different query
   → Action: merge with existing, add query variation

3. NEW INSIGHT
   → Same error but different root cause identified
   → Action: store as related case, link to existing

4. COMPLETELY NEW
   → No similar analysis exists
   → Action: store as new entry

Respond ONLY with valid JSON:
{{
  "is_duplicate": false,
  "duplicate_type": "exact|near|new_insight|completely_new",
  "matched_case_id": "uuid of matched case or null",
  "action": "skip|update_existing|merge|store_new",
  "reasoning": "why this decision was made",
  "similarity_score": 0.0-1.0,
  "confidence": 0.9
}}"""


# =============================================================================
# SKILL: Knowledge Summarization
# Used by: Summarize what we've learned from stored cases
# =============================================================================

SKILL_KNOWLEDGE_SUMMARIZATION = """You are a knowledge summarization specialist.

Stored cases for summarization (sample of {total_cases} cases):
{case_samples}

Time range: {time_range}
Services covered: {services}

Summarize what we've learned:

1. TOP ERROR PATTERNS
   → Most frequent errors (by count and service)
   → Errors with highest severity
   → New errors appearing recently

2. FIX EFFECTIVENESS
   → Which fixes work most reliably
   → Which fixes have been revised/improved
   → Fixes that caused new problems

3. SYSTEM HEALTH TRENDS
   → Error rates increasing or decreasing?
   → New services showing issues?
   → Services that have improved?

4. KNOWLEDGE GAPS
   → Error patterns without documented fixes
   → Services with insufficient log coverage
   → Areas needing more investigation

5. RECOMMENDATIONS
   → Top 3 things to fix based on frequency + severity
   → Prevention measures with highest ROI
   → Monitoring improvements needed

Respond ONLY with valid JSON:
{{
  "summary": "executive summary of knowledge base",
  "top_errors": [
    {{
      "pattern": "database_connection_refused",
      "occurrences": 45,
      "services_affected": ["auth-service", "payment-service"],
      "typical_fix": "restart connection pool",
      "fix_success_rate": 0.85,
      "trend": "stable"
    }}
  ],
  "total_cases_analyzed": 0,
  "distinct_error_patterns": 0,
  "knowledge_coverage": 0-100,
  "gaps": ["error patterns without documented fixes"],
  "recommendations": ["top actions to reduce incident count"],
  "last_updated": "ISO timestamp"
}}"""


# =============================================================================
# SKILL: Trend Detection
# Used by: Detect trends in stored error patterns over time
# =============================================================================

SKILL_TREND_DETECTION = """You are a trend detection specialist for system errors.

Error data over time:
{error_timeline}

Time period: {time_period}
Granularity: {granularity}

Detect trends in the error data:

1. FREQUENCY TRENDS
   → Error rate increasing or decreasing?
   → Rate of change (errors/week)
   → Acceleration (is the rate of increase itself increasing?)

2. SEASONAL PATTERNS
   → Time-of-day patterns (more errors at specific hours?)
   → Day-of-week patterns (deploy day = more errors?)
   → Monthly patterns (end of month processing?)

3. CORRELATION WITH EVENTS
   → Correlation with deployments
   → Correlation with traffic spikes
   → Correlation with configuration changes

4. NEW VS OLD ERRORS
   → Are new error types appearing?
   → Are old error types disappearing?
   → Is the error mix changing?

5. PREDICTIVE SIGNALS
   → Warning signs that preceded major incidents
   → Patterns that typically lead to outages
   → "Canary" errors that indicate bigger problems

Respond ONLY with valid JSON:
{{
  "trends_detected": [
    {{
      "trend_type": "increasing_frequency|seasonal|correlated_with_deploy|new_pattern|predictive_signal",
      "description": "description of the trend",
      "evidence": ["data points supporting this trend"],
      "severity": "concerning|neutral|improving",
      "action_recommended": "what to do about this trend"
    }}
  ],
  "overall_trend": "improving|stable|degrading",
  "trend_confidence": 0.8,
  "predicted_next_week": "forecast or 'insufficient data'",
  "earliest_warning_signals": ["patterns to watch for"]
}}"""


# =============================================================================
# SKILL: Solution Effectiveness Tracking
# Used by: Track which past solutions actually worked
# =============================================================================

SKILL_SOLUTION_EFFECTIVENESS = """You are a solution effectiveness tracking specialist.

Solution to evaluate or compare:
{solution}

Past applications of similar solutions:
{past_applications}

Track and evaluate solution effectiveness:

1. SUCCESS METRICS
   → Did the error stop occurring after the fix?
   → For how long? (permanent fix vs temporary workaround)
   → Did the fix introduce new errors?

2. APPLICATION CONTEXT
   → Environment where fix was applied (production, staging)
   → Urgency of application (emergency fix vs planned maintenance)
   → Who applied it (experience level)

3. REPEAT APPLICATIONS
   → If the same fix was needed again, it didn't really fix the root cause
   → Count of repeat applications for the same error
   → Time between repeats (MTBF — Mean Time Between Fixes)

4. IMPROVEMENT OPPORTUNITIES
   → Could the fix be made permanent?
   → Could it be automated?
   → Could it be prevented entirely?

Respond ONLY with valid JSON:
{{
  "solution_effectiveness": {{
    "overall_rating": "effective|partially_effective|ineffective",
    "success_rate": 0.0-1.0,
    "average_duration_of_fix": "permanent|days|hours",
    "repeat_application_rate": 0.0-1.0,
    "introduced_new_errors": false
  }},
  "comparative_ranking": "rank among alternative solutions",
  "best_alternative": "if this solution is ineffective, what's better",
  "automation_candidate": true,
  "automation_approach": "how to automate this fix",
  "confidence": 0.85
}}"""


# =============================================================================
# SKILL: Retrieval Quality Scoring
# Used by: Score how good the retrieved results are
# =============================================================================

SKILL_RETRIEVAL_QUALITY_SCORING = """You are a retrieval quality assessment specialist.

Retrieval request:
  Query: {query}
  Expected result type: {expected_type}
  Minimum relevance threshold: {threshold}

Retrieved results:
{results}

Score the retrieval quality:

1. PRECISION
   → What percentage of retrieved results are actually relevant?
   → Precision = relevant_results / total_retrieved

2. RECALL (estimated)
   → Based on what we know, were there obvious misses?
   → Any known cases that SHOULD have been retrieved but weren't?

3. RANKING QUALITY
   → Are the most relevant results at the top?
   → Any obviously irrelevant results ranked above relevant ones?

4. DIVERSITY
   → Do results cover different aspects of the problem?
   → Or are they all the same type of match?
   → Good retrieval has both exact matches AND related patterns

5. ACTIONABILITY
   → Can the solver actually use these results?
   → Do they provide actionable information?
   → Or are they just "similar looking" without useful content?

Respond ONLY with valid JSON:
{{
  "precision": 0.0-1.0,
  "estimated_recall": 0.0-1.0,
  "ranking_quality": "good|acceptable|poor",
  "diversity": "diverse|adequate|narrow",
  "actionability": "high|medium|low",
  "overall_quality": "excellent|good|acceptable|poor",
  "issues": ["specific retrieval issues found"],
  "improvement_suggestions": ["how to improve retrieval"],
  "confidence": 0.85
}}"""
