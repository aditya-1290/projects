"""
Solver Agent

Uses Gemma-4-E4B for root cause analysis, fix generation, and explanations.
This is the core reasoning agent in the pipeline.
"""

from typing import Dict, Any, List

from agents.base_agent import BaseAgent, A2AMessage, MessageType, AgentResponse


class SolverAgent(BaseAgent):
    """Analyzes logs and generates solutions"""

    def __init__(self):
        super().__init__("solver_v1", "agents/solver/capabilities.json")

    async def process(self, message: A2AMessage) -> A2AMessage:
        """Process log analysis request and generate solutions"""
        task = message.task or {}
        context = message.context or {}

        action = task.get("action", "solve")

        if action == "analyze_root_cause":
            return await self._handle_root_cause_analysis(message)
        elif action == "generate_fix":
            return await self._handle_fix_generation(message)
        elif action == "explain":
            return await self._handle_explanation(message)
        else:
            # Full solve pipeline
            return await self._handle_full_solve(message)

    async def _handle_full_solve(self, message: A2AMessage) -> A2AMessage:
        """Run the complete solve pipeline"""
        task = message.task or {}
        context = message.context or {}

        clean_logs = context.get("clean_logs", "") or task.get("clean_logs", "")
        log_type = context.get("log_type", "unknown")
        intent = context.get("intent", "debugging")

        if not clean_logs:
            return A2AMessage(
                message_type=MessageType.ERROR,
                sender_id=self.agent_id,
                sender_type="solver",
                target_id=message.sender_id,
                correlation_id=message.message_id,
                error="No logs provided for analysis"
            )

        self.log(f"Solving: type={log_type}, intent={intent}")

        # 🔥 Extract key error line manually (improves LLM performance)
        error_line = None
        for line in clean_logs.split("\n"):
            if "Error" in line or "Exception" in line:
                error_line = line.strip()
                break

        context["error_line"] = error_line

        try:
            model = await self.get_model("gemma")

            # Step 1: Root cause analysis
            self.log("Step 1/3: Root cause analysis...")
            # 🔥 BOOST SIGNAL FROM CONTEXT
            if "NameError" in clean_logs:
                context["error_hint"] = "NameError"
            root_cause = await self._analyze_root_cause(
                clean_logs + f"\n\nKey Error Line:\n{error_line}",
                log_type,
                model
            )

            # Step 2: Generate fix
            self.log("Step 2/3: Generating fix...")
            fix = await self._generate_fix(
                clean_logs, root_cause, log_type, model
            )

            # Step 3: Generate explanation
            self.log("Step 3/3: Generating explanation...")
            explanation = await self._generate_explanation(
                root_cause, fix, intent, model
            )

            return A2AMessage(
                message_type=MessageType.RESPONSE,
                sender_id=self.agent_id,
                sender_type="solver",
                target_id=message.sender_id,
                correlation_id=message.message_id,
                response={
                    "root_cause": root_cause,
                    "fix_suggestion": fix,
                    "explanation": explanation,
                    "log_type": log_type,
                    "intent": intent,

                    # 🔥 CRITICAL ADDITION
                    "solution": {
                        "root_cause": root_cause,
                        "fix": fix,
                        "explanation": explanation
                    },

                    # 🔥 pass forward for critic
                    "analysis": context.get("analysis")
                },
                confidence=self._calculate_confidence(root_cause, fix),
                caveats=self._generate_caveats(log_type),
                context=message.context
            )

        except Exception as e:
            self.log(f"Error: {e}", "ERROR")
            return A2AMessage(
                message_type=MessageType.ERROR,
                sender_id=self.agent_id,
                sender_type="solver",
                target_id=message.sender_id,
                correlation_id=message.message_id,
                error=f"Analysis failed: {str(e)}"
            )

    async def _analyze_root_cause(
            self, logs: str, log_type: str, model
    ) -> Dict:
        """Analyze logs to find root cause"""
        from agents.solver.error_analyzer import ErrorAnalyzer
        analyzer = ErrorAnalyzer()
        return await analyzer.analyze(logs, log_type, model)

    async def _generate_fix(
            self, logs: str, root_cause: Dict, log_type: str, model
    ) -> Dict:
        """Generate fix suggestions"""
        from agents.solver.fix_generator import FixGenerator
        generator = FixGenerator()
        return await generator.generate(logs, root_cause, log_type, model)

    async def _generate_explanation(
            self, root_cause: Dict, fix: Dict, intent: str, model
    ) -> str:
        """Generate human-readable explanation"""
        from agents.solver.explanation_generator import ExplanationGenerator
        generator = ExplanationGenerator()
        return await generator.generate(root_cause, fix, intent, model)

    async def _handle_root_cause_analysis(self, message: A2AMessage) -> A2AMessage:
        """Handle explicit root cause analysis request"""
        # Similar to _handle_full_solve but only step 1
        task = message.task or {}
        context = message.context or {}

        clean_logs = context.get("clean_logs", "") or task.get("clean_logs", "")
        log_type = context.get("log_type", "unknown")

        model = await self.get_model("gemma")
        root_cause = await self._analyze_root_cause(clean_logs, log_type, model)

        return A2AMessage(
            message_type=MessageType.RESPONSE,
            sender_id=self.agent_id,
            sender_type="solver",
            target_id=message.sender_id,
            correlation_id=message.message_id,
            response={"root_cause": root_cause},
            confidence=root_cause.get("confidence", 0.7)
        )

    async def _handle_fix_generation(self, message: A2AMessage) -> A2AMessage:
        """Handle explicit fix generation request"""
        task = message.task or {}
        context = message.context or {}

        clean_logs = context.get("clean_logs", "")
        root_cause = context.get("root_cause", task.get("root_cause", {}))
        log_type = context.get("log_type", "unknown")

        model = await self.get_model("gemma")
        fix = await self._generate_fix(clean_logs, root_cause, log_type, model)

        return A2AMessage(
            message_type=MessageType.RESPONSE,
            sender_id=self.agent_id,
            sender_type="solver",
            target_id=message.sender_id,
            correlation_id=message.message_id,
            response={"fix_suggestion": fix},
            confidence=0.8
        )

    async def _handle_explanation(self, message: A2AMessage) -> A2AMessage:
        """Handle explicit explanation request"""
        task = message.task or {}
        context = message.context or {}

        root_cause = context.get("root_cause", task.get("root_cause", {}))
        fix = context.get("fix_suggestion", task.get("fix", {}))
        intent = context.get("intent", "explanation")

        model = await self.get_model("gemma")
        explanation = await self._generate_explanation(root_cause, fix, intent, model)

        return A2AMessage(
            message_type=MessageType.RESPONSE,
            sender_id=self.agent_id,
            sender_type="solver",
            target_id=message.sender_id,
            correlation_id=message.message_id,
            response={"explanation": explanation},
            confidence=0.85
        )

    def _calculate_confidence(self, root_cause: Dict, fix: Dict) -> float:
        """Calculate overall confidence score"""
        rc_conf = root_cause.get("confidence", 0.5)
        fix_conf = fix.get("confidence", 0.5)
        return round((rc_conf + fix_conf) / 2, 2)

    def _generate_caveats(self, log_type: str) -> List[str]:
        """Generate appropriate caveats"""
        caveats = [
            "This analysis is based on the provided logs only",
            "Verify all suggestions in a test environment first",
            "Consider system-specific configurations"
        ]

        if log_type == "database_error":
            caveats.append("Database changes should be reviewed by a DBA")
        elif log_type == "security":
            caveats.append("Security fixes may require immediate attention")
        elif log_type == "network_error":
            caveats.append("Network changes may affect connectivity")

        return caveats