"""
Log Parser - Structures cleaned logs into organized format
"""

import re
from typing import Dict, List, Optional, Any
from datetime import datetime


class LogParser:
    """Parses cleaned logs into structured entries"""

    # Common log patterns
    LOG_PATTERNS = {
        "standard": re.compile(
            r'^\[?(?P<timestamp>\d{4}[-/]\d{2}[-/]\d{2}[T\s]\d{2}:\d{2}:\d{2}(?:\.\d+)?)\]?\s+'
            r'\[?(?P<level>DEBUG|INFO|WARN(?:ING)?|ERROR|ERR|CRIT(?:ICAL)?|FATAL|TRACE|NOTICE)\]?\s+'
            r'(?P<message>.*)',
            re.IGNORECASE
        ),
        "syslog": re.compile(
            r'^(?P<timestamp>\w{3}\s+\d+\s+\d{2}:\d{2}:\d{2})\s+'
            r'(?P<hostname>\S+)\s+'
            r'(?P<process>\S+?)(?:\[(?P<pid>\d+)\])?:\s+'
            r'(?P<message>.*)'
        ),
        "apache": re.compile(
            r'^(?P<ip>\S+)\s+\S+\s+\S+\s+'
            r'\[(?P<timestamp>\d{2}/\w{3}/\d{4}:\d{2}:\d{2}:\d{2}\s+[\+\-]\d{4})\]\s+'
            r'"(?P<method>\S+)\s+(?P<path>\S+)\s+\S+"\s+'
            r'(?P<status>\d+)\s+(?P<size>\S+)'
        ),
        "json_log": re.compile(r'^\s*\{.*\}\s*$'),
        "stack_trace": re.compile(r'^\s+at\s+|\s+\.\.\.\s+\d+\s+more|^Caused by:'),
        "timestamp_only": re.compile(
            r'^(?P<timestamp>\d{4}[-/]\d{2}[-/]\d{2}[T\s]\d{2}:\d{2}:\d{2}(?:\.\d+)?)\s+'
            r'(?P<message>.*)'
        )
    }

    async def parse(self, cleaned_logs: str, model=None) -> Dict[str, Any]:
        """
        Parse cleaned logs into structured format.

        Returns:
            {
                "format": "standard" | "syslog" | "apache" | "json" | "text",
                "entries": List of parsed log entries,
                "total_lines": int,
                "parsed_lines": int,
                "fields_found": List[str]
            }
        """
        lines = cleaned_logs.strip().split('\n')

        # Detect format
        detected_format = self._detect_format(lines)

        # Parse based on format
        if detected_format == "json":
            return await self._parse_json_format(cleaned_logs)

        entries = []
        fields_found = set()

        for line in lines:
            if not line.strip():
                continue

            entry = self._parse_line(line, detected_format)
            entries.append(entry)

            if entry.get("parsed"):
                fields_found.update(entry.keys())

        result = {
            "format": detected_format,
            "entries": entries,
            "total_lines": len(lines),
            "parsed_lines": sum(1 for e in entries if e.get("parsed")),
            "fields_found": list(fields_found - {"raw", "parsed"})
        }

        # If model available, do intelligent enrichment
        if model and entries:
            result = await self._intelligent_enrich(result, model)

        return result

    def _detect_format(self, lines: List[str]) -> str:
        """Detect the log format from sample lines"""
        sample = '\n'.join(lines[:20])  # First 20 lines

        # Check for JSON
        json_lines = [l for l in lines[:10] if l.strip().startswith('{')]
        if len(json_lines) > len(lines[:10]) * 0.5:
            return "json"

        # Check Apache
        apache_matches = sum(1 for l in lines[:10] if self.LOG_PATTERNS["apache"].match(l))
        if apache_matches > len(lines[:10]) * 0.5:
            return "apache"

        # Check syslog
        syslog_matches = sum(1 for l in lines[:10] if self.LOG_PATTERNS["syslog"].match(l))
        if syslog_matches > len(lines[:10]) * 0.5:
            return "syslog"

        # Check standard
        standard_matches = sum(1 for l in lines[:10] if self.LOG_PATTERNS["standard"].match(l))
        if standard_matches > len(lines[:10]) * 0.3:
            return "standard"

        return "text"

    def _parse_line(self, line: str, format_type: str) -> Dict:
        """Parse a single log line"""
        entry = {
            "raw": line,
            "parsed": False
        }

        # Try format-specific pattern first
        if format_type in self.LOG_PATTERNS:
            pattern = self.LOG_PATTERNS[format_type]
            match = pattern.match(line)
            if match:
                entry.update(match.groupdict())
                entry["parsed"] = True
                return entry

        # Try all patterns
        for pattern_name, pattern in self.LOG_PATTERNS.items():
            if pattern_name == "json_log" or pattern_name == "stack_trace":
                continue

            match = pattern.match(line)
            if match:
                entry.update(match.groupdict())
                entry["parsed"] = True
                entry["detected_format"] = pattern_name
                return entry

        # Last resort: timestamp + message
        ts_match = self.LOG_PATTERNS["timestamp_only"].match(line)
        if ts_match:
            entry.update(ts_match.groupdict())
            entry["parsed"] = True
            entry["detected_format"] = "timestamp_only"
            return entry

        # Check if it's a stack trace line
        if self.LOG_PATTERNS["stack_trace"].match(line):
            entry["is_stack_trace"] = True
            entry["message"] = line.strip()
            entry["parsed"] = True

        return entry

    async def _parse_json_format(self, content: str) -> Dict:
        """Parse JSON formatted logs"""
        from agents.extractor.parsers.json_parser import JSONParser
        parser = JSONParser()
        return await parser.parse(content)

    async def _intelligent_enrich(self, result: Dict, model) -> Dict:
        """Use LLM to enrich parsed logs"""
        unparsed = [e for e in result["entries"] if not e.get("parsed")]

        if not unparsed:
            return result

        # Only process a sample
        sample = '\n'.join([e["raw"] for e in unparsed[:10]])

        prompt = f"""Analyze these unparsed log lines and identify:
1. The likely log format
2. The fields present (timestamp, level, message, etc.)
3. Any patterns

Log lines:
{sample}

Respond with JSON:
{{
    "format": "format_name",
    "fields": ["field1", "field2"],
    "pattern_description": "description"
}}"""

        try:
            response = await model.generate(prompt, max_tokens=512)
            # Try to parse JSON from response
            import json
            try:
                enrichment = json.loads(response)
                result["format"] = enrichment.get("format", result["format"])
                result["fields_found"].extend(enrichment.get("fields", []))
                result["fields_found"] = list(set(result["fields_found"]))
            except json.JSONDecodeError:
                pass
        except Exception:
            pass

        return result