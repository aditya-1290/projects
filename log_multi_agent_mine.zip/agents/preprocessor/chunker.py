"""
Log Chunker - Splits large logs into manageable chunks
"""

import re
from typing import Dict, List, Any
from datetime import datetime


class LogChunker:
    """Splits large log sets into processable chunks"""

    # Target chunk sizes (in characters)
    DEFAULT_CHUNK_SIZE = 4000
    MAX_CHUNK_SIZE = 6000
    MIN_CHUNK_SIZE = 500

    # Chunk boundary patterns (prefer splitting here)
    BOUNDARY_PATTERNS = [
        re.compile(r'^\d{4}-\d{2}-\d{2}'),  # Timestamp start
        re.compile(r'^\['),  # Bracket start
        re.compile(r'^\{'),  # JSON start
        re.compile(r'^\w{3}\s+\d+\s+\d{2}:\d{2}'),  # Syslog timestamp
    ]

    async def chunk(
            self,
            parsed_logs: Dict,
            model=None,
            chunk_size: int = None
    ) -> Dict:
        """
        Chunk parsed logs if they exceed the size limit.

        Strategy:
        1. If total content fits in one chunk, return as-is
        2. If chunking needed, try semantic chunking with model
        3. Fall back to boundary-based chunking
        """
        chunk_size = chunk_size or self.DEFAULT_CHUNK_SIZE

        entries = parsed_logs.get("entries", [])

        # Get content as text
        content = self._entries_to_text(entries)
        total_length = len(content)
        total_lines = len(entries)

        # Check if chunking is needed
        if total_length <= chunk_size:
            return {
                "content": content,
                "chunks": [content],
                "is_chunked": False,
                "chunk_count": 1,
                "total_length": total_length,
                "total_lines": total_lines,
                "format": parsed_logs.get("format", "text")
            }

        # Need chunking
        if model:
            chunks = await self._semantic_chunk(content, model, chunk_size)
        else:
            chunks = self._boundary_chunk(content, chunk_size)

        # Add overlap context to each chunk
        chunks = self._add_overlap(chunks)

        return {
            "content": content,
            "chunks": chunks,
            "is_chunked": True,
            "chunk_count": len(chunks),
            "total_length": total_length,
            "total_lines": total_lines,
            "format": parsed_logs.get("format", "text"),
            "chunk_sizes": [len(c) for c in chunks]
        }

    def _entries_to_text(self, entries: List[Dict]) -> str:
        """Convert entries back to text"""
        lines = []
        for entry in entries:
            if entry.get("raw"):
                lines.append(entry["raw"])
            elif entry.get("message"):
                ts = entry.get("timestamp_iso", "")
                level = entry.get("level_normalized", "")
                msg = entry["message"]
                if ts and level:
                    lines.append(f"{ts} [{level}] {msg}")
                elif ts:
                    lines.append(f"{ts} {msg}")
                else:
                    lines.append(msg)

        return '\n'.join(lines)

    async def _semantic_chunk(
            self, content: str, model, chunk_size: int
    ) -> List[str]:
        """Use LLM to find semantic chunk boundaries"""
        # For very large content, sample first
        if len(content) > 10000:
            sample = content[:5000] + "\n...[truncated]...\n" + content[-2000:]
        else:
            sample = content

        prompt = f"""Split these log entries into coherent chunks.
Each chunk should:
- Be at most {chunk_size} characters
- End at natural boundaries (end of related events, timestamp changes)
- Not split stack traces or related error messages

Return the chunks separated by "---CHUNK---".

Logs:
{sample[:3000]}

Chunks:"""

        try:
            response = await model.generate(prompt, max_tokens=2048)
            chunks = response.split("---CHUNK---")
            return [c.strip() for c in chunks if c.strip()]
        except Exception:
            return self._boundary_chunk(content, chunk_size)

    def _boundary_chunk(self, content: str, chunk_size: int) -> List[str]:
        """Split content at natural boundaries"""
        lines = content.split('\n')
        chunks = []
        current_chunk = []
        current_size = 0

        for line in lines:
            line_size = len(line) + 1  # +1 for newline

            # Check if adding this line exceeds chunk size
            if current_size + line_size > chunk_size and current_chunk:
                # Check if this is a good boundary
                if self._is_boundary(line):
                    # Save current chunk
                    chunks.append('\n'.join(current_chunk))
                    current_chunk = [line]
                    current_size = line_size
                else:
                    # Find last boundary in current chunk
                    last_boundary_idx = self._find_last_boundary(current_chunk)

                    if last_boundary_idx > 0:
                        # Split at last boundary
                        chunks.append('\n'.join(current_chunk[:last_boundary_idx]))
                        current_chunk = current_chunk[last_boundary_idx:] + [line]
                        current_size = sum(len(l) + 1 for l in current_chunk)
                    else:
                        # Force split
                        chunks.append('\n'.join(current_chunk))
                        current_chunk = [line]
                        current_size = line_size
            else:
                current_chunk.append(line)
                current_size += line_size

        # Don't forget the last chunk
        if current_chunk:
            chunks.append('\n'.join(current_chunk))

        return chunks

    def _is_boundary(self, line: str) -> bool:
        """Check if a line is a good chunk boundary"""
        for pattern in self.BOUNDARY_PATTERNS:
            if pattern.match(line.strip()):
                return True
        return False

    def _find_last_boundary(self, lines: List[str]) -> int:
        """Find the index of the last boundary line"""
        for i in range(len(lines) - 1, -1, -1):
            if self._is_boundary(lines[i]):
                return i
        return -1

    def _add_overlap(self, chunks: List[str], overlap_lines: int = 2) -> List[str]:
        """Add overlap between chunks for context preservation"""
        if len(chunks) <= 1:
            return chunks

        overlapped = []
        for i, chunk in enumerate(chunks):
            if i == 0:
                # First chunk: add next chunk's first lines as preview
                next_lines = chunks[i + 1].split('\n')[:overlap_lines]
                if next_lines:
                    chunk += '\n\n[Next chunk preview]\n' + '\n'.join(next_lines)
            elif i == len(chunks) - 1:
                # Last chunk: add previous chunk's last lines as context
                prev_lines = chunks[i - 1].split('\n')[-overlap_lines:]
                if prev_lines:
                    chunk = '[Previous chunk context]\n' + '\n'.join(prev_lines) + '\n\n' + chunk
            else:
                # Middle chunk: add both
                prev_lines = chunks[i - 1].split('\n')[-overlap_lines:]
                next_lines = chunks[i + 1].split('\n')[:overlap_lines]

                prefix = '[Previous context]\n' + '\n'.join(prev_lines) if prev_lines else ''
                suffix = '\n\n[Next preview]\n' + '\n'.join(next_lines) if next_lines else ''

                chunk = prefix + '\n\n' + chunk + suffix if prefix else chunk
                chunk = chunk + suffix if suffix else chunk

            overlapped.append(chunk)

        return overlapped