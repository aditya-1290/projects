"""
Skill Prompts for the Preprocessor Agent.

The Preprocessor cleans, parses, normalizes, and chunks raw logs
before analysis. Uses Qwen2.5-3B for intelligent processing.

Skill catalogue:
  SKILL_LOG_CLEANING            — Remove noise, filter irrelevant lines
  SKILL_NOISE_REMOVAL           — Strip ANSI codes, binary garbage, UI chrome
  SKILL_LOG_PARSING             — Parse unstructured logs into structured format
  SKILL_TIMESTAMP_NORMALIZATION — Normalize timestamps to UTC ISO-8601
  SKILL_IP_NORMALIZATION        — Normalize IP addresses, handle IPv4/IPv6
  SKILL_CHUNK_STRATEGY          — Decide how to split large logs for analysis
  SKILL_STRUCTURE_DETECTION     — Detect log structure (key=value, JSON-like, freeform)
  SKILL_LOG_FORMAT_DETECTION    — Auto-detect log format from content
  SKILL_FIELD_EXTRACTION        — Extract common fields (timestamp, level, message, service)
  SKILL_LOG_DEDUPLICATION       — Remove duplicate/repeated log entries
  SKILL_MULTILINE_MERGING       — Merge multi-line entries (stack traces, SQL queries)
"""


# =============================================================================
# SKILL: Log Cleaning
# Used by: Step 1/4 — Clean raw logs
# =============================================================================

SKILL_LOG_CLEANING = """You are a log cleaning specialist.

Raw log content:
{raw_logs}

Cleaning operations to apply:

1. REMOVE EMPTY LINES
   → Delete lines that contain only whitespace
   → But preserve intentional blank line separators between log entries

2. REMOVE HEADER/FOOTER NOISE
   → Page headers ("Page 1 of 5", "Log file: ...")
   → Viewer UI chrome (tab names, window titles, scroll indicators)
   → Line numbers added by text editors
   → Copyright notices, license headers

3. NORMALIZE WHITESPACE
   → Collapse multiple spaces to single space (except in stack traces)
   → Remove trailing whitespace
   → Normalize tabs to spaces (preserving indentation in code snippets)

4. REMOVE NON-LOG CONTENT
   → SQL query results mixed with logs
   → Binary garbage / non-printable characters
   → Configuration file contents accidentally included
   → Debug print statements from unrelated code

5. FILTER BY RELEVANCE
   → Keep: ERROR, WARN, FATAL, CRITICAL, Exception, Traceback
   → Keep: Timestamped entries
   → Remove: DEBUG/TRACE unless specifically requested
   → Remove: Repeated informational heartbeats (keep first and last)

6. REPAIR MINOR DAMAGE
   → Join split log lines (line wraps from terminal width)
   → Fix truncated timestamps where possible
   → Restore missing newlines between entries

Respond ONLY with valid JSON:
{{
  "cleaned_logs": "the cleaned log content",
  "lines_removed": 0,
  "lines_kept": 0,
  "removal_reasons": {{
    "empty_lines": 0,
    "header_footer": 0,
    "noise": 0,
    "non_log": 0,
    "debug_trace": 0,
    "duplicate_heartbeats": 0
  }},
  "repairs_made": ["list of specific repairs"],
  "quality_score": 0-100,
  "notes": "any important observations about the cleaning process"
}}"""


# =============================================================================
# SKILL: Noise Removal
# Used by: Detailed noise filtering
# =============================================================================

SKILL_NOISE_REMOVAL = """You are a noise filtering specialist for log data.

Log content:
{raw_logs}

Remove these types of noise:

1. ANSI ESCAPE CODES
   → Color codes: \\x1b[31m, \\033[0m, \\e[32m
   → Cursor movement: \\x1b[H, \\x1b[2J
   → Bold/underline/reset sequences
   → Replace with plain text equivalents

2. BINARY / NON-PRINTABLE CHARACTERS
   → Null bytes (\\x00)
   → Control characters (\\x01-\\x08, \\x0B-\\x0C, \\x0E-\\x1F)
   → High Unicode that isn't actual text
   → Replace with [BINARY] or [NON_PRINTABLE] markers

3. LOG FRAMEWORK OVERHEAD
   → Logback/Log4j pattern headers that repeat on every line
   → Spring Boot banner
   → Application startup ASCII art
   → Framework version dumps

4. VIEWER / EDITOR ARTIFACTS
   → Line numbers inserted by text editors ("  1  ", "  42 | ")
   → Selection highlights copied accidentally
   → Cursor position indicators
   → Scrollbar artifacts

5. SHELL PROMPTS
   → "user@host:~$ " prefixes
   → ">>> " Python prompts
   → "PS C:\\>" PowerShell prompts
   → "# " root shell prompts

Respond ONLY with valid JSON:
{{
  "cleaned_content": "content with noise removed",
  "noise_items_removed": 0,
  "noise_types_found": ["ansi_codes", "binary", "framework_overhead", "shell_prompts"],
  "replaced_markers": ["list of [MARKER] replacements made"],
  "confidence": 0.95
}}"""


# =============================================================================
# SKILL: Log Parsing
# Used by: Step 2/4 — Parse cleaned logs into structured format
# =============================================================================

SKILL_LOG_PARSING = """You are a log parsing specialist.

Cleaned log content:
{cleaned_logs}

Parse each log entry into a structured format. Extract these fields where present:

STANDARD FIELDS:
  → timestamp: ISO-8601 UTC format
  → level: CRITICAL|ERROR|WARN|WARNING|INFO|DEBUG|TRACE
  → message: the main log message
  → service: service/component name
  → host: hostname or IP
  → pid: process ID
  → tid: thread ID

ERROR FIELDS:
  → error_type: exception class name
  → error_message: exception message
  → stack_trace: full stack trace as array of frames
  → file: source file
  → line: line number
  → function: function/method name

REQUEST FIELDS:
  → method: HTTP method
  → path: URL path
  → status: HTTP status code
  → duration_ms: request duration
  → user_agent: client user agent
  → ip: client IP

DATABASE FIELDS:
  → query: SQL query (truncated if very long)
  → duration_ms: query duration
  → rows_affected: number of rows

Parse rules:
  - If a field cannot be extracted, set it to null, do not guess
  - For multi-line entries (stack traces, SQL), group them as a single entry
  - Preserve the original raw text as _raw field
  - Assign each entry a sequential index starting from 0

Respond ONLY with valid JSON:
{{
  "entries": [
    {{
      "index": 0,
      "timestamp": "2024-01-15T10:23:45Z",
      "level": "ERROR",
      "message": "Database connection failed",
      "service": "auth-service",
      "host": "auth-pod-1",
      "pid": 1234,
      "tid": 5678,
      "error_type": "ConnectionRefusedError",
      "error_message": "Connection refused to postgres:5432",
      "stack_trace": ["line 1", "line 2"],
      "file": "db/connection.py",
      "line": 42,
      "function": "connect",
      "method": null,
      "path": null,
      "status": null,
      "duration_ms": null,
      "query": null,
      "_raw": "original log line"
    }}
  ],
  "total_entries": 0,
  "parse_success_rate": 0.0-1.0,
  "unparseable_lines": ["lines that couldn't be parsed"],
  "format_detected": "structured|semi_structured|unstructured",
  "confidence": 0.9
}}"""


# =============================================================================
# SKILL: Timestamp Normalization
# Used by: Step 3/4 — Normalize all timestamps
# =============================================================================

SKILL_TIMESTAMP_NORMALIZATION = """You are a timestamp normalization specialist.

Parsed log entries:
{parsed_logs}

Normalize all timestamps to UTC ISO-8601 format (YYYY-MM-DDTHH:MM:SS.mmmZ).

Common input formats to handle:

APACHE FORMATS:
  [15/Jan/2024:10:23:45 +0000] → 2024-01-15T10:23:45.000Z
  [Mon Jan 15 10:23:45.123456 2024] → 2024-01-15T10:23:45.123Z

SYSLOG FORMATS:
  Oct 11 22:14:15 → 2024-10-11T22:14:15.000Z (assume current year)
  <34>Oct 11 22:14:15 → 2024-10-11T22:14:15.000Z

ISO VARIANTS:
  2024-01-15 10:23:45 → 2024-01-15T10:23:45.000Z
  2024-01-15T10:23:45+05:30 → 2024-01-15T04:53:45.000Z

UNIX TIMESTAMPS:
  1705314225 → 2024-01-15T10:23:45.000Z
  1705314225123 → 2024-01-15T10:23:45.123Z

KUBERNETES:
  I0115 10:23:45.123456 → 2024-01-15T10:23:45.123Z

Rules:
  - If no timezone is specified, assume UTC and add 'Z'
  - If year is missing, use current year
  - If timestamp is in the future by more than 1 hour, flag as anomaly
  - If timestamp cannot be parsed, keep original and add _parse_error field
  - Sort entries by normalized timestamp after parsing

Respond ONLY with valid JSON:
{{
  "entries": "same format as input, with timestamps normalized",
  "normalization_stats": {{
    "total": 0,
    "normalized": 0,
    "already_utc": 0,
    "failed": 0
  }},
  "timezone_detected": "UTC|EST|PST|CET|IST|unknown",
  "time_range": {{
    "earliest": "ISO timestamp",
    "latest": "ISO timestamp",
    "span_seconds": 0
  }},
  "anomalies": ["any timestamp anomalies detected"]
}}"""


# =============================================================================
# SKILL: IP Normalization
# Used by: Normalize IP addresses in log entries
# =============================================================================

SKILL_IP_NORMALIZATION = """You are an IP address normalization specialist.

Parsed entries:
{parsed_logs}

Normalize IP addresses:

1. IPV4 NORMALIZATION
   → Remove leading zeros: 192.168.001.100 → 192.168.1.100
   → Classify: public, private, loopback, link-local, multicast
   → Map private ranges:
       10.0.0.0/8       → Private (Class A)
       172.16.0.0/12    → Private (Class B)
       192.168.0.0/16   → Private (Class C)

2. IPV6 NORMALIZATION
   → Expand :: shorthand to full notation
   → Remove leading zeros from each group
   → Convert to lowercase
   → Classify: global unicast, link-local (fe80::), loopback (::1)

3. ANONYMIZATION (if requested)
   → Replace last octet of IPv4 with .xxx
   → Replace last 64 bits of IPv6 with :xxxx
   → Preserve network portion for subnet analysis

4. HOSTNAME RESOLUTION HINTS
   → Flag localhost, localhost.localdomain
   → Flag cloud metadata IPs (169.254.169.254)
   → Flag Kubernetes service IPs (10.x.x.x)

Respond ONLY with valid JSON:
{{
  "entries": "entries with normalized IPs",
  "ip_summary": {{
    "unique_ips": 0,
    "private_ips": 0,
    "public_ips": 0,
    "ipv4_count": 0,
    "ipv6_count": 0
  }},
  "anonymized": false,
  "flagged_ips": [
    {{
      "ip": "169.254.169.254",
      "reason": "Cloud metadata endpoint",
      "occurrences": 3
    }}
  ]
}}"""


# =============================================================================
# SKILL: Chunk Strategy
# Used by: Step 4/4 — Decide how to split large logs
# =============================================================================

SKILL_CHUNK_STRATEGY = """You are a data chunking specialist for LLM processing.

Normalized log content:
{normalized_logs}

Statistics:
  Total characters: {total_chars}
  Total entries: {total_entries}
  Log type: {log_type}

LLM context limit: 8192 tokens (~6000 characters safe limit)

Chunk strategies (choose best for this content):

1. BY ENTRY COUNT
   → Split every N entries
   → Good for: uniformly sized entries
   → Risk: may split multi-line entries (stack traces, SQL)

2. BY CHARACTER COUNT
   → Split at ~5000 character boundaries
   → Good for: unpredictable entry sizes
   → Risk: may split in the middle of an entry

3. BY TIME WINDOW
   → Split by time ranges (every 15 min, every hour)
   → Good for: continuous log streams
   → Risk: uneven chunk sizes if error bursts

4. BY ERROR CLUSTER
   → Group errors together, info/debug separately
   → Good for: mixed severity logs
   → Benefit: keeps related errors in same chunk

5. SMART CHUNKING (recommended)
   → Split at natural boundaries (empty lines, timestamp patterns)
   → Keep stack traces with their parent error
   → Keep SQL queries with their results
   → Target 4000-5000 chars per chunk
   → Overlap 200 chars between chunks for context

Respond ONLY with valid JSON:
{{
  "strategy": "smart|by_entry|by_char|by_time|by_error",
  "chunks": [
    {{
      "chunk_index": 0,
      "content": "chunk text",
      "char_count": 0,
      "entry_count": 0,
      "time_range": {{"start": "ISO", "end": "ISO"}},
      "severity_summary": {{"CRITICAL": 0, "ERROR": 1, "WARN": 1, "INFO": 2}},
      "contains_stack_trace": false,
      "overlap_with_next": "last 200 chars of this chunk"
    }}
  ],
  "total_chunks": 0,
  "total_chars": 0,
  "chunking_reason": "why this strategy was chosen",
  "estimated_llm_calls": 0,
  "confidence": 0.9
}}"""


# =============================================================================
# SKILL: Structure Detection
# Used by: Detect the internal structure of log entries
# =============================================================================

SKILL_STRUCTURE_DETECTION = """You are a log structure analysis specialist.

Log content sample (first 1000 chars):
{cleaned_logs}

Detect the structural pattern of these log entries:

1. KEY=VALUE STRUCTURES
   → "timestamp=2024-01-15 level=ERROR message=DB connection failed"
   → Separators: =, :, =>
   → Delimiters: space, comma, tab

2. JSON-LIKE / STRUCTURED
   → Full JSON objects per line
   → Partial JSON (key: value pairs without outer braces)
   → LTSV (Labeled Tab-Separated Values)

3. COLUMN / TABULAR
   → Fixed-width columns
   → Tab-separated columns
   → Space-aligned columns

4. FREEFORM / UNSTRUCTURED
   → Natural language log messages
   → No consistent field structure
   → May have embedded key=value pairs

5. HYBRID
   → Structured prefix + freeform message
   → Example: "2024-01-15 ERROR [auth-service] Database connection failed"
   → Common in: Logback, Log4j, Winston, Bunyan

Respond ONLY with valid JSON:
{{
  "structure_type": "key_value|json_like|tabular|freeform|hybrid",
  "field_separator": "space|comma|tab|pipe",
  "key_value_separator": "=|:|=>",
  "detected_fields": ["timestamp", "level", "message", "service"],
  "consistent_structure": true,
  "consistency_score": 0-100,
  "freeform_ratio": 0.0-1.0,
  "sample_parsed": {{
    "timestamp": "extracted value or null",
    "level": "extracted value or null",
    "message": "extracted value or null"
  }},
  "confidence": 0.9
}}"""


# =============================================================================
# SKILL: Log Format Detection
# Used by: Auto-detect the specific log format
# =============================================================================

SKILL_LOG_FORMAT_DETECTION = """You are a log format detection specialist.

Log content sample:
{cleaned_logs}

Detect the specific log format from this taxonomy:

COMMON FORMATS:
  apache_common      — 127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /apache_pb.gif HTTP/1.0" 200 2326
  apache_combined    — Same + referer + user-agent
  nginx_access       — Similar to Apache but with upstream fields
  apache_error       — [Wed Oct 11 14:32:52 2000] [error] [client 127.0.0.1] client denied

  syslog_rfc3164     — <34>Oct 11 22:14:15 mymachine su: 'su root' failed for lonvick on /dev/pts/8
  syslog_rfc5424     — <34>1 2003-10-11T22:14:15.003Z mymachine.example.com su - ID47 - BOM'su root' failed

  log4j              — 2024-01-15 10:23:45,123 [main] ERROR com.app.Service - Message
  logback            — 10:23:45.123 [main] ERROR c.a.Service - Message
  java_util_logging  — Jan 15, 2024 10:23:45 AM com.app.Service errorSomething

  python_logging     — 2024-01-15 10:23:45,123 - module - ERROR - Message
  structlog          — {"timestamp": "...", "level": "error", "event": "...", "logger": "..."}

  bunyan             — {"name":"app","hostname":"host","pid":123,"level":30,"msg":"message","time":"..."}
  winston            — {"level":"error","message":"message","timestamp":"..."}
  pino               — {"level":30,"time":1705314225123,"pid":123,"hostname":"host","msg":"message"}

  kubernetes         — I0115 10:23:45.123456   1 pod.go:123] message
  docker_json        — {"log":"message","stream":"stdout","time":"2024-01-15T10:23:45.123Z"}
  containerd         — 2024-01-15T10:23:45.123456789Z stdout F message

CLOUD FORMATS:
  aws_cloudwatch     — {"awslogs": {"data": "BASE64ENCODED"}}
  aws_lambda         — START RequestId: ... / END RequestId: ... / REPORT RequestId: ...
  gcp_stackdriver    — {"insertId":"...","logName":"...","receiveTimestamp":"...","resource":{...}}
  azure_monitor      — {"time":"...","resourceId":"...","properties":{"message":"..."}}

Respond ONLY with valid JSON:
{{
  "format": "specific_format_name",
  "confidence": 0.0-1.0,
  "alternative_formats": ["other possible formats"],
  "matched_patterns": ["which patterns matched"],
  "parser_recommendation": "which parser to use (regex|json|csv|syslog|apache)"
}}"""


# =============================================================================
# SKILL: Field Extraction
# Used by: Extract common fields from parsed entries
# =============================================================================

SKILL_FIELD_EXTRACTION = """You are a field extraction specialist.

Parsed log entries:
{parsed_logs}

Extract these common fields where present:

REQUIRED FIELDS (always try to extract):
  → timestamp: ISO-8601 UTC
  → level: normalized severity
  → message: main log message text

RECOMMENDED FIELDS:
  → service: service/module/component name
  → host: hostname, pod name, container ID
  → pid: process ID
  → tid: thread ID or goroutine ID

OPTIONAL FIELDS (extract if available):
  → trace_id: distributed tracing ID
  → span_id: span within a trace
  → user_id: authenticated user
  → request_id: HTTP request ID
  → session_id: user session
  → duration_ms: operation duration
  → status_code: HTTP/gRPC status
  → method: HTTP method
  → path: URL path or gRPC method
  → query_params: URL query string
  → user_agent: client user agent
  → ip: client IP address
  → error_code: application error code
  → error_type: exception class
  → stack_trace: stack trace lines

Field extraction rules:
  - Extract from structured data first (JSON fields, key=value pairs)
  - Then try regex patterns for common formats
  - Never invent values — if unsure, set to null
  - Preserve original casing for service names and messages

Respond ONLY with valid JSON:
{{
  "entries": "entries with extracted fields added",
  "field_stats": {{
    "timestamp_present": true,
    "level_present": true,
    "service_present": false,
    "trace_id_present": false,
    "fields_found": ["timestamp", "level", "message"]
  }},
  "extraction_quality": "high|medium|low",
  "missing_critical_fields": ["fields that should exist but don't"],
  "confidence": 0.9
}}"""


# =============================================================================
# SKILL: Log Deduplication
# Used by: Remove repeated/identical log entries
# =============================================================================

SKILL_LOG_DEDUPLICATION = """You are a log deduplication specialist.

Parsed entries:
{parsed_logs}

Total entries: {total_entries}

Deduplication strategies:

1. EXACT DEDUPLICATION
   → Remove entries with identical message field
   → Keep first occurrence, add repeat_count to it
   → Add first_seen and last_seen timestamps

2. SEMANTIC DEDUPLICATION
   → Group entries that differ only in:
        - Timestamps
        - IP addresses
        - Request IDs
        - Memory addresses
   → Replace variable parts with placeholders
   → Example: "User 1234 logged in" and "User 5678 logged in"
        → Template: "User {id} logged in" (count: 2)

3. RATE-BASED DEDUPLICATION
   → For heartbeat/polling messages: keep 1 per minute
   → For repeated errors: keep 1 per occurrence within 5-second windows
   → Preserve the pattern: first occurrence, peak, last occurrence

4. ERROR BURST DEDUPLICATION
   → If identical error appears > 10 times in 1 minute
   → Keep: first 3, last 1, and a summary count
   → Mark: "[BURST] Error X repeated N times between T1 and T2"

Respond ONLY with valid JSON:
{{
  "entries": "deduplicated entries",
  "stats": {{
    "original_count": 100,
    "deduplicated_count": 45,
    "duplicates_removed": 55,
    "burst_groups": 3
  }},
  "deduplication_method": "exact|semantic|rate_based|hybrid",
  "repeated_patterns": [
    {{
      "template": "User {id} logged in",
      "count": 25,
      "first_seen": "ISO timestamp",
      "last_seen": "ISO timestamp"
    }}
  ],
  "preserved_for_context": ["entries kept for narrative understanding"]
}}"""


# =============================================================================
# SKILL: Multiline Merging
# Used by: Merge multi-line log entries into single entries
# =============================================================================

SKILL_MULTILINE_MERGING = """You are a multiline log merging specialist.

Raw log content:
{raw_logs}

Detect and merge multiline entries:

1. STACK TRACES
   → Start: "Traceback", "Exception", "Error:", "panic:", "at com.", "at org."
   → Continuation: indented lines, "File ...", "Caused by:", "Suppressed:"
   → End: blank line, new timestamped entry, or different severity level
   → Merge into single entry with stack_trace array

2. SQL QUERIES
   → Start: "SELECT", "INSERT", "UPDATE", "DELETE", "CREATE", "ALTER"
   → Continuation: lines starting with spaces/tabs, field lists, JOIN clauses
   → End: semicolon, blank line, or new log entry
   → Merge into single entry with query field

3. XML / JSON BLOCKS
   → Start: "<", "{"
   → Continuation: more XML elements or JSON key-value pairs
   → End: matching closing tag or closing brace
   → Merge into single entry with xml_blob or json_blob field

4. CONFIGURATION DUMPS
   → Start: "Configuration:", "Settings:", "Properties:"
   → Continuation: key=value lines
   → End: blank line or new log entry
   → Merge into single entry with config map

5. WRAPPED LINES (terminal width wrapping)
   → Lines that end without punctuation or closing delimiter
   → Next line starts with lowercase or continuation character
   → Join with space (not newline)
   → Common in: terminal output, log viewers with word wrap

Respond ONLY with valid JSON:
{{
  "entries": "merged entries",
  "merge_stats": {{
    "original_lines": 100,
    "merged_entries": 65,
    "stack_traces_merged": 3,
    "sql_queries_merged": 1,
    "xml_json_merged": 0,
    "wrapped_lines_joined": 15
  }},
  "multiline_types_found": ["stack_trace", "sql_query"],
  "merge_confidence": 0.95
}}"""
