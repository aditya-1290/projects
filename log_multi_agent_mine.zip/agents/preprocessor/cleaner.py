"""
Log Cleaner - Removes noise and irrelevant content from logs
"""

import re
from typing import Optional


class LogCleaner:
    """Cleans raw logs by removing noise and normalizing content"""

    # Patterns to remove
    NOISE_PATTERNS = [
        re.compile(r'^\s*$'),  # Empty lines
        re.compile(r'^-{3,}$'),  # Separator lines
        re.compile(r'^=+$'),  # Equal sign separators
        re.compile(r'^\*{3,}$'),  # Asterisk separators
        re.compile(r'^\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\.\d{3}\s+---'),  # Log4j separators
    ]

    # ANSI escape codes
    ANSI_PATTERN = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')

    # Stack trace noise
    STACK_TRACE_NOISE = [
        re.compile(r'^\s+at\s+'),  # Java stack trace
        re.compile(r'^\s+\.\.\.\s+\d+\s+more'),  # Java "X more"
        re.compile(r'^Caused by:\s+'),  # Java caused by
        re.compile(r'^\s+from\s+'),  # Ruby stack trace
        re.compile(r'^Traceback\s+\(most\s+recent'),  # Python traceback
    ]

    async def clean(self, raw_logs: str, model=None) -> str:
        """
        Clean raw logs.

        If model is provided, uses Qwen2.5-3B for intelligent cleaning.
        Otherwise, uses regex-based cleaning.
        """
        lines = raw_logs.split('\n')
        cleaned_lines = []
        noise_count = 0

        for line in lines:
            # Remove ANSI codes
            line = self.ANSI_PATTERN.sub('', line)

            # Skip empty/noise lines
            if self._is_noise(line):
                noise_count += 1
                continue

            # Normalize line
            line = self._normalize_line(line)
            cleaned_lines.append(line)

        result = '\n'.join(cleaned_lines)

        # If model available, do intelligent cleaning
        if model:
            result = await self._intelligent_clean(result, model)

        print(f"[CLEANER] Removed {noise_count} noise lines, "
              f"kept {len(cleaned_lines)} lines")

        return result

    def _is_noise(self, line: str) -> bool:
        """Check if a line is noise"""
        line_stripped = line.strip()

        # Empty
        if not line_stripped:
            return True

        # Match noise patterns
        for pattern in self.NOISE_PATTERNS:
            if pattern.match(line_stripped):
                return True

        return False

    def _normalize_line(self, line: str) -> str:
        """Normalize a single log line"""
        # Remove extra whitespace
        line = re.sub(r'\s+', ' ', line)

        # Strip trailing spaces
        line = line.strip()

        return line

    async def _intelligent_clean(self, logs: str, model) -> str:
        """Use Qwen2.5-3B for intelligent cleaning"""
        prompt = f"""Clean the following log entries. Remove:
1. Empty lines
2. Separator lines (---, ===, ***)
3. ANSI color codes
4. Duplicate timestamps
5. Non-log text (comments, headers)

Keep all actual log entries intact.

Logs:
{logs[:3000]}  # Limit to avoid context overflow

Cleaned logs:"""

        try:
            result = await model.generate(prompt, max_tokens=2048)
            return result.strip()
        except Exception:
            return logs  # Return original if model fails