"""
Preprocessor Agent

Uses Qwen2.5-3B for intelligent log cleaning, parsing, and chunking.
This is the second step in the pipeline after extraction.
"""

from typing import Dict, Any, List

from agents.base_agent import BaseAgent, A2AMessage, MessageType


class PreprocessorAgent(BaseAgent):
    """Cleans, parses, and structures raw logs"""

    def __init__(self):
        super().__init__("preprocessor_v1", "agents/preprocessor/capabilities.json")

    async def process(self, message: A2AMessage) -> A2AMessage:
        """
        Process raw logs through the preprocessing pipeline:
        1. Clean noise
        2. Parse structure
        3. Normalize
        4. Chunk if needed
        """
        task = message.task or {}
        context = message.context or {}

        # Try multiple sources for raw_logs
        raw_logs = (
                task.get("raw_logs") or
                context.get("raw_logs") or
                context.get("previous_results", {}).get("subtask_0", {}).get("response", {}).get("raw_logs") or
                context.get("previous_results", {}).get("subtask_0", {}).get("response", {}).get("content") or
                task.get("content") or
                ""
        )

        if not raw_logs or not raw_logs.strip():
            # Instead of error loop, return a graceful response
            self.log("No raw logs provided - returning empty result")
            return A2AMessage(
                message_type=MessageType.RESPONSE,  # Use RESPONSE not ERROR
                sender_id=self.agent_id,
                sender_type="preprocessor",
                target_id=message.sender_id,
                correlation_id=message.message_id,
                response={
                    "clean_logs": "",
                    "chunks": [],
                    "is_chunked": False,
                    "chunk_count": 0,
                    "warning": "No logs to preprocess - extraction may have failed"
                },
                confidence=0.0,
                caveats=["Extraction step did not provide any logs to process"]
            )

        self.log(f"Preprocessing {len(raw_logs)} characters of logs")

        try:
            # Step 1: Clean
            self.log("Step 1/4: Cleaning logs...")
            cleaned_logs = await self._clean(raw_logs)

            # Step 2: Parse
            self.log("Step 2/4: Parsing structure...")
            parsed_logs = await self._parse(cleaned_logs)

            # Step 3: Normalize
            self.log("Step 3/4: Normalizing...")
            normalized_logs = await self._normalize(parsed_logs)

            # Step 4: Chunk if needed
            self.log("Step 4/4: Checking if chunking needed...")
            result = await self._chunk_if_needed(normalized_logs)

            self.log(f"Preprocessing complete: {result['chunk_count']} chunks, "
                     f"{result['total_length']} chars total")

            return A2AMessage(
                message_type=MessageType.RESPONSE,
                sender_id=self.agent_id,
                sender_type="preprocessor",
                target_id=message.sender_id,
                correlation_id=message.message_id,
                response={
                    "clean_logs": result["content"],
                    "raw_logs": raw_logs,  # 🔥 ADD THIS
                    "chunks": result.get("chunks", []),
                    "is_chunked": result["is_chunked"],
                    "chunk_count": result["chunk_count"],
                    "original_length": len(raw_logs),
                    "cleaned_length": result["total_length"],
                    "format_detected": result.get("format", "text"),
                    "noise_removed_lines": result.get("noise_removed", 0)
                },
                confidence=0.9,
                context=message.context
            )

        except Exception as e:
            self.log(f"Error: {e}", "ERROR")
            return A2AMessage(
                message_type=MessageType.ERROR,
                sender_id=self.agent_id,
                sender_type="preprocessor",
                target_id=message.sender_id,
                correlation_id=message.message_id,
                error=f"Preprocessing failed: {str(e)}"
            )

    async def _clean(self, raw_logs: str) -> str:
        """Remove noise from raw logs"""
        from agents.preprocessor.cleaner import LogCleaner
        cleaner = LogCleaner()

        # Try with Qwen model if available
        try:
            model = await self.get_model("qwen_small")
            return await cleaner.clean(raw_logs, model=model)
        except Exception:
            # Fallback: clean without model
            return await cleaner.clean(raw_logs, model=None)

    async def _parse(self, cleaned_logs: str) -> Dict:
        """Parse cleaned logs into structured format"""
        from agents.preprocessor.parser import LogParser
        parser = LogParser()

        try:
            model = await self.get_model("qwen_small")
            return await parser.parse(cleaned_logs, model=model)
        except Exception:
            return await parser.parse(cleaned_logs, model=None)

    async def _normalize(self, parsed_logs: Dict) -> Dict:
        """Normalize timestamps, IPs, and other fields"""
        from agents.preprocessor.normalizer import LogNormalizer
        normalizer = LogNormalizer()
        return await normalizer.normalize(parsed_logs)

    async def _chunk_if_needed(self, normalized_logs: Dict) -> Dict:
        """Chunk large logs for processing"""
        from agents.preprocessor.chunker import LogChunker
        chunker = LogChunker()

        try:
            model = await self.get_model("qwen_small")
            return await chunker.chunk(normalized_logs, model=model)
        except Exception:
            return await chunker.chunk(normalized_logs, model=None)