"""
Debugger Agent - Code-level debugging and patch generation.

Enhancements over v1:
  - Multi-language stack trace parsing (Python, Java, JS, Go, Rust, C#, …)
  - Wider content fallback: checks raw_logs, clean_logs, analyzed_logs,
    stack_trace, and preprocessed_logs from pipeline context
  - CodeParser and PatchGenerator are now actually used (they were unused in v1)
  - Error context window (lines around error line) sent to LLM for better patches
  - No-source-code analysis mode: still returns useful guidance without source
  - LLM-assisted trace parsing with regex fallback (graceful degradation)
  - Multi-attempt patch generation with validation loop (up to max_iterations)
  - Proactive code analysis (bug scan) when requested without a stack trace
  - Proper confidence scoring based on evidence quality
  - Caveats populated with actionable warnings
"""

import json
import re
from typing import Any, Dict, List, Optional, Tuple

from agents.base_agent import BaseAgent, A2AMessage, MessageType

from agents.debugger.code_parser     import CodeParser
from agents.debugger.patch_generator import PatchGenerator
from agents.debugger.prompts import (
    STACK_TRACE_PARSE_PROMPT_WITH_EXAMPLE,
    PATCH_GENERATION_PROMPT,
    PATCH_GENERATION_NO_SOURCE_PROMPT,
    CODE_ANALYSIS_PROMPT,
    PATCH_REFINEMENT_PROMPT,
    PATCH_REVIEW_PROMPT,
)


# Maximum source code characters sent to the LLM to fit small context windows
_MAX_SOURCE_CHARS = 3000
_MAX_TRACE_CHARS  = 2000


class DebuggerAgent(BaseAgent):
    """
    Parses stack traces, extracts error context, and generates validated code patches.

    Task fields recognised:
      stack_trace  : raw stack trace text
      source_code  : full source file content (optional but improves quality)
      action       : "debug" (default) | "analyze" (proactive bug scan)
      language     : override language detection (optional)
      file_path    : path of the file being debugged (for diff headers)
      max_attempts : patch generation attempts before giving up (default 2)

    Context fields also checked (lower priority):
      clean_logs, raw_logs, analyzed_logs, preprocessed_logs, stack_trace,
      source_code, language
    """

    def __init__(self):
        super().__init__("debugger_v1", "agents/debugger/capabilities.json")
        self._code_parser     = CodeParser()
        self._patch_generator = PatchGenerator()
        self._max_iterations  = 3

    # =========================================================================
    # Main entry point — keep this signature unchanged
    # =========================================================================

    async def process(self, message: A2AMessage) -> A2AMessage:
        task    = message.task    or {}
        context = message.context or {}

        action = task.get("action", "debug").lower()

        # ── Proactive code analysis (no stack trace needed) ───────────────────
        if action == "analyze":
            return await self._handle_code_analysis(message, task, context)

        # ── Standard debug flow ───────────────────────────────────────────────
        return await self._handle_debug(message, task, context)

    # =========================================================================
    # Debug flow
    # =========================================================================

    async def _handle_debug(
        self, message: A2AMessage, task: Dict, context: Dict
    ) -> A2AMessage:

        # ── 1. Gather inputs ──────────────────────────────────────────────────
        stack_trace = self._find_stack_trace(task, context)
        source_code = self._find_source_code(task, context)
        file_path   = task.get("file_path", "") or context.get("file_path", "")
        language    = task.get("language",   "") or context.get("language",   "")
        max_attempts = int(task.get("max_attempts", 2))

        # ── 2. No stack trace at all → return RESPONSE with guidance ─────────
        if not stack_trace or not stack_trace.strip():
            return self._make_response(
                message=message,
                response={
                    "parsed_trace":   None,
                    "patch":          None,
                    "code_analysis":  None,
                    "requires_source": True,
                    "guidance": (
                        "No stack trace found. Please paste the full error output "
                        "including 'Traceback' lines or the exception message."
                    ),
                },
                confidence=0.2,
                caveats=["No stack trace available — only general guidance provided"],
            )

        try:
            model = await self._get_model()

            # ── 3. Parse the stack trace ──────────────────────────────────────
            parsed = await self._parse_trace_smart(stack_trace, model)

            # Resolve language (parsed > task override > auto-detect from source)
            effective_lang = (
                language
                or parsed.get("language", "")
                or (self._code_parser.detect_language(source_code) if source_code else "unknown")
            )

            # Resolve file path
            effective_file = (
                file_path
                or parsed.get("root_file", "")
            )

            # ── 4. Extract code context window (lines around the error) ───────
            error_line    = parsed.get("root_line", 0)
            code_context  = {}
            code_structure: Dict = {}
            if source_code and error_line:
                code_context = self._code_parser.extract_error_context(
                    source_code, error_line, context_lines=12
                )
                code_structure = self._code_parser.parse(source_code, effective_lang)

            # ── 5. Generate patch (with retry loop) ───────────────────────────
            patch_result: Optional[Dict] = None
            patch_diff:   Optional[Dict] = None
            attempt      = 0
            last_issue   = ""

            while attempt < max_attempts:
                attempt += 1
                raw_patch = await self._generate_patch_llm(
                    parsed,
                    source_code,
                    code_context,
                    code_structure,
                    effective_lang,
                    effective_file,
                    last_issue,
                    model,
                )

                if not raw_patch:
                    last_issue = "LLM returned no structured patch"
                    continue

                # Build unified diff if we have before/after snippets
                code_before = raw_patch.get("code_before", "").strip()
                code_after  = raw_patch.get("code_after",  "").strip()

                if code_before and code_after and source_code:
                    # Apply the snippet replacement to the full file
                    fixed_source = source_code.replace(code_before, code_after, 1)
                    if fixed_source != source_code:
                        patch_diff = self._patch_generator.generate(
                            source_code,
                            fixed_source,
                            file_path=effective_file,
                            description=raw_patch.get("fix_description", ""),
                        )
                        # Validate
                        if patch_diff.get("is_valid"):
                            patch_result = raw_patch
                            patch_result["unified_diff"] = patch_diff
                            break
                        else:
                            last_issue = "; ".join(patch_diff.get("validation_notes", ["invalid patch"]))
                    else:
                        # Snippet not found verbatim — still return LLM suggestion
                        patch_result = raw_patch
                        patch_result["unified_diff"] = None
                        patch_result["_note"] = "code_before snippet not found verbatim in source — apply manually"
                        break
                else:
                    # No source or no snippets — just return LLM guidance
                    patch_result = raw_patch
                    break

            # ── 6. Anti-pattern scan on source ────────────────────────────────
            anti_patterns: List[Dict] = []
            if source_code:
                anti_patterns = self._code_parser._detect_anti_patterns(
                    source_code, effective_lang
                )

            # ── 7. Build confidence score ─────────────────────────────────────
            confidence = self._compute_confidence(
                parsed, patch_result, source_code, code_context
            )

            # ── 8. Build caveats ──────────────────────────────────────────────
            caveats = self._build_caveats(
                patch_result, source_code, parsed, anti_patterns
            )

            return self._make_response(
                message=message,
                response={
                    "parsed_trace":    parsed,
                    "code_context":    code_context,
                    "code_structure":  code_structure,
                    "patch":           patch_result,
                    "anti_patterns":   anti_patterns,
                    "requires_source": not bool(source_code),
                    "language":        effective_lang,
                    "file":            effective_file,
                },
                confidence=confidence,
                caveats=caveats,
            )

        except Exception as exc:
            self.log(f"Debugging pipeline error: {exc}", "ERROR")
            # Return RESPONSE (not ERROR) so orchestrator doesn't bounce
            return self._make_response(
                message=message,
                response={
                    "parsed_trace":  None,
                    "patch":         None,
                    "requires_source": True,
                    "error_detail":  str(exc),
                },
                confidence=0.1,
                caveats=[f"Internal error during debugging: {exc}"],
            )

    # =========================================================================
    # Proactive code analysis (action = "analyze")
    # =========================================================================

    async def _handle_code_analysis(
        self, message: A2AMessage, task: Dict, context: Dict
    ) -> A2AMessage:
        source_code = self._find_source_code(task, context)
        language    = task.get("language", "auto")

        if not source_code:
            return self._make_response(
                message=message,
                response={"error": "No source code provided for analysis"},
                confidence=0.0,
                caveats=["Source code is required for proactive analysis"],
            )

        try:
            model      = await self._get_model()
            structure  = self._code_parser.parse(source_code, language)
            eff_lang   = structure["language"]

            # LLM-based analysis
            llm_issues: List[Dict] = []
            if model:
                prompt = CODE_ANALYSIS_PROMPT.format(
                    language=eff_lang,
                    code=source_code[:_MAX_SOURCE_CHARS],
                )
                raw = await model.generate(prompt, max_tokens=1024)
                parsed_analysis = self._extract_json(raw)
                if parsed_analysis:
                    llm_issues = parsed_analysis.get("issues", [])

            # Regex-based anti-pattern scan (always runs)
            anti_patterns = self._code_parser._detect_anti_patterns(source_code, eff_lang)

            return self._make_response(
                message=message,
                response={
                    "code_structure": structure,
                    "llm_issues":     llm_issues,
                    "anti_patterns":  anti_patterns,
                    "language":       eff_lang,
                    "summary":        (
                        f"Found {len(llm_issues)} LLM-detected issues and "
                        f"{len(anti_patterns)} anti-patterns in {structure['total_lines']} lines."
                    ),
                },
                confidence=0.75 if model else 0.5,
                caveats=["Static analysis only — dynamic/runtime issues not detected"],
            )

        except Exception as exc:
            return self._make_response(
                message=message,
                response={"error": str(exc)},
                confidence=0.0,
                caveats=[f"Analysis failed: {exc}"],
            )

    # =========================================================================
    # Stack trace parsing: LLM first, regex fallback
    # =========================================================================

    async def _parse_trace_smart(self, trace: str, model) -> Dict:
        """
        Try LLM-based parsing first; fall back to pure regex if LLM fails
        or returns malformed JSON.
        """
        # ── Try LLM ───────────────────────────────────────────────────────────
        if model:
            try:
                prompt = STACK_TRACE_PARSE_PROMPT_WITH_EXAMPLE.format(
                    trace=trace[:_MAX_TRACE_CHARS]
                )
                raw = await model.generate(prompt, max_tokens=512)
                parsed = self._extract_json(raw)
                if parsed and parsed.get("error_type"):
                    return parsed
            except Exception as exc:
                self.log(f"LLM trace parse failed, using regex: {exc}", "WARNING")

        # ── Regex fallback ────────────────────────────────────────────────────
        from agents.debugger.tools import DebuggerTools
        return await DebuggerTools().parse_trace(trace)

    # =========================================================================
    # Patch generation
    # =========================================================================

    async def _generate_patch_llm(
        self,
        parsed: Dict,
        source_code: str,
        code_context: Dict,
        code_structure: Dict,
        language: str,
        file_path: str,
        last_issue: str,
        model,
    ) -> Optional[Dict]:
        """Generate a patch dict using the LLM."""
        if not model:
            return None

        error_type    = parsed.get("error_type",    "Unknown")
        error_message = parsed.get("error_message", "")
        root_line     = parsed.get("root_line",     0)
        function_name = (
            code_context.get("containing_function", "")
            or (parsed.get("call_chain", [{}])[0].get("function", "") if parsed.get("call_chain") else "")
        )

        # Choose prompt (with source or without)
        if source_code and not last_issue:
            prompt = PATCH_GENERATION_PROMPT.format(
                error_type=error_type,
                error_message=error_message,
                file=file_path or parsed.get("root_file", "unknown"),
                line=root_line,
                language=language,
                function=function_name or "unknown",
                context=code_context.get("snippet", "Not available"),
                source_chars=_MAX_SOURCE_CHARS,
                source=source_code[:_MAX_SOURCE_CHARS],
            )
        elif source_code and last_issue:
            # Retry with refinement prompt
            prompt = PATCH_REFINEMENT_PROMPT.format(
                issue=last_issue,
                error_type=error_type,
                error_message=error_message,
                previous_patch="",   # We don't persist previous patch text here
                source=source_code[:_MAX_SOURCE_CHARS],
            )
        else:
            # No source code
            call_chain_text = "\n".join(
                f"  {i+1}. {f.get('file')} line {f.get('line')} in {f.get('function','?')}"
                for i, f in enumerate(parsed.get("call_chain", []))
            ) or "  (not available)"
            prompt = PATCH_GENERATION_NO_SOURCE_PROMPT.format(
                error_type=error_type,
                error_message=error_message,
                file=file_path or parsed.get("root_file", "unknown"),
                line=root_line,
                language=language,
                call_chain=call_chain_text,
            )

        try:
            raw = await model.generate(prompt, max_tokens=1024)
            return self._extract_json(raw)
        except Exception as exc:
            self.log(f"LLM patch generation failed: {exc}", "WARNING")
            return None

    # =========================================================================
    # Scoring & caveats
    # =========================================================================

    def _compute_confidence(
        self,
        parsed: Dict,
        patch: Optional[Dict],
        source_code: str,
        code_context: Dict,
    ) -> float:
        score = 0.0

        # Stack trace parsed?
        if parsed.get("error_type") and parsed["error_type"] != "Unknown":
            score += 0.2
        if parsed.get("root_file"):
            score += 0.1
        if parsed.get("root_line"):
            score += 0.1

        # Source code provided?
        if source_code:
            score += 0.15
        if code_context.get("snippet"):
            score += 0.05

        # Patch quality
        if patch:
            if patch.get("code_before") and patch.get("code_after"):
                score += 0.2
            if patch.get("unified_diff", {}) and patch["unified_diff"].get("is_valid"):
                score += 0.15
            llm_conf = float(patch.get("confidence", 0))
            score += llm_conf * 0.05

        return round(min(1.0, score), 2)

    def _build_caveats(
        self,
        patch: Optional[Dict],
        source_code: str,
        parsed: Dict,
        anti_patterns: List[Dict],
    ) -> List[str]:
        caveats: List[str] = []

        if not source_code:
            caveats.append(
                "No source code provided — patch is based on stack trace only. "
                "Provide the source file for a more precise fix."
            )

        if patch:
            if patch.get("side_effects"):
                caveats.append(f"Side effects to watch: {patch['side_effects']}")
            if patch.get("unified_diff") is None and patch.get("code_after"):
                caveats.append(
                    "Patch snippet could not be located verbatim in source — "
                    "apply code_before/code_after manually."
                )
            if patch.get("unified_diff", {}) and not patch["unified_diff"].get("is_valid"):
                notes = "; ".join(patch["unified_diff"].get("validation_notes", []))
                caveats.append(f"Patch validation warning: {notes}")

        # Always add this
        caveats.append("Patch requires human review before applying to production code.")

        errors_in_anti = [p for p in anti_patterns if p.get("severity") == "error"]
        if errors_in_anti:
            caveats.append(
                f"{len(errors_in_anti)} high-severity anti-pattern(s) detected in source "
                f"(bare except, eval, unclosed resources) — review separately."
            )

        return caveats

    # =========================================================================
    # Content discovery helpers
    # =========================================================================

    def _find_stack_trace(self, task: Dict, context: Dict) -> str:
        """
        Find the stack trace from any of the fields the pipeline might use.
        Heuristic: prefer the field most likely to contain a traceback.
        """
        candidates = [
            task.get("stack_trace",       ""),
            task.get("content",           ""),
            task.get("raw_logs",          ""),
            context.get("clean_logs",     ""),
            context.get("stack_trace",    ""),
            context.get("raw_logs",       ""),
            context.get("analyzed_logs",  ""),
            context.get("preprocessed_logs", ""),
            context.get("query",          ""),
        ]
        # Score each by how much it looks like a stack trace
        def trace_score(text: str) -> int:
            if not text:
                return 0
            score = 0
            if "Traceback" in text:   score += 10
            if "Error:" in text:      score += 5
            if "Exception" in text:   score += 5
            if 'File "' in text:      score += 8
            if " line " in text:      score += 3
            if "at " in text and ".java:" in text: score += 10
            if "goroutine" in text:   score += 8
            return score

        best = max(candidates, key=trace_score)
        return best or ""

    def _find_source_code(self, task: Dict, context: Dict) -> str:
        return (
            task.get("source_code",    "")
            or context.get("source_code", "")
            or ""
        )

    # =========================================================================
    # JSON extraction
    # =========================================================================

    def _extract_json(self, text: str) -> Optional[Dict]:
        """Extract the first JSON object from LLM output, tolerating markdown fences."""
        if not text:
            return None

        # Strip markdown code fences
        text = re.sub(r"```(?:json)?\s*", "", text).strip()

        # Try the whole string first
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            pass

        # Greedy search for {...}
        match = re.search(r"\{.*\}", text, re.DOTALL)
        if match:
            try:
                return json.loads(match.group())
            except json.JSONDecodeError:
                pass

        return None

    # =========================================================================
    # Model access (graceful degradation)
    # =========================================================================

    async def _get_model(self):
        """Return the LLM model or None (regex-only mode)."""
        try:
            return await self.get_model("gemma")
        except Exception:
            try:
                return await self.get_model("qwen")
            except Exception:
                return None

    # =========================================================================
    # Response builder
    # =========================================================================

    def _make_response(
        self,
        message: A2AMessage,
        response: Dict[str, Any],
        confidence: float,
        caveats: List[str],
    ) -> A2AMessage:
        return A2AMessage(
            message_type=MessageType.RESPONSE,
            sender_id=self.agent_id,
            sender_type="debugger",
            target_id=message.sender_id,
            correlation_id=message.message_id,
            response={
                **response,
                "solution": response.get("patch")  # 🔥 helps pipeline
            },
            confidence=confidence,
            caveats=caveats,
        )
