"""
Skill Prompts for the Debugger Agent.

Organized by skill domain. Covers all supported languages plus
cross-cutting concerns like async errors, obfuscated code, and security.

Skill catalogue:
  SKILL_PYTHON_DEBUG          — Python-specific error patterns and fixes
  SKILL_JAVA_DEBUG            — Java/JVM-specific debugging
  SKILL_JS_TS_DEBUG           — JavaScript/TypeScript debugging
  SKILL_GO_DEBUG              — Go goroutine and panic analysis
  SKILL_RUST_DEBUG            — Rust panic/unsafe debugging
  SKILL_ASYNC_ERROR_ANALYSIS  — async/await, coroutine, event loop errors
  SKILL_DEEP_CALL_CHAIN       — 50+ frame stack traces (find the real bug)
  SKILL_MINIFIED_CODE_DEBUG   — debugging minified/bundled JS/CSS
  SKILL_CONCURRENT_ERROR      — race conditions, deadlocks, thread safety
  SKILL_LIBRARY_ERROR         — error inside third-party library code
  SKILL_MEMORY_ERROR_ANALYSIS — OOM, heap dump, memory leak debugging
  SKILL_SECURITY_PATCH_REVIEW — security implications of a proposed patch
  SKILL_PATCH_TEST_SUGGESTION — suggest test cases for a patch
  SKILL_ERROR_PREVENTION      — architectural recommendations to prevent error class
  SKILL_MULTI_ERROR_TRIAGE    — multiple simultaneous errors, find root cause
"""

# =============================================================================
# SKILL: Python-specific Debugging
# Used by: Step 4 when language = "python"
# =============================================================================

SKILL_PYTHON_DEBUG = """You are a Python debugging expert.

Error details:
  Type: {error_type}
  Message: {error_message}
  File: {file}, Line: {line}
  Function: {function}

Code context (>>> = error line):
{context}

Python-specific checks for {error_type}:

AttributeError:
  → Check if object is None before attribute access
  → Check for circular imports where a module-level variable is None at import time
  → Check for typos in attribute names (case sensitivity)
  → Check for method vs property confusion

NameError:
  → Variable referenced before assignment (especially in closures)
  → Conditional assignment where else branch is missing
  → Shadowed built-in (e.g., list = [...] then list() fails)
  → __all__ missing from __init__.py

TypeError:
  → Passing None where a value is expected
  → Calling a non-callable (variable shadowed a function)
  → Wrong number of arguments (positional vs keyword mismatch)
  → Bytes vs str confusion in Python 3

KeyError:
  → Use dict.get(key, default) instead of dict[key]
  → Check if key was deleted in a concurrent thread
  → JSON parsed as string instead of dict (double-serialized)

ImportError / ModuleNotFoundError:
  → Package not installed in current venv
  → Circular import (module A imports B, B imports A at module level)
  → Wrong PYTHONPATH or sys.path

RecursionError:
  → Missing base case in recursive function
  → Mutual recursion without termination
  → __repr__ or __str__ calling itself

Respond ONLY with valid JSON:
{{
  "python_error_category": "none_reference|name_before_assign|type_mismatch|missing_key|import_cycle|recursion|bytes_str|other",
  "root_cause": "precise explanation",
  "fix_description": "what to change",
  "code_before": "exact snippet to replace",
  "code_after": "fixed snippet",
  "fix_type": "null_check|missing_import|wrong_type|logic_error|resource_leak|other",
  "confidence": 0.9,
  "pythonic_alternative": "more idiomatic Python version if applicable",
  "side_effects": "any risks",
  "prevention": "how to avoid this class of error",
  "related_errors_to_watch": ["other errors that may surface after this fix"]
}}"""


# =============================================================================
# SKILL: Java/JVM Debugging
# Used by: Step 4 when language = "java"
# =============================================================================

SKILL_JAVA_DEBUG = """You are a Java/JVM debugging expert.

Error details:
  Type: {error_type}
  Message: {error_message}
  Class: {function}, File: {file}, Line: {line}
  JVM version hint: {language}

Code context:
{context}

Java-specific checks for {error_type}:

NullPointerException:
  → Check Optional.get() without isPresent()
  → Autowired bean is null (Spring context not loaded)
  → Method returns null instead of empty collection
  → Static field not initialized before use
  → Array element not initialized

ClassCastException:
  → Unchecked cast of generic type (type erasure)
  → Deserialized object from incompatible version
  → Wrong bean type in Spring context

StackOverflowError:
  → Recursive toString()/equals()/hashCode()
  → Circular bean dependency (Spring)
  → Recursive Lombok-generated methods

OutOfMemoryError:
  → Java heap: large collection not released (check for static caches)
  → PermGen/Metaspace: classloader leak (undeploy/redeploy cycles)
  → GC overhead limit: excessive object creation in hot path

ConcurrentModificationException:
  → Modifying collection while iterating (use Iterator.remove())
  → Shared mutable state without synchronization

Respond ONLY with valid JSON:
{{
  "java_error_category": "npe|class_cast|stack_overflow|oom|concurrent_mod|spring_context|type_erasure|other",
  "root_cause": "precise explanation",
  "fix_description": "what to change",
  "code_before": "exact snippet",
  "code_after": "fixed snippet",
  "fix_type": "null_check|missing_import|wrong_type|logic_error|resource_leak|other",
  "confidence": 0.88,
  "jvm_config_change": "any JVM flag changes needed e.g. -Xmx, -XX:MaxMetaspaceSize",
  "side_effects": "any risks",
  "prevention": "how to avoid this class of error"
}}"""


# =============================================================================
# SKILL: JavaScript/TypeScript Debugging
# Used by: Step 4 when language = "javascript" or "typescript"
# =============================================================================

SKILL_JS_TS_DEBUG = """You are a JavaScript/TypeScript debugging expert.

Error details:
  Type: {error_type}
  Message: {error_message}
  File: {file}, Line: {line}
  Runtime: Node.js / Browser (inferred from stack)

Code context:
{context}

JS/TS-specific checks:

TypeError: Cannot read property X of undefined/null:
  → Optional chaining: obj?.prop?.subprop
  → Async function returning before data is ready
  → Event handler firing before DOM is ready
  → fetch() response not awaited before .json()

ReferenceError: X is not defined:
  → Variable declared with let/const in block scope
  → Missing import statement
  → Typo in variable name (case-sensitive)
  → Accessing module.exports vs ES module export default

UnhandledPromiseRejectionWarning:
  → Missing await on async function
  → Missing .catch() on Promise chain
  → try/catch not covering async code
  → Promise.all() where one rejects

Maximum call stack size exceeded:
  → Recursive function without base case
  → Circular object reference in JSON.stringify
  → Infinite reactive loop (Vue/React state mutation in render)

CORS errors / Network errors:
  → Missing Access-Control-Allow-Origin header
  → Preflight request failing (OPTIONS not handled)

Respond ONLY with valid JSON:
{{
  "js_error_category": "null_undefined|scope|unhandled_promise|call_stack|cors|event_timing|import_export|other",
  "root_cause": "precise explanation",
  "fix_description": "what to change",
  "code_before": "exact snippet",
  "code_after": "fixed snippet",
  "fix_type": "null_check|missing_import|wrong_type|logic_error|resource_leak|other",
  "confidence": 0.87,
  "typescript_specific": "any TypeScript type annotation fix needed",
  "side_effects": "any risks",
  "prevention": "how to avoid this class of error"
}}"""


# =============================================================================
# SKILL: Go Debugging
# Used by: Step 4 when language = "go"
# =============================================================================

SKILL_GO_DEBUG = """You are a Go language debugging expert.

Error details:
  Panic/Error: {error_type}: {error_message}
  File: {file}, Line: {line}
  Goroutine count at crash: {frame_count}

Stack (goroutine dump):
{context}

Go-specific checks:

nil pointer dereference:
  → Interface value is nil but concrete type is expected
  → Pointer returned from function not checked for nil
  → Map key not present (map returns zero value, not error)

concurrent map read/write:
  → Map shared between goroutines without sync.RWMutex
  → sync.Map should be used for concurrent access

channel deadlock (all goroutines asleep):
  → Unbuffered channel send with no receiver running
  → Circular channel dependency
  → WaitGroup.Wait() called without matching Done()

index out of range:
  → Slice bounds not checked before access
  → Off-by-one in loop
  → Slice modified during range iteration

goroutine leak:
  → Goroutine started but channel it reads from never written to
  → Context not cancelled when goroutine should exit
  → Select without default block blocking forever

Respond ONLY with valid JSON:
{{
  "go_error_category": "nil_deref|concurrent_map|channel_deadlock|index_oob|goroutine_leak|interface_nil|other",
  "root_cause": "precise explanation",
  "fix_description": "what to change",
  "code_before": "exact snippet",
  "code_after": "fixed snippet",
  "fix_type": "null_check|missing_import|wrong_type|logic_error|resource_leak|other",
  "confidence": 0.86,
  "goroutine_leak_risk": false,
  "context_cancellation_needed": false,
  "side_effects": "any risks",
  "prevention": "how to avoid this class of error"
}}"""


# =============================================================================
# SKILL: Async / Event Loop Error Analysis
# Used by: When error occurs inside async/await, coroutine, or event loop
# =============================================================================

SKILL_ASYNC_ERROR_ANALYSIS = """You are an async programming debugging specialist.

This error occurred in an async/concurrent context.

Error: {error_type}: {error_message}
Language: {language}
Async framework hints: {technologies}

Code context:
{context}

Async-specific failure modes to check:

Python asyncio:
  → RuntimeError: no running event loop — calling async code from sync context
  → RuntimeError: Event loop is closed — using loop after shutdown
  → Coroutine never awaited warning — forgot await keyword
  → asyncio.TimeoutError — use async with asyncio.timeout() or asyncio.wait_for()
  → Blocking call in event loop (time.sleep, requests.get, open()) — use asyncio equivalents

JavaScript (Node.js):
  → UnhandledPromiseRejection — missing .catch() or try/await block
  → Callback called multiple times — guard with called flag
  → EventEmitter memory leak — too many listeners, call removeListener
  → setImmediate vs process.nextTick vs Promise.resolve() ordering confusion

Java CompletableFuture:
  → CompletionException wrapping the real error — unwrap with getCause()
  → thenApply vs thenCompose confusion (returning nested CompletableFuture)
  → ExecutionException from .get() — always check getCause()

Go:
  → Goroutine leak from channel never closed
  → Context deadline exceeded vs context cancelled — handle both
  → WaitGroup counter going negative — Done() called more than Add()

Respond ONLY with valid JSON:
{{
  "async_error_category": "no_event_loop|loop_closed|forgot_await|blocking_in_async|unhandled_promise|goroutine_leak|context_timeout|concurrent_access|other",
  "root_cause": "precise explanation",
  "fix_description": "what to change",
  "code_before": "exact snippet",
  "code_after": "fixed snippet with proper async handling",
  "fix_type": "null_check|missing_import|wrong_type|logic_error|resource_leak|other",
  "confidence": 0.84,
  "requires_refactor": false,
  "refactor_description": "if requires_refactor, what restructuring is needed",
  "side_effects": "any risks",
  "prevention": "how to avoid async errors in this codebase"
}}"""


# =============================================================================
# SKILL: Deep Call Chain Analysis
# Used by: When stack trace has 50+ frames (find the user code in the noise)
# =============================================================================

SKILL_DEEP_CALL_CHAIN = """You are a stack trace analysis specialist for deeply nested call chains.

This stack trace has many frames. Your task is to find the user's code amid framework/library frames.

Total frames: {frame_count}
Language: {language}
Technologies: {technologies}

Full call chain (summarized):
{call_chain}

Rules for finding the real bug location:
1. Framework frames (spring, django, flask, express, net/http) are rarely the bug.
2. The bug is usually in the LAST user-code frame before entering a library.
3. Look for the frame with a path that doesn't contain: site-packages, node_modules,
   JAVA_HOME, jdk, jre, stdlib, runtime, framework, vendor.
4. If all frames are library code → the bug is in how the library is CALLED (configuration).
5. Chained exceptions: the INNERMOST cause is usually the real root.

Respond ONLY with valid JSON:
{{
  "user_code_frames": [
    {{"file": "app/services/user.py", "line": 42, "function": "save_user", "is_likely_root": true}}
  ],
  "library_frames_count": 47,
  "user_frames_count": 3,
  "real_bug_location": {{"file": "app/services/user.py", "line": 42, "function": "save_user"}},
  "is_library_configuration_issue": false,
  "innermost_cause": "AttributeError: NullPointerException in user-service database call",
  "chain_summary": ["HTTP request → Django view → UserService.save → DB adapter → None.insert"],
  "root_cause": "precise explanation of what user code did wrong",
  "fix_direction": "where to look and what to change"
}}"""


# =============================================================================
# SKILL: Concurrent / Race Condition Debugging
# Used by: When error is timing-dependent or involves shared state
# =============================================================================

SKILL_CONCURRENT_ERROR = """You are a concurrency debugging specialist.

This error appears to be concurrency-related (race condition, deadlock, or thread safety).

Error: {error_type}: {error_message}
Language: {language}
Thread/goroutine count: {frame_count}

Code context:
{context}

Concurrency failure patterns:

Race condition indicators:
  → Error only happens under load
  → Error involves shared mutable state (global variable, class attribute, singleton)
  → Works in single-threaded test but fails in production
  → ConcurrentModificationException, concurrent map write

Deadlock indicators:
  → All goroutines/threads asleep (Go)
  → Thread dump shows BLOCKED state on lock held by another BLOCKED thread
  → Lock acquisition order inconsistent

Starvation indicators:
  → Thread pool fully occupied
  → Priority inversion (low-priority task blocking high-priority)

Memory visibility:
  → Java: field not declared volatile, changes not visible across threads
  → Go: memory not synchronized through channel or sync primitive

Respond ONLY with valid JSON:
{{
  "concurrency_issue_type": "race_condition|deadlock|starvation|memory_visibility|atomic_violation|other",
  "shared_resource": "the variable/object being contested",
  "threads_involved": 2,
  "fix_description": "synchronization strategy to apply",
  "code_before": "original code",
  "code_after": "thread-safe version",
  "fix_type": "logic_error",
  "confidence": 0.78,
  "requires_architecture_change": false,
  "lock_strategy": "mutex|rwlock|channel|atomic|synchronized|volatile|none",
  "side_effects": "performance impact of locking",
  "prevention": "design pattern to avoid this class of race"
}}"""


# =============================================================================
# SKILL: Third-party Library Error
# Used by: When error_is_external_library = true and user code is only 1-2 frames
# =============================================================================

SKILL_LIBRARY_ERROR = """You are a third-party library integration debugging specialist.

The error is inside a library. Your job is to find what the USER CODE did wrong
when calling the library — not to fix the library itself.

Error: {error_type}: {error_message}
Library: {root_file} (detected as external)
User code entry point: {function}
Language: {language}

Context around the library call:
{context}

Investigation approach:
1. What did the user code pass to the library call that triggered this?
2. Is there a precondition the library requires that the user code violated?
3. Is the library version incompatible with how it's being called?
4. Is there a lifecycle method (init, close, connect) that was missed?
5. Is there a known bug in this library version that requires a workaround?

Respond ONLY with valid JSON:
{{
  "user_code_mistake": "what the user code did wrong at the library boundary",
  "library_precondition_violated": "what the library expected vs what it got",
  "fix_location": "user code, not the library",
  "fix_description": "what to change in the calling code",
  "code_before": "user code snippet before the library call",
  "code_after": "corrected calling code",
  "fix_type": "null_check|missing_import|wrong_type|logic_error|resource_leak|other",
  "confidence": 0.75,
  "library_version_issue": false,
  "version_note": "if version_issue=true, which version is needed and why",
  "workaround_available": false,
  "side_effects": "any risks",
  "prevention": "defensive coding pattern for library calls"
}}"""


# =============================================================================
# SKILL: Memory Error Analysis
# Used by: When error_type contains OOM, MemoryError, OutOfMemoryError
# =============================================================================

SKILL_MEMORY_ERROR_ANALYSIS = """You are a memory analysis and debugging specialist.

Memory-related error detected.

Error: {error_type}: {error_message}
Language: {language}
Technologies: {technologies}

Memory context from logs:
{context}

Memory failure analysis:

Python MemoryError:
  → Large list/dict accumulating in memory (unbounded cache)
  → Generator not used where list comprehension is (loading all into RAM)
  → Circular references preventing GC (check with gc.collect())
  → C extension holding memory (numpy, pandas not releasing)

Java OutOfMemoryError:
  → Java heap: large object, collection not cleared, listener not removed
  → Metaspace: classloader leak (dynamic class generation, reflection abuse)
  → Direct buffer: NIO ByteBuffer not released
  → GC overhead: too many small objects, GC spending >98% time

Go:
  → Slice capacity retained (large backing array kept alive by small slice)
  → Goroutine stack (millions of goroutines, each using 2KB minimum)
  → String concatenation in loop (use strings.Builder)

Respond ONLY with valid JSON:
{{
  "memory_error_category": "heap_exhaustion|metaspace|gc_overhead|direct_buffer|unbounded_cache|memory_leak|large_allocation|goroutine_stack|other",
  "estimated_memory_used_mb": 0,
  "memory_limit_mb": 0,
  "leak_suspected": true,
  "leak_location": "where memory is being held",
  "fix_description": "what to change",
  "code_before": "problematic code",
  "code_after": "memory-efficient version",
  "fix_type": "resource_leak",
  "confidence": 0.82,
  "jvm_tuning": "any -Xmx/-Xms/-XX flags if Java",
  "monitoring_recommendation": "metric to watch to confirm fix worked",
  "side_effects": "any risks",
  "prevention": "memory management pattern to adopt"
}}"""


# =============================================================================
# SKILL: Security-aware Patch Review
# Used by: Step 5 patch review when the patch touches auth/crypto/input handling
# =============================================================================

SKILL_SECURITY_PATCH_REVIEW = """You are a security engineer reviewing a code patch.

Original error: {error_type}: {error_message}

Proposed patch:
{patch}

Security review checklist:
1. Does the fix introduce new injection vectors? (SQL, command, path traversal)
2. Does the fix bypass authentication or authorization checks?
3. Does the fix introduce hardcoded secrets or credentials?
4. Does the fix use weak cryptography? (MD5, SHA1 for passwords, ECB mode)
5. Does the fix introduce insecure deserialization?
6. Does the fix expose sensitive data in logs or error messages?
7. Does the fix create a TOCTOU (time-of-check-time-of-use) race?
8. Does the fix introduce open redirect or SSRF?
9. Does the fix properly validate and sanitize user input?
10. Does the fix close the file/connection/resource on ALL code paths?

Respond ONLY with valid JSON:
{{
  "security_approved": true,
  "security_issues_found": [
    {{"severity": "HIGH", "type": "sql_injection", "description": "user input not parameterized in new query"}}
  ],
  "fixes_original_error": true,
  "introduces_new_vulnerability": false,
  "vulnerability_type": null,
  "cwe_ids": [],
  "secure_coding_recommendations": ["use parameterized queries", "validate input length"],
  "overall_verdict": "approve|approve_with_changes|reject",
  "reviewer_notes": "summary of security assessment"
}}"""


# =============================================================================
# SKILL: Test Case Suggestion
# Used by: After patch generation to suggest how to verify the fix
# =============================================================================

SKILL_PATCH_TEST_SUGGESTION = """You are a test engineer reviewing a bug fix.

Bug fixed: {error_type}: {error_message}
Fix applied: {fix_description}
Language: {language}

Suggest test cases that would:
1. Reproduce the original bug (regression test).
2. Verify the fix works.
3. Test edge cases around the fix.
4. Test that the fix doesn't break adjacent behavior.

Respond ONLY with valid JSON:
{{
  "test_cases": [
    {{
      "name": "test_save_user_with_none_db",
      "type": "unit",
      "description": "Verify that save_user raises ValueError when db is None",
      "setup": "db = None",
      "action": "save_user(db, user)",
      "expected": "raises ValueError with message 'db connection required'",
      "is_regression_test": true
    }},
    {{
      "name": "test_save_user_happy_path",
      "type": "unit",
      "description": "Verify normal save still works after fix",
      "setup": "db = MockDB()",
      "action": "save_user(db, valid_user)",
      "expected": "user saved, no exception",
      "is_regression_test": false
    }}
  ],
  "test_framework": "pytest|junit|jest|go_test|rspec",
  "coverage_areas": ["null handling", "normal operation", "boundary conditions"],
  "integration_test_needed": false,
  "integration_test_description": ""
}}"""


# =============================================================================
# SKILL: Error Prevention Architecture
# Used by: When the same error class keeps recurring (memory stores pattern)
# =============================================================================

SKILL_ERROR_PREVENTION = """You are a software architect specializing in error prevention.

This error has occurred multiple times. Recommend architectural changes to prevent recurrence.

Error class: {error_type}
Occurrences: {occurrence_count}
Affected components: {affected_components}
Language/framework: {language}
Fix history: {fix_history}

Provide architectural recommendations:
1. Design patterns that prevent this error class.
2. Static analysis / linter rules to catch it at development time.
3. Runtime guards (circuit breakers, health checks, rate limits).
4. Monitoring/alerting improvements to catch it earlier.
5. Testing strategy improvements.
6. Documentation / developer education.

Respond ONLY with valid JSON:
{{
  "root_pattern": "the underlying pattern that keeps causing this error",
  "design_recommendations": [
    {{"pattern": "Null Object Pattern", "description": "return empty object instead of null", "effort": "low|medium|high"}}
  ],
  "static_analysis_tools": ["pylint null-check rule", "mypy --strict"],
  "runtime_guards": ["connection pool health check", "circuit breaker on DB calls"],
  "monitoring_improvements": ["alert when null_db_connection_count > 0", "dashboard for connection pool usage"],
  "testing_improvements": ["add null-db integration test to CI", "chaos engineering: kill DB mid-request"],
  "estimated_prevention_confidence": 0.85,
  "implementation_priority": "immediate|this_sprint|this_quarter"
}}"""


# =============================================================================
# SKILL: Multiple Simultaneous Error Triage
# Used by: When logs contain 3+ different error types occurring together
# =============================================================================

SKILL_MULTI_ERROR_TRIAGE = """You are a systems reliability engineer triaging a multi-failure event.

Multiple errors are occurring simultaneously. Find the single root cause.

Errors detected:
{error_list}

Timeline:
{timeline}

Technologies: {technologies}

Multi-failure analysis:
1. Sort errors by first occurrence timestamp.
2. Identify which error occurred FIRST.
3. Determine if subsequent errors are symptoms of the first (cascading).
4. Identify independent errors that have separate root causes.
5. Prioritize the fix order.

Respond ONLY with valid JSON:
{{
  "root_error": "the error that triggered everything else",
  "root_error_time": "2025-01-15T10:23:45Z",
  "is_cascading_failure": true,
  "cascade_chain": [
    {{"time": "10:23:45", "error": "DB connection refused", "caused_by": "root"}},
    {{"time": "10:23:46", "error": "NullPointerException in UserService", "caused_by": "DB connection refused"}},
    {{"time": "10:23:47", "error": "HTTP 500 on /api/users", "caused_by": "NullPointerException"}}
  ],
  "independent_errors": [
    {{"error": "CSS minification warning", "is_independent": true, "severity": "LOW"}}
  ],
  "fix_priority": [
    {{"priority": 1, "error": "DB connection refused", "reason": "fixes 3 downstream errors"}},
    {{"priority": 2, "error": "NullPointerException", "reason": "add null guard as defence-in-depth"}}
  ],
  "estimated_fixes_needed": 1,
  "summary": "DB connection failure at 10:23:45 caused cascade of 3 downstream errors"
}}"""
