"""
Base Agent Class for Log Analysis Multi-Agent System

All agents inherit from this class. It provides:
- Capability contract management
- A2A message handling
- Model access
- Self-awareness (can_handle checks)
"""

import json
import uuid
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from enum import Enum
from abc import ABC, abstractmethod
from datetime import datetime

# ═══════════════════════════════════════════════════════════════════════════════
# SINGLE SOURCE OF TRUTH: Import A2A types from communication/a2a_protocol.py
# All agents and the communication bus use these exact same classes.
# ═══════════════════════════════════════════════════════════════════════════════
from communication.a2a_protocol import (
    A2AMessage,
    MessageType,
    MessagePriority,
    DeliveryStatus,
    CapabilityQuery,
    CapabilityResponse,
    ErrorCodes
)


# ═══════════════════════════════════════════════════════════════════════════════
# Agent State Enum (only defined here — not in a2a_protocol)
# ═══════════════════════════════════════════════════════════════════════════════

class AgentState(Enum):
    IDLE = "idle"
    PROCESSING = "processing"
    WAITING_FOR_HUMAN = "waiting_for_human"
    WAITING_FOR_AGENT = "waiting_for_agent"
    ERROR = "error"


# ═══════════════════════════════════════════════════════════════════════════════
# Capability Contract (agent-specific, not in a2a_protocol)
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class CapabilityContract:
    """Machine-readable capability declaration for each agent"""
    agent_name: str
    agent_id: str
    domain: str
    capabilities: List[str]
    limitations: List[str]
    preconditions: List[str]
    required_tools: List[str] = field(default_factory=list)
    fallback_agents: List[str] = field(default_factory=list)
    confidence_threshold: float = 0.5
    max_iterations: int = 3
    out_of_scope_message: str = "This task is outside my capabilities."

    @classmethod
    def from_json(cls, path: str) -> "CapabilityContract":
        """Load capability contract from JSON file"""
        with open(path, 'r') as f:
            data = json.load(f)
        return cls(**data)

    def to_dict(self) -> Dict:
        """Convert to dictionary for serialization"""
        return {
            "agent_name": self.agent_name,
            "agent_id": self.agent_id,
            "domain": self.domain,
            "capabilities": self.capabilities,
            "limitations": self.limitations,
            "preconditions": self.preconditions,
            "required_tools": self.required_tools,
            "fallback_agents": self.fallback_agents,
            "confidence_threshold": self.confidence_threshold,
            "max_iterations": self.max_iterations,
            "out_of_scope_message": self.out_of_scope_message
        }


# ═══════════════════════════════════════════════════════════════════════════════
# Agent Response (structured return from agent processing)
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class AgentResponse:
    """Structured response from agent processing"""
    success: bool
    data: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None
    confidence: float = 1.0
    caveats: List[str] = field(default_factory=list)
    requires_human: bool = False
    human_question: Optional[str] = None
    next_agent_suggestion: Optional[str] = None
    state_changes: Dict[str, Any] = field(default_factory=dict)


# ═══════════════════════════════════════════════════════════════════════════════
# Base Agent Class
# ═══════════════════════════════════════════════════════════════════════════════

class BaseAgent(ABC):
    """
    Base class for all agents in the Log Analysis Multi-Agent System.

    Every agent:
    - Has a capability contract defining what it can/cannot do
    - Communicates via A2A messages through the communication bus
    - Can access models through the model manager
    - Self-evaluates whether it can handle incoming tasks
    """

    def __init__(self, agent_id: str, capability_path: str):
        """
        Initialize the agent.

        Args:
            agent_id: Unique identifier for this agent instance
            capability_path: Path to the capabilities.json file
        """
        self.agent_id = agent_id
        self.capability = CapabilityContract.from_json(capability_path)
        self.state = AgentState.IDLE
        self.comm_bus = None  # Set by CommunicationBus during registration
        self.model_manager = None  # Set during system initialization
        self.processing_history: List[Dict] = []
        self.current_task: Optional[Dict] = None

    # ═══════════════════════════════════════════════════════════════════════════
    # Core Methods (Override in subclasses)
    # ═══════════════════════════════════════════════════════════════════════════

    @abstractmethod
    async def process(self, message: A2AMessage) -> A2AMessage:
        """
        Process an incoming A2A message.

        MUST be implemented by every agent subclass.

        Args:
            message: The A2A message to process

        Returns:
            A2AMessage with the response
        """
        pass

    # ═══════════════════════════════════════════════════════════════════════════
    # Message Handling
    # ═══════════════════════════════════════════════════════════════════════════

    async def receive_message(self, message: A2AMessage) -> Optional[A2AMessage]:
        """
        Called by the communication bus when a message arrives for this agent.

        Performs pre-processing checks before calling process().
        """
        # Check TTL
        if message.ttl <= 0:
            return self._create_error_response(
                message, "Message TTL expired"
            )

        # Decrement TTL
        message.ttl -= 1
        message.route_history.append(self.agent_id)

        # Check if we can handle this
        if message.task and not self.can_handle(message.task):
            return self._create_cannot_handle_response(message)

        # Update state
        self.state = AgentState.PROCESSING
        self.current_task = message.task

        try:
            # Process the message
            response = await self.process(message)
            self.processing_history.append({
                "task": message.task,
                "response": response.to_dict(),
                "timestamp": datetime.now().isoformat()
            })
            return response

        except Exception as e:
            self.state = AgentState.ERROR
            return self._create_error_response(message, str(e))

        finally:
            if self.state != AgentState.ERROR:
                self.state = AgentState.IDLE
            self.current_task = None

    async def send_message(self, message: A2AMessage):
        """
        Send a message via the communication bus.

        Args:
            message: The A2A message to send
        """
        if self.comm_bus:
            message.sender_id = self.agent_id
            message.sender_type = self.capability.agent_name
            await self.comm_bus.send_message(message)
        else:
            raise RuntimeError(
                f"Agent {self.agent_id} is not connected to a communication bus"
            )

    # Function for handling capabilities of agents
    def _can_handle_action(self, action: str) -> bool:
        """
        Map high-level action to this agent's capabilities.
        Each agent decides what actions it supports.
        """
        action_map = {
            "extract": [
                "extract_from_text_file",
                "extract_from_log_file",
                "extract_from_json",
                "extract_from_csv",
                "extract_from_xml",
                "extract_from_image",
                "extract_from_terminal",
                "extract_from_syslog",
                "extract_from_apache_log",
                "extract_from_pasted_text"
            ],
            "preprocess": [
                "clean_logs",
                "parse_logs",
                "chunk_large_inputs"
            ],
            "analyze": [
                "classify_logs",
                "detect_intent"
            ],
            "solve": [
                "root_cause_analysis",
                "generate_fix_suggestions"
            ],
            "debug": [
                "parse_stack_trace",
                "generate_code_patch"
            ],
            "validate": [
                "validate_solution_quality"
            ]
        }

        required_caps = action_map.get(action, [])

        # If agent has ANY matching capability → accept
        return any(cap in self.capability.capabilities for cap in required_caps)

    # ═══════════════════════════════════════════════════════════════════════════
    # Self-Awareness Methods
    # ═══════════════════════════════════════════════════════════════════════════

    def can_handle(self, task: Dict) -> bool:
        """
        Self-awareness check: Can this agent handle the given task?

        Checks:
        1. Domain match
        2. Required capability present
        3. Preconditions met

        Returns True if agent can handle, False otherwise.
        """
        # Check domain if specified
        # task_domain = task.get("domain")
        # if task_domain and task_domain != self.capability.domain:
        #     return False

        # self.log(
        #     f"can_handle [{self.capability.agent_name}]: task_domain={task.get('domain')}, req_cap={task.get('required_capability')}, req_caps={task.get('required_capabilities')}, preconditions_checking={self.capability.preconditions}",
        #     "DEBUG")
        #
        # # Check required capability
        # required_capability = task.get("required_capability")
        # action = task.get("action")
        #
        # # 1. If required_capability is explicitly given → use it
        # if required_capability:
        #     if required_capability not in self.capability.capabilities:
        #         return False
        #
        # # 2. If only action is given → let agent decide
        # elif action:
        #     if not self._can_handle_action(action):
        #         return False
        #
        # # Check required capabilities list
        # required_capabilities = task.get("required_capabilities", [])
        # for cap in required_capabilities:
        #     if cap not in self.capability.capabilities:
        #         return False
        #
        # self.log(f"Checking can_handle for task: {task}", "DEBUG")
        # self.log(f"Capabilities: {self.capability.capabilities}", "DEBUG")
        # self.log(f"Preconditions: {self.capability.preconditions}", "DEBUG")

        # Check preconditions
        # context = task.get("context", {})
        # for precondition in self.capability.preconditions:
        #     if not self._evaluate_precondition(precondition, context):
        #         return False

        return True

    def _evaluate_precondition(self, condition: str, context: Dict) -> bool:
        """
        Evaluate a precondition against the current context.

        Simple implementation - can be extended for complex conditions.
        """
        # Check if condition key exists in context with truthy value
        if condition.startswith("state."):
            key = condition.replace("state.", "")
            return bool(context.get(key))

        if condition.startswith("context."):
            key = condition.replace("context.", "")
            return bool(context.get(key))

        # Logs to check condition and context
        self.log(f"Evaluating precondition: {condition} with context: {context}", "DEBUG")

        # Simple key check
        # Custom condition handling
        if condition == "clean_logs_present":
            return bool(context.get("clean_logs"))

        if condition == "raw_logs_present":
            return bool(context.get("raw_logs"))

        if condition == "log_analysis_complete":
            return bool(context.get("analysis"))

        if condition == "solution_generated":
            return bool(context.get("solution"))

        if condition == "original_logs_available":
            return bool(context.get("raw_logs") or context.get("clean_logs"))

        # Generic fallback
        return bool(context.get(condition))

    def what_can_you_do(self) -> str:
        """Return a human-readable capability description"""
        can = ", ".join(self.capability.capabilities)
        cannot = ", ".join(self.capability.limitations)

        return f"""
🤖 Agent: {self.capability.agent_name} ({self.agent_id})
📋 Domain: {self.capability.domain}

✅ I CAN:
   {can}

❌ I CANNOT:
   {cannot}

📎 Required Tools: {", ".join(self.capability.required_tools) if self.capability.required_tools else 'None'}
🔄 Fallback Agents: {", ".join(self.capability.fallback_agents)}
"""

    # ═══════════════════════════════════════════════════════════════════════════
    # Model Access
    # ═══════════════════════════════════════════════════════════════════════════

    async def get_model(self, model_name: str):
        """
        Get a model instance from the model manager.

        Args:
            model_name: One of 'gemma', 'qwen_small', 'deepseek_ocr', 'embedding'

        Returns:
            Model instance for inference
        """
        if self.model_manager:
            return await self.model_manager.get_model(model_name)
        else:
            raise RuntimeError(
                f"Agent {self.agent_id} has no model manager configured"
            )

    async def release_model(self, model_name: str):
        """Release a model back to the pool"""
        if self.model_manager:
            await self.model_manager.release_model(model_name)

    # ═══════════════════════════════════════════════════════════════════════════
    # Helper Methods
    # ═══════════════════════════════════════════════════════════════════════════

    def _create_error_response(self, original_message: A2AMessage, error: str) -> A2AMessage:
        """Create an error response message"""
        return A2AMessage(
            message_type=MessageType.ERROR,
            sender_id=self.agent_id,
            sender_type=self.capability.agent_name,
            target_id=original_message.sender_id,
            correlation_id=original_message.message_id,
            error=error,
            context={"original_task": original_message.task}
        )

    def _create_cannot_handle_response(self, message: A2AMessage) -> A2AMessage:
        """Create response for tasks this agent cannot handle"""
        return A2AMessage(
            message_type=MessageType.RESPONSE,
            sender_id=self.agent_id,
            sender_type=self.capability.agent_name,
            target_id=message.sender_id,
            correlation_id=message.message_id,
            response={
                "can_handle": False,
                "reason": self.capability.out_of_scope_message,
                "suggested_agents": self.capability.fallback_agents,
                "my_capabilities": self.capability.capabilities
            },
            confidence=0.0
        )

    def _create_human_request(self, question: str) -> A2AMessage:
        """Create a message requesting human input"""
        self.state = AgentState.WAITING_FOR_HUMAN
        return A2AMessage(
            message_type=MessageType.HUMAN_INPUT_REQUEST,
            sender_id=self.agent_id,
            sender_type=self.capability.agent_name,
            requires_human=True,
            human_question=question
        )

    def log(self, message: str, level: str = "INFO"):
        """Simple logging helper"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        print(f"[{timestamp}] [{self.capability.agent_name}] [{level}] {message}")
