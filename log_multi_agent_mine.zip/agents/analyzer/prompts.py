"""
Skill Prompts for the Analyzer Agent.

The Analyzer classifies logs, detects user intent, identifies severity,
and detects patterns before the Solver performs deep analysis.

Uses Gemma-4-E4B (primary reasoning model).

Skill catalogue:
  SKILL_LOG_CLASSIFICATION        — Classify log type from content and structure
  SKILL_INTENT_DETECTION          — Determine what the user wants to do
  SKILL_SEVERITY_ASSESSMENT       — Assess severity level of the incident
  SKILL_PATTERN_DETECTION         — Detect recurring patterns and anomalies
  SKILL_TECHNOLOGY_IDENTIFICATION — Identify technology stack from log entries
  SKILL_ANOMALY_FLAGGING          — Flag unusual patterns needing attention
  SKILL_LOG_HEALTH_SCORING        — Score overall log quality and completeness
  SKILL_TRIAGE_PRIORITIZATION     — Prioritize multiple issues found in logs
"""


# =============================================================================
# SKILL: Log Classification
# Used by: Primary analysis step — classify the log type
# =============================================================================

SKILL_LOG_CLASSIFICATION = """You are a log analysis specialist classifying log entries.

Log content (first 3000 chars):
{clean_logs}

Pre-parsed metadata:
  Format: {format}
  Entry count: {entry_count}
  Has timestamps: {has_timestamps}

Classify the log into ONE primary type from this taxonomy:

ERROR LOGS:
  python_traceback  — Python stack trace with Traceback, File, line numbers
  java_stacktrace   — Java exception with at com., at org., Caused by
  js_error          — JavaScript/TypeScript error with .js/.ts file references
  go_panic          — Go panic with goroutine dump
  system_error      — OS-level errors (segfault, OOM, kernel panic)

SERVER LOGS:
  apache_access     — Apache/Nginx access log (IP, method, status, bytes)
  apache_error      — Apache/Nginx error log ([day month time year] [level])
  iis_log           — Microsoft IIS log format
  envoy_log         — Envoy proxy log format

APPLICATION LOGS:
  json_log          — Structured JSON log entries
  ndjson            — Newline-delimited JSON (one JSON object per line)
  application_log   — Generic application log with timestamps and levels
  mobile_app_log    — Mobile application crash/analytics log

SYSTEM LOGS:
  syslog_rfc5424    — Syslog with structured data (<priority>version timestamp)
  syslog_bsd        — BSD syslog (month day time host tag)
  windows_event     — Windows Event Log format
  kubernetes_log    — Kubernetes container log (I/W/E/F date time)
  docker_log        — Docker daemon or container log
  systemd_journal   — Systemd journal export format

SECURITY LOGS:
  auth_log          — Authentication/authorization logs
  firewall_log      — Firewall deny/allow logs
  ids_alert         — Intrusion detection system alert

DATABASE LOGS:
  postgres_log      — PostgreSQL log format
  mysql_log         — MySQL/MariaDB log format
  mongodb_log       — MongoDB log format
  redis_log         — Redis log format

CLOUD LOGS:
  cloudwatch_log    — AWS CloudWatch log format
  stackdriver_log   — GCP Stackdriver/Cloud Logging
  azure_monitor     — Azure Monitor log format

Data LOGS:
  csv               — Comma-separated values
  tsv               — Tab-separated values
  xml               — XML-formatted log entries

Rules:
  - If you see "Traceback (most recent call last)" → python_traceback
  - If you see "at com." or "at org." → java_stacktrace
  - JSON lines starting with {{ that contain "level"/"severity" → json_log
  - Lines starting with I/W/E/F followed by 4-digit date → kubernetes_log
  - IP address followed by [timestamp] "METHOD → apache_access
  - <digit> followed by timestamp → syslog_rfc5424

If you cannot determine the type, use "unknown" with confidence < 0.3.

Respond ONLY with valid JSON:
{{
  "log_type": "exact_type_from_taxonomy",
  "confidence": 0.0-1.0,
  "reasoning": "one sentence explaining the classification",
  "alternative_types": ["other possible types if uncertain"],
  "format_indicators": ["specific patterns that led to this classification"],
  "is_mixed_format": false,
  "technology_stack_hint": "python|java|node|go|dotnet|unknown"
}}"""


# =============================================================================
# SKILL: Intent Detection
# Used by: Determine what the user wants to accomplish
# =============================================================================

SKILL_INTENT_DETECTION = """You are an intent detection specialist for a log analysis system.

User query: {query}
Log type detected: {log_type}
Log sample (first 500 chars): {clean_logs}

Determine the user's PRIMARY intent from this taxonomy:

DEBUGGING:
  → User has an error and wants to know why it happened
  → Indicators: "why", "what caused", "fix", "debug", "error", "crash", "bug"
  → Expected output: Root cause analysis + fix suggestions

EXPLANATION:
  → User wants to understand what the logs mean
  → Indicators: "explain", "what does this mean", "help understand", "translate"
  → Expected output: Plain-language explanation of log entries

OPTIMIZATION:
  → User wants to improve performance
  → Indicators: "slow", "performance", "optimize", "speed", "latency", "timeout"
  → Expected output: Performance analysis + optimization suggestions

SECURITY_AUDIT:
  → User suspects security issue
  → Indicators: "attack", "breach", "unauthorized", "hacked", "suspicious", "scan"
  → Expected output: Security incident analysis + mitigation steps

HEALTH_CHECK:
  → User wants to know if the system is healthy
  → Indicators: "health", "status", "check", "monitor", "overview", "summary"
  → Expected output: System health report + recommendations

ROOT_CAUSE_ANALYSIS:
  → User wants deep root cause investigation
  → Indicators: "root cause", "rca", "why did this fail", "what triggered"
  → Expected output: Detailed RCA with evidence chain

GENERAL_ANALYSIS:
  → Default — user provided logs without specific intent
  → Expected output: Classification + severity + basic pattern detection

Rules:
  - If the user query is just a file path or pasted logs → GENERAL_ANALYSIS
  - If the user asks a specific question about the logs → match to intent above
  - If multiple intents match → pick the most specific one

Respond ONLY with valid JSON:
{{
  "primary_intent": "debugging|explanation|optimization|security_audit|health_check|root_cause_analysis|general_analysis",
  "confidence": 0.0-1.0,
  "secondary_intent": "secondary intent or null",
  "reasoning": "why this intent was selected",
  "user_technical_level": "beginner|intermediate|expert",
  "expected_output_type": "root_cause_analysis|explanation|fix_suggestion|health_report|security_analysis|summary"
}}"""


# =============================================================================
# SKILL: Severity Assessment
# Used by: Determine how critical the incident is
# =============================================================================

SKILL_SEVERITY_ASSESSMENT = """You are an incident severity assessment specialist.

Log content sample:
{clean_logs}

Log type: {log_type}
Patterns detected: {pattern_results}

Assess severity using this framework:

CRITICAL (SEV0/SEV1):
  → Service completely unavailable to all users
  → Data loss or corruption occurring
  → Security breach in progress
  → Keywords: "FATAL", "CRITICAL", "panic", "kernel panic", "OutOfMemoryError"
  → Response: Immediate escalation, war room, all hands

ERROR (SEV2):
  → Major feature broken for most users
  → Cascading failures affecting multiple services
  → Repeated errors with no successful requests
  → Keywords: "ERROR", "Exception", "Failed", "refused", "denied"
  → Response: On-call engineer investigates immediately

WARNING (SEV3):
  → Intermittent failures affecting some users
  → Degraded performance but service still available
  → First occurrence of a new error pattern
  → Keywords: "WARN", "Warning", "timeout", "retry", "degraded"
  → Response: Investigate during business hours

INFO (SEV4):
  → Normal operations with expected errors handled
  → Informational messages about system state
  → Routine maintenance events
  → Keywords: "INFO", "started", "completed", "success"
  → Response: No action needed, monitor for changes

Rules:
  - If the SAME error repeats > 5 times in the sample → upgrade severity by one level
  - If the error involves "database" or "authentication" → add +1 severity weight
  - If the error is a known handled exception with recovery → downgrade by one level
  - If timestamps show the error is no longer occurring → note "possibly resolved"

Respond ONLY with valid JSON:
{{
  "severity": "CRITICAL|ERROR|WARNING|INFO",
  "severity_score": 0-100,
  "confidence": 0.0-1.0,
  "escalation_needed": true,
  "escalation_reason": "why escalation is or isn't needed",
  "urgency_factors": [
    "specific factors that increase urgency"
  ],
  "mitigating_factors": [
    "factors that reduce urgency"
  ],
  "recommended_response_time": "immediate|within_1_hour|within_4_hours|within_24_hours|no_rush",
  "is_ongoing": true,
  "error_frequency": "once|intermittent|continuous|resolved",
  "affected_user_estimate": "all|most|some|few|none"
}}"""


# =============================================================================
# SKILL: Pattern Detection
# Used by: Detect recurring patterns and known error signatures
# =============================================================================

SKILL_PATTERN_DETECTION = """You are a pattern recognition specialist analyzing log entries.

Log content:
{clean_logs}

Detect these pattern categories:

1. ERROR PATTERNS
   → Repeated identical errors (count occurrences)
   → Error rate over time (increasing, decreasing, steady)
   → New errors vs known recurring errors
   → Error clustering (same component, same time window)

2. TEMPORAL PATTERNS
   → Time-of-day patterns (errors peak at specific hours)
   → Periodic patterns (every N minutes/hours)
   → Burst patterns (sudden spike then silence)
   → Gradual degradation (slow increase over time)

3. DEPENDENCY PATTERNS
   → Which services fail together?
   → Order of failures (A fails, then B, then C)
   → Shared dependencies (do all failures involve the same DB/API?)

4. ANOMALY PATTERNS
   → Unusual error messages never seen before
   → Unexpected severity combinations (WARN with stack trace)
   → Missing expected log entries (gaps in the timeline)
   → Volume anomalies (sudden increase or decrease in log volume)

5. CORRELATION PATTERNS
   → Errors that correlate with specific operations (deploy, backup, cron)
   → Errors that correlate with specific users/IPs/regions
   → Errors that correlate with resource metrics (CPU spike, memory pressure)

Respond ONLY with valid JSON:
{{
  "patterns_found": [
    {{
      "pattern_type": "repeated_error|temporal|dependency|anomaly|correlation",
      "description": "description of the pattern",
      "evidence": ["specific log lines demonstrating this pattern"],
      "significance": "high|medium|low",
      "recommended_action": "what to do about this pattern"
    }}
  ],
  "dominant_pattern": "the most significant pattern found",
  "pattern_count": 3,
  "has_known_error_signature": false,
  "known_signature_match": "name of known error pattern or null",
  "is_anomalous": false,
  "anomaly_description": "what makes this anomalous or null",
  "confidence": 0.0-1.0
}}"""


# =============================================================================
# SKILL: Technology Identification
# Used by: Identify the technology stack from log entries
# =============================================================================

SKILL_TECHNOLOGY_IDENTIFICATION = """You are a technology stack identification specialist.

Log entries:
{clean_logs}

Identify the technology stack from log signatures:

LANGUAGES:
  Python    → "File \".*.py\"", "Traceback", "self.", "NoneType", "django", "flask"
  Java      → "at com.", "at org.", "Exception in thread", "NullPointerException"
  JavaScript→ ".js:", ".ts:", "node_modules/", "Promise", "async", "TypeError: Cannot read"
  Go        → "goroutine", "panic:", ".go:", "runtime error", "defer"
  C#/.NET   → "System.", "Microsoft.", "at .* in .*.cs:line"
  Ruby      → ".rb:", "Rails", "NoMethodError", "undefined method"

FRAMEWORKS:
  Spring Boot → "org.springframework", "EmbeddedWebApplicationContext"
  Django      → "django", "wsgi", "middleware", "ORM"
  Express     → "express", "req.", "res.", "middleware"
  Rails       → "ActionController", "ActiveRecord", "Rails"
  Laravel     → "laravel", "artisan", "eloquent"
  Gin         → "gin", "gin.Context"

DATABASES:
  PostgreSQL → "postgres", "psql", "pg_", "PostgreSQL"
  MySQL      → "mysql", "mysqld", "InnoDB"
  MongoDB    → "mongodb", "mongod", "BSON"
  Redis      → "redis", "sentinel"

SERVERS / INFRASTRUCTURE:
  Nginx      → "nginx", "upstream", "fastcgi"
  Apache     → "Apache", "httpd", "mod_"
  Docker     → "container", "docker", "k8s_"
  Kubernetes → "kube", "k8s.io", "pod", "deployment"
  AWS        → "aws", "ec2", "s3", "lambda", "cloudwatch"
  GCP        → "gcp", "gce", "gke", "stackdriver"
  Azure      → "azure", "aks", "app service"

Respond ONLY with valid JSON:
{{
  "languages": ["python", "java"],
  "frameworks": ["django", "spring"],
  "databases": ["postgresql"],
  "infrastructure": ["kubernetes", "docker", "aws"],
  "confidence": 0.0-1.0,
  "evidence": {{
    "python": "Traceback pattern and .py file references",
    "django": "django.* references in stack trace"
  }},
  "primary_stack": "python/django/postgresql/aws",
  "stack_complexity": "simple|moderate|complex|microservices",
  "observability_maturity": "basic_logging|structured_logging|distributed_tracing|full_observability"
}}"""


# =============================================================================
# SKILL: Anomaly Flagging
# Used by: Flag unusual patterns that need human attention
# =============================================================================

SKILL_ANOMALY_FLAGGING = """You are an anomaly detection specialist reviewing log entries.

Log content:
{clean_logs}

Log type: {log_type}
Known patterns: {pattern_results}

Flag anomalies in these categories:

1. VOLUME ANOMALIES
   → Sudden spike in error count
   → Sudden drop in log volume (logging broken? service down?)
   → Burst of identical messages (stuck retry loop?)

2. CONTENT ANOMALIES
   → Error messages never seen before
   → Stack traces in unexpected locations (INFO level with stack trace)
   → Mixed languages in same log stream (Python + Java in same service)

3. TEMPORAL ANOMALIES
   → Logs outside expected time range (3 AM when nobody deploys)
   → Time gaps (missing minutes/hours of logs)
   → Timestamp going backwards (clock skew, timezone issue)

4. STRUCTURAL ANOMALIES
   → JSON schema change (new fields, missing required fields)
   → Log format inconsistency (mixed formats in same stream)
   → Truncated entries (partial log lines, cut-off stack traces)

5. SECURITY ANOMALIES
   → Authentication failures from new IP ranges
   → Privilege escalation attempts
   → Unusual API paths being accessed
   → Credential patterns in logs (passwords, tokens, keys)

Respond ONLY with valid JSON:
{{
  "anomalies_detected": [
    {{
      "type": "volume|content|temporal|structural|security",
      "severity": "CRITICAL|ERROR|WARNING|INFO",
      "description": "what anomaly was detected",
      "evidence": "specific log lines",
      "first_occurrence": "ISO timestamp or line number",
      "recommended_action": "what to investigate"
    }}
  ],
  "total_anomalies": 0,
  "requires_immediate_attention": false,
  "attention_items": ["anomalies needing human review"],
  "false_positive_risk": "low|medium|high",
  "confidence": 0.0-1.0
}}"""


# =============================================================================
# SKILL: Log Health Scoring
# Used by: Score the quality and completeness of the provided logs
# =============================================================================

SKILL_LOG_HEALTH_SCORING = """You are a log quality assessment specialist.

Log content:
{clean_logs}

Score the log quality across these dimensions (each 0-100):

1. COMPLETENESS (are we seeing the full picture?)
   → Does the log span the full incident window?
   → Are there gaps in timestamps?
   → Are stack traces complete or truncated?
   → Are all relevant services/components represented?

2. STRUCTURE (how well-formed are the entries?)
   → Consistent format throughout?
   → Valid JSON/XML where applicable?
   → Proper timestamp formatting?
   → Consistent field presence?

3. GRANULARITY (right level of detail?)
   → DEBUG/TRACE level available for deep analysis?
   → Request IDs / trace IDs present?
   → User/session context included?
   → Error messages are specific, not generic?

4. SEARCHABILITY (how easy to find relevant entries?)
   → Consistent field names?
   → Standard severity levels?
   → Service/component identification?
   → Correlation IDs for tracing?

5. TIMELINESS (when were these captured?)
   → Timestamps are UTC/ISO?
   → Timezone information present?
   → Clock skew evident between services?
   → Real-time or batch-imported?

Respond ONLY with valid JSON:
{{
  "overall_score": 0-100,
  "scores": {{
    "completeness": 0-100,
    "structure": 0-100,
    "granularity": 0-100,
    "searchability": 0-100,
    "timeliness": 0-100
  }},
  "grade": "A|B|C|D|F",
  "strengths": ["what's good about these logs"],
  "weaknesses": ["what's missing or poor"],
  "improvement_recommendations": [
    {{
      "area": "completeness",
      "recommendation": "specific improvement",
      "effort": "low|medium|high",
      "impact": "low|medium|high"
    }}
  ],
  "sufficient_for_analysis": true,
  "confidence": 0.0-1.0
}}"""


# =============================================================================
# SKILL: Triage Prioritization
# Used by: When multiple issues are found, prioritize which to fix first
# =============================================================================

SKILL_TRIAGE_PRIORITIZATION = """You are an incident triage specialist prioritizing multiple issues.

Issues detected:
{issues}

Resources available:
  Time window: {time_window}
  Team size: {team_size}
  Environment: {environment}

Prioritize using this framework (score each 1-10):

IMPACT (how many users affected?):
  10 = All users, core functionality down
  7  = Many users, major feature degraded
  4  = Some users, minor feature affected
  1  = Few users, cosmetic issue

URGENCY (how quickly does this need fixing?):
  10 = Fix immediately (data loss, security breach)
  7  = Fix within hours (revenue impact, SLA breach)
  4  = Fix within days (degraded experience)
  1  = Fix when convenient (nice to have)

EFFORT (how hard is the fix?):
  10 = One-line config change
  7  = Code change with tests
  4  = Architecture change needed
  1  = Requires external dependency/team

DEPENDENCY (does fixing this unblock others?):
  10 = Fixing this resolves 3+ other issues
  7  = Fixing this resolves 1-2 other issues
  4  = Independent issue
  1  = This issue is a symptom, not a cause

SCORE = (IMPACT × 3) + (URGENCY × 2) + (EFFORT × 1) + (DEPENDENCY × 2)

Sort by SCORE descending. Highest score = fix first.

Respond ONLY with valid JSON:
{{
  "prioritized_issues": [
    {{
      "rank": 1,
      "issue": "description",
      "impact_score": 8,
      "urgency_score": 9,
      "effort_score": 7,
      "dependency_score": 8,
      "total_score": 59,
      "reasoning": "why this is ranked here",
      "suggested_owner": "team or role"
    }}
  ],
  "quick_wins": ["issues with high SCORE and low effort"],
  "can_be_deferred": ["low SCORE issues"],
  "parallel_work_possible": true,
  "suggested_workstreams": [
    {{
      "workstream": "name",
      "issues": ["issues to handle in parallel"],
      "team": "assigned team"
    }}
  ],
  "estimated_total_effort": "hours or days"
}}"""
