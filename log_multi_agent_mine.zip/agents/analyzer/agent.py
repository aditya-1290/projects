"""
Analyzer Agent - Classifies logs and detects user intent
"""

from agents.base_agent import BaseAgent, A2AMessage, MessageType
from typing import Dict, Any
import json
import re


class AnalyzerAgent(BaseAgent):
    """Classifies log types and determines user intent"""

    def __init__(self):
        super().__init__("analyzer_v1", "agents/analyzer/capabilities.json")

    async def process(self, message: A2AMessage) -> A2AMessage:
        task = message.task or {}
        context = message.context or {}

        clean_logs = task.get("clean_logs", "") or context.get("clean_logs", "")

        if not clean_logs:
            return A2AMessage(
                message_type=MessageType.ERROR,
                sender_id=self.agent_id,
                sender_type="analyzer",
                target_id=message.sender_id,
                correlation_id=message.message_id,
                error="No clean logs provided for analysis"
            )

        try:
            model = await self.get_model("gemma")

            # 🔥 ADD THIS BEFORE LLM CALL
            if "Traceback" in clean_logs or "Error" in clean_logs:
                context["log_type_hint"] = "error_log"

            # Run classification
            analysis = await self._analyze(clean_logs, model)

            return A2AMessage(
                message_type=MessageType.RESPONSE,
                sender_id=self.agent_id,
                sender_type="analyzer",
                target_id=message.sender_id,
                correlation_id=message.message_id,
                response={
                    **analysis,
                    "analysis": analysis,  # 🔥 standardized key
                    "log_type": analysis.get("log_type"),
                    "intent": analysis.get("primary_intent"),
                },
                confidence=analysis.get("confidence", 0.7),
                context=message.context
            )

        except Exception as e:
            # Fallback: pattern-based classification
            analysis = await self._pattern_analysis(clean_logs)
            return A2AMessage(
                message_type=MessageType.RESPONSE,
                sender_id=self.agent_id,
                sender_type="analyzer",
                target_id=message.sender_id,
                correlation_id=message.message_id,
                response=analysis,
                confidence=analysis.get("confidence", 0.5)
            )

    async def _analyze(self, logs: str, model) -> Dict:
        """Use LLM to classify logs"""
        prompt = f"""
        You are a senior debugging expert.

        Analyze the following logs carefully.

        LOGS:
        {logs[:3000]}

        Your job is to extract precise debugging information.

        Return STRICT JSON:

        {{
          "log_type": "error_log | server_log | application_log | unknown",
          "primary_intent": "debugging | explanation | optimization",
          "severity": "CRITICAL | ERROR | WARNING | INFO",
          "main_error": "exact exception or error message",
          "error_line": "the exact line where error occurs (if visible)",
          "root_cause": "why this error occurred (very specific)",
          "affected_components": ["list of components"],
          "confidence": 0.0-1.0,
          "summary": "short summary"
        }}

        IMPORTANT:
        - Extract the EXACT exception (e.g., NameError)
        - Identify the root cause from the traceback
        - Do NOT return generic answers
        """

        response = await model.generate(prompt, max_tokens=512)

        import re
        # Extract JSON
        json_match = re.search(r'\{.*\}', response, re.DOTALL)
        if json_match:
            try:
                parsed = json.loads(json_match.group())

                main_error = parsed.get("main_error", "")

                # 🔥 STRONG VALIDATION (NEW)
                if (
                        not main_error
                        or "unknown" in main_error.lower()
                        or "not specified" in main_error.lower()
                        or len(main_error) < 10  # too vague
                ):
                    self.log("LLM output weak → fallback to pattern", "WARNING")
                    return await self._pattern_analysis(logs)

                # 🔥 ENRICHMENT LAYER (VERY IMPORTANT)
                if "NameError" in logs and "NameError" not in main_error:
                    import re
                    match = re.search(r"NameError:\s*(.+)", logs)
                    if match:
                        parsed["main_error"] = f"NameError: {match.group(1)}"
                    else:
                        parsed["main_error"] = "NameError: undefined variable"

                return parsed

            except json.JSONDecodeError:
                pass

        # Fallback
        return await self._pattern_analysis(logs)

    async def _pattern_analysis(self, logs: str) -> Dict:
        """Pattern-based classification without LLM"""
        logs_lower = logs.lower()

        # Determine log type
        if any(word in logs_lower for word in ['database', 'sql', 'postgres', 'mysql', 'connection refused']):
            log_type = "database_log"
        elif any(word in logs_lower for word in ['http', 'apache', 'nginx', '404', '500']):
            log_type = "server_log"
        elif any(word in logs_lower for word in ['permission denied', 'unauthorized', 'forbidden', 'auth']):
            log_type = "security_log"
        elif any(word in logs_lower for word in ['timeout', 'network', 'dns', 'refused']):
            log_type = "network_log"
        elif any(word in logs_lower for word in ['exception', 'traceback', 'error']):
            log_type = "error_log"
        elif any(word in logs_lower for word in ['warn', 'warning']):
            log_type = "application_log"
        else:
            log_type = "system_log"

        # Determine severity
        if any(word in logs_lower for word in ['critical', 'fatal', 'emergency']):
            severity = "CRITICAL"
        elif any(word in logs_lower for word in ['error', 'exception', 'failed']):
            severity = "ERROR"
        elif any(word in logs_lower for word in ['warn', 'warning']):
            severity = "WARNING"
        else:
            severity = "INFO"

        # Determine intent
        if any(word in logs_lower for word in ['traceback', 'exception', 'stack trace', 'line']):
            intent = "debugging"
        elif any(word in logs_lower for word in ['what', 'why', 'explain', 'how']):
            intent = "explanation"
        else:
            intent = "debugging"

        import re
        # Extract main error
        error_pattern = re.search(r'(?:Error|Exception|FATAL|CRITICAL):?\s*([^\n]+)', logs, re.IGNORECASE)
        main_error = error_pattern.group(1).strip() if error_pattern else "Unknown error"

        # 🔥 STRONG DETECTION
        if "NameError" in logs:
            import re
            match = re.search(r"NameError:\s*(.+)", logs)
            if match:
                main_error = f"NameError: {match.group(1)}"
            else:
                main_error = "NameError: undefined variable"

        return {
            "log_type": log_type,
            "primary_intent": intent,
            "severity": severity,
            "main_error": main_error[:200],
            "affected_components": [],
            "confidence": 0.6,
            "summary": f"{severity} {log_type}: {main_error[:100]}"
        }
