"""
Skill Prompts for the Extractor Agent.

The Extractor handles multi-source log extraction from files, images (OCR),
terminal output, and pasted text. Uses custom parsers (no LLM for most tasks)
with DeepSeek-OCR2 for image extraction.

Skill catalogue:
  SKILL_FORMAT_DISAMBIGUATION   — Resolve conflicting format signals
  SKILL_CONTENT_REPAIR          — Fix malformed/trucated extracted content
  SKILL_METADATA_EXTRACTION     — Extract structured metadata from logs
  SKILL_OCR_POST_PROCESSING     — Clean up OCR-extracted text
  SKILL_LARGE_FILE_SAMPLING     — Decide sampling strategy for large files
  SKILL_MULTI_FORMAT_SPLITTING  — Split mixed-format files
  SKILL_CONTENT_VALIDATION      — Validate extracted content is actually logs
  SKILL_SOURCE_TYPE_DETECTION   — Auto-detect input source type
  SKILL_ENCODING_DETECTION      — Detect file encoding for proper reading
  SKILL_TERMINAL_OUTPUT_PARSING — Parse terminal command output
"""


# =============================================================================
# SKILL: Source Type Detection
# Used by: First step — determine what kind of input this is
# =============================================================================

SKILL_SOURCE_TYPE_DETECTION = """You are an input source detection specialist.

User input (first 500 chars):
{query}

Available context:
  Has file_path: {has_file_path}
  File extension: {extension}
  Has command: {has_command}
  Input length: {chars} chars, {lines} lines

Determine the source type from:

SOURCE TYPES:
  file_text       — File with .log, .txt, .json, .csv, .xml, .out, .err extension
  file_compressed — File with .gz, .bz2, .xz extension
  image           — File with .png, .jpg, .jpeg, .bmp, .tiff extension
  terminal        — "command:" or "cmd:" prefix present
  pasted_text     — User pasted log content directly
  pasted_traceback— Pasted content contains "Traceback (most recent call last)"
  pasted_json     — Pasted content starts with {{ or [
  pasted_syslog   — Pasted content matches syslog pattern
  pasted_apache   — Pasted content matches Apache access/error pattern

Detection rules:
  - If file_path is set and extension matches → use file_* type
  - If "command:" or "cmd:" prefix → terminal
  - If content starts with "Traceback" → pasted_traceback
  - If content starts with {{ and contains "level"/"timestamp" → pasted_json
  - If content matches syslog timestamp pattern → pasted_syslog
  - If content matches Apache pattern → pasted_apache
  - Otherwise → pasted_text

Respond ONLY with valid JSON:
{{
  "source_type": "file_text|file_compressed|image|terminal|pasted_text|pasted_traceback|pasted_json|pasted_syslog|pasted_apache",
  "confidence": 0.0-1.0,
  "requires_ocr": false,
  "requires_decompression": false,
  "requires_terminal_execution": false,
  "recommended_parser": "file_loader|image_loader|terminal_loader|text_parser|json_parser|csv_parser|xml_parser|syslog_parser|apache_parser",
  "detection_signals": ["specific signals that led to this decision"]
}}"""


# =============================================================================
# SKILL: Format Disambiguation
# Used by: When regex pre-analysis finds conflicting format signals
# =============================================================================

SKILL_FORMAT_DISAMBIGUATION = """You are a log format disambiguation specialist.

Conflicting signals detected: {conflicting_signals}

Content sample (first 500 chars):
{sample}

Choose ONE format from this ranked list (most specific first):
  python_traceback, java_stacktrace, javascript_error, go_panic,
  apache_access, apache_error, syslog_rfc5424, syslog_bsd,
  json_log, ndjson, csv, tsv, xml, plain_text, mixed, unknown

Rules:
  - "mixed" = file contains 2+ distinct formats (describe all)
  - "unknown" only if you genuinely cannot tell
  - If you see "Traceback (most recent call last)" → always python_traceback
  - If you see "at com." or "at org." → always java_stacktrace
  - If you see "goroutine" and "panic:" → always go_panic
  - JSON lines that start with {{ → ndjson (not json)
  - A single top-level JSON object/array spanning multiple lines → json_log
  - IP address + [timestamp] + "METHOD /path" → apache_access
  - [day month time year] [level] → apache_error
  - Lines starting with <digit> + timestamp → syslog_rfc5424
  - Month day time host tag: → syslog_bsd

If signals genuinely conflict:
  - Check which format matches MORE lines
  - Check for format transitions (first half JSON, second half plain text?)
  - If truly mixed, return "mixed" with split information

Respond ONLY with valid JSON:
{{
  "primary_format": "exact_format_name",
  "secondary_format": "second_format_or_null",
  "is_mixed": false,
  "split_point": "line number where format changes, or null",
  "confidence": 0.0-1.0,
  "reasoning": "one sentence explaining the decision",
  "format_evidence": {{
    "for_primary": ["evidence supporting primary format"],
    "against_alternatives": ["why other formats were rejected"]
  }}
}}"""


# =============================================================================
# SKILL: Content Repair
# Used by: When extracted content has structural damage
# =============================================================================

SKILL_CONTENT_REPAIR = """You are a content repair specialist for damaged log data.

Issues detected:
{issues}

Damaged content (first 800 chars):
{content}

Repair instructions for common damage types:

1. TRUNCATED JSON
   → Close unclosed brackets and braces
   → Add missing closing quotes for string values
   → Add missing commas between array elements
   → If truncation point is obvious, mark as [TRUNCATED]

2. BROKEN XML
   → Close unclosed tags (find matching tag name)
   → Fix mismatched case in tags (XML is case-sensitive)
   → Add missing closing slash in self-closing tags
   → Escape unescaped & characters

3. PARTIAL LOG LINES
   → Mark incomplete lines with [INCOMPLETE_LINE] prefix
   → If line is clearly the first half of a split line, attempt to merge
   → Preserve partial timestamps as-is with [PARTIAL] marker

4. BINARY BLEED / ENCODING ERRORS
   → Replace non-printable sequences with [BINARY_DATA]
   → Fix mojibake (e.g., "Ã©" → "é") using encoding detection
   → Remove null bytes

5. DUPLICATE HEADERS / FOOTERS
   → Remove repeated page headers from log viewers
   → Remove repeated column headers from tabular data
   → Remove repeated separator lines (====, ----)

CRITICAL RULES:
   → Do NOT invent log entries — only repair structure
   → Do NOT change the meaning of any log message
   → If repair is impossible, return the content unchanged with an error note
   → Mark all repairs so the user knows what was changed

Respond ONLY with valid JSON:
{{
  "repaired_content": "the fixed content",
  "repairs_made": [
    {{
      "type": "closed_brace|merged_lines|removed_binary|fixed_encoding",
      "location": "line number or character position",
      "original": "what was there before",
      "repair": "what it was changed to"
    }}
  ],
  "repair_confidence": 0.8,
  "is_fully_repaired": true,
  "remaining_issues": ["issues that could not be repaired"],
  "notes": "any important caveats about the repairs"
}}"""


# =============================================================================
# SKILL: Metadata Extraction
# Used by: After extraction, produce a structured summary
# =============================================================================

SKILL_METADATA_EXTRACTION = """You are a log metadata extraction specialist.

Log content (first 2000 chars):
{content}

Pre-parsed info:
  Format: {format}
  Entry count: {entry_count}
  Technologies detected: {technologies}

Extract metadata and statistics:

1. TIME RANGE
   → Earliest timestamp found
   → Latest timestamp found
   → Total time span in seconds
   → Timezone detected

2. SEVERITY DISTRIBUTION
   → Count of each severity level
   → Dominant severity
   → Error rate (% of entries that are ERROR or above)

3. TOP ENTITIES
   → Unique hosts/servers
   → Unique services/components
   → Unique error types
   → Unique users/IPs (if present)

4. STRUCTURAL INFO
   → Average entry length
   → Has stack traces?
   → Has SQL queries?
   → Has HTTP requests?

5. QUALITY INDICATORS
   → Percentage of entries with timestamps
   → Percentage of entries with severity levels
   → Percentage of entries that are parseable
   → Gaps in timeline?

Respond ONLY with valid JSON:
{{
  "time_range": {{
    "earliest": "ISO timestamp or null",
    "latest": "ISO timestamp or null",
    "span_seconds": null
  }},
  "severity_counts": {{
    "CRITICAL": 0, "ERROR": 0, "WARNING": 0, "INFO": 0, "DEBUG": 0
  }},
  "unique_hosts": ["hostnames"],
  "unique_services": ["service names"],
  "error_types": ["unique error class names"],
  "peak_error_window": "timestamp range with most errors, or null",
  "has_stack_traces": false,
  "has_timestamps": true,
  "estimated_log_rate": "N entries/minute or unknown",
  "entry_count": 0,
  "avg_entry_length": 0,
  "parseable_percentage": 0.0-1.0,
  "quality_score": 0-100
}}"""


# =============================================================================
# SKILL: OCR Post-Processing
# Used by: After image_loader.extract() to clean up OCR noise
# =============================================================================

SKILL_OCR_POST_PROCESSING = """You are an OCR text cleanup specialist.

Raw OCR output from log screenshot:
{ocr_text}

Common OCR errors in log text and their fixes:

CHARACTER CONFUSIONS:
  "l" (lowercase L) vs "1" (one)  → "l" in text, "1" in numbers and timestamps
  "O" (letter O) vs "0" (zero)    → "O" in text, "0" in hex values and numbers
  "rn" vs "m"                     → "rn" in "error", "warning"; "m" in "memory"
  "5" vs "S"                      → "5" in numbers, "S" in text
  "8" vs "B"                      → "8" in numbers, "B" in text
  "cl" vs "d"                     → context-dependent

STRUCTURAL FIXES:
  Broken timestamps: "10 23 45" → "10:23:45"
  Split lines (OCR wrapped mid-word): join if split point is mid-word
  Missing spaces between fields: add spaces at natural boundaries
  Extra spaces from OCR alignment: collapse to single space

NOISE REMOVAL:
  Page headers and footers from the viewer
  Line numbers added by the text editor/viewer
  UI chrome (tab names, window titles, status bars)
  Scroll position indicators
  Selection highlights accidentally captured

RULES:
  → Preserve exact error messages and stack traces — do not paraphrase
  → Mark uncertain corrections as [OCR_UNCERTAIN: original_text → best_guess]
  → Preserve original line structure where possible
  → If the quality is very poor, say so rather than guessing
  → NEVER change the meaning of an error message

Respond ONLY with valid JSON:
{{
  "cleaned_text": "the repaired OCR output",
  "corrections_made": [
    {{
      "type": "character_confusion|structural_fix|noise_removal",
      "original": "what OCR produced",
      "corrected": "what it should be",
      "location": "line number or position"
    }}
  ],
  "uncertain_sections": [
    {{
      "location": "line:position",
      "ocr_text": "what OCR produced",
      "best_guess": "most likely correct text",
      "alternatives": ["other possible readings"]
    }}
  ],
  "quality_estimate": "good|fair|poor",
  "quality_score": 0-100,
  "notes": "any observations about OCR quality"
}}"""


# =============================================================================
# SKILL: Large File Sampling
# Used by: When file size > 10MB, decide what parts to extract
# =============================================================================

SKILL_LARGE_FILE_SAMPLING = """You are a large file sampling specialist.

File info:
  Size: {file_size_mb} MB
  Extension: {extension}
  Estimated lines: {estimated_lines}
  Format hint: {format_hint}

Head sample (first 500 chars):
{head_sample}

Tail sample (last 500 chars):
{tail_sample}

Sampling strategies (choose the best for this file):

1. HEAD + TAIL
   → Read first N lines + last N lines
   → Best for: understanding structure, time range
   → Misses: middle anomalies, periodic patterns

2. ERROR LINES ONLY
   → Filter for ERROR/CRITICAL/FATAL/Exception lines
   → Best for: debugging, incident analysis
   → Misses: context around errors

3. RANDOM SAMPLE
   → Randomly select N lines from the file
   → Best for: statistical analysis, pattern detection
   → Misses: rare events

4. TIME WINDOW
   → Extract a specific time range
   → Best for: incident investigation with known time
   → Requires: timestamps in the log

5. SMART SAMPLING
   → Head + tail + error clusters + time-spread random samples
   → Best for: general analysis with limited context
   → Coverage: structure + errors + statistical spread

Respond ONLY with valid JSON:
{{
  "strategy": "head_tail|error_lines_only|random_sample|time_window|smart",
  "head_lines": 200,
  "tail_lines": 200,
  "middle_sample": true,
  "middle_sample_line_range": "10000-10200",
  "error_lines_include": true,
  "filter_pattern": "ERROR|CRITICAL|Exception|FATAL",
  "reasoning": "why this strategy was chosen for this file",
  "estimated_coverage": "what percentage of issues this will capture",
  "estimated_extraction_time": "time estimate",
  "warnings": ["what might be missed with this strategy"]
}}"""


# =============================================================================
# SKILL: Multi-Format Splitting
# Used by: When a file contains multiple log formats mixed together
# =============================================================================

SKILL_MULTI_FORMAT_SPLITTING = """You are a multi-format log splitting specialist.

Content (first 1500 chars):
{content}

Detected formats present: {detected_formats}

Split the file into sections, each with a single format.

Common split indicators:
  → Format signature change (JSON ↔ syslog ↔ Apache)
  → Clear section headers ("--- Error Log ---", "# Application Log")
  → Blank line clusters (3+ blank lines often separate sections)
  → Timestamp format change (ISO ↔ BSD syslog ↔ Apache format)
  → Source change (different hostnames, different services)

For each section, identify:
  → Start and end line numbers
  → Format type
  → What the section contains
  → How it relates to other sections (if at all)

Rules:
  → Sections should be contiguous in the original file
  → If a section is too small (< 3 lines), merge with adjacent section
  → The dominant format is the one with the most entries
  → If no clear split exists, return a single section

Respond ONLY with valid JSON:
{{
  "sections": [
    {{
      "section_index": 0,
      "format": "python_traceback",
      "start_line": 1,
      "end_line": 45,
      "description": "Python error traceback from auth-service",
      "entry_count": 45,
      "severity": "ERROR"
    }},
    {{
      "section_index": 1,
      "format": "apache_access",
      "start_line": 46,
      "end_line": 120,
      "description": "Apache access logs during the incident window",
      "entry_count": 75,
      "severity": "MIXED"
    }}
  ],
  "dominant_format": "apache_access",
  "total_sections": 2,
  "split_confidence": 0.85,
  "is_genuinely_mixed": true,
  "notes": "any observations about the split"
}}"""


# =============================================================================
# SKILL: Content Validation
# Used by: Confirm the extracted content is actually log data
# =============================================================================

SKILL_CONTENT_VALIDATION = """You are a content validation specialist.

Extracted content sample (first 600 chars):
{content}

Format claimed: {claimed_format}

Validate that this content is actually LOG DATA (not source code, config files, documentation, or binary noise).

Validation criteria for log data:
  ✓ Contains timestamps, severity levels, or error messages
  ✓ Has repetitive line structure (each line follows a pattern)
  ✓ References running processes, services, or system events
  ✓ Has temporal ordering (newer entries after older ones)

Red flags (content might NOT be log data):
  ✗ Function definitions, class declarations
  ✗ HTML/CSS/JavaScript source code
  ✗ Configuration files (INI, YAML, TOML)
  ✗ Database schema definitions (CREATE TABLE)
  ✗ Documentation or README text
  ✗ Compiled binary with text snippets
  ✗ Git diffs or patch files
  ✗ Package manager lock files

Edge cases (these ARE log data):
  ✓ JSON with timestamp + severity (CloudWatch, Bunyan, Pino)
  ✓ XML with EventID (Windows Event Log)
  ✓ CSV with timestamp column
  ✓ Stack traces (they contain file paths but are log outputs)

If you're not sure:
  → Compare with the claimed_format expectations
  → Check if the structure matches known log formats
  → If < 30% of lines look like log entries → reject

Respond ONLY with valid JSON:
{{
  "is_log_data": true,
  "confidence": 0.9,
  "format_matches_content": true,
  "rejection_reason": null,
  "actual_content_type": "log|source_code|config|documentation|binary|unknown",
  "recommendation": "proceed|warn_user|reject",
  "warning_notes": "any caveats the user should know",
  "log_like_percentage": 0-100
}}"""


# =============================================================================
# SKILL: Encoding Detection
# Used by: Detect the character encoding of a file
# =============================================================================

SKILL_ENCODING_DETECTION = """You are a file encoding detection specialist.

File info:
  Path: {file_path}
  Size: {file_size} bytes
  First 200 bytes (hex): {hex_sample}
  First 200 bytes (text with replacement): {text_sample}

Detect the character encoding:

COMMON ENCODINGS:
  UTF-8        → Most common, ASCII-compatible, multi-byte characters
  UTF-8-BOM    → Starts with EF BB BF
  UTF-16-LE    → ASCII chars interleaved with 00 bytes
  UTF-16-BE    → 00 bytes before ASCII chars
  Latin-1      → ISO-8859-1, Western European
  CP1252       → Windows Western European (like Latin-1 but with extras)
  Shift-JIS    → Japanese
  GB2312       → Simplified Chinese
  EUC-KR       → Korean

Detection signals:
  → BOM (Byte Order Mark) at file start → UTF-8/UTF-16
  → Null bytes mixed with text → UTF-16 or binary
  → High byte values (128-255) in patterns → specific encodings
  → Mojibake patterns (e.g., "Ã©" for "é") → UTF-8 bytes interpreted as Latin-1
  → All bytes < 128 → ASCII (subset of UTF-8)

Respond ONLY with valid JSON:
{{
  "encoding": "utf-8|utf-8-bom|utf-16-le|utf-16-be|latin-1|cp1252|shift-jis|gb2312|euc-kr|ascii|binary",
  "confidence": 0.95,
  "has_bom": false,
  "is_ascii_only": true,
  "alternative_encodings": ["other possible encodings"],
  "decoding_instructions": "how to decode (e.g., 'use utf-8')",
  "risk_of_mojibake": "low|medium|high"
}}"""


# =============================================================================
# SKILL: Terminal Output Parsing
# Used by: Parse and structure terminal command output
# =============================================================================

SKILL_TERMINAL_OUTPUT_PARSING = """You are a terminal output parsing specialist.

Command executed: {command}
Raw output:
{raw_output}

Output type detected: {output_type}

Parse terminal output based on command type:

DIR / LS OUTPUT:
  → Extract file/directory names
  → Extract sizes and dates
  → Parse into structured list
  → Identify directories vs files
  → Flag permission patterns

TYPE / CAT OUTPUT:
  → Pass through as-is (file content)
  → Detect encoding if possible
  → Note line count and size

SYSTEMINFO / UNAME OUTPUT:
  → Extract key-value pairs
  → Categorize: OS, CPU, Memory, Network
  → Structure into sections

TASKLIST / PS OUTPUT:
  → Parse process table
  → Extract PID, name, memory usage
  → Flag high-memory processes
  → Identify suspicious processes

NETSTAT OUTPUT:
  → Parse connection table
  → Extract protocol, local/remote address, state
  → Flag unusual connections
  → Identify listening services

GENERIC OUTPUT:
  → Detect if output is structured (table, key=value)
  → Parse accordingly
  → If freeform, preserve as-is with line count

Respond ONLY with valid JSON:
{{
  "command": "original command",
  "output_type": "file_content|directory_listing|system_info|process_list|network_info|error_message|generic",
  "parsed_output": {{
    "summary": "one line summary of output",
    "structured_data": "parsed data appropriate to output type",
    "raw_lines": 0
  }},
  "warnings": ["any issues with the output"],
  "exit_code_hint": "success|error|timeout|blocked"
}}"""
