"""
Input Type Detector

Detects the type, format, and structure of user input BEFORE processing.
Uses a three-layer approach:
  Layer 1 — Fast signals (hardcoded, zero-latency)
  Layer 2 — Structured parsing (JSON/XML/Apache/Syslog/K8s patterns)
  Layer 3 — LLM fallback (for unknown formats, used in Phase A)

Design principle:
  All layers return the same output structure. The orchestrator doesn't care
  HOW detection happened — it just reads the result and routes accordingly.
"""

import re
import json
import os
from typing import Dict, Optional, Tuple


# ═══════════════════════════════════════════════════════════════════════════════
# File / Image / Terminal indicators (Layer 1)
# ═══════════════════════════════════════════════════════════════════════════════

FILE_EXTENSIONS = {
    ".log", ".txt", ".out", ".err",
    ".json", ".jsonl", ".ndjson",
    ".csv", ".tsv",
    ".xml",
    ".gz", ".bz2", ".xz",
    ".syslog", ".access", ".error",
}

IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".bmp", ".tiff", ".tif", ".gif", ".webp"}

TERMINAL_PREFIXES = ("command:", "cmd:")


# ═══════════════════════════════════════════════════════════════════════════════
# Log-level keywords
# ═══════════════════════════════════════════════════════════════════════════════

LOG_LEVELS = {"CRITICAL", "FATAL", "ERROR", "WARN", "WARNING", "INFO", "DEBUG", "TRACE"}


# ═══════════════════════════════════════════════════════════════════════════════
# Common error / traceback patterns
# ═══════════════════════════════════════════════════════════════════════════════

ERROR_KEYWORDS = [
    "exception", "traceback", "stack trace", "nameerror", "typeerror",
    "valueerror", "keyerror", "indexerror", "attributeerror",
    "modulenotfounderror", "syntaxerror", "indentationerror",
    "filenotfounderror", "nullpointerexception", "outofmemoryerror",
    "segmentation fault", "core dumped", "panic", "fatal error",
]

PYTHON_TRACEBACK_RE = re.compile(
    r'Traceback\s*\(\s*most\s+recent\s+call\s+last\s*\)', re.IGNORECASE
)

# ── Timestamp patterns (earliest wins) ────────────────────────────────────────

TIMESTAMP_PATTERNS = [
    # ISO-8601: 2024-01-15T10:23:45Z / 2024-01-15 10:23:45
    (re.compile(r'\d{4}-\d{2}-\d{2}[T\s]\d{2}:\d{2}:\d{2}'), "iso8601"),
    # Apache: [15/Jan/2024:10:23:45 +0000]
    (re.compile(r'\[\d{1,2}/[A-Z][a-z]{2}/\d{4}:\d{2}:\d{2}:\d{2}\s[+\-]\d{4}\]'), "apache"),
    # Syslog RFC 5424: <34>Oct 11 22:14:15
    (re.compile(r'^<\d+>[A-Z][a-z]{2}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2}'), "syslog_rfc5424"),
    # BSD Syslog: Jan 15 10:23:45
    (re.compile(r'^[A-Z][a-z]{2}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2}'), "syslog_bsd"),
    # Kubernetes: I0429 16:30:45.123456
    (re.compile(r'^[IEWF]\d{4}\s+\d{2}:\d{2}:\d{2}\.\d+'), "kubernetes"),
    # Generic: 2024-01-15
    (re.compile(r'\d{4}-\d{2}-\d{2}'), "date_only"),
]


# ═══════════════════════════════════════════════════════════════════════════════
# Public API — single entry point
# ═══════════════════════════════════════════════════════════════════════════════

def detect_input(query: str) -> Dict:
    """
    Detect the type and format of user input.

    Returns:
        {
            "input_type": "file" | "pasted_log" | "terminal" | "image" | "query",
            "format": "python_traceback" | "json_log" | "csv" | "xml" | "apache_access" | ...,
            "sub_format": "kubernetes" | "docker" | "cloudwatch" | None,
            "confidence": "high" | "medium" | "low",
            "detection_layer": 1 | 2 | 3,
            "chars": 419,
            "lines": 7,
            "source_hint": "file_path" | "pasted_text" | "command" | "unknown",
            "display_message": "Python traceback (419 chars)"
        }
    """
    query = query.strip()
    chars = len(query)
    lines = query.count('\n') + 1

    # ── Layer 1: Fast signals ─────────────────────────────────────────────────
    result = _layer1_fast_signals(query, chars, lines)
    if result:
        return result

    # ── Layer 2: Structured detection ─────────────────────────────────────────
    result = _layer2_structured_detection(query, chars, lines)
    if result:
        return result

    # ── Layer 3: LLM fallback (Phase A) ───────────────────────────────────────
    # For now, return a generic pasted_log
    return {
        "input_type": "pasted_log",
        "format": "plain_text",
        "sub_format": None,
        "confidence": "low",
        "detection_layer": 3,
        "chars": chars,
        "lines": lines,
        "source_hint": "pasted_text",
        "display_message": f"Unknown format ({chars} chars, {lines} lines)"
    }


# ═══════════════════════════════════════════════════════════════════════════════
# Layer 1 — Fast Signals (Hardcoded, zero-latency)
# ═══════════════════════════════════════════════════════════════════════════════

def _layer1_fast_signals(query: str, chars: int, lines: int) -> Optional[Dict]:
    """
    Check for immediately obvious signals:
    - File paths with extensions
    - Image paths
    - Terminal commands
    - Python tracebacks
    - Log levels in content
    - Timestamp patterns
    """

    # 1. Terminal command
    lower = query.lower()
    for prefix in TERMINAL_PREFIXES:
        if lower.startswith(prefix):
            command = query.split(":", 1)[1].strip()
            return {
                "input_type": "terminal",
                "format": "terminal_output",
                "sub_format": None,
                "confidence": "high",
                "detection_layer": 1,
                "chars": chars,
                "lines": lines,
                "source_hint": "command",
                "display_message": f"Terminal command → {command[:50]}",
                "command": command,
            }

    # 2. File path (looks like a path with extension)
    #    Clean the query — if it has no spaces and ends with an extension,
    #    it's almost certainly a file path.
    if " " not in query or query.count("/") > 0 or query.count("\\") > 0:
        for ext in FILE_EXTENSIONS:
            if query.lower().endswith(ext):
                return {
                    "input_type": "file",
                    "format": _ext_to_format(ext),
                    "sub_format": None,
                    "confidence": "high",
                    "detection_layer": 1,
                    "chars": chars,
                    "lines": lines,
                    "source_hint": "file_path",
                    "display_message": f"File path ({ext}) → {os.path.basename(query)}",
                }

    # 3. Image path
    for ext in IMAGE_EXTENSIONS:
        if query.lower().endswith(ext):
            return {
                "input_type": "image",
                "format": "image",
                "sub_format": None,
                "confidence": "high",
                "detection_layer": 1,
                "chars": chars,
                "lines": lines,
                "source_hint": "file_path",
                "display_message": f"Image file ({ext}) → {os.path.basename(query)}",
            }

    # 4. Python traceback
    if PYTHON_TRACEBACK_RE.search(query):
        return {
            "input_type": "pasted_log",
            "format": "python_traceback",
            "sub_format": None,
            "confidence": "high",
            "detection_layer": 1,
            "chars": chars,
            "lines": lines,
            "source_hint": "pasted_text",
            "display_message": f"Python traceback ({chars} chars, {lines} lines)",
        }

    # 5. Contains log levels (multiple occurrences suggest log entries)
    words = set(query.split())
    log_level_hits = words & LOG_LEVELS
    if len(log_level_hits) >= 2 or (len(log_level_hits) >= 1 and lines >= 3):
        return {
            "input_type": "pasted_log",
            "format": "log_entries",
            "sub_format": None,
            "confidence": "medium",
            "detection_layer": 1,
            "chars": chars,
            "lines": lines,
            "source_hint": "pasted_text",
            "display_message": f"Log entries with levels: {', '.join(sorted(log_level_hits))} ({chars} chars, {lines} lines)",
        }

    # 6. Timestamp patterns
    for pattern, name in TIMESTAMP_PATTERNS:
        if pattern.search(query):
            return {
                "input_type": "pasted_log",
                "format": "timestamped_log",
                "sub_format": name,
                "confidence": "medium",
                "detection_layer": 1,
                "chars": chars,
                "lines": lines,
                "source_hint": "pasted_text",
                "display_message": f"Timestamped log ({name}) ({chars} chars, {lines} lines)",
            }

    return None


# ═══════════════════════════════════════════════════════════════════════════════
# Layer 2 — Structured Detection (Parsing-based)
# ═══════════════════════════════════════════════════════════════════════════════

def _layer2_structured_detection(query: str, chars: int, lines: int) -> Optional[Dict]:
    """
    Try to parse the input as structured formats:
    - JSON (standard, NDJSON, Docker, CloudWatch, GCP, ELK)
    - XML (standard, Windows Event Log)
    - Apache access / error
    - Syslog (RFC5424, BSD)
    - Kubernetes
    """

    # 1. Try JSON detection
    json_result = _detect_json_format(query, chars, lines)
    if json_result:
        return json_result

    # 2. Try XML detection
    xml_result = _detect_xml_format(query, chars, lines)
    if xml_result:
        return xml_result

    # 3. Apache access log
    if _looks_like_apache_access(query):
        return {
            "input_type": "pasted_log",
            "format": "apache_access",
            "sub_format": None,
            "confidence": "high",
            "detection_layer": 2,
            "chars": chars,
            "lines": lines,
            "source_hint": "pasted_text",
            "display_message": f"Apache access log ({chars} chars, {lines} lines)",
        }

    # 4. Apache error log
    if _looks_like_apache_error(query):
        return {
            "input_type": "pasted_log",
            "format": "apache_error",
            "sub_format": None,
            "confidence": "high",
            "detection_layer": 2,
            "chars": chars,
            "lines": lines,
            "source_hint": "pasted_text",
            "display_message": f"Apache error log ({chars} chars, {lines} lines)",
        }

    # 5. Syslog
    for pattern_name in ["syslog_rfc5424", "syslog_bsd"]:
        for pattern, name in TIMESTAMP_PATTERNS:
            if name == pattern_name and pattern.match(query.strip().split('\n')[0]):
                return {
                    "input_type": "pasted_log",
                    "format": name,
                    "sub_format": None,
                    "confidence": "high",
                    "detection_layer": 2,
                    "chars": chars,
                    "lines": lines,
                    "source_hint": "pasted_text",
                    "display_message": f"Syslog ({name}) ({chars} chars, {lines} lines)",
                }

    # 6. Kubernetes log
    if _looks_like_kubernetes(query):
        return {
            "input_type": "pasted_log",
            "format": "kubernetes_log",
            "sub_format": None,
            "confidence": "medium",
            "detection_layer": 2,
            "chars": chars,
            "lines": lines,
            "source_hint": "pasted_text",
            "display_message": f"Kubernetes log ({chars} chars, {lines} lines)",
        }

    # 7. CSV detection (multiple lines, consistent delimiters)
    if lines >= 2 and _looks_like_csv(query, lines):
        return {
            "input_type": "pasted_log",
            "format": "csv",
            "sub_format": None,
            "confidence": "medium",
            "detection_layer": 2,
            "chars": chars,
            "lines": lines,
            "source_hint": "pasted_text",
            "display_message": f"CSV data ({chars} chars, {lines} lines)",
        }

    return None


# ═══════════════════════════════════════════════════════════════════════════════
# JSON Detection Helpers
# ═══════════════════════════════════════════════════════════════════════════════

def _detect_json_format(query: str, chars: int, lines: int) -> Optional[Dict]:
    """Detect JSON-based log formats."""
    sample = query.strip()

    # Must start with { or [
    if not (sample.startswith("{") or sample.startswith("[")):
        return None

    # NDJSON: multiple lines each starting with {
    if lines >= 2:
        line_starts = [l.strip().startswith("{") for l in query.splitlines() if l.strip()]
        if all(line_starts) and len(line_starts) >= 2:
            return _classify_json_schema(query, chars, lines, "ndjson")

    # Try parsing as single JSON
    try:
        data = json.loads(sample)
    except json.JSONDecodeError:
        # Might be truncated or multi-object
        return None

    return _classify_json_schema(query, chars, lines, "json_log")


def _classify_json_schema(query: str, chars: int, lines: int, base_format: str) -> Dict:
    """Determine the specific JSON log schema."""
    sample = query.strip().split('\n')[0]
    try:
        data = json.loads(sample) if sample.startswith("{") else {}
    except json.JSONDecodeError:
        data = {}

    keys = set(data.keys()) if isinstance(data, dict) else set()

    # Docker log
    if "log" in keys and "stream" in keys:
        return {
            "input_type": "pasted_log",
            "format": "json_log",
            "sub_format": "docker",
            "confidence": "high",
            "detection_layer": 2,
            "chars": chars,
            "lines": lines,
            "source_hint": "pasted_text",
            "display_message": f"Docker log (JSON) ({chars} chars, {lines} lines)",
        }

    # GCP Stackdriver
    if "insertId" in keys:
        return {
            "input_type": "pasted_log",
            "format": "json_log",
            "sub_format": "gcp",
            "confidence": "high",
            "detection_layer": 2,
            "chars": chars,
            "lines": lines,
            "source_hint": "pasted_text",
            "display_message": f"GCP log (JSON) ({chars} chars, {lines} lines)",
        }

    # CloudWatch / ELK
    if "@timestamp" in keys or "@message" in keys:
        return {
            "input_type": "pasted_log",
            "format": "json_log",
            "sub_format": "cloudwatch_elk",
            "confidence": "high",
            "detection_layer": 2,
            "chars": chars,
            "lines": lines,
            "source_hint": "pasted_text",
            "display_message": f"CloudWatch/ELK log (JSON) ({chars} chars, {lines} lines)",
        }

    # Generic JSON with log-level indicators
    has_log_keys = keys & {"level", "severity", "timestamp", "message", "logger", "trace_id"}
    if len(has_log_keys) >= 2:
        return {
            "input_type": "pasted_log",
            "format": base_format,
            "sub_format": "structured",
            "confidence": "medium",
            "detection_layer": 2,
            "chars": chars,
            "lines": lines,
            "source_hint": "pasted_text",
            "display_message": f"Structured JSON log ({chars} chars, {lines} lines)",
        }

    # Generic JSON (might not be logs)
    return {
        "input_type": "pasted_log",
        "format": base_format,
        "sub_format": None,
        "confidence": "low",
        "detection_layer": 2,
        "chars": chars,
        "lines": lines,
        "source_hint": "pasted_text",
        "display_message": f"JSON data ({chars} chars, {lines} lines)",
    }


# ═══════════════════════════════════════════════════════════════════════════════
# XML Detection Helpers
# ═══════════════════════════════════════════════════════════════════════════════

def _detect_xml_format(query: str, chars: int, lines: int) -> Optional[Dict]:
    """Detect XML-based log formats."""
    sample = query.strip()

    if not (sample.startswith("<") and ">" in sample):
        return None

    # Windows Event Log
    if "<Event " in sample or "<Event>" in sample or "<Events>" in sample:
        if "EventID" in sample or "<System>" in sample:
            return {
                "input_type": "pasted_log",
                "format": "xml",
                "sub_format": "windows_event",
                "confidence": "high",
                "detection_layer": 2,
                "chars": chars,
                "lines": lines,
                "source_hint": "pasted_text",
                "display_message": f"Windows Event Log (XML) ({chars} chars, {lines} lines)",
            }

    # Generic XML
    return {
        "input_type": "pasted_log",
        "format": "xml",
        "sub_format": None,
        "confidence": "medium",
        "detection_layer": 2,
        "chars": chars,
        "lines": lines,
        "source_hint": "pasted_text",
        "display_message": f"XML data ({chars} chars, {lines} lines)",
    }


# ═══════════════════════════════════════════════════════════════════════════════
# Apache / Syslog / Kubernetes / CSV Helpers
# ═══════════════════════════════════════════════════════════════════════════════

def _looks_like_apache_access(query: str) -> bool:
    """Check if query looks like Apache access log."""
    first_line = query.strip().split('\n')[0]
    # Format: 192.168.1.100 - - [15/Jan/2024:10:23:45 +0000] "GET /api/users HTTP/1.1" 500 1234
    return bool(re.match(
        r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\s+', first_line
    )) and ('"GET ' in first_line or '"POST ' in first_line or '"PUT ' in first_line)


def _looks_like_apache_error(query: str) -> bool:
    """Check if query looks like Apache error log."""
    first_line = query.strip().split('\n')[0]
    # Format: [Mon Jan 15 10:23:45.123456 2024] [core:error] [pid 12345] ...
    return bool(re.match(r'^\[[A-Z][a-z]{2}\s+[A-Z][a-z]{2}\s+\d+', first_line))


def _looks_like_kubernetes(query: str) -> bool:
    """Check if query looks like Kubernetes log."""
    # Format: I0429 16:30:45.123456   1 pod.go:123] ...
    first_line = query.strip().split('\n')[0]
    return bool(re.match(r'^[IEWF]\d{4}\s+\d{2}:\d{2}:\d{2}', first_line))


def _looks_like_csv(query: str, lines: int) -> bool:
    """Check if multi-line content looks like CSV."""
    line_list = [l for l in query.splitlines()[:5] if l.strip()]
    if len(line_list) < 2:
        return False

    for delim in [",", "\t", "|", ";"]:
        counts = [l.count(delim) for l in line_list]
        if min(counts) > 0 and max(counts) - min(counts) <= 2:
            return True
    return False


# ═══════════════════════════════════════════════════════════════════════════════
# Utility
# ═══════════════════════════════════════════════════════════════════════════════

def _ext_to_format(ext: str) -> str:
    """Map file extension to log format name."""
    mapping = {
        ".log": "text_log",
        ".txt": "text_log",
        ".out": "text_log",
        ".err": "text_log",
        ".json": "json_log",
        ".jsonl": "ndjson",
        ".ndjson": "ndjson",
        ".csv": "csv",
        ".tsv": "csv",
        ".xml": "xml",
        ".gz": "compressed",
        ".bz2": "compressed",
        ".xz": "compressed",
        ".syslog": "syslog",
        ".access": "apache_access",
        ".error": "apache_error",
    }
    return mapping.get(ext, "text_log")
