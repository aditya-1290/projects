"""
Orchestrator Agent

The first point of contact for users. Decomposes queries, discovers
capable agents, coordinates the pipeline, and aggregates results.

Uses Gemma-4-E4B for intelligent task decomposition.

IMPORTANT: This agent NEVER imports other agents directly.
All communication happens through the Communication Bus via A2A messages.
"""

import asyncio
from typing import Dict, List, Any, Optional
from datetime import datetime
import os

from agents.orchestrator.input_detector import detect_input
from agents.base_agent import BaseAgent, A2AMessage, MessageType, AgentState


def _merge_results(results):
    """
    Flatten previous agent outputs into context
    """
    merged = {}

    for key, step in results.items():   # ✅ FIX HERE
        if not step or not isinstance(step, dict):
            continue

        response = step.get("response", {})
        if isinstance(response, dict):
            merged.update(response)

    return merged


class OrchestratorAgent(BaseAgent):
    """
    Central coordinator for the multi-agent system.

    ALL inter-agent communication goes through the Communication Bus.
    This agent discovers other agents by querying the bus, not by importing them.
    """

    def __init__(self):
        super().__init__("orchestrator_v1", "agents/orchestrator/capabilities.json")
        self.planner = None
        self.router = None
        self.execution_history: List[Dict] = []

    async def initialize(self):
        """Initialize planner and router - no agent imports needed"""
        from agents.orchestrator.planner import TaskPlanner
        from agents.orchestrator.router import AgentRouter

        self.planner = TaskPlanner()
        self.router = AgentRouter(self.comm_bus)  # Router uses comm_bus for discovery
        self.log("Orchestrator initialized")

    async def receive_message(self, message: A2AMessage) -> Optional[A2AMessage]:
        """
        Override to resolve pending futures when responses arrive.
        This is the CRITICAL fix — without this, _send_and_wait always times out.
        """
        # Check if this is a response to a pending request we're waiting for
        if hasattr(self, '_pending_responses') and message.correlation_id:
            future = self._pending_responses.get(message.correlation_id)
            if future and not future.done():
                future.set_result(message)
                self.log(
                    f"Resolved pending future for {message.correlation_id[:8]}... "
                    f"(type={message.message_type.value}, conf={message.confidence:.2f})",
                    "DEBUG"
                )
                return None  # Don't process further — the waiter in _send_and_wait handles it

        # For ERROR messages without a matching future, log and drop to avoid loops
        if message.message_type == MessageType.ERROR and not (
                hasattr(self, '_pending_responses') and
                message.correlation_id in self._pending_responses
        ):
            self.log(f"Dropping orphaned ERROR: {message.error}", "WARNING")
            return None

        # NEW: Drop RESPONSE's without matching future (fire-and-forget like memory store)
        if message.message_type == MessageType.RESPONSE and not (
            hasattr(self, '_pending_responses') and
            message.correlation_id in self._pending_responses
        ):
            self.log(f"Dropping unsolicited RESPONSE from {message.sender_type}", "DEBUG")
            return None

        # Otherwise, let BaseAgent handle it normally
        return await super().receive_message(message)

    async def process(self, message: A2AMessage) -> A2AMessage:
        """Process incoming messages"""
        if not self.planner:
            await self.initialize()

        task = message.task or {}
        action = task.get("action", "handle_query")

        if action == "handle_query":
            return await self._handle_user_query(message)
        elif action == "aggregate_results":
            return await self._handle_aggregation(message)
        else:
            return await self._handle_user_query(message)

    async def handle_user_query(self, query: str) -> str:
        """Main entry point for user queries - NO agent imports"""
        # NEW: Detect input type first, before any processing
        input_info = detect_input(query)
        print(f"\n⏳ {input_info['display_message']}")

        self.log(f"Processing query: {query[:100]}...")
        self.log(
            f"Detected: {input_info['input_type']}/{input_info['format']} (layer {input_info['detection_layer']}, confidence: {input_info['confidence']})",
            "INFO")

        try:
            # Step 1: Check if in scope
            if not await self._is_in_scope(query):
                return self._get_capability_summary()

            # Step 2: Decompose query
            self.log("Decomposing query...")
            model = None
            try:
                model = await self.get_model("gemma")
            except Exception:
                pass
            plan = await self.planner.decompose(query, model)

            # Step 3: Execute plan via Communication Bus
            self.log(f"Executing plan with {len(plan['subtasks'])} subtasks")
            results = await self._execute_plan(plan)

            # Step 4: Aggregate results
            self.log("Aggregating results...")
            final_response = await self._aggregate_results(results, query)

            # Step 5: Store in memory via Communication Bus
            await self._store_in_memory(query, results)

            return final_response

        except Exception as e:
            self.log(f"Error: {e}", "ERROR")
            return f"I encountered an error: {str(e)}\n\nPlease try again."

    async def _is_in_scope(self, query: str) -> bool:
        """Check if query is within system capabilities"""
        query_lower = query.lower()

        # NEW: Terminal commands are always in scope
        if query_lower.startswith("command:") or query_lower.startswith("cmd:"):
            return True

        # Clearly out-of-scope
        out_of_scope = [
            'weather', 'news', 'sport', 'recipe', 'cook',
            'movie', 'song', 'game', 'play', 'joke', 'what is your name',
            'who are you', 'how old are you',
            'how are you',     # ← ADD
            'how do you do',   # ← ADD
        ]

        for keyword in out_of_scope:
            if keyword in query_lower:
                return False

        # Log-related keywords
        log_keywords = [
            'log', 'error', 'debug', 'fix', 'crash', 'exception',
            'stack trace', 'analyze', 'issue', 'problem', 'failed',
            'failure', 'warning', 'critical', 'trace', 'fatal',
            'null', 'timeout', 'refused', 'denied', 'not found',
            'permission', 'memory', 'disk', 'network', 'database'
        ]

        for keyword in log_keywords:
            if keyword in query_lower:
                return True

        # Python error patterns
        python_errors = [
            'traceback', 'nameerror', 'typeerror', 'valueerror',
            'keyerror', 'indexerror', 'attributeerror', 'importerror',
            'modulenotfounderror', 'syntaxerror', 'indentationerror',
            'filenotfounderror', 'permissionerror', 'connectionerror',
            'timeouterror', 'runtimeerror', 'notimplementederror'
        ]

        for error in python_errors:
            if error in query_lower:
                return True

        # Contains file paths
        if any(ext in query_lower for ext in ['.py', '.log', '.txt', '.json', '.xml', '.csv']):
            return True

        # Contains line numbers (common in stack traces)
        if 'line' in query_lower and any(char.isdigit() for char in query):
            return True

        # Contains error patterns like "Error:" or "Exception:"
        if 'error:' in query_lower or 'exception:' in query_lower:
            return True

        # Has timestamp patterns
        import re
        if re.search(r'\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}', query):
            return True

        # Default: check if it looks like a technical question
        technical_words = ['what', 'why', 'how', 'fix', 'help', 'check', 'find', 'cause']
        return any(word in query_lower for word in technical_words)

    async def _execute_plan(self, plan: Dict) -> Dict:
        """Execute plan by sending A2A messages - skip if previous step failed critically"""
        import os

        subtasks = plan.get("subtasks", [])
        results = {}
        pipeline_broken = False

        for i, subtask in enumerate(subtasks):
            action = subtask.get("action", "unknown")

            # Skip if pipeline is broken
            if pipeline_broken:
                self.log(f"Skipping subtask {i + 1}: {action} (pipeline broken)")
                results[f"subtask_{i}"] = {
                    "status": "skipped",
                    "reason": "Previous critical step failed"
                }
                continue

            # ---- Fix extract subtask ----
            if action == "extract":
                import os

                original_query = plan.get("original_query", "")

                # NEW: Detect terminal command prefix
                if original_query.lower().startswith("command:") or original_query.lower().startswith("cmd:"):
                    command = original_query.split(":", 1)[1].strip()
                    if command:
                        subtask["command"] = command
                        subtask["source_type"] = "terminal"
                        subtask["content"] = None
                        subtask["file_path"] = ""
                        self.log(f"Detected terminal command: {command}", "DEBUG")

                # If query looks like a file path, resolve it directly
                elif original_query and not subtask.get("file_path"):
                    if any(original_query.endswith(ext) for ext in
                           ['.log', '.txt', '.json', '.csv', '.xml', '.jpg', '.png']):
                        abs_path = os.path.abspath(original_query)
                        subtask["file_path"] = abs_path
                        subtask["content"] = None
                        self.log(f"Resolved file path: {abs_path}", "DEBUG")

                # If still no file_path, check options and plan
                if not subtask.get("file_path") and not subtask.get("command"):
                    file_path = subtask.get("options", {}).get("path") or plan.get("file_path")
                    if file_path:
                        if not os.path.isabs(file_path):
                            file_path = os.path.abspath(file_path)
                        subtask["file_path"] = file_path
                        subtask["content"] = None

                # Last resort: use query as pasted text
                if not subtask.get("content") and not subtask.get("file_path") and not subtask.get("command"):
                    subtask["content"] = original_query
            # ---------------------------------

            self.log(f"Subtask {i + 1}/{len(subtasks)}: {action}")

            target_type = self.router.get_agent_type_for_action(action)

            if not target_type:
                self.log(f"No agent type for: {action}", "WARNING")
                results[f"subtask_{i}"] = {"status": "failed", "error": "No capable agent"}
                if action in ["extract", "preprocess"]:
                    pipeline_broken = True
                continue

            # Merge all previous results into context for downstream agents
            merged_context = _merge_results(results)
            merged_context["query"] = plan.get("original_query", "")

            request = A2AMessage.create_request(
                sender_id=self.agent_id,
                sender_type="orchestrator",
                target_type=target_type,
                task=subtask,
                context=merged_context
            )

            result = await self._send_and_wait(request, timeout=60.0)

            if result:
                if result.message_type == MessageType.ERROR:
                    results[f"subtask_{i}"] = {
                        "status": "completed_with_error",
                        "response": {"raw_logs": "", "warning": getattr(result, 'error', str(result))},
                        "confidence": 0.0
                    }
                    self.log(f"Subtask {action} returned ERROR: {getattr(result, 'error', 'unknown')}", "WARNING")
                else:
                    results[f"subtask_{i}"] = {
                        "status": "completed",
                        "agent_type": target_type,
                        "response": result.response if result.response else {"raw_logs": ""},
                        "confidence": result.confidence
                    }
                    if not result.response or not result.response.get("raw_logs"):
                        if result.confidence < 0.3:
                            self.log(f"Low confidence ({result.confidence}) and empty data — breaking pipeline",
                                     "WARNING")
                            pipeline_broken = True
            else:
                results[f"subtask_{i}"] = {
                    "status": "failed",
                    "error": "No response from agent"
                }
                if action in ["extract", "preprocess"]:
                    pipeline_broken = True

        return results

    async def _send_and_wait(
        self, message: A2AMessage, timeout: float = 60.0
    ) -> Optional[A2AMessage]:
        """Send message via bus and wait for response"""
        response_future = asyncio.Future()

        if not hasattr(self, '_pending_responses'):
            self._pending_responses = {}
        self._pending_responses[message.message_id] = response_future

        # Send through Communication Bus (not direct call)
        await self.send_message(message)

        try:
            response = await asyncio.wait_for(response_future, timeout=timeout)
            return response
        except asyncio.TimeoutError:
            return None
        finally:
            self._pending_responses.pop(message.message_id, None)

    async def _aggregate_results(self, results: Dict, query: str) -> str:
        """Aggregate results from multiple agents"""
        summary_parts = []

        for key, result in results.items():
            try:
                if result.get("status") == "completed":
                    response = result.get("response", {})
                    if isinstance(response, dict):
                        if "root_cause" in response:
                            root_cause = response["root_cause"]
                            if isinstance(root_cause, dict):
                                summary_parts.append(
                                    f"Root Cause: {root_cause.get('primary_cause', 'N/A')}"
                                )
                            elif isinstance(root_cause, str):
                                summary_parts.append(f"Root Cause: {root_cause[:500]}")
                        if "fix_suggestion" in response:
                            fix = response["fix_suggestion"]
                            if isinstance(fix, dict):
                                actions = fix.get('immediate_actions', [])
                                if actions:
                                    summary_parts.append(f"Fix: {actions[0]}")
                            elif isinstance(fix, str):
                                summary_parts.append(f"Fix: {fix[:500]}")
                        if "explanation" in response:
                            explanation = response["explanation"]
                            if isinstance(explanation, str):
                                summary_parts.append(str(explanation[:1000]))
                        if "log_type" in response:
                            summary_parts.append(f"Type: {response['log_type']}")
                        if "severity" in response:
                            summary_parts.append(f"Severity: {response['severity']}")
                        if "summary" in response:
                            summary_parts.append(str(response["summary"])[:500])
                    elif isinstance(response, str):
                        summary_parts.append(response[:500])
                elif result.get("status") == "completed_with_error":
                    summary_parts.append(
                        f"Step completed with warning: {result.get('response', {}).get('warning', 'Unknown warning')}")
                elif result.get("status") == "skipped":
                    summary_parts.append(f"Step skipped: {result.get('reason', 'Previous step failed')}")
                else:
                    summary_parts.append(f"Step incomplete: {result.get('error', 'Unknown')}")
            except Exception as e:
                summary_parts.append(f"Error processing result {key}: {e}")

        # Try LLM aggregation if model available
        try:
            model = await self.get_model("gemma")
            if model and summary_parts:
                prompt = f"""Create a helpful response from these analysis results.

                    Query: {query}
                    Results: {chr(10).join(summary_parts[:10])}
                
                    Response:"""
                final = await model.generate(prompt, max_tokens=1024)
                if final and len(final) > 50:
                    return final
        except Exception:
            pass

        return '\n\n'.join(summary_parts) if summary_parts else "Analysis complete."

    async def _store_in_memory(self, query: str, results: Dict):
        """Store in memory via A2A message, not direct call"""
        try:
            store_msg = A2AMessage.create_request(
                sender_id=self.agent_id,
                sender_type="orchestrator",
                target_type="memory",  # Discover memory agent by type
                task={
                    "action": "store_log_analysis",
                    "query": query,
                    "results": results
                }
            )
            await self.send_message(store_msg)
        except Exception:
            pass

    async def _request_human_input(self, question: str) -> str:
        """Request input from human user"""
        print(f"\n🤔 {question}")
        return input("> ")

    def _get_capability_summary(self) -> str:
        """Get system capability summary"""
        return """
🤖 I'm a specialized log analysis assistant. I can help with:

📥 LOG EXTRACTION - Files, images (OCR), terminal output
🧹 LOG PREPROCESSING - Clean, parse, structure logs
🔍 LOG ANALYSIS - Classify errors, detect intent
🔧 PROBLEM SOLVING - Root cause analysis, fix suggestions
🛡️ VALIDATION - Quality checks, safety audits
💾 MEMORY - Store and retrieve past analyses

How can I help with your logs today?
"""
