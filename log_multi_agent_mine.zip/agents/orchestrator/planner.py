"""
Task Planner - Decomposes user queries into subtasks
"""

import json
import re
from typing import Dict, List, Any
import copy

class TaskPlanner:
    """Decomposes user queries into executable subtasks"""

    # Standard pipeline stages
    PIPELINE_STAGES = [
        "extract",
        "preprocess",
        "analyze",
        "solve",
        "debug",
        "validate"
    ]

    # Task templates for common query types
    TASK_TEMPLATES = {
        "analyze_log_file": {
            "subtasks": [
                {"action": "extract", "source_type": "file"},
                {"action": "preprocess", "options": {"clean": True, "parse": True}},
                {"action": "analyze"},
                {"action": "solve"},
                {"action": "validate"}
            ]
        },
        "analyze_image_log": {
            "subtasks": [
                {"action": "extract", "source_type": "image"},
                {"action": "preprocess"},
                {"action": "analyze"},
                {"action": "solve"},
                {"action": "validate"}
            ]
        },
        "analyze_pasted_log": {
            "subtasks": [
                {"action": "extract", "source_type": "text"},
                {"action": "preprocess"},
                {"action": "analyze"},
                {"action": "solve"},
                {"action": "validate"}
            ]
        },
        "debug_error": {
            "subtasks": [
                {"action": "analyze"},
                {"action": "solve"},
                {"action": "debug"},
                {"action": "validate"}
            ]
        },
        "explain_error": {
            "subtasks": [
                {"action": "analyze"},
                {"action": "solve", "intent": "explanation"},
                {"action": "validate"}
            ]
        }
    }

    async def decompose(self, query: str, model=None) -> Dict:
        """
        Decompose a user query into a task plan.

        Returns:
            {
                "original_query": str,
                "query_type": str,
                "subtasks": List[Dict],
                "estimated_time": str,
                "requires_human": bool
            }
        """
        # Detect query type
        query_type = self._detect_query_type(query)

        # Get template-based plan
        plan = self._get_template_plan(query_type, query)

        # Only use LLM enhancement for complex/ambiguous queries
        # Skip for obvious file paths and pasted logs (templates are sufficient)
        skip_llm_types = ["analyze_log_file", "analyze_image_log", "analyze_pasted_log"]

        if model and query_type not in skip_llm_types:
            plan = await self._enhance_plan(plan, query, model)

        return plan

    def _detect_query_type(self, query: str) -> str:
        """Detect the type of user query"""
        query_lower = query.lower()

        # NEW: Check for terminal command
        if query_lower.startswith("command:") or query_lower.startswith("cmd:"):
            return "analyze_log_file"  # Reuse file pipeline with command extraction

        # Check for file paths
        if any(ext in query for ext in ['.log', '.txt', '.json', '.csv', '.xml']):
            return "analyze_log_file"

        # Check for image
        if any(ext in query for ext in ['.png', '.jpg', '.jpeg', '.bmp']):
            return "analyze_image_log"

        # Check for pasted log content (contains timestamps or log levels)
        if re.search(r'\d{4}-\d{2}-\d{2}', query):
            return "analyze_pasted_log"

        if any(level in query for level in ['ERROR', 'WARN', 'INFO', 'DEBUG', 'FATAL']):
            return "analyze_pasted_log"

        # Check intent
        if any(word in query_lower for word in ['debug', 'fix', 'patch', 'code']):
            return "debug_error"

        if any(word in query_lower for word in ['explain', 'what', 'why', 'how', 'understand']):
            return "explain_error"

        if any(word in query_lower for word in ['analyze', 'analysis', 'check', 'look']):
            return "analyze_log_file"

        # Default
        return "analyze_pasted_log"

    def _get_template_plan(self, query_type: str, query: str) -> Dict:
        """Get a template-based execution plan"""
        template = self.TASK_TEMPLATES.get(
            query_type,
            self.TASK_TEMPLATES["analyze_pasted_log"]
        )

        plan = {
            "original_query": query,
            "query_type": query_type,
            "subtasks": copy.deepcopy(template["subtasks"]),
            "estimated_time": f"{len(template['subtasks']) * 10}-{len(template['subtasks']) * 30} seconds",
            "requires_human": False
        }

        # Add query context to each subtask
        for subtask in plan["subtasks"]:
            subtask["context"] = {"query": query}

        # For pasted logs, include the content directly in the extract subtask
        if query_type == "analyze_pasted_log":
            for subtask in plan["subtasks"]:
                if subtask["action"] == "extract":
                    subtask["content"] = query  # The user's pasted text

        # Extract specific details from query
        if query_type in ("analyze_log_file", "analyze_image_log"):
            file_path = self._extract_file_path(query)
            if file_path:
                plan["file_path"] = file_path

        return plan

    async def _enhance_plan(self, plan: Dict, query: str, model) -> Dict:
        """Use LLM to enhance the execution plan"""
        prompt = f"""Improve this execution plan for a log analysis system.

User Query: {query}

Current Plan:
{json.dumps(plan['subtasks'], indent=2)}

Available pipeline stages: {', '.join(self.PIPELINE_STAGES)}

Can you:
1. Add/remove stages as needed
2. Specify options for each stage
3. Note any special handling needed

Return the improved plan as JSON:
{{
    "subtasks": [
        {{"action": "stage", "options": {{}}, "priority": "high|normal|low"}}
    ]
}}

Improved Plan:"""

        try:
            response = await model.generate(prompt, max_tokens=512)
            json_match = re.search(r'\{.*\}', response, re.DOTALL)
            if json_match:
                try:
                    enhanced = json.loads(json_match.group())
                    if "subtasks" in enhanced:
                        # Preserve file_path and content from original first subtask
                        original_first = plan["subtasks"][0] if plan["subtasks"] else {}
                        for subtask in enhanced["subtasks"]:
                            if subtask.get("action") == "extract":
                                if "file_path" in original_first:
                                    subtask["file_path"] = original_first["file_path"]
                                if "content" in original_first:
                                    subtask["content"] = original_first["content"]
                        plan["subtasks"] = enhanced["subtasks"]
                except json.JSONDecodeError:
                    pass
        except Exception:
            pass

        return plan

    def _extract_file_path(self, query: str) -> str:
        """Extract file path from query"""
        # Common path patterns
        patterns = [
            r'(?:file|path|log)[:\s]+([^\s]+\.(?:log|txt|json|csv|xml))',
            r'([/\\][^\s]+\.(?:log|txt|json|csv|xml))',
            r'([^\s]+\.(?:log|txt|json|csv|xml))',
        ]

        for pattern in patterns:
            match = re.search(pattern, query, re.IGNORECASE)
            if match:
                return match.group(1)

        return None

    def get_pipeline_stages(self) -> List[str]:
        """Get all available pipeline stages"""
        return self.PIPELINE_STAGES.copy()