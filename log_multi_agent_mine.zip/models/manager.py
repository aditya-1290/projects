"""
Model Manager - Multi-Model Lifecycle Management

Handles loading, unloading, and swapping models to stay within memory limits.
Optimized for CPU-only environments with 16GB RAM.

Key Features:
- Smart model loading/unloading
- Memory pressure detection
- Least-Recently-Used (LRU) eviction
- Automatic model swapping
- Usage statistics tracking
"""

import asyncio
import gc
import time
from typing import Dict, Optional, Any, List
from enum import Enum
from datetime import datetime

from models.model_configs import ModelConfig, MODELS, get_model_config


class ModelState(Enum):
    """Possible states for a model"""
    UNLOADED = "unloaded"
    LOADING = "loading"
    LOADED = "loaded"
    IN_USE = "in_use"
    ERROR = "error"
    UNLOADING = "unloading"


class ModelInfo:
    """Runtime information about a loaded model"""

    def __init__(self, config: ModelConfig):
        self.config = config
        self.state = ModelState.UNLOADED
        self.instance: Optional[Any] = None
        self.load_time: float = 0.0
        self.last_used: float = 0.0
        self.call_count: int = 0
        self.error_count: int = 0
        self.total_inference_time: float = 0.0
        self.loaded_at: Optional[str] = None

    @property
    def name(self) -> str:
        return self.config.name

    @property
    def size_gb(self) -> float:
        return self.config.size_gb

    @property
    def is_loaded(self) -> bool:
        return self.state in [ModelState.LOADED, ModelState.IN_USE]

    def to_dict(self) -> Dict:
        return {
            "name": self.name,
            "state": self.state.value,
            "size_gb": self.size_gb,
            "call_count": self.call_count,
            "error_count": self.error_count,
            "load_time": f"{self.load_time:.2f}s",
            "avg_inference_time": f"{self.total_inference_time / max(self.call_count, 1):.2f}s" if self.call_count > 0 else "N/A",
            "last_used": datetime.fromtimestamp(self.last_used).isoformat() if self.last_used else "never",
            "loaded_at": self.loaded_at
        }


class ModelManager:
    """
    Central model lifecycle manager.

    Responsibilities:
    - Load models on demand
    - Unload models under memory pressure
    - Track model usage and performance
    - Ensure total memory stays within limits

    Usage:
        manager = ModelManager(max_memory_gb=12.0)
        model = await manager.get_model("gemma")
        # ... use model ...
        await manager.release_model("gemma")
    """

    def __init__(self, max_memory_gb: float = 15.0):
        self.max_memory_gb = max_memory_gb
        self.models: Dict[str, ModelInfo] = {}
        self._lock = asyncio.Lock()
        self.startup_complete = False

        # Statistics
        self.total_loads = 0
        self.total_unloads = 0
        self.peak_memory_used = 0.0

        # Initialize model infos from configs
        for model_name, config in MODELS.items():
            self.models[model_name] = ModelInfo(config)

    # ============================================
    # Initialization
    # ============================================

    async def initialize(self):
        """Load all startup models"""
        self._log("INIT", "Initializing Model Manager...")
        self._log("INIT", f"Memory limit: {self.max_memory_gb}GB")

        # Load always-loaded models
        for model_name, model_info in self.models.items():
            if model_info.config.load_on_startup:
                try:
                    await self._load_model(model_info)
                    self._log("INIT", f"  ✅ Loaded: {model_info.name} ({model_info.size_gb}GB)")
                except Exception as e:
                    self._log("INIT", f"  ❌ Failed: {model_info.name} - {e}")

        self.startup_complete = True
        self._log("INIT", f"Current memory usage: {self._get_current_usage():.1f}GB")
        self._log("INIT", "Model Manager ready")

    # ============================================
    # Model Access (Main API)
    # ============================================

    async def get_model(self, name: str) -> Any:
        """
        Get a model instance. Loads if not already loaded.

        This is the PRIMARY method agents use to access models.

        Args:
            name: Model name ('gemma', 'qwen_small', 'deepseek_ocr', 'embedding')

        Returns:
            Model instance ready for inference
        """
        if name not in self.models:
            raise ValueError(f"Unknown model: {name}. Available: {list(self.models.keys())}")

        model_info = self.models[name]

        async with self._lock:
            # Already loaded - just mark as in use
            if model_info.is_loaded:
                model_info.last_used = time.time()
                model_info.call_count += 1
                model_info.state = ModelState.IN_USE
                return model_info.instance

            # Need to load
            await self._load_model_with_memory_check(model_info)
            model_info.state = ModelState.IN_USE
            model_info.call_count += 1
            return model_info.instance

    async def release_model(self, name: str):
        """
        Release a model (mark as available for unloading).

        Doesn't immediately unload, but allows it to be evicted
        if memory pressure occurs.
        """
        if name in self.models:
            model_info = self.models[name]
            async with self._lock:
                if model_info.state == ModelState.IN_USE:
                    model_info.state = ModelState.LOADED
                    model_info.last_used = time.time()

    # ============================================
    # Model Loading
    # ============================================

    async def _load_model_with_memory_check(self, model_info: ModelInfo):
        """Load model, freeing memory if needed"""
        required_memory = model_info.size_gb + 0.5  # 0.5GB buffer for overhead

        # Check if we have enough memory
        if not self._has_sufficient_memory(required_memory):
            await self._free_memory(required_memory)

            # Check again after cleanup
            if not self._has_sufficient_memory(required_memory):
                raise MemoryError(
                    f"Cannot load {model_info.name}. "
                    f"Required: {required_memory}GB, "
                    f"Available: {self._get_available_memory():.1f}GB, "
                    f"Currently used: {self._get_current_usage():.1f}GB"
                )

        await self._load_model(model_info)

    async def _load_model(self, model_info: ModelInfo):
        """Actually load a model into memory"""
        start_time = time.time()
        model_info.state = ModelState.LOADING

        try:
            # Load based on type
            if model_info.config.model_type == "llm":
                model_info.instance = await self._load_llm(model_info)
            elif model_info.config.model_type == "ocr":
                model_info.instance = await self._load_ocr(model_info)
            elif model_info.config.model_type == "embedding":
                model_info.instance = await self._load_embedding(model_info)
            else:
                raise ValueError(f"Unknown model type: {model_info.config.model_type}")

            model_info.load_time = time.time() - start_time
            model_info.state = ModelState.LOADED
            model_info.last_used = time.time()
            model_info.loaded_at = datetime.now().isoformat()

            self.total_loads += 1

            # Track peak memory
            current = self._get_current_usage()
            if current > self.peak_memory_used:
                self.peak_memory_used = current

            self._log("LOAD", f"✅ {model_info.name} loaded in {model_info.load_time:.1f}s")

        except Exception as e:
            model_info.state = ModelState.ERROR
            model_info.error_count += 1
            self._log("ERROR", f"❌ Failed to load {model_info.name}: {e}")
            raise

    def _create_llm_wrapper(self, llm, config: ModelConfig) -> Any:
        """Wrap a Llama instance to provide a consistent .generate() API"""

        class LlamaWrapper:
            def __init__(self, llama_instance, cfg):
                self._llm = llama_instance
                self._config = cfg
                self.name = cfg.name

            async def generate(self, prompt: str, max_tokens: int = 1024) -> str:
                """Generate text using create_completion (runs in thread to avoid blocking)"""
                import asyncio

                # Run the synchronous create_completion in a thread
                loop = asyncio.get_event_loop()
                result = await loop.run_in_executor(
                    None,
                    lambda: self._llm.create_completion(
                        prompt=prompt,
                        max_tokens=max_tokens,
                        temperature=self._config.temperature,
                        top_p=self._config.top_p,
                        top_k=self._config.top_k,
                        repeat_penalty=self._config.repeat_penalty,
                        stop=["<|endoftext|>", "<|user|>", "<|assistant|>"]
                    )
                )

                # Extract the generated text
                if isinstance(result, dict):
                    choices = result.get("choices", [])
                    if choices:
                        return choices[0].get("text", "")

                return str(result)

        return LlamaWrapper(llm, config)

    async def _load_llm(self, model_info: ModelInfo) -> Any:
        """Load a GGUF LLM model"""
        config = model_info.config

        try:
            from llama_cpp import Llama

            llm = Llama(
                model_path=config.path,
                n_ctx=config.context_size,
                n_threads=config.n_threads,
                n_batch=config.n_batch,
                verbose=False
            )

            self._log("LLM", f"Loaded {config.name} (ctx={config.context_size})")

            # Return a wrapper that provides a consistent .generate() interface
            return self._create_llm_wrapper(llm, config)

        except ImportError:
            self._log("LLM", "llama-cpp-python not installed, using mock")
            return self._create_mock_llm(config)
        except FileNotFoundError:
            self._log("LLM", f"Model file not found: {config.path}, using mock")
            return self._create_mock_llm(config)

    async def _load_ocr(self, model_info: ModelInfo) -> Any:
        """Load OCR model"""
        self._log("OCR", f"Loading OCR model from {model_info.config.path}")

        try:
            from models.ocr.deepseek_ocr import DeepSeekOCR
            ocr = DeepSeekOCR(model_info.config.path)
            self._log("OCR", "DeepSeek-OCR2 loaded successfully")

            # Force immediate load so memory is reserved before other models reload
            await ocr._load_model()

            return ocr
        except ImportError:
            self._log("OCR", "DeepSeek-OCR2 module not found, using mock OCR")
        except Exception as e:
            self._log("OCR", f"DeepSeek-OCR2 failed: {e}, using mock OCR")

        return self._create_mock_ocr()

    async def _load_embedding(self, model_info: ModelInfo) -> Any:
        """Load embedding model"""
        try:
            from sentence_transformers import SentenceTransformer

            model = SentenceTransformer(model_info.config.path)
            self._log("EMBED", f"Loaded embedding model from {model_info.config.path}")
            return model

        except ImportError:
            self._log("EMBED", "sentence-transformers not installed, using mock")
            return self._create_mock_embedding()
        except Exception:
            self._log("EMBED", "Failed to load embedding model, using mock")
            return self._create_mock_embedding()

    # ============================================
    # Memory Management
    # ============================================

    def _has_sufficient_memory(self, required_gb: float) -> bool:
        """Check if enough memory is available"""
        return self._get_available_memory() >= required_gb

    def _get_available_memory(self) -> float:
        """Get available system memory in GB"""
        try:
            import psutil
            mem = psutil.virtual_memory()
            available = mem.available / (1024 ** 3)

            # Subtract currently used by loaded models
            available -= self._get_current_usage()

            return max(0, available)
        except ImportError:
            # Assume enough memory if psutil not available
            return self.max_memory_gb - self._get_current_usage()

    def _get_current_usage(self) -> float:
        """Calculate memory used by loaded models"""
        return sum(
            model.size_gb
            for model in self.models.values()
            if model.is_loaded
        )

    async def _free_memory(self, required_gb: float):
        """
        Free memory by unloading models.
        Uses LRU (Least Recently Used) strategy.
        """
        needed = required_gb - self._get_available_memory()

        if needed <= 0:
            return

        self._log("MEMORY", f"Need to free {needed:.1f}GB")

        # Find unloadable models — include priority 1 if absolutely necessary
        unloadable = [
            model for model in self.models.values()
            if model.state == ModelState.LOADED
        ]

        # Sort: lower priority first, then by last used
        unloadable.sort(key=lambda m: (m.config.priority, m.last_used))

        freed = 0.0
        for model in unloadable:
            if freed >= needed:
                break

            self._log("MEMORY", f"Unloading {model.name} ({model.size_gb}GB)")
            await self._unload_model(model)
            freed += model.size_gb

    async def _unload_model(self, model_info: ModelInfo):
        """Unload a model and free its memory"""
        model_info.state = ModelState.UNLOADING
        model_info.instance = None
        model_info.state = ModelState.UNLOADED
        model_info.loaded_at = None

        self.total_unloads += 1

        # Force garbage collection
        gc.collect()

    # ============================================
    # Mock Models (for development/testing)
    # ============================================

    def _create_mock_llm(self, config: ModelConfig) -> Any:
        """Create a mock LLM for testing without real models"""

        class MockLLM:
            def __init__(self, name, context_size):
                self.name = name
                self.context_size = context_size

            async def generate(self, prompt: str, max_tokens: int = 1024) -> str:
                """Mock generation"""
                return f"[MOCK {self.name} RESPONSE] This is a mock response for: {prompt[:100]}..."

        return MockLLM(config.name, config.context_size)

    def _create_mock_ocr(self) -> Any:
        """Create a mock OCR for testing"""

        class MockOCR:
            def __init__(self):
                self.name = "mock-ocr"

            async def extract_text(self, image_path: str) -> str:
                import os
                filename = os.path.basename(image_path)
                return f"[MOCK OCR] Simulated text from: {filename}\n" \
                       f"Install DeepSeek-OCR2 or tesseract for real OCR."

        return MockOCR()

    def _create_mock_embedding(self) -> Any:
        """Create a mock embedding model"""
        import numpy as np

        class MockEmbedding:
            def encode(self, texts, **kwargs):
                if isinstance(texts, str):
                    texts = [texts]
                return np.random.randn(len(texts), 384)  # BGE-Small dimension

        return MockEmbedding()

    # ============================================
    # Status & Monitoring
    # ============================================

    def get_status(self) -> Dict:
        """Get comprehensive model manager status"""
        return {
            "startup_complete": self.startup_complete,
            "max_memory_gb": self.max_memory_gb,
            "current_usage_gb": round(self._get_current_usage(), 2),
            "available_memory_gb": round(self._get_available_memory(), 2),
            "peak_memory_gb": round(self.peak_memory_used, 2),
            "total_loads": self.total_loads,
            "total_unloads": self.total_unloads,
            "models": {
                name: model.to_dict()
                for name, model in self.models.items()
            }
        }

    def print_status(self):
        """Pretty print the model manager status"""
        status = self.get_status()

        print("\n" + "=" * 60)
        print("MODEL MANAGER STATUS")
        print("=" * 60)
        print(f"Memory: {status['current_usage_gb']}GB / {status['max_memory_gb']}GB "
              f"(Peak: {status['peak_memory_gb']}GB)")
        print(f"Available: {status['available_memory_gb']}GB")
        print(f"Loads: {status['total_loads']} | Unloads: {status['total_unloads']}")
        print()

        for name, model in status['models'].items():
            state_emoji = {
                "loaded": "✅",
                "unloaded": "⬜",
                "in_use": "🟢",
                "loading": "🔄",
                "error": "❌"
            }.get(model['state'], "❓")

            print(f"{state_emoji} {model['name']} ({model['state']})")
            print(f"   Size: {model['size_gb']}GB | Calls: {model['call_count']}")
            print(f"   Load time: {model['load_time']} | Avg inference: {model['avg_inference_time']}")
        print("=" * 60 + "\n")

    def _log(self, category: str, message: str):
        """Internal logging"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        print(f"[{timestamp}] [MODEL] [{category}] {message}")


# ============================================
# Singleton (optional)
# ============================================

# Global model manager instance
_model_manager: Optional[ModelManager] = None


def get_model_manager(max_memory_gb: float = 15.0) -> ModelManager:
    """Get or create the global model manager"""
    global _model_manager
    if _model_manager is None:
        _model_manager = ModelManager(max_memory_gb=max_memory_gb)
    return _model_manager