"""
FasTag Multi‑Agents – FastAPI Backend
Serves the chat UI, manages sessions, and processes user queries.
"""

import json
import asyncio
import logging
from pathlib import Path
from typing import Optional, List
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from core.communication_bus import InMemoryCommunicationBus
from core.capability_registry import CapabilityRegistry
from core.context_manager import ContextManager
from cache.recent_queries import RecentQueriesCache
from core.workflow_router import QueryRouter
from agents.support_agent.agent import SupportAgent
from agents.support_agent.adk_agent_card import SupportAgentCard
from agents.mlff_agent.agent import MLFFAgent
from agents.mlff_agent.adk_agent_card import MLFFAgentCard
from config.settings import settings

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# App Setup
# ---------------------------------------------------------------------------
app = FastAPI(title=settings.app_name)

# Session storage (in‑memory for now, file‑based later)
sessions_db: dict = {}           # session_id -> list of messages
session_metadata: dict = {}      # session_id -> {"created_at": ..., "title": ...}
MAX_SESSIONS = settings.sessions.max_sessions
MAX_MESSAGES = settings.sessions.max_messages_per_session

# Core components (singletons)
bus = InMemoryCommunicationBus()
registry = CapabilityRegistry()
context_manager = ContextManager()
cache = RecentQueriesCache()

# Agents
support_agent = SupportAgent(
    SupportAgentCard(tenant_id=settings.tenant_id),
    bus, registry, context_manager
)
mlff_agent = MLFFAgent(
    MLFFAgentCard(tenant_id=settings.tenant_id),
    bus, registry, context_manager
)

# Router
router = QueryRouter(bus, registry, context_manager, cache, support_agent, mlff_agent)

# Static files (frontend HTML/CSS/JS)
from fastapi.staticfiles import StaticFiles
import os
frontend_dir = os.path.join(os.path.dirname(__file__), "..", "frontend")
if os.path.isdir(frontend_dir):
    app.mount("/static", StaticFiles(directory=frontend_dir), name="static")

# ---------------------------------------------------------------------------
# Session Helpers
# ---------------------------------------------------------------------------
def _enforce_session_limits():
    """Ensure only MAX_SESSIONS are kept."""
    if len(sessions_db) > MAX_SESSIONS:
        # Remove oldest session
        oldest = min(sessions_db, key=lambda sid: session_metadata[sid]["created_at"])
        del sessions_db[oldest]
        del session_metadata[oldest]
        logger.info(f"Session limit reached; removed oldest session {oldest}")

def _enforce_message_limit(session_id: str):
    if len(sessions_db.get(session_id, [])) > MAX_MESSAGES:
        # Remove first (oldest) message
        sessions_db[session_id].pop(0)

# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------
@app.get("/", response_class=HTMLResponse)
async def index():
    """Serve the chat UI."""
    index_path = os.path.join(frontend_dir, "index.html")
    if os.path.exists(index_path):
        return HTMLResponse(open(index_path, "r").read())
    return HTMLResponse("<h1>Frontend not found</h1>")

@app.get("/api/sessions")
async def list_sessions():
    """Return list of sessions with metadata."""
    return [
        {"id": sid, "title": meta.get("title", "New Chat"), "created_at": meta["created_at"]}
        for sid, meta in session_metadata.items()
    ]

@app.post("/api/sessions")
async def create_session(request: Request):
    data = await request.json()
    title = data.get("title", "New Chat")
    from datetime import datetime, timezone
    sid = str(len(sessions_db) + 1)
    sessions_db[sid] = []
    session_metadata[sid] = {"title": title, "created_at": datetime.now(timezone.utc).isoformat()}
    _enforce_session_limits()
    return {"session_id": sid}

@app.delete("/api/sessions/{session_id}")
async def delete_session(session_id: str):
    """Delete a session."""
    sessions_db.pop(session_id, None)
    session_metadata.pop(session_id, None)
    return {"status": "deleted"}

@app.get("/api/agents")
async def list_agents():
    """Return available agents for the selector."""
    return [
        {"id": "auto", "name": "Auto (Recommended)"},
        {"id": "support", "name": "Support Agent"},
        {"id": "mlff", "name": "MLFF Agent"},
    ]

@app.post("/api/query")
async def handle_query(request: Request):
    """Process a user query."""
    data = await request.json()
    user_query = data.get("query")
    session_id = data.get("session_id", "default")
    selected_agent = data.get("agent", None)  # 'auto' or None means auto

    if not user_query:
        raise HTTPException(status_code=400, detail="Missing 'query' field.")

    # Route the query
    response = await router.route(user_query, session_id, selected_agent)

    # Add to session history
    if session_id not in sessions_db:
        sessions_db[session_id] = []
    sessions_db[session_id].append({
        "role": "user",
        "content": user_query,
    })
    sessions_db[session_id].append({
        "role": "agent",
        "content": response["text"],
        "chart": response.get("chart"),
    })
    _enforce_message_limit(session_id)

    return JSONResponse(response)

@app.get("/api/sessions/{session_id}/messages")
async def get_session_messages(session_id: str):
    """Return all messages for a session."""
    return JSONResponse(sessions_db.get(session_id, []))
