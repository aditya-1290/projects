"""
PostgreSQL MCP tool definitions – reusable query functions.
Used by the MCP server but also importable by agents that want direct DB access.
"""

import asyncpg
from typing import Any, Dict, List, Optional
import logging

logger = logging.getLogger(__name__)


async def query(pool: asyncpg.Pool, sql: str, params: Optional[List[Any]] = None) -> List[Dict]:
    async with pool.acquire() as conn:
        rows = await conn.fetch(sql, *(params or []))
        return [dict(r) for r in rows]


async def get_schema(pool: asyncpg.Pool, table_name: str) -> List[Dict]:
    sql = """
        SELECT column_name, data_type, is_nullable, column_default
        FROM information_schema.columns
        WHERE table_name = $1
        ORDER BY ordinal_position
    """
    return await query(pool, sql, [table_name])


async def list_tables(pool: asyncpg.Pool) -> List[str]:
    sql = "SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' ORDER BY table_name"
    rows = await query(pool, sql)
    return [r['table_name'] for r in rows]


async def insert(pool: asyncpg.Pool, table: str, data: Dict[str, Any]) -> Dict:
    columns = list(data.keys())
    values = list(data.values())
    placeholders = [f"${i+1}" for i in range(len(values))]
    sql = f"INSERT INTO {table} ({', '.join(columns)}) VALUES ({', '.join(placeholders)}) RETURNING *"
    async with pool.acquire() as conn:
        row = await conn.fetchrow(sql, *values)
        return dict(row) if row else {}
