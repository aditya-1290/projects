"""
PostgreSQL MCP Server using FastMCP.
Provides tools for querying and managing a PostgreSQL database.
Can be used internally by agents (via McpToolset) or exposed to external apps like Claude Desktop.
"""

import os
import logging
from typing import Annotated, Optional, List, Any
from pydantic import Field
import asyncpg
from fastmcp import FastMCP

logger = logging.getLogger(__name__)

# Create the MCP server
mcp = FastMCP("PostgreSQL MCP Server")

# Global connection pool
_pool: Optional[asyncpg.Pool] = None

async def get_pool() -> asyncpg.Pool:
    """Get or create a connection pool using the POSTGRES_DSN env var."""
    global _pool
    if _pool is None:
        dsn = os.getenv("POSTGRES_DSN", "postgresql://postgres:postgres@localhost:5432/defaultdb")
        _pool = await asyncpg.create_pool(dsn, min_size=2, max_size=10)
        logger.info("PostgreSQL connection pool created")
    return _pool

@mcp.tool
async def query_database(
    query: Annotated[str, Field(description="SQL query to execute (SELECT only for safety)")],
    params: Annotated[Optional[List[Any]], Field(description="Query parameters")] = None
) -> dict:
    """Execute a read-only SQL query."""
    pool = await get_pool()
    try:
        async with pool.acquire() as conn:
            rows = await conn.fetch(query, *(params or []))
            return {
                "status": "success",
                "count": len(rows),
                "data": [dict(r) for r in rows]
            }
    except Exception as e:
        logger.error(f"Query failed: {e}")
        return {"status": "error", "message": str(e)}

@mcp.tool
async def get_table_schema(
    table_name: Annotated[str, Field(description="Name of the table")]
) -> dict:
    """Get column information for a table."""
    pool = await get_pool()
    try:
        async with pool.acquire() as conn:
            rows = await conn.fetch("""
                SELECT column_name, data_type, is_nullable, column_default
                FROM information_schema.columns
                WHERE table_name = $1
                ORDER BY ordinal_position
            """, table_name)
            return {
                "status": "success",
                "table": table_name,
                "columns": [dict(r) for r in rows]
            }
    except Exception as e:
        return {"status": "error", "message": str(e)}

@mcp.tool
async def list_tables() -> dict:
    """List all tables in the public schema."""
    pool = await get_pool()
    try:
        async with pool.acquire() as conn:
            rows = await conn.fetch("""
                SELECT table_name
                FROM information_schema.tables
                WHERE table_schema = 'public'
                ORDER BY table_name
            """)
            return {"status": "success", "tables": [r['table_name'] for r in rows]}
    except Exception as e:
        return {"status": "error", "message": str(e)}

@mcp.tool
async def insert_record(
    table: Annotated[str, Field(description="Target table")],
    data: Annotated[dict, Field(description="Column-value pairs")]
) -> dict:
    """Insert a record into a table."""
    pool = await get_pool()
    try:
        columns = list(data.keys())
        values = list(data.values())
        placeholders = [f"${i+1}" for i in range(len(values))]
        query = f"INSERT INTO {table} ({', '.join(columns)}) VALUES ({', '.join(placeholders)}) RETURNING *"
        async with pool.acquire() as conn:
            row = await conn.fetchrow(query, *values)
            return {"status": "success", "record": dict(row)}
    except Exception as e:
        return {"status": "error", "message": str(e)}

if __name__ == "__main__":
    mcp.run()
