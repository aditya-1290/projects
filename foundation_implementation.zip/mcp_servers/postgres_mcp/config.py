"""PostgreSQL MCP server configuration."""
from dataclasses import dataclass

@dataclass
class PostgresMCPConfig:
    dsn: str = "postgresql://postgres:postgres@localhost:5432/defaultdb"
    pool_min_size: int = 2
    pool_max_size: int = 10