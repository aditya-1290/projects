"""MCP server discovery and registration."""
from typing import Dict, List, Optional
import logging

logger = logging.getLogger(__name__)

class MCPServerRegistry:
    """Registry of available MCP servers for agents to discover."""

    def __init__(self):
        self._servers: Dict[str, dict] = {}

    def register(self, name: str, command: str, args: List[str], env: Optional[Dict[str, str]] = None) -> None:
        self._servers[name] = {"command": command, "args": args, "env": env or {}}
        logger.info(f"MCP server '{name}' registered")

    def get(self, name: str) -> Optional[dict]:
        return self._servers.get(name)

    def list_servers(self) -> List[str]:
        return list(self._servers.keys())

# Default servers
def create_default_registry() -> MCPServerRegistry:
    registry = MCPServerRegistry()
    registry.register(
        "postgres",
        command="python",
        args=["-m", "mcp_servers.postgres_mcp.server"],
        env={"POSTGRES_DSN": "postgresql://postgres:postgres@localhost:5432/defaultdb"}
    )
    return registry
