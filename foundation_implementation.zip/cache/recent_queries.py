"""
SQLite cache for recent queries (last 50 by default).
Used to instantly return cached results if the exact same query is repeated.
"""

import sqlite3
import json
from datetime import datetime, timezone
from typing import Any, Dict, Optional
from config.settings import settings

TABLE_NAME = "recent_queries"

CREATE_TABLE_SQL = f"""
CREATE TABLE IF NOT EXISTS {TABLE_NAME} (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    query_text TEXT UNIQUE,
    agent_used TEXT,
    result_data TEXT,          -- JSON string
    created_at TEXT
)
"""

class RecentQueriesCache:
    def __init__(self, db_path: str = settings.cache.db_path):
        self.db_path = db_path
        self._init_db()

    def _init_db(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(CREATE_TABLE_SQL)
            conn.commit()

    def get(self, query_text: str, agent_used: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """
        Return cached result if an exact query match exists.
        If agent_used is given, only return cache entry if the same agent handled it.
        """
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            if agent_used:
                row = conn.execute(
                    f"SELECT * FROM {TABLE_NAME} WHERE query_text = ? AND agent_used = ?",
                    (query_text, agent_used)
                ).fetchone()
            else:
                row = conn.execute(
                    f"SELECT * FROM {TABLE_NAME} WHERE query_text = ?",
                    (query_text,)
                ).fetchone()

            if row:
                return {
                    "query_text": row["query_text"],
                    "agent_used": row["agent_used"],
                    "result_data": json.loads(row["result_data"]),
                }
        return None

    def set(self, query_text: str, agent_used: str, result_data: Any):
        """Insert or update a cached query result."""
        now = datetime.now(timezone.utc).isoformat()
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                f"""
                INSERT INTO {TABLE_NAME} (query_text, agent_used, result_data, created_at)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(query_text) DO UPDATE SET
                    agent_used = excluded.agent_used,
                    result_data = excluded.result_data,
                    created_at = excluded.created_at
                """,
                (query_text, agent_used, json.dumps(result_data), now)
            )
            conn.commit()
            self._enforce_limit()

    def _enforce_limit(self):
        """Keep only the most recent max_entries."""
        with sqlite3.connect(self.db_path) as conn:
            count = conn.execute(f"SELECT COUNT(*) FROM {TABLE_NAME}").fetchone()[0]
            if count > settings.cache.max_entries:
                delete_count = count - settings.cache.max_entries
                conn.execute(
                    f"""
                    DELETE FROM {TABLE_NAME}
                    WHERE id IN (
                        SELECT id FROM {TABLE_NAME}
                        ORDER BY created_at ASC
                        LIMIT ?
                    )
                    """,
                    (delete_count,)
                )
                conn.commit()
