"""
Local Model Provider – ADK‑compatible model for any OpenAI‑compatible
local server (llama.cpp, vLLM). Uses google.genai.types to build responses.
"""

from typing import Optional
import aiohttp
from pydantic import Field

from google.adk.models.base_llm import BaseLlm
from google.adk.models.llm_request import LlmRequest
from google.adk.models.llm_response import LlmResponse
from google.genai import types


class LocalOpenAIModel(BaseLlm):
    """Calls a local OpenAI‑compatible inference server."""

    model_name: str = Field(default="D:/python_tasks/models/gemma-4-E4B-it-Q5_K_M.gguf")
    base_url: str = Field(default="http://127.0.0.1:8080/v1")
    api_key: str = Field(default="not-needed")
    temperature: float = Field(default=0.7)
    max_tokens: int = Field(default=4096)

    async def generate_content_async(self, request: LlmRequest) -> LlmResponse:
        # Build messages list from the request contents
        messages = []
        for content in request.contents:
            role = content.role if content.role else "user"
            text = " ".join(
                part.text for part in content.parts if hasattr(part, "text")
            )
            messages.append({"role": role, "content": text})

        payload = {
            "model": self.model_name,
            "messages": messages,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
        }
        headers = {"Authorization": f"Bearer {self.api_key}"}

        async with aiohttp.ClientSession() as session:
            async with session.post(
                f"{self.base_url}/chat/completions", json=payload, headers=headers
            ) as resp:
                if resp.status != 200:
                    error_text = await resp.text()
                    raise RuntimeError(
                        f"Local model error {resp.status}: {error_text}"
                    )
                data = await resp.json()
                answer = data["choices"][0]["message"]["content"]

        # Build a valid LlmResponse using google.genai.types
        genai_response = types.GenerateContentResponse(
            candidates=[
                types.Candidate(
                    content=types.Content(
                        role="model",
                        parts=[types.Part(text=answer)],
                    ),
                    finish_reason=types.FinishReason.STOP,
                )
            ],
            model_version=self.model_name,
        )
        return LlmResponse(response=genai_response)


def create_local_model(
    model: str = "D:/python_tasks/models/gemma-4-E4B-it-Q5_K_M.gguf",
    base_url: str = "http://127.0.0.1:8080/v1",
    api_key: str = "not-needed",
    temperature: float = 0.7,
    max_tokens: int = 4096,
) -> LocalOpenAIModel:
    return LocalOpenAIModel(
        model=model,
        base_url=base_url,
        api_key=api_key,
        temperature=temperature,
        max_tokens=max_tokens,
    )