"""
Model Manager – Centralized local LLM lifecycle, pooling, and cost tracking.
All models are local (Ollama or any OpenAI-compatible endpoint).
"""

import logging
from typing import Dict, Optional, Any
from dataclasses import dataclass

logger = logging.getLogger(__name__)

@dataclass
class ModelConfig:
    """Configuration for a local model."""
    model_id: str              # e.g., "ollama/llama3.1"
    provider: str = "local"    # always local
    model_name: str = "llama3.1"  # actual model name on the local server
    base_url: str = "http://localhost:11434/v1"  # OpenAI-compatible endpoint
    api_key: str = "not-needed"
    temperature: float = 0.7
    max_tokens: int = 4096
    rate_limit_per_minute: int = 60

class ModelManager:
    """Manages local model instances, usage tracking, and fallback chains."""

    def __init__(self):
        self._models: Dict[str, ModelConfig] = {}
        self._usage: Dict[str, int] = {}

    def register_model(self, config: ModelConfig) -> None:
        self._models[config.model_id] = config
        logger.info(f"Local model registered: {config.model_id} ({config.model_name}) at {config.base_url}")

    def get_model_config(self, model_id: str) -> Optional[ModelConfig]:
        return self._models.get(model_id)

    async def generate(self, model_id: str, prompt: str, **kwargs) -> str:
        """
        Generate a response from a local model.
        Uses the OpenAI-compatible endpoint; works with Ollama, vLLM, etc.
        """
        config = self.get_model_config(model_id)
        if not config:
            raise ValueError(f"Model {model_id} not registered")

        self._usage[model_id] = self._usage.get(model_id, 0) + 1

        # Use an async HTTP call to the local endpoint (e.g., Ollama)
        import aiohttp
        async with aiohttp.ClientSession() as session:
            payload = {
                "model": config.model_name,
                "messages": [{"role": "user", "content": prompt}],
                "temperature": kwargs.get("temperature", config.temperature),
                "max_tokens": kwargs.get("max_tokens", config.max_tokens),
            }
            headers = {"Authorization": f"Bearer {config.api_key}"}
            async with session.post(f"{config.base_url}/chat/completions", json=payload, headers=headers) as resp:
                if resp.status != 200:
                    raise RuntimeError(f"Local model error: {resp.status} {await resp.text()}")
                data = await resp.json()
                return data["choices"][0]["message"]["content"]

    async def generate_with_fallback(self, model_ids: list, prompt: str, **kwargs) -> str:
        last_error = None
        for mid in model_ids:
            try:
                return await self.generate(mid, prompt, **kwargs)
            except Exception as e:
                logger.warning(f"Model {mid} failed: {e}")
                last_error = e
        raise RuntimeError(f"All fallback models failed. Last error: {last_error}")
    