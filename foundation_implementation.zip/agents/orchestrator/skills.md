# Orchestrator Agent – Skills & Capabilities

## Overview
The Orchestrator Agent is the central routing and coordination layer for the multi-agent system. It analyzes incoming user requests, determines the appropriate specialized agent(s) to handle them, and manages complex multi-step workflows.

## Core Skills

### 1. Intent Recognition
- **Description**: Classifies user queries into predefined intents.
- **Method**: LLM-based (Gemini) with regex fallback.
- **Example**: "What's the weather?" → `weather_query`

### 2. Intelligent Agent Routing
- **Description**: Selects the best agent for the task.
- **Strategies**: Intent-based (default), capability match, round-robin, least-load.
- **Selection Criteria**: Availability, historical performance, capability match score.

### 3. Multi-Agent Workflow Orchestration
- **Description**: Coordinates multiple agents for complex tasks.
- **Patterns**: Sequential (pipeline), parallel (fan-out), conditional branching.

### 4. Error Handling & Fallback
- **Description**: Retry on failure, fallback to alternate agents, circuit breaking.

## Tools/Functions

| Tool | Description |
|------|-------------|
| `find_agents_for_intent(intent)` | Queries the CapabilityRegistry for agents matching the intent. |
| `get_agent_details(agent_id)` | Returns full agent card. |
| `list_all_agents()` | Lists all registered agents (diagnostics). |

## Limitations
- Single point of failure (mitigated by future replication).
- LLM intent classification may have latency.
- Requires well-defined agent capabilities for optimal routing.