"""
Orchestrator Agent – Routes requests to specialized agents.
Extends BaseAgent, implements build_llm_agent() and process().
"""

import logging
from typing import Optional
from google.adk.agents import LlmAgent
from google.adk.tools import FunctionTool

from core.a2a_protocol import A2AMessage, MessageType
from core.communication_bus import CommunicationBus
from core.capability_registry import CapabilityRegistry
from core.context_manager import ContextManager
from agents.base_agent import BaseAgent
from agents.orchestrator.adk_agent_card import OrchestratorAgentCard
from agents.orchestrator.config import OrchestratorConfig
from agents.orchestrator.tools import OrchestratorTools

logger = logging.getLogger(__name__)


class OrchestratorAgent(BaseAgent):
    """The routing agent that delegates to the appropriate specialized agent."""

    def __init__(
        self,
        agent_card: OrchestratorAgentCard,
        communication_bus: CommunicationBus,
        registry: CapabilityRegistry,
        context_manager: ContextManager,
        config: Optional[OrchestratorConfig] = None,
    ):
        super().__init__(
            agent_card=agent_card,
            communication_bus=communication_bus,
            registry=registry,
            context_manager=context_manager,
            # Do NOT pass name or config here
        )
        self.config = config or OrchestratorConfig()
        self.tools = OrchestratorTools(registry, agent_card.tenant_id)
        
    def build_llm_agent(self) -> LlmAgent:
        """
        Construct the ADK LlmAgent that powers the orchestrator.
        The LLM will use tools to find and select agents for routing.
        """
        # Define tools as ADK FunctionTool
        adk_tools = [
            FunctionTool(self.tools.find_agents_for_intent),
            FunctionTool(self.tools.get_agent_details),
            FunctionTool(self.tools.list_all_agents),
        ]

        from config.settings import settings
        from model.providers.local_provider import create_local_model

        model_cfg = settings.get_model_config(settings.orchestrator.model_id)
        model = create_local_model(
            model_name=model_cfg.model_name,
            base_url=model_cfg.base_url,
            api_key=model_cfg.api_key,
            temperature=model_cfg.temperature,
            max_tokens=model_cfg.max_tokens
        )

        instruction = """
                You are an orchestrator agent. Your job is to route user requests to the most appropriate agent.
                Use the available tools to find agents that can handle the user's intent.
                Analyze the request, determine the intent, and select the best agent.
                If multiple agents can handle it, pick the one with the highest capability match and availability.
                If no agent can handle it, respond with a helpful error message.
                """

        return LlmAgent(
            name=self.card.agent_id,
            model=model,
            instruction=instruction,
            tools=adk_tools,
            # output_key not strictly needed; we'll capture the agent's final response manually.
        )


    async def process(self, message: A2AMessage) -> Optional[A2AMessage]:
        """
        Process an incoming request.
        Steps:
        1. Use LLM (via built-in ADK agent) to extract intent and select target agent.
        2. Forward the original payload to the selected agent via the bus.
        3. Return the response back to the original caller.
        """
        if message.message_type != MessageType.REQUEST:
            # We only handle requests; events are ignored
            return None

        # Extract user query (could be in payload)
        user_query = message.payload.get("query", "")
        if not user_query:
            return A2AMessage(
                tenant_id=self.card.tenant_id,
                message_type=MessageType.ERROR,
                sender_id=self.card.agent_id,
                recipient_id=message.sender_id,
                correlation_id=message.message_id,
                payload={"error": "No query provided in request payload."}
            )

        # Step 1: Use LLM to analyze intent and select target agent
        # We'll create a synthetic user content for the ADK runner
        try:
            # This is a simplified approach: we directly call the tools and LLM logic
            # In a real scenario we'd use the Runner, but for now we manually orchestrate.
            intent = await self._classify_intent(user_query)
            if not intent:
                return A2AMessage(
                    tenant_id=self.card.tenant_id,
                    message_type=MessageType.ERROR,
                    sender_id=self.card.agent_id,
                    recipient_id=message.sender_id,
                    correlation_id=message.message_id,
                    payload={"error": "Could not determine intent from query."}
                )

            # Find agents that can handle the intent
            capable_agents = await self.registry.find_by_intent(intent, self.card.tenant_id)
            if not capable_agents:
                return A2AMessage(
                    tenant_id=self.card.tenant_id,
                    message_type=MessageType.ERROR,
                    sender_id=self.card.agent_id,
                    recipient_id=message.sender_id,
                    correlation_id=message.message_id,
                    payload={"error": f"No agent capable of handling intent '{intent}'."}
                )

            # Select best agent (simple: pick first available)
            target_agent = capable_agents[0]
            logger.info(f"Routing '{user_query}' to agent {target_agent.agent_id}")

            # Step 2: Forward request to target agent
            forwarded = A2AMessage(
                tenant_id=self.card.tenant_id,
                message_type=MessageType.REQUEST,
                sender_id=self.card.agent_id,
                recipient_id=target_agent.agent_id,
                payload=message.payload,  # Pass through original payload
                intent=intent,
                context=message.context,
                correlation_id=message.message_id,  # Keep original correlation
            )
            response = await self.bus.request(forwarded, timeout=self.config.request_timeout_seconds)

            # Step 3: Return the response to the original requester
            return response

        except Exception as e:
            logger.error(f"Orchestration failed: {e}", exc_info=True)
            return A2AMessage(
                tenant_id=self.card.tenant_id,
                message_type=MessageType.ERROR,
                sender_id=self.card.agent_id,
                recipient_id=message.sender_id,
                correlation_id=message.message_id,
                payload={"error": f"Orchestration error: {str(e)}"}
            )

    async def _classify_intent(self, query: str) -> Optional[str]:
        """
        Simple intent classification. In production, use the LLM with tool calling.
        For now, we'll use a keyword-based fallback or directly use the LLM agent.
        """
        # Placeholder: use the LLM agent's generate_content if available, else simple mapping
        # For demonstration, assume a simple mapping
        query_lower = query.lower()
        if "weather" in query_lower:
            return "weather_query"
        elif "calculate" in query_lower or "math" in query_lower:
            return "calculator"
        # In a full implementation, we'd invoke self._adk_agent with a prompt
        # For now return "general" and rely on registry fallback
        return "general"
