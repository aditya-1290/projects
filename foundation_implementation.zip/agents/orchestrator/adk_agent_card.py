"""
Orchestrator-specific agent card extending ADKAgentCard.
"""
import os
from dataclasses import dataclass, field
from typing import List, Dict, Any
from core.agent_card import ADKAgentCard, Capability, AgentStatus

@dataclass
class OrchestratorAgentCard(ADKAgentCard):
    """Custom card with routing metadata."""
    routing_strategy: str = "intent_based"       # "intent_based", "round_robin", "load_balanced"
    supported_intents: List[str] = field(default_factory=lambda: ["*"])  # All intents
    max_parallel_routes: int = 10
    # model_name: str = os.getenv("LOCAL_MODEL_NAME")         # LLM used for intent classification
    # Default capabilities
    capabilities: List[Capability] = field(default_factory=lambda: [
        Capability(
            name="intent_routing",
            description="Routes user requests to the best agent based on intent analysis",
            input_schema={
                "type": "object",
                "properties": {
                    "user_query": {"type": "string"},
                    "session_context": {"type": "object"}
                }
            },
            output_schema={
                "type": "object",
                "properties": {
                    "routed_agent": {"type": "string"},
                    "confidence": {"type": "number"}
                }
            },
            tags=["orchestration", "routing"]
        ),
        Capability(
            name="multi_agent_workflow",
            description="Coordinates multiple agents for complex tasks",
            input_schema={},
            output_schema={},
            tags=["orchestration", "workflow"]
        )
    ])
