"""
Orchestrator tools: functions the LLM agent can call to find and select agents.
"""
from typing import Dict, List, Optional, Any
import logging
from core.capability_registry import CapabilityRegistry
from core.agent_card import ADKAgentCard

logger = logging.getLogger(__name__)


class OrchestratorTools:
    """Callable tools for the Orchestrator LLM agent."""

    def __init__(self, registry: CapabilityRegistry, tenant_id: str):
        self.registry = registry
        self.tenant_id = tenant_id

    async def find_agents_for_intent(self, intent: str) -> List[Dict[str, Any]]:
        """
        Find agents in the registry that can handle a specific intent.
        Returns list of agent summaries.
        """
        try:
            agents = await self.registry.find_by_intent(intent, self.tenant_id)
            return [
                {
                    "agent_id": a.agent_id,
                    "display_name": a.display_name,
                    "capabilities": [c.name for c in a.capabilities],
                    "status": a.status.value,
                    "avg_response_time_ms": a.average_response_time_ms
                }
                for a in agents
            ]
        except Exception as e:
            logger.error(f"Error finding agents for intent '{intent}': {e}")
            return []

    async def get_agent_details(self, agent_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve detailed card for a specific agent."""
        try:
            agent = await self.registry.get_agent(agent_id, self.tenant_id)
            return {
                "agent_id": agent.agent_id,
                "display_name": agent.display_name,
                "description": agent.description,
                "capabilities": [{
                    "name": c.name,
                    "description": c.description,
                    "input_schema": c.input_schema,
                    "output_schema": c.output_schema
                } for c in agent.capabilities],
                "status": agent.status.value,
                "rate_limits": agent.rate_limits
            }
        except Exception:
            return None

    async def list_all_agents(self) -> List[Dict[str, Any]]:
        """List all registered agents (for diagnostics or routing decisions)."""
        agents = await self.registry.list_agents(self.tenant_id)
        return [
            {
                "agent_id": a.agent_id,
                "display_name": a.display_name,
                "capabilities": [c.name for c in a.capabilities],
                "status": a.status.value
            }
            for a in agents
        ]
