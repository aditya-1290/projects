"""Orchestrator-specific configuration."""
from dataclasses import dataclass, field
from typing import List


@dataclass
class OrchestratorConfig:
    # Routing
    default_routing_strategy: str = "intent_based"
    min_confidence_threshold: float = 0.7
    max_retries: int = 3

    # Intent classification
    intent_model: str = "gemini-2.0-flash"
    use_cached_intents: bool = True
    cache_ttl_seconds: int = 3600

    # Performance
    max_parallel_executions: int = 10
    request_timeout_seconds: int = 30

    # Supported intents (if not '*')
    supported_intents: List[str] = field(default_factory=lambda: ["*"])
