from dataclasses import dataclass, field
from core.agent_card import ADKAgentCard, Capability

@dataclass
class MLFFAgentCard(ADKAgentCard):
    agent_type: str = "mlff"
    display_name: str = "MLFF Agent"
    description: str = "Answers queries using the MLFF schema (tolling data)."
    capabilities: list = field(default_factory=lambda: [
        Capability(
            name="mlff_query",
            description="Executes natural language queries against MLFF tables.",
            tags=["mlff", "tolling"]
        )
    ])
