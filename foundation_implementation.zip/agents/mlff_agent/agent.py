"""
MLFFAgent – Translates user queries to SQL for the MLFF schema,
executes via MCP server, and returns results with a Plotly chart.
"""

import json
import logging
from typing import Dict, Any, List, Optional
from pathlib import Path

from agents.base_agent import BaseAgent
from agents.mlff_agent.adk_agent_card import MLFFAgentCard
from core.communication_bus import CommunicationBus
from core.capability_registry import CapabilityRegistry
from core.context_manager import ContextManager
from config.settings import settings
from model.providers.local_provider import create_local_model

logger = logging.getLogger(__name__)

# Reuse the same MCP client as SupportAgent (could be shared in a future refactor)
class MCPServerClient:
    def __init__(self, base_url: str = "http://localhost:8001"):
        self.base_url = base_url

    async def query(self, sql: str) -> List[Dict]:
        import aiohttp
        async with aiohttp.ClientSession() as session:
            async with session.post(
                f"{self.base_url}/tools/query_database",
                json={"query": sql}
            ) as resp:
                data = await resp.json()
                if data.get("status") == "success":
                    return data["data"]
                raise RuntimeError(data.get("message", "MCP query failed"))


class MLFFAgent(BaseAgent):
    def __init__(
        self,
        agent_card: MLFFAgentCard,
        communication_bus: CommunicationBus,
        registry: CapabilityRegistry,
        context_manager: ContextManager,
        mcp_client: Optional[MCPServerClient] = None,
    ):
        super().__init__(agent_card, communication_bus, registry, context_manager)
        self.mcp_client = mcp_client or MCPServerClient()
        self.schema = self._load_schema()
        self.model = create_local_model(**settings.model.as_config_dict())
        # self.model = create_local_model(
        #     model_name=settings.model.model_name,
        #     base_url=settings.model.base_url,
        #     api_key=settings.model.api_key,
        #     temperature=settings.model.temperature,
        #     max_tokens=settings.model.max_tokens,
        # )

    def build_llm_agent(self):
        # Not used for direct process_query; we use the model manually.
        return None

    async def process(self, message):
        return None

    async def process_query(self, user_query: str) -> Dict[str, Any]:
        """Generate SQL, execute, and return result with chart."""
        sql = await self._generate_sql(user_query)
        if not sql:
            return {"text": "I couldn't turn that into a valid SQL query.", "chart": None}

        # Basic safety: only allow SELECT on the allowed tables
        if not self._is_allowed(sql):
            return {"text": "The query would access tables outside my scope.", "chart": None}

        data = await self.mcp_client.query(sql)
        chart = self._generate_chart(data, user_query)
        text = f"Here are the results for *{user_query}*."
        return {"text": text, "chart": chart, "data": data}

    def _load_schema(self) -> Dict:
        schema_path = Path(settings.mlff_agent.schema_file)
        if not schema_path.exists():
            logger.warning(f"MLFF schema file not found: {schema_path}")
            return {"tables": []}
        with open(schema_path) as f:
            return json.load(f)

    async def _generate_sql(self, user_query: str) -> Optional[str]:
        """Use the local LLM to create a SQL query."""
        table_info = ""
        for table in self.schema.get("tables", []):
            cols = ", ".join(table["columns"])
            table_info += f"Table: {table['name']} ({cols})\n"

        prompt = f"""
You are an SQL expert. Only use the tables and columns listed below.
{self.schema.get('description', '')}

{table_info}

Write a SELECT query to answer the following question:
"{user_query}"

Return only the SQL query, no explanation. Do not use any tables not listed.
"""
        response = await self._call_llm(prompt)
        sql = response.strip().strip("```sql").strip("```").strip()
        if sql.upper().startswith("SELECT"):
            return sql
        logger.warning(f"LLM returned non-SELECT: {sql}")
        return None

    async def _call_llm(self, prompt: str) -> str:
        """Call the local model using the LocalOpenAIModel."""
        from google.adk.models.llm_request import LlmRequest
        from google.genai.types import Content, Part
        # Build a minimal request
        content = Content(parts=[Part(text=prompt)], role="user")
        request = LlmRequest(contents=[content])
        response = await self.model.generate_content_async(request)
        # Extract the first candidate text
        if response.response and response.response.candidates:
            candidate = response.response.candidates[0]
            for part in candidate.content.parts:
                if hasattr(part, "text"):
                    return part.text
        return ""

    def _is_allowed(self, sql: str) -> bool:
        """Check that the SQL uses only tables from the schema."""
        allowed_tables = {t["name"].lower() for t in self.schema.get("tables", [])}
        # Very crude check – just look for FROM/JOIN clauses
        import re
        tables_used = set(re.findall(r'\bFROM\s+(\w+)', sql, re.IGNORECASE))
        tables_used.update(re.findall(r'\bJOIN\s+(\w+)', sql, re.IGNORECASE))
        return tables_used.issubset(allowed_tables)

    def _generate_chart(self, data: List[Dict], title: str) -> Optional[Dict]:
        if not data or len(data) == 0:
            return None
        try:
            import plotly.graph_objects as go
            keys = list(data[0].keys())
            x = [row[keys[0]] for row in data]
            y = [row[keys[1]] for row in data]

            fig = go.Figure(data=[go.Bar(x=x, y=y)])
            fig.update_layout(title=title)
            return fig.to_dict()
        except ImportError:
            logger.warning("plotly not installed; skipping chart")
            return None
