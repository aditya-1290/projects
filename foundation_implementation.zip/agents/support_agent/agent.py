"""
SupportAgent – matches user queries to predefined SQL files using keywords,
executes them via MCP server, and returns results with a Plotly chart.
"""

import os
import re
import logging
from typing import Dict, Any, Optional, List
from pathlib import Path

from agents.base_agent import BaseAgent
from agents.support_agent.adk_agent_card import SupportAgentCard
from core.communication_bus import CommunicationBus
from core.capability_registry import CapabilityRegistry
from core.context_manager import ContextManager
from config.settings import settings

logger = logging.getLogger(__name__)

# Placeholder for MCP client – we'll inject a callable later
class MCPServerClient:
    """Thin wrapper around the PostgreSQL MCP server."""
    def __init__(self, base_url: str = "http://localhost:8001"):
        self.base_url = base_url

    async def query(self, sql: str) -> List[Dict]:
        """Send a query to the MCP server (using its REST endpoint)."""
        import aiohttp
        async with aiohttp.ClientSession() as session:
            async with session.post(
                f"{self.base_url}/tools/query_database",
                json={"query": sql}
            ) as resp:
                data = await resp.json()
                if data.get("status") == "success":
                    return data["data"]
                raise RuntimeError(data.get("message", "MCP query failed"))


class SupportAgent(BaseAgent):
    def __init__(
        self,
        agent_card: SupportAgentCard,
        communication_bus: CommunicationBus,
        registry: CapabilityRegistry,
        context_manager: ContextManager,
        mcp_client: Optional[MCPServerClient] = None,
    ):
        super().__init__(agent_card, communication_bus, registry, context_manager)
        self.mcp_client = mcp_client or MCPServerClient()
        self.predefined_queries = self._load_queries()

    def build_llm_agent(self):
        # SupportAgent doesn't need an LLM for its primary job;
        # it can have a lightweight LLM for generating explanations if desired.
        return None

    async def process(self, message):
        # Not used by this agent (routed via process_query)
        return None

    async def process_query(self, user_query: str) -> Dict[str, Any]:
        """
        Check if any predefined query matches the user's query.
        Returns:
            {"matched": True, "text": ..., "chart": <plotly_json>} if matched,
            {"matched": False} otherwise.
        """
        query_lower = user_query.lower()
        for pq in self.predefined_queries:
            if any(kw in query_lower for kw in pq["keywords"]):
                logger.info(f"Matched predefined query: {pq['name']}")
                data = await self.mcp_client.query(pq["sql"])
                chart = self._generate_chart(data, pq["name"])
                text = f"Here is the result for *{pq['description']}*."
                return {"matched": True, "text": text, "chart": chart, "data": data}
        return {"matched": False}

    def _load_queries(self) -> List[Dict]:
        """Parse all .sql files in the predefined queries directory."""
        queries = []
        sql_dir = Path(settings.support_agent.predefined_sql_dir)
        if not sql_dir.exists():
            logger.warning(f"Predefined SQL directory not found: {sql_dir}")
            return queries

        for file_path in sql_dir.glob("*.sql"):
            with open(file_path, "r") as f:
                content = f.read()
            meta = self._parse_header(content)
            if meta:
                meta["file"] = file_path.name
                queries.append(meta)
        logger.info(f"Loaded {len(queries)} predefined queries.")
        return queries

    def _parse_header(self, content: str) -> Optional[Dict]:
        """Extract name, description, keywords, and SQL from a .sql file."""
        lines = content.splitlines()
        name = desc = ""
        keywords = []
        sql_start = 0
        for i, line in enumerate(lines):
            if line.startswith("-- Name:"):
                name = line.split(":", 1)[1].strip()
            elif line.startswith("-- Description:"):
                desc = line.split(":", 1)[1].strip()
            elif line.startswith("-- Keywords:"):
                kw_str = line.split(":", 1)[1].strip()
                keywords = [k.strip().lower() for k in kw_str.split(",") if k.strip()]
            elif not line.startswith("--") and line.strip():
                sql_start = i
                break
        sql = "\n".join(lines[sql_start:]).strip()
        if not name or not sql:
            return None
        return {"name": name, "description": desc, "keywords": keywords, "sql": sql}

    def _generate_chart(self, data: List[Dict], name: str) -> Optional[Dict]:
        """Create a Plotly bar/line chart based on the first two columns."""
        if not data or len(data) == 0:
            return None
        try:
            import plotly.graph_objects as go
            keys = list(data[0].keys())
            x = [row[keys[0]] for row in data]
            y = [row[keys[1]] for row in data]

            # Choose chart type – simple bar for now
            fig = go.Figure(data=[go.Bar(x=x, y=y)])
            fig.update_layout(title=name.replace("_", " ").title())
            return fig.to_dict()
        except ImportError:
            logger.warning("plotly not installed; skipping chart")
            return None
