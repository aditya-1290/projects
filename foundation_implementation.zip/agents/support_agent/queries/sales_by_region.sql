-- Name: sales_by_region
-- Description: Total sales amount grouped by region.
-- Keywords: sales, region, revenue, location, total
SELECT region, SUM(amount) AS total_sales
FROM sales
GROUP BY region
ORDER BY total_sales DESC;
