from dataclasses import dataclass, field
from core.agent_card import ADKAgentCard, Capability

@dataclass
class SupportAgentCard(ADKAgentCard):
    agent_type: str = "support"
    display_name: str = "Support Agent"
    description: str = "Answers queries using predefined SQL queries."
    capabilities: list = field(default_factory=lambda: [
        Capability(
            name="predefined_query",
            description="Fetches data using stored SQL queries when keywords match.",
            tags=["support", "predefined"]
        )
    ])
