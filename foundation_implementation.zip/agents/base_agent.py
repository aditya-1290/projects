import re
import logging
from abc import abstractmethod
from typing import Any, Dict, List, Optional

from google.adk.agents import BaseAgent as AdkBaseAgent

from core.agent_card import ADKAgentCard, AgentStatus
from core.a2a_protocol import A2AMessage, MessageType
from core.communication_bus import CommunicationBus
from core.capability_registry import CapabilityRegistry
from core.context_manager import ContextManager
from core.errors import RegistrationError

logger = logging.getLogger(__name__)


class BaseAgent(AdkBaseAgent):
    """Abstract base for all agents. Inherits ADK's BaseAgent but allows extra fields."""

    model_config = {"extra": "allow"}   # allows card, bus, registry, etc.

    def __init__(
        self,
        agent_card: ADKAgentCard,
        communication_bus: CommunicationBus,
        registry: CapabilityRegistry,
        context_manager: ContextManager,
        name: Optional[str] = None,
        **kwargs,
    ):
        # Sanitize name to a valid Python identifier
        if name:
            safe_name = name
        else:
            raw = agent_card.display_name.strip() or agent_card.agent_id
            safe_name = re.sub(r'[^a-zA-Z0-9_]', '_', raw)
            if not safe_name[0].isalpha():
                safe_name = 'agent_' + safe_name
            safe_name = safe_name[:50]

        super().__init__(name=safe_name, **kwargs)

        # Custom attributes (allowed by model_config extra=allow)
        self.card = agent_card
        self.bus = communication_bus
        self.registry = registry
        self.context_manager = context_manager

        self.state: Dict[str, Any] = {}
        self._conversation_history: List[A2AMessage] = []

    # ── Lifecycle (ADK‑compatible) ─────────────────────────
    async def initialize(self) -> None:
        """Register with CapabilityRegistry and subscribe to bus."""
        try:
            await self.registry.register(self.card)
            await self.bus.subscribe(
                agent_id=self.card.agent_id,
                tenant_id=self.card.tenant_id,
                callback=self._handle_message,
            )
            self.card.status = AgentStatus.READY
            logger.info(f"Agent {self.card.display_name} initialized")
        except Exception as e:
            self.card.status = AgentStatus.DEGRADED
            raise RegistrationError(f"Failed to initialize agent: {e}")

    async def shutdown(self) -> None:
        self.card.status = AgentStatus.TERMINATING
        await self.bus.unsubscribe(self.card.agent_id, self.card.tenant_id)
        await self.registry.unregister(self.card.agent_id, self.card.tenant_id)

    # ADK’s required async run method (can be overridden)
    async def _run_async_impl(self, ctx) -> None:
        """Default ADK runner entry point. Subclasses can override."""
        pass

    # ── Bus message handling ───────────────────────────────
    async def _handle_message(self, message: A2AMessage) -> Optional[A2AMessage]:
        return await self.process(message)

    @abstractmethod
    async def process(self, message: A2AMessage) -> Optional[A2AMessage]:
        """Process a bus message (abstract)."""
        pass

    @abstractmethod
    async def process_query(self, user_query: str) -> Dict[str, Any]:
        """Process a user query directly (called by QueryRouter)."""
        pass
