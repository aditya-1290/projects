"""
FasTag Multi‑Agents – Start the FastAPI server.
"""
import uvicorn
from api.main import app
from config.settings import settings

if __name__ == "__main__":
    uvicorn.run(
        "api.main:app",
        host="127.0.0.1",
        port=8000,
        reload=True,
    )
