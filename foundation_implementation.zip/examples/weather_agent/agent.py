"""
Weather Agent – Provides weather information.
Demonstrates a simple agent using the base infrastructure.
"""

from typing import Optional
from google.adk.agents import LlmAgent
from google.adk.tools import FunctionTool

from core.a2a_protocol import A2AMessage, MessageType
from core.communication_bus import CommunicationBus
from core.capability_registry import CapabilityRegistry
from core.context_manager import ContextManager
from agents.base_agent import BaseAgent
from examples.weather_agent.adk_agent_card import WeatherAgentCard
from examples.weather_agent.tools import WeatherTools

class WeatherAgent(BaseAgent):
    def __init__(self, agent_card: WeatherAgentCard, communication_bus: CommunicationBus,
                 registry: CapabilityRegistry, context_manager: ContextManager):
        super().__init__(agent_card, communication_bus, registry, context_manager)
        self.tools = WeatherTools()

    def build_llm_agent(self) -> LlmAgent:
        return LlmAgent(
            name=self.card.agent_id,
            model="gemini-2.0-flash",
            instruction="You are a weather agent. Use the get_weather tool to answer weather queries.",
            tools=[FunctionTool(self.tools.get_weather)]
        )

    async def process(self, message: A2AMessage) -> Optional[A2AMessage]:
        if message.message_type != MessageType.REQUEST:
            return None

        location = message.payload.get("location", "")
        units = message.payload.get("units", "metric")
        if not location:
            return A2AMessage(
                tenant_id=self.card.tenant_id,
                message_type=MessageType.ERROR,
                sender_id=self.card.agent_id,
                correlation_id=message.message_id,
                payload={"error": "location is required"}
            )

        weather_data = await self.tools.get_weather(location, units)
        return A2AMessage(
            tenant_id=self.card.tenant_id,
            message_type=MessageType.RESPONSE,
            sender_id=self.card.agent_id,
            correlation_id=message.message_id,
            payload=weather_data
        )
