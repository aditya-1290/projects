"""Mock weather tools (replace with real API in production)."""
import random

class WeatherTools:
    async def get_weather(self, location: str, units: str = "metric") -> dict:
        # Mock implementation
        conditions = ["sunny", "cloudy", "rainy", "partly cloudy"]
        return {
            "location": location,
            "temperature": random.randint(-5, 40) if units == "metric" else random.randint(20, 100),
            "conditions": random.choice(conditions),
            "humidity": random.randint(30, 90),
            "units": units
        }
