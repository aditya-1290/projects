from dataclasses import dataclass, field
from core.agent_card import ADKAgentCard, Capability

@dataclass
class WeatherAgentCard(ADKAgentCard):
    agent_type: str = "tool"
    display_name: str = "Weather Agent"
    description: str = "Provides weather information for locations worldwide."
    capabilities: list = field(default_factory=lambda: [
        Capability(
            name="weather_query",
            description="Fetches current weather and forecasts for a city.",
            input_schema={
                "type": "object",
                "properties": {
                    "location": {"type": "string"},
                    "units": {"type": "string", "enum": ["metric", "imperial"]}
                },
                "required": ["location"]
            },
            output_schema={
                "type": "object",
                "properties": {
                    "temperature": {"type": "number"},
                    "conditions": {"type": "string"},
                    "humidity": {"type": "number"}
                }
            },
            tags=["weather", "forecast"]
        )
    ])
