"""
Common utilities used across the project.
"""
import uuid
import json
from datetime import datetime, timezone
from typing import Any, Dict


class IDGenerator:
    @staticmethod
    def new_id() -> str:
        return str(uuid.uuid4())

    @staticmethod
    def new_trace_id() -> str:
        return str(uuid.uuid4())


class JSONSerializer:
    @staticmethod
    def serialize(obj: Any) -> str:
        return json.dumps(obj, default=str, indent=2)

    @staticmethod
    def deserialize(json_str: str) -> Any:
        return json.loads(json_str)


class TimeUtils:
    @staticmethod
    def utc_now() -> datetime:
        return datetime.now(timezone.utc)

    @staticmethod
    def format_iso(dt: datetime) -> str:
        return dt.isoformat()
    