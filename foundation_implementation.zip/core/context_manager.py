"""
Context Manager - Shared session state across agents.

Design:
- Abstract ContextStore backend with a default in-memory implementation.
- ContextManager wraps the store and adds session lifecycle (create, expire).
- Pluggable: swap InMemoryContextStore for Redis/DB later without changing agent code.
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional
from datetime import datetime, timezone
import uuid
import logging

logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────
# Abstract Store Interface
# ──────────────────────────────────────────────────────────────

class ContextStore(ABC):
    """Abstract backend for session/context storage."""

    @abstractmethod
    async def get(self, tenant_id: str, session_id: str, key: str) -> Optional[Any]:
        """Retrieve a value from a session."""
        pass

    @abstractmethod
    async def set(self, tenant_id: str, session_id: str, key: str, value: Any) -> None:
        """Store a value in a session."""
        pass

    @abstractmethod
    async def delete(self, tenant_id: str, session_id: str, key: str) -> None:
        """Remove a key from a session."""
        pass

    @abstractmethod
    async def get_all(self, tenant_id: str, session_id: str) -> Dict[str, Any]:
        """Get all keys for a session."""
        pass

    @abstractmethod
    async def clear(self, tenant_id: str, session_id: str) -> None:
        """Remove all data for a session."""
        pass


# ──────────────────────────────────────────────────────────────
# In-Memory Implementation (Default)
# ──────────────────────────────────────────────────────────────

class InMemoryContextStore(ContextStore):
    """Default in-memory store for single-process use."""

    def __init__(self):
        # tenant_id -> session_id -> {key: value}
        self._store: Dict[str, Dict[str, Dict[str, Any]]] = {}

    async def get(self, tenant_id: str, session_id: str, key: str) -> Optional[Any]:
        return self._store.get(tenant_id, {}).get(session_id, {}).get(key)

    async def set(self, tenant_id: str, session_id: str, key: str, value: Any) -> None:
        self._store.setdefault(tenant_id, {}).setdefault(session_id, {})[key] = value

    async def delete(self, tenant_id: str, session_id: str, key: str) -> None:
        session_data = self._store.get(tenant_id, {}).get(session_id, {})
        if key in session_data:
            del session_data[key]

    async def get_all(self, tenant_id: str, session_id: str) -> Dict[str, Any]:
        return dict(self._store.get(tenant_id, {}).get(session_id, {}))

    async def clear(self, tenant_id: str, session_id: str) -> None:
        if tenant_id in self._store and session_id in self._store[tenant_id]:
            del self._store[tenant_id][session_id]


# ──────────────────────────────────────────────────────────────
# Context Manager (Session Lifecycle)
# ──────────────────────────────────────────────────────────────

class ContextManager:
    """
    Manages shared context across multi-agent interactions.
    Uses a pluggable ContextStore for persistence.
    """

    def __init__(self, store: Optional[ContextStore] = None):
        self._store = store or InMemoryContextStore()

    async def create_session(self, tenant_id: str, metadata: Optional[Dict] = None) -> str:
        """Create a new session and return its ID."""
        session_id = str(uuid.uuid4())
        await self._store.set(tenant_id, session_id, "_metadata", {
            "created_at": datetime.now(timezone.utc).isoformat(),
            "metadata": metadata or {},
        })
        logger.info(f"Session {session_id} created for tenant {tenant_id}")
        return session_id

    async def get(self, tenant_id: str, session_id: str, key: str) -> Optional[Any]:
        return await self._store.get(tenant_id, session_id, key)

    async def set(self, tenant_id: str, session_id: str, key: str, value: Any) -> None:
        await self._store.set(tenant_id, session_id, key, value)

    async def delete(self, tenant_id: str, session_id: str, key: str) -> None:
        await self._store.delete(tenant_id, session_id, key)

    async def get_all(self, tenant_id: str, session_id: str) -> Dict[str, Any]:
        data = await self._store.get_all(tenant_id, session_id)
        # Filter internal metadata
        return {k: v for k, v in data.items() if not k.startswith("_")}

    async def get_history(self, tenant_id: str, session_id: str) -> list:
        """Retrieve conversation history (if stored)."""
        return await self._store.get(tenant_id, session_id, "_history") or []

    async def add_to_history(self, tenant_id: str, session_id: str, message: Any) -> None:
        """Append a message to the conversation history."""
        history = await self.get_history(tenant_id, session_id)
        history.append(message)
        await self._store.set(tenant_id, session_id, "_history", history)

    async def clear(self, tenant_id: str, session_id: str) -> None:
        await self._store.clear(tenant_id, session_id)
