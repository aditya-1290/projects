"""
Capability Registry - Tenant-isolated agent discovery.
Agents register their ADKAgentCard, and the orchestrator queries
to find agents with specific capabilities.
"""

import logging
from typing import Dict, List, Optional, Set
from collections import defaultdict
from datetime import datetime, timezone

from core.agent_card import ADKAgentCard, Capability, AgentStatus
from core.errors import AgentNotFoundError, CapabilityNotFoundError, TenantIsolationError

logger = logging.getLogger(__name__)


class CapabilityRegistry:
    """
    In-memory registry of agent capabilities.
    Scoped by tenant_id: agents in different tenants are completely isolated.
    """

    def __init__(self):
        # tenant_id -> agent_id -> ADKAgentCard
        self._agents: Dict[str, Dict[str, ADKAgentCard]] = defaultdict(dict)
        # tenant_id -> capability_name -> set of agent_ids
        self._capability_index: Dict[str, Dict[str, Set[str]]] = defaultdict(lambda: defaultdict(set))

    # ── Registration ───────────────────────────────────────

    async def register(self, agent_card: ADKAgentCard) -> None:
        """
        Register or update an agent in the registry.
        Must be called when an agent starts or its capabilities change.
        """
        tenant = agent_card.tenant_id
        agent_id = agent_card.agent_id

        # Remove old capability index entries if updating
        if agent_id in self._agents[tenant]:
            old_card = self._agents[tenant][agent_id]
            for cap in old_card.capabilities:
                self._capability_index[tenant][cap.name].discard(agent_id)

        # Store the card
        self._agents[tenant][agent_id] = agent_card
        agent_card.status = AgentStatus.READY
        agent_card.last_heartbeat = datetime.now(timezone.utc)

        # Rebuild capability index
        for cap in agent_card.capabilities:
            self._capability_index[tenant][cap.name].add(agent_id)

        logger.info(f"Agent {agent_id} registered in tenant {tenant} with "
                    f"capabilities: {[c.name for c in agent_card.capabilities]}")

    async def unregister(self, agent_id: str, tenant_id: str) -> None:
        """
        Remove an agent from the registry.
        Called on graceful shutdown or health check failure.
        """
        if tenant_id not in self._agents or agent_id not in self._agents[tenant_id]:
            logger.warning(f"Attempt to unregister unknown agent {agent_id} in tenant {tenant_id}")
            return

        # Remove from capability index
        old_card = self._agents[tenant_id][agent_id]
        for cap in old_card.capabilities:
            self._capability_index[tenant_id][cap.name].discard(agent_id)

        # Remove the agent
        del self._agents[tenant_id][agent_id]
        logger.info(f"Agent {agent_id} unregistered from tenant {tenant_id}")

    # ── Discovery ──────────────────────────────────────────

    async def find_by_capability(
            self,
            capability_name: str,
            tenant_id: str,
            only_available: bool = True
    ) -> List[ADKAgentCard]:
        """
        Find all agents that implement a given capability within a tenant.

        Args:
            capability_name: The name of the capability (e.g., "weather_query").
            tenant_id: Tenant scope.
            only_available: If True, only return agents with status READY.

        Returns:
            List of matching agent cards.

        Raises:
            CapabilityNotFoundError: If no agents match the capability.
        """
        self._validate_tenant(tenant_id)

        agent_ids = self._capability_index.get(tenant_id, {}).get(capability_name, set())
        if not agent_ids:
            raise CapabilityNotFoundError(
                f"No agents with capability '{capability_name}' in tenant '{tenant_id}'"
            )

        matching = []
        for aid in agent_ids:
            card = self._agents[tenant_id].get(aid)
            if card and (not only_available or card.is_available()):
                matching.append(card)

        if not matching and only_available:
            raise CapabilityNotFoundError(
                f"Found agents with '{capability_name}' but none are READY."
            )

        return matching

    async def find_by_intent(
            self,
            intent: str,
            tenant_id: str,
            only_available: bool = True
    ) -> List[ADKAgentCard]:
        """
        Find agents whose capability names or tags match the intent.
        This is a high-level discovery method the orchestrator can use.
        """
        # Direct capability match first
        try:
            return await self.find_by_capability(intent, tenant_id, only_available)
        except CapabilityNotFoundError:
            pass

        # If not found, search by tags
        matching = []
        for agent_id, card in self._agents.get(tenant_id, {}).items():
            if only_available and not card.is_available():
                continue
            for cap in card.capabilities:
                if intent in cap.tags:
                    matching.append(card)
                    break

        if not matching:
            raise CapabilityNotFoundError(
                f"No agents found for intent '{intent}' in tenant '{tenant_id}'"
            )

        return matching

    async def get_agent(self, agent_id: str, tenant_id: str) -> ADKAgentCard:
        """
        Retrieve a specific agent's card.

        Raises:
            AgentNotFoundError: If agent not found.
        """
        self._validate_tenant(tenant_id)
        card = self._agents.get(tenant_id, {}).get(agent_id)
        if not card:
            raise AgentNotFoundError(
                f"Agent '{agent_id}' not found in tenant '{tenant_id}'"
            )
        return card

    async def list_agents(self, tenant_id: str) -> List[ADKAgentCard]:
        """List all agents registered in a tenant."""
        self._validate_tenant(tenant_id)
        return list(self._agents.get(tenant_id, {}).values())

    async def heartbeat(self, agent_id: str, tenant_id: str) -> None:
        """
        Update the last_heartbeat timestamp for an agent.
        Used by health-check mechanisms.
        """
        card = await self.get_agent(agent_id, tenant_id)
        card.last_heartbeat = datetime.now(timezone.utc)

    async def update_status(self, agent_id: str, tenant_id: str, status: AgentStatus) -> None:
        """Change an agent's lifecycle status."""
        card = await self.get_agent(agent_id, tenant_id)
        card.status = status
        logger.info(f"Agent {agent_id} status → {status.value}")

    # ── Helpers ────────────────────────────────────────────

    def _validate_tenant(self, tenant_id: str) -> None:
        """Placeholder for tenant validation logic."""
        # In a production system, this would verify the tenant exists and is active.
        pass

    def get_capability_schema(self, capability_name: str, tenant_id: str) -> Optional[dict]:
        """
        Attempt to retrieve the capability schema from the first agent that implements it.
        For a real system, we'd reference the centralized schemas/ directory.
        """
        try:
            agents = self._agents.get(tenant_id, {})
            for agent in agents.values():
                for cap in agent.capabilities:
                    if cap.name == capability_name:
                        return {
                            "input": cap.input_schema,
                            "output": cap.output_schema,
                            "schema_ref": cap.schema_ref
                        }
        except Exception:
            pass
        return None
