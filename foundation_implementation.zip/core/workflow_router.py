"""
Workflow Router – Implements the decision logic for query handling.
- Checks recent query cache (SQLite)
- Routes to SupportAgent if predefined query matches
- Routes to MLFFAgent otherwise
- If user manually selected an agent, bypasses routing and goes directly to that agent
"""

from typing import Optional, Dict, Any
from core.capability_registry import CapabilityRegistry
from core.communication_bus import CommunicationBus
from core.context_manager import ContextManager
from cache.recent_queries import RecentQueriesCache
from agents.base_agent import BaseAgent
from config.settings import settings


class QueryRouter:
    def __init__(
        self,
        bus: CommunicationBus,
        registry: CapabilityRegistry,
        context_manager: ContextManager,
        cache: RecentQueriesCache,
        support_agent: BaseAgent,
        mlff_agent: BaseAgent,
    ):
        self.bus = bus
        self.registry = registry
        self.context_manager = context_manager
        self.cache = cache
        self.support_agent = support_agent
        self.mlff_agent = mlff_agent

    async def route(
        self,
        user_query: str,
        session_id: str,
        selected_agent: Optional[str] = None,   # "support", "mlff", or None (auto)
    ) -> Dict[str, Any]:
        """
        Main entry point for a user query.
        Returns a dict with:
            - text: str (response message)
            - chart: Optional[dict] (Plotly JSON)
        """
        # 1. Check recent queries cache
        cached = self.cache.get(user_query, selected_agent)
        if cached and not selected_agent:
            # In auto mode, use cached result regardless of original agent
            return self._format_response(cached["result_data"])
        elif cached and selected_agent and cached["agent_used"] == selected_agent:
            return self._format_response(cached["result_data"])

        # 2. If a specific agent is selected, go directly to it
        if selected_agent:
            agent = self._get_agent_by_name(selected_agent)
            if agent is None:
                return {"text": f"Agent '{selected_agent}' not found.", "chart": None}
            result = await agent.process_query(user_query)
            self.cache.set(user_query, selected_agent, result)
            return self._format_response(result)

        # 3. Auto mode – check SupportAgent predefined queries first
        support_result = await self.support_agent.process_query(user_query)
        if support_result.get("matched"):
            self.cache.set(user_query, "support", support_result)
            return self._format_response(support_result)

        # 4. Fallback to MLFFAgent
        mlff_result = await self.mlff_agent.process_query(user_query)
        self.cache.set(user_query, "mlff", mlff_result)
        return self._format_response(mlff_result)

    def _get_agent_by_name(self, name: str) -> Optional[BaseAgent]:
        if name == "support":
            return self.support_agent
        elif name == "mlff":
            return self.mlff_agent
        return None

    def _format_response(self, data: dict) -> dict:
        return {
            "text": data.get("text", "Here is what I found."),
            "chart": data.get("chart"),   # Plotly JSON or None
        }
