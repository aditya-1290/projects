"""
Observability – Structured logging, tracing, and metrics hooks.
Uses Python logging and a simple trace context for now.
Replace with OpenTelemetry for production.
"""

import logging
import time
from contextvars import ContextVar
from typing import Optional, Dict, Any

# Trace context (correlation ID) shared across async calls
_trace_id: ContextVar[Optional[str]] = ContextVar("trace_id", default=None)


class TraceContext:
    @staticmethod
    def set_trace_id(trace_id: str):
        _trace_id.set(trace_id)

    @staticmethod
    def get_trace_id() -> Optional[str]:
        return _trace_id.get()

    @staticmethod
    def clear():
        _trace_id.set(None)


class AgentLogger:
    """Logger wrapper that automatically includes trace_id."""

    def __init__(self, name: str):
        self._logger = logging.getLogger(name)

    def _format_msg(self, msg: str) -> str:
        trace_id = _trace_id.get()
        if trace_id:
            return f"[trace={trace_id}] {msg}"
        return msg

    def info(self, msg, *args, **kwargs):
        self._logger.info(self._format_msg(msg), *args, **kwargs)

    def warning(self, msg, *args, **kwargs):
        self._logger.warning(self._format_msg(msg), *args, **kwargs)

    def error(self, msg, *args, **kwargs):
        self._logger.error(self._format_msg(msg), *args, **kwargs)

    def debug(self, msg, *args, **kwargs):
        self._logger.debug(self._format_msg(msg), *args, **kwargs)


class MetricsCollector:
    """Simple in-memory metrics collector (replace with Prometheus client)."""

    def __init__(self):
        self.counters: Dict[str, int] = {}
        self.timings: Dict[str, list] = {}

    def increment(self, name: str, value: int = 1):
        self.counters[name] = self.counters.get(name, 0) + value

    def record_timing(self, name: str, duration_ms: float):
        self.timings.setdefault(name, []).append(duration_ms)

    def get_metrics(self) -> Dict[str, Any]:
        avg_timings = {k: sum(v) / len(v) for k, v in self.timings.items() if v}
        return {
            "counters": dict(self.counters),
            "avg_timings_ms": avg_timings
        }
