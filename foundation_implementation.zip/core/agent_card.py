"""
Base ADKAgentCard dataclass.
Every agent has a card that describes its identity, capabilities,
and runtime metadata. The CapabilityRegistry uses this to discover agents.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from enum import Enum
from datetime import datetime, timezone
import uuid


class AgentStatus(Enum):
    """Current lifecycle status of an agent."""
    INITIALIZING = "initializing"
    READY = "ready"
    BUSY = "busy"
    DEGRADED = "degraded"
    PAUSED = "paused"
    TERMINATING = "terminating"


@dataclass
class Capability:
    """
    Describes a single capability an agent provides.
    References a centralized schema in schemas/capabilities/.
    """
    name: str  # e.g., "weather_query"
    description: str  # Human-readable description
    schema_ref: Optional[str] = None  # Path to JSON Schema file (optional)
    input_schema: Optional[Dict[str, Any]] = None  # Inline schema if no ref
    output_schema: Optional[Dict[str, Any]] = None
    version: str = "1.0.0"
    examples: List[Dict[str, Any]] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)


@dataclass
class ADKAgentCard:
    """
    Identity card for an agent. All agents must provide this metadata.
    Extended by agent-specific cards (e.g., OrchestratorAgentCard).
    """
    agent_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    tenant_id: str = ""  # Tenant isolation key
    agent_type: str = ""  # "orchestrator", "tool", "lmm", etc.
    display_name: str = ""
    description: str = ""

    # Capabilities this agent implements
    capabilities: List[Capability] = field(default_factory=list)

    # Lifecycle
    status: AgentStatus = AgentStatus.INITIALIZING

    # Communication endpoints (for distributed deployment)
    endpoints: Dict[str, str] = field(default_factory=dict)  # {"grpc": "...", "http": "..."}

    # Performance / SLA
    max_concurrent_requests: int = 5
    average_response_time_ms: int = 1000
    rate_limits: Dict[str, int] = field(default_factory=dict)

    # Version & metadata
    version: str = "1.0.0"
    metadata: Dict[str, Any] = field(default_factory=dict)
    registered_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    last_heartbeat: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    # Authentication
    auth_required: bool = False
    auth_config: Optional[Dict[str, Any]] = None

    def is_available(self) -> bool:
        """Check if agent is ready to accept work."""
        return self.status == AgentStatus.READY
