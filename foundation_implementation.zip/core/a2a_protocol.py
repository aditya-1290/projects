"""
A2A Protocol - Standard message format for agent-to-agent communication.
Uses JSON for debuggability and a Python dataclass for type safety.
"""

from dataclasses import dataclass, field
from typing import Optional, Dict, Any
from enum import Enum
from datetime import datetime, timezone
import uuid


class MessageType(Enum):
    """Types of messages in the A2A protocol."""
    REQUEST = "request"             # A request to perform an action
    RESPONSE = "response"           # A successful response to a request
    EVENT = "event"                 # A notification/event (no response expected)
    ERROR = "error"                 # An error response
    HEARTBEAT = "heartbeat"         # Liveness ping
    REGISTER = "register"           # Agent registration announcement
    UNREGISTER = "unregister"       # Agent deregistration
    CAPABILITY_QUERY = "capability_query"  # Query against the registry


class Priority(Enum):
    """Message priority levels."""
    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class A2AMessage:
    """
    Standard message envelope for all inter-agent communication.
    Tenant isolation is enforced via tenant_id.
    """
    message_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    correlation_id: Optional[str] = None   # Links request-response pairs
    tenant_id: str = ""                     # Tenant isolation boundary
    message_type: MessageType = MessageType.EVENT

    # Addressing
    sender_id: str = ""
    recipient_id: Optional[str] = None      # None for broadcast
    reply_to: Optional[str] = None          # Queue/topic to reply to

    # Content
    intent: Optional[str] = None            # High-level intent (e.g., "weather_query")
    payload: Dict[str, Any] = field(default_factory=dict)
    context: Optional[Dict[str, Any]] = None  # Shared context snapshot

    # Metadata
    priority: Priority = Priority.NORMAL
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    expires_at: Optional[datetime] = None
    headers: Dict[str, str] = field(default_factory=dict)

    # Security & Observability
    auth_token: Optional[str] = None
    trace_id: Optional[str] = field(default_factory=lambda: str(uuid.uuid4()))

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary (JSON compatible)."""
        return {
            "message_id": self.message_id,
            "correlation_id": self.correlation_id,
            "tenant_id": self.tenant_id,
            "message_type": self.message_type.value,
            "sender_id": self.sender_id,
            "recipient_id": self.recipient_id,
            "reply_to": self.reply_to,
            "intent": self.intent,
            "payload": self.payload,
            "context": self.context,
            "priority": self.priority.value,
            "timestamp": self.timestamp.isoformat(),
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
            "headers": self.headers,
            "auth_token": self.auth_token,
            "trace_id": self.trace_id,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "A2AMessage":
        """Deserialize from dictionary."""
        return cls(
            message_id=data["message_id"],
            correlation_id=data.get("correlation_id"),
            tenant_id=data["tenant_id"],
            message_type=MessageType(data["message_type"]),
            sender_id=data["sender_id"],
            recipient_id=data.get("recipient_id"),
            reply_to=data.get("reply_to"),
            intent=data.get("intent"),
            payload=data.get("payload", {}),
            context=data.get("context"),
            priority=Priority(data.get("priority", "normal")),
            timestamp=datetime.fromisoformat(data["timestamp"]),
            expires_at=datetime.fromisoformat(data["expires_at"]) if data.get("expires_at") else None,
            headers=data.get("headers", {}),
            auth_token=data.get("auth_token"),
            trace_id=data.get("trace_id"),
        )

    def create_response(self, payload: Dict[str, Any], message_type: MessageType = MessageType.RESPONSE) -> "A2AMessage":
        """Create a response message linked to this request."""
        return A2AMessage(
            correlation_id=self.message_id,
            tenant_id=self.tenant_id,
            message_type=message_type,
            sender_id=self.recipient_id or "unknown",  # Responder becomes sender
            recipient_id=self.sender_id,                # Original sender becomes recipient
            reply_to=self.reply_to,
            intent=self.intent,
            payload=payload,
            context=self.context,
            priority=self.priority,
            trace_id=self.trace_id,
        )

    def is_expired(self) -> bool:
        """Check if the message has expired."""
        if self.expires_at is None:
            return False
        return datetime.now(timezone.utc) > self.expires_at