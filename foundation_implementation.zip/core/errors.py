"""
Custom exceptions for the multi-agent foundation.
"""


class AgentFoundationError(Exception):
    """Base exception for all custom errors."""
    pass


class CommunicationError(AgentFoundationError):
    """Raised when communication fails (timeout, connection lost, etc.)."""
    pass


class MessageTimeoutError(CommunicationError):
    """Request timed out waiting for a response."""
    pass


class AgentNotFoundError(AgentFoundationError):
    """Requested agent not found in the registry."""
    pass


class CapabilityNotFoundError(AgentFoundationError):
    """No agent found with the requested capability."""
    pass


class CapabilityMismatchError(AgentFoundationError):
    """Agent's capability does not match the expected schema."""
    pass


class TenantIsolationError(AgentFoundationError):
    """Attempted cross-tenant communication."""
    pass


class RegistrationError(AgentFoundationError):
    """Agent registration failed."""
    pass


class ConfigurationError(AgentFoundationError):
    """Invalid configuration."""
    pass


class SecurityError(AgentFoundationError):
    """Authentication or authorization failure."""
    pass
