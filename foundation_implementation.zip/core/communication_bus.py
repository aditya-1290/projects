"""
Tenant-Isolated Communication Bus

Provides pub/sub and request/reply messaging patterns.
Enforces strict tenant boundaries: messages are only visible
to agents within the same tenant.

Default implementation is in-memory (single-process).
Replace with Redis/Kafka/etc. for distributed deployments.
"""

import asyncio
import logging
from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Callable, Any
from collections import defaultdict
from datetime import datetime, timezone

from core.a2a_protocol import A2AMessage, MessageType
from core.errors import CommunicationError, MessageTimeoutError, TenantIsolationError

logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────
# Abstract Interface
# ──────────────────────────────────────────────────────────────

class CommunicationBus(ABC):
    """
    Abstract interface for the message bus.
    All methods enforce tenant isolation.
    """

    @abstractmethod
    async def publish(self, message: A2AMessage) -> None:
        """
        Publish a message to the bus.
        The message will be delivered to subscribers within the same tenant.
        """
        pass

    @abstractmethod
    async def subscribe(
            self,
            agent_id: str,
            tenant_id: str,
            callback: Callable[[A2AMessage], Any],
            pattern: Optional[str] = None
    ) -> None:
        """
        Subscribe an agent to receive messages.

        Args:
            agent_id: Unique agent identifier.
            tenant_id: Tenant boundary. Agent only receives messages from this tenant.
            callback: Async or sync function called with each matching message.
            pattern: Optional regex pattern to filter messages by intent or content.
        """
        pass

    @abstractmethod
    async def unsubscribe(self, agent_id: str, tenant_id: str) -> None:
        """Remove an agent's subscriptions."""
        pass

    @abstractmethod
    async def request(self, message: A2AMessage, timeout: int = 30) -> A2AMessage:
        """
        Synchronous request-response pattern.
        Sends a request and waits for a correlated response.

        Args:
            message: The REQUEST message.
            timeout: Seconds to wait before raising MessageTimeoutError.

        Returns:
            The RESPONSE message.

        Raises:
            MessageTimeoutError: If no response arrives within timeout.
        """
        pass

    @abstractmethod
    async def broadcast(self, message: A2AMessage) -> List[A2AMessage]:
        """
        Broadcast to all agents in the same tenant (except sender).
        Returns list of response messages (if any).
        """
        pass


# ──────────────────────────────────────────────────────────────
# In-Memory Implementation
# ──────────────────────────────────────────────────────────────

class InMemoryCommunicationBus(CommunicationBus):
    """
    In-process message bus with tenant isolation.
    Suitable for monolithic deployments and testing.
    """

    def __init__(self):
        # Tenant -> agent_id -> list of callbacks
        self._subscriptions: Dict[str, Dict[str, List[Callable]]] = defaultdict(lambda: defaultdict(list))
        # Tenant -> pattern -> list of callbacks (for regex matching)
        self._pattern_subscriptions: Dict[str, Dict[str, List[Callable]]] = defaultdict(lambda: defaultdict(list))
        # Pending request futures: correlation_id -> asyncio.Future
        self._pending_requests: Dict[str, asyncio.Future] = {}
        # Message history per tenant (for debugging/replay)
        self._message_log: Dict[str, List[A2AMessage]] = defaultdict(list)

        # Lock for thread safety (if needed)
        self._lock = asyncio.Lock()

    # ── Tenant Enforcement ────────────────────────────────

    def _validate_tenant(self, message: A2AMessage, target_tenant: str) -> None:
        """Raise if message tenant doesn't match target tenant."""
        if message.tenant_id != target_tenant:
            raise TenantIsolationError(
                f"Message tenant '{message.tenant_id}' does not match "
                f"target tenant '{target_tenant}'"
            )

    # ── Publish / Subscribe ───────────────────────────────

    async def publish(self, message: A2AMessage) -> None:
        """
        Deliver message to subscribers in the same tenant.
        Non-blocking: returns immediately after dispatching.
        """
        tenant = message.tenant_id

        # Log for audit
        self._message_log[tenant].append(message)

        # Deliver to direct subscriber
        if message.recipient_id:
            callbacks = self._subscriptions[tenant].get(message.recipient_id, [])
            for cb in callbacks:
                await self._invoke_callback(cb, message)

        # Deliver to pattern subscribers
        for pattern, callbacks in self._pattern_subscriptions[tenant].items():
            if self._matches_pattern(message, pattern):
                for cb in callbacks:
                    await self._invoke_callback(cb, message)

        # Handle pending request correlations
        if message.correlation_id and message.correlation_id in self._pending_requests:
            future = self._pending_requests.pop(message.correlation_id)
            if not future.done():
                future.set_result(message)

    async def subscribe(self, agent_id: str, tenant_id: str, callback: Callable,
                        pattern: Optional[str] = None) -> None:
        """Register a callback for messages."""
        async with self._lock:
            if pattern:
                self._pattern_subscriptions[tenant_id][pattern].append(callback)
            else:
                self._subscriptions[tenant_id][agent_id].append(callback)
        logger.info(f"Agent {agent_id} subscribed in tenant {tenant_id}")

    async def unsubscribe(self, agent_id: str, tenant_id: str) -> None:
        """Remove all subscriptions for an agent."""
        async with self._lock:
            self._subscriptions[tenant_id].pop(agent_id, None)
            # Also remove from pattern subscriptions (tracked by agent_id in value)
            for pattern in list(self._pattern_subscriptions[tenant_id].keys()):
                self._pattern_subscriptions[tenant_id][pattern] = [
                    cb for cb in self._pattern_subscriptions[tenant_id][pattern]
                    if getattr(cb, "__agent_id__", None) != agent_id
                ]

    # ── Request-Response ───────────────────────────────────

    async def request(self, message: A2AMessage, timeout: int = 30) -> A2AMessage:
        """Send a request and await the correlated response."""
        if message.message_type != MessageType.REQUEST:
            raise CommunicationError("request() requires message_type=REQUEST")

        # Create a future to wait for the response
        loop = asyncio.get_event_loop()
        future = loop.create_future()
        self._pending_requests[message.message_id] = future

        # Publish the request
        await self.publish(message)

        try:
            return await asyncio.wait_for(future, timeout=timeout)
        except asyncio.TimeoutError:
            self._pending_requests.pop(message.message_id, None)
            raise MessageTimeoutError(
                f"Request {message.message_id} timed out after {timeout}s"
            )

    # ── Broadcast ──────────────────────────────────────────

    async def broadcast(self, message: A2AMessage) -> List[A2AMessage]:
        """
        Broadcast to all agents in the tenant (except sender).
        For REQUEST type, collects responses; otherwise returns empty list.
        """
        tenant = message.tenant_id
        responses = []

        for agent_id, callbacks in self._subscriptions[tenant].items():
            if agent_id != message.sender_id:
                for cb in callbacks:
                    result = await self._invoke_callback(cb, message)
                    if result is not None:
                        responses.append(result)
        return responses

    # ── Helpers ────────────────────────────────────────────

    async def _invoke_callback(self, callback: Callable, message: A2AMessage) -> Any:
        """Invoke a callback (async or sync) safely."""
        try:
            if asyncio.iscoroutinefunction(callback):
                return await callback(message)
            else:
                return callback(message)
        except Exception as e:
            logger.error(f"Callback error for message {message.message_id}: {e}", exc_info=True)
            return None

    def _matches_pattern(self, message: A2AMessage, pattern: str) -> bool:
        """Simple intent/field matching. For production, use regex."""
        # For now, match on intent exactly
        return message.intent == pattern

    def get_message_history(self, tenant_id: str, limit: int = 100) -> List[A2AMessage]:
        """Retrieve recent messages for a tenant (debugging)."""
        return self._message_log.get(tenant_id, [])[-limit:]
