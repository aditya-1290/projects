"""
FasTag Multi‑Agents – Central Configuration
Loads from .env file, provides typed settings for all components.
"""

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

# Load .env if python-dotenv is available
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

# ─── Paths ──────────────────────────────────────────────────
BASE_DIR = Path(__file__).resolve().parent.parent          # project root
DATA_DIR = BASE_DIR / "data"
SESSIONS_DIR = DATA_DIR / "sessions"
PREDEFINED_SQL_DIR = BASE_DIR / "agents" / "support_agent" / "queries"   # .sql files
MLFF_SCHEMA_FILE = BASE_DIR / "agents" / "mlff_agent" / "schema.json"    # MLFF table definitions

# Ensure directories exist
SESSIONS_DIR.mkdir(parents=True, exist_ok=True)
PREDEFINED_SQL_DIR.mkdir(parents=True, exist_ok=True)
MLFF_SCHEMA_FILE.parent.mkdir(parents=True, exist_ok=True)

# ─── Model Settings (Local) ─────────────────────────────────
@dataclass
class ModelSettings:
    provider: str = "local"
    model_name: str = os.getenv("LOCAL_MODEL_NAME", "D:/python_tasks/models/gemma-4-E4B-it-Q5_K_M.gguf")
    base_url: str = os.getenv("LOCAL_MODEL_BASE_URL", "http://127.0.0.1:8080/v1")
    api_key: str = os.getenv("LOCAL_MODEL_API_KEY", "not-needed")
    temperature: float = float(os.getenv("LOCAL_MODEL_TEMPERATURE", "0.7"))
    max_tokens: int = int(os.getenv("LOCAL_MODEL_MAX_TOKENS", "4096"))

    def as_config_dict(self):
        return {
            "model": self.model_name,
            "base_url": self.base_url,
            "api_key": self.api_key,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
        }

# ─── Database Settings (PostgreSQL) ─────────────────────────
@dataclass
class DatabaseSettings:
    dsn: str = os.getenv("POSTGRES_DSN", "postgresql://postgres:root@localhost:5432/enterprisedb")

# ─── Cache Settings (SQLite) ────────────────────────────────
@dataclass
class CacheSettings:
    db_path: str = str(DATA_DIR / "cache.db")
    max_entries: int = 50                     # keep only 50 most recent queries
    exact_match_only: bool = True             # reuse cached result only on exact query match

# ─── Session Settings ────────────────────────────────────────
@dataclass
class SessionSettings:
    max_sessions: int = 10
    max_messages_per_session: int = 100       # can be 80-100; we use 100
    storage_dir: str = str(SESSIONS_DIR)

# ─── Agent Settings ─────────────────────────────────────────
@dataclass
class SupportAgentSettings:
    predefined_sql_dir: str = str(PREDEFINED_SQL_DIR)
    keyword_match_threshold: int = 1          # minimum keyword overlaps to trigger a match

@dataclass
class MLFFAgentSettings:
    schema_file: str = str(MLFF_SCHEMA_FILE)   # JSON describing allowed tables/columns

@dataclass
class OrchestratorSettings:
    model_id: str = os.getenv("ORCHESTRATOR_MODEL_ID", "local-model")
    routing_strategy: str = os.getenv("ORCHESTRATOR_ROUTING_STRATEGY", "intent_based")
    min_confidence: float = float(os.getenv("ORCHESTRATOR_MIN_CONFIDENCE", "0.7"))

# ─── MCP Server Settings ────────────────────────────────────
@dataclass
class MCPSettings:
    host: str = os.getenv("MCP_HOST", "127.0.0.1")
    port: int = int(os.getenv("MCP_PORT", "8001"))
    transport: str = os.getenv("MCP_TRANSPORT", "sse")   # sse or streamable-http

# ─── Top-Level App Settings ─────────────────────────────────
@dataclass
class AppSettings:
    app_name: str = "FasTag Multi-Agents"
    tenant_id: str = os.getenv("TENANT_ID", "fastag-default")
    model: ModelSettings = field(default_factory=ModelSettings)
    database: DatabaseSettings = field(default_factory=DatabaseSettings)
    cache: CacheSettings = field(default_factory=CacheSettings)
    sessions: SessionSettings = field(default_factory=SessionSettings)
    support_agent: SupportAgentSettings = field(default_factory=SupportAgentSettings)
    mlff_agent: MLFFAgentSettings = field(default_factory=MLFFAgentSettings)
    orchestrator: OrchestratorSettings = field(default_factory=OrchestratorSettings)
    mcp: MCPSettings = field(default_factory=MCPSettings)

    def get_model_config(self, model_id: str) -> "ModelConfig":
        from model.model_manager import ModelConfig
        return ModelConfig(
            model_id=model_id,
            provider=self.model.provider,
            model_name=self.model.model_name,
            base_url=self.model.base_url,
            api_key=self.model.api_key,
            temperature=self.model.temperature,
            max_tokens=self.model.max_tokens,
        )

# Singleton instance
settings = AppSettings()
