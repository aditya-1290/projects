# ADK Multi-Agent Foundation

A modular, reusable foundation for building multi-agent systems using **Google ADK**.
Provides ready-made infrastructure for agent communication, discovery, routing, model management, and MCP integration — so you only need to focus on building agents.

---

## Features

- **Agent-to-Agent (A2A) Protocol** – JSON-based standard messages with tenant isolation.
- **Communication Bus** – Pub/sub and request/reply patterns; all agents talk through the bus.
- **Capability Registry** – Agents register their capabilities; the orchestrator discovers them dynamically.
- **Orchestrator Agent** – Built-in routing agent using intent analysis and registry queries.
- **Model Manager** – LLM pooling, fallback chains, and cost tracking.
- **Context Manager** – Pluggable session/state storage (in-memory by default).
- **MCP Servers** – PostgreSQL MCP server using FastMCP; easily extendable to other data sources.
- **Tenant Isolation** – Every component enforces tenant boundaries.
- **Observability** – Structured logging and tracing hooks.
- **Stateful Agents** – Agents maintain state and conversation history.
- **Security Stubs** – Auth, encryption, and rate limiter (marked as not production-ready).

---

## Architecture

```
User Request
│
▼
Orchestrator Agent (routes based on intent)
│
├──► Agent A (Weather)    ──► External API / MCP Server
├──► Agent B (Database)   ──► PostgreSQL MCP Server
└──► Agent C (Calculator)
```

All inter-agent communication flows through the **Communication Bus**, which enforces tenant isolation. The **Capability Registry** is queried by the Orchestrator to find the right agent for each request.

---

## Project Structure

```
├── core/                         # Foundation: bus, registry, protocol, context
│   ├── communication_bus.py
│   ├── capability_registry.py
│   ├── a2a_protocol.py
│   ├── agent_card.py
│   ├── context_manager.py
│   ├── errors.py
│   ├── observability.py
│   └── utils.py
│
├── schemas/                      # Centralized JSON schemas (capabilities, messages)
│   └── a2a_message.json
│
├── agents/                       # Agent implementations
│   ├── base_agent.py             # ADK-integrated base agent
│   └── orchestrator/             # Built-in routing agent
│       ├── agent.py
│       ├── adk_agent_card.py
│       ├── capabilities.json
│       ├── skills.md
│       ├── tools.py
│       └── config.py
│
├── mcp_servers/                  # MCP server implementations
│   ├── postgres_mcp/             # PostgreSQL MCP server
│   │   ├── server.py
│   │   └── config.py
│   └── discovery.py              # MCP server registry
│
├── model/                        # LLM management
│   ├── model_manager.py
│   └── providers/
│       └── gemini_provider.py
│
├── security/                     # Security stubs (demo only)
│   ├── auth.py
│   ├── encryption.py
│   └── rate_limiter.py
│
├── examples/                     # Example agents and demos
│   ├── weather_agent/
│   │   ├── agent.py
│   │   ├── adk_agent_card.py
│   │   └── tools.py
│   └── multi_agent_demo.py
│
├── testing/                      # Mock agents and test utilities
├── config/                       # Global configuration
└── README.md
```

---

## Getting Started

### Prerequisites

- Python 3.10+
- [Google ADK](https://pypi.org/project/google-adk/) — `pip install google-adk`
- [FastMCP](https://pypi.org/project/fastmcp/) — `pip install fastmcp`
- [asyncpg](https://pypi.org/project/asyncpg/) — `pip install asyncpg` (for PostgreSQL MCP)

### Installation

```bash
git clone <repo-url>
cd adk-multi-agent-foundation
pip install -r requirements.txt
cp .env.example .env
# Edit .env with your API keys and settings
```

### Running the Demo

```bash
python examples/multi_agent_demo.py
```

This will:

1. Create the Communication Bus and Capability Registry.
2. Start the Orchestrator agent.
3. Register a Weather agent and a Calculator agent.
4. Send a test request and print the response.

---

## Creating a New Agent

**1. Scaffold the agent folder:**

```bash
python scripts/create_agent.py --name MyAgent --capabilities "search,summarize"
```

**2. Fill in agent metadata:**

Edit `agents/my_agent/adk_agent_card.py` with your agent's ID, capabilities, version, and description.

**3. Implement the agent:**

Extend `BaseAgent` in `agents/my_agent/agent.py` and override `process()`.

**4. Define tools:**

Add your Python tool functions to `agents/my_agent/tools.py`.

**5. Register the agent in your application:**

```python
# agent = MyAgent(card, bus, registry, context_manager)
# await agent.initialize()
```

---

## MCP Integration

### Using the PostgreSQL MCP Server with an Agent

```python
# from google.adk.tools.mcp_toolset import McpToolset
# 
# toolset = McpToolset(connection_params={
#     "command": "python",
#     "args": ["-m", "mcp_servers.postgres_mcp.server"],
#     "env": {"POSTGRES_DSN": "postgresql://..."}
# })
# 
# agent = LlmAgent(..., tools=[toolset])
```

### Exposing to Claude Desktop

Add the following to your Claude MCP config:

```json
{
  "mcpServers": {
    "postgres": {
      "command": "python",
      "args": ["-m", "mcp_servers.postgres_mcp.server"],
      "env": {
        "POSTGRES_DSN": "postgresql://user:password@host/dbname"
      }
    }
  }
}
```

---

## Configuration

Global settings live in `config/settings.py`. Each agent can override defaults via its own `config.py`.

---

## Security Notice

> ⚠️ The `security/` module contains **stubs for demonstration only**.
> Replace `auth.py`, `encryption.py`, and `rate_limiter.py` with production-grade implementations before deploying.

---

## Next Steps

- Replace in-memory components with Redis or Kafka for distributed deployments.
- Implement additional MCP servers (REST APIs, other databases).
- Add persistent state storage for agents.
- Integrate with monitoring tools such as Prometheus and Grafana.

---
