"""
Tenant isolation helpers – not a stub, as isolation is enforced in bus and registry.
These are validation utilities for external use.
"""

from core.errors import TenantIsolationError


def validate_tenant(expected_tenant: str, actual_tenant: str) -> None:
    """
    Raise TenantIsolationError if tenants don't match.
    Used by any component that needs explicit tenant checks.
    """
    if expected_tenant != actual_tenant:
        raise TenantIsolationError(
            f"Tenant mismatch: expected '{expected_tenant}', got '{actual_tenant}'"
        )


def is_same_tenant(tenant_a: str, tenant_b: str) -> bool:
    return tenant_a == tenant_b
