"""
WARNING: STUB – NOT PRODUCTION-READY.
Replace with real authentication (OAuth2, JWT) before deploying.
"""

async def verify_token(token: str) -> dict:
    """Stub: always returns a valid user."""
    return {"user_id": "demo_user", "tenant_id": "default", "roles": ["admin"]}
