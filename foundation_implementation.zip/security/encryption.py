"""
WARNING: STUB – NOT PRODUCTION-READY.
Replace with actual encryption (AES-GCM, TLS) before deploying.
"""

async def encrypt(data: str) -> str:
    """Stub: returns data unchanged."""
    return data

async def decrypt(data: str) -> str:
    """Stub: returns data unchanged."""
    return data
