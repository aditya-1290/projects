"""
Simple in-memory rate limiter for demo purposes.
Not suitable for distributed deployments.
"""

import time
from collections import defaultdict

class RateLimiter:
    def __init__(self, max_requests: int = 60, window_seconds: int = 60):
        self.max_requests = max_requests
        self.window = window_seconds
        self._clients: defaultdict = defaultdict(list)

    def allow_request(self, client_id: str) -> bool:
        now = time.time()
        window_start = now - self.window
        self._clients[client_id] = [t for t in self._clients[client_id] if t > window_start]
        if len(self._clients[client_id]) >= self.max_requests:
            return False
        self._clients[client_id].append(now)
        return True
