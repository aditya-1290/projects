@echo off
echo ============================================================
echo   MLFF ADK - Quick Start (Windows)
echo ============================================================
echo.
echo Make sure .venv is activated in ALL 3 terminals:
echo   .venv\Scripts\activate
echo.
echo TERMINAL 1 - LLM Server:
echo   python -m llama_cpp.server --model "D:\Models\gemma-4-E4B-it-Q5_K_M.gguf" --host 127.0.0.1 --port 8001 --chat_format chatml --n_ctx 4096
echo.
echo TERMINAL 2 - MCP Server:
echo   uvicorn mcp_server.main:app --host 127.0.0.1 --port 9000 --reload
echo.
echo TERMINAL 3 - Main App:
echo   uvicorn app:app --host 127.0.0.1 --port 8000 --reload
echo.
echo Browser: http://127.0.0.1:8000
echo.
echo Run setup_check.py first to verify everything is ready:
echo   python setup_check.py
echo.
pause
