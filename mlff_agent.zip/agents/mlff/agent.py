"""
agents/mlff/agent.py
Real Google ADK implementation with Tool Call Parser Bridge.

Bridge handles Gemma's plain-text tool call output:
  print(generate_sql_query(user_query="...", intent="...", ...))
  print(execute_sql_via_mcp(sql="SELECT ..."))
  print(explain_results(user_query="...", sql="...", execution_result_json="..."))
"""
import uuid as _uuid
import os
import json
import asyncio
from typing import Any, Dict, List

from dotenv import load_dotenv
from google.adk.agents import LlmAgent
from google.adk.models.lite_llm import LiteLlm
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types

from agents.mlff.agent_card import MLFF_CARD
from agents.mlff.skills.sql_generator import generate_sql
from agents.mlff.skills.result_formatter import format_result
from core.mcp_client import mcp_client
from core.tool_call_parser import parse_tool_call, execute_tool, detect_tool_call
from core.logger import get_logger, success_logger, error_logger

load_dotenv()
logger = get_logger("mlff_agent")

os.environ["OPENAI_API_KEY"] = os.getenv("LOCAL_LLM_API_KEY", "sk-local")
os.environ["OPENAI_API_BASE"] = os.getenv("LOCAL_LLM_BASE_URL", "http://127.0.0.1:8001/v1")

_model = LiteLlm(model=f"openai/{os.getenv('LOCAL_LLM_MODEL', 'local-model')}")

MAX_DISPLAY_ROWS = 50
MAX_BRIDGE_ITERATIONS = 6


# ── ADK Tool functions ────────────────────────────────────────────────────────

def generate_sql_query(
    user_query: str,
    intent: str,
    query_type: str,
    selected_schema: str,
    selected_tables_json: str,
    schema_details_json: str,
    relationships_hint_json: str,
) -> str:
    """
    Generate a safe PostgreSQL SELECT SQL query from user query and schema context.
    Args:
        user_query: The original natural language query.
        intent: Detected query intent.
        query_type: Query complexity - simple, medium, or complex.
        selected_schema: The PostgreSQL schema name.
        selected_tables_json: JSON array of relevant table names.
        schema_details_json: JSON object mapping table to columns and row_count.
        relationships_hint_json: JSON array of foreign key relationship hints.
    Returns:
        A clean PostgreSQL SELECT SQL string.
    """
    try:
        #selected_tables=[t if isinstance(t, str) else str(t) for t in orchestrator_payload.get("selected_tables", [])],schema_details = json.loads(schema_details_json) if isinstance(schema_details_json, str) else schema_details_json
        #relationships_hint=[r if isinstance(r, str) else str(r) for r in orchestrator_payload.get("relationships_hint", [])],

        selected_tables = json.loads(selected_tables_json) if isinstance(selected_tables_json, str) else selected_tables_json
        schema_details = json.loads(schema_details_json) if isinstance(schema_details_json, str) else schema_details_json
        relationships_hint = json.loads(relationships_hint_json) if isinstance(relationships_hint_json, str) else relationships_hint_json





        sql = generate_sql(
            user_query=user_query,
            intent=intent,
            query_type=query_type,
            selected_schema=selected_schema,
            selected_tables=selected_tables,
            schema_details=schema_details,
            relationships_hint=relationships_hint,
        )
        return sql
    except Exception as e:
        error_logger.error(f"generate_sql_query tool error: {e}")
        return f"-- SQL generation failed: {e}"


def execute_sql_via_mcp(sql: str) -> str:
    """
    Execute a SQL query via MCP server. Read-only, validated.
    Args:
        sql: A PostgreSQL SELECT SQL query string.
    Returns:
        JSON string with ok, rows, row_count, columns or error.
    """
    try:
        result = mcp_client.execute_query(sql)
        if result.get("rows"):
            result["rows"] = result["rows"][:MAX_DISPLAY_ROWS]
            result["row_count"] = len(result["rows"])
        return json.dumps(result, default=str)
    except Exception as e:
        error_logger.error(f"execute_sql_via_mcp tool error: {e}")
        return json.dumps({"ok": False, "error": str(e), "rows": [], "row_count": 0})


def explain_results(
    user_query: str,
    sql: str,
    execution_result_json: str,
) -> str:
    """
    Generate natural language explanation and chart type suggestion for query results.
    Args:
        user_query: The original user question.
        sql: The SQL query that was executed.
        execution_result_json: JSON string of the execution result.
    Returns:
        JSON string with explanation, chart_type, chart_reason.
    """
    try:
        exec_result = json.loads(execution_result_json) if isinstance(execution_result_json, str) else execution_result_json
        rows = exec_result.get("rows", [])
        row_count = exec_result.get("row_count", 0)
        result = format_result(
            user_query=user_query,
            sql=sql,
            rows=rows,
            row_count=row_count,
        )
        return json.dumps(result)
    except Exception as e:
        error_logger.error(f"explain_results tool error: {e}")
        return json.dumps({
            "explanation": "Results retrieved successfully.",
            "chart_type": "table",
            "chart_reason": "Default fallback.",
        })


# ── Tools map for bridge ──────────────────────────────────────────────────────
_TOOLS_MAP = {
    "generate_sql_query": generate_sql_query,
    "execute_sql_via_mcp": execute_sql_via_mcp,
    "explain_results": explain_results,
}

# ── ADK LlmAgent ──────────────────────────────────────────────────────────────

MLFF_INSTRUCTION = """
You are the MLFF Analytics Agent. You execute database queries.

For every request call these tools in order:

Step 1 - Generate SQL:
generate_sql_query(user_query="...", intent="...", query_type="...", selected_schema="...", selected_tables_json=["table1","table2"], schema_details_json={...}, relationships_hint_json=[...])

Step 2 - Execute SQL:
execute_sql_via_mcp(sql="the SQL from step 1")

Step 3 - Explain results:
explain_results(user_query="...", sql="the SQL", execution_result_json="the result from step 2")

After all 3 tools, return ONLY this JSON (no markdown, no explanation):
{
  "sql": "<sql from step 1>",
  "ok": true,
  "rows": [],
  "row_count": 0,
  "columns": [],
  "explanation": "<from step 3>",
  "chart_type": "<from step 3>",
  "chart_reason": "<from step 3>",
  "error": ""
}
"""

mlff_llm_agent = LlmAgent(
    name="mlff",
    model=_model,
    description=MLFF_CARD.description,
    instruction=MLFF_INSTRUCTION,
    tools=[generate_sql_query, execute_sql_via_mcp, explain_results],
    output_key="mlff_result",
)

_session_service = InMemorySessionService()
_runner = Runner(
    agent=mlff_llm_agent,
    app_name="mlff_adk",
    session_service=_session_service,
)


# ── Bridge Runner ─────────────────────────────────────────────────────────────

async def _run_with_bridge(
    runner: Runner,
    session_service: InMemorySessionService,
    user_id: str,
    session_id: str,
    initial_message: str,
    app_name: str = "mlff_adk",
) -> str:
    """
    Run ADK agent with Tool Call Parser Bridge.
    Intercepts Gemma tool calls, executes in Python, injects results back.
    """
    # Ensure session exists
    existing = await session_service.get_session(
        app_name=app_name, user_id=user_id, session_id=session_id
    )
    if not existing:
        await session_service.create_session(
            app_name=app_name, user_id=user_id, session_id=session_id
        )

    current_message = initial_message
    iterations = 0

    while iterations < MAX_BRIDGE_ITERATIONS:
        iterations += 1
        logger.debug(f"[BRIDGE] MLFF Iteration {iterations} | session={session_id}")

        message = types.Content(
            role="user",
            parts=[types.Part(text=current_message)],
        )

        raw_text = ""

        async for event in runner.run_async(
            user_id=user_id,
            session_id=session_id,
            new_message=message,
        ):
            if event.is_final_response():
                if event.content and event.content.parts:
                    raw_text = event.content.parts[0].text or ""
                break

        logger.debug(f"[BRIDGE] MLFF raw output (iter {iterations}): {raw_text[:150]}")

        if not raw_text:
            logger.warning(f"[BRIDGE] MLFF empty response on iteration {iterations}")
            break

        # ── Check for tool call ───────────────────────────────────────
        if detect_tool_call(raw_text):
            parsed = parse_tool_call(raw_text)

            if parsed:
                tool_result = await execute_tool(parsed, _TOOLS_MAP)

                if tool_result:
                    current_message = (
                        f"Tool '{parsed['tool_name']}' returned:\n"
                        f"{tool_result}\n\n"
                        f"Continue with the next step."
                    )
                    logger.info(
                        f"[BRIDGE] MLFF tool executed: {parsed['tool_name']} | "
                        f"result_len={len(tool_result)}"
                    )
                    continue
                else:
                    logger.error(f"[BRIDGE] MLFF tool returned None: {parsed['tool_name']}")
                    break
            else:
                logger.warning(f"[BRIDGE] MLFF tool detected but parse failed: {raw_text[:200]}")
                break
        else:
            # No tool call — final response
            logger.info(f"[BRIDGE] MLFF final response on iteration {iterations}")
            return raw_text

    return raw_text


# ── Public interface ──────────────────────────────────────────────────────────

async def run_mlff_async(
    orchestrator_payload: Dict[str, Any],
    session_id: str,
    user_id: str = "mlff_user",
) -> Dict[str, Any]:
    """Run MLFF ADK agent with bridge. Returns full result dict for UI."""

    user_query = orchestrator_payload.get("user_query", "")
    success_logger.info(f"[{session_id}] MLFF ADK started")

    if not orchestrator_payload.get("ok"):
        error = orchestrator_payload.get("error", "Orchestrator failed")
        return _error_response(session_id, user_query, orchestrator_payload, error)

    # Build context message for MLFF
    context_message = f"""
User query: {user_query}

Context from Orchestrator:
- intent: {orchestrator_payload.get('intent', 'lookup')}
- query_type: {orchestrator_payload.get('query_type', 'simple')}
- selected_schema: {orchestrator_payload.get('selected_schema', 'public')}
- selected_tables_json: {json.dumps(orchestrator_payload.get('selected_tables', []))}
- schema_details_json: {json.dumps(orchestrator_payload.get('schema_details', {}), default=str)}
- relationships_hint_json: {json.dumps(orchestrator_payload.get('relationships_hint', []))}
- context_summary: {orchestrator_payload.get('context_summary', '')}

Now call generate_sql_query, then execute_sql_via_mcp, then explain_results.
"""

    try:
        final_text = await _run_with_bridge(
            runner=_runner,
            session_service=_session_service,
            user_id=user_id,
            session_id=f"mlff_{session_id}_{_uuid.uuid4().hex[:6]}",
            initial_message=context_message,
        )

        success_logger.info(
            f"[{session_id}] MLFF ADK raw output: {final_text[:200]}"
        )

        # Parse JSON output
        clean = final_text.strip()
        if "```" in clean:
            parts = clean.split("```")
            for part in parts:
                s = part.strip()
                if s.startswith("{"):
                    clean = s
                    break
            else:
                clean = parts[1].strip()
                if clean.lower().startswith("json"):
                    clean = clean[4:].strip()

        result = json.loads(clean)
        result["ok"] = result.get("ok", True)

    except (json.JSONDecodeError, Exception) as e:
        error_logger.error(f"[{session_id}] MLFF bridge/parse error: {e}")
        result = await _mlff_fallback(orchestrator_payload, session_id)

    # Merge orchestrator metadata
    result.update({
        "request_id": session_id,
        "user_query": user_query,
        "intent": orchestrator_payload.get("intent", ""),
        "query_type": orchestrator_payload.get("query_type", ""),
        "confidence": orchestrator_payload.get("confidence", 0),
        "confidence_note": orchestrator_payload.get("confidence_note", ""),
        "low_confidence": orchestrator_payload.get("low_confidence", False),
        "selected_schema": orchestrator_payload.get("selected_schema", ""),
        "selected_tables": orchestrator_payload.get("selected_tables", []),
        "context_summary": orchestrator_payload.get("context_summary", ""),
    })

    success_logger.info(
        f"[{session_id}] MLFF complete | ok={result.get('ok')} | rows={result.get('row_count', 0)}"
    )
    return result


async def _mlff_fallback(
    orchestrator_payload: Dict[str, Any],
    session_id: str,
) -> Dict[str, Any]:
    """Direct fallback — calls skills in Python if bridge also fails."""
    logger.warning(f"[{session_id}] Using MLFF fallback (direct skill calls)")
    user_query = orchestrator_payload.get("user_query", "")
    try:
        sql = generate_sql(
            user_query=user_query,
            intent=orchestrator_payload.get("intent", "lookup"),
            query_type=orchestrator_payload.get("query_type", "simple"),
            selected_schema=orchestrator_payload.get("selected_schema", "public"),
            selected_tables=orchestrator_payload.get("selected_tables", []),
            schema_details=orchestrator_payload.get("schema_details", {}),
            relationships_hint=orchestrator_payload.get("relationships_hint", []),
        )
        mcp_result = mcp_client.execute_query(sql)
        rows = mcp_result.get("rows", [])[:MAX_DISPLAY_ROWS]
        row_count = len(rows)
        columns = list(rows[0].keys()) if rows else []
        fmt = format_result(user_query, sql, rows, row_count)
        return {
            "ok": mcp_result.get("ok", False),
            "sql": sql,
            "rows": rows,
            "row_count": row_count,
            "columns": columns,
            "explanation": fmt.get("explanation", ""),
            "chart_type": fmt.get("chart_type", "table"),
            "chart_reason": fmt.get("chart_reason", ""),
            "error": mcp_result.get("error", ""),
        }
    except Exception as e:
        return {
            "ok": False, "sql": "", "rows": [], "row_count": 0,
            "columns": [], "explanation": str(e),
            "chart_type": "none", "chart_reason": "", "error": str(e),
        }


def _error_response(
    session_id: str,
    user_query: str,
    orchestrator_payload: Dict,
    error: str,
) -> Dict[str, Any]:
    return {
        "ok": False, "request_id": session_id, "user_query": user_query,
        "error": error, "sql": "", "rows": [], "row_count": 0,
        "explanation": error, "chart_type": "none", "chart_reason": "",
        "intent": orchestrator_payload.get("intent", ""),
        "query_type": orchestrator_payload.get("query_type", ""),
        "confidence": orchestrator_payload.get("confidence", 0),
        "confidence_note": orchestrator_payload.get("confidence_note", ""),
        "low_confidence": orchestrator_payload.get("low_confidence", False),
        "selected_schema": orchestrator_payload.get("selected_schema", ""),
        "selected_tables": orchestrator_payload.get("selected_tables", []),
        "columns": [],
    }


def run_mlff(
    orchestrator_payload: Dict[str, Any],
    session_id: str,
    user_id: str = "mlff_user",
) -> Dict[str, Any]:
    """Sync wrapper — do NOT use from FastAPI. Use run_mlff_async instead."""
    return asyncio.run(run_mlff_async(orchestrator_payload, session_id, user_id))