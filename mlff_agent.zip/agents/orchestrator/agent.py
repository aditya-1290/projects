"""
agents/orchestrator/agent.py
Real Google ADK implementation with Tool Call Parser Bridge.

Bridge handles Gemma's plain-text tool call output:
  print(detect_query_intent(user_query="..."))
  print(get_database_context(user_query="...", intent="...", query_type="..."))
"""
import os
import json
import asyncio
from typing import Any, Dict

from dotenv import load_dotenv
from google.adk.agents import LlmAgent
from google.adk.models.lite_llm import LiteLlm
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types

from agents.orchestrator.agent_card import ORCHESTRATOR_CARD
from agents.orchestrator.skills.intent_detection import run_intent_detection
from agents.orchestrator.skills.schema_context_selector import select_schema_context
from core.mcp_client import mcp_client
from core.tool_call_parser import parse_tool_call, execute_tool, detect_tool_call
from core.logger import get_logger, success_logger, error_logger

load_dotenv()
logger = get_logger("orchestrator")

os.environ["OPENAI_API_KEY"] = os.getenv("LOCAL_LLM_API_KEY", "sk-local")
os.environ["OPENAI_API_BASE"] = os.getenv("LOCAL_LLM_BASE_URL", "http://127.0.0.1:8001/v1")

_model = LiteLlm(model=f"openai/{os.getenv('LOCAL_LLM_MODEL', 'local-model')}")

MAX_BRIDGE_ITERATIONS = 5  # max tool calls per agent run


# ── ADK Tool functions ────────────────────────────────────────────────────────

def detect_query_intent(user_query: str) -> str:
    """
    Detect the intent and complexity of a user database query.
    Args:
        user_query: The natural language query from the user.
    Returns:
        JSON string with intent, query_type, confidence, confidence_note.
    """
    result = run_intent_detection(user_query)
    logger.info(f"Intent detected: {result}")
    return json.dumps(result)


def get_database_context(user_query: str, intent: str, query_type: str) -> str:
    """
    Fetch database schema cache and select relevant schema, tables, columns.
    Args:
        user_query: The natural language query from the user.
        intent: Detected intent label.
        query_type: Complexity level - simple, medium, or complex.
    Returns:
        JSON string with selected_schema, selected_tables, relevant_columns,
        relationships_hint, context_summary, schema_details.
    """
    try:
        cache = mcp_client.get_cache()
        context = select_schema_context(user_query, intent, query_type, cache)

        selected_schema = context.get("selected_schema", "public")
        selected_tables = context.get("selected_tables", [])
        schemas_data = cache.get("schemas", {})

        schema_details = {}
        for table in selected_tables:
            full_name = f"{selected_schema}.{table}"
            info = schemas_data.get(full_name) or schemas_data.get(table, {})
            if info:
                schema_details[table] = {
                    "columns": info.get("columns", []),
                    "row_count": info.get("row_count", 0),
                }

        context["schema_details"] = schema_details
        context["table_count"] = cache.get("metadata", {}).get("table_count", 0)
        return json.dumps(context)
    except Exception as e:
        error_logger.error(f"get_database_context failed: {e}")
        return json.dumps({"error": str(e)})


# ── Tools map for bridge ──────────────────────────────────────────────────────
_TOOLS_MAP = {
    "detect_query_intent": detect_query_intent,
    "get_database_context": get_database_context,
}

# ── ADK LlmAgent ──────────────────────────────────────────────────────────────

ORCHESTRATOR_INSTRUCTION = f"""
You are the Orchestrator Agent for the MLFF analytics system.

For every user query you MUST call these two tools in order:
1. detect_query_intent - to detect intent, query_type, confidence
2. get_database_context - to get relevant schema and tables

Call them exactly like this:
detect_query_intent(user_query="the user query here")
get_database_context(user_query="the user query here", intent="detected intent", query_type="detected type")

After calling both tools, return ONLY this JSON (no markdown, no explanation):
{{
  "intent": "<from detect_query_intent>",
  "query_type": "<from detect_query_intent>",
  "confidence": <float>,
  "confidence_note": "<empty string or note>",
  "low_confidence": <true/false>,
  "selected_schema": "<from get_database_context>",
  "selected_tables": ["<table>"],
  "relevant_columns": {{}},
  "relationships_hint": [],
  "context_summary": "<from get_database_context>",
  "schema_details": {{}},
  "routing_to": "mlff"
}}
"""

orchestrator_llm_agent = LlmAgent(
    name="orchestrator",
    model=_model,
    description=ORCHESTRATOR_CARD.description,
    instruction=ORCHESTRATOR_INSTRUCTION,
    tools=[detect_query_intent, get_database_context],
    output_key="orchestrator_result",
)

_session_service = InMemorySessionService()
_runner = Runner(
    agent=orchestrator_llm_agent,
    app_name="mlff_adk",
    session_service=_session_service,
)


# ── Bridge Runner ─────────────────────────────────────────────────────────────

async def _run_with_bridge(
    runner: Runner,
    session_service: InMemorySessionService,
    user_id: str,
    session_id: str,
    initial_message: str,
    app_name: str = "mlff_adk",
) -> str:
    """
    Run ADK agent with Tool Call Parser Bridge.

    Intercepts Gemma's plain-text tool calls, executes them in Python,
    injects results back as messages, loops until final JSON response.

    Returns final text response from agent.
    """
    # Ensure session exists
    existing = await session_service.get_session(
        app_name=app_name, user_id=user_id, session_id=session_id
    )
    if not existing:
        await session_service.create_session(
            app_name=app_name, user_id=user_id, session_id=session_id
        )

    current_message = initial_message
    iterations = 0

    while iterations < MAX_BRIDGE_ITERATIONS:
        iterations += 1
        logger.debug(f"[BRIDGE] Iteration {iterations} | session={session_id}")

        message = types.Content(
            role="user",
            parts=[types.Part(text=current_message)],
        )

        raw_text = ""

        async for event in runner.run_async(
            user_id=user_id,
            session_id=session_id,
            new_message=message,
        ):
            if event.is_final_response():
                if event.content and event.content.parts:
                    raw_text = event.content.parts[0].text or ""
                break

        logger.debug(f"[BRIDGE] Raw output (iter {iterations}): {raw_text[:150]}")

        if not raw_text:
            logger.warning(f"[BRIDGE] Empty response on iteration {iterations}")
            break

        # ── Check if Gemma output contains a tool call ────────────────
        if detect_tool_call(raw_text):
            parsed = parse_tool_call(raw_text)

            if parsed:
                # Execute the tool in Python
                tool_result = await execute_tool(parsed, _TOOLS_MAP)

                if tool_result:
                    # Inject result back as next message
                    current_message = (
                        f"Tool '{parsed['tool_name']}' was called and returned:\n"
                        f"{tool_result}\n\n"
                        f"Continue with the next step."
                    )
                    logger.info(
                        f"[BRIDGE] Tool executed: {parsed['tool_name']} | "
                        f"result_len={len(tool_result)}"
                    )
                    continue
                else:
                    logger.error(f"[BRIDGE] Tool execution returned None for {parsed['tool_name']}")
                    break
            else:
                logger.warning(f"[BRIDGE] Tool detected but parse failed: {raw_text[:200]}")
                break
        else:
            # No tool call — this is the final response
            logger.info(f"[BRIDGE] Final response received on iteration {iterations}")
            return raw_text

    return raw_text


# ── Public interface ──────────────────────────────────────────────────────────

async def run_orchestrator_async(
    user_query: str,
    session_id: str,
    user_id: str = "mlff_user",
) -> Dict[str, Any]:
    """Run orchestrator ADK agent with bridge. Returns routing payload."""

    success_logger.info(
        f"[{session_id}] Orchestrator ADK started | query={user_query[:80]}"
    )

    try:
        final_text = await _run_with_bridge(
            runner=_runner,
            session_service=_session_service,
            user_id=user_id,
            session_id=f"orch_{session_id}",
            initial_message=user_query,
        )

        success_logger.info(
            f"[{session_id}] Orchestrator ADK raw output: {final_text[:200]}"
        )

        # Parse JSON output
        clean = final_text.strip()
        if "```" in clean:
            parts = clean.split("```")
            for part in parts:
                s = part.strip()
                if s.startswith("{"):
                    clean = s
                    break
            else:
                clean = parts[1].strip()
                if clean.lower().startswith("json"):
                    clean = clean[4:].strip()

        payload = json.loads(clean)
        payload["ok"] = True
        payload["user_query"] = user_query
        payload["request_id"] = session_id

        success_logger.info(
            f"[{session_id}] Orchestrator complete | "
            f"schema={payload.get('selected_schema')} | "
            f"tables={payload.get('selected_tables')}"
        )
        return payload

    except json.JSONDecodeError as e:
        error_logger.error(
            f"[{session_id}] Orchestrator JSON parse error: {e} | raw={final_text[:200]}"
        )
        return await _orchestrator_fallback(user_query, session_id)

    except Exception as e:
        error_logger.error(f"[{session_id}] Orchestrator failed: {e}")
        return await _orchestrator_fallback(user_query, session_id)


async def _orchestrator_fallback(
    user_query: str,
    session_id: str,
) -> Dict[str, Any]:
    """Direct fallback — calls skills in Python if bridge also fails."""
    logger.warning(f"[{session_id}] Using orchestrator fallback (direct skill calls)")
    try:
        intent_result = run_intent_detection(user_query)
        cache = mcp_client.get_cache()
        context = select_schema_context(
            user_query,
            intent_result["intent"],
            intent_result["query_type"],
            cache,
        )
        schemas_data = cache.get("schemas", {})
        selected_schema = context.get("selected_schema", "public")
        schema_details = {}
        for table in context.get("selected_tables", []):
            full_name = f"{selected_schema}.{table}"
            info = schemas_data.get(full_name) or schemas_data.get(table, {})
            if info:
                schema_details[table] = {
                    "columns": info.get("columns", []),
                    "row_count": info.get("row_count", 0),
                }
        return {
            "ok": True,
            "request_id": session_id,
            "user_query": user_query,
            "intent": intent_result["intent"],
            "query_type": intent_result["query_type"],
            "confidence": intent_result["confidence"],
            "confidence_note": intent_result["confidence_note"],
            "low_confidence": intent_result["confidence"] < ORCHESTRATOR_CARD.confidence_threshold,
            "selected_schema": selected_schema,
            "selected_tables": context.get("selected_tables", []),
            "relevant_columns": context.get("relevant_columns", {}),
            "relationships_hint": context.get("relationships_hint", []),
            "context_summary": context.get("context_summary", ""),
            "schema_details": schema_details,
            "routing_to": "mlff",
        }
    except Exception as e:
        return {
            "ok": False,
            "request_id": session_id,
            "user_query": user_query,
            "error": str(e),
            "confidence": 0.0,
        }


def run_orchestrator(
    user_query: str,
    session_id: str,
    user_id: str = "mlff_user",
) -> Dict[str, Any]:
    """Sync wrapper — do NOT use from FastAPI. Use run_orchestrator_async instead."""
    return asyncio.run(run_orchestrator_async(user_query, session_id, user_id))