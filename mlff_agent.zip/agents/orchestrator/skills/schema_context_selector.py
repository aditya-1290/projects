"""
agents/orchestrator/skills/schema_context_selector.py
Selects relevant schema, tables, and columns from in-memory cache.
FIX: Strict prompt - LLM can ONLY use exact table names from cache.
"""
import json
from typing import Any, Dict, List

from core.llm_client import call_llm
from core.logger import get_logger

logger = get_logger("schema_context_skill")

MAX_TABLES_IN_CONTEXT = 6
MAX_COLUMNS_PER_TABLE = 10


def select_schema_context(
    user_query: str,
    intent: str,
    query_type: str,
    cache: Dict[str, Any],
) -> Dict[str, Any]:

    table_map = cache.get("table_map", {})
    schemas_data = cache.get("schemas", {})
    relationships = cache.get("relationships", {})

    # ── Build strict table list with columns ──────────────────────────
    # Pass EXACT names — no free text that lets LLM invent names
    strict_table_list = []
    for schema, tables in table_map.items():
        for table in tables:
            full_name = f"{schema}.{table}"
            info = schemas_data.get(full_name, {})
            cols = info.get("columns", [])[:MAX_COLUMNS_PER_TABLE]
            col_names = [c["column_name"] for c in cols]
            strict_table_list.append({
                "exact_schema": schema,
                "exact_table": table,
                "exact_full_name": full_name,
                "columns": col_names,
            })

    # Top 20 FK relationships
    rel_lines = list(relationships.keys())[:20]

    prompt = f"""You are a database table selector.

USER QUERY: {user_query}
INTENT: {intent}
QUERY TYPE: {query_type}

AVAILABLE TABLES (these are the ONLY tables that exist in the database):
{json.dumps(strict_table_list, indent=2)}

FOREIGN KEY RELATIONSHIPS:
{chr(10).join(rel_lines) if rel_lines else 'None'}

YOUR TASK:
Select the most relevant tables from the list above to answer the user query.

STRICT RULES - YOU MUST FOLLOW THESE:
1. You can ONLY use table names from the "exact_table" field in the list above.
2. You can ONLY use schema names from the "exact_schema" field in the list above.
3. NEVER invent or guess table names. NEVER use table names not in the list.
4. NEVER use schema names not in the list.
5. Select maximum {MAX_TABLES_IN_CONTEXT} tables.
6. Use EXACT spelling as shown in "exact_table" field.

Return ONLY this JSON (no markdown, no explanation, no extra text):
{{
  "selected_schema": "<exact_schema from list above>",
  "selected_tables": ["<exact_table>", "<exact_table>"],
  "relevant_columns": {{"<exact_table>": ["col1", "col2"]}},
  "relationships_hint": ["<copy exact relationship strings from above if relevant>"],
  "context_summary": "<one sentence about what data is needed>"
}}"""

    system = (
        "You are a strict database table selector. "
        "You ONLY use table names and schema names exactly as provided in the input. "
        "You NEVER invent table names. "
        "Return only valid JSON. No markdown. No extra text."
    )

    try:
        raw = call_llm(system, prompt, max_tokens=500)
        raw = raw.strip()

        # Strip markdown fences
        if "```" in raw:
            parts = raw.split("```")
            for part in parts:
                s = part.strip()
                if s.startswith("{"):
                    raw = s
                    break
            else:
                raw = parts[1].strip()
                if raw.lower().startswith("json"):
                    raw = raw[4:].strip()

        result = json.loads(raw)

        # ── VALIDATE — reject any hallucinated names ───────────────────
        all_valid_tables = [t["exact_table"] for t in strict_table_list]
        all_valid_schemas = list(table_map.keys())

        selected_schema = result.get("selected_schema", "")
        selected_tables = result.get("selected_tables", [])

        # Fix schema if hallucinated
        if selected_schema not in all_valid_schemas:
            logger.warning(
                f"LLM returned invalid schema '{selected_schema}'. "
                f"Valid: {all_valid_schemas}. Using first valid schema."
            )
            selected_schema = all_valid_schemas[0] if all_valid_schemas else "public"

        # Fix tables — remove any hallucinated names
        valid_selected = [t for t in selected_tables if t in all_valid_tables]
        if len(valid_selected) < len(selected_tables):
            bad = [t for t in selected_tables if t not in all_valid_tables]
            logger.warning(f"LLM hallucinated table names: {bad}. Removed.")

        # If all tables were hallucinated, fallback to first N tables in schema
        if not valid_selected:
            logger.warning("All selected tables invalid. Using fallback tables.")
            valid_selected = table_map.get(selected_schema, [])[:MAX_TABLES_IN_CONTEXT]

        result["selected_schema"] = selected_schema
        result["selected_tables"] = valid_selected[:MAX_TABLES_IN_CONTEXT]

        logger.info(
            f"Schema selected: {selected_schema} | "
            f"Tables: {result['selected_tables']}"
        )
        return result

    except Exception as e:
        logger.error(f"Schema context LLM failed: {e}. Using fallback.")
        first_schema = list(table_map.keys())[0] if table_map else "public"
        first_tables = table_map.get(first_schema, [])[:MAX_TABLES_IN_CONTEXT]
        return {
            "selected_schema": first_schema,
            "selected_tables": first_tables,
            "relevant_columns": {},
            "relationships_hint": [],
            "context_summary": "Fallback selection.",
        }