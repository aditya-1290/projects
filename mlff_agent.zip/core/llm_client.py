import os
from typing import Optional

from core.config import config
from core.logger import get_logger

logger = get_logger("llm_client")


def call_llm(system_prompt: str, user_prompt: str, max_tokens: int = 4096) -> str:
    """
    Call local LLM via litellm using llama_cpp_python server on port 8001.
    Falls back gracefully with error message if LLM is unreachable.
    """
    import litellm

    os.environ["OPENAI_API_KEY"] = config.LOCAL_LLM_API_KEY
    os.environ["OPENAI_API_BASE"] = config.LOCAL_LLM_BASE_URL

    model = f"openai/{config.LOCAL_LLM_MODEL}"

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt},
    ]

    logger.debug(f"LLM call | model={model} | prompt_len={len(user_prompt)}")

    try:
        response = litellm.completion(
            model=model,
            messages=messages,
            max_tokens=max_tokens,
            temperature=0.1,
            api_base=config.LOCAL_LLM_BASE_URL,
            api_key=config.LOCAL_LLM_API_KEY,
        )
        result = response.choices[0].message.content.strip()
        logger.debug(f"LLM response len={len(result)}")
        return result

    except Exception as e:
        error_msg = str(e)
        if "connection" in error_msg.lower() or "refused" in error_msg.lower():
            raise RuntimeError(
                f"Cannot connect to LLM server at {config.LOCAL_LLM_BASE_URL}. "
                "Is Terminal 1 running? Run: python -m llama_cpp.server --model <path> --host 127.0.0.1 --port 8001"
            )
        logger.error(f"LLM error: {e}")
        raise
