import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional

from core.logger import get_logger

logger = get_logger("session")

# In-memory session store: { session_id: SessionData }
_sessions: Dict[str, Dict[str, Any]] = {}

MAX_HISTORY_PER_SESSION = 50


def create_session() -> str:
    """Create a new session and return session_id."""
    session_id = str(uuid.uuid4())
    _sessions[session_id] = {
        "session_id": session_id,
        "created_at": datetime.utcnow().isoformat(),
        "last_active": datetime.utcnow().isoformat(),
        "history": [],  # List of query results
    }
    logger.info(f"Session created | session_id={session_id}")
    return session_id


def get_session(session_id: str) -> Optional[Dict[str, Any]]:
    """Get session data by session_id. Returns None if not found."""
    session = _sessions.get(session_id)
    if session:
        session["last_active"] = datetime.utcnow().isoformat()
    return session


def get_or_create_session(session_id: Optional[str]) -> str:
    """Get existing session or create a new one."""
    if session_id and session_id in _sessions:
        _sessions[session_id]["last_active"] = datetime.utcnow().isoformat()
        return session_id
    return create_session()


def add_to_history(session_id: str, entry: Dict[str, Any]) -> None:
    """Add a query result entry to session history."""
    session = _sessions.get(session_id)
    if not session:
        logger.warning(f"Session not found for history update | session_id={session_id}")
        return

    entry["timestamp"] = datetime.utcnow().isoformat()
    session["history"].append(entry)

    # Keep only last N entries
    if len(session["history"]) > MAX_HISTORY_PER_SESSION:
        session["history"] = session["history"][-MAX_HISTORY_PER_SESSION:]

    logger.info(f"History updated | session_id={session_id} | total={len(session['history'])}")


def get_history(session_id: str) -> List[Dict[str, Any]]:
    """Get query history for a session."""
    session = _sessions.get(session_id)
    if not session:
        return []
    return session["history"]


def clear_session(session_id: str) -> None:
    """Remove a session from memory."""
    if session_id in _sessions:
        del _sessions[session_id]
        logger.info(f"Session cleared | session_id={session_id}")


def list_sessions() -> List[str]:
    """Return all active session IDs (for debugging)."""
    return list(_sessions.keys())
