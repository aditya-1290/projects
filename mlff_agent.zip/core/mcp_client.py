import requests
from typing import Any, Dict

from core.config import config
from core.logger import get_logger

logger = get_logger("mcp_client")


class MCPClient:
    """HTTP client for calling the MCP server on port 9000."""

    def __init__(self):
        self.base_url = config.MCP_BASE_URL
        self.headers = {"x-api-key": config.MCP_API_KEY}

    def _get(self, path: str, params: Dict = None) -> Dict[str, Any]:
        url = f"{self.base_url}{path}"
        logger.debug(f"MCP GET {url} params={params}")
        try:
            resp = requests.get(url, headers=self.headers, params=params, timeout=30)
            resp.raise_for_status()
            return resp.json()
        except requests.exceptions.ConnectionError:
            raise RuntimeError(
                f"Cannot connect to MCP server at {self.base_url}. "
                "Is Terminal 2 running? Run: uvicorn mcp_server.main:app --host 127.0.0.1 --port 9000"
            )

    def _post(self, path: str, data: Dict) -> Dict[str, Any]:
        url = f"{self.base_url}{path}"
        logger.debug(f"MCP POST {url}")
        try:
            resp = requests.post(url, headers=self.headers, json=data, timeout=30)
            resp.raise_for_status()
            return resp.json()
        except requests.exceptions.ConnectionError:
            raise RuntimeError(
                f"Cannot connect to MCP server at {self.base_url}. "
                "Is Terminal 2 running?"
            )

    def health(self) -> Dict:
        return self._get("/health")

    def get_cache(self) -> Dict:
        """Get the full in-memory cache (schemas, tables, columns, relationships)."""
        return self._get("/cache")

    def get_schema(self, table_name: str = None) -> Dict:
        params = {}
        if table_name:
            params["table_name"] = table_name
        return self._get("/tools/get_schema", params=params)

    def get_relationships(self) -> Dict:
        return self._get("/tools/get_relationships")

    def execute_query(self, query: str, params: Dict = None) -> Dict:
        return self._post("/tools/execute_query", {
            "query": query,
            "params": params or {}
        })

    def refresh_cache(self) -> Dict:
        return self._post("/tools/refresh_cache", {})


# Singleton instance
mcp_client = MCPClient()
