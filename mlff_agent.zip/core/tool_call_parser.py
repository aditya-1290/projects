"""
core/tool_call_parser.py

Parser Bridge for Gemma's plain-text tool call output.

Gemma 4B does not follow ADK function-calling protocol.
Instead it outputs Python-style print statements like:
    print(generate_sql_query(user_query="...", intent="aggregation", ...))
    print(detect_query_intent(user_query="..."))
    generate_sql_query(user_query="...", intent="aggregation", ...)

This module:
1. Detects if Gemma output contains a tool call
2. Parses the tool name and arguments
3. Provides executor to call the actual Python function
"""

import re
import json
import inspect
import asyncio
from typing import Any, Dict, Optional

from core.logger import get_logger

logger = get_logger("tool_call_parser")


# ── Known tool argument names across both agents ──────────────────────────────
# Used for robust regex extraction
ALL_KNOWN_ARGS = [
    "user_query",
    "intent",
    "query_type",
    "selected_schema",
    "selected_tables_json",
    "schema_details_json",
    "relationships_hint_json",
    "sql",
    "execution_result_json",
]

# ── Known tool names across both agents ───────────────────────────────────────
ALL_KNOWN_TOOLS = [
    "detect_query_intent",
    "get_database_context",
    "generate_sql_query",
    "execute_sql_via_mcp",
    "explain_results",
]


def detect_tool_call(text: str) -> bool:
    """
    Quick check — does this text contain a tool call from Gemma?
    Returns True if any known tool name appears in the text.
    """
    if not text:
        return False
    for tool in ALL_KNOWN_TOOLS:
        if tool in text:
            return True
    return False


def _extract_tool_name(text: str) -> Optional[str]:
    """Extract tool name from Gemma output."""
    # Try: print(tool_name(...)) or tool_name(...)
    for tool in ALL_KNOWN_TOOLS:
        if tool in text:
            return tool
    return None


def _extract_string_arg(text: str, arg_name: str) -> Optional[str]:
    """
    Extract a string argument value from Python-style function call text.
    Handles: arg_name="value", arg_name='value', arg_name triple-quoted.
    """
    # Try triple-quoted first (for long strings)
    pattern = rf'{arg_name}\s*=\s*"""(.*?)"""'
    m = re.search(pattern, text, re.DOTALL)
    if m:
        return m.group(1).strip()

    # Try double-quoted
    pattern = rf'{arg_name}\s*=\s*"((?:[^"\\]|\\.)*)"'
    m = re.search(pattern, text, re.DOTALL)
    if m:
        return m.group(1).strip()

    # Try single-quoted
    pattern = rf"{arg_name}\s*=\s*'((?:[^'\\]|\\.)*)'"
    m = re.search(pattern, text, re.DOTALL)
    if m:
        return m.group(1).strip()

    return None


def _extract_json_arg(text: str, arg_name: str) -> Optional[str]:
    """
    Extract a JSON argument (list or dict) from Python-style function call text.
    Handles:
      arg_name=["a","b"]
      arg_name={"key":"value"}
      arg_name='[...]'
      arg_name="[...]"
    """
    # Try quoted JSON string first
    val = _extract_string_arg(text, arg_name)
    if val:
        stripped = val.strip()
        if stripped.startswith("[") or stripped.startswith("{"):
            return stripped

    # Try unquoted JSON list or dict
    # Find arg_name= then capture balanced brackets
    pattern = rf'{arg_name}\s*=\s*(\[|\{{)'
    m = re.search(pattern, text)
    if not m:
        return None

    start = m.start(1)
    open_char = text[start]
    close_char = "]" if open_char == "[" else "}"

    depth = 0
    i = start
    while i < len(text):
        if text[i] == open_char:
            depth += 1
        elif text[i] == close_char:
            depth -= 1
            if depth == 0:
                return text[start:i+1]
        i += 1

    return None


def parse_tool_call(text: str) -> Optional[Dict[str, Any]]:
    """
    Parse Gemma's plain-text tool call output into tool_name + args dict.

    Handles formats:
      print(detect_query_intent(user_query="Show top 10 customers"))
      print(generate_sql_query(user_query="...", intent="aggregation", ...))
      detect_query_intent(user_query="...")
      generate_sql_query(...)

    Returns:
      {"tool_name": "...", "args": {...}} or None
    """
    if not text or not detect_tool_call(text):
        return None

    tool_name = _extract_tool_name(text)
    if not tool_name:
        return None

    args = {}

    # ── Extract arguments based on tool ──────────────────────────────
    if tool_name == "detect_query_intent":
        val = _extract_string_arg(text, "user_query")
        if val:
            args["user_query"] = val

    elif tool_name == "get_database_context":
        for arg in ["user_query", "intent", "query_type"]:
            val = _extract_string_arg(text, arg)
            if val:
                args[arg] = val

    elif tool_name == "generate_sql_query":
        for arg in ["user_query", "intent", "query_type", "selected_schema"]:
            val = _extract_string_arg(text, arg)
            if val:
                args[arg] = val
        for arg in ["selected_tables_json", "schema_details_json", "relationships_hint_json"]:
            val = _extract_json_arg(text, arg)
            if val:
                args[arg] = val

    elif tool_name == "execute_sql_via_mcp":
        val = _extract_string_arg(text, "sql")
        if val:
            args["sql"] = val
        else:
            # Sometimes model writes: execute_sql_via_mcp("SELECT ...")
            m = re.search(r'execute_sql_via_mcp\s*\(\s*["\'](.+?)["\']', text, re.DOTALL)
            if m:
                args["sql"] = m.group(1).strip()

    elif tool_name == "explain_results":
        for arg in ["user_query", "sql"]:
            val = _extract_string_arg(text, arg)
            if val:
                args[arg] = val
        val = _extract_json_arg(text, "execution_result_json")
        if val:
            args["execution_result_json"] = val

    if not args:
        logger.warning(f"Tool call detected for '{tool_name}' but no args parsed. Text: {text[:200]}")
        return None

    logger.info(f"[BRIDGE] Parsed tool call: {tool_name} | args_keys={list(args.keys())}")
    return {"tool_name": tool_name, "args": args}


async def execute_tool(
    parsed: Dict[str, Any],
    tools_map: Dict[str, Any],
) -> Optional[str]:
    """
    Execute a parsed tool call against the tools map.
    Returns result as string, or None if tool not found.
    """
    tool_name = parsed["tool_name"]
    args = parsed["args"]

    tool_fn = tools_map.get(tool_name)
    if not tool_fn:
        logger.error(f"[BRIDGE] Unknown tool: {tool_name}. Available: {list(tools_map.keys())}")
        return None

    try:
        logger.info(f"[BRIDGE] Executing tool: {tool_name} | args_keys={list(args.keys())}")

        # Get valid parameters for this function
        sig = inspect.signature(tool_fn)
        valid_params = list(sig.parameters.keys())
        filtered_args = {k: v for k, v in args.items() if k in valid_params}

        # Call — handles both sync and async functions
        if asyncio.iscoroutinefunction(tool_fn):
            result = await tool_fn(**filtered_args)
        else:
            result = tool_fn(**filtered_args)

        result_str = str(result) if result is not None else ""
        logger.info(f"[BRIDGE] Tool result: {tool_name} | len={len(result_str)}")
        return result_str

    except Exception as e:
        logger.error(f"[BRIDGE] Tool execution error: {tool_name} | error={e}")
        return json.dumps({"error": str(e)})