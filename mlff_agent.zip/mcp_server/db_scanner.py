"""
Scans the full PostgreSQL database on MCP server startup.
Stores everything in memory_store.
Runs ONCE per server start.
"""
import os
from datetime import datetime
from typing import Any, Dict, List

import psycopg2
import psycopg2.extras
from dotenv import load_dotenv

load_dotenv()

from mcp_server.memory_store import set_cache
from core.logger import get_logger

logger = get_logger("db_scanner")

SAMPLE_ROWS_LIMIT = 3
ROW_COUNT_LIMIT = 100  # cap row count query for huge tables


def _get_connection():
    return psycopg2.connect(
        host=os.getenv("POSTGRES_HOST", "127.0.0.1"),
        port=int(os.getenv("POSTGRES_PORT", "5432")),
        user=os.getenv("POSTGRES_USER", "postgres"),
        password=os.getenv("POSTGRES_PASSWORD", "root"),
        dbname=os.getenv("POSTGRES_DATABASE", "dvdrental"),
    )


def scan_database() -> Dict[str, Any]:
    """
    Full DB scan. Returns populated cache dict.
    Called once on MCP server startup.
    """
    logger.info("=== DB SCAN STARTED ===")
    conn = _get_connection()
    cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

    try:
        # ── 1. DB version ──────────────────────────────────────────────
        cur.execute("SELECT version();")
        db_version = cur.fetchone()["version"]
        logger.info(f"DB version: {db_version[:60]}")

        # ── 2. All schemas (exclude system schemas) ────────────────────
        cur.execute("""
            SELECT schema_name
            FROM information_schema.schemata
            WHERE schema_name NOT IN ('pg_catalog','information_schema','pg_toast')
              AND schema_name NOT LIKE 'pg_%'
            ORDER BY schema_name;
        """)
        schema_names: List[str] = [row["schema_name"] for row in cur.fetchall()]
        logger.info(f"Schemas found: {schema_names}")

        # ── 3. All tables per schema ───────────────────────────────────
        table_map: Dict[str, List[str]] = {}
        all_tables: List[Dict] = []

        for schema in schema_names:
            cur.execute("""
                SELECT table_name
                FROM information_schema.tables
                WHERE table_schema = %s
                  AND table_type = 'BASE TABLE'
                ORDER BY table_name;
            """, (schema,))
            tables = [row["table_name"] for row in cur.fetchall()]
            table_map[schema] = tables
            for t in tables:
                all_tables.append({"schema": schema, "table": t})
            logger.info(f"  Schema '{schema}': {len(tables)} tables")

        logger.info(f"Total tables: {len(all_tables)}")

        # ── 4. Columns, indexes, row counts for every table ────────────
        schemas_cache: Dict[str, Any] = {}

        for item in all_tables:
            schema = item["schema"]
            table = item["table"]
            full_name = f"{schema}.{table}"

            # Columns
            cur.execute("""
                SELECT
                    c.column_name,
                    c.data_type,
                    c.is_nullable,
                    c.column_default,
                    CASE WHEN pk.column_name IS NOT NULL THEN true ELSE false END AS primary_key
                FROM information_schema.columns c
                LEFT JOIN (
                    SELECT ku.column_name
                    FROM information_schema.table_constraints tc
                    JOIN information_schema.key_column_usage ku
                      ON tc.constraint_name = ku.constraint_name
                     AND tc.table_schema = ku.table_schema
                     AND tc.table_name = ku.table_name
                    WHERE tc.constraint_type = 'PRIMARY KEY'
                      AND tc.table_schema = %s
                      AND tc.table_name = %s
                ) pk ON c.column_name = pk.column_name
                WHERE c.table_schema = %s AND c.table_name = %s
                ORDER BY c.ordinal_position;
            """, (schema, table, schema, table))
            columns = [dict(row) for row in cur.fetchall()]

            # Indexes
            cur.execute("""
                SELECT indexname, indexdef
                FROM pg_indexes
                WHERE schemaname = %s AND tablename = %s;
            """, (schema, table))
            indexes = [dict(row) for row in cur.fetchall()]

            # Row count (fast estimate for large tables)
            try:
                cur.execute(f'SELECT COUNT(*) as cnt FROM "{schema}"."{table}" LIMIT {ROW_COUNT_LIMIT};')
                row_count = cur.fetchone()["cnt"]
            except Exception:
                row_count = -1
                conn.rollback()

            schemas_cache[full_name] = {
                "schema": schema,
                "table": table,
                "columns": columns,
                "indexes": indexes,
                "row_count": row_count,
            }

        logger.info(f"Columns + indexes loaded for {len(schemas_cache)} tables")

        # ── 5. Foreign key relationships ───────────────────────────────
        cur.execute("""
            SELECT
                tc.table_schema AS from_schema,
                tc.table_name AS from_table,
                kcu.column_name AS from_col,
                ccu.table_schema AS to_schema,
                ccu.table_name AS to_table,
                ccu.column_name AS to_col
            FROM information_schema.table_constraints tc
            JOIN information_schema.key_column_usage kcu
              ON tc.constraint_name = kcu.constraint_name
             AND tc.table_schema = kcu.table_schema
            JOIN information_schema.constraint_column_usage ccu
              ON ccu.constraint_name = tc.constraint_name
            WHERE tc.constraint_type = 'FOREIGN KEY';
        """)
        fk_rows = cur.fetchall()
        relationships: Dict[str, str] = {}
        for row in fk_rows:
            key = f"{row['from_schema']}.{row['from_table']}.{row['from_col']} -> {row['to_schema']}.{row['to_table']}.{row['to_col']}"
            relationships[key] = "foreign_key"
        logger.info(f"Relationships found: {len(relationships)}")

        # ── 6. Sample data (first 3 rows of each table) ────────────────
        sample_data: Dict[str, List] = {}
        for item in all_tables:
            schema = item["schema"]
            table = item["table"]
            full_name = f"{schema}.{table}"
            try:
                cur.execute(f'SELECT * FROM "{schema}"."{table}" LIMIT {SAMPLE_ROWS_LIMIT};')
                rows = cur.fetchall()
                sample_data[full_name] = [dict(r) for r in rows]
            except Exception:
                sample_data[full_name] = []
                conn.rollback()

        logger.info(f"Sample data loaded for {len(sample_data)} tables")

        # ── 7. Assemble cache ──────────────────────────────────────────
        cache = {
            "metadata": {
                "last_updated": datetime.utcnow().isoformat(),
                "db_version": db_version,
                "table_count": len(all_tables),
                "schema_count": len(schema_names),
            },
            "schemas": schemas_cache,
            "relationships": relationships,
            "sample_data": sample_data,
            "table_map": table_map,
        }

        set_cache(cache)
        logger.info("=== DB SCAN COMPLETE === Cache populated.")
        return cache

    except psycopg2.OperationalError as e:
        logger.error(f"DB connection failed: {e}")
        raise RuntimeError(
            f"Cannot connect to PostgreSQL: {e}\n"
            "Check your .env: POSTGRES_HOST, POSTGRES_PORT, POSTGRES_USER, POSTGRES_PASSWORD, POSTGRES_DATABASE"
        )
    finally:
        cur.close()
        conn.close()
