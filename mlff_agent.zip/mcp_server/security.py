import os
from dotenv import load_dotenv
from fastapi import Header, HTTPException

load_dotenv()


def verify_api_key(x_api_key: str = Header(default="")) -> bool:
    expected = os.getenv("MCP_API_KEY", "local-mcp-key")
    if x_api_key != expected:
        raise HTTPException(status_code=401, detail="Invalid MCP API key")
    return True
