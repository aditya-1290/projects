from typing import Any, Dict, Optional
from pydantic import BaseModel


class ExecuteQueryRequest(BaseModel):
    query: str
    params: Dict[str, Any] = {}


class GetSchemaRequest(BaseModel):
    table_name: Optional[str] = None


class RefreshCacheResponse(BaseModel):
    ok: bool
    message: str
    table_count: int = 0
