"""
In-memory store for full database metadata.
Populated once on MCP server startup by db_scanner.py.
Structure matches the agreed cache schema.
"""
from datetime import datetime
from typing import Any, Dict

_cache: Dict[str, Any] = {
    "metadata": {
        "last_updated": None,
        "db_version": None,
        "table_count": 0,
        "schema_count": 0,
    },
    "schemas": {},        # table_name -> {columns, indexes, row_count}
    "relationships": {},  # "table1.col -> table2.col": "foreign_key"
    "sample_data": {},    # table_name -> [rows]
    "table_map": {},      # schema_name -> [table_names]
}


def get_cache() -> Dict[str, Any]:
    return _cache


def set_cache(new_cache: Dict[str, Any]) -> None:
    global _cache
    _cache.update(new_cache)
    _cache["metadata"]["last_updated"] = datetime.utcnow().isoformat()


def is_populated() -> bool:
    return _cache["metadata"]["last_updated"] is not None


def get_table_schema(table_name: str) -> Dict[str, Any]:
    return _cache["schemas"].get(table_name, {})


def get_relationships() -> Dict[str, str]:
    return _cache["relationships"]


def get_table_map() -> Dict[str, list]:
    return _cache["table_map"]
