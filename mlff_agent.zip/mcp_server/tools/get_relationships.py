from typing import Any, Dict
from mcp_server.memory_store import get_cache


def get_table_relationships() -> Dict[str, Any]:
    """Return all foreign key relationships from in-memory cache."""
    cache = get_cache()
    relationships = cache.get("relationships", {})
    return {
        "relationships": relationships,
        "total": len(relationships),
    }
