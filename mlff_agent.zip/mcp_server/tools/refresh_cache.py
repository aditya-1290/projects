from typing import Any, Dict
from core.logger import get_logger

logger = get_logger("refresh_cache")


def refresh_cache() -> Dict[str, Any]:
    """Force a full DB rescan and reload the in-memory cache."""
    from mcp_server.db_scanner import scan_database
    try:
        logger.info("Cache refresh triggered manually.")
        cache = scan_database()
        return {
            "ok": True,
            "message": "Cache refreshed successfully.",
            "table_count": cache["metadata"]["table_count"],
            "last_updated": cache["metadata"]["last_updated"],
        }
    except Exception as e:
        logger.error(f"Cache refresh failed: {e}")
        return {"ok": False, "message": str(e), "table_count": 0}
