from typing import Any, Dict, Optional
from mcp_server.memory_store import get_cache, get_table_schema


def get_schema(table_name: Optional[str] = None) -> Dict[str, Any]:
    """
    Return schema for a specific table or all tables.
    Uses in-memory cache only (no DB hit).
    """
    cache = get_cache()

    if table_name:
        # Try exact match first
        if table_name in cache["schemas"]:
            return {"table": table_name, "schema": cache["schemas"][table_name]}

        # Try partial match (e.g. just table name without schema prefix)
        matches = {k: v for k, v in cache["schemas"].items() if k.endswith(f".{table_name}")}
        if matches:
            return {"tables": matches}

        return {"error": f"Table '{table_name}' not found in cache."}

    # Return all schemas (summary)
    summary = {}
    for full_name, info in cache["schemas"].items():
        summary[full_name] = {
            "schema": info.get("schema"),
            "table": info.get("table"),
            "column_count": len(info.get("columns", [])),
            "row_count": info.get("row_count", 0),
            "columns": info.get("columns", []),
        }
    return {"schemas": summary, "total_tables": len(summary)}
