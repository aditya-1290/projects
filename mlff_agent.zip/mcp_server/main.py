"""
MCP Server - Terminal 2
Run: uvicorn mcp_server.main:app --host 127.0.0.1 --port 9000 --reload
"""
import sys
import os

# Ensure project root is on path
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from fastapi import Depends, FastAPI
from contextlib import asynccontextmanager

from mcp_server.schemas import ExecuteQueryRequest
from mcp_server.security import verify_api_key
from mcp_server.memory_store import get_cache
from mcp_server.tools.get_schema import get_schema
from mcp_server.tools.execute_query import execute_query
from mcp_server.tools.get_relationships import get_table_relationships
from mcp_server.tools.refresh_cache import refresh_cache
from core.logger import get_logger

logger = get_logger("mcp_server")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Scan DB once on startup and populate in-memory cache."""
    logger.info("MCP Server starting up - scanning database...")
    try:
        from mcp_server.db_scanner import scan_database
        scan_database()
        logger.info("MCP Server ready.")
    except Exception as e:
        logger.error(f"STARTUP ERROR: {e}")
        logger.error("MCP Server started WITHOUT cache. Check your .env PostgreSQL settings.")
    yield
    logger.info("MCP Server shutting down.")


app = FastAPI(title="MLFF MCP Server", version="1.0.0", lifespan=lifespan)


# ── Health ────────────────────────────────────────────────────────────────────

@app.get("/health")
def health():
    cache = get_cache()
    return {
        "status": "ok",
        "cache_populated": cache["metadata"]["last_updated"] is not None,
        "table_count": cache["metadata"]["table_count"],
        "last_updated": cache["metadata"]["last_updated"],
    }


# ── Cache ─────────────────────────────────────────────────────────────────────

@app.get("/cache", dependencies=[Depends(verify_api_key)])
def full_cache():
    """Return full in-memory cache (used by agents)."""
    cache = get_cache()
    # Strip sample_data from response to keep it light
    return {
        "metadata": cache["metadata"],
        "table_map": cache["table_map"],
        "relationships": cache["relationships"],
        "schemas": {
            k: {
                "schema": v.get("schema"),
                "table": v.get("table"),
                "columns": v.get("columns", []),
                "row_count": v.get("row_count", 0),
                "indexes": v.get("indexes", []),
            }
            for k, v in cache["schemas"].items()
        }
    }


# ── Tools ─────────────────────────────────────────────────────────────────────

@app.get("/tools/get_schema", dependencies=[Depends(verify_api_key)])
def tool_get_schema(table_name: str = None):
    return get_schema(table_name)


@app.post("/tools/execute_query", dependencies=[Depends(verify_api_key)])
def tool_execute_query(payload: ExecuteQueryRequest):
    return execute_query(payload.query, payload.params)


@app.get("/tools/get_relationships", dependencies=[Depends(verify_api_key)])
def tool_get_relationships():
    return get_table_relationships()


@app.post("/tools/refresh_cache", dependencies=[Depends(verify_api_key)])
def tool_refresh_cache():
    return refresh_cache()
