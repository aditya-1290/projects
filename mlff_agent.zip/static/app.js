/* ── State ──────────────────────────────────────────────────────── */
let SESSION_ID = null;
let currentChartInstance = null;

/* ── DOM refs ───────────────────────────────────────────────────── */
const queryInput      = document.getElementById('queryInput');
const sendBtn         = document.getElementById('sendBtn');
const sendLabel       = document.getElementById('sendLabel');
const sendSpinner     = document.getElementById('sendSpinner');
const resultArea      = document.getElementById('resultArea');
const metaIntent      = document.getElementById('metaIntent');
const metaType        = document.getElementById('metaType');
const metaConfidence  = document.getElementById('metaConfidence');
const metaSchema      = document.getElementById('metaSchema');
const metaRows        = document.getElementById('metaRows');
const lowConfWarning  = document.getElementById('lowConfidenceWarning');
const errorBox        = document.getElementById('errorBox');
const sqlOutput       = document.getElementById('sqlOutput');
const explanationOut  = document.getElementById('explanationOutput');
const tableHead       = document.getElementById('tableHead');
const tableBody       = document.getElementById('tableBody');
const rowCountLabel   = document.getElementById('rowCountLabel');
const chartCard       = document.getElementById('chartCard');
const chartReasonEl   = document.getElementById('chartReason');
const historyList     = document.getElementById('historyList');

/* ── Status check ───────────────────────────────────────────────── */
async function checkStatus() {
  const dot  = document.getElementById('statusDot');
  const text = document.getElementById('statusText');
  try {
    const r = await fetch('/health');
    if (r.ok) {
      dot.className = 'status-dot online';
      text.textContent = 'System Online';
    } else {
      throw new Error();
    }
  } catch {
    dot.className = 'status-dot offline';
    text.textContent = 'Offline';
  }
}
checkStatus();

/* ── Enter key to submit ────────────────────────────────────────── */
queryInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendQuery();
  }
});

/* ── Send query ─────────────────────────────────────────────────── */
async function sendQuery() {
  const query = queryInput.value.trim();
  if (!query) return;

  setLoading(true);
  clearResult();

  try {
    const resp = await fetch('/query', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: query, session_id: SESSION_ID }),
    });

    if (!resp.ok) {
      const txt = await resp.text();
      throw new Error(txt || `HTTP ${resp.status}`);
    }

    const data = await resp.json();
    SESSION_ID = data.session_id || SESSION_ID;

    renderResult(data, query);
    addToHistorySidebar(query, data);

  } catch (err) {
    showError(err.message || 'Request failed. Check that all 3 terminals are running.');
    resultArea.classList.remove('hidden');
  } finally {
    setLoading(false);
  }
}

/* ── Render result ──────────────────────────────────────────────── */
function renderResult(data, query) {
  resultArea.classList.remove('hidden');

  // ── Meta chips ──
  metaIntent.textContent    = `Intent: ${data.intent || 'N/A'}`;
  metaType.textContent      = `Type: ${data.query_type || 'N/A'}`;
  metaSchema.textContent    = `Schema: ${data.selected_schema || 'N/A'}`;
  metaRows.textContent      = `Rows: ${data.row_count ?? 0}`;

  const conf = data.confidence ?? 0;
  metaConfidence.textContent = `Confidence: ${(conf * 100).toFixed(0)}%`;
  metaConfidence.className = 'meta-chip confidence-chip ' + confidenceClass(conf);

  // ── Low confidence warning ──
  if (data.low_confidence && data.confidence_note) {
    lowConfWarning.textContent = '⚠ ' + data.confidence_note;
    lowConfWarning.classList.remove('hidden');
  } else {
    lowConfWarning.classList.add('hidden');
  }

  // ── Error ──
  if (!data.ok || data.error) {
    showError(data.error || data.explanation || 'An error occurred.');
    if (data.sql) sqlOutput.textContent = data.sql;
    return;
  }

  errorBox.classList.add('hidden');

  // ── SQL ──
  sqlOutput.textContent = data.sql || '-- No SQL generated';

  // ── Explanation ──
  explanationOut.textContent = data.explanation || 'No explanation available.';

  // ── Table ──
  renderTable(data.columns || [], data.rows || []);
  rowCountLabel.textContent = `${data.row_count} row${data.row_count !== 1 ? 's' : ''}`;

  // ── Chart ──
  if (data.chart_type && data.chart_type !== 'none' && data.chart_type !== 'table' && data.rows?.length > 0) {
    chartCard.style.display = 'block';
    chartReasonEl.textContent = data.chart_reason || '';
    renderChart(data.chart_type, data.rows, data.columns);
  } else {
    chartCard.style.display = 'none';
  }
}

/* ── Render table ───────────────────────────────────────────────── */
function renderTable(columns, rows) {
  tableHead.innerHTML = '';
  tableBody.innerHTML = '';

  if (!columns.length && rows.length) {
    columns = Object.keys(rows[0]);
  }

  if (!columns.length) return;

  const tr = document.createElement('tr');
  columns.forEach(col => {
    const th = document.createElement('th');
    th.textContent = col;
    tr.appendChild(th);
  });
  tableHead.appendChild(tr);

  rows.forEach(row => {
    const tr = document.createElement('tr');
    columns.forEach(col => {
      const td = document.createElement('td');
      const val = row[col];
      td.textContent = val === null || val === undefined ? '—' : String(val);
      td.title = td.textContent;
      tr.appendChild(td);
    });
    tableBody.appendChild(tr);
  });
}

/* ── Add to history sidebar ─────────────────────────────────────── */
function addToHistorySidebar(query, data) {
  const empty = historyList.querySelector('.history-empty');
  if (empty) empty.remove();

  const item = document.createElement('div');
  item.className = `history-item ${data.ok ? 'history-ok' : 'history-fail'}`;

  const ts = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  item.innerHTML = `
    <div class="history-query">${escapeHtml(query)}</div>
    <div class="history-meta">${ts} · ${data.row_count ?? 0} rows · ${((data.confidence ?? 0) * 100).toFixed(0)}%</div>
  `;

  item.onclick = () => {
    queryInput.value = query;
  };

  historyList.prepend(item);
}

/* ── Helpers ────────────────────────────────────────────────────── */
function setLoading(on) {
  sendBtn.disabled = on;
  sendLabel.textContent = on ? 'Running...' : 'Run Query';
  sendSpinner.classList.toggle('hidden', !on);
}

function clearResult() {
  errorBox.classList.add('hidden');
  lowConfWarning.classList.add('hidden');
  sqlOutput.textContent = '';
  explanationOut.textContent = '';
  tableHead.innerHTML = '';
  tableBody.innerHTML = '';
  chartCard.style.display = 'none';
  if (currentChartInstance) { currentChartInstance.destroy(); currentChartInstance = null; }
}

function showError(msg) {
  errorBox.textContent = '✖ ' + msg;
  errorBox.classList.remove('hidden');
}

function confidenceClass(conf) {
  if (conf >= 0.75) return 'high';
  if (conf >= 0.60) return 'medium';
  return 'low';
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}
