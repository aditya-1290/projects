/**
 * charts.js
 * Renders Chart.js charts based on agent-suggested chart type and data.
 * Supports: bar, line, pie
 */

const CHART_COLORS = [
  '#00e5ff', '#7c3aed', '#00ff88', '#ffd600', '#ff6b35',
  '#e91e8c', '#4caf50', '#2196f3', '#ff5722', '#9c27b0',
];

function renderChart(chartType, rows, columns) {
  if (currentChartInstance) {
    currentChartInstance.destroy();
    currentChartInstance = null;
  }

  if (!rows || rows.length === 0) return;

  const canvas = document.getElementById('myChart');
  const ctx = canvas.getContext('2d');

  // Determine label and value columns
  const { labelCol, valueCol, valueCols } = detectColumns(rows, columns);

  if (!labelCol || !valueCol) return;

  const labels = rows.map(r => {
    const v = r[labelCol];
    return v === null || v === undefined ? 'N/A' : String(v).substring(0, 20);
  });

  // Limit labels to 20 for readability
  const maxPoints = 20;
  const trimmedLabels  = labels.slice(0, maxPoints);
  const trimmedRows    = rows.slice(0, maxPoints);

  const chartConfig = buildChartConfig(chartType, trimmedLabels, trimmedRows, valueCol, valueCols);

  if (!chartConfig) return;

  currentChartInstance = new Chart(ctx, chartConfig);
}

function detectColumns(rows, columns) {
  if (!columns || !columns.length) {
    columns = Object.keys(rows[0] || {});
  }

  // First non-numeric column as label
  const labelCol = columns.find(col => {
    const val = rows[0]?.[col];
    return isNaN(Number(val)) || typeof val === 'string';
  }) || columns[0];

  // First numeric column as value
  const valueCols = columns.filter(col => {
    const val = rows[0]?.[col];
    return col !== labelCol && !isNaN(Number(val)) && val !== null;
  });

  const valueCol = valueCols[0] || columns[1] || columns[0];

  return { labelCol, valueCol, valueCols };
}

function toNumbers(rows, col) {
  return rows.map(r => {
    const v = r[col];
    return v === null || v === undefined ? 0 : Number(v);
  });
}

function buildChartConfig(chartType, labels, rows, valueCol, valueCols) {
  const baseFont = { family: "'JetBrains Mono', monospace", size: 11 };

  const commonScales = {
    x: {
      ticks: { color: '#9090a8', font: baseFont, maxRotation: 30 },
      grid: { color: '#2a2a35' },
    },
    y: {
      ticks: { color: '#9090a8', font: baseFont },
      grid: { color: '#2a2a35' },
    },
  };

  const commonPlugins = {
    legend: {
      labels: { color: '#e8e8f0', font: baseFont, boxWidth: 12 },
    },
    tooltip: {
      backgroundColor: '#18181f',
      titleColor: '#00e5ff',
      bodyColor: '#e8e8f0',
      borderColor: '#2a2a35',
      borderWidth: 1,
    },
  };

  if (chartType === 'bar') {
    return {
      type: 'bar',
      data: {
        labels,
        datasets: [{
          label: valueCol,
          data: toNumbers(rows, valueCol),
          backgroundColor: CHART_COLORS.map(c => c + 'cc'),
          borderColor: CHART_COLORS,
          borderWidth: 1,
          borderRadius: 4,
        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: commonPlugins,
        scales: commonScales,
      },
    };
  }

  if (chartType === 'line') {
    // Support multiple value columns for line
    const datasets = (valueCols.length > 0 ? valueCols.slice(0, 3) : [valueCol]).map((col, i) => ({
      label: col,
      data: toNumbers(rows, col),
      borderColor: CHART_COLORS[i],
      backgroundColor: CHART_COLORS[i] + '22',
      pointBackgroundColor: CHART_COLORS[i],
      tension: 0.3,
      fill: i === 0,
      pointRadius: 3,
    }));

    return {
      type: 'line',
      data: { labels, datasets },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: commonPlugins,
        scales: commonScales,
      },
    };
  }

  if (chartType === 'pie') {
    const values = toNumbers(rows, valueCol);
    return {
      type: 'pie',
      data: {
        labels,
        datasets: [{
          data: values,
          backgroundColor: CHART_COLORS.map(c => c + 'cc'),
          borderColor: '#0a0a0f',
          borderWidth: 2,
        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          ...commonPlugins,
          legend: {
            position: 'right',
            labels: { color: '#e8e8f0', font: baseFont, boxWidth: 12, padding: 12 },
          },
        },
      },
    };
  }

  return null;
}
