"""
setup_check.py
Run this BEFORE starting the 3 terminals to verify everything is configured.

Usage:
    python setup_check.py
"""
import sys
import os

print("=" * 60)
print("  MLFF ADK - Setup Check")
print("=" * 60)

errors = []
warnings = []

# ── Python version ────────────────────────────────────────────
v = sys.version_info
print(f"\n[1] Python version: {v.major}.{v.minor}.{v.micro}")
if v.major < 3 or (v.major == 3 and v.minor < 10):
    errors.append("Python 3.10+ required.")
else:
    print("    OK")

# ── .env exists ───────────────────────────────────────────────
print("\n[2] Checking .env file...")
if not os.path.exists(".env"):
    errors.append(".env file not found. Copy .env.example to .env and fill in your values.")
else:
    print("    OK - .env found")

# ── Load .env ─────────────────────────────────────────────────
from dotenv import load_dotenv
load_dotenv()

# ── Required packages ─────────────────────────────────────────
print("\n[3] Checking required packages...")
packages = [
    ("fastapi", "fastapi"),
    ("uvicorn", "uvicorn"),
    ("psycopg2", "psycopg2"),
    ("pydantic", "pydantic"),
    ("requests", "requests"),
    ("litellm", "litellm"),
    ("jinja2", "jinja2"),
    ("dotenv", "python-dotenv"),
]

for module, pip_name in packages:
    try:
        __import__(module)
        print(f"    OK - {pip_name}")
    except ImportError:
        errors.append(f"Missing package: {pip_name}. Run: pip install {pip_name}")

# llama_cpp check (optional but needed for Terminal 1)
try:
    import llama_cpp
    print("    OK - llama-cpp-python")
except ImportError:
    warnings.append(
        "llama-cpp-python not installed. Terminal 1 (LLM server) will not work.\n"
        "    Install: pip install llama-cpp-python"
    )

# ── PostgreSQL connection ─────────────────────────────────────
print("\n[4] Checking PostgreSQL connection...")
try:
    import psycopg2
    conn = psycopg2.connect(
        host=os.getenv("POSTGRES_HOST", "127.0.0.1"),
        port=int(os.getenv("POSTGRES_PORT", "5432")),
        user=os.getenv("POSTGRES_USER", "postgres"),
        password=os.getenv("POSTGRES_PASSWORD", "root"),
        dbname=os.getenv("POSTGRES_DATABASE", "dvdrental"),
    )
    cur = conn.cursor()
    cur.execute("SELECT version();")
    ver = cur.fetchone()[0]
    print(f"    OK - Connected: {ver[:50]}")
    cur.execute("""
        SELECT COUNT(*) FROM information_schema.tables
        WHERE table_schema NOT IN ('pg_catalog','information_schema')
    """)
    count = cur.fetchone()[0]
    print(f"    OK - Tables found: {count}")
    conn.close()
except Exception as e:
    errors.append(
        f"PostgreSQL connection failed: {e}\n"
        f"    Check .env: POSTGRES_HOST={os.getenv('POSTGRES_HOST')} "
        f"POSTGRES_DATABASE={os.getenv('POSTGRES_DATABASE')} "
        f"POSTGRES_USER={os.getenv('POSTGRES_USER')}"
    )

# ── GGUF model path ───────────────────────────────────────────
print("\n[5] Checking GGUF model path...")
model_path = os.getenv("GGUF_MODEL_PATH", "")
if not model_path:
    warnings.append("GGUF_MODEL_PATH not set in .env. Set it to your model file path.")
elif not os.path.exists(model_path):
    warnings.append(
        f"GGUF model not found at: {model_path}\n"
        f"    Update GGUF_MODEL_PATH in .env to your actual model file path."
    )
else:
    size_gb = os.path.getsize(model_path) / (1024**3)
    print(f"    OK - Model found: {model_path} ({size_gb:.1f} GB)")

# ── Directories ───────────────────────────────────────────────
print("\n[6] Checking project directories...")
for d in ["logs", "static", "templates", "mcp_server", "agents", "core"]:
    if os.path.isdir(d):
        print(f"    OK - {d}/")
    else:
        errors.append(f"Missing directory: {d}/")

# ── Summary ───────────────────────────────────────────────────
print("\n" + "=" * 60)

if warnings:
    print("\n  WARNINGS:")
    for w in warnings:
        print(f"  ⚠  {w}")

if errors:
    print("\n  ERRORS (must fix before running):")
    for e in errors:
        print(f"  ✖  {e}")
    print("\n  Setup check FAILED. Fix errors above.\n")
    sys.exit(1)
else:
    print("\n  All checks passed!")
    print("\n  Start the system with 3 terminals:")
    print()
    model_path = os.getenv("GGUF_MODEL_PATH", "D:\\Models\\your-model.gguf")
    print(f'  Terminal 1:  python -m llama_cpp.server --model "{model_path}" --host 127.0.0.1 --port 8001 --chat_format chatml --n_ctx 4096')
    print()
    print("  Terminal 2:  uvicorn mcp_server.main:app --host 127.0.0.1 --port 9000 --reload")
    print()
    print("  Terminal 3:  uvicorn app:app --host 127.0.0.1 --port 8000 --reload")
    print()
    print("  Browser:     http://127.0.0.1:8000")
    print()
    print("=" * 60)
