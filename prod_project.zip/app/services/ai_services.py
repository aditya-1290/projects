# from transformers import pipeline
#
# # Load model once (IMPORTANT)
# # qa_pipeline = pipeline(
# #     "text2text-generation",
# #     model="google/flan-t5-base",
# #     max_length=512
# # )
#
#
# def generate_answer(query: str, context_chunks: list[str]) -> str:
#     context = " ".join(context_chunks)
#
#     prompt = f"""
#     Answer the question based on the context.
#
#     Context: {context}
#
#     Question: {query}
#     """
#
#     result = qa_pipeline(prompt)
#
#     return result[0]["generated_text"]
