# from llama_cpp import Llama
from app.services.memory_service import get_history

# Load model ONCE (very important)
# llm = Llama(
#     model_path="D:/python_task/models/mistral_model/mistral-7b-instruct-v0.2.Q4_K_M.gguf",  # 👈 change path
#     n_ctx=4096,   # context size
#     n_threads=4,  # adjust based on CPU
#     n_gpu_layers=0  # set >0 if you have GPU
# )


def generate_answer(query: str, context_chunks: list[str]) -> str:
    pass
#     context = "\n\n".join(context_chunks)
#
#     history = get_history()
#
#     history_text = ""
#     for h in history:
#         history_text += f"User: {h['user']}\nAssistant: {h['assistant']}\n"
#
#     prompt = f"""
# You are a helpful AI assistant.
#
# Answer the question based ONLY on the context below.
#
# Conversation History
# {history_text}
#
# Context:
# {context}
#
# Question:
# {query}
#
# Answer:
# """
#
#     output = llm(
#         prompt,
#         max_tokens=300,
#         temperature=0.3,
#         stop=["Question:", "Context:"]
#     )
#
#     return output["choices"][0]["text"].strip()