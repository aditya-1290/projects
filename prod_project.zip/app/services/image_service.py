from transformers import AutoModelForImageClassification, AutoImageProcessor
from PIL import Image
import torch

MODEL_NAME = "D:/python_tasks/models/classification_model/models/models--google--vit-base-patch16-224/snapshots/3f49326eb077187dfe1c2a2bb15fbd74e6ab91e3"

# Load ONCE (important for performance)
processor = AutoImageProcessor.from_pretrained(MODEL_NAME)
model = AutoModelForImageClassification.from_pretrained(MODEL_NAME)


def classify_image(image_file):
    image = Image.open(image_file).convert("RGB")

    inputs = processor(images=image, return_tensors="pt")

    with torch.no_grad():
        outputs = model(**inputs)

    logits = outputs.logits
    probs = torch.nn.functional.softmax(logits, dim=-1)

    top_probs, top_indices = torch.topk(probs, 5)

    results = []

    for prob, idx in zip(top_probs[0], top_indices[0]):
        label = model.config.id2label[idx.item()]
        results.append({
            "label": label,
            "confidence": float(prob.item())
        })

    return results