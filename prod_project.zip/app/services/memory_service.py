chat_history = []

def add_to_history(user_query: str, answer: str):
    chat_history.append({
        "user": user_query,
        "assistant": answer
    })

def get_history():
    return chat_history[-5] # last 5 messages