import chromadb
from chromadb.utils import embedding_functions
import os
# from fastapi.security import api_key
# from app.core.config import OPEN_API_KEY

# Create persistent DB (stored locally)
client = chromadb.PersistentClient(
    path="D:/python_tasks/prod_project/chroma_db"
)

# OpenAI embedding function
embedding_function = embedding_functions.SentenceTransformerEmbeddingFunction(
    model_name="all-mpnet-base-v2",
    #model_name="text-embedding-3-small"
)

# Create / get collection
collection = client.get_or_create_collection(
    name="documents",
    embedding_function=embedding_function
)

# printing chroma_db path
print("Chroma DB path:", os.path.abspath("D:/python_tasks/prod_project/chroma_db"))