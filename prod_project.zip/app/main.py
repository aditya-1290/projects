from fastapi import FastAPI
from app.api.upload import router as upload_router
from app.api.search import router as search_router
from app.api.image import router as image_router
from app.db.chroma import collection
app = FastAPI()

app.include_router(upload_router)
app.include_router(search_router)
app.include_router(image_router)
@app.get("/")
def root():
    return {"message": "AI Document Search API is running 🚀"}

@app.get("/test-chroma")
def test_chroma():
    collection.add(
        documents=["FastAPI is awesome", "AI is the future"],
        ids=["1","2"]
    )

    results = collection.query(
        query_texts=["What is AI"],
        n_results=2
    )

    return results

@app.get("/debug-chunks")
def debug_chunks():
    results = collection.get()

    return {
        "total_chunks": len(results["documents"]),
        "sample": results["documents"][:5]
    }

@app.get("/debug-embeddings")
def debug_embeddings():
    results = collection.get(include=["embeddings", "documents"])

    return {
        "total": len(results["embeddings"]),
        "sample_embedding": results["embeddings"][0][:10],  # first 10 values
        "sample_text": results["documents"][0]
    }