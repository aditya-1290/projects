from fastapi import APIRouter
from pydantic import BaseModel
from app.db.chroma import collection
from app.services.ai_service import generate_answer
from app.services.memory_service import add_to_history

router = APIRouter()

class QueryRequest(BaseModel):
    query: str
    n_results: int = 3

@router.post("/search")
def search_docs(request: QueryRequest):
    results = collection.query(
        query_texts=[request.query],
        n_results=request.n_results
    )

    return {
        "query": request.query,
        "results": results["documents"][0]
    }

@router.post("/ask")
def ask_question(request: QueryRequest):
    results = collection.query(
        query_texts=[request.query],
        n_results=request.n_results
    )

    chunks = results["documents"][0]

    answer = generate_answer(request.query, chunks)

    add_to_history(request.query, answer)

    return {
        "query": request.query,
        "answer": answer,
        "sources": chunks
    }