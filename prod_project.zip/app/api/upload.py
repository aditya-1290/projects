# from chromadb.db.impl.grpc import client
from fastapi import APIRouter, UploadFile, File
from app.services.pdf_service import extract_text_from_pdf
from app.services.chunking import chunk_text
from app.db.chroma import collection
import uuid
import json
import os

router = APIRouter()

# data path to chunks json file
DATA_PATH = "D:/python_tasks/prod_project/data/chunks.json"

@router.post("/upload")
async def upload_pdf(file:UploadFile = File(...)):
    file_bytes = await file.read()

    # Extract text
    text = extract_text_from_pdf(file_bytes)

    # Chunk Text
    chunks = chunk_text(text)

    # Store in chromaDB
    ids = [str(uuid.uuid4()) for _ in chunks]

    collection.add(
        documents=chunks,
        ids=ids
    )

    # 🔥 SAVE CHUNKS LOCALLY
    if os.path.exists(DATA_PATH):
        with open(DATA_PATH, "r") as f:
            existing = json.load(f)
    else:
        existing = []

    existing.extend(chunks)

    with open(DATA_PATH, "w") as f:
        json.dump(existing, f, indent=2)

    return {
        "message": "Document processed successfully.",
        "chunks_stored": len(chunks)
    }