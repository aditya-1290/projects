from fastapi import APIRouter, UploadFile, File
from app.services.image_service import classify_image

router = APIRouter()

@router.post("/image-check")
async def image_check(file: UploadFile = File(...)):
    results = classify_image(file.file)

    return {
        "predictions": results
    }