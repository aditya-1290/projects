text = "hello"
print(text.append(" world"))