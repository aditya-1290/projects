import threading
import queue
import time

q = queue.Queue()

def producer():
    for i in range(5):
        q.put(i)
    q.put(None)

def consumer():
    while True:
        item = q.get()
        result = 100 / (item - 2)
        print(result)

threading.Thread(target=producer).start()
threading.Thread(target=consumer).start()