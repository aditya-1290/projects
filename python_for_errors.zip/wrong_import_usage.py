import math

print(math.square(5))