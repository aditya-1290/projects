value = "100" + 50
print(value)