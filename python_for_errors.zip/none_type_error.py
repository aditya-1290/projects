def get_value():
    return None

result = get_value()
print(result + 10)