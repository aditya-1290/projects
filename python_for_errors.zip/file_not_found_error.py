with open("non_existent_file.txt", "r") as f:
    content = f.read()
    print(content)