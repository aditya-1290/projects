def test():
    print(x)
    x = 10

test()