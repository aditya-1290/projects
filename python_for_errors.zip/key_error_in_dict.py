data = {"name": "Aditya", "age": 22}
print(data["address"])