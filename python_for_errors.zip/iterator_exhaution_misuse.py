nums = iter([1, 2, 3])
print(next(nums))
print(next(nums))
print(next(nums))
print(next(nums))  # crashes