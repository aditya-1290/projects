"use client";

import React, { useState, Suspense } from "react";
import { signIn } from "next-auth/react";
import { useRouter, useSearchParams } from "next/navigation";

export function LoginForm() {
    const router = useRouter();
    const searchParams = useSearchParams();
    const callbackUrl = searchParams.get("callbackUrl") || "/products";
    
    const [email, setEmail] = useState("alex@example.com");
    const [password, setPassword] = useState("password123");
    const [error, setError] = useState<string | null>(null);
    const [loading, setLoading] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setError(null);

        const res = await signIn("credentials", {
            email, 
            password,
            redirect: false,
        });

        if (res?.error) {
            setError("Invalid email or password.");
            setLoading(false);
        } else {
            router.push(callbackUrl);
            router.refresh();
        }
    };

    return (
        <div className="max-w-md mx-auto py-16">
            <div className="bg-slate-800 border border-slate-700 p-8 rounded-xl shadow-xl space-y-6">
                <div>
                    <h1 className="text-2xl font-bold text-white mb-1">Sign In</h1>
                    <p className="text-slate-400 text-sm">
                        Demo Credentials: <code className="text-blue-400">alex@example.com</code> / <code className="text-blue-400">password123</code>
                    </p>
                </div>

                {error && (
                <div className="bg-red-950/60 border border-red-800 text-red-300 p-3 rounded-lg text-sm">
                    {error}
                </div>
                )}

                <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <label className="block text-xs uppercase font-semibold text-slate-400 mb-1">
                        Email Address
                    </label>
                    <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-sm text-white focus:outline-none focus:border-blue-500"
                    />
                </div>

                <div>
                    <label className="block text-xs uppercase font-semibold text-slate-400 mb-1">
                        Password
                    </label>
                    <input
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-sm text-white focus:outline-none focus:border-blue-500"
                    />
                </div>

                <button
                    type="submit"
                    disabled={loading}
                    className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-all shadow-lg disabled:opacity-50 cursor-pointer"
                >
                    {loading ? "Authenticating..." : "Sign In"}
                </button>
                </form>
            </div>
        </div>
    );
}

// Default export wrapped in a Suspense boundary
export default function LoginPage() {
  return (
    <Suspense fallback={<div className="text-center py-20 text-slate-400">Loading...</div>}>
      <LoginForm />
    </Suspense>
  );
}
