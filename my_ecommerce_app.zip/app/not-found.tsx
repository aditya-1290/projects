import Link from "next/link";

export default function NotFound() {
    return (
        <div className="max-w-md mx-auto py-20 text-center space-y-4">
            <div className="bg-slate-800 border border-slate-700 p-8 rounded-xl shadow-xl">
                <h1 className="text-6xl font-extrabold text-blue-500 mb-2">404</h1>
                <h2 className="text-xl font-bold text-white mb-2">Page Not Found</h2>
                <p className="text-slate-400 text-sm mb-6">
                    The page or product you are looking for does not exist or has been moved.
                </p>

                <Link
                    href="/products"
                    className="inline-block w-full py-3 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-medium rounded-lg transition-all text-center shadow-lg"
                >
                    Return to Catalogue
                </Link>
            </div>
        </div>
    );
}
