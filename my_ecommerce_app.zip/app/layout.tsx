import type { Metadata } from "next";
import "./globals.css";
import { CartProvider } from "@/context/CartContext";
import { ToastProvider } from "@/context/ToastContext";
import Provider from "@/components/Providers";
import Navbar from "@/components/Navbar";

export const metadata: Metadata = {
  title: "TechStore - Modern E-Commerce",
  description: "High performance tech store.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="bg-slate-900 text-slate-100 min-h-screen">
        <Provider>
          <ToastProvider>
            <CartProvider>
              <Navbar />
              <main className="max-w-7xl mx-auto px-4 py-6">
                {children}
              </main>
            </CartProvider>
          </ToastProvider>
        </Provider>
      </body>
    </html>
  );
}