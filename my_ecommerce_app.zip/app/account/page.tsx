import React from "react";
import { auth } from "@/auth";
import { redirect } from "next/navigation";
import Link from "next/link";

export default async function AccountPage() {
    // Fetch authenticated session on the server
    const session = await auth();

    // Fallback protection if reached without authenticatoion
    if (!session?.user) {
        redirect("/login?callbackUrl=/account")
    }

    const user = session.user;

    return (
        <div className="max-w-2xl mx-auto py-8 space-y-6">
            <div className="bg-slate-800/60 border border-slate-700/80 p-5 rounded-xl space-y-2">
                <h3 className="font-semmibold text-white">📦 Recent Orders</h3>
                <p className="text-slate-400 text-xs">View past order details and download receipt invoices.</p>
                <Link
                    href="/cart"
                    className="inline-block text-xs text-blue-400 hover:underline font-medium pt-2"
                >
                    Go to Cart & Order History →
                </Link>
            </div>

            <div className="bg-slate-800/60 border border-slate-700/80 p-5 rounded-xl space-y-2">
                <h3 className="font-semibold text-white">💳 Payment Methods</h3>
                <p className="text-slate-400 text-xs">Manage saved credit cards and default shipping addresses.</p>
                <span className="inline-block text-xs text-slate-500 pt-2">Simulated Account Settings</span>
            </div>
        </div>
    );
}
