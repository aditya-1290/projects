export default function AboutPAge() {
    return (
        <div className="space-y-4">
        <h1 className="text-3xl font-bold">About TechStore</h1>
        <p className="text-slate-300">
            This application is built as part of the 30-Day Fullstack JS/TS Mastery Curriculum.
        </p>
        <div className="p-4 bg-slate-800 border border-slate-700 rounded-md">
            <h3 className="font-semibold text-lg text-blue-400 mb-1">Architecture Highlights</h3>
            <ul className="list-disc list-inside text-slate-300 space-y-1">
            <li>Next.js App Router File-System Routing</li>
            <li>TypeScript Strict Type Checking</li>
            <li>Reusable Component Patterns & Custom Hooks</li>
            </ul>
        </div>
        </div>
    );
}