export default function ProductsLoading() {
    return (
        <div className="animate-pulse space-y-6">
            {/* Title Placeholder */}
            <div className="h-9 bg-slate-800 rounded-md w-64 mb-6"></div>

            {/* Filter Bar Placeholder */}
            <div className="h-20 bg-slate-800 rounded-xl border border-slate-700/50"></div>

            {/* Product Cards Grid Skeleton */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3  gap-6 mt-8">
                {Array.from({ length: 6 }).map((_, index) => (
                    <div
                        key={index}
                        className="bg-slate-800/60 border border-slate-700/50 rounded-lg p-5 h-80 flex flex-col justify-between"
                    >
                        <div>
                            <div className="h-40 bg-slate-700/50 rounded-md mb-4"></div>
                            <div className="h-3 bg-blue-500/30 rounded w-1/4 mb-2"></div>
                            <div className="h-5 bg-slate-700/60 rounded w-3/4"></div>
                        </div>
                        <div className="flex justify-between items-center pt-3 border-t border-slate-700/50">
                            <div className="h-6 bg-emerald-500/30 rounded w-20"></div>
                            <div className="h-8 bg-blue-600/30 rounded w-24"></div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}
