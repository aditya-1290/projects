"use client";

import React, { useEffect } from "react";

interface ErrorProps {
    error: Error & { digest?: string };
    reset: () => void;
}

export default function ProductsError({ error ,reset }: ErrorProps) {
    useEffect(() => {
        // Log error to an error reporting device
        console.error("Caught inside error boundary:", error);
    }, [error]);

    return (
        <div className="max-w-mdd mx-auto my-12 bg-slate-800 border border-red-800/60 rounded-xl p-8 text-center shadow-xl">
            <div className="w-14 h-14 bg-red-950/80 border border-red-700 text-red-400 rounded-full flex items-center justify-center mx-auto text-2xl mb-4">
                ⚠️
            </div>
            <h2 className="text-xl font-bold text-white mb-2">Something went wrong!</h2>
            <p className="text-slate-300 text-sm mb-6 leading-relaxed">
                We encountered an error while loading the product catalogue.
            </p>

            <button
                onClick={() => reset()}
                className="px-5 py-2.5 bg-red-600 hover:bg-red-700 text-white text-sm font-medium rounded-lg transition-colors cursor-pointer shadow-md"
            >
                Try Again
            </button>
        </div>
    );
} 