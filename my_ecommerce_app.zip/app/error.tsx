"use client";

import React, { useEffect } from "react";

export default function Error({
    error, 
    reset,
} : {
    error: Error & { digest?: string };
    reset: () => void;
}) {
    useEffect(() => {
        // Log the error to an analytics or logging service
        console.error("Application Error Captured:", error);
    }, [error]);

    return (
        <div className="max-w-md mx-auto py-20 text-center space-y-4">
            <div className="bg-slate-800 border border-red-900/50 p-8 rounded-xl shadow-xl">
                <div className="w-12 h-12 bg-red-500/20 text-red-400 rounded-full flex items-center mx-auto text-2xl font-bold mb-4">
                    !
                </div>
                <h2 className="text-2xl font-bold text-white mb-2">Something went wrong</h2>
                <p className="text-slate-400 text-sm mb-6">
                    An unexpected error occurred while loading this section.
                </p>

                <button
                    onClick={() => reset()}
                    className="w-full py-3 bg-red-600 hover:bg-red-700 active:scale-95 text-white font-medium rounded-lg transition-all cursor-pointer shadow-lg"
                >
                    Try Again
                </button>
            </div>
        </div>
    );
}
