"use client";

import React from "react";
import Link from "next/link";
import { useCart } from "@/context/CartContext";

export default function CartPage() {
  const { cart, removeFromCart, updateQuantity, totalAmount, clearCart } = useCart();

  if (cart.length === 0) {
    return (
      <div className="max-w-2xl mx-auto py-16 text-center space-y-4">
        <h1 className="text-3xl font-bold text-white">Your Cart is Empty</h1>
        <p className="text-slate-400">Looks like you haven't added anything to your cart yet.</p>
        <Link
          href="/products"
          className="inline-block px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-all"
        >
          Explore Products
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto py-8 space-y-6">
      <div className="flex justify-between items-center border-b border-slate-700 pb-4">
        <h1 className="text-3xl font-bold text-white">Shopping Cart</h1>
        <button
          onClick={clearCart}
          className="text-sm text-red-400 hover:text-red-300 transition-colors"
        >
          Clear Cart
        </button>
      </div>

      {/* Cart Items List */}
      <div className="space-y-4">
        {cart.map((item) => (
          <div
            key={item.id}
            className="flex items-center justify-between bg-slate-800 border border-slate-700 p-4 rounded-xl"
          >
            <div className="flex items-center gap-4">
              <img
                src={item.image}
                alt={item.title}
                className="w-16 h-16 object-contain bg-white p-2 rounded-lg"
              />
              <div>
                <h3 className="font-semibold text-white text-sm line-clamp-1">{item.title}</h3>
                <p className="text-slate-400 text-xs">${item.price} each</p>
              </div>
            </div>

            <div className="flex items-center gap-6">
              {/* Quantity Selector */}
              <div className="flex items-center gap-2 bg-slate-900 border border-slate-700 rounded-lg p-1">
                <button
                  onClick={() => updateQuantity(item.id, item.quantity - 1)}
                  className="w-6 h-6 flex items-center justify-center text-slate-300 hover:bg-slate-800 rounded"
                >
                  -
                </button>
                <span className="text-sm font-semibold w-6 text-center">{item.quantity}</span>
                <button
                  onClick={() => updateQuantity(item.id, item.quantity + 1)}
                  className="w-6 h-6 flex items-center justify-center text-slate-300 hover:bg-slate-800 rounded"
                >
                  +
                </button>
              </div>

              <span className="font-bold text-white min-w-[70px] text-right">
                ${(item.price * item.quantity).toFixed(2)}
              </span>

              <button
                onClick={() => removeFromCart(item.id)}
                className="text-red-400 hover:text-red-300 text-sm"
              >
                ✕
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Summary Footer */}
      <div className="bg-slate-800 border border-slate-700 p-6 rounded-xl flex flex-col md:flex-row justify-between items-center gap-4">
        <div>
          <p className="text-slate-400 text-sm">Total Subtotal</p>
          <p className="text-3xl font-extrabold text-white">${totalAmount.toFixed(2)}</p>
        </div>

        {/* Proceed to Checkout -> Navigates to /checkout */}
        <Link
          href="/checkout"
          className="w-full md:w-auto px-8 py-3 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg shadow-lg text-center transition-all"
        >
          Proceed to Checkout →
        </Link>
      </div>
    </div>
  );
}
