"use client";

import React, { useState } from "react";
import Link from "next/link";
import { useCart } from "@/context/CartContext";

interface FormData {
    fullName: string;
    email: string;
    address: string;
    city: string;
    zipCode: string;
    cardNumber: string;
    expiry: string;
    cvv: string;
}

interface FormErrors {
    [key: string]: string;
}

export default function CheckoutPage() {
    const { cart, totalPrice, removeFromCart } = useCart();

    // Form State
    const [formData, setFormData] = useState<FormData>({
        fullName: "",
        email: "",
        address: "",
        city: "",
        zipCode: "",
        cardNumber: "",
        expiry: "",
        cvv: "",
    });

    const [errors, setErrors] = useState<FormErrors>({});
    const [isSubmitted, setIsSubmitted] = useState(false);
    const [orderId, setOrderId] = useState<string>("");

    // Handle Input Changes
    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData((prev) => ({ ...prev, [name]: value}));
        // Clear error as user types
        if (errors[name]) {
            setErrors((prev) => ({ ...prev, [name]: ""}));
        }
    };

    // Basic Validation Function
    const validateForm = (): boolean => {
        const newErrors: FormErrors = {};

        if (!formData.fullName.trim()) newErrors.fullName = "Full Name is required.";
        if (!formData.email.includes("@")) newErrors.email = "Enter a valid email address.";
        if (!formData.address.trim()) newErrors.address = "Shipping address is required.";
        if (!formData.city.trim()) newErrors.city = "City is required.";
        if (!/^\d{6}$/.test(formData.zipCode)) newErrors.zipCode = "Enter a valid 5-digit ZIP code.";
        if (!/^\d{16}$/.test(formData.cardNumber.replace(/\s/g, ""))) {
        newErrors.cardNumber = "Enter a valid 16-digit card number.";
        }
        if (!/^\d{2}\/\d{2}$/.test(formData.expiry)) {
        newErrors.expiry = "Use MM/YY format.";
        }
        if (!/^\d{3}$/.test(formData.cvv)) {
        newErrors.cvv = "3-digit CVV required.";
        }

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    //Handle Form Submission
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();

        if (!validateForm()) return;

        // Generate random Order ID & set success rate
        const genaratedId = "ORD-" + Math.floor(100000 + Math.random() * 900000);
        setOrderId(genaratedId);
        setIsSubmitted(true);

        // Clear itemsfrom cart context
        cart.forEach((item) => removeFromCart(item.id));
    };

    // Order Success Screen
    if (isSubmitted){
        return (
            <div className="max-w-xl mx-auto my-12 bg-slate-800 border border-slate-700 rounded-xl p-8 text-center shadow-2xl">
                <div className="w-16 h-16 bg-emerald-900/60 border border-emerald-500 text-emarald-400 ronded-full flex items-center justify-center mx-auto text-3xl mb-4">
                   ✓
                </div>
                <h2 className="text-2xl font-bold text-white mb-2">Order Confirmed!</h2>
                <p className="text-slate-300 text-sm mb-4">
                    Thank you for your purchase, <span className="font-semibold text-emerald-400">{formData.fullName}</span>
                </p>
                <div className="bg-slate-900 p-4 rounded-lg text-left text text-xs font-mono text-slate-400 space-y-1 mb-6">
                    <p>Order ID: <span className="text-slate-200 font-bold">{orderId}</span></p>
                    <p>Confirmation sent to: <span className="text-slate-200">{formData.email}</span></p>
                    <p>Shipping to: <span className="text-slate-200">{formData.address}, {formData.city}</span></p>
                </div>
                <Link
                    href="/products"
                    className="inline-block px-6-py-3 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors"
                >
                    Back to Catalogue
                </Link>
            </div>
        );
    }

    // Redirect if cart is empty before starting checkout
  if (cart.length === 0) {
    return (
      <div className="max-w-md mx-auto my-12 bg-slate-800 border border-slate-700 rounded-xl p-8 text-center">
        <h2 className="text-xl font-bold text-slate-200 mb-2">Your Cart is Empty</h2>
        <p className="text-sm text-slate-400 mb-6">Add items to your cart before proceeding to checkout.</p>
        <Link
          href="/products"
          className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-lg transition-colors"
        >
          Explore Products
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">Checkout</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Checkout Form */}
        <form onSubmit={handleSubmit} className="lg:col-span-2 space-y-6">
          {/* Shipping Info */}
          <div className="bg-slate-800 border border-slate-700 rounded-xl p-6 shadow-md space-y-4">
            <h3 className="text-lg font-semibold text-white border-b border-slate-700 pb-2">
              1. Shipping Address
            </h3>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Full Name</label>
              <input
                type="text"
                name="fullName"
                value={formData.fullName}
                onChange={handleChange}
                placeholder="Jane Doe"
                className="w-full bg-slate-900 border border-slate-700 rounded p-2.5 text-sm text-white focus:outline-none focus:border-blue-500"
              />
              {errors.fullName && <p className="text-xs text-red-400 mt-1">{errors.fullName}</p>}
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Email Address</label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="jane@example.com"
                className="w-full bg-slate-900 border border-slate-700 rounded p-2.5 text-sm text-white focus:outline-none focus:border-blue-500"
              />
              {errors.email && <p className="text-xs text-red-400 mt-1">{errors.email}</p>}
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Street Address</label>
              <input
                type="text"
                name="address"
                value={formData.address}
                onChange={handleChange}
                placeholder="123 Main St"
                className="w-full bg-slate-900 border border-slate-700 rounded p-2.5 text-sm text-white focus:outline-none focus:border-blue-500"
              />
              {errors.address && <p className="text-xs text-red-400 mt-1">{errors.address}</p>}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">City</label>
                <input
                  type="text"
                  name="city"
                  value={formData.city}
                  onChange={handleChange}
                  placeholder="New York"
                  className="w-full bg-slate-900 border border-slate-700 rounded p-2.5 text-sm text-white focus:outline-none focus:border-blue-500"
                />
                {errors.city && <p className="text-xs text-red-400 mt-1">{errors.city}</p>}
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">ZIP Code</label>
                <input
                  type="text"
                  name="zipCode"
                  value={formData.zipCode}
                  onChange={handleChange}
                  placeholder="100001"
                  className="w-full bg-slate-900 border border-slate-700 rounded p-2.5 text-sm text-white focus:outline-none focus:border-blue-500"
                />
                {errors.zipCode && <p className="text-xs text-red-400 mt-1">{errors.zipCode}</p>}
              </div>
            </div>
          </div>

          {/* Payment Info */}
          <div className="bg-slate-800 border border-slate-700 rounded-xl p-6 shadow-md space-y-4">
            <h3 className="text-lg font-semibold text-white border-b border-slate-700 pb-2">
              2. Payment Details
            </h3>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Card Number</label>
              <input
                type="text"
                name="cardNumber"
                value={formData.cardNumber}
                onChange={handleChange}
                placeholder="4532123456789012"
                maxLength={16}
                className="w-full bg-slate-900 border border-slate-700 rounded p-2.5 text-sm text-white focus:outline-none focus:border-blue-500"
              />
              {errors.cardNumber && <p className="text-xs text-red-400 mt-1">{errors.cardNumber}</p>}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Expiry (MM/YY)</label>
                <input
                  type="text"
                  name="expiry"
                  value={formData.expiry}
                  onChange={handleChange}
                  placeholder="12/28"
                  maxLength={5}
                  className="w-full bg-slate-900 border border-slate-700 rounded p-2.5 text-sm text-white focus:outline-none focus:border-blue-500"
                />
                {errors.expiry && <p className="text-xs text-red-400 mt-1">{errors.expiry}</p>}
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">CVV</label>
                <input
                  type="text"
                  name="cvv"
                  value={formData.cvv}
                  onChange={handleChange}
                  placeholder="123"
                  maxLength={3}
                  className="w-full bg-slate-900 border border-slate-700 rounded p-2.5 text-sm text-white focus:outline-none focus:border-blue-500"
                />
                {errors.cvv && <p className="text-xs text-red-400 mt-1">{errors.cvv}</p>}
              </div>
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg transition-colors cursor-pointer shadow-lg"
          >
            Complete Order (${totalPrice.toFixed(2)})
          </button>
        </form>

        {/* Mini Order Summary Sidebar */}
        <div className="bg-slate-800 border border-slate-700 rounded-xl p-6 h-fit shadow-md">
          <h3 className="text-lg font-semibold text-white mb-4 border-b border-slate-700 pb-2">
            Order Summary
          </h3>
          <div className="space-y-3 mb-4 max-h-60 overflow-y-auto pr-1">
            {cart.map((item) => (
              <div key={item.id} className="flex justify-between text-xs text-slate-300">
                <span className="truncate max-w-[160px]">{item.title} (x{item.quantity})</span>
                <span className="font-mono text-emerald-400">${(item.price * item.quantity).toFixed(2)}</span>
              </div>
            ))}
          </div>
          <div className="border-t border-slate-700 pt-3 flex justify-between font-bold text-white text-lg">
            <span>Total:</span>
            <span className="text-emerald-400">${totalPrice.toFixed(2)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
