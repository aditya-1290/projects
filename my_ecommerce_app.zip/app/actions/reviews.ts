"use server";

import { revalidatePath } from "next/cache";

export interface ActionState {
  success?: boolean;
  message?: string;
  errors?: {
    author?: string;
    comment?: string;
    rating?: string;
  };
}

export async function submitReviewAction(
  prevState: ActionState,
  formData: FormData
): Promise<ActionState> {
  // 1. Extract form values
  const author = formData.get("author") as string;
  const comment = formData.get("comment") as string;
  const rating = formData.get("rating") as string;
  const productId = formData.get("productId") as string;

  // 2. Validate input fields
  const errors: ActionState["errors"] = {};

  if (!author || author.trim().length < 2) {
    errors.author = "Name must be at least 2 characters long.";
  }
  if (!comment || comment.trim().length < 10) {
    errors.comment = "Review must be at least 10 characters long.";
  }
  if (!rating || Number(rating) < 1 || Number(rating) > 5) {
    errors.rating = "Please select a valid rating between 1 and 5 stars.";
  }

  // Return validation errors if present
  if (Object.keys(errors).length > 0) {
    return { success: false, errors };
  }

  // 3. Simulate backend DB insert delay
  await new Promise((resolve) => setTimeout(resolve, 800));

  console.log("Review saved to database:", {
    productId,
    author,
    comment,
    rating: Number(rating),
    createdAt: new Date().toISOString(),
  });

  // 4. Invalidate cache for the product page so updated reviews display instantly
  revalidatePath(`/products/${productId}`);

  return {
    success: true,
    message: "Thank you! Your review has been published.",
  };
}
