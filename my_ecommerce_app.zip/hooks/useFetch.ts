"use client";

import { useState, useEffect } from "react";

// Generic state interface that accepts type parameter T
export interface FetchResult<T> {
    data: T | null;
    loading: boolean;
    error: string | null;
}

// reusable Custom Hook with Generic Type T
export function useFetch<T>(url: string): FetchResult<T> {
    const [data, setData] = useState<T | null>(null);
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        let isMounted = true;
        setLoading(true);

        fetch(url)
            .then((res) => {
                if (!res.ok) {
                    throw new Error(`HTTP Error! Status: ${res.status}`);
                }
                return res.json();
            })
            .then((responseData: T) => {
                if (isMounted) {
                    setData(responseData);
                    setError(null);
                }
            })
            .catch((err: Error) => {
                if (isMounted) {
                    setError(err.message);
                }
            })
            .finally(() => {
                if (isMounted) {
                    setLoading(false);
                }
            });
        // Clean-up logic on unmount or URL change
        return () => {
            isMounted = false;
        };
    }, [url]);

    return { data, loading, error };
}
