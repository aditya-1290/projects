import { useState, useEffect, use } from "react";

/**
 * Custom hook that delays updating a value until a specified delay has passed.
 * @param value The fast-changing value (e.g., search query input)
 * @param delay Delay in milliseconds (default: 300ms)
 */

export function useDebounce<T>(value: T, delay: number = 300): T {
    const [debouncedValue, setDebouncedValue] = useState<T>(value);

    useEffect(() => {
        // Set up a timer to update debouncedValue after the delay
        const timer = setTimeout(() => {
            setDebouncedValue(value);
        }, delay);

        // Cleanup function: cancel the timer if value or delay changes before completion
        return () => {
            clearTimeout(timer);
        };
    }, [value, delay]);

    return debouncedValue;
}