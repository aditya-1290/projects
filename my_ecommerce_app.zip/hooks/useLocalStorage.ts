"use client";

import { useState, useEffect, use } from "react";

export function useLocalStorage<T>(key: string, initialValue: T) {
    // Initialize state with initialValue to prevent server/client mismatch
    const [storedValue, setStoredValue] = useState<T>(initialValue);
    const [isHydrated, setIsHydrated] = useState(false);

    // Read from localStorage after initial render on the client 
    useEffect(() => {
        try {
            const item = window.localStorage.getItem(key);
            if (item) {
                setStoredValue(JSON.parse(item));
            } 
        } catch (error) {
            console.error(`Error reading localStorage key "${key}":`, error);
        } finally {
            setIsHydrated(true);
        }
    }, [key]);

    // Save to localStorage whenever key or storedValue changes
    useEffect(() => {
        if (!isHydrated) return; // Don't overwrite localStorage before initial load

        try {
            window.localStorage.setItem(key, JSON.stringify(storedValue));
        } catch (error) {
            console.error(`Error saveing to localStorage key "${key}":`, error);
        }
    }, [key, storedValue, isHydrated]);

    return [storedValue, setStoredValue] as const;
}
