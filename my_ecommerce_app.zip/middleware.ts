import { auth } from "@/auth";
import { NextResponse } from "next/server";

export default auth((req) => {
  const isLoggedIn = !!req.auth;
  const { pathname } = req.nextUrl;

  const protectedRoutes = ["/checkout", "/account"];
  const isProtected = protectedRoutes.some((route) => pathname.startsWith(route));

  if (isProtected && !isLoggedIn) {
    const loginUrl = new URL("/login", req.nextUrl.origin);
    loginUrl.searchParams.set("callbackUrl", pathname);
    return NextResponse.redirect(loginUrl);
  }

  // Redirect to home if logged in user tries to visit /login
  if (pathname === "/login" && isLoggedIn) {
    return NextResponse.redirect(new URL("/products", req.nextUrl.origin));
  }

  return NextResponse.next();
});

export const config = {
  matcher: ["/:path*", "/checkout/:path*", "/account/:path*", "/login"],
};
