"use client";

import React from "react";
import Link from "next/link";
import Image from "next/image";
import { Product } from "@/app/products/page";
import { useCart } from "@/context/CartContext";

export default function ProductCard({ product }: { product: Product }) {
  // Use global CartContext directly instead of prop callbacks
  const { addToCart } = useCart();

  return (
    <div className="bg-slate-800 border border-slate-700/60 hover:border-slate-600 rounded-xl p-5 flex flex-col justify-between transition-all hover:shadow-lg hover:-translate-y-0.5">
      <div>
        {/* Optimized Image Container */}
        <div className="relative w-full h-48 bg-slate-900 rounded-lg p-4 mb-4 flex items-center justify-center overflow-hidden">
          <Image
            src={product.image}
            alt={product.title}
            fill
            sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
            className="object-contain p-2 hover:scale-105 transition-transform duration-300"
          />
        </div>

        <span className="text-[10px] font-bold uppercase tracking-wider text-blue-400 bg-blue-950/80 border border-blue-800/50 px-2 py-0.5 rounded-full">
          {product.category}
        </span>

        <h3 className="text-base font-semibold text-white mt-2 mb-1 line-clamp-1">
          {product.title}
        </h3>

        <p className="text-slate-400 text-xs line-clamp-2 mb-4">
          {product.description}
        </p>
      </div>

      <div className="flex items-center justify-between pt-3 border-t border-slate-700/60">
        <span className="text-lg font-bold text-emerald-400">
          ${product.price.toFixed(2)}
        </span>

        <div className="flex items-center gap-2">
          <Link
            href={`/products/${product.id}`}
            className="px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-700/50 hover:bg-slate-700 rounded-md transition-colors"
          >
            Details
          </Link>
          <button
            onClick={() => addToCart(product)}
            className="px-3 py-1.5 text-xs font-medium bg-blue-600 hover:bg-blue-700 active:scale-95 text-white rounded-md transition-all cursor-pointer shadow"
          >
            + Add to Cart
          </button>
        </div>
      </div>
    </div>
  );
}
