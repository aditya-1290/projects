"use client";

import React, { useActionState } from "react";
import { useFormStatus } from "react-dom";
import { submitReviewAction, ActionState } from "@/app/actions/reviews";

// Submit button sub-component to consume useFormStatus
function SubmitButton() {
  const { pending } = useFormStatus();

  return (
    <button
      type="submit"
      disabled={pending}
      className="w-full py-3 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-medium rounded-lg transition-all cursor-pointer shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
    >
      {pending ? "Submitting Review..." : "Submit Review"}
    </button>
  );
}

export default function ReviewForm({ productId }: { productId: string }) {
  const initialState: ActionState = {};
  const [state, formAction] = useActionState(submitReviewAction, initialState);

  return (
    <div className="bg-slate-800 border border-slate-700 p-6 rounded-xl mt-8 shadow-md">
      <h3 className="text-xl font-bold text-white mb-4">Leave a Review</h3>

      {state.success && (
        <div className="bg-emerald-950/60 border border-emerald-800 text-emerald-300 p-4 rounded-lg text-sm mb-6">
          ✓ {state.message}
        </div>
      )}

      <form action={formAction} className="space-y-4">
        {/* Hidden field to pass productId */}
        <input type="hidden" name="productId" value={productId} />

        {/* Name Input */}
        <div>
          <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
            Your Name
          </label>
          <input
            type="text"
            name="author"
            placeholder="e.g. Sarah Connor"
            className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-sm text-white focus:outline-none focus:border-blue-500"
          />
          {state.errors?.author && (
            <p className="text-red-400 text-xs mt-1">{state.errors.author}</p>
          )}
        </div>

        {/* Rating Select */}
        <div>
          <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
            Rating
          </label>
          <select
            name="rating"
            defaultValue="5"
            className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-sm text-white focus:outline-none focus:border-blue-500"
          >
            <option value="5">★★★★★ (5/5)</option>
            <option value="4">★★★★☆ (4/5)</option>
            <option value="3">★★★☆☆ (3/5)</option>
            <option value="2">★★☆☆☆ (2/5)</option>
            <option value="1">★☆☆☆☆ (1/5)</option>
          </select>
          {state.errors?.rating && (
            <p className="text-red-400 text-xs mt-1">{state.errors.rating}</p>
          )}
        </div>

        {/* Comment Input */}
        <div>
          <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
            Review
          </label>
          <textarea
            name="comment"
            rows={3}
            placeholder="What did you think of this product?"
            className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-sm text-white focus:outline-none focus:border-blue-500 resize-none"
          />
          {state.errors?.comment && (
            <p className="text-red-400 text-xs mt-1">{state.errors.comment}</p>
          )}
        </div>

        <SubmitButton />
      </form>
    </div>
  );
}
