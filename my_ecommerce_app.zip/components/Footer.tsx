export default function Footer() {
  return (
    <footer className="w-full bg-slate-950 text-slate-400 p-4 text-center mt-auto border-t border-slate-800">
      <p>&copy; 2026 TechStore Inc. All rights reserved.</p>
    </footer>
  );
}