import React from "react";

// Expicit Typescript Interface for properties
export interface ButtonProps {
    label: string;
    onClick: () => void;
    variant?: "primary" | "secondary" | "danger";
    disabled?: boolean;
}

export const Button: React.FC<ButtonProps> = ({
    label,
    onClick,
    variant = "primary",
    disabled = false,
}) => {
    const baseStyles = "px-4 py-2 rounded-md font-medium transition-all duration-200 focus:outline-none";

    const variantStyles = {
        primary: "bg-blue-600 hover:bg-blue-700 text-white shadow-sm",
        secondary: "bg-slate-700 hover:bg-slate-600 text-slate-200",
        danger: "bg-red-600 hover:bg-red-700 text-white",
    };

    return (
        <button
            className={`${baseStyles} ${variantStyles[variant]} ${disabled ? "opacity-50 cursor-not-allowed" : "cursor-pointer"}`}
            onClick={onClick}
            disabled={disabled}
            >
                {label}
            </button>
    );
};
