"use client";

import React from "react";
import Link from "next/link";
import { useSession, signOut } from "next-auth/react";
import { useCart } from "@/context/CartContext";

export default function Navbar() {
  const { data: session, status } = useSession();
  const { totalItems } = useCart();

  return (
    <header className="bg-slate-800/80 backdrop-blur-md border-b border-slate-700 sticky top-0 z-50 mb-8">
      <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
        
        {/* Brand / Logo */}
        <Link href="/products" className="text-xl font-bold text-white tracking-wide flex items-center gap-2">
          <span className="text-blue-500">⚡</span> TechStore
        </Link>

        {/* Center Links */}
        <nav className="flex items-center gap-6 text-sm font-medium text-slate-300">
          <Link href="/products" className="hover:text-white transition-colors">
            Catalogue
          </Link>
          {session?.user && (
            <Link href="/account" className="hover:text-white transition-colors">
              My Account
            </Link>
          )}
        </nav>

        {/* Right Actions: Cart & Auth State */}
        <div className="flex items-center gap-4">
          
          {/* Cart Icon */}
          <Link
            href="/cart"
            className="relative bg-slate-900 border border-slate-700 hover:border-slate-600 px-3 py-1.5 rounded-lg text-sm text-slate-200 flex items-center gap-2 transition-all"
          >
            🛒 <span className="hidden sm:inline">Cart</span>
            {totalItems > 0 && (
              <span className="bg-blue-600 text-white text-xs font-bold px-2 py-0.5 rounded-full">
                {totalItems}
              </span>
            )}
          </Link>

          {/* Auth State */}
          {status === "loading" ? (
            <div className="w-20 h-8 bg-slate-700/50 animate-pulse rounded-lg" />
          ) : session?.user ? (
            <div className="flex items-center gap-3">
              <Link href="/account" className="flex items-center gap-2 group">
                <img
                  src={session.user.image || "https://api.dicebear.com/7.x/avataaars/svg?seed=User"}
                  alt={session.user.name || "User"}
                  className="w-8 h-8 rounded-full bg-slate-700 border border-slate-600 group-hover:border-blue-400 transition-colors"
                />
                <span className="text-xs font-medium text-slate-200 hidden md:inline truncate max-w-[100px]">
                  {session.user.name}
                </span>
              </Link>

              <button
                onClick={() => signOut({ callbackUrl: "/login" })}
                className="text-xs bg-red-950/40 hover:bg-red-900/60 border border-red-800 text-red-300 px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
              >
                Logout
              </button>
            </div>
          ) : (
            <Link
              href="/login"
              className="text-xs bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium transition-colors shadow-sm"
            >
              Sign In
            </Link>
          )}
        </div>

      </div>
    </header>
  );
}
