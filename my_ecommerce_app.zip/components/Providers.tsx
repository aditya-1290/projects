"use client";

import React from "react";
// import { CartProvider } from "@/context/CartContext";
import { SessionProvider } from "next-auth/react";

// export function Providers({ children }: { children: React.ReactNode}) {
//     return <CartProvider>{children}</CartProvider>;
// }

export default function Providers({ children }: { children: React.ReactNode }) {
    return <SessionProvider>{children}</SessionProvider>
}
