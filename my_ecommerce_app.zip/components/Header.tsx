export default function Header() {
    return (
    <header className="w-full bg-slate-900 text-white p-4 shadow-md flex justify-between items-center">
      <h1 className="text-xl font-bold">TechStore E-Commerce</h1>
      <nav className="space-x-4">
        <a href="#" className="hover:underline">Home</a>
        <a href="#" className="hover:underline">Products</a>
      </nav>
    </header>
    );
}