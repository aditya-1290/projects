import React from "react";

// Explicit Interface defining title and the React children node
export interface WrapperProps {
    title: string;
    children: React.ReactNode; // Strictly typed nested JSX/components 

}

export const Wrapper: React.FC<WrapperProps> = ({title, children}) => {
    return (
    <section className="bg-slate-800 border border-slate-700 rounded-lg p-6 my-4 shadow-md">
      <h3 className="text-xl font-semibold mb-4 text-slate-100 border-b border-slate-700 pb-2">
        {title}
      </h3>
      <div className="wrapper-content">{children}</div>
    </section>
    );
};