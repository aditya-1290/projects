"use client";

import React, { createContext, useContext, useState, ReactNode } from "react";

export interface Toast {
  id: string;
  message: string;
  type?: "success" | "info" | "error";
}

interface ToastContextType {
  addToast: (message: string, type?: "success" | "info" | "error") => void;
}

const ToastContext = createContext<ToastContextType | undefined>(undefined);

export const ToastProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const addToast = (message: string, type: "success" | "info" | "error" = "success") => {
    const id = Math.random().toString(36).substring(2, 9);
    
    // Add toast to state
    setToasts((prev) => [...prev, { id, message, type }]);

    // Auto-remove after 3 seconds
    setTimeout(() => {
      setToasts((prev) => prev.filter((toast) => toast.id !== id));
    }, 3000);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((toast) => toast.id !== id));
  };

  return (
    <ToastContext.Provider value={{ addToast }}>
      {children}

      {/* Floating Toast Notification Container */}
      <div className="fixed bottom-5 right-5 z-50 flex flex-col gap-2 max-w-sm w-full pointer-events-none px-4 sm:px-0">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className={`pointer-events-auto flex items-center justify-between p-4 rounded-lg shadow-xl text-sm font-medium text-white transition-all transform translate-y-0 animate-bounce-once border ${
              toast.type === "error"
                ? "bg-red-900/90 border-red-700"
                : toast.type === "info"
                ? "bg-slate-800/90 border-slate-700"
                : "bg-emerald-900/90 border-emerald-700"
            }`}
          >
            <span>
              {toast.type === "error" && "❌ "}
              {toast.type === "info" && "ℹ️ "}
              {toast.type === "success" && "✅ "}
              {toast.message}
            </span>
            <button
              onClick={() => removeToast(toast.id)}
              className="ml-4 text-xs text-slate-300 hover:text-white cursor-pointer"
            >
              ✕
            </button>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
};

export const useToast = () => {
  const context = useContext(ToastContext);
  if (!context) {
    throw new Error("useToast must be used within a ToastProvider");
  }
  return context;
};
