"use client";

import React, { createContext, useContext, ReactNode } from "react";
import { Product } from "@/app/products/page";
import { useLocalStorage } from "@/hooks/useLocalStorage";
import { useToast } from "./ToastContext";

// Define Cart Item Structure (Product + Quantity)
export interface CartItem extends Product {
  quantity: number;
}

// Define Context Interface
interface CartContextType {
  cart: CartItem[];
  addToCart: (product: Product) => void;
  removeFromCart: (productId: number) => void;
  updateQuantity: (productId: number, quantity: number) => void;
  clearCart: () => void;
  totalItems: number;
  totalPrice: number;
  totalAmount: number; // Aliased to totalPrice so all components work
}

// Create context
const CartContext = createContext<CartContextType | undefined>(undefined);

// Create provider component
export const CartProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Use our custom hook to persist cart state under key "techstore_cart"
  const [cart, setCart] = useLocalStorage<CartItem[]>("techstore_cart", []);
  const { addToast } = useToast();

  // Add item to cart (increments quantity if already exists)
  const addToCart = (product: Product) => {
    setCart((prevCart) => {
      const existingIndex = prevCart.findIndex((item) => item.id === product.id);
      if (existingIndex > -1) {
        const updated = [...prevCart];
        updated[existingIndex].quantity += 1;
        return updated;
      }
      return [...prevCart, { ...product, quantity: 1 }];
    });

    // Fire toast notification
    addToast(`Added "${product.title.substring(0, 20)}..." to cart!`, "success");
  };

  // Remove item from cart completely
  const removeFromCart = (productId: number) => {
    const itemToRemove = cart.find((i) => i.id === productId);
    setCart((prevCart) => prevCart.filter((item) => item.id !== productId));

    // Fire toast notification
    if (itemToRemove) {
      addToast(`Removed item from cart.`, "info");
    }
  };

  // Update specific item quantity directly
  const updateQuantity = (productId: number, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart((prevCart) =>
      prevCart.map((item) => (item.id === productId ? { ...item, quantity } : item))
    );
  };

  // Clear all items from cart
  const clearCart = () => {
    setCart([]);
  };

  // Derived Values
  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
  const totalPrice = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const totalAmount = totalPrice; // Alias for convenience across components

  return (
    <CartContext.Provider
      value={{
        cart,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        totalItems,
        totalPrice,
        totalAmount,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

// Custom hook for consuming CartContext safely
export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error("useCart must be used within a CartProvider");
  }
  return context;
};
