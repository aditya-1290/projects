import NextAuth from "next-auth";
import Credentials from "next-auth/providers/credentials";

export const { handlers, auth, signIn, signOut } = NextAuth({
    providers: [
        Credentials({
            name: "Credentials",
            credentials: {
                email: { label: "Email", type: "email" },
                password: { label: "Password", type: "password" },
            },
            async authorize(credentials) {
                const email = credentials?.email as string;
                const password = credentials?.password as string;

                // Mock User Authentication (Later we will connect this to Prisma / Supabase DB)
                if (email === "alex@example.com" && password === "password123") {
                    return {
                        id: "usr_101",
                        name: "Alex Smith",
                        email: "alex@example.com",
                        image: "HTTPS://api.dicebear.com/7.x/avataaars/svg?seed=Alex",
                    };
                }

                // Return null if authorization fails
                return null;
            },
        }),
    ],
    pages: {
        signIn: "/login",
    },
    callbacks: {
        async session({ session, token }) {
            if (token?.sub && session.user) {
                session.user.id = token.sub;
            }
            return session;
        },
    },
    session :{
        strategy: "jwt",
    },
});
