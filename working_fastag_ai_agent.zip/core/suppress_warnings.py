"""
core/suppress_warnings.py
Suppress known harmless warnings and tracebacks from third-party libraries.
"""
import os
import sys
import warnings
import logging

# ── Environment variables (set before any imports) ──────────────
os.environ["OTEL_SDK_DISABLED"] = "true"
os.environ["OTEL_PYTHON_LOG_LEVEL"] = "error"

# ── Suppress Python warnings ────────────────────────────────────
warnings.filterwarnings("ignore")
warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", message=".*EXPERIMENTAL.*")
warnings.filterwarnings("ignore", message=".*datetime.datetime.utcnow.*")

# ── Suppress noisy loggers ──────────────────────────────────────
logging.getLogger("opentelemetry").setLevel(logging.CRITICAL)
logging.getLogger("LiteLLM").setLevel(logging.CRITICAL)
logging.getLogger("litellm").setLevel(logging.CRITICAL)
logging.getLogger("asyncio").setLevel(logging.CRITICAL)
logging.getLogger("LiteLLM").setLevel(logging.CRITICAL)
logging.getLogger("litellm").setLevel(logging.CRITICAL)


# ── Filter stderr to remove known tracebacks ────────────────────
class StderrFilter:
    """Filter stderr to hide known harmless tracebacks."""

    BLOCKED_PATTERNS = [
        "Failed to detach context",
        "Traceback (most recent call last):",
        "  File ",  # traceback lines
        "ValueError: <Token var=",
        "was created in a different Context",
        "GeneratorExit",
        "opentelemetry",
        "ConnectionResetError: [WinError 10054]",
        "Exception in callback _ProactorBasePipeTransport",
        "LiteLLM:ERROR:",
        "LoggingWorker error:",
        "asyncio.exceptions.CancelledError",
        "TimeoutError",
        "The above exception was the direct cause",
        "During handling of the above exception",
    ]

    def __init__(self, original_stderr):
        self.original_stderr = original_stderr
        self._in_traceback = False
        self._buffer = ""

    def write(self, message):
        # Check if this message starts a traceback we want to hide
        should_hide = False
        for pattern in self.BLOCKED_PATTERNS:
            if pattern in message:
                should_hide = True
                break

        if should_hide:
            self._in_traceback = True
            self._buffer += message
            # If this is the last line of a traceback (empty or ends with newline after error)
            if message.strip() == "" or (
                    self._buffer.count("\n") > 5 and message.strip() and not message.startswith("  ")):
                self._in_traceback = False
                self._buffer = ""
            return

        # If we're in a traceback, check if this line continues it
        if self._in_traceback:
            if message.startswith("  ") or message.startswith("Traceback") or \
                    "During handling" in message or "The above exception" in message:
                self._buffer += message
                return
            else:
                # Traceback ended
                self._in_traceback = False
                self._buffer = ""

        # Not blocked, write to original stderr
        self.original_stderr.write(message)

    def flush(self):
        self.original_stderr.flush()


# Apply the filter
sys.stderr = StderrFilter(sys.stderr)
