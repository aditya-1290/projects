"""
MCP Client for Agents to call MCP Server tools.
Supports both MCP protocol (via SSE) and direct HTTP fallback.
"""

import json
import httpx
from typing import Any, Dict, Optional
from core.config import config
from core.logger import get_logger

logger = get_logger("mcp_client")


class MCPClient:
    """Client for calling MCP Server tools."""
    
    def __init__(self):
        self.base_url = config.MCP_BASE_URL
        self.headers = {"x-api-key": config.MCP_API_KEY, "Content-Type": "application/json"}
    
    async def call_tool(self, tool_name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """
        Call an MCP tool via the SSE endpoint.
        This is the PROPER MCP way - uses the /sse endpoint.
        """
        # For simplicity, we also have direct HTTP endpoints
        # But this shows the MCP pattern
        
        if tool_name == "query_database":
            return self.execute_query(arguments.get("sql", ""), arguments.get("params", {}))
        elif tool_name == "get_schema":
            return self.get_schema(arguments.get("table_name"))
        elif tool_name == "get_relationships":
            return self.get_relationships()
        elif tool_name == "get_table_list":
            return self.get_table_list()
        elif tool_name == "get_cache_status":
            return self.get_cache_status()
        elif tool_name == "refresh_cache":
            return self.refresh_cache()
        else:
            return {"error": f"Unknown tool: {tool_name}"}
    
    def execute_query(self, sql: str, params: Dict = None) -> Dict[str, Any]:
        """Execute SQL query via direct HTTP endpoint."""
        try:
            with httpx.Client(timeout=600.0) as client:
                resp = client.post(
                    f"{self.base_url}/tools/execute_query",
                    json={"query": sql, "params": params or {}},
                    headers=self.headers,
                )
                resp.raise_for_status()
                return resp.json()
        except Exception as e:
            logger.error(f"MCP execute_query failed: {e}")
            return {"ok": False, "error": str(e), "rows": [], "row_count": 0}
    
    def get_cache(self) -> Dict[str, Any]:
        """Get full cache via direct HTTP endpoint."""
        try:
            with httpx.Client(timeout=600.0) as client:
                resp = client.get(f"{self.base_url}/cache", headers=self.headers)
                resp.raise_for_status()
                return resp.json()
        except Exception as e:
            logger.error(f"MCP get_cache failed: {e}")
            return {"schemas": {}, "relationships": {}, "table_map": {}}
    
    def get_schema(self, table_name: str = None) -> Dict[str, Any]:
        """Get schema via MCP tool."""
        try:
            with httpx.Client(timeout=600.0) as client:
                # This would go to /sse in pure MCP, but we use direct endpoint for simplicity
                resp = client.get(f"{self.base_url}/cache", headers=self.headers)
                cache = resp.json()
                
                if table_name:
                    for full_name, info in cache.get("schemas", {}).items():
                        if full_name.endswith(f".{table_name}") or full_name == table_name:
                            return {"table": full_name, "columns": info.get("columns", [])}
                    return {"error": f"Table '{table_name}' not found"}
                return {"schemas": cache.get("schemas", {})}
        except Exception as e:
            return {"error": str(e)}
    
    def get_relationships(self) -> Dict[str, Any]:
        """Get relationships via direct endpoint."""
        try:
            with httpx.Client(timeout=600.0) as client:
                resp = client.get(f"{self.base_url}/cache", headers=self.headers)
                cache = resp.json()
                return {"relationships": cache.get("relationships", {})}
        except Exception as e:
            return {"relationships": {}}
    
    def get_table_list(self) -> Dict[str, Any]:
        """Get table list."""
        try:
            with httpx.Client(timeout=600.0) as client:
                resp = client.get(f"{self.base_url}/cache", headers=self.headers)
                cache = resp.json()
                return {"table_map": cache.get("table_map", {})}
        except Exception as e:
            return {"table_map": {}}
    
    def get_cache_status(self) -> Dict[str, Any]:
        """Get cache status."""
        try:
            with httpx.Client(timeout=600.0) as client:
                resp = client.get(f"{self.base_url}/health", headers=self.headers)
                return resp.json()
        except Exception as e:
            return {"status": "error", "error": str(e)}
    
    def refresh_cache(self) -> Dict[str, Any]:
        """Refresh cache."""
        try:
            with httpx.Client(timeout=600.0) as client:
                # Call the MCP tool - in real MCP this would go via SSE
                # For simplicity, we use direct HTTP
                resp = client.post(f"{self.base_url}/tools/refresh_cache", headers=self.headers)
                return resp.json()
        except Exception as e:
            return {"ok": False, "error": str(e)}


# Singleton instance
mcp_client = MCPClient()
