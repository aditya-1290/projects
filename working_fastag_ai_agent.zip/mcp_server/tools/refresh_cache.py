"""
Refresh cache tool - called via MCP.
"""

from mcp_server.main import _scan_database, _cache
from core.logger import get_logger

logger = get_logger("refresh_cache")


def refresh_cache() -> dict:
    """Force a full database rescan."""
    try:
        _scan_database()
        return {
            "ok": True,
            "message": "Cache refreshed successfully",
            "table_count": _cache["metadata"]["table_count"],
        }
    except Exception as e:
        logger.error(f"Cache refresh failed: {e}")
        return {"ok": False, "message": str(e)}
    