"""
MCP Server using official FastMCP package + HTTP compatibility layer
Run with: python mcp_server/main.py
"""

import sys
import os
import json
import re
import threading
import asyncio
from datetime import datetime
from contextlib import asynccontextmanager
from typing import Dict, Any, Optional

import psycopg2
import psycopg2.extras

# FastMCP import
from mcp.server.fastmcp import FastMCP

# For HTTP compatibility layer
from starlette.applications import Starlette
from starlette.routing import Route
from starlette.responses import JSONResponse
from starlette.requests import Request
import uvicorn

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from core.config import config
from core.logger import get_logger

logger = get_logger("mcp_server")

# ============================================================================
# CONFIGURATION
# ============================================================================

DEFAULT_ROW_LIMIT = 100
BLOCKED_KEYWORDS = re.compile(
    r"\b(INSERT|UPDATE|DELETE|DROP|ALTER|CREATE|TRUNCATE|GRANT|REVOKE|REPLACE|MERGE)\b",
    re.IGNORECASE,
)

# ============================================================================
# DATABASE CONNECTION
# ============================================================================

def get_db_connection():
    """Get PostgreSQL connection using config from .env"""
    return psycopg2.connect(
        host=config.POSTGRES_HOST,
        port=config.POSTGRES_PORT,
        user=config.POSTGRES_USER,
        password=config.POSTGRES_PASSWORD,
        dbname=config.POSTGRES_DATABASE,
    )

def is_safe_sql(query: str) -> tuple[bool, str]:
    """Validate SQL is read-only."""
    stripped = query.strip().lstrip(";").strip()
    match = BLOCKED_KEYWORDS.search(stripped)
    if match:
        return False, f"Blocked keyword: {match.group().upper()}"
    
    first_word = stripped.split()[0].upper() if stripped.split() else ""
    if first_word not in ("SELECT", "WITH", "EXPLAIN"):
        return False, f"Only SELECT/WITH/EXPLAIN allowed. Got: {first_word}"
    
    return True, "ok"

# ============================================================================
# IN-MEMORY CACHE
# ============================================================================

_cache: Dict[str, Any] = {
    "metadata": {"last_updated": None, "table_count": 0, "schema_count": 0},
    "schemas": {},
    "relationships": {},
    "table_map": {},
    "sample_data": {},
}

def scan_database():
    """Full DB scan - runs once on server startup."""
    logger.info("Starting database scan...")
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    
    try:
        # Get schemas
        cur.execute("""
            SELECT schema_name
            FROM information_schema.schemata
            WHERE schema_name NOT IN ('pg_catalog','information_schema','pg_toast')
              AND schema_name NOT LIKE 'pg_%'
        """)
        schemas = [row["schema_name"] for row in cur.fetchall()]
        
        table_map = {}
        schemas_cache = {}
        all_tables = []
        
        for schema in schemas:
            cur.execute("""
                SELECT table_name
                FROM information_schema.tables
                WHERE table_schema = %s AND table_type = 'BASE TABLE'
            """, (schema,))
            tables = [row["table_name"] for row in cur.fetchall()]
            table_map[schema] = tables
            for table in tables:
                all_tables.append({"schema": schema, "table": table})
        
        logger.info(f"Found {len(all_tables)} tables across {len(schemas)} schemas")
        
        # Get columns for each table
        for item in all_tables:
            schema = item["schema"]
            table = item["table"]
            full_name = f"{schema}.{table}"
            
            cur.execute("""
                SELECT column_name, data_type, is_nullable,
                       column_default::text as column_default
                FROM information_schema.columns
                WHERE table_schema = %s AND table_name = %s
                ORDER BY ordinal_position
            """, (schema, table))
            columns = [dict(row) for row in cur.fetchall()]
            
            # Add primary key info
            cur.execute("""
                SELECT kcu.column_name
                FROM information_schema.table_constraints tc
                JOIN information_schema.key_column_usage kcu
                    ON tc.constraint_name = kcu.constraint_name
                WHERE tc.constraint_type = 'PRIMARY KEY'
                  AND tc.table_schema = %s
                  AND tc.table_name = %s
            """, (schema, table))
            pk_columns = [row["column_name"] for row in cur.fetchall()]
            
            for col in columns:
                col["primary_key"] = col["column_name"] in pk_columns
            
            # Get row count
            try:
                cur.execute(f'SELECT COUNT(*) as cnt FROM "{schema}"."{table}" LIMIT {DEFAULT_ROW_LIMIT}')
                row_count = cur.fetchone()["cnt"]
            except:
                row_count = -1
                conn.rollback()
            
            schemas_cache[full_name] = {
                "schema": schema,
                "table": table,
                "columns": columns,
                "row_count": row_count,
            }
        
        # Get foreign key relationships
        cur.execute("""
            SELECT
                tc.table_schema AS from_schema,
                tc.table_name AS from_table,
                kcu.column_name AS from_col,
                ccu.table_schema AS to_schema,
                ccu.table_name AS to_table,
                ccu.column_name AS to_col
            FROM information_schema.table_constraints tc
            JOIN information_schema.key_column_usage kcu
                ON tc.constraint_name = kcu.constraint_name
            JOIN information_schema.constraint_column_usage ccu
                ON ccu.constraint_name = tc.constraint_name
            WHERE tc.constraint_type = 'FOREIGN KEY'
        """)
        relationships = {}
        for row in cur.fetchall():
            key = f"{row['from_schema']}.{row['from_table']}.{row['from_col']} -> {row['to_schema']}.{row['to_table']}.{row['to_col']}"
            relationships[key] = "foreign_key"
        
        _cache["metadata"] = {
            "last_updated": datetime.utcnow().isoformat(),
            "table_count": len(all_tables),
            "schema_count": len(schemas),
        }
        _cache["schemas"] = schemas_cache
        _cache["relationships"] = relationships
        _cache["table_map"] = table_map
        
        logger.info(f"Database scan complete | tables={len(all_tables)}")
        return _cache
        
    except Exception as e:
        logger.error(f"Database scan failed: {e}")
        raise
    finally:
        cur.close()
        conn.close()

# ============================================================================
# FAST MCP SERVER - STANDARD MCP PROTOCOL
# ============================================================================

# Create FastMCP server instance
mcp = FastMCP("mlff-database-server")

@mcp.tool()
def execute_sql(query: str, limit: int = 100) -> Dict[str, Any]:
    """
    Execute a read-only SQL SELECT query on the PostgreSQL database.
    
    Args:
        query: The SQL SELECT query to execute
        limit: Maximum number of rows to return (default 100)
    """
    safe, reason = is_safe_sql(query)
    if not safe:
        return {"ok": False, "error": reason, "rows": [], "row_count": 0}
    
    conn = None
    try:
        conn = get_db_connection()
        cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        
        q = query.strip().rstrip(";")
        if "LIMIT" not in q.upper() and not q.upper().startswith("EXPLAIN"):
            q = f"{q} LIMIT {limit}"
        
        cur.execute(q)
        rows = [dict(r) for r in cur.fetchall()]
        
        for row in rows:
            for k, v in row.items():
                if not isinstance(v, (str, int, float, bool, type(None))):
                    row[k] = str(v)
        
        return {
            "ok": True,
            "rows": rows,
            "row_count": len(rows),
            "columns": list(rows[0].keys()) if rows else [],
        }
    except Exception as e:
        return {"ok": False, "error": str(e), "rows": [], "row_count": 0}
    finally:
        if conn:
            conn.close()

@mcp.tool()
def get_table_schema(table_name: str) -> Dict[str, Any]:
    """Get column information for a specific table."""
    for full_name, info in _cache["schemas"].items():
        if full_name.endswith(f".{table_name}") or full_name == table_name:
            return {
                "table": full_name,
                "columns": info.get("columns", []),
                "row_count": info.get("row_count", 0),
            }
    return {"error": f"Table '{table_name}' not found"}

@mcp.tool()
def list_tables(schema: str = "public") -> Dict[str, Any]:
    """List all tables in a schema."""
    tables = _cache["table_map"].get(schema, [])
    return {"schema": schema, "tables": tables}

@mcp.tool()
def get_relationships() -> Dict[str, Any]:
    """Get all foreign key relationships."""
    return {"relationships": _cache["relationships"], "total": len(_cache["relationships"])}

@mcp.tool()
def get_cache_status() -> Dict[str, Any]:
    """Get cache status."""
    return {
        "status": "ready" if _cache["metadata"]["last_updated"] else "empty",
        "metadata": _cache["metadata"],
    }

@mcp.tool()
def refresh_cache() -> Dict[str, Any]:
    """Force a full database rescan."""
    try:
        scan_database()
        return {
            "ok": True,
            "message": "Cache refreshed successfully",
            "table_count": _cache["metadata"]["table_count"],
        }
    except Exception as e:
        return {"ok": False, "message": str(e)}

# ============================================================================
# HTTP COMPATIBILITY LAYER (for existing agents)
# ============================================================================

async def http_health(request: Request):
    """Health check endpoint."""
    return JSONResponse({
        "status": "ok",
        "cache_ready": _cache["metadata"]["last_updated"] is not None,
        "table_count": _cache["metadata"]["table_count"],
        "mcp_version": "1.0.0",
    })

async def http_cache(request: Request):
    """Get full cache - used by mcp_client.get_cache()"""
    api_key = request.headers.get("x-api-key")
    if api_key != config.MCP_API_KEY:
        return JSONResponse({"error": "Invalid API key"}, status_code=401)
    return JSONResponse(_cache)

async def http_execute_query(request: Request):
    """Execute SQL query - used by mcp_client.execute_query()"""
    api_key = request.headers.get("x-api-key")
    if api_key != config.MCP_API_KEY:
        return JSONResponse({"error": "Invalid API key"}, status_code=401)
    body = await request.json()
    query = body.get("query", "")
    limit = body.get("limit", 100)
    result = execute_sql(query, limit)
    return JSONResponse(result)

async def http_get_schema(request: Request):
    """Get schema - used by mcp_client.get_schema()"""
    api_key = request.headers.get("x-api-key")
    if api_key != config.MCP_API_KEY:
        return JSONResponse({"error": "Invalid API key"}, status_code=401)
    table_name = request.query_params.get("table_name")
    result = get_table_schema(table_name) if table_name else {"tables": list(_cache["schemas"].keys())}
    return JSONResponse(result)

async def http_get_relationships(request: Request):
    """Get relationships - used by mcp_client.get_relationships()"""
    api_key = request.headers.get("x-api-key")
    if api_key != config.MCP_API_KEY:
        return JSONResponse({"error": "Invalid API key"}, status_code=401)
    result = get_relationships()
    return JSONResponse(result)

async def http_get_table_list(request: Request):
    """Get table list - used by mcp_client.get_table_list()"""
    api_key = request.headers.get("x-api-key")
    if api_key != config.MCP_API_KEY:
        return JSONResponse({"error": "Invalid API key"}, status_code=401)
    return JSONResponse({"table_map": _cache["table_map"]})

async def http_refresh_cache(request: Request):
    """Refresh cache - used by mcp_client.refresh_cache()"""
    api_key = request.headers.get("x-api-key")
    if api_key != config.MCP_API_KEY:
        return JSONResponse({"error": "Invalid API key"}, status_code=401)
    result = refresh_cache()
    return JSONResponse(result)

# ============================================================================
# RUN BOTH SERVERS (FastMCP + HTTP) IN PARALLEL
# ============================================================================

def run_fastmcp_server():
    """Run FastMCP server on a separate thread."""
    asyncio.run(mcp.run(transport="sse", host="127.0.0.1", port=9001))

# Create Starlette app for HTTP endpoints
http_app = Starlette(
    routes=[
        Route("/health", http_health, methods=["GET"]),
        Route("/cache", http_cache, methods=["GET"]),
        Route("/tools/execute_query", http_execute_query, methods=["POST"]),
        Route("/tools/get_schema", http_get_schema, methods=["GET"]),
        Route("/tools/get_relationships", http_get_relationships, methods=["GET"]),
        Route("/tools/get_table_list", http_get_table_list, methods=["GET"]),
        Route("/tools/refresh_cache", http_refresh_cache, methods=["POST"]),
    ]
)

if __name__ == "__main__":
    # Scan database first
    scan_database()
    
    # Run HTTP server (for your agents) on port 9000
    print("Starting HTTP server on port 9000 (for agents)...")
    print("FastMCP server will run on port 9001 (for MCP clients)")
    
    # Run just the HTTP server (simpler, works with your agents)
    uvicorn.run(http_app, host="127.0.0.1", port=9000, log_level="info")
    