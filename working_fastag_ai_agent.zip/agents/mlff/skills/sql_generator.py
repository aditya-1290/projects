"""
agents/mlff/skills/sql_generator.py
Generates PostgreSQL SELECT SQL from user query and schema context.
FIX: Strict prompt - forces exact table/schema names, blocks hallucination.
"""
import json
from typing import Any, Dict, List

from core.llm_client import call_llm
from core.logger import get_logger

logger = get_logger("sql_generator")

MAX_COLS_IN_PROMPT = 12


def _build_strict_schema_text(
    selected_schema: str,
    selected_tables: List[str],
    schema_details: Dict[str, Any],
) -> str:
    """Build explicit schema block with exact qualified names."""
    lines = []
    lines.append(f"SCHEMA NAME (use exactly this): {selected_schema}")
    lines.append("")
    lines.append("TABLES AND COLUMNS (use ONLY these exact names):")
    lines.append("")

    for table in selected_tables:
        info = schema_details.get(table, {})
        cols = info.get("columns", [])[:MAX_COLS_IN_PROMPT]

        lines.append(f"  Table (exact name): {table}")
        lines.append(f"  Qualified name to use in SQL: {selected_schema}.{table}")
        for c in cols:
            pk = " [PRIMARY KEY]" if c.get("primary_key") else ""
            lines.append(f"    - {c['column_name']} ({c['data_type']}){pk}")
        lines.append("")

    return "\n".join(lines)


def generate_sql(
    user_query: str,
    intent: str,
    query_type: str,
    selected_schema: str,
    selected_tables: List[str],
    schema_details: Dict[str, Any],
    relationships_hint: List[str],
) -> str:
    """
    Generate PostgreSQL SQL using LLM with strict table/schema enforcement.
    Returns clean SQL string.
    """
    schema_text = _build_strict_schema_text(
        selected_schema, selected_tables, schema_details
    )
    rel_text = "\n".join(relationships_hint[:10]) if relationships_hint else "None"

    prompt = f"""Write a PostgreSQL SELECT query to answer this question:

USER QUESTION: {user_query}
INTENT: {intent}
COMPLEXITY: {query_type}

{schema_text}

FOREIGN KEY HINTS:
{rel_text}

STRICT RULES - MUST FOLLOW ALL:
1. Use ONLY the exact table names listed above. NO other table names allowed.
2. Use ONLY the exact schema name: {selected_schema}
3. Always qualify table names as: {selected_schema}.tablename
4. Use ONLY column names listed above for each table.
5. NEVER invent table names, schema names, or column names.
6. Only SELECT statements. No INSERT, UPDATE, DELETE, DROP, ALTER, CREATE.
7. Add LIMIT 50 for non-aggregate queries.
8. Use table aliases in JOINs.

EXAMPLE of correct qualified name format:
  SELECT * FROM {selected_schema}.{selected_tables[0] if selected_tables else 'tablename'}

Return ONLY the SQL query. No markdown. No explanation. No code fences. Just SQL."""

    system = (
        "You are a PostgreSQL expert. "
        f"You ONLY use tables from schema '{selected_schema}'. "
        f"The ONLY valid tables are: {', '.join(selected_tables)}. "
        "You NEVER invent table names or column names. "
        "Return only raw SQL. No markdown. No explanation."
    )

    logger.debug(f"Generating SQL | intent={intent} | tables={selected_tables}")

    raw = call_llm(system, prompt, max_tokens=1048)
    sql = raw.strip()

    # Clean markdown fences
    if "```" in sql:
        parts = sql.split("```")
        for part in parts:
            s = part.strip()
            if s.upper().startswith("SELECT") or s.upper().startswith("WITH"):
                sql = s
                break
        else:
            sql = parts[1].strip()
            if sql.lower().startswith("sql"):
                sql = sql[3:].strip()

    sql = sql.strip().rstrip(";")

    # ── Safety check — if wrong schema crept in, replace it ──────────
    # Common hallucinated schema names the model uses
    bad_schemas = ["film_data", "dvdrental", "public_data", "db", "database"]
    for bad in bad_schemas:
        if bad != selected_schema and f"{bad}." in sql:
            logger.warning(f"SQL contains hallucinated schema '{bad}'. Replacing with '{selected_schema}'.")
            sql = sql.replace(f"{bad}.", f"{selected_schema}.")

    logger.info(f"SQL generated: {sql[:120]}...")
    return sql