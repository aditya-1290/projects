"""
Skill: Result Formatter
Formats DB rows into natural language explanation + chart suggestion.
"""
import json
from typing import Any, Dict, List

from core.llm_client import call_llm
from core.logger import get_logger
from agents.mlff.prompts import RESULT_FORMATTER_PROMPT

logger = get_logger("result_formatter")

SAMPLE_ROWS_FOR_EXPLANATION = 5


def format_result(
    user_query: str,
    sql: str,
    rows: List[Dict],
    row_count: int,
) -> Dict[str, Any]:
    """
    Call LLM to generate explanation and chart suggestion.
    Returns dict with explanation, chart_type, chart_reason.
    """
    import json as _json

    sample_rows = rows[:SAMPLE_ROWS_FOR_EXPLANATION]

    # Convert rows to safe JSON string
    try:
        sample_json = _json.dumps(sample_rows, default=str, indent=2)
    except Exception:
        sample_json = str(sample_rows)

    prompt = RESULT_FORMATTER_PROMPT.format(
        user_query=user_query,
        sql=sql,
        row_count=row_count,
        sample_rows=sample_json,
    )

    system = (
        "You are a data analyst. Return only valid JSON. "
        "No markdown. No extra text. Respond with the JSON object only."
    )

    try:
        raw = call_llm(system, prompt, max_tokens=2096)
        raw = raw.strip()

        # Strip markdown if present
        if "```" in raw:
            parts = raw.split("```")
            for part in parts:
                stripped = part.strip()
                if stripped.startswith("{"):
                    raw = stripped
                    break

        result = _json.loads(raw)
        return {
            "explanation": result.get("explanation", "Data retrieved successfully."),
            "chart_type": result.get("chart_type", "table"),
            "chart_reason": result.get("chart_reason", ""),
        }

    except Exception as e:
        logger.error(f"Result formatter LLM failed: {e}")
        return {
            "explanation": f"Query returned {row_count} rows successfully.",
            "chart_type": "table",
            "chart_reason": "Fallback - LLM formatter failed.",
        }
