"""
agents/mlff/agent.py
Real Google ADK implementation with Tool Call Parser Bridge.
"""
import os
import warnings
os.environ["OTEL_SDK_DISABLED"] = "true"
warnings.filterwarnings("ignore", category=UserWarning, module="google.adk")

import uuid as _uuid
import os
import json
import asyncio
from typing import Any, Dict

from dotenv import load_dotenv
from google.adk.agents import LlmAgent
from google.adk.models.lite_llm import LiteLlm
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types

from agents.mlff.agent_card import MLFF_CARD
from agents.mlff.skills.sql_generator import generate_sql
from agents.mlff.skills.result_formatter import format_result
from core.mcp_client import mcp_client
from core.tool_call_parser import (
    parse_tool_call, execute_parsed_tool, detect_tool_call,
    detect_tool_response, detect_batch_tool_calls, parse_batch_tool_calls,
    format_tool_response,
)
# from core.tool_call_parser import set_tools_map as _set_global_tools
from core.tool_call_parser import set_tools_map
from core.logger import get_logger, success_logger, error_logger

load_dotenv()
logger = get_logger("mlff_agent")

os.environ["OPENAI_API_KEY"] = os.getenv("LOCAL_LLM_API_KEY", "sk-local")
os.environ["OPENAI_API_BASE"] = os.getenv("LOCAL_LLM_BASE_URL", "http://127.0.0.1:8001/v1")

_model = LiteLlm(model=f"openai/{os.getenv('LOCAL_LLM_MODEL', 'local-model')}")

MAX_DISPLAY_ROWS = 50
MAX_BRIDGE_ITERATIONS = 8


# ── ADK Tool functions ────────────────────────────────────────────────────────

# In agents/mlff/agent.py, replace the generate_sql_query function:

def generate_sql_query(
    user_query: str,
    intent: str,
    query_type: str,
    selected_schema: str,
    selected_tables_json: Any,
    schema_details_json: Any,
    relationships_hint_json: Any,
) -> str:
    """Generate a safe PostgreSQL SELECT SQL query from user query and schema context."""
    try:
        # Helper to clean Gemma <|"|> tokens from strings
        def _clean_gemma(val: Any) -> Any:
            """Replace Gemma quote tokens and parse JSON."""
            if not isinstance(val, str):
                return val
            # Replace Gemma quote tokens with actual double quotes
            cleaned = val.replace('<|"|>', '"').replace('<|"|', '"').replace('"|>', '"')
            try:
                return json.loads(cleaned)
            except json.JSONDecodeError:
                try:
                    import ast
                    return ast.literal_eval(cleaned)
                except:
                    return val
            except Exception:
                return val

        # Clean all three JSON arguments
        selected_tables = _clean_gemma(selected_tables_json)
        schema_details = _clean_gemma(schema_details_json)
        relationships_hint = _clean_gemma(relationships_hint_json)

        # Ensure correct types
        if not isinstance(selected_tables, list):
            selected_tables = []
        if not isinstance(schema_details, dict):
            schema_details = {}
        if not isinstance(relationships_hint, list):
            relationships_hint = []

        sql = generate_sql(
            user_query=user_query,
            intent=intent,
            query_type=query_type,
            selected_schema=selected_schema,
            selected_tables=selected_tables,
            schema_details=schema_details,
            relationships_hint=relationships_hint,
        )
        return sql
    except Exception as e:
        error_logger.error(f"generate_sql_query tool error: {e}")
        return f"-- SQL generation failed: {e}"

def execute_sql_via_mcp(sql: str) -> str:
    """Execute a SQL query via MCP server. Read-only, validated."""
    try:
        result = mcp_client.execute_query(sql)
        if result.get("rows"):
            result["rows"] = result["rows"][:MAX_DISPLAY_ROWS]
            result["row_count"] = len(result["rows"])
        return json.dumps(result, default=str)
    except Exception as e:
        error_logger.error(f"execute_sql_via_mcp tool error: {e}")
        return json.dumps({"ok": False, "error": str(e), "rows": [], "row_count": 0})


def explain_results(
    user_query: str,
    sql: str,
    execution_result_json: str,
) -> str:
    """Generate natural language explanation and chart type suggestion for query results."""
    try:
        # Clean Gemma tokens
        if isinstance(execution_result_json, str):
            execution_result_json = execution_result_json.replace('<|"|>', '"').replace('<|"|', '"').replace('"|>', '"')

        exec_result = json.loads(execution_result_json) if isinstance(execution_result_json,
                                                                      str) else execution_result_json
        # exec_result = json.loads(execution_result_json) if isinstance(execution_result_json, str) else execution_result_json
        rows = exec_result.get("rows", [])
        row_count = exec_result.get("row_count", 0)
        result = format_result(
            user_query=user_query,
            sql=sql,
            rows=rows,
            row_count=row_count,
        )
        return json.dumps(result)
    except Exception as e:
        error_logger.error(f"explain_results tool error: {e}")
        return json.dumps({
            "explanation": "Results retrieved successfully.",
            "chart_type": "table",
            "chart_reason": "Default fallback.",
        })


# ── Tools map for bridge ──────────────────────────────────────────────────────

_TOOLS_MAP = {
    "generate_sql_query": generate_sql_query,
    "execute_sql_via_mcp": execute_sql_via_mcp,
    "explain_results": explain_results,
}

set_tools_map(_TOOLS_MAP)

# _set_global_tools({
#     "detect_query_intent": _TOOLS_MAP.get("generate_sql_query"),  
#     **_TOOLS_MAP  # generate_sql_query, execute_sql_via_mcp, explain_results
# })

# ── ADK LlmAgent ──────────────────────────────────────────────────────────────

MLFF_INSTRUCTION = """
You are the MLFF Analytics Agent. You execute database queries.

For every request call these tools in order:

Step 1 - Generate SQL:
generate_sql_query(user_query="...", intent="...", query_type="...", selected_schema="...", selected_tables_json=["table1","table2"], schema_details_json={...}, relationships_hint_json=[...])

Step 2 - Execute SQL:
execute_sql_via_mcp(sql="the SQL from step 1")

Step 3 - Explain results:
explain_results(user_query="...", sql="the SQL", execution_result_json="the result from step 2")

After all 3 tools, return ONLY this JSON (no markdown, no explanation):
{
  "sql": "<sql from step 1>",
  "ok": true,
  "rows": [],
  "row_count": 0,
  "columns": [],
  "explanation": "<from step 3>",
  "chart_type": "<from step 3>",
  "chart_reason": "<from step 3>",
  "error": ""
}
"""

mlff_llm_agent = LlmAgent(
    name="mlff",
    model=_model,
    description=MLFF_CARD.description,
    instruction=MLFF_INSTRUCTION,
    tools=[generate_sql_query, execute_sql_via_mcp, explain_results],
    output_key="mlff_result",
)

_session_service = InMemorySessionService()


# ── Bridge Runner ─────────────────────────────────────────────────────────────

async def _run_with_bridge(
    session_service: InMemorySessionService,
    user_id: str,
    session_id: str,
    initial_message: str,
    app_name: str = "mlff_adk",
    query_id: str = "",
) -> str:
    """
    Run ADK agent with Tool Call Parser Bridge.
    Fresh runner + fresh session per iteration eliminates ADK context bleed.
    """
    tool_results = {}
    iterations = 0
    current_message = initial_message

    while iterations < MAX_BRIDGE_ITERATIONS:
        iterations += 1

        # Fresh session per iteration
        session_id_iter = f"{session_id}_{query_id}_iter{iterations}"
        await session_service.create_session(
            app_name=app_name,
            user_id=user_id,
            session_id=session_id_iter,
        )

        # Fresh Runner per iteration — eliminates shared async context bleed
        fresh_runner = Runner(
            agent=mlff_llm_agent,
            app_name=app_name,
            session_service=session_service,
        )

        logger.debug(f"[BRIDGE] MLFF Iteration {iterations} | session={session_id_iter}")

        message = types.Content(
            role="user",
            parts=[types.Part(text=current_message)],
        )

        raw_text = ""
        gen = fresh_runner.run_async(
            user_id=user_id,
            session_id=session_id_iter,
            new_message=message,
        )

        try:
            async for event in gen:
                if event.is_final_response():
                    if event.content and event.content.parts:
                        raw_text = event.content.parts[0].text or ""
                        logger.debug(f"[BRIDGE] Raw output (iter {iterations}): {raw_text[:200]}")
                    await gen.aclose()
                    break
        except Exception as e:
            if "created in a different Context" not in str(e):
                logger.error(f"Unexpected error: {e}")

        if not raw_text:
            logger.warning(f"[BRIDGE] MLFF empty response on iteration {iterations}")
            break

        # ── Case 1: Batch JSON array tool calls ──────────────────────
        if detect_batch_tool_calls(raw_text):
            parsed_list = parse_batch_tool_calls(raw_text)
            if parsed_list:
                logger.info(f"[BRIDGE] MLFF batch tool calls: {[p['tool_name'] for p in parsed_list]}")
                for parsed in parsed_list:
                    tool_result = await execute_parsed_tool(parsed, _TOOLS_MAP)
                    if tool_result:
                        tool_results[parsed['tool_name']] = tool_result
                        logger.info(f"[BRIDGE] MLFF batch tool executed: {parsed['tool_name']} | result_len={len(tool_result)}")
                    else:
                        logger.error(f"[BRIDGE] MLFF batch tool returned None: {parsed['tool_name']}")

                # If only generate_sql_query ran, execute and explain directly
                if "generate_sql_query" in tool_results and "execute_sql_via_mcp" not in tool_results:
                    logger.info("[BRIDGE] MLFF executing remaining tools directly")
                    sql = tool_results["generate_sql_query"]

                    exec_result = execute_sql_via_mcp(sql)
                    tool_results["execute_sql_via_mcp"] = exec_result

                    explain_result = explain_results(
                        user_query=initial_message,
                        sql=sql,
                        execution_result_json=exec_result,
                    )
                    tool_results["explain_results"] = explain_result

                return _synthesize_mlff_results(tool_results, initial_message)

        # ── Case 2: Single tool CALL ──────────────────────────────────
        elif detect_tool_call(raw_text):
            parsed = parse_tool_call(raw_text)
            if parsed:
                tool_result = await execute_parsed_tool(parsed, _TOOLS_MAP)
                if tool_result:
                    tool_results[parsed['tool_name']] = tool_result
                    logger.info(f"[BRIDGE] MLFF tool executed: {parsed['tool_name']} | result_len={len(tool_result)}")

                    # If all 3 tools done, synthesize directly
                    if all(k in tool_results for k in ["generate_sql_query", "execute_sql_via_mcp", "explain_results"]):
                        logger.info("[BRIDGE] MLFF all tools complete, synthesizing")
                        return _synthesize_mlff_results(tool_results, initial_message)

                    current_message = format_tool_response(parsed['tool_name'], tool_result)
                    continue
                else:
                    logger.error(f"[BRIDGE] MLFF tool returned None: {parsed['tool_name']}")
                    break
            else:
                logger.warning(f"[BRIDGE] MLFF tool detected but parse failed: {raw_text[:200]}")
                break

        # ── Case 3: Tool RESPONSE from ADK patch — keep looping ──────
        elif detect_tool_response(raw_text):
            logger.info(f"[BRIDGE] MLFF got tool response on iter {iterations}, continuing...")
            current_message = raw_text
            continue

        # ── Case 4: Final JSON response ───────────────────────────────
        else:
            logger.info(f"[BRIDGE] MLFF final response on iteration {iterations}")
            return raw_text

    # Exhausted iterations — synthesize from whatever we collected
    if tool_results:
        logger.info(f"[BRIDGE] MLFF synthesizing from {len(tool_results)} collected results")
        return _synthesize_mlff_results(tool_results, initial_message)

    return ""


def _synthesize_mlff_results(tool_results: dict, user_query: str) -> str:
    """Build final MLFF JSON directly from collected tool results."""
    sql = tool_results.get("generate_sql_query", "")

    exec_raw = tool_results.get("execute_sql_via_mcp", "{}")
    try:
        exec_data = json.loads(exec_raw) if isinstance(exec_raw, str) else exec_raw
    except Exception:
        exec_data = {}

    explain_raw = tool_results.get("explain_results", "{}")
    try:
        explain_data = json.loads(explain_raw) if isinstance(explain_raw, str) else explain_raw
    except Exception:
        explain_data = {}

    rows = exec_data.get("rows", [])
    columns = list(rows[0].keys()) if rows else []

    return json.dumps({
        "sql": sql,
        "ok": exec_data.get("ok", True),
        "rows": rows,
        "row_count": exec_data.get("row_count", len(rows)),
        "columns": columns,
        "explanation": explain_data.get("explanation", "Query executed successfully."),
        "chart_type": explain_data.get("chart_type", "table"),
        "chart_reason": explain_data.get("chart_reason", ""),
        "error": exec_data.get("error", ""),
    })


# ── Public interface ──────────────────────────────────────────────────────────

async def run_mlff_async(
    orchestrator_payload: Dict[str, Any],
    session_id: str,
    user_id: str = "mlff_user",
) -> Dict[str, Any]:
    """Run MLFF ADK agent with bridge. Returns full result dict for UI."""

    user_query = orchestrator_payload.get("user_query", "")
    success_logger.info(f"[{session_id}] MLFF ADK started")

    if not orchestrator_payload.get("ok"):
        error = orchestrator_payload.get("error", "Orchestrator failed")
        return _error_response(session_id, user_query, orchestrator_payload, error)

    context_message = f"""
User query: {user_query}

Context from Orchestrator:
- intent: {orchestrator_payload.get('intent', 'lookup')}
- query_type: {orchestrator_payload.get('query_type', 'simple')}
- selected_schema: {orchestrator_payload.get('selected_schema', 'public')}
- selected_tables_json: {json.dumps(orchestrator_payload.get('selected_tables', []))}
- schema_details_json: {json.dumps(orchestrator_payload.get('schema_details', {}), default=str)}
- relationships_hint_json: {json.dumps(orchestrator_payload.get('relationships_hint', []))}
- context_summary: {orchestrator_payload.get('context_summary', '')}

Now call generate_sql_query, then execute_sql_via_mcp, then explain_results.
"""

    try:
        mlff_session_id = f"mlff_{session_id}_{_uuid.uuid4().hex[:6]}"

        import uuid
        query_id = uuid.uuid4().hex[:8]

        final_text = await _run_with_bridge(
            session_service=_session_service,
            user_id=user_id,
            session_id=mlff_session_id,
            initial_message=context_message,
            query_id=query_id,
        )

        success_logger.info(f"[{session_id}] MLFF ADK raw output: {final_text[:200]}")

        # In run_mlff_async, update the markdown extraction:
        clean = final_text.strip()
        if not clean:
            raise ValueError("Empty response from MLFF bridge")

        if "```" in clean:
            parts = clean.split("```")
            for part in parts:
                s = part.strip()
                if s.lower().startswith("json"):
                    s = s[4:].strip()
                if s.startswith("{"):
                    clean = s
                    break
            else:
                if len(parts) >= 2:
                    s = parts[1].strip()
                    if s.lower().startswith("json"):
                        s = s[4:].strip()
                    if s.startswith("{"):
                        clean = s

        result = json.loads(clean)
        result["ok"] = result.get("ok", True)

    except Exception as e:
        error_logger.error(f"[{session_id}] MLFF bridge/parse error: {e}")
        result = await _mlff_fallback(orchestrator_payload, session_id)

    result.update({
        "request_id": session_id,
        "user_query": user_query,
        "intent": orchestrator_payload.get("intent", ""),
        "query_type": orchestrator_payload.get("query_type", ""),
        "confidence": orchestrator_payload.get("confidence", 0),
        "confidence_note": orchestrator_payload.get("confidence_note", ""),
        "low_confidence": orchestrator_payload.get("low_confidence", False),
        "selected_schema": orchestrator_payload.get("selected_schema", ""),
        "selected_tables": orchestrator_payload.get("selected_tables", []),
        "context_summary": orchestrator_payload.get("context_summary", ""),
    })

    success_logger.info(f"[{session_id}] MLFF complete | ok={result.get('ok')} | rows={result.get('row_count', 0)}")
    return result


async def _mlff_fallback(
    orchestrator_payload: Dict[str, Any],
    session_id: str,
) -> Dict[str, Any]:
    """Direct fallback — calls skills in Python if bridge fails."""
    logger.warning(f"[{session_id}] Using MLFF fallback (direct skill calls)")
    user_query = orchestrator_payload.get("user_query", "")
    try:
        sql = generate_sql(
            user_query=user_query,
            intent=orchestrator_payload.get("intent", "lookup"),
            query_type=orchestrator_payload.get("query_type", "simple"),
            selected_schema=orchestrator_payload.get("selected_schema", "public"),
            selected_tables=orchestrator_payload.get("selected_tables", []),
            schema_details=orchestrator_payload.get("schema_details", {}),
            relationships_hint=orchestrator_payload.get("relationships_hint", []),
        )
        mcp_result = mcp_client.execute_query(sql)
        rows = mcp_result.get("rows", [])[:MAX_DISPLAY_ROWS]
        row_count = len(rows)
        columns = list(rows[0].keys()) if rows else []
        fmt = format_result(user_query, sql, rows, row_count)
        return {
            "ok": mcp_result.get("ok", False),
            "sql": sql,
            "rows": rows,
            "row_count": row_count,
            "columns": columns,
            "explanation": fmt.get("explanation", ""),
            "chart_type": fmt.get("chart_type", "table"),
            "chart_reason": fmt.get("chart_reason", ""),
            "error": mcp_result.get("error", ""),
        }
    except Exception as e:
        return {
            "ok": False, "sql": "", "rows": [], "row_count": 0,
            "columns": [], "explanation": str(e),
            "chart_type": "none", "chart_reason": "", "error": str(e),
        }


def _error_response(
    session_id: str,
    user_query: str,
    orchestrator_payload: Dict,
    error: str,
) -> Dict[str, Any]:
    return {
        "ok": False, "request_id": session_id, "user_query": user_query,
        "error": error, "sql": "", "rows": [], "row_count": 0,
        "explanation": error, "chart_type": "none", "chart_reason": "",
        "intent": orchestrator_payload.get("intent", ""),
        "query_type": orchestrator_payload.get("query_type", ""),
        "confidence": orchestrator_payload.get("confidence", 0),
        "confidence_note": orchestrator_payload.get("confidence_note", ""),
        "low_confidence": orchestrator_payload.get("low_confidence", False),
        "selected_schema": orchestrator_payload.get("selected_schema", ""),
        "selected_tables": orchestrator_payload.get("selected_tables", []),
        "columns": [],
    }


def run_mlff(
    orchestrator_payload: Dict[str, Any],
    session_id: str,
    user_id: str = "mlff_user",
) -> Dict[str, Any]:
    """Sync wrapper — do NOT use from FastAPI. Use run_mlff_async instead."""
    return asyncio.run(run_mlff_async(orchestrator_payload, session_id, user_id))
