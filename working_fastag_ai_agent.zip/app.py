"""
app.py - FIXED
"""
import core.suppress_warnings

import os
import sys
# os.environ["OTEL_SDK_DISABLED"] = "true"
# os.environ["OTEL_PYTHON_LOG_LEVEL"] = "error"

# import warnings
# # Suppress all warnings
# warnings.filterwarnings("ignore")
#
# import logging
# logging.getLogger("LiteLLM").setLevel(logging.CRITICAL)
# logging.getLogger("litellm").setLevel(logging.CRITICAL)
# logging.getLogger("asyncio").setLevel(logging.CRITICAL)
# logging.getLogger("opentelemetry").setLevel(logging.CRITICAL)


# # ── MUST be before ALL other imports ──────────────────
# os.environ["PYTHONUTF8"] = "1"
# os.environ["LITELLM_LOG"] = "ERROR"
#
# # Suppress specific noisy modules
# warnings.filterwarnings("ignore", category=UserWarning, module="google.adk")
# warnings.filterwarnings("ignore", category=DeprecationWarning)
# warnings.filterwarnings("ignore", message=".*EXPERIMENTAL.*")
# warnings.filterwarnings("ignore", message=".*datetime.datetime.utcnow.*")

sys.path.insert(0, os.path.dirname(__file__))

# Now import everything else
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from typing import Optional
import httpx
import logging

# Silence LiteLLM logging
logging.getLogger("LiteLLM").setLevel(logging.ERROR)
logging.getLogger("litellm").setLevel(logging.ERROR)

from core.logger import get_logger, success_logger, error_logger
from core.session_manager import get_or_create_session, add_to_history, get_history
from agents.orchestrator.agent import run_orchestrator_async
from agents.mlff.agent import run_mlff_async
from core.config import config

logger = get_logger("app")
app = FastAPI(title="MLFF ADK Analytics", version="2.0.0")
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")


class QueryRequest(BaseModel):
    message: str
    session_id: Optional[str] = None

# In app.py startup event
@app.on_event("startup")
async def check_llm_health():
    try:
        async with httpx.AsyncClient(timeout=60.0) as client:
            # llama.cpp doesn't have /health, use /v1/models instead
            resp = await client.get(f"{config.LOCAL_LLM_BASE_URL}/models")
            if resp.status_code == 200:
                logger.info("LLM server is healthy")
            else:
                logger.warning(f"LLM server returned status {resp.status_code}")
    except Exception as e:
        logger.error(f"LLM server not reachable: {e}")

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.post("/query")
async def query(payload: QueryRequest):
    session_id = get_or_create_session(payload.session_id)
    user_query = payload.message.strip()
    if not user_query:
        raise HTTPException(status_code=400, detail="Query cannot be empty.")
    success_logger.info(f"Query received | session={session_id} | query={user_query[:80]}")
    try:
        orchestrator_result = await run_orchestrator_async(user_query=user_query, session_id=session_id)
        mlff_result = await run_mlff_async(orchestrator_payload=orchestrator_result, session_id=session_id)
        add_to_history(session_id, {
            "user_query": user_query,
            "sql": mlff_result.get("sql", ""),
            "row_count": mlff_result.get("row_count", 0),
            "explanation": mlff_result.get("explanation", ""),
            "intent": mlff_result.get("intent", ""),
            "confidence": mlff_result.get("confidence", 0),
            "ok": mlff_result.get("ok", False),
        })
        return {**mlff_result, "session_id": session_id}
    except Exception as e:
        error_logger.error(f"Pipeline error: {e}")
        return JSONResponse(status_code=500, content={
            "ok": False, "error": str(e), "session_id": session_id,
            "sql": "", "rows": [], "row_count": 0,
            "explanation": str(e), "chart_type": "none", "columns": [],
        })


@app.get("/history/{session_id}")
def get_session_history(session_id: str):
    return {"session_id": session_id, "history": get_history(session_id)}


@app.get("/health")
def health():
    return {"status": "ok", "service": "MLFF ADK App v2"}


@app.get("/agent-cards")
def agent_cards():
    from agents.orchestrator.agent_card import ORCHESTRATOR_CARD
    from agents.mlff.agent_card import MLFF_CARD
    return {"orchestrator": ORCHESTRATOR_CARD.to_dict(), "mlff": MLFF_CARD.to_dict()}