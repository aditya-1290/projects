# agents/critic/__init__.py
"""
Critic Agent - Evaluates and validates outputs
"""

from .agent import CriticAgent

__all__ = ['CriticAgent']