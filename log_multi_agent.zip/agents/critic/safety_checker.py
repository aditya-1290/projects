# agents/critic/safety_checker.py
"""
Safety Checker - Validates solutions for security risks, dangerous commands,
and potentially harmful recommendations before delivery to users.
"""

from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
import re


class SafetyLevel(Enum):
    SAFE = "safe"  # No concerns
    CAUTION = "caution"  # Minor concerns, warn user
    WARNING = "warning"  # Significant concerns, require confirmation
    DANGEROUS = "dangerous"  # Block entirely
    UNKNOWN = "unknown"


class SafetyCategory(Enum):
    COMMAND_EXECUTION = "command_execution"
    FILE_SYSTEM = "file_system"
    NETWORK = "network"
    PERMISSIONS = "permissions"
    DATA_LOSS = "data_loss"
    SECURITY = "security"
    PRIVACY = "privacy"
    SYSTEM_MODIFICATION = "system_modification"
    DEPENDENCY = "dependency"


@dataclass
class SafetyIssue:
    """Represents a specific safety concern."""
    category: SafetyCategory
    severity: SafetyLevel
    description: str
    location: str = ""  # The specific text that triggered this
    recommendation: str = ""
    pattern_matched: str = ""


@dataclass
class SafetyReport:
    """Complete safety assessment report."""
    overall_level: SafetyLevel = SafetyLevel.SAFE
    issues: List[SafetyIssue] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    blocked_commands: List[str] = field(default_factory=list)
    requires_user_confirmation: bool = False
    safe_to_execute: bool = True
    summary: str = ""


class SafetyChecker:
    """
    Checks solutions and recommendations for safety concerns.
    Identifies dangerous commands, security risks, and potential data loss.
    """

    def __init__(self):
        # Dangerous command patterns
        self.dangerous_commands = [
            (r'\brm\s+(-rf?|--recursive)\b', SafetyLevel.DANGEROUS, SafetyCategory.DATA_LOSS,
             "Force-delete command - can cause permanent data loss"),
            (r'\bdd\s+if=', SafetyLevel.DANGEROUS, SafetyCategory.DATA_LOSS,
             "Disk duplicator command - can overwrite disks"),
            (r'\bmkfs\.', SafetyLevel.DANGEROUS, SafetyCategory.DATA_LOSS,
             "Filesystem format command - will erase all data"),
            (r'\b:\(\)\s*\{', SafetyLevel.DANGEROUS, SafetyCategory.SYSTEM_MODIFICATION,
             "Fork bomb pattern - can crash system"),
            (r'>\s*/dev/sd[a-z]', SafetyLevel.DANGEROUS, SafetyCategory.DATA_LOSS,
             "Writing directly to disk device"),
        ]

        # High-risk patterns
        self.high_risk_patterns = [
            (r'\bchmod\s+777\b', SafetyLevel.WARNING, SafetyCategory.PERMISSIONS,
             "World-writable permissions - security risk"),
            (r'\beval\s*\(', SafetyLevel.WARNING, SafetyCategory.SECURITY,
             "Eval execution - can run arbitrary code"),
            (r'\bexec\s*\(', SafetyLevel.WARNING, SafetyCategory.SECURITY,
             "Exec execution - can run arbitrary code"),
            (r'(?i)\bdrop\s+table\b', SafetyLevel.WARNING, SafetyCategory.DATA_LOSS,
             "Drop table command - will delete database data"),
            (r'(?i)\bdelete\s+from\b', SafetyLevel.CAUTION, SafetyCategory.DATA_LOSS,
             "Delete query - may remove data permanently"),
            (r'\bsudo\s+', SafetyLevel.CAUTION, SafetyCategory.PERMISSIONS,
             "Sudo command - elevated privileges"),
            (r'\bchown\s+', SafetyLevel.CAUTION, SafetyCategory.PERMISSIONS,
             "Change ownership command"),
            (r'\bkill\s+-9\b', SafetyLevel.CAUTION, SafetyCategory.SYSTEM_MODIFICATION,
             "Force kill - may cause data corruption"),
        ]

        # Files that shouldn't be modified casually
        self.protected_files = [
            '/etc/passwd', '/etc/shadow', '/etc/sudoers',
            '/etc/ssh/', '/boot/', '/sys/', '/proc/',
            'C:\\Windows\\', 'C:\\System32\\',
        ]

        # Sensitive data patterns
        self.sensitive_data_patterns = [
            (r'(?i)password\s*[=:]\s*\S+', "Password exposure"),
            (r'(?i)api[_-]?key\s*[=:]\s*\S+', "API key exposure"),
            (r'(?i)token\s*[=:]\s*\S+', "Token exposure"),
            (r'(?i)secret\s*[=:]\s*\S+', "Secret exposure"),
        ]

    def check_solution(self, solution: Dict[str, Any]) -> SafetyReport:
        """
        Perform comprehensive safety check on a solution.

        Args:
            solution: The solution/response to check

        Returns:
            SafetyReport with all identified issues
        """
        report = SafetyReport()

        # Extract content to check
        content = self._extract_content(solution)

        if not content:
            report.overall_level = SafetyLevel.UNKNOWN
            report.summary = "No content to check"
            return report

        # Run all checks
        issues = []

        # ⭐ 1. Check for dangerous commands
        command_issues = self._check_dangerous_commands(content)
        issues.extend(command_issues)

        # ⭐ 2. Check for high-risk patterns
        risk_issues = self._check_high_risk_patterns(content)
        issues.extend(risk_issues)

        # ⭐ 3. Check for protected file access
        file_issues = self._check_protected_files(content)
        issues.extend(file_issues)

        # ⭐ 4. Check for sensitive data exposure
        sensitive_issues = self._check_sensitive_data(content)
        issues.extend(sensitive_issues)

        # ⭐ 5. Check for network safety
        network_issues = self._check_network_safety(content)
        issues.extend(network_issues)

        # ⭐ 6. Check for dependency risks
        dep_issues = self._check_dependency_risks(content)
        issues.extend(dep_issues)

        report.issues = issues

        # Determine overall safety level
        report.overall_level = self._determine_overall_level(issues)

        # Generate warnings
        report.warnings = [issue.description for issue in issues if
                           issue.severity in [SafetyLevel.WARNING, SafetyLevel.CAUTION]]

        # Extract blocked commands
        report.blocked_commands = [issue.pattern_matched for issue in issues if issue.severity == SafetyLevel.DANGEROUS]

        # Decision flags
        report.requires_user_confirmation = any(
            issue.severity in [SafetyLevel.WARNING, SafetyLevel.DANGEROUS]
            for issue in issues
        )
        report.safe_to_execute = not any(
            issue.severity == SafetyLevel.DANGEROUS
            for issue in issues
        )

        # Generate summary
        report.summary = self._generate_summary(report)

        return report

    def check_single_command(self, command: str) -> Tuple[bool, str]:
        """
        Quick check for a single command.

        Returns:
            (is_safe, reason)
        """
        for pattern, level, category, description in self.dangerous_commands:
            if re.search(pattern, command):
                return False, f"DANGEROUS: {description}"

        for pattern, level, category, description in self.high_risk_patterns:
            if re.search(pattern, command):
                return False, f"WARNING: {description}"

        return True, "Safe"

    def _extract_content(self, solution: Dict[str, Any]) -> str:
        """Extract content text from solution."""
        if isinstance(solution, str):
            return solution

        for field in ["recommended_solution", "solution", "user_explanation",
                      "content", "text", "output", "problem_understanding"]:
            if field in solution and solution[field]:
                return str(solution[field])

        return str(solution)

    # ============================================
    # Individual Safety Checks
    # ============================================

    def _check_dangerous_commands(self, content: str) -> List[SafetyIssue]:
        """Check for dangerous system commands."""
        issues = []

        for pattern, level, category, description in self.dangerous_commands:
            match = re.search(pattern, content)
            if match:
                # Check if warned about
                nearby = content[max(0, match.start() - 60):match.end() + 60]
                if any(w in nearby.lower() for w in ['warning', 'caution', 'avoid', "don't", 'never']):
                    # Downgrade if warned about
                    level = SafetyLevel.CAUTION
                    description += " (warned)"

                issues.append(SafetyIssue(
                    category=category,
                    severity=level,
                    description=description,
                    location=match.group(0),
                    recommendation=f"Avoid using '{match.group(0)}'. Consider safer alternatives.",
                    pattern_matched=match.group(0)
                ))

        return issues

    def _check_high_risk_patterns(self, content: str) -> List[SafetyIssue]:
        """Check for high-risk patterns."""
        issues = []

        for pattern, level, category, description in self.high_risk_patterns:
            match = re.search(pattern, content)
            if match:
                # Check if in warning context
                nearby = content[max(0, match.start() - 60):match.end() + 60]
                if any(w in nearby.lower() for w in ['warning', 'caution', 'careful', 'avoid']):
                    level = SafetyLevel.CAUTION

                issues.append(SafetyIssue(
                    category=category,
                    severity=level,
                    description=description,
                    location=nearby.strip()[:100],
                    recommendation=f"Exercise caution with '{match.group(0)}'. Review before executing.",
                    pattern_matched=match.group(0)
                ))

        return issues

    def _check_protected_files(self, content: str) -> List[SafetyIssue]:
        """Check for access to protected system files."""
        issues = []

        for protected_path in self.protected_files:
            if protected_path.lower() in content.lower():
                issues.append(SafetyIssue(
                    category=SafetyCategory.FILE_SYSTEM,
                    severity=SafetyLevel.WARNING,
                    description=f"Accessing protected system path: {protected_path}",
                    location=protected_path,
                    recommendation=f"Modifying {protected_path} can break the system. Ensure you have backups.",
                    pattern_matched=protected_path
                ))

        return issues

    def _check_sensitive_data(self, content: str) -> List[SafetyIssue]:
        """Check for exposed sensitive data."""
        issues = []

        for pattern, description in self.sensitive_data_patterns:
            matches = re.findall(pattern, content)
            for match in matches:
                issues.append(SafetyIssue(
                    category=SafetyCategory.PRIVACY,
                    severity=SafetyLevel.WARNING,
                    description=f"{description}: {match[:50]}...",
                    location=match[:80],
                    recommendation="Remove or mask sensitive credentials before sharing.",
                    pattern_matched=match[:50]
                ))

        return issues

    def _check_network_safety(self, content: str) -> List[SafetyIssue]:
        """Check for network safety concerns."""
        issues = []

        network_risks = [
            (r'(?i)curl\s+.*\|\s*(?:bash|sh|python)', SafetyLevel.DANGEROUS,
             "Piping remote content to shell - remote code execution risk"),
            (r'(?i)wget\s+.*\|\s*(?:bash|sh|python)', SafetyLevel.DANGEROUS,
             "Piping downloaded content to shell - remote code execution risk"),
            (r'(?i)nc\s+-[lL]', SafetyLevel.WARNING,
             "Netcat listener - opens network port"),
            (r'(?i)telnet\s+', SafetyLevel.CAUTION,
             "Telnet is unencrypted - use SSH instead"),
        ]

        for pattern, level, description in network_risks:
            if re.search(pattern, content):
                issues.append(SafetyIssue(
                    category=SafetyCategory.NETWORK,
                    severity=level,
                    description=description,
                    recommendation="Use secure alternatives.",
                    pattern_matched=pattern
                ))

        return issues

    def _check_dependency_risks(self, content: str) -> List[SafetyIssue]:
        """Check for dependency installation risks."""
        issues = []

        dep_risks = [
            (r'(?i)pip\s+install\s+(?!-r|--requirement)', SafetyLevel.CAUTION,
             "Pip install without pinned version - may install incompatible version"),
            (r'(?i)npm\s+install\s+-g', SafetyLevel.CAUTION,
             "Global npm install - requires sudo, security risk"),
            (r'(?i)gem\s+install', SafetyLevel.CAUTION,
             "Ruby gem install - verify source"),
        ]

        for pattern, level, description in dep_risks:
            if re.search(pattern, content):
                issues.append(SafetyIssue(
                    category=SafetyCategory.DEPENDENCY,
                    severity=level,
                    description=description,
                    recommendation="Pin versions and verify package sources.",
                    pattern_matched=pattern
                ))

        return issues

    # ============================================
    # Report Generation
    # ============================================

    def _determine_overall_level(self, issues: List[SafetyIssue]) -> SafetyLevel:
        """Determine overall safety level from all issues."""
        if not issues:
            return SafetyLevel.SAFE

        severities = [issue.severity for issue in issues]

        if SafetyLevel.DANGEROUS in severities:
            return SafetyLevel.DANGEROUS
        elif SafetyLevel.WARNING in severities:
            return SafetyLevel.WARNING
        elif SafetyLevel.CAUTION in severities:
            return SafetyLevel.CAUTION

        return SafetyLevel.SAFE

    def _generate_summary(self, report: SafetyReport) -> str:
        """Generate human-readable safety summary."""
        total_issues = len(report.issues)

        if total_issues == 0:
            return "✅ No safety concerns detected. Solution appears safe to execute."

        dangerous_count = sum(1 for i in report.issues if i.severity == SafetyLevel.DANGEROUS)
        warning_count = sum(1 for i in report.issues if i.severity == SafetyLevel.WARNING)
        caution_count = sum(1 for i in report.issues if i.severity == SafetyLevel.CAUTION)

        parts = []

        if dangerous_count > 0:
            parts.append(f"🚫 {dangerous_count} DANGEROUS issue(s) found - DO NOT EXECUTE")
        if warning_count > 0:
            parts.append(f"⚠️ {warning_count} WARNING(S) - Review carefully before proceeding")
        if caution_count > 0:
            parts.append(f"❗ {caution_count} Caution(s) - Be aware of potential risks")

        if not report.safe_to_execute:
            parts.append("❌ NOT SAFE TO EXECUTE - Contains dangerous operations")
        elif report.requires_user_confirmation:
            parts.append("🔐 User confirmation recommended before proceeding")

        return " | ".join(parts) if parts else "No safety concerns"