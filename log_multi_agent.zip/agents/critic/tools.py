# agents/critic/tools.py (MINIMAL)
"""
Critic Tools - Minimal utilities for evaluation
"""

from typing import Dict, Any, List


class CriticTools:
    """Minimal tools - model handles all evaluation logic"""

    @staticmethod
    def compare_outputs(original: Any, processed: Any) -> Dict[str, Any]:
        """Simple comparison metrics"""
        return {
            "original_size": len(str(original)),
            "processed_size": len(str(processed)),
            "changed": original != processed
        }