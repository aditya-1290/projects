# agents/critic/agent.py (REDESIGNED - Model-Driven)
"""
Critic Agent - Uses LLM to evaluate, validate, and improve agent outputs
"""

from typing import Dict, Any, List, Optional
import logging
from datetime import datetime

from agents.base_agent import BaseAgent, A2AMessage, MessageType, AgentState
from agents.agent_config import AgentConfig
from agents.critic.evaluator import SolutionEvaluator, EvaluationResult, QualityGrade
from agents.critic.safety_checker import SafetyChecker, SafetyReport, SafetyLevel

logger = logging.getLogger(__name__)


class CriticAgent(BaseAgent):
    """
    Critic agent that evaluates outputs from other agents,
    identifies issues, suggests improvements, and validates quality.
    This agent implements the reflection/review loop.
    """

    # agents/extractor/agent.py - FIXED __init__
    def __init__(self, agent_id: str = "critic", capability_path: str = None, config=None, **kwargs):

        # Check if first argument is actually an AgentConfig (test passes it as positional)
        if hasattr(agent_id, 'agent_id') and hasattr(agent_id, 'capabilities'):
            # First argument is actually an AgentConfig object
            config = agent_id
            agent_id = config.agent_id if hasattr(config, 'agent_id') else "extractor"
            if capability_path is None:
                capability_path = getattr(config, 'capability_path', None)
        elif config is not None:
            # Old style with explicit config= parameter
            agent_id = config.agent_id if hasattr(config, 'agent_id') else "extractor"
            if capability_path is None:
                capability_path = getattr(config, 'capability_path', None)

        # Make sure capability_path is not None
        if capability_path is None:
            from pathlib import Path
            default_path = Path(__file__).parent / "capabilities.json"
            if default_path.exists():
                capability_path = str(default_path)

        super().__init__(agent_id=agent_id, capability_path=capability_path)
        self.evaluator = SolutionEvaluator()
        self.safety_checker = SafetyChecker()
        self.evaluation_history = []

    def get_system_prompt(self) -> str:
        """Define the critic's persona and capabilities"""
        return """
        You are an expert quality assurance agent. Your purpose is to critically 
        evaluate outputs from other agents, ensure quality, safety, and accuracy.

        Your capabilities:
        - Evaluate the quality and accuracy of log analysis
        - Validate solutions and recommendations
        - Check for completeness and clarity
        - Identify potential issues, biases, or errors
        - Assess confidence and reliability of findings
        - Ensure safety and security of proposed actions
        - Suggest improvements and iterations

        Your evaluation criteria:
        1. ACCURACY: Are the findings correct based on the data?
        2. COMPLETENESS: Is anything important missing?
        3. CLARITY: Is the output clear and understandable?
        4. ACTIONABILITY: Can the user act on these recommendations?
        5. SAFETY: Are there any risks in the proposed actions?
        6. CONFIDENCE: Is the confidence level appropriate?

        Your thinking process:
        1. Review the input data and the agent's output
        2. Check each evaluation criterion
        3. Identify specific issues with examples
        4. Suggest concrete improvements
        5. Provide an overall quality score (0-100)
        6. Decide: PASS (good enough), REVISE (needs improvement), or REJECT (start over)

        Be constructive in your criticism - always suggest how to improve.
        """

    async def process(self, message: A2AMessage) -> A2AMessage:
        """
        Process incoming A2A message.
        This is the entry point called by the communication bus.
        It bridges A2A protocol to the agent's process_task logic.
        """

        # Handle capability queries
        if message.task and message.task.get("action") == "report_capabilities":
            return A2AMessage(
                message_type=MessageType.RESPONSE,
                sender_id=self.agent_id,
                sender_type=self.capability.agent_name,
                target_id=message.sender_id,
                correlation_id=message.message_id,
                response=self.capability.to_dict(),
                confidence=1.0
            )

        # Check if agent can handle this task
        task = message.task or {}
        if not self.can_handle(task):
            return A2AMessage(
                message_type=MessageType.RESPONSE,
                sender_id=self.agent_id,
                sender_type=self.capability.agent_name,
                target_id=message.sender_id,
                correlation_id=message.message_id,
                response={
                    "can_handle": False,
                    "reason": self.capability.out_of_scope_message,
                    "suggested_agents": self.capability.fallback_agents,
                    "my_capabilities": self.capability.capabilities
                },
                confidence=0.0
            )

        # Process the task using the agent's existing logic
        try:
            self.state = AgentState.PROCESSING

            # Convert A2A task format to what process_task expects
            task_input = {
                "input": task.get("input", task),
                "parameters": task.get("parameters", {}),
                "context": message.context or {}
            }

            # Call the agent's existing process_task method
            result = await self.process_task(task_input)

            self.state = AgentState.IDLE

            return A2AMessage(
                message_type=MessageType.RESPONSE,
                sender_id=self.agent_id,
                sender_type=self.capability.agent_name,
                target_id=message.sender_id,
                correlation_id=message.message_id,
                response=result,
                confidence=0.85
            )

        except Exception as e:
            self.state = AgentState.ERROR
            return A2AMessage(
                message_type=MessageType.ERROR,
                sender_id=self.agent_id,
                sender_type=self.capability.agent_name,
                target_id=message.sender_id,
                correlation_id=message.message_id,
                error=str(e)
            )

    async def process_task(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """Evaluate agent output using the evaluator and safety checker."""

        input_data = task.get("input", {})
        output_to_evaluate = input_data.get("input", input_data)

        # Extract the solution and original context
        solution = output_to_evaluate.get("solution", output_to_evaluate)
        original_task = output_to_evaluate.get("original_task", {})

        logger.info(f"[CRITIC] Evaluating solution...")
        print(f"  [CRITIC] Running evaluation...")

        # ⭐ STEP 1: Quality Evaluation
        evaluation_result = self.evaluator.evaluate(solution, {"original_task": original_task})

        print(f"  [CRITIC] Quality Score: {evaluation_result.overall_score}/100 ({evaluation_result.grade.value})")
        print(
            f"  [CRITIC] Accuracy: {evaluation_result.accuracy_score} | Completeness: {evaluation_result.completeness_score}")
        print(
            f"  [CRITIC] Clarity: {evaluation_result.clarity_score} | Actionability: {evaluation_result.actionability_score}")

        # ⭐ STEP 2: Safety Check
        safety_report = self.safety_checker.check_solution(solution)

        print(f"  [CRITIC] Safety: {safety_report.overall_level.value}")
        if safety_report.issues:
            print(f"  [CRITIC] Safety issues: {len(safety_report.issues)}")
        print(f"  [CRITIC] {safety_report.summary}")

        # ⭐ STEP 3: Generate improvements if needed
        improvements = []
        if evaluation_result.requires_revision:
            # Try model for improvement suggestions
            if self.model and not isinstance(self.model, dict):
                try:
                    improvement_prompt = {
                        "task": "suggest_improvements",
                        "original_solution": str(solution)[:1000],
                        "quality_score": evaluation_result.overall_score,
                        "weaknesses": evaluation_result.weaknesses,
                        "instructions": "Suggest 2-3 specific improvements to address the weaknesses."
                    }
                    model_suggestions = await asyncio.wait_for(self.think(improvement_prompt), timeout=10)
                    if model_suggestions and not model_suggestions.startswith("["):
                        improvements = [s.strip() for s in model_suggestions.split('\n') if s.strip()]
                except:
                    pass

            if not improvements:
                improvements = evaluation_result.improvement_suggestions

        # ⭐ STEP 4: Build final result
        verdict = "PASS"
        if evaluation_result.requires_rejection or not safety_report.safe_to_execute:
            verdict = "REJECT"
        elif evaluation_result.requires_revision or safety_report.requires_user_confirmation:
            verdict = "REVISE"

        result = {
            "success": True,
            "agent_id": self.agent_id,

            # Quality evaluation
            "quality_score": evaluation_result.overall_score,
            "grade": evaluation_result.grade.value,
            "accuracy": evaluation_result.accuracy_score,
            "completeness": evaluation_result.completeness_score,
            "clarity": evaluation_result.clarity_score,
            "actionability": evaluation_result.actionability_score,
            "safety_score": evaluation_result.safety_score,

            # Detailed evaluation
            "strengths": evaluation_result.strengths,
            "weaknesses": evaluation_result.weaknesses,
            "improvements": improvements,
            "missing_information": evaluation_result.missing_information,
            "evaluator_notes": evaluation_result.evaluator_notes,

            # Safety report
            "safety_level": safety_report.overall_level.value,
            "safety_issues": [
                {"category": i.category.value, "severity": i.severity.value, "description": i.description}
                for i in safety_report.issues
            ],
            "safety_warnings": safety_report.warnings,
            "safe_to_execute": safety_report.safe_to_execute,
            "requires_user_confirmation": safety_report.requires_user_confirmation,
            "safety_summary": safety_report.summary,

            # Decision
            "verdict": verdict,
            "needs_revision": verdict in ["REVISE", "REJECT"],

            # Metadata
            "confidence": evaluation_result.overall_score / 100,
            "timestamp": datetime.now().isoformat()
        }

        return result

    def _extract_quality_score(self, verdict: str) -> float:
        """Extract quality score from verdict text"""
        # The model would include a score in its response
        # This is a simplified extraction
        import re
        match = re.search(r'(\d+)/100', verdict)
        if match:
            return int(match.group(1)) / 100
        return 0.5  # Default if no score found

    def _extract_decision(self, verdict: str) -> str:
        """Extract PASS/REVISE/REJECT decision"""
        if "PASS" in verdict.upper():
            return "PASS"
        elif "REJECT" in verdict.upper():
            return "REJECT"
        else:
            return "REVISE"