# agents/critic/evaluator.py
"""
Solution Evaluator - Evaluates the quality and correctness of agent outputs.
Provides detailed quality scoring across multiple criteria.
"""

from typing import Dict, Any, List, Optional
from dataclasses import dataclass, field
from enum import Enum
import re


class QualityGrade(Enum):
    EXCELLENT = "excellent"  # 90-100
    GOOD = "good"  # 75-89
    ADEQUATE = "adequate"  # 60-74
    NEEDS_IMPROVEMENT = "needs_improvement"  # 40-59
    POOR = "poor"  # <40
    UNKNOWN = "unknown"


@dataclass
class EvaluationResult:
    """Structured evaluation result."""
    overall_score: float = 0.0
    grade: QualityGrade = QualityGrade.UNKNOWN

    # Individual criteria scores (0-100)
    accuracy_score: float = 0.0
    completeness_score: float = 0.0
    clarity_score: float = 0.0
    actionability_score: float = 0.0
    safety_score: float = 0.0

    # Details
    strengths: List[str] = field(default_factory=list)
    weaknesses: List[str] = field(default_factory=list)
    improvement_suggestions: List[str] = field(default_factory=list)
    missing_information: List[str] = field(default_factory=list)

    # Meta
    evaluator_notes: str = ""
    requires_revision: bool = False
    requires_rejection: bool = False


class SolutionEvaluator:
    """
    Evaluates solutions and agent outputs across multiple quality dimensions.
    Provides structured feedback for improvement.
    """

    def __init__(self):
        # Quality criteria with their weights
        self.criteria_weights = {
            "accuracy": 0.30,  # Is it correct?
            "completeness": 0.20,  # Is anything missing?
            "clarity": 0.20,  # Is it understandable?
            "actionability": 0.15,  # Can the user act on it?
            "safety": 0.15,  # Are there risks?
        }

        # Minimum acceptable scores
        self.thresholds = {
            "pass": 70,  # Overall score to pass
            "revision": 50,  # Below this needs revision
            "rejection": 30,  # Below this should be rejected
        }

    def evaluate(self, solution: Dict[str, Any], context: Dict[str, Any] = None) -> EvaluationResult:
        """
        Perform comprehensive evaluation of a solution.

        Args:
            solution: The solution/response to evaluate
            context: Original problem context for comparison

        Returns:
            Structured EvaluationResult with scores and feedback
        """
        result = EvaluationResult()

        # Extract the actual content to evaluate
        content = self._extract_content(solution)
        original_problem = context.get("original_task", "") if context else ""

        # ⭐ 1. ACCURACY - Is the solution correct?
        result.accuracy_score = self._evaluate_accuracy(content, solution, context)

        # ⭐ 2. COMPLETENESS - Is everything covered?
        result.completeness_score = self._evaluate_completeness(content, solution)

        # ⭐ 3. CLARITY - Is it clear and understandable?
        result.clarity_score = self._evaluate_clarity(content)

        # ⭐ 4. ACTIONABILITY - Can the user take action?
        result.actionability_score = self._evaluate_actionability(content)

        # ⭐ 5. SAFETY - Are there safety concerns?
        result.safety_score = self._evaluate_safety(content)

        # Calculate weighted overall score
        result.overall_score = self._calculate_weighted_score(result)

        # Determine grade
        result.grade = self._determine_grade(result.overall_score)

        # Generate feedback
        result.strengths = self._identify_strengths(content, result)
        result.weaknesses = self._identify_weaknesses(content, result)
        result.improvement_suggestions = self._generate_improvements(content, result)
        result.missing_information = self._identify_missing_info(content, original_problem)

        # Decision flags
        result.requires_rejection = result.overall_score < self.thresholds["rejection"]
        result.requires_revision = result.overall_score < self.thresholds["revision"]

        # Evaluator notes
        result.evaluator_notes = self._generate_notes(result)

        return result

    def _extract_content(self, solution: Dict[str, Any]) -> str:
        """Extract the main content text from a solution."""
        if isinstance(solution, str):
            return solution

        # Try common fields
        for field in ["recommended_solution", "solution", "user_explanation",
                      "problem_understanding", "content", "text", "output"]:
            if field in solution and solution[field]:
                return str(solution[field])

        # Try nested
        if "data" in solution:
            return self._extract_content(solution["data"])

        return str(solution)

    # ============================================
    # Individual Criteria Evaluators
    # ============================================

    def _evaluate_accuracy(self, content: str, solution: Dict, context: Dict) -> float:
        """Evaluate factual accuracy of the solution."""
        score = 75.0  # Start at 75 (assume decent)

        if not content or len(content) < 20:
            return 20.0  # Empty or very short - likely inaccurate

        # Positive indicators of accuracy
        accuracy_indicators = [
            (r'\d+', 2),  # Has specific numbers/data
            (r'step \d', 3),  # Has step-by-step instructions
            (r'(?i)because', 2),  # Provides reasoning
            (r'(?i)therefore', 2),  # Draws conclusions
            (r'(?i)verify|check|confirm', 3),  # Suggests verification
        ]

        for pattern, bonus in accuracy_indicators:
            if re.search(pattern, content):
                score += bonus

        # Negative indicators
        inaccuracy_indicators = [
            (r'(?i)i think|maybe|probably|possibly', -3),  # Uncertainty
            (r'(?i)i am not sure|uncertain', -5),  # Explicit uncertainty
            (r'\[.*?\]', -2),  # Placeholder text
            (r'(?i)error:|failed:', -3),  # Error in response
        ]

        for pattern, penalty in inaccuracy_indicators:
            if re.search(pattern, content):
                score += penalty

        return max(0, min(100, score))

    def _evaluate_completeness(self, content: str, solution: Dict) -> float:
        """Evaluate how complete and thorough the solution is."""
        score = 60.0  # Start at 60

        if not content:
            return 0.0

        # Check for expected sections
        expected_sections = {
            "problem_understanding": ["problem", "issue", "error", "what's happening"],
            "solution_steps": ["step", "fix", "resolve", "solution", "action"],
            "explanation": ["because", "reason", "cause", "explain"],
            "verification": ["verify", "check", "confirm", "test", "monitor"],
            "risks": ["risk", "caution", "warning", "careful", "mitigation"],
        }

        sections_found = 0
        for section_name, keywords in expected_sections.items():
            if any(kw in content.lower() for kw in keywords):
                sections_found += 1
                score += 8

        # Bonus for having solution in the dict
        if isinstance(solution, dict):
            if solution.get("recommended_solution"):
                score += 5
            if solution.get("risk_assessment"):
                score += 5
            if solution.get("user_explanation"):
                score += 5

        return max(0, min(100, score))

    def _evaluate_clarity(self, content: str) -> float:
        """Evaluate how clear and readable the solution is."""
        score = 70.0

        if not content:
            return 0.0

        # Positive clarity indicators
        if len(content) > 50:
            score += 5  # Has substantial content

        if re.search(r'\d+\.', content):
            score += 5  # Uses numbered steps

        if re.search(r'^[#\*\-\•]', content, re.MULTILINE):
            score += 3  # Uses formatting

        if len(content.split()) / max(len(content.splitlines()), 1) < 30:
            score += 5  # Reasonable line length

        # Negative clarity indicators
        if len(content) > 2000:
            score -= 5  # Too long

        if re.search(r'[^\x00-\x7F]+', content):
            score -= 3  # Non-ASCII characters

        jargon_count = len(re.findall(r'\b(?:utilize|leverage|synergize|paradigm|ecosystem)\b', content, re.IGNORECASE))
        score -= jargon_count * 2  # Penalize unnecessary jargon

        return max(0, min(100, score))

    def _evaluate_actionability(self, content: str) -> float:
        """Evaluate whether the user can actually act on the solution."""
        score = 50.0

        if not content:
            return 0.0

        # Highly actionable indicators
        if re.search(r'(?i)step\s+\d', content):
            score += 15  # Has step-by-step

        if re.search(r'```|`[^`]+`', content):
            score += 10  # Has code/commands

        if re.search(r'(?i)(?:run|execute|type|enter|click|go to|open)', content):
            score += 10  # Has direct instructions

        if re.search(r'(?i)(?:check|verify|confirm|test)', content):
            score += 8  # Has verification steps

        # Not actionable indicators
        if re.search(r'(?i)(?:consider|perhaps|might want to)', content):
            score -= 5  # Vague suggestions

        if content.count('?') > 3:
            score -= 5  # Too many questions, not enough answers

        return max(0, min(100, score))

    def _evaluate_safety(self, content: str) -> float:
        """Evaluate safety concerns in the solution."""
        score = 85.0  # Start high - assume safe

        if not content:
            return 50.0

        # Dangerous commands/patterns
        dangerous_patterns = [
            (r'\brm\s+-rf\b', -20, "Force delete command"),
            (r'\bdd\s+if=', -20, "Disk destroyer command"),
            (r'\bchmod\s+777\b', -15, "World-writable permissions"),
            (r'\beval\(', -15, "Eval execution"),
            (r'\bexec\(', -15, "Exec execution"),
            (r'(?i)drop\s+table', -15, "Drop table command"),
            (r'(?i)delete\s+from\s+\w+\s+where', -10, "Delete query"),
            (r'(?i)shutdown|reboot|restart', -8, "System restart command"),
        ]

        for pattern, penalty, description in dangerous_patterns:
            match = re.search(pattern, content)
            if match:
                # Check if it's in a warning context (mitigated)
                nearby = content[max(0, match.start() - 50):match.end() + 50]
                if any(warn in nearby.lower() for warn in ['warning', 'caution', 'careful', 'avoid', "don't", 'never']):
                    score += penalty // 2  # Half penalty if warned about
                else:
                    score += penalty

        # Safety-conscious indicators
        safety_indicators = [
            (r'(?i)(?:backup|back up)\s+(?:before|first)', 5),
            (r'(?i)(?:test|verify)\s+(?:first|before|after)', 5),
            (r'(?i)(?:warning|caution|careful|attention)', 3),
        ]

        for pattern, bonus in safety_indicators:
            if re.search(pattern, content):
                score += bonus

        return max(0, min(100, score))

    # ============================================
    # Scoring & Grading
    # ============================================

    def _calculate_weighted_score(self, result: EvaluationResult) -> float:
        """Calculate weighted overall score from individual criteria."""
        weighted = (
                result.accuracy_score * self.criteria_weights["accuracy"] +
                result.completeness_score * self.criteria_weights["completeness"] +
                result.clarity_score * self.criteria_weights["clarity"] +
                result.actionability_score * self.criteria_weights["actionability"] +
                result.safety_score * self.criteria_weights["safety"]
        )
        return round(weighted, 1)

    def _determine_grade(self, score: float) -> QualityGrade:
        """Determine quality grade from score."""
        if score >= 90:
            return QualityGrade.EXCELLENT
        elif score >= 75:
            return QualityGrade.GOOD
        elif score >= 60:
            return QualityGrade.ADEQUATE
        elif score >= 40:
            return QualityGrade.NEEDS_IMPROVEMENT
        else:
            return QualityGrade.POOR

    # ============================================
    # Feedback Generation
    # ============================================

    def _identify_strengths(self, content: str, result: EvaluationResult) -> List[str]:
        """Identify strengths of the solution."""
        strengths = []

        if result.accuracy_score >= 80:
            strengths.append("Accurate and factually correct")
        if result.completeness_score >= 80:
            strengths.append("Comprehensive coverage of the problem")
        if result.clarity_score >= 80:
            strengths.append("Clear and well-structured explanation")
        if result.actionability_score >= 80:
            strengths.append("Highly actionable with specific steps")
        if result.safety_score >= 80:
            strengths.append("Safety-conscious with appropriate warnings")

        if len(content.splitlines()) > 3:
            strengths.append("Well-structured with multiple sections")

        if re.search(r'\d+\.\s+\w+', content):
            strengths.append("Uses numbered steps for clarity")

        if not strengths:
            strengths.append("Provides a response to the problem")

        return strengths

    def _identify_weaknesses(self, content: str, result: EvaluationResult) -> List[str]:
        """Identify weaknesses of the solution."""
        weaknesses = []

        if result.accuracy_score < 60:
            weaknesses.append("Accuracy concerns - may contain incorrect information")
        if result.completeness_score < 60:
            weaknesses.append("Incomplete - missing important details or sections")
        if result.clarity_score < 60:
            weaknesses.append("Unclear - difficult to understand or follow")
        if result.actionability_score < 60:
            weaknesses.append("Not actionable - lacks concrete steps")
        if result.safety_score < 60:
            weaknesses.append("Safety concerns - potentially risky recommendations")

        if len(content) < 100:
            weaknesses.append("Response is too brief - needs more detail")

        if content.count('?') > 3:
            weaknesses.append("Contains more questions than answers")

        return weaknesses

    def _generate_improvements(self, content: str, result: EvaluationResult) -> List[str]:
        """Generate specific improvement suggestions."""
        improvements = []

        if result.accuracy_score < 80:
            improvements.append("Verify facts and provide specific evidence or data points")

        if result.completeness_score < 80:
            improvements.append("Add verification steps and expected outcomes")
            improvements.append("Include potential risks and mitigation strategies")

        if result.clarity_score < 80:
            improvements.append("Use numbered steps and clear headings for structure")
            improvements.append("Break long paragraphs into shorter, focused sections")

        if result.actionability_score < 80:
            improvements.append("Add specific commands, code snippets, or configuration examples")
            improvements.append("Include expected outcomes for each step")

        if result.safety_score < 80:
            improvements.append("Add warnings before dangerous operations")
            improvements.append("Mention backup/recovery steps before making changes")

        if not improvements:
            improvements.append("Minor: Consider adding an executive summary at the top")

        return improvements

    def _identify_missing_info(self, content: str, original_problem: str) -> List[str]:
        """Identify potentially missing information."""
        missing = []

        if "error" in (original_problem or "").lower() and "error" not in content.lower():
            missing.append("Specific error message reference")

        if not re.search(r'\d{4}-\d{2}-\d{2}', content):
            missing.append("Timestamps or timing information")

        if not re.search(r'(?i)(?:config|setting|parameter|env)', content):
            missing.append("Configuration details")

        if not re.search(r'(?i)(?:log|output|result)', content):
            missing.append("Expected log output after fix")

        return missing

    def _generate_notes(self, result: EvaluationResult) -> str:
        """Generate overall evaluator notes."""
        grade = result.grade.value.replace('_', ' ').title()
        notes = f"Overall: {grade} ({result.overall_score}/100). "

        if result.requires_rejection:
            notes += "RECOMMEND REJECTION - Quality is too low. "
        elif result.requires_revision:
            notes += "REVISION RECOMMENDED - Needs improvement before delivery. "
        else:
            notes += "Meets quality standards. "

        if result.weaknesses:
            notes += f"{len(result.weaknesses)} weakness(es) identified. "
        if result.strengths:
            notes += f"{len(result.strengths)} strength(s) noted."

        return notes