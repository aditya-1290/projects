# agents/solver/prompts.py
"""
Solver Prompts - Prompt templates for solution generation
"""


class SolverPrompts:
    """Prompt templates for the solver agent"""

    @staticmethod
    def get_solution_prompt(problem_description: str, context: str = "") -> str:
        """Generate a prompt for solution generation"""
        return f"""
        Problem Description:
        {problem_description}

        Additional Context:
        {context if context else 'No additional context provided'}

        Please provide a comprehensive solution including:
        1. Root cause analysis
        2. Step-by-step fix instructions
        3. Verification steps
        4. Prevention measures
        5. Alternative approaches if applicable
        """

    @staticmethod
    def get_explanation_prompt(technical_issue: str, user_level: str = "intermediate") -> str:
        """Generate a prompt for explaining technical issues"""
        return f"""
        Technical Issue: {technical_issue}
        Target Audience Level: {user_level}

        Please explain:
        1. What happened in simple terms
        2. Why it happened
        3. What the impact is
        4. How it was or can be fixed
        5. How to prevent it in the future

        Adjust the technical depth based on the target audience level.
        """