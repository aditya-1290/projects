# agents/solver/explanation_generator.py
"""
Explanation Generator - Generates human-readable explanations for technical issues
"""

from typing import Dict, Any, List, Optional


class ExplanationGenerator:
    """
    Generates clear, human-readable explanations for technical issues.
    Adapts tone and detail based on audience.
    """

    def __init__(self):
        self.audience_levels = {
            "beginner": {
                "tone": "simple",
                "use_analogies": True,
                "avoid_jargon": True,
                "detail_level": "basic"
            },
            "intermediate": {
                "tone": "balanced",
                "use_analogies": True,
                "avoid_jargon": False,
                "detail_level": "moderate"
            },
            "expert": {
                "tone": "technical",
                "use_analogies": False,
                "avoid_jargon": False,
                "detail_level": "detailed"
            }
        }

    def explain_error(self, error_type: str, context: Dict = None,
                      audience: str = "intermediate") -> str:
        """
        Explain an error in human-readable terms.

        Args:
            error_type: The type of error
            context: Additional context
            audience: beginner, intermediate, or expert

        Returns:
            Human-readable explanation
        """
        explanations = {
            "connection_refused": {
                "simple": "The system tried to connect to another service but was rejected. Like knocking on a door and nobody answering.",
                "technical": "TCP connection attempt was actively refused by the target host. This typically means the target service is not listening on the specified port."
            },
            "timeout": {
                "simple": "The system waited too long for a response. Like calling someone and they never pick up.",
                "technical": "The operation exceeded its maximum wait time. This can be caused by network latency, overloaded services, or deadlocked resources."
            },
            "out_of_memory": {
                "simple": "The system ran out of memory. Like trying to fit too many things in a small box.",
                "technical": "The process exceeded its allocated memory. This can be caused by memory leaks, insufficient RAM, or large data processing."
            },
            "permission_denied": {
                "simple": "The system doesn't have permission to do this. Like trying to enter a room without a key.",
                "technical": "The operation was denied due to insufficient permissions. Check file permissions, user roles, and access control lists."
            },
            "file_not_found": {
                "simple": "The system couldn't find the file it was looking for. Like looking for a book that's been moved.",
                "technical": "The specified file path does not exist. Verify the path is correct and the file hasn't been moved or deleted."
            },
            "null_pointer": {
                "simple": "The program tried to use something that doesn't exist yet. Like trying to read a page from an empty book.",
                "technical": "A null reference was dereferenced. This occurs when code tries to access a member of an object that hasn't been initialized."
            },
            "database_error": {
                "simple": "The system had trouble talking to the database. Like trying to read from a library where the books are locked up.",
                "technical": "Database operation failed. This could be due to connection issues, query errors, deadlocks, or schema problems."
            },
            "authentication_failed": {
                "simple": "The system couldn't verify your identity. Like showing an expired ID card.",
                "technical": "Authentication credentials were rejected. Check username/password, token expiry, or authentication service status."
            },
            "disk_full": {
                "simple": "The storage is completely full. Like a closet with no more space for anything.",
                "technical": "Disk usage has reached 100%. No more data can be written until space is freed up."
            },
            "ssl_error": {
                "simple": "The secure connection couldn't be established. Like a security badge that's expired.",
                "technical": "SSL/TLS handshake failed. Common causes include expired certificates, mismatched hostnames, or untrusted certificate authorities."
            },
        }

        # Get the explanation for this error type
        error_info = explanations.get(error_type, {
            "simple": f"An error of type '{error_type}' occurred.",
            "technical": f"An error of type '{error_type}' was detected in the system."
        })

        # Get audience settings
        settings = self.audience_levels.get(audience, self.audience_levels["intermediate"])

        # Build explanation
        parts = []

        if settings["tone"] == "simple":
            parts.append(error_info.get("simple", error_info.get("technical", "")))
        else:
            parts.append(error_info.get("technical", error_info.get("simple", "")))

        # Add context if available
        if context:
            if context.get("affected_component"):
                parts.append(f"\nThis affects: {context['affected_component']}")
            if context.get("frequency"):
                parts.append(f"\nOccurrence: {context['frequency']}")

        # Add analogy for non-experts
        if settings["use_analogies"] and audience != "expert":
            parts.append(f"\n\nThink of it like this: {error_info.get('simple', '')}")

        return "\n".join(parts)

    def explain_solution(self, fix: Dict[str, Any], audience: str = "intermediate") -> str:
        """
        Explain a solution in simple terms.

        Args:
            fix: The fix dictionary from FixGenerator
            audience: beginner, intermediate, or expert

        Returns:
            Human-readable solution explanation
        """
        parts = [
            f"Problem: {fix.get('error_type', 'Unknown issue')}",
            f"\nSolution Summary: {fix.get('summary', 'Apply the following fix')}",
            f"\nSteps to resolve:"
        ]

        for i, step in enumerate(fix.get("steps", []), 1):
            parts.append(f"  {i}. {step}")

        if fix.get("code_patch"):
            parts.append(f"\nCode change needed:\n```\n{fix['code_patch']}\n```")

        if fix.get("warnings"):
            parts.append(f"\n⚠️ Warnings:")
            for warning in fix["warnings"]:
                parts.append(f"  - {warning}")

        if fix.get("verification"):
            parts.append(f"\n✅ To verify the fix: {fix['verification']}")

        return "\n".join(parts)

    def generate_summary(self, analysis: Dict[str, Any],
                         fixes: List[Dict], audience: str = "intermediate") -> str:
        """
        Generate a complete summary of the analysis and fixes.

        Args:
            analysis: Error analysis results
            fixes: Generated fixes
            audience: Target audience level

        Returns:
            Complete summary
        """
        total_errors = analysis.get("total_errors", 0)
        top_error = analysis.get("top_error", "unknown")
        top_category = analysis.get("top_category", "unknown")

        parts = [
            "=" * 50,
            "LOG ANALYSIS SUMMARY",
            "=" * 50,
            f"\nTotal errors found: {total_errors}",
            f"Most common error: {top_error}",
            f"Primary category: {top_category}",
        ]

        if analysis.get("needs_immediate_attention"):
            parts.append("\n⚠️ IMMEDIATE ATTENTION REQUIRED!")

        parts.append(f"\nTop fixes to apply:")
        for i, fix in enumerate(fixes[:3], 1):
            parts.append(f"\n  Fix {i}: {fix.get('error_type')} "
                         f"({fix.get('affected_entries', 0)} occurrences)")
            parts.append(f"  Summary: {fix.get('summary', '')}")

        parts.append(f"\n{'=' * 50}")
        parts.append("For detailed steps, see the full analysis above.")
        parts.append("=" * 50)

        return "\n".join(parts)