# agents/solver/tools.py
"""
Solver Tools - Utility functions for solution generation
"""

from typing import Dict, Any, List, Optional
import re


class SolverTools:
    """Utility tools for the solver agent"""

    @staticmethod
    def extract_error_message(log_entry: str) -> Optional[str]:
        """Extract error message from a log entry"""
        patterns = [
            r'Error:\s*(.+?)(?:\n|$)',
            r'Exception:\s*(.+?)(?:\n|$)',
            r'FATAL:\s*(.+?)(?:\n|$)',
            r'ERROR\s*(.+?)(?:\n|$)',
            r'Failed:\s*(.+?)(?:\n|$)',
        ]

        for pattern in patterns:
            match = re.search(pattern, log_entry, re.IGNORECASE)
            if match:
                return match.group(1).strip()

        return None

    @staticmethod
    def categorize_solution_type(error_message: str) -> str:
        """Categorize the type of solution needed"""
        categories = {
            'configuration': ['config', 'settings', 'properties', 'ini', 'yaml', 'json'],
            'network': ['connection', 'timeout', 'refused', 'unreachable', 'dns'],
            'permission': ['denied', 'unauthorized', 'forbidden', 'access'],
            'database': ['sql', 'query', 'table', 'column', 'index', 'constraint'],
            'memory': ['memory', 'heap', 'stack', 'overflow', 'out of'],
            'syntax': ['syntax', 'invalid', 'unexpected', 'token', 'parse'],
            'runtime': ['null', 'undefined', 'type', 'cast', 'reference'],
            'dependency': ['module', 'package', 'import', 'require', 'missing'],
        }

        error_lower = error_message.lower() if error_message else ""

        for category, keywords in categories.items():
            if any(keyword in error_lower for keyword in keywords):
                return category

        return "general"

    @staticmethod
    def format_solution_as_checklist(steps: List[str]) -> str:
        """Format solution steps as a checklist"""
        if not steps:
            return "No steps provided"

        checklist = "## Solution Checklist:\n\n"
        for i, step in enumerate(steps, 1):
            checklist += f"{i}. {step}\n"

        return checklist

    @staticmethod
    def extract_code_blocks(text: str) -> List[str]:
        """Extract code blocks from text"""
        pattern = r'```(?:\w+)?\n(.*?)```'
        matches = re.findall(pattern, text, re.DOTALL)
        return matches

    @staticmethod
    def get_risk_level(solution: str) -> str:
        """Assess the risk level of a solution"""
        high_risk_keywords = ['delete', 'drop', 'remove', 'rm ', 'format', 'truncate']
        medium_risk_keywords = ['update', 'modify', 'change', 'alter', 'move']

        solution_lower = solution.lower()

        if any(keyword in solution_lower for keyword in high_risk_keywords):
            return "HIGH"
        elif any(keyword in solution_lower for keyword in medium_risk_keywords):
            return "MEDIUM"
        else:
            return "LOW"