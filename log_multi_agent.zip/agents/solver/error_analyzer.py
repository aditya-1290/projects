# agents/solver/error_analyzer.py
"""
Error Analyzer - Analyzes errors and identifies root causes
"""

from typing import Dict, Any, List, Optional
import re


class ErrorAnalyzer:
    """
    Analyzes error patterns in logs to identify root causes.
    Works with the Solver agent to understand what went wrong.
    """

    def __init__(self):
        self.error_patterns = {
            "connection_refused": {
                "pattern": r"connection refused|connection refused",
                "likely_cause": "Service is not running or port is blocked",
                "category": "network"
            },
            "timeout": {
                "pattern": r"timeout|timed out|timedout",
                "likely_cause": "Slow response, network latency, or resource exhaustion",
                "category": "performance"
            },
            "out_of_memory": {
                "pattern": r"out of memory|OOM|memory exhausted",
                "likely_cause": "Memory leak or insufficient memory allocation",
                "category": "resource"
            },
            "permission_denied": {
                "pattern": r"permission denied|access denied|forbidden",
                "likely_cause": "Insufficient permissions or authentication failure",
                "category": "security"
            },
            "file_not_found": {
                "pattern": r"file not found|no such file|cannot find",
                "likely_cause": "Missing file, incorrect path, or deleted resource",
                "category": "configuration"
            },
            "null_pointer": {
                "pattern": r"null pointer|null reference|NoneType|undefined is not",
                "likely_cause": "Uninitialized variable or missing null check",
                "category": "code_bug"
            },
            "database_error": {
                "pattern": r"database error|sql error|query failed|deadlock",
                "likely_cause": "Database connection issue, bad query, or deadlock",
                "category": "database"
            },
            "authentication_failed": {
                "pattern": r"auth failed|authentication failed|login failed|invalid credentials",
                "likely_cause": "Wrong credentials, expired token, or auth service down",
                "category": "security"
            },
            "disk_full": {
                "pattern": r"disk full|no space left|insufficient space",
                "likely_cause": "Disk is full, need to free up space",
                "category": "resource"
            },
            "ssl_error": {
                "pattern": r"ssl error|certificate|tls error|handshake failed",
                "likely_cause": "SSL certificate expired or misconfigured",
                "category": "security"
            },
        }

    def analyze_errors(self, log_entries: List[Dict]) -> Dict[str, Any]:
        """
        Analyze log entries for error patterns.

        Args:
            log_entries: List of parsed log entries

        Returns:
            Analysis results with identified errors and root causes
        """
        errors_found = []
        error_counts = {}
        categories = {}

        for entry in log_entries:
            message = str(entry.get("message", entry.get("raw", "")))
            level = entry.get("level", "").upper()

            # Only analyze error-level entries
            if level in ["ERROR", "CRITICAL", "FATAL", "EMERGENCY"]:
                for error_type, error_info in self.error_patterns.items():
                    if re.search(error_info["pattern"], message, re.IGNORECASE):
                        errors_found.append({
                            "type": error_type,
                            "category": error_info["category"],
                            "likely_cause": error_info["likely_cause"],
                            "message": message[:200],
                            "timestamp": entry.get("timestamp", "unknown")
                        })

                        error_counts[error_type] = error_counts.get(error_type, 0) + 1
                        categories[error_info["category"]] = categories.get(error_info["category"], 0) + 1
                        break

        # Identify the most common error
        top_error = None
        if error_counts:
            top_error = max(error_counts, key=error_counts.get)

        # Identify the most affected category
        top_category = None
        if categories:
            top_category = max(categories, key=categories.get)

        return {
            "total_errors": len(errors_found),
            "unique_error_types": len(error_counts),
            "error_counts": error_counts,
            "categories": categories,
            "top_error": top_error,
            "top_category": top_category,
            "errors": errors_found[:10],  # Top 10 errors
            "needs_immediate_attention": top_category in ["security", "resource"]
        }

    def identify_root_cause(self, errors: List[Dict]) -> str:
        """
        Identify the most likely root cause from a list of errors.

        Args:
            errors: List of identified errors

        Returns:
            Root cause description
        """
        if not errors:
            return "No errors found to analyze."

        # Group by category
        categories = {}
        for error in errors:
            cat = error.get("category", "unknown")
            if cat not in categories:
                categories[cat] = []
            categories[cat].append(error)

        # Find the dominant category
        dominant_cat = max(categories, key=lambda k: len(categories[k]))

        # Check for cascading failures
        if len(categories) > 1:
            # Multiple categories suggest cascading failure
            return (
                f"Multiple error categories detected. "
                f"Primary issue appears to be in '{dominant_cat}' category "
                f"({len(categories[dominant_cat])} errors). "
                f"Other categories may be cascading effects."
            )

        # Single category - find the specific cause
        errors_in_cat = categories[dominant_cat]
        error_types = set(e["type"] for e in errors_in_cat)

        if len(error_types) == 1:
            error_type = list(error_types)[0]
            pattern_info = self.error_patterns.get(error_type, {})
            return pattern_info.get("likely_cause", f"Issue related to {error_type}")

        return f"Multiple {dominant_cat} issues detected. Investigate {dominant_cat} infrastructure."