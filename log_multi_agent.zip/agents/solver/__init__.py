# agents/solver/__init__.py
"""
Solver Agent - Provides solutions and explanations for log issues
"""

from .agent import SolverAgent

__all__ = ['SolverAgent']