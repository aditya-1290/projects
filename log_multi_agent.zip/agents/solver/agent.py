# agents/solver/agent.py
"""
Solver Agent - Uses Gemma-4-E4B to intelligently analyze logs, detect errors,
understand root causes, and generate solutions.

Model: Gemma-4-E4B (deep reasoning for error detection and solution generation)
"""

from typing import Dict, Any, List, Optional
import logging
from datetime import datetime
import asyncio
import json
import re
from pathlib import Path

from agents.base_agent import BaseAgent, A2AMessage, MessageType, AgentState

logger = logging.getLogger(__name__)


class SolverAgent(BaseAgent):
    """
    Solver agent that uses Gemma model to:
    1. INTELLIGENTLY DETECT errors from log content (not just pass-through)
    2. Understand root causes
    3. Generate solutions, explanations, and risk assessments
    """

    SUPPORTED_LOG_TYPES = [
        "system_log", "application_log", "security_log", "access_log",
        "error_log", "database_log", "network_log", "general_log", "unknown"
    ]

    def __init__(self, agent_id: str = "solver", capability_path: str = None, config=None, **kwargs):
        if hasattr(agent_id, 'agent_id') and hasattr(agent_id, 'capabilities'):
            config = agent_id
            agent_id = config.agent_id if hasattr(config, 'agent_id') else "solver"
            if capability_path is None:
                capability_path = getattr(config, 'capability_path', None)
        elif config is not None:
            agent_id = config.agent_id if hasattr(config, 'agent_id') else "solver"
            if capability_path is None:
                capability_path = getattr(config, 'capability_path', None)

        if capability_path is None:
            default_path = Path(__file__).parent / "capabilities.json"
            if default_path.exists():
                capability_path = str(default_path)

        super().__init__(agent_id=agent_id, capability_path=capability_path)
        self.solution_history = []

    def get_system_prompt(self) -> str:
        return """You are an expert log analyzer and problem solver.

        Your job is to:
        1. READ the log entries carefully
        2. IDENTIFY errors, warnings, and anomalies yourself (don't rely on pre-labeled data)
        3. UNDERSTAND the root cause
        4. PROVIDE actionable solutions

        Look for: error messages, stack traces, exception names, failed operations,
        timeout errors, connection issues, permission problems, missing files,
        configuration errors, and any abnormal patterns."""

    # ============================================
    # Main Process
    # ============================================

    async def process(self, message: A2AMessage) -> A2AMessage:
        """Process incoming A2A message."""

        if message.task and message.task.get("action") == "report_capabilities":
            return A2AMessage(
                message_type=MessageType.RESPONSE,
                sender_id=self.agent_id,
                sender_type=self.capability.agent_name,
                target_id=message.sender_id,
                correlation_id=message.message_id,
                response=self.capability.to_dict(),
                confidence=1.0
            )

        task = message.task or {}

        if not self.can_handle(task):
            return A2AMessage(
                message_type=MessageType.RESPONSE,
                sender_id=self.agent_id,
                sender_type=self.capability.agent_name,
                target_id=message.sender_id,
                correlation_id=message.message_id,
                response={
                    "can_handle": False,
                    "reason": self.capability.out_of_scope_message,
                },
                confidence=0.0
            )

        try:
            self.state = AgentState.PROCESSING
            task_input = {
                "input": task.get("input", task),
                "parameters": task.get("parameters", {}),
                "context": message.context or {}
            }
            result = await self.process_task(task_input)
            self.state = AgentState.IDLE

            return A2AMessage(
                message_type=MessageType.RESPONSE,
                sender_id=self.agent_id,
                sender_type=self.capability.agent_name,
                target_id=message.sender_id,
                correlation_id=message.message_id,
                response=result,
                confidence=result.get("confidence", 0.85)
            )

        except Exception as e:
            self.state = AgentState.ERROR
            logger.error(f"[SOLVER] Error: {e}", exc_info=True)
            return A2AMessage(
                message_type=MessageType.ERROR,
                sender_id=self.agent_id,
                sender_type=self.capability.agent_name,
                target_id=message.sender_id,
                correlation_id=message.message_id,
                error=str(e)
            )

    # ============================================
    # Core Logic - Uses Gemma for EVERYTHING
    # ============================================

    async def process_task(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """Use Gemma to analyze logs and generate solutions."""
        input_data = task.get("input", {})

        # ⭐ Extract raw log content for Gemma to analyze
        raw_content = self._get_raw_content(input_data)
        log_entries = self._get_entries(input_data)
        log_type = input_data.get("log_type", input_data.get("classification", "unknown"))

        if not raw_content and not log_entries:
            return {
                "success": False,
                "error": "No log content to analyze",
                "agent_id": self.agent_id
            }

        # Format log content for Gemma
        formatted_logs = self._format_logs_for_analysis(log_entries, raw_content)

        model_available = (self.model is not None and not isinstance(self.model, dict))
        logger.info(
            f"[SOLVER] Model available: {model_available} | Log type: {log_type} | Content: {len(formatted_logs)} chars")

        # ⭐ STEP 1: Let Gemma find the errors (not pass-through!)
        print(f"  [SOLVER] 1/5 Detecting errors in logs...")
        error_analysis = await self._ask_gemma(
            f"""Analyze these logs and identify ALL errors, warnings, and issues.

            {formatted_logs}

            Find:
            - Error messages and their types (NameError, ConnectionError, etc.)
            - Stack traces and what caused them
            - Warning messages
            - Failed operations
            - Any abnormal patterns

            Return JSON:
            {{
                "errors_found": [
                    {{"type": "NameError", "severity": "high", "message": "...", "line": "...", "root_cause_hint": "..."}}
                ],
                "total_errors": 0,
                "has_critical_errors": false
            }}""",
            '{"errors_found": [], "total_errors": 0, "has_critical_errors": false}'
        )

        # Parse Gemma's error detection
        detected_errors = self._parse_json_safe(error_analysis)
        errors = detected_errors.get("errors_found", [])
        total_errors = detected_errors.get("total_errors", len(errors))
        has_errors = total_errors > 0 or detected_errors.get("has_critical_errors", False)

        if has_errors:
            print(f"  [SOLVER] Found {total_errors} error(s)")
            for e in errors[:3]:
                print(
                    f"         - [{e.get('severity', '?').upper()}] {e.get('type', 'ERROR')}: {str(e.get('message', ''))[:80]}")
        else:
            print(f"  [SOLVER] No errors detected")

        # ⭐ STEP 2: Root cause analysis
        print(f"  [SOLVER] 2/5 Analyzing root cause...")
        root_cause = await self._ask_gemma(
            f"""Based on these errors, explain the root cause.

            Errors found: {json.dumps(errors[:5]) if errors else 'None detected'}
            Log summary: {formatted_logs[:1000]}

            Explain WHAT went wrong and WHY in 2-3 sentences.""",
            "The logs indicate issues that need investigation."
        )
        print(f"  [SOLVER] 2/5 -> {root_cause[:120]}...")

        # ⭐ STEP 3: Generate solutions
        print(f"  [SOLVER] 3/5 Generating solutions...")
        solution = await self._ask_gemma(
            f"""Based on this analysis, provide step-by-step solutions.

            Root cause: {root_cause}
            Errors: {json.dumps(errors[:3]) if errors else 'None'}

            Provide:
            1. Immediate fix (what to do right now)
            2. Code changes needed (if any)
            3. Configuration changes (if any)
            4. Verification steps""",
            "Step 1: Review the errors. Step 2: Fix the identified issues. Step 3: Verify the fix."
        )
        print(f"  [SOLVER] 3/5 -> {solution[:120]}...")

        # ⭐ STEP 4: Simple explanation
        print(f"  [SOLVER] 4/5 Creating explanation...")
        explanation = await self._ask_gemma(
            f"Explain this in simple terms for a non-technical person: {root_cause}",
            "The system encountered issues that need to be fixed."
        )
        print(f"  [SOLVER] 4/5 -> {explanation[:120]}...")

        # ⭐ STEP 5: Risk assessment
        print(f"  [SOLVER] 5/5 Assessing risks...")
        risks = await self._ask_gemma(
            f"What are the risks of this solution? {solution[:800]}",
            "Standard risks apply. Backup before making changes."
        )
        print(f"  [SOLVER] 5/5 -> {risks[:120]}...")

        return {
            "success": True,
            "agent_id": self.agent_id,
            "has_errors": has_errors,
            "error_count": total_errors,
            "errors": errors,
            "problem_understanding": root_cause,
            "recommended_solution": solution,
            "solution": solution,
            "user_explanation": explanation,
            "risk_assessment": risks,
            "log_type": log_type,
            "entries_analyzed": len(log_entries) if isinstance(log_entries, list) else len(
                str(raw_content).splitlines()),
            "confidence": 0.85 if model_available else 0.5,
            "model_used": model_available,
            "timestamp": datetime.now().isoformat()
        }

    # ============================================
    # Gemma Communication
    # ============================================

    async def _ask_gemma(self, prompt: str, fallback: str) -> str:
        """Ask Gemma for analysis with fallback."""
        if self.model is None or isinstance(self.model, dict):
            return fallback

        try:
            prompt_data = {
                "task": "analyze",
                "query": prompt,
                "instructions": "Respond concisely. Return JSON when requested."
            }

            response = await asyncio.wait_for(
                self.think(prompt_data),
                timeout=30  # 30 seconds for deep analysis
            )

            if response and not response.startswith("[") and len(response.strip()) > 10:
                return response.strip()

        except asyncio.TimeoutError:
            logger.warning(f"[SOLVER] Gemma timed out")
        except Exception as e:
            logger.warning(f"[SOLVER] Gemma error: {e}")

        return fallback

    # ============================================
    # Data Extraction Helpers
    # ============================================

    def _get_raw_content(self, input_data: Dict) -> str:
        """Get raw log content from any source."""
        return (
                input_data.get("cleaned_content") or
                input_data.get("raw_content") or
                input_data.get("text") or
                input_data.get("content") or
                ""
        )

    def _get_entries(self, input_data: Dict) -> List:
        """Get structured log entries."""
        entries = (
                input_data.get("normalized_data") or
                input_data.get("entries") or
                input_data.get("data") or
                []
        )
        if isinstance(entries, dict):
            entries = entries.get("entries", entries.get("data", []))
        if isinstance(entries, list):
            return entries[:100]  # Limit to 100 entries
        return []

    def _format_logs_for_analysis(self, entries: List, raw_content: str) -> str:
        """Format logs for Gemma analysis."""
        parts = []

        if entries:
            parts.append(f"=== LOG ENTRIES ({len(entries)} total) ===\n")
            for i, entry in enumerate(entries[:20]):  # First 20 entries
                if isinstance(entry, dict):
                    ts = entry.get("timestamp", "")
                    level = entry.get("level", "")
                    msg = entry.get("message", entry.get("raw", str(entry)))
                    parts.append(f"[{i + 1}] {ts} [{level}] {str(msg)[:200]}")
                elif isinstance(entry, str):
                    parts.append(f"[{i + 1}] {entry[:200]}")
        elif raw_content:
            parts.append(f"=== RAW LOG CONTENT ===\n")
            parts.append(str(raw_content)[:2000])  # First 2000 chars

        return "\n".join(parts) if parts else "No log data available."

    def _parse_json_safe(self, text: str) -> Dict:
        """Safely parse JSON from Gemma's response."""
        try:
            return json.loads(text)
        except:
            pass

        # Try to extract JSON from text
        import re
        json_patterns = [
            r'```json\s*(\{.*?\})\s*```',
            r'```\s*(\{.*?\})\s*```',
            r'(\{[^{}]*"errors_found"[^{}]*\})',
            r'(\{.*\})',
        ]

        for pattern in json_patterns:
            match = re.search(pattern, text, re.DOTALL)
            if match:
                try:
                    return json.loads(match.group(1))
                except:
                    continue

        # Fallback: try to extract error count from text
        errors_found = []
        if "error" in text.lower() or "exception" in text.lower():
            errors_found = [{"type": "ERROR", "severity": "medium", "message": "Errors detected in logs"}]

        return {
            "errors_found": errors_found,
            "total_errors": len(errors_found),
            "has_critical_errors": False
        }