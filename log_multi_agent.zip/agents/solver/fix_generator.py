# agents/solver/fix_generator.py
"""
Fix Generator - Generates specific fixes for identified issues
"""

from typing import Dict, Any, List, Optional


class FixGenerator:
    """
    Generates actionable fixes for identified problems.
    Provides step-by-step instructions and code patches.
    """

    def __init__(self):
        self.fix_templates = {
            "connection_refused": {
                "steps": [
                    "Check if the service is running: `systemctl status <service>`",
                    "Verify the port is open: `netstat -tuln | grep <port>`",
                    "Check firewall rules: `iptables -L -n`",
                    "Restart the service: `systemctl restart <service>`"
                ],
                "verification": "Try connecting to the service again and check logs for successful connection"
            },
            "timeout": {
                "steps": [
                    "Check system resources: `top`, `free -h`, `df -h`",
                    "Review database query performance",
                    "Increase timeout settings in configuration",
                    "Check for network latency: `ping <host>`"
                ],
                "verification": "Monitor response times after changes"
            },
            "out_of_memory": {
                "steps": [
                    "Identify memory-intensive processes: `ps aux --sort=-%mem | head`",
                    "Check for memory leaks in application code",
                    "Increase swap space if needed",
                    "Optimize memory usage or add more RAM"
                ],
                "verification": "Monitor memory usage with `free -h` over time"
            },
            "permission_denied": {
                "steps": [
                    "Check file/directory permissions: `ls -la <path>`",
                    "Verify user has correct permissions",
                    "Check if service is running as correct user",
                    "Review security policies and ACLs"
                ],
                "verification": "Retry the operation after fixing permissions"
            },
            "file_not_found": {
                "steps": [
                    "Verify the file path is correct",
                    "Check if file was moved or deleted",
                    "Restore from backup if available",
                    "Update configuration with correct path"
                ],
                "verification": "Confirm file exists at expected location"
            },
            "null_pointer": {
                "steps": [
                    "Find the exact line in the code where the error occurs",
                    "Add null check before accessing the object",
                    "Ensure proper initialization of variables",
                    "Add unit tests for null/edge cases"
                ],
                "code_example": (
                    "# Before:\n"
                    "result = obj.method()\n\n"
                    "# After:\n"
                    "if obj is not None:\n"
                    "    result = obj.method()\n"
                    "else:\n"
                    "    raise ValueError('Object is None')"
                ),
                "verification": "Run the code with null inputs to verify fix"
            },
            "database_error": {
                "steps": [
                    "Check database connectivity: verify host, port, credentials",
                    "Check database logs for specific errors",
                    "Verify query syntax and performance",
                    "Check connection pool settings"
                ],
                "verification": "Run a simple query to confirm database access"
            },
            "authentication_failed": {
                "steps": [
                    "Verify credentials are correct",
                    "Check if tokens/keys have expired",
                    "Review authentication service logs",
                    "Reset credentials if necessary"
                ],
                "verification": "Attempt login with verified credentials"
            },
            "disk_full": {
                "steps": [
                    "Identify large files: `du -sh /* | sort -rh | head -10`",
                    "Clean up old logs and temporary files",
                    "Archive and compress old data",
                    "Add more disk space if needed"
                ],
                "verification": "Check disk space: `df -h`"
            },
            "ssl_error": {
                "steps": [
                    "Check certificate expiration date",
                    "Verify certificate chain is valid",
                    "Renew certificate if expired",
                    "Update CA certificates if needed"
                ],
                "verification": "Access the service via HTTPS and check certificate"
            },
        }

    def generate_fix(self, error_type: str, context: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Generate a fix for a specific error type.

        Args:
            error_type: The type of error to fix
            context: Additional context about the error

        Returns:
            Fix instructions with steps and verification
        """
        template = self.fix_templates.get(error_type)

        if not template:
            # Generic fix for unknown error types
            return {
                "error_type": error_type,
                "summary": f"Investigate and resolve the '{error_type}' issue",
                "steps": [
                    "Review the error message and logs for details",
                    "Check system and application status",
                    "Research the specific error message",
                    "Apply the appropriate fix based on findings",
                    "Test and verify the fix"
                ],
                "code_patch": None,
                "warnings": ["Generic fix - may need adjustment for your specific case"],
                "verification": "Confirm the error no longer occurs"
            }

        return {
            "error_type": error_type,
            "summary": f"Fix for {error_type}",
            "steps": template.get("steps", []),
            "code_patch": template.get("code_example"),
            "warnings": template.get("warnings", []),
            "verification": template.get("verification", "Test the fix and monitor logs")
        }

    def generate_fixes_for_all(self, errors: List[Dict]) -> List[Dict]:
        """
        Generate fixes for multiple errors.

        Args:
            errors: List of error dictionaries

        Returns:
            List of fix instructions
        """
        fixes = []
        seen_types = set()

        for error in errors:
            error_type = error.get("type", "unknown")
            if error_type not in seen_types:
                seen_types.add(error_type)
                fix = self.generate_fix(error_type, error)
                fix["affected_entries"] = sum(1 for e in errors if e.get("type") == error_type)
                fixes.append(fix)

        # Sort by number of affected entries (most impactful first)
        fixes.sort(key=lambda x: x.get("affected_entries", 0), reverse=True)

        return fixes