"""
Base Agent Class for Log Analysis Multi-Agent System

All agents inherit from this class. It provides:
- Capability contract management
- A2A message handling
- Model access with proper llama-cpp support
- Self-awareness (can_handle checks)
"""

import json
import uuid
import asyncio
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from enum import Enum
from abc import ABC, abstractmethod
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


# ============================================
# Enums
# ============================================

class MessageType(Enum):
    REQUEST = "request"
    RESPONSE = "response"
    BROADCAST = "broadcast"
    DISCOVERY = "discovery"
    CAPABILITY_QUERY = "capability_query"
    CAPABILITY_RESPONSE = "capability_response"
    ERROR = "error"
    HANDOFF = "handoff"
    HUMAN_INPUT_REQUEST = "human_input_request"
    HUMAN_INPUT_RESPONSE = "human_input_response"


class MessagePriority(Enum):
    LOW = 1
    NORMAL = 2
    HIGH = 3
    CRITICAL = 4


class AgentState(Enum):
    IDLE = "idle"
    PROCESSING = "processing"
    WAITING_FOR_HUMAN = "waiting_for_human"
    WAITING_FOR_AGENT = "waiting_for_agent"
    ERROR = "error"
    SHUTDOWN = "shutdown"


# ============================================
# Data Classes
# ============================================

@dataclass
class CapabilityContract:
    """Machine-readable capability declaration for each agent"""
    agent_name: str
    agent_id: str
    domain: str
    capabilities: List[str]
    limitations: List[str]
    preconditions: List[str]
    required_tools: List[str] = field(default_factory=list)
    fallback_agents: List[str] = field(default_factory=list)
    confidence_threshold: float = 0.5
    max_iterations: int = 3
    out_of_scope_message: str = "This task is outside my capabilities."

    @classmethod
    def from_json(cls, path: str) -> "CapabilityContract":
        """Load capability contract from JSON file"""
        with open(path, 'r') as f:
            data = json.load(f)
        return cls(**data)

    def to_dict(self) -> Dict:
        """Convert to dictionary for serialization"""
        return {
            "agent_name": self.agent_name,
            "agent_id": self.agent_id,
            "domain": self.domain,
            "capabilities": self.capabilities,
            "limitations": self.limitations,
            "preconditions": self.preconditions,
            "required_tools": self.required_tools,
            "fallback_agents": self.fallback_agents,
            "confidence_threshold": self.confidence_threshold,
            "max_iterations": self.max_iterations,
            "out_of_scope_message": self.out_of_scope_message
        }


@dataclass
class A2AMessage:
    """Standard Agent-to-Agent message envelope"""
    message_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    message_type: MessageType = MessageType.REQUEST
    sender_id: str = ""
    sender_type: str = ""
    target_id: Optional[str] = None
    target_type: Optional[str] = None
    correlation_id: Optional[str] = None
    priority: MessagePriority = MessagePriority.NORMAL

    # Payload
    task: Optional[Dict[str, Any]] = None
    response: Optional[Dict[str, Any]] = None
    context: Dict[str, Any] = field(default_factory=dict)

    # Meta
    confidence: float = 1.0
    caveats: List[str] = field(default_factory=list)
    requires_human: bool = False
    human_question: Optional[str] = None
    error: Optional[str] = None

    # Routing
    ttl: int = 10
    route_history: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict:
        """Convert to dictionary for serialization"""
        return {
            "message_id": self.message_id,
            "message_type": self.message_type.value,
            "sender_id": self.sender_id,
            "sender_type": self.sender_type,
            "target_id": self.target_id,
            "target_type": self.target_type,
            "correlation_id": self.correlation_id,
            "priority": self.priority.value,
            "task": self.task,
            "response": self.response,
            "context": self.context,
            "confidence": self.confidence,
            "caveats": self.caveats,
            "requires_human": self.requires_human,
            "human_question": self.human_question,
            "error": self.error,
            "ttl": self.ttl,
            "route_history": self.route_history
        }

    @classmethod
    def from_dict(cls, data: Dict) -> "A2AMessage":
        """Create from dictionary"""
        msg = cls()
        msg.message_id = data.get("message_id", msg.message_id)
        msg.message_type = MessageType(data.get("message_type", "request"))
        msg.sender_id = data.get("sender_id", "")
        msg.sender_type = data.get("sender_type", "")
        msg.target_id = data.get("target_id")
        msg.target_type = data.get("target_type")
        msg.correlation_id = data.get("correlation_id")
        msg.priority = MessagePriority(data.get("priority", 2))
        msg.task = data.get("task")
        msg.response = data.get("response")
        msg.context = data.get("context", {})
        msg.confidence = data.get("confidence", 1.0)
        msg.caveats = data.get("caveats", [])
        msg.requires_human = data.get("requires_human", False)
        msg.human_question = data.get("human_question")
        msg.error = data.get("error")
        msg.ttl = data.get("ttl", 10)
        msg.route_history = data.get("route_history", [])
        return msg


@dataclass
class AgentResponse:
    """Structured response from agent processing"""
    success: bool
    data: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None
    confidence: float = 1.0
    caveats: List[str] = field(default_factory=list)
    requires_human: bool = False
    human_question: Optional[str] = None
    next_agent_suggestion: Optional[str] = None
    state_changes: Dict[str, Any] = field(default_factory=dict)


# ============================================
# Base Agent Class
# ============================================

class BaseAgent(ABC):
    """
    Base class for all agents in the Log Analysis Multi-Agent System.

    Every agent:
    - Has a capability contract defining what it can/cannot do
    - Communicates via A2A messages through the communication bus
    - Can access models through the model manager
    - Self-evaluates whether it can handle incoming tasks
    """

    def __init__(self, agent_id: str, capability_path: str):
        """
        Initialize the agent.

        Args:
            agent_id: Unique identifier for this agent instance
            capability_path: Path to the capabilities.json file
        """
        self.agent_id = agent_id
        self.capability = CapabilityContract.from_json(capability_path)
        self.state = AgentState.IDLE
        self.comm_bus = None
        self.model_manager = None
        self.model = None  # Will be set by main.py during initialization
        self.processing_history: List[Dict] = []
        self.current_task: Optional[Dict] = None

    # ============================================
    # Abstract Methods (MUST be implemented)
    # ============================================

    @abstractmethod
    async def process(self, message: A2AMessage) -> A2AMessage:
        """
        Process an incoming A2A message.
        MUST be implemented by every agent subclass.
        """
        pass

    @abstractmethod
    def get_system_prompt(self) -> str:
        """
        Return the system prompt for this agent.
        MUST be implemented by every agent subclass.
        """
        pass

    # ============================================
    # Lifecycle
    # ============================================

    async def start(self):
        """Start the agent"""
        self.state = AgentState.IDLE
        logger.info(f"Agent [{self.agent_id}] started")

    async def shutdown(self):
        """Shutdown the agent"""
        self.state = AgentState.SHUTDOWN
        logger.info(f"Agent [{self.agent_id}] shutdown")

    # ============================================
    # Message Handling
    # ============================================

    async def receive_message(self, message: A2AMessage) -> Optional[A2AMessage]:
        """
        Called by the communication bus when a message arrives.
        Performs pre-processing checks before calling process().
        """
        # Check TTL
        if message.ttl <= 0:
            return self._create_error_response(message, "Message TTL expired")

        # Decrement TTL
        message.ttl -= 1
        message.route_history.append(self.agent_id)

        # Check if we can handle this
        if message.task and not self.can_handle(message.task):
            return self._create_cannot_handle_response(message)

        # Update state
        self.state = AgentState.PROCESSING
        self.current_task = message.task

        try:
            response = await self.process(message)
            self.processing_history.append({
                "task": message.task,
                "response": response.to_dict() if response else None,
                "timestamp": datetime.now().isoformat()
            })
            return response

        except Exception as e:
            logger.error(f"Agent [{self.agent_id}] error: {e}", exc_info=True)
            self.state = AgentState.ERROR
            return self._create_error_response(message, str(e))

        finally:
            if self.state != AgentState.ERROR:
                self.state = AgentState.IDLE
            self.current_task = None

    async def send_message(self, message: A2AMessage):
        """Send a message via the communication bus"""
        if self.comm_bus:
            message.sender_id = self.agent_id
            message.sender_type = self.capability.agent_name
            await self.comm_bus.send_message(message)
        else:
            raise RuntimeError(f"Agent {self.agent_id} not connected to communication bus")

    # ============================================
    # Self-Awareness Methods
    # ============================================

    def can_handle(self, task: Dict) -> bool:
        """
        Self-awareness check: Can this agent handle the given task?

        FIXED: Pipeline tasks with "action": "process" always pass.
        Preconditions are only checked for explicit domain/capability tasks.
        """
        if not task:
            return True

        # Pipeline tasks always pass - let the agent try
        action = task.get("action", "")
        if action in ["process", "route_request", "execute_pipeline"]:
            return True

        # Check domain if specified
        task_domain = task.get("domain")
        if task_domain and task_domain != self.capability.domain:
            return False

        # Check required capability (single)
        required_capability = task.get("required_capability")
        if required_capability:
            if required_capability not in self.capability.capabilities:
                return False

        # Check required capabilities (list)
        required_capabilities = task.get("required_capabilities", [])
        for cap in required_capabilities:
            if cap not in self.capability.capabilities:
                return False

        # Only check preconditions for explicit domain/capability tasks
        if task_domain or required_capability or required_capabilities:
            context = task.get("context")
            if context:
                for precondition in self.capability.preconditions:
                    if not self._evaluate_precondition(precondition, context):
                        return False
            return True

        # Has input data? Let the agent try
        has_input = bool(
            task.get("input") or
            task.get("text") or
            task.get("raw_content") or
            task.get("content") or
            task.get("query")
        )
        if has_input:
            return True

        # Default: let the agent try
        return True

    def _evaluate_precondition(self, condition: str, context: Dict) -> bool:
        """Evaluate a precondition against context"""
        if condition.startswith("state."):
            key = condition.replace("state.", "")
            return bool(context.get(key))
        if condition.startswith("context."):
            key = condition.replace("context.", "")
            return bool(context.get(key))
        return bool(context.get(condition))

    def what_can_you_do(self) -> str:
        """Return human-readable capability description"""
        can = ", ".join(self.capability.capabilities)
        cannot = ", ".join(self.capability.limitations)
        return f"""
Agent: {self.capability.agent_name} ({self.agent_id})
Domain: {self.capability.domain}

I CAN: {can}
I CANNOT: {cannot}
"""

    # ============================================
    # Model Access & Thinking
    # ============================================

    async def think(self, prompt_data: Dict) -> str:
        """
        Send data to the model for reasoning.

        FIXED: Properly handles llama-cpp-python models.
        Falls back gracefully when model is not available.
        """
        model = getattr(self, 'model', None)

        # LAZY LOAD: If no model, try to load it now
        if model is None:
            if self.model_manager:
                model_key = self._get_model_key()
                if model_key:
                    try:
                        logger.info(f"[{self.agent_id}] Lazy-loading {model_key}...")
                        model = await self.model_manager.load_model(model_key)
                        if model is not None and not isinstance(model, dict):
                            self.model = model
                            logger.info(f"[{self.agent_id}] Model {model_key} loaded on demand")
                        else:
                            logger.warning(f"[{self.agent_id}] Could not load {model_key}")
                            return f"[{self.agent_id}] Model {model_key} not available."
                    except Exception as e:
                        logger.error(f"[{self.agent_id}] Failed to load {model_key}: {e}")
                        return f"[{self.agent_id}] Model loading failed: {str(e)}"
                else:
                    return f"[{self.agent_id}] No model configured for this agent."
            else:
                return f"[{self.agent_id}] No model manager available."

        # Re-check after lazy load
        model = getattr(self, 'model', None)
        if model is None:
            return f"[{self.agent_id}] Model not available."

        # Skip placeholder dicts
        if isinstance(model, dict):
            return f"[{self.agent_id}] Model is placeholder (not loaded)."

        # Build prompt
        system_prompt = self.get_system_prompt()
        user_content = json.dumps(prompt_data, indent=2)

        try:
            # Handle llama-cpp-python model with create_chat_completion
            if hasattr(model, 'create_chat_completion'):
                logger.info(f"[{self.agent_id}] Using llama-cpp chat completion")

                loop = asyncio.get_event_loop()
                response = await asyncio.wait_for(
                    loop.run_in_executor(
                        None,
                        lambda: model.create_chat_completion(
                            messages=[
                                {"role": "system", "content": system_prompt},
                                {"role": "user", "content": user_content}
                            ],
                            max_tokens=512,
                            temperature=0.3,
                            stop=["<|im_end|>", "<end_of_turn>", "\n\n\n"],
                        )
                    ),
                    timeout=600
                )

                if isinstance(response, dict):
                    choices = response.get('choices', [])
                    if choices:
                        message = choices[0].get('message', {})
                        content = message.get('content', '')
                        if content.strip():
                            logger.info(f"[{self.agent_id}] Model response: {content[:100]}...")
                            return content

                # Try text field
                if isinstance(response, dict):
                    text = response.get('choices', [{}])[0].get('text', '')
                    if text.strip():
                        return text

                return str(response)

            # Handle callable model (direct __call__)
            elif callable(model):
                logger.info(f"[{self.agent_id}] Using direct model call")

                full_prompt = f"{system_prompt}\n\nTask:\n{user_content}\n\nResponse:"

                loop = asyncio.get_event_loop()
                result = await asyncio.wait_for(
                    loop.run_in_executor(
                        None,
                        lambda: model(
                            full_prompt,
                            max_tokens=512,
                            temperature=0.3,
                            stop=["<|im_end|>", "<end_of_turn>"],
                        )
                    ),
                    timeout=600
                )

                if isinstance(result, dict):
                    text = result.get('choices', [{}])[0].get('text', str(result))
                else:
                    text = str(result)

                if text.strip():
                    logger.info(f"[{self.agent_id}] Model response: {text[:100]}...")
                    return text

                return str(result)

            else:
                logger.error(f"[{self.agent_id}] Unknown model type: {type(model).__name__}")
                logger.error(f"[{self.agent_id}] Model dir: {[a for a in dir(model) if not a.startswith('_')][:15]}")
                return f"[{self.agent_id}] Unknown model type: {type(model).__name__}"

        except asyncio.TimeoutError:
            logger.error(f"[{self.agent_id}] Model inference timed out (120s)")
            return f"[{self.agent_id}] Model inference timed out."
        except Exception as e:
            logger.error(f"[{self.agent_id}] Model error: {e}", exc_info=True)
            return f"[{self.agent_id}] Inference error: {str(e)}"

    def _get_model_key(self) -> Optional[str]:
        """Determine which model this agent should use based on its agent_id"""
        agent_model_map = {
            "extractor": "qwen",
            "preprocessor": "qwen",
            "memory": "qwen",
            "analyzer": "gemma",
            "solver": "gemma",
            "debugger": "gemma",
            "critic": "gemma",
            "orchestrator": None,
        }
        return agent_model_map.get(self.agent_id, "qwen")

    async def get_model(self, model_name: str):
        """Get a model instance from model manager"""
        if self.model_manager:
            return await self.model_manager.load_model(model_name)
        raise RuntimeError(f"Agent {self.agent_id} has no model manager")

    async def release_model(self, model_name: str):
        """Release a model back to the pool"""
        if self.model_manager:
            await self.model_manager.release_model(model_name)

    # ============================================
    # Confidence Scoring
    # ============================================

    def calculate_confidence(self, result: Dict, task: Dict) -> float:
        """
        Calculate confidence score for a result.
        """
        if not result:
            return 0.0

        confidence = 0.5

        if isinstance(result, dict):
            if result.get("success", False):
                confidence += 0.2
            if result.get("error"):
                confidence -= 0.3
            if result.get("raw_content") or result.get("data") or result.get("result"):
                confidence += 0.15
            if result.get("metadata") or result.get("line_count") or result.get("entry_count"):
                confidence += 0.1
            if "confidence" in result:
                return float(result["confidence"])

        return round(max(0.0, min(1.0, confidence)), 2)

    # ============================================
    # Helper Methods
    # ============================================

    def _create_error_response(self, original_message: A2AMessage, error: str) -> A2AMessage:
        """Create an error response message"""
        return A2AMessage(
            message_type=MessageType.ERROR,
            sender_id=self.agent_id,
            sender_type=self.capability.agent_name,
            target_id=original_message.sender_id,
            correlation_id=original_message.message_id,
            error=error,
            context={"original_task": original_message.task}
        )

    def _create_cannot_handle_response(self, message: A2AMessage) -> A2AMessage:
        """Create response for tasks this agent cannot handle"""
        return A2AMessage(
            message_type=MessageType.RESPONSE,
            sender_id=self.agent_id,
            sender_type=self.capability.agent_name,
            target_id=message.sender_id,
            correlation_id=message.message_id,
            response={
                "can_handle": False,
                "reason": self.capability.out_of_scope_message,
                "suggested_agents": self.capability.fallback_agents,
                "my_capabilities": self.capability.capabilities
            },
            confidence=0.0
        )

    def _create_human_request(self, question: str) -> A2AMessage:
        """Create a message requesting human input"""
        self.state = AgentState.WAITING_FOR_HUMAN
        return A2AMessage(
            message_type=MessageType.HUMAN_INPUT_REQUEST,
            sender_id=self.agent_id,
            sender_type=self.capability.agent_name,
            requires_human=True,
            human_question=question
        )

    # ============================================
    # Run Pipeline
    # ============================================

    async def run_pipeline(self, input_data: Dict, pipeline: List[str]) -> Dict[str, Any]:
        """Execute a pipeline of agents sequentially."""
        results = {}
        context = input_data.copy()

        for agent_id in pipeline:
            if not hasattr(self, 'comm_bus') or not self.comm_bus:
                results[agent_id] = {"success": False, "error": "No communication bus"}
                continue

            task = {
                "action": "process",
                "input": context,
                "context": {"pipeline_step": agent_id, "previous_results": results}
            }

            from agentos.communication_bus import Message, MessageType
            msg = Message(
                sender=self.agent_id,
                receiver=agent_id,
                message_type=MessageType.TASK_REQUEST,
                content=task
            )

            try:
                response = await self.comm_bus.request_response(msg, timeout=600)
                if response and response.content:
                    results[agent_id] = response.content
                    logger.info(f"  [PIPELINE] {agent_id} OK: {str(response.content)[:200]}")
                else:
                    logger.error(f"  [PIPELINE] {agent_id} NO RESPONSE")
                    results[agent_id] = {"success": False, "error": f"No response from {agent_id}"}
            except Exception as e:
                logger.error(f"  [PIPELINE] {agent_id} EXCEPTION: {e}", exc_info=True)
                results[agent_id] = {"success": False, "error": str(e)}

        return results