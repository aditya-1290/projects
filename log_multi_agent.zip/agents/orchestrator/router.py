# agents/orchestrator/router.py
"""
Task Router - Routes tasks to appropriate agents based on capabilities
"""

from typing import Dict, Any, List, Optional


class TaskRouter:
    """
    Routes tasks to the correct agents based on their capabilities.
    Works with the orchestrator to determine which agent handles what.
    """

    def __init__(self):
        self.agent_capabilities = {}
        self.routing_history = []

    def register_agent(self, agent_id: str, capabilities: List[str]):
        """Register an agent's capabilities for routing."""
        self.agent_capabilities[agent_id] = capabilities

    def unregister_agent(self, agent_id: str):
        """Remove an agent from routing."""
        if agent_id in self.agent_capabilities:
            del self.agent_capabilities[agent_id]

    def find_agent_for_task(self, task_type: str) -> Optional[str]:
        """
        Find the best agent for a specific task type.

        Args:
            task_type: The type of task to perform (extract, analyze, solve, etc.)

        Returns:
            Agent ID that can handle this task, or None
        """
        for agent_id, capabilities in self.agent_capabilities.items():
            if task_type in capabilities:
                return agent_id

            # Check partial matches
            for cap in capabilities:
                if task_type in cap or cap in task_type:
                    return agent_id

        return None

    def find_fallback_agent(self, failed_agent: str, task_type: str) -> Optional[str]:
        """
        Find an alternative agent if the primary one fails.

        Args:
            failed_agent: The agent that failed
            task_type: The task that needs to be done

        Returns:
            Alternative agent ID or None
        """
        for agent_id, capabilities in self.agent_capabilities.items():
            if agent_id != failed_agent:
                if task_type in capabilities:
                    return agent_id

                for cap in capabilities:
                    if task_type in cap or cap in task_type:
                        return agent_id

        return None

    def route_by_pipeline(self, pipeline: List[str], task: Dict[str, Any]) -> Dict[str, Dict]:
        """
        Create subtasks for each agent in the pipeline.

        Args:
            pipeline: List of agent IDs in order
            task: The original task data

        Returns:
            Dict mapping agent_id to their specific subtask
        """
        routed_tasks = {}
        previous_results = {}

        for i, agent_id in enumerate(pipeline):
            subtask = {
                "action": "process",
                "step_number": i + 1,
                "total_steps": len(pipeline),
                "input": task.get("input", {}),
                "context": {
                    "pipeline_step": agent_id,
                    "previous_results": previous_results.copy(),
                    "original_query": task.get("query", "")
                }
            }

            routed_tasks[agent_id] = subtask
            self.routing_history.append({
                "agent_id": agent_id,
                "task_type": subtask["action"],
                "step": i + 1
            })

        return routed_tasks

    def get_available_agents(self) -> List[str]:
        """Get list of all registered agent IDs."""
        return list(self.agent_capabilities.keys())

    def get_agent_capabilities(self, agent_id: str) -> List[str]:
        """Get capabilities for a specific agent."""
        return self.agent_capabilities.get(agent_id, [])

    def get_routing_history(self, limit: int = 20) -> List[Dict]:
        """Get recent routing history."""
        return self.routing_history[-limit:]