# agents/orchestrator/tools.py (MINIMAL)
"""
Orchestrator Tools - Minimal utilities
"""

from typing import Dict, Any, List


class OrchestratorTools:
    """Minimal tools - model handles all orchestration logic"""

    @staticmethod
    def get_agent_capabilities() -> Dict[str, List[str]]:
        """Get capabilities of all available agents"""
        return {
            "extractor": ["extract_from_file", "extract_from_image", "extract_from_terminal"],
            "preprocessor": ["clean", "parse", "normalize", "structure"],
            "analyzer": ["classify", "detect_patterns", "find_anomalies", "assess_severity"],
            "solver": ["solve_issues", "explain_errors", "provide_fixes"],
            "critic": ["evaluate", "validate", "safety_check"],
            "memory": ["store", "retrieve", "learn"]
        }