# agents/orchestrator/agent.py
"""
Orchestrator Agent - The ONLY coordinator in the system.
No model - purely routing and result synthesis.
After pipeline completes, presents final suggestions and asks for user feedback.
"""

import re
from typing import Dict, Any, List, Optional
from datetime import datetime
import logging
from agents.base_agent import BaseAgent, A2AMessage, MessageType, MessagePriority, AgentState

logger = logging.getLogger(__name__)


class OrchestratorAgent(BaseAgent):
    """
    Master orchestrator that coordinates all agents dynamically.
    No model - routing only.

    After pipeline completion:
    1. Synthesizes results into actionable suggestions
    2. Presents error resolution steps
    3. Asks user for feedback on usefulness
    """

    def __init__(self, agent_id: str = "orchestrator", capability_path: str = None, config=None, **kwargs):
        """Initialize orchestrator."""
        if hasattr(agent_id, 'agent_id') and hasattr(agent_id, 'capabilities'):
            config = agent_id
            agent_id = config.agent_id if hasattr(config, 'agent_id') else "orchestrator"
            if capability_path is None:
                capability_path = getattr(config, 'capability_path', None)
        elif config is not None:
            agent_id = config.agent_id if hasattr(config, 'agent_id') else "orchestrator"
            if capability_path is None:
                capability_path = getattr(config, 'capability_path', None)

        if capability_path is None:
            from pathlib import Path
            default_path = Path(__file__).parent / "capabilities.json"
            if default_path.exists():
                capability_path = str(default_path)

        super().__init__(agent_id=agent_id, capability_path=capability_path)
        self._known_agents: Dict[str, Dict] = {}
        self._workflow_history: List[Dict] = []
        self._feedback_history: List[Dict] = []

    def get_system_prompt(self) -> str:
        return """You are the Orchestrator Agent - master coordinator of the log analysis system."""

    # ============================================
    # Main Process Method
    # ============================================

    async def process(self, message: A2AMessage) -> A2AMessage:
        """Route requests to the appropriate pipeline."""
        task = message.task or {}

        if task.get("action") == "report_capabilities":
            return A2AMessage(
                message_type=MessageType.RESPONSE,
                sender_id=self.agent_id,
                sender_type=self.capability.agent_name,
                target_id=message.sender_id,
                correlation_id=message.message_id,
                response=self.capability.to_dict(),
                confidence=1.0
            )

        if task.get("action") == "route_request":
            input_data = task.get("input", {}).get("input", {})
            source_type = input_data.get("source_type", "unknown")

            if source_type in ["file", "image", "terminal"]:
                pipeline = ["extractor", "preprocessor", "analyzer", "solver", "critic"]
            elif source_type == "code":
                pipeline = ["extractor", "debugger", "solver", "critic"]
            else:
                pipeline = ["extractor", "preprocessor", "analyzer", "solver", "critic"]

            return A2AMessage(
                message_type=MessageType.RESPONSE,
                sender_id=self.agent_id,
                sender_type=self.capability.agent_name,
                target_id=message.sender_id,
                correlation_id=message.message_id,
                response={"pipeline": pipeline}
            )

        # Default pipeline
        return A2AMessage(
            message_type=MessageType.RESPONSE,
            sender_id=self.agent_id,
            sender_type=self.capability.agent_name,
            target_id=message.sender_id,
            correlation_id=message.message_id,
            response={"pipeline": ["extractor", "preprocessor", "analyzer", "solver", "critic"]}
        )

    # ============================================
    # Result Synthesis (Called by main.py after pipeline)
    # ============================================

    def synthesize_results(self, pipeline_results: Dict[str, Any], original_input: str = "") -> Dict[str, Any]:
        """
        Synthesize all agent outputs into a comprehensive final response.
        Generates actionable suggestions for the user.
        """

        # Extract key findings from each agent
        extractor_result = pipeline_results.get("extractor", {})
        preprocessor_result = pipeline_results.get("preprocessor", {})
        analyzer_result = pipeline_results.get("analyzer", {})
        solver_result = pipeline_results.get("solver", {})
        debugger_result = pipeline_results.get("debugger", {})
        critic_result = pipeline_results.get("critic", {})

        # Build the synthesis
        synthesis = {
            "summary": "",
            "error_detected": False,
            "error_details": [],
            "suggestions": [],
            "steps_to_resolve": [],
            "quality_assessment": {},
            "needs_further_action": False,
            "timestamp": datetime.now().isoformat()
        }

        # ⭐ 1. Check if errors were found
        if solver_result.get("has_errors", False):
            synthesis["error_detected"] = True
            synthesis["error_details"] = solver_result.get("errors", [])

        # ⭐ 2. Get solution suggestions from solver
        solution = solver_result.get("recommended_solution", "")
        if solution:
            synthesis["suggestions"].append({
                "source": "solver",
                "title": "Recommended Solution",
                "content": solution
            })

        # ⭐ 3. Get user explanation
        explanation = solver_result.get("user_explanation", "")
        if explanation:
            synthesis["suggestions"].append({
                "source": "solver",
                "title": "Simple Explanation",
                "content": explanation
            })

        # ⭐ 4. Get risk assessment
        risk = solver_result.get("risk_assessment", "")
        if risk:
            synthesis["suggestions"].append({
                "source": "solver",
                "title": "Risk Assessment",
                "content": risk
            })

        # ⭐ 5. Extract actionable steps
        steps = self._extract_steps(solution)
        if steps:
            synthesis["steps_to_resolve"] = steps
        else:
            # Generate basic steps from available data
            synthesis["steps_to_resolve"] = self._generate_steps(pipeline_results)

        # ⭐ 6. Quality assessment from critic
        if critic_result:
            synthesis["quality_assessment"] = {
                "score": critic_result.get("quality_score", "N/A"),
                "grade": critic_result.get("grade", "N/A"),
                "verdict": critic_result.get("verdict", "N/A"),
                "safety_level": critic_result.get("safety_level", "N/A"),
                "safe_to_execute": critic_result.get("safe_to_execute", True),
                "strengths": critic_result.get("strengths", []),
                "weaknesses": critic_result.get("weaknesses", []),
            }

        # ⭐ 7. Determine if further action needed
        synthesis["needs_further_action"] = (
                synthesis["error_detected"] or
                critic_result.get("needs_revision", False) or
                not critic_result.get("safe_to_execute", True)
        )

        # ⭐ 8. Generate overall summary
        synthesis["summary"] = self._generate_summary(synthesis, pipeline_results)

        # ⭐ 9. Log type info
        synthesis["log_type"] = preprocessor_result.get("log_type", "unknown")
        synthesis["entries_analyzed"] = preprocessor_result.get("total_entries_processed", 0)
        synthesis["format_detected"] = extractor_result.get("format", "unknown")

        return synthesis

    def _extract_steps(self, solution_text: str) -> List[str]:
        """Extract numbered steps from solution text."""
        steps = []

        if not solution_text:
            return steps

        # Look for numbered steps: "Step 1:", "1.", "1)", etc.
        lines = solution_text.split('\n')
        for line in lines:
            line = line.strip()
            # Match various step formats
            if re.match(r'^(?:Step\s*\d+[:\s]|\d+[\.\)]\s|\-\s|\•\s)', line, re.IGNORECASE):
                steps.append(line)

        # If no numbered steps found, try bullet points
        if not steps:
            for line in lines:
                if line.strip().startswith(('-', '•', '*')):
                    steps.append(line.strip())

        # If still no steps, split by newlines
        if not steps:
            steps = [l.strip() for l in lines if l.strip() and len(l.strip()) > 10][:10]

        return steps[:10]  # Max 10 steps

    def _generate_steps(self, pipeline_results: Dict[str, Any]) -> List[str]:
        """Generate basic resolution steps from pipeline results."""
        steps = []

        solver = pipeline_results.get("solver", {})
        preprocessor = pipeline_results.get("preprocessor", {})

        # Step 1: Review the logs
        steps.append("Step 1: Review the extracted log entries to understand the sequence of events")

        # Step 2: Identify errors
        if solver.get("has_errors", False):
            error_count = solver.get("error_count", 0)
            steps.append(f"Step 2: Address the {error_count} error(s) identified in the logs")
        else:
            steps.append("Step 2: Monitor system health based on log patterns")

        # Step 3: Apply fixes
        solution = solver.get("recommended_solution", "")
        if solution:
            steps.append("Step 3: Apply the recommended solution from the analysis")
        else:
            steps.append("Step 3: Check system resources and configurations")

        # Step 4: Verify
        steps.append("Step 4: Verify that the changes resolved the issues")

        # Step 5: Monitor
        steps.append("Step 5: Continue monitoring logs for any recurrence")

        return steps

    def _generate_summary(self, synthesis: Dict, pipeline_results: Dict) -> str:
        """Generate overall summary of findings."""
        parts = []

        solver = pipeline_results.get("solver", {})
        critic = pipeline_results.get("critic", {})
        preprocessor = pipeline_results.get("preprocessor", {})

        # What was analyzed
        log_type = preprocessor.get("log_type", "unknown")
        entries = preprocessor.get("total_entries_processed", 0)
        parts.append(f"Analyzed {entries} log entries of type '{log_type}'.")

        # What was found
        if synthesis["error_detected"]:
            error_count = solver.get("error_count", 0)
            parts.append(f"Detected {error_count} error(s) requiring attention.")
        else:
            parts.append("No critical errors detected in the logs.")

        # Quality
        if critic:
            score = critic.get("quality_score", "N/A")
            verdict = critic.get("verdict", "N/A")
            parts.append(f"Analysis quality: {score}/100 ({verdict}).")

        # Safety
        safe = critic.get("safe_to_execute", True)
        if not safe:
            parts.append("⚠️ WARNING: Some recommendations may not be safe to execute directly.")

        # Next steps
        if synthesis["needs_further_action"]:
            parts.append("Further action is recommended. Follow the steps below.")
        else:
            parts.append("The logs appear healthy. Continue regular monitoring.")

        return " ".join(parts)

    def format_final_output(self, synthesis: Dict[str, Any]) -> str:
        """
        Format the synthesis into a user-friendly final output.
        """
        lines = []

        # Header
        lines.append("=" * 65)
        lines.append("  📊 LOG ANALYSIS COMPLETE")
        lines.append("=" * 65)
        lines.append("")

        # Summary
        lines.append(f"📋 Summary: {synthesis.get('summary', 'Analysis complete.')}")
        lines.append("")

        # Key findings
        if synthesis.get("error_detected"):
            lines.append(f"🔴 Errors Detected: {len(synthesis.get('error_details', []))}")
            for i, error in enumerate(synthesis.get('error_details', [])[:5], 1):
                error_type = error.get('type', 'ERROR')
                severity = error.get('severity', 'medium')
                message = error.get('message', '')[:100]
                lines.append(f"   {i}. [{severity.upper()}] {error_type}: {message}")
            lines.append("")

        # Suggestions
        for i, suggestion in enumerate(synthesis.get('suggestions', []), 1):
            title = suggestion.get('title', f'Suggestion {i}')
            content = suggestion.get('content', '')
            lines.append(f"💡 {title}:")
            lines.append(f"   {str(content)[:300]}")
            lines.append("")

        # Steps to resolve
        steps = synthesis.get('steps_to_resolve', [])
        if steps:
            lines.append("🔧 RECOMMENDED STEPS:")
            lines.append("-" * 40)
            for step in steps[:7]:
                lines.append(f"   {step}")
            lines.append("")

        # Quality assessment
        quality = synthesis.get('quality_assessment', {})
        if quality:
            lines.append(f"✅ Quality: {quality.get('score', 'N/A')}/100 ({quality.get('grade', 'N/A')})")
            lines.append(f"🛡️ Safety: {quality.get('safety_level', 'N/A')}")
            if quality.get('verdict'):
                lines.append(f"📝 Verdict: {quality.get('verdict', 'N/A')}")
            lines.append("")

        # Metadata
        lines.append("-" * 65)
        lines.append(f"Log Type: {synthesis.get('log_type', 'unknown')} | "
                     f"Entries: {synthesis.get('entries_analyzed', 0)} | "
                     f"Format: {synthesis.get('format_detected', 'unknown')}")
        lines.append(
            f"Time: {synthesis.get('timestamp', datetime.now()).strftime('%Y-%m-%d %H:%M:%S') if isinstance(synthesis.get('timestamp'), datetime) else synthesis.get('timestamp', '')}")
        lines.append("=" * 65)

        return "\n".join(lines)

    # ============================================
    # Feedback Collection
    # ============================================

    def collect_feedback(self, was_useful: bool, comments: str = "") -> Dict[str, Any]:
        """
        Collect user feedback on the analysis.
        """
        feedback = {
            "was_useful": was_useful,
            "comments": comments,
            "timestamp": datetime.now().isoformat()
        }
        self._feedback_history.append(feedback)
        return feedback

    def get_feedback_stats(self) -> Dict[str, Any]:
        """Get feedback statistics."""
        if not self._feedback_history:
            return {"total": 0, "useful": 0, "not_useful": 0, "rate": 0}

        total = len(self._feedback_history)
        useful = sum(1 for f in self._feedback_history if f.get("was_useful", False))

        return {
            "total": total,
            "useful": useful,
            "not_useful": total - useful,
            "rate": round(useful / total * 100, 1) if total > 0 else 0
        }
