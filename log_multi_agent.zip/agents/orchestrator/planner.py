# agents/orchestrator/planner.py
"""
Workflow Planner - Plans optimal agent workflows based on input type
"""

from typing import Dict, Any, List


class WorkflowPlanner:
    """
    Plans which agents should run and in what order.
    Determines the pipeline based on extracted data type.
    """

    # Pipeline definitions based on source type
    PIPELINES = {
        "direct_text": ["extractor", "preprocessor", "analyzer", "solver", "critic"],
        "file_log": ["extractor", "preprocessor", "analyzer", "solver", "critic"],
        "file_json": ["extractor", "preprocessor", "analyzer", "solver", "critic"],
        "file_csv": ["extractor", "preprocessor", "analyzer", "solver", "critic"],
        "file_xml": ["extractor", "preprocessor", "analyzer", "solver", "critic"],
        "image_ocr": ["extractor", "preprocessor", "analyzer", "solver", "critic"],
        "terminal": ["extractor", "preprocessor", "analyzer", "solver", "critic"],
        "code": ["extractor", "debugger", "solver", "critic"],
        "unknown": ["extractor", "preprocessor", "analyzer", "solver", "critic"],
    }

    def __init__(self):
        self.workflow_history = []

    def plan_workflow(self, source_type: str, context: Dict[str, Any] = None) -> List[str]:
        """
        Determine the optimal pipeline for a given source type.

        Args:
            source_type: The type of data extracted (direct_text, file_log, code, etc.)
            context: Additional context about the request

        Returns:
            List of agent IDs in execution order
        """
        # Get base pipeline for this source type
        pipeline = self.PIPELINES.get(source_type, self.PIPELINES["unknown"])

        # Adjust based on context if available
        if context:
            pipeline = self._adjust_pipeline(pipeline, context)

        return pipeline

    def _adjust_pipeline(self, pipeline: List[str], context: Dict) -> List[str]:
        """Adjust pipeline based on additional context."""
        # If user specifically asked for debugging, include debugger
        if context.get("needs_debugging"):
            if "debugger" not in pipeline:
                pipeline.insert(-1, "debugger")  # Before critic

        # If user wants just analysis without solutions
        if context.get("analysis_only"):
            pipeline = [a for a in pipeline if a not in ["solver", "debugger"]]

        # If it's a quick question, use shorter pipeline
        if context.get("quick_query"):
            pipeline = ["extractor", "analyzer", "solver"]

        return pipeline

    def get_pipeline_for_input(self, input_data: Dict[str, Any]) -> List[str]:
        """
        Determine pipeline from extraction results.

        Args:
            input_data: The output from the extractor agent

        Returns:
            List of agent IDs
        """
        source_type = input_data.get("source_type", "unknown")
        is_code = input_data.get("is_code", False)

        if is_code or source_type == "code":
            return self.PIPELINES["code"]

        return self.PIPELINES.get(source_type, self.PIPELINES["unknown"])

    def explain_pipeline(self, pipeline: List[str]) -> str:
        """Return a human-readable explanation of the pipeline."""
        agent_descriptions = {
            "extractor": "Extract data from the source",
            "preprocessor": "Clean and structure the data",
            "analyzer": "Analyze for patterns and anomalies",
            "solver": "Generate solutions for issues found",
            "debugger": "Deep code analysis and debugging",
            "critic": "Validate quality of the output",
            "memory": "Retrieve relevant context from history",
        }

        steps = []
        for i, agent_id in enumerate(pipeline, 1):
            desc = agent_descriptions.get(agent_id, agent_id)
            steps.append(f"  Step {i}: {agent_id} - {desc}")

        return "\n".join(steps)