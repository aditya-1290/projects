# agents/extractor/__init__.py
"""
Extractor Agent - Extracts logs from various sources
"""

from .agent import ExtractorAgent

__all__ = ['ExtractorAgent']