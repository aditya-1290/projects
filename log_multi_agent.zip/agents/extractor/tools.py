# agents/extractor/tools.py
"""
Extractor Tools - Utility tools for the Extractor Agent
"""

from typing import Dict, Any, Optional
import subprocess
import json
from pathlib import Path


class ExtractorTools:
    """Tools for extracting logs from various sources"""

    def parse_raw_text(self, text: str) -> Dict[str, Any]:
        """Parse raw text and attempt to structure it"""
        lines = text.strip().split('\n')
        return {
            "raw_lines": lines,
            "line_count": len(lines),
            "detected_format": self._detect_format(lines)
        }

    def _detect_format(self, lines: list) -> str:
        """Detect the format of log entries"""
        if not lines:
            return "unknown"

        first_line = lines[0]
        if first_line.startswith('{') or first_line.startswith('['):
            return "json"
        elif ',' in first_line and len(first_line.split(',')) > 3:
            return "csv"
        elif first_line.startswith('<'):
            return "xml"
        elif self._looks_like_syslog(first_line):
            return "syslog"
        elif self._looks_like_apache(first_line):
            return "apache_log"
        else:
            return "plain_text"

    def _looks_like_syslog(self, line: str) -> bool:
        """Check if line looks like a syslog entry"""
        # Syslog format: <timestamp> <hostname> <process>[<pid>]: <message>
        import re
        syslog_pattern = r'\w{3}\s+\d+\s+\d{2}:\d{2}:\d{2}\s+\S+\s+\S+'
        return bool(re.match(syslog_pattern, line))

    def _looks_like_apache(self, line: str) -> bool:
        """Check if line looks like an Apache log entry"""
        # Apache format: IP - - [timestamp] "METHOD URL PROTOCOL" STATUS SIZE
        import re
        apache_pattern = r'\S+\s+\S+\s+\S+\s+\[.*?\]'
        return bool(re.match(apache_pattern, line))

    async def perform_ocr(self, image_path: str, ocr_model=None) -> Dict[str, Any]:
        """Perform OCR on an image"""
        # This would integrate with DeepSeek OCR
        # For now, return a placeholder
        image_path = Path(image_path)
        if not image_path.exists():
            return {"error": "Image file not found", "confidence": 0.0}

        # Simulated OCR result
        return {
            "text": f"Extracted text from {image_path.name}",
            "confidence": 0.95,
            "image_path": str(image_path)
        }

    async def execute_terminal_command(self, command: str) -> Dict[str, Any]:
        """Execute a terminal command safely"""
        try:
            # Validate command against whitelist
            if not self._is_command_safe(command):
                return {"error": "Command not allowed for security reasons"}

            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=10
            )

            return {
                "stdout": result.stdout,
                "stderr": result.stderr,
                "return_code": result.returncode
            }
        except subprocess.TimeoutExpired:
            return {"error": "Command timed out"}
        except Exception as e:
            return {"error": str(e)}

    def _is_command_safe(self, command: str) -> bool:
        """Check if command is in the allowed whitelist"""
        from config import Config
        base_command = command.split()[0] if command.split() else ""
        return base_command in Config.COMMAND_WHITELIST

    def detect_file_type(self, file_path: str) -> str:
        """Detect file type based on extension"""
        path = Path(file_path)
        extension = path.suffix.lower()

        type_map = {
            '.log': 'log',
            '.txt': 'text',
            '.json': 'json',
            '.csv': 'csv',
            '.xml': 'xml',
            '.gz': 'compressed',
            '.zip': 'compressed'
        }

        return type_map.get(extension, 'unknown')

    def read_file(self, file_path: str) -> Dict[str, Any]:
        """Read and parse a file"""
        path = Path(file_path)
        if not path.exists():
            return {"error": "File not found"}

        try:
            with open(path, 'r') as f:
                content = f.read()

            file_type = self.detect_file_type(file_path)

            # Parse based on type
            if file_type == 'json':
                parsed = json.loads(content)
            else:
                parsed = content

            return {
                "file_path": str(path),
                "file_type": file_type,
                "content": parsed,
                "size": path.stat().st_size
            }
        except Exception as e:
            return {"error": f"Failed to read file: {str(e)}"}