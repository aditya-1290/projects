# agents/extractor/agent.py
"""
Extractor Agent - Dynamically detects input type and extracts logs
No model needed for basic extraction - uses tools for files/commands/images
"""

from typing import Dict, Any, List, Optional
import logging
from pathlib import Path
from datetime import datetime
import re

from agents.base_agent import BaseAgent, A2AMessage, MessageType, AgentState
from .loaders.file_loader import FileLoader
from .loaders.image_loader import ImageLoader
from .loaders.terminal_loader import TerminalLoader
from .parsers.json_parser import JSONParser
from .parsers.csv_parser import CSVParser
from .parsers.xml_parser import XMLParser
from .parsers.syslog_parser import SyslogParser
from .parsers.apache_log_parser import ApacheLogParser

logger = logging.getLogger(__name__)


class ExtractorAgent(BaseAgent):
    """Extracts logs by dynamically detecting the input type."""

    def __init__(self, agent_id: str = "extractor", capability_path: str = None, config=None, **kwargs):
        if hasattr(agent_id, 'agent_id') and hasattr(agent_id, 'capabilities'):
            config = agent_id
            agent_id = config.agent_id if hasattr(config, 'agent_id') else "extractor"
            if capability_path is None:
                capability_path = getattr(config, 'capability_path', None)
        elif config is not None:
            agent_id = config.agent_id if hasattr(config, 'agent_id') else "extractor"
            if capability_path is None:
                capability_path = getattr(config, 'capability_path', None)

        if capability_path is None:
            default_path = Path(__file__).parent / "capabilities.json"
            if default_path.exists():
                capability_path = str(default_path)

        super().__init__(agent_id=agent_id, capability_path=capability_path)

        self.file_loader = FileLoader()
        self.image_loader = ImageLoader()
        self.terminal_loader = TerminalLoader()
        self.extraction_history = []

    def get_system_prompt(self) -> str:
        return """You are a log extraction agent. Extract and parse log data from any source."""

    # ============================================
    # Main Process
    # ============================================

    # agents/extractor/agent.py - Update process method to show progress:

    async def process(self, message: A2AMessage) -> A2AMessage:
        """Process incoming A2A message for log extraction."""
        task = message.task or {}

        if task.get("action") == "report_capabilities":
            return A2AMessage(
                message_type=MessageType.RESPONSE,
                sender_id=self.agent_id,
                sender_type=self.capability.agent_name,
                target_id=message.sender_id,
                correlation_id=message.message_id,
                response=self.capability.to_dict(),
                confidence=1.0
            )

        input_data = task.get("input", {})
        if not input_data:
            input_data = task

        raw_text = (
                input_data.get("raw_content") or
                input_data.get("text") or
                input_data.get("content") or
                str(input_data)
        )

        if isinstance(raw_text, dict):
            inner = raw_text.get("input", {})
            if isinstance(inner, dict):
                raw_text = inner.get("text") or inner.get("raw_content") or str(inner)

        text_len = len(str(raw_text))
        line_count = len(str(raw_text).splitlines())

        # ⭐ PRINT TO TERMINAL
        print(f"     [EXTRACTOR] Received: {text_len} chars, {line_count} lines")
        logger.info(f"[EXTRACTOR] Processing: len={text_len}, lines={line_count}")

        try:
            self.state = AgentState.PROCESSING

            # Step 1: LOAD
            print(f"     [EXTRACTOR] Detecting input type...")
            source_type, loaded_result = await self._load_content(str(raw_text))
            print(f"     [EXTRACTOR] Detected: {source_type}")

            if not loaded_result or not loaded_result.get("success"):
                error_msg = loaded_result.get("error", "Failed to load") if loaded_result else "No data"
                print(f"     [EXTRACTOR] ERROR: {error_msg}")
                return A2AMessage(
                    message_type=MessageType.ERROR,
                    sender_id=self.agent_id,
                    sender_type=self.capability.agent_name,
                    target_id=message.sender_id,
                    correlation_id=message.message_id,
                    error=error_msg
                )

            # Step 2: PARSE
            raw_content = loaded_result.get("raw_content", str(raw_text))
            print(f"     [EXTRACTOR] Parsing content ({len(str(raw_content))} chars)...")

            parsed = self._parse_content(str(raw_content), source_type)

            fmt = parsed.get("format", "unknown")
            entries = parsed.get("entry_count", 0)
            parser_used = parsed.get("parser_used", "none")

            print(f"     [EXTRACTOR] Format: {fmt} | Entries: {entries} | Parser: {parser_used}")
            logger.info(f"[EXTRACTOR] Parse result: format={fmt}, entries={entries}")

            # Build result
            result = {
                **loaded_result,
                **parsed,
                "success": True,
                "agent_id": self.agent_id,
                "source_type": source_type,
                "raw_content": raw_content,
                "load_method": source_type
            }

            self.state = AgentState.IDLE

            return A2AMessage(
                message_type=MessageType.RESPONSE,
                sender_id=self.agent_id,
                sender_type=self.capability.agent_name,
                target_id=message.sender_id,
                correlation_id=message.message_id,
                response=result,
                confidence=result.get("confidence", 0.85)
            )

        except Exception as e:
            self.state = AgentState.ERROR
            print(f"     [EXTRACTOR] EXCEPTION: {str(e)[:100]}")
            logger.error(f"[EXTRACTOR] Error: {e}", exc_info=True)
            return A2AMessage(
                message_type=MessageType.ERROR,
                sender_id=self.agent_id,
                sender_type=self.capability.agent_name,
                target_id=message.sender_id,
                correlation_id=message.message_id,
                error=str(e)
            )

    # ============================================
    # Load Content
    # ============================================

    async def _load_content(self, raw_text: str) -> tuple:
        """Detect input type and load content accordingly."""
        cleaned = raw_text.strip().strip('"').strip("'")

        # Check if it's a file path
        path = Path(cleaned)
        if path.exists() and path.is_file():
            suffix = path.suffix.lower()
            if suffix in ['.png', '.jpg', '.jpeg', '.bmp', '.webp', '.tiff', '.gif']:
                logger.info(f"[EXTRACTOR] Loading image: {cleaned}")
                return "image", await self._try_image_extraction(cleaned)
            else:
                logger.info(f"[EXTRACTOR] Loading file: {cleaned}")
                return "file", await self._try_file_extraction(cleaned)

        # Check if it looks like a command
        if self._looks_like_command(cleaned) and len(cleaned.splitlines()) == 1:
            logger.info(f"[EXTRACTOR] Executing command: {cleaned}")
            return "terminal", await self._try_terminal_extraction(cleaned)

        # Direct text
        logger.info(f"[EXTRACTOR] Direct text: {len(raw_text.splitlines())} lines")
        return "direct_text", {
            "success": True,
            "source_type": "direct_text",
            "raw_content": raw_text,
            "line_count": len(raw_text.splitlines()),
            "confidence": 0.95
        }

    # ============================================
    # ⭐ PARSE CONTENT - COMPLETELY FIXED
    # ============================================

    def _parse_content(self, raw_content: str, source_type: str = None) -> Dict[str, Any]:
        """
        Parse content by trying ALL parsers and picking the one with the most entries.
        ⭐ FIXED: Tries ALL parsers, picks the one with `highest entry count.
        """
        if not raw_content or not raw_content.strip():
            return {"parsed": False, "format": "unknown", "entry_count": 0, "error": "Empty content"}

        lines = [l for l in raw_content.splitlines() if l.strip()]
        total_lines = len(lines)

        # ⭐ Try ALL parsers and collect results
        parser_results = []

        parsers = [
            (JSONParser(), "json"),
            (XMLParser(), "xml"),
            (CSVParser(), "csv"),
            (SyslogParser(), "syslog"),
            (ApacheLogParser(), "apache"),
        ]

        for parser, format_name in parsers:
            try:
                result = parser.parse(raw_content)
                if isinstance(result, dict):
                    entry_count = result.get("entry_count", result.get("total_entries", 0))
                    has_error = bool(result.get("error"))

                    parser_results.append({
                        "format": format_name,
                        "entry_count": entry_count,
                        "has_error": has_error,
                        "result": result,
                        "parser": parser.__class__.__name__
                    })

                    logger.debug(f"[EXTRACTOR] {format_name}: {entry_count} entries (error={has_error})")

            except Exception as e:
                logger.debug(f"[EXTRACTOR] {format_name} exception: {str(e)[:50]}")

        # ⭐ Find the parser with the MOST entries
        successful = [r for r in parser_results if r["entry_count"] > 0 and not r["has_error"]]

        if successful:
            # Sort by entry count (highest first)
            successful.sort(key=lambda x: x["entry_count"], reverse=True)
            best = successful[0]

            logger.info(
                f"[EXTRACTOR] Best parser: {best['format']} with {best['entry_count']} entries (from {len(parser_results)} attempts)")

            return {
                "parsed": True,
                "format": best["format"],
                "data": best["result"],
                "entry_count": best["entry_count"],
                "parser_used": best["parser"],
                "line_count": total_lines
            }

        # ⭐ No parser matched - create plain text entries
        logger.info(f"[EXTRACTOR] No parser matched from {len(parser_results)} attempts. Creating plain text entries.")

        plain_entries = []
        for i, line in enumerate(lines):
            plain_entries.append({
                "line_number": i + 1,
                "raw": line,
                "message": line,
                "level": self._detect_level_in_line(line),
                "timestamp": self._extract_timestamp_from_line(line)
            })

        return {
            "parsed": True,
            "format": "plain_text",
            "data": {
                "format": "plain_text",
                "parsed": True,
                "entries": plain_entries,
                "entry_count": len(plain_entries),
                "total_entries": len(plain_entries)
            },
            "entry_count": len(plain_entries),
            "line_count": total_lines,
            "parser_used": "PlainTextFallback",
            "parsers_tried": [r["format"] for r in parser_results]
        }

    # ============================================
    # Line-Level Helpers
    # ============================================

    def _detect_level_in_line(self, line: str) -> str:
        """Detect log level in a single line."""
        line_upper = line.upper()
        levels = ["CRITICAL", "FATAL", "ERROR", "WARNING", "WARN", "INFO", "DEBUG", "TRACE", "NOTICE"]
        for level in levels:
            # Match level as a whole word
            if re.search(r'\b' + level + r'\b', line_upper):
                return level
        if "TRACEBACK" in line_upper or "FILE \"" in line_upper:
            return "ERROR"
        return "INFO"

    def _extract_timestamp_from_line(self, line: str) -> str:
        """Extract timestamp from a line."""
        patterns = [
            r'(\d{4}-\d{2}-\d{2}[\sT]\d{2}:\d{2}:\d{2}(?:[.,]\d+)?)',  # ISO format
            r'(\d{2}/\d{2}/\d{4}\s+\d{2}:\d{2}:\d{2})',  # US format
            r'(\w{3}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2})',  # Syslog format
        ]
        for pattern in patterns:
            match = re.search(pattern, line)
            if match:
                return match.group(1)
        return ""

    # ============================================
    # Detection Helpers
    # ============================================

    def _looks_like_command(self, text: str) -> bool:
        command_patterns = [
            r'^(cat|tail|head|grep|awk|sed|less|more|ls|dir|find|locate)\s',
            r'^(ps|top|htop|kill|killall|df|du|free|vmstat|iostat)\s',
            r'^(netstat|ss|ifconfig|ip|ping|traceroute)\s',
            r'^(journalctl|dmesg|syslog)\s',
            r'^(docker|kubectl|systemctl|service)\s',
            r'^(python|node|npm|pip|git)\s',
        ]
        for pattern in command_patterns:
            if re.match(pattern, text, re.IGNORECASE):
                return True
        return False

    # ============================================
    # Extraction Methods
    # ============================================

    async def _try_file_extraction(self, file_path: str) -> Dict[str, Any]:
        logger.info(f"[EXTRACTOR] Loading file: {file_path}")
        result = self.file_loader.load_file(file_path)
        if "error" in result:
            return {"success": False, "error": result["error"], "source_type": "file", "file_path": file_path}
        content = result.get("content", "")
        return {
            "success": True,
            "source_type": f"file_{result.get('file_type', 'unknown')}",
            "raw_content": content if isinstance(content, str) else str(content),
            "file_path": file_path,
            "metadata": result.get("metadata", {}),
            "line_count": len(content.splitlines()) if isinstance(content, str) else 0,
            "confidence": 0.9
        }

    async def _try_image_extraction(self, image_path: str) -> Dict[str, Any]:
        logger.info(f"[EXTRACTOR] Loading image: {image_path}")
        result = await self.image_loader.extract_from_image(image_path)
        if "error" in result:
            return {"success": False, "error": result["error"], "source_type": "image", "image_path": image_path}
        return {
            "success": True,
            "source_type": "image_ocr",
            "raw_content": result.get("text", ""),
            "image_path": image_path,
            "ocr_confidence": result.get("confidence", 0.0),
            "confidence": result.get("confidence", 0.5)
        }

    async def _try_terminal_extraction(self, command: str) -> Dict[str, Any]:
        logger.info(f"[EXTRACTOR] Executing command: {command}")
        result = await self.terminal_loader.execute_with_permission(command)
        if not result.get("success"):
            return {"success": False, "error": result.get("error", "Command failed"), "source_type": "terminal",
                    "command": command}
        return {
            "success": True,
            "source_type": "terminal",
            "raw_content": result.get("stdout", ""),
            "command": command,
            "return_code": result.get("return_code", 0),
            "confidence": 0.85
        }