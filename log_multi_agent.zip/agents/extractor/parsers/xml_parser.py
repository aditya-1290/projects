# agents/extractor/parsers/xml_parser.py
"""
XML Log Parser - Parses XML formatted logs
"""

import xml.etree.ElementTree as ET
from typing import Dict, Any, List, Optional
import re
import logging

logger = logging.getLogger(__name__)


class XMLParser:
    """Parser for XML-formatted logs"""

    def __init__(self):
        self.max_depth = 10  # Maximum recursion depth for XML parsing

    def parse(self, content: str) -> Dict[str, Any]:
        """Parse XML log content"""
        try:
            # Clean the content
            cleaned_content = self._clean_xml(content)

            # Parse XML
            root = ET.fromstring(cleaned_content)

            # Convert to dictionary/list structure
            parsed_data = self._element_to_dict(root)

            # Get structure information
            structure = self._analyze_structure(root)

            return {
                "format": "xml",
                "parsed": True,
                "data": parsed_data,
                "root_tag": root.tag,
                "structure": structure,
                "summary": self._generate_summary(root, parsed_data)
            }

        except ET.ParseError as e:
            logger.error(f"XML parse error: {str(e)}")
            # Try parsing as log entries
            return self._parse_xml_lines(content)
        except Exception as e:
            logger.error(f"XML parsing failed: {str(e)}")
            return {
                "format": "xml",
                "parsed": False,
                "entry_count": 0,
                "error": str(e),
                "raw_content": content[:1500]
            }

    def _clean_xml(self, content: str) -> str:
        """Clean XML content before parsing"""
        # Remove XML declaration if present
        content = re.sub(r'<\?xml[^>]*\?>', '', content)

        # Handle multiple root elements by wrapping in a container
        root_elements = re.findall(r'<(\w+)[^>]*>', content)
        if len(set(root_elements[:2])) > 1 or content.count('<') > content.count('</') + 1:
            # Multiple different root elements, wrap them
            content = f"<log_entries>{content}</log_entries>"

        # Remove comments
        content = re.sub(r'<!--.*?-->', '', content, flags=re.DOTALL)

        return content.strip()

    def _element_to_dict(self, element: ET.Element, depth: int = 0) -> Any:
        """Convert XML element to dictionary/list structure"""
        if depth > self.max_depth:
            return {"_max_depth_reached": True}

        result = {}

        # Add attributes
        if element.attrib:
            result['@attributes'] = element.attrib

        # Add children
        children = list(element)
        if children:
            # Group children by tag
            child_dict = {}
            for child in children:
                child_data = self._element_to_dict(child, depth + 1)

                if child.tag in child_dict:
                    # Convert to list if multiple children with same tag
                    if not isinstance(child_dict[child.tag], list):
                        child_dict[child.tag] = [child_dict[child.tag]]
                    child_dict[child.tag].append(child_data)
                else:
                    child_dict[child.tag] = child_data

            result.update(child_dict)

        # Add text content
        text = element.text
        if text and text.strip():
            if not children and not element.attrib:
                # Simple element with only text
                result = text.strip()
            else:
                result['#text'] = text.strip()

        return result

    def _analyze_structure(self, root: ET.Element) -> Dict[str, Any]:
        """Analyze the structure of XML log"""
        # Find recurring patterns (log entries)
        children = list(root)
        tag_counts = {}

        for child in children:
            tag_counts[child.tag] = tag_counts.get(child.tag, 0) + 1

        # Determine if this is a log file with repeated entries
        if len(children) > 1:
            most_common_tag = max(tag_counts, key=tag_counts.get)
            is_log_format = tag_counts[most_common_tag] / len(children) > 0.5

            if is_log_format:
                # Sample a few entries to understand structure
                sample_entries = [
                    self._element_to_dict(c)
                    for c in children[:3]
                    if c.tag == most_common_tag
                ]

                return {
                    "type": "log_entries",
                    "entry_tag": most_common_tag,
                    "total_entries": tag_counts[most_common_tag],
                    "sample_structure": sample_entries[0] if sample_entries else {},
                    "all_tags": list(tag_counts.keys()),
                    "tag_distribution": tag_counts
                }

        return {
            "type": "structured_xml",
            "root_tag": root.tag,
            "child_tags": list(tag_counts.keys()),
            "tag_distribution": tag_counts
        }

    def _parse_xml_lines(self, content: str) -> Dict[str, Any]:
        """Attempt to parse content as individual XML lines"""
        lines = content.strip().split('\n')
        entries = []
        errors = []

        current_entry = ""
        for i, line in enumerate(lines):
            current_entry += line

            # Check if we have a complete XML element
            if self._is_complete_xml(current_entry):
                try:
                    element = ET.fromstring(current_entry)
                    entries.append(self._element_to_dict(element))
                    current_entry = ""
                except ET.ParseError:
                    # Keep accumulating
                    if len(current_entry) > 10000:  # Safety limit
                        errors.append({
                            "line": i + 1,
                            "content": current_entry[:100]
                        })
                        current_entry = ""

        return {
            "format": "xml_lines",
            "parsed": True,
            "data": entries,
            "entry_count": len(entries),
            "error_count": len(errors),
            "errors": errors
        }

    def _is_complete_xml(self, text: str) -> bool:
        """Check if text contains a complete XML element"""
        # Simple check: should start with < and end with >
        text = text.strip()
        if not (text.startswith('<') and text.endswith('>')):
            return False

        # Count opening and closing tags
        open_tags = len(re.findall(r'<\w+[^>]*>', text))
        close_tags = len(re.findall(r'</\w+>', text))
        self_closing = len(re.findall(r'<\w+[^>]*/>', text))

        return open_tags == close_tags + self_closing

    def _generate_summary(self, root: ET.Element, parsed_data: Dict) -> Dict[str, Any]:
        """Generate summary of XML log data"""
        summary = {
            "root_tag": root.tag,
            "timestamp": None
        }

        # Try to find common log fields
        log_fields = ['timestamp', 'time', 'date', 'level', 'severity',
                      'message', 'source', 'host', 'error', 'status']

        found_fields = []
        for field in log_fields:
            if self._find_field(parsed_data, field):
                found_fields.append(field)

        summary["identified_log_fields"] = found_fields

        # Count total entries if it's a log format
        structure = self._analyze_structure(root)
        if structure.get("type") == "log_entries":
            summary["total_entries"] = structure["total_entries"]

        return summary

    def _find_field(self, data: Any, field_name: str) -> bool:
        """Recursively search for a field in parsed data"""
        if isinstance(data, dict):
            for key, value in data.items():
                if field_name.lower() in key.lower():
                    return True
                if self._find_field(value, field_name):
                    return True
        elif isinstance(data, list):
            for item in data[:10]:  # Check first 10 items
                if self._find_field(item, field_name):
                    return True
        return False