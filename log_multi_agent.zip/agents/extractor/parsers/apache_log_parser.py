# agents/extractor/parsers/apache_log_parser.py
"""
Apache Log Parser - Parses Apache/Nginx web server logs
"""

import re
from typing import Dict, Any, List, Optional
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


class ApacheLogParser:
    """Parser for Apache and Nginx web server logs"""

    # Common Log Format (CLF)
    CLF_PATTERN = re.compile(
        r'(?P<ip>\S+)\s+'  # IP address
        r'(?P<identd>\S+)\s+'  # Identd (usually -)
        r'(?P<user>\S+)\s+'  # User (usually -)
        r'\[(?P<timestamp>[^\]]+)\]\s+'  # Timestamp
        r'"(?P<method>[A-Z]+)\s+'  # HTTP method
        r'(?P<url>[^\s]+)\s+'  # URL
        r'(?P<protocol>[^"]+)"\s+'  # Protocol
        r'(?P<status>\d{3})\s+'  # Status code
        r'(?P<size>\S+)'  # Response size
    )

    # Combined Log Format (with referer and user-agent)
    COMBINED_PATTERN = re.compile(
        r'(?P<ip>\S+)\s+'
        r'(?P<identd>\S+)\s+'
        r'(?P<user>\S+)\s+'
        r'\[(?P<timestamp>[^\]]+)\]\s+'
        r'"(?P<method>[A-Z]+)\s+'
        r'(?P<url>[^\s]+)\s+'
        r'(?P<protocol>[^"]+)"\s+'
        r'(?P<status>\d{3})\s+'
        r'(?P<size>\S+)\s+'
        r'"(?P<referer>[^"]*)"\s+'
        r'"(?P<user_agent>[^"]*)"'
    )

    # Nginx error log format
    NGINX_ERROR_PATTERN = re.compile(
        r'(?P<timestamp>\d{4}/\d{2}/\d{2}\s+\d{2}:\d{2}:\d{2})\s+'
        r'\[(?P<level>[^\]]+)\]\s+'
        r'(?P<pid>\d+#\d+):\s+'
        r'(?P<message>.*?)(?:,\s+client:\s+(?P<client>\S+))?'
        r'(?:,\s+server:\s+(?P<server>\S+))?'
        r'(?:,\s+request:\s+"(?P<request>[^"]*)")?'
        r'(?:,\s+host:\s+"(?P<host>[^"]*)")?'
    )

    # Custom log format patterns
    CUSTOM_PATTERNS = {
        'json_apache': re.compile(
            r'\{.*"ip":\s*"(?P<ip>[^"]+)".*'
            r'"timestamp":\s*"(?P<timestamp>[^"]+)".*'
            r'"method":\s*"(?P<method>[^"]+)".*'
            r'"url":\s*"(?P<url>[^"]+)".*'
            r'"status":\s*(?P<status>\d+).*'
            r'"size":\s*(?P<size>\d+).*\}'
        )
    }

    def parse(self, content: str) -> Dict[str, Any]:
        """Parse Apache/Nginx log content"""
        lines = content.strip().split('\n')
        entries = []
        errors = []

        # Detect format from first line
        detected_format = self._detect_format(lines[0] if lines else "")

        for i, line in enumerate(lines):
            if not line.strip():
                continue

            parsed = self._parse_line(line, detected_format)
            if parsed:
                entries.append(parsed)
            else:
                errors.append({"line": i + 1, "content": line[:200]})

        return {
            "format": detected_format,
            "parsed": True,
            "entries": entries,
            "entry_count": 0,
            "error_count": len(errors),
            "errors": errors[:10],  # Limit error display
            "summary": self._generate_summary(entries)
        }

    def _detect_format(self, first_line: str) -> str:
        """Detect the log format from a sample line"""
        if not first_line:
            return "unknown"

        # Try combined format first (most detailed)
        if self.COMBINED_PATTERN.match(first_line):
            return "apache_combined"

        # Try common log format
        if self.CLF_PATTERN.match(first_line):
            return "apache_common"

        # Try Nginx error log
        if self.NGINX_ERROR_PATTERN.match(first_line):
            return "nginx_error"

        # Try custom formats
        for format_name, pattern in self.CUSTOM_PATTERNS.items():
            if pattern.match(first_line):
                return format_name

        # Check if it looks like a web server log
        if re.search(r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}', first_line):
            return "custom_web_log"

        return "unknown"

    def _parse_line(self, line: str, format_type: str) -> Optional[Dict[str, Any]]:
        """Parse a single log line based on detected format"""

        # Try combined format
        match = self.COMBINED_PATTERN.match(line)
        if match:
            return self._enrich_entry(match.groupdict(), "apache_combined")

        # Try common format
        match = self.CLF_PATTERN.match(line)
        if match:
            return self._enrich_entry(match.groupdict(), "apache_common")

        # Try Nginx error format
        match = self.NGINX_ERROR_PATTERN.match(line)
        if match:
            return self._enrich_entry(match.groupdict(), "nginx_error")

        # Try custom formats
        for format_name, pattern in self.CUSTOM_PATTERNS.items():
            match = pattern.match(line)
            if match:
                return self._enrich_entry(match.groupdict(), format_name)

        return None

    def _enrich_entry(self, entry: Dict[str, str], format_type: str) -> Dict[str, Any]:
        """Enrich parsed entry with additional information"""
        enriched = {**entry}

        # Parse timestamp
        if 'timestamp' in enriched:
            enriched['parsed_timestamp'] = self._parse_timestamp(enriched['timestamp'])

        # Classify status code
        if 'status' in enriched:
            try:
                status_code = int(enriched['status'])
                enriched['status_category'] = self._classify_status(status_code)
                enriched['is_error'] = status_code >= 400
                enriched['is_server_error'] = status_code >= 500
            except ValueError:
                pass

        # Parse response size
        if 'size' in enriched:
            try:
                if enriched['size'] != '-':
                    enriched['size_bytes'] = int(enriched['size'])
            except ValueError:
                pass

        # Extract URL components
        if 'url' in enriched:
            enriched['url_components'] = self._parse_url(enriched['url'])

        # Detect user agent info
        if 'user_agent' in enriched:
            enriched['browser_info'] = self._parse_user_agent(enriched['user_agent'])

        # Add security analysis
        enriched['security_flags'] = self._check_security_issues(entry)

        return enriched

    def _parse_timestamp(self, timestamp: str) -> Optional[str]:
        """Parse Apache timestamp format to ISO format"""
        # Apache format: 31/Dec/2023:23:59:59 +0000
        try:
            dt = datetime.strptime(timestamp.split(' ')[0], '%d/%b/%Y:%H:%M:%S')
            return dt.isoformat()
        except (ValueError, IndexError):
            pass

        # Try ISO format directly
        try:
            dt = datetime.fromisoformat(timestamp)
            return dt.isoformat()
        except ValueError:
            pass

        return None

    def _classify_status(self, status_code: int) -> str:
        """Classify HTTP status code"""
        categories = {
            100: "informational",
            200: "success",
            300: "redirection",
            400: "client_error",
            500: "server_error"
        }

        category = status_code // 100 * 100
        return categories.get(category, "unknown")

    def _parse_url(self, url: str) -> Dict[str, Any]:
        """Parse URL into components"""
        result = {
            "full_url": url,
            "path": url,
            "query_params": {},
            "has_suspicious_patterns": False
        }

        # Extract query string
        if '?' in url:
            path_part, query_part = url.split('?', 1)
            result['path'] = path_part
            result['raw_query'] = query_part

            # Parse query parameters
            for param in query_part.split('&'):
                if '=' in param:
                    key, value = param.split('=', 1)
                    result['query_params'][key] = value

        # Check for suspicious patterns (security scanning, SQL injection, XSS)
        suspicious_patterns = [
            r'union\s+select', r'<script', r'../',
            r'\.\.\\', r'exec\s*\(', r'eval\s*\(',
            r'passwd', r'shadow', r'\.\.%2f'
        ]

        for pattern in suspicious_patterns:
            if re.search(pattern, url, re.IGNORECASE):
                result['has_suspicious_patterns'] = True
                result['suspicious_pattern'] = pattern
                break

        # Check for file extension
        extension_match = re.search(r'\.(\w+)$', result['path'])
        if extension_match:
            result['file_extension'] = extension_match.group(1)

        return result

    def _parse_user_agent(self, user_agent: str) -> Dict[str, Any]:
        """Parse user agent string"""
        info = {
            "raw": user_agent,
            "browser": "unknown",
            "os": "unknown",
            "is_bot": False
        }

        # Detect bots/crawlers
        bot_patterns = ['bot', 'crawler', 'spider', 'scraper', 'curl', 'wget']
        info['is_bot'] = any(pattern in user_agent.lower() for pattern in bot_patterns)

        # Detect browsers
        if 'Chrome' in user_agent:
            info['browser'] = 'Chrome'
        elif 'Firefox' in user_agent:
            info['browser'] = 'Firefox'
        elif 'Safari' in user_agent:
            info['browser'] = 'Safari'
        elif 'Edge' in user_agent:
            info['browser'] = 'Edge'

        # Detect OS
        if 'Windows' in user_agent:
            info['os'] = 'Windows'
        elif 'Mac' in user_agent:
            info['os'] = 'macOS'
        elif 'Linux' in user_agent:
            info['os'] = 'Linux'
        elif 'Android' in user_agent:
            info['os'] = 'Android'
        elif 'iPhone' in user_agent:
            info['os'] = 'iOS'

        return info

    def _check_security_issues(self, entry: Dict[str, str]) -> List[str]:
        """Check for security issues in log entry"""
        flags = []

        # Check URL for attacks
        url = entry.get('url', '')
        if url:
            # SQL Injection patterns
            if re.search(r'(?i)(union.*select|or\s+1=1|--|;--)', url):
                flags.append('possible_sql_injection')

            # XSS patterns
            if re.search(r'(?i)(<script|javascript:|onerror=|onload=)', url):
                flags.append('possible_xss')

            # Path traversal
            if re.search(r'\.\./', url):
                flags.append('path_traversal')

            # Command injection
            if re.search(r'[;&|`$]', url):
                flags.append('possible_command_injection')

        # Check status for brute force
        status = entry.get('status', '')
        if status == '401' or status == '403':
            flags.append('authentication_failure')

        # Check for scanner user agents
        user_agent = entry.get('user_agent', '')
        scanner_agents = ['nikto', 'nessus', 'nmap', 'burp', 'zap', 'sqlmap']
        if any(scanner in user_agent.lower() for scanner in scanner_agents):
            flags.append('security_scanner')

        return flags

    def _generate_summary(self, entries: List[Dict]) -> Dict[str, Any]:
        """Generate summary of web server logs"""
        if not entries:
            return {"error": "No entries to summarize"}

        # Count status codes
        status_counts = {}
        for entry in entries:
            status = entry.get('status', 'unknown')
            status_counts[status] = status_counts.get(status, 0) + 1

        # Count HTTP methods
        method_counts = {}
        for entry in entries:
            method = entry.get('method', 'unknown')
            method_counts[method] = method_counts.get(method, 0) + 1

        # Top URLs
        url_counts = {}
        for entry in entries:
            url = entry.get('url', '')
            if url:
                # Strip query strings for grouping
                base_url = url.split('?')[0]
                url_counts[base_url] = url_counts.get(base_url, 0) + 1

        top_urls = sorted(url_counts.items(), key=lambda x: x[1], reverse=True)[:10]

        # Error rates
        total = len(entries)
        errors = sum(1 for e in entries if e.get('is_error', False))
        server_errors = sum(1 for e in entries if e.get('is_server_error', False))

        # Security flags
        security_issues = []
        for entry in entries:
            flags = entry.get('security_flags', [])
            security_issues.extend(flags)

        return {
            "total_requests": total,
            "unique_ips": len(set(e.get('ip') for e in entries if e.get('ip'))),
            "status_distribution": status_counts,
            "method_distribution": method_counts,
            "top_urls": top_urls,
            "error_rate": (errors / total * 100) if total > 0 else 0,
            "server_error_rate": (server_errors / total * 100) if total > 0 else 0,
            "security_issues_found": list(set(security_issues)),
            "is_bot_traffic": sum(1 for e in entries if e.get('browser_info', {}).get('is_bot', False))
        }