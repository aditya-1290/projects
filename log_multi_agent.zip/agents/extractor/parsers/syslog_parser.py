# agents/extractor/parsers/syslog_parser.py
"""
Syslog Parser - Parses syslog formatted logs
"""

import re
from typing import Dict, Any, List, Optional
from datetime import datetime


class SyslogParser:
    """Parser for syslog format logs"""

    # Syslog pattern: <timestamp> <hostname> <process>[<pid>]: <message>
    SYSLOG_PATTERN = re.compile(
        r'(?P<timestamp>\w{3}\s+\d+\s+\d{2}:\d{2}:\d{2})\s+'
        r'(?P<hostname>\S+)\s+'
        r'(?P<process>[^\s:]+)(?:\[(?P<pid>\d+)\])?:\s+'
        r'(?P<message>.*)'
    )

    # Alternative pattern for ISO timestamps
    ISO_SYSLOG_PATTERN = re.compile(
        r'(?P<timestamp>\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}[^\s]*)\s+'
        r'(?P<hostname>\S+)\s+'
        r'(?P<process>[^\s:]+)(?:\[(?P<pid>\d+)\])?:\s+'
        r'(?P<message>.*)'
    )

    def parse(self, content: str) -> Dict[str, Any]:
        """Parse syslog formatted content"""
        lines = content.strip().split('\n')
        entries = []
        errors = []

        for i, line in enumerate(lines):
            if not line.strip():
                continue

            parsed = self._parse_line(line)
            if parsed:
                entries.append(parsed)
            else:
                errors.append({"line": i + 1, "content": line[:100]})

        return {
            "format": "syslog",
            "parsed": True,
            "entries": entries,
            "entry_count": 0,
            "error_count": len(errors),
            "errors": errors,
            "summary": self._generate_summary(entries)
        }

    def _parse_line(self, line: str) -> Optional[Dict[str, Any]]:
        """Parse a single syslog line"""
        # Try ISO format first
        match = self.ISO_SYSLOG_PATTERN.match(line)
        if not match:
            # Try traditional format
            match = self.SYSLOG_PATTERN.match(line)

        if match:
            data = match.groupdict()

            # Try to determine severity
            data['severity'] = self._determine_severity(data.get('message', ''))

            # Try to extract error codes
            data['error_codes'] = self._extract_error_codes(data.get('message', ''))

            return data

        return None

    def _determine_severity(self, message: str) -> str:
        """Determine log severity from message content"""
        message_lower = message.lower()

        severity_patterns = {
            "EMERGENCY": ["emergency", "system is unusable"],
            "ALERT": ["alert", "immediate action"],
            "CRITICAL": ["critical", "crit "],
            "ERROR": ["error", "fail", "fatal", "exception"],
            "WARNING": ["warning", "warn "],
            "NOTICE": ["notice", "normal but significant"],
            "INFO": ["info ", "information", "starting", "stopping"],
            "DEBUG": ["debug", "trace"]
        }

        for severity, patterns in severity_patterns.items():
            for pattern in patterns:
                if pattern in message_lower:
                    return severity

        return "INFO"  # Default severity

    def _extract_error_codes(self, message: str) -> List[str]:
        """Extract error codes from message"""
        error_codes = []

        # Common error code patterns
        patterns = [
            r'error[_\s]?code[:\s]*(\d+)',
            r'errno[:\s]*(\d+)',
            r'status[:\s]*(\d+)',
            r'HTTP/\d\.\d\s+(\d{3})',
            r'returned\s+(-?\d+)'
        ]

        for pattern in patterns:
            matches = re.findall(pattern, message, re.IGNORECASE)
            error_codes.extend(matches)

        return error_codes

    def _generate_summary(self, entries: List[Dict]) -> Dict[str, Any]:
        """Generate summary of syslog entries"""
        if not entries:
            return {"error": "No entries parsed"}

        processes = {}
        severities = {}
        time_range = {}

        for entry in entries:
            # Count processes
            process = entry.get('process', 'unknown')
            processes[process] = processes.get(process, 0) + 1

            # Count severities
            severity = entry.get('severity', 'INFO')
            severities[severity] = severities.get(severity, 0) + 1

        # Get time range
        timestamps = [e.get('timestamp') for e in entries if e.get('timestamp')]

        return {
            "total_entries": len(entries),
            "processes_found": list(processes.keys()),
            "process_counts": processes,
            "severity_distribution": severities,
            "time_range": {
                "first": timestamps[0] if timestamps else None,
                "last": timestamps[-1] if timestamps else None
            }
        }