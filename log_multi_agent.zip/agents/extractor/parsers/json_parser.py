# agents/extractor/parsers/json_parser.py - Replace with this:

import json
from typing import Dict, Any, List, Optional
from datetime import datetime


class JSONParser:

    def parse(self, content: str) -> Dict[str, Any]:
        """Parse JSON log content. Returns entry_count=0 if not valid JSON."""
        if not content or not content.strip():
            return {"format": "json", "parsed": False, "error": "Empty content", "entry_count": 0}

        # Only try JSON if content looks like JSON
        stripped = content.strip()
        if not (stripped.startswith('{') or stripped.startswith('[')):
            return {"format": "json", "parsed": False, "error": "Content does not start with { or [", "entry_count": 0}

        try:
            data = json.loads(content)
            if isinstance(data, list):
                entry_count = len(data)
            elif isinstance(data, dict):
                # If dict has log entries, count those
                for key in ['logs', 'entries', 'records', 'data']:
                    if key in data and isinstance(data[key], list):
                        entry_count = len(data[key])
                        break
                else:
                    entry_count = 1
            else:
                entry_count = 1

            return {
                "format": "json",
                "parsed": True,
                "data": data,
                "type": self._determine_json_type(data),
                "entry_count": entry_count,
                "summary": self._generate_summary(data)
            }
        except json.JSONDecodeError as e:
            # Try JSON lines format
            return self._parse_json_lines(content)

    def _parse_json_lines(self, content: str) -> Dict[str, Any]:
        """Parse newline-delimited JSON. Only counts lines that are valid JSON."""
        lines = content.strip().split('\n')
        entries = []
        errors = []

        for i, line in enumerate(lines):
            line = line.strip()
            if not line:
                continue
            # Only try lines that look like JSON objects
            if line.startswith('{') or line.startswith('['):
                try:
                    entry = json.loads(line)
                    entries.append(entry)
                except json.JSONDecodeError:
                    errors.append({"line": i + 1, "content": line[:100]})

        return {
            "format": "json_lines",
            "parsed": len(entries) > 0,
            "data": entries,
            "entry_count": len(entries),
            "error_count": len(errors),
            "errors": errors[:10]
        }

    def _determine_json_type(self, data: Any) -> str:
        """Determine the type of JSON log"""
        if isinstance(data, list):
            if data and isinstance(data[0], dict):
                if 'timestamp' in data[0] or 'time' in data[0]:
                    return "structured_logs"
                elif 'level' in data[0] or 'severity' in data[0]:
                    return "log_entries"
            return "array"
        elif isinstance(data, dict):
            if 'logs' in data or 'entries' in data:
                return "log_container"
            elif 'error' in data:
                return "error_report"
            elif 'config' in data:
                return "configuration"
        return "generic_json"

    def _generate_summary(self, data: Any) -> Dict[str, Any]:
        """Generate summary of JSON log data"""
        summary = {
            "timestamp": datetime.now().isoformat(),
            "keys_found": [],
            "sample_entries": []
        }

        if isinstance(data, list):
            summary["total_entries"] = len(data)
            if data and isinstance(data[0], dict):
                summary["keys_found"] = list(data[0].keys())
                summary["sample_entries"] = data[:3]
        elif isinstance(data, dict):
            summary["keys_found"] = list(data.keys())
            for key in ['logs', 'entries', 'records']:
                if key in data and isinstance(data[key], list):
                    summary["total_entries"] = len(data[key])
                    summary["sample_entries"] = data[key][:3]
                    break

        return summary