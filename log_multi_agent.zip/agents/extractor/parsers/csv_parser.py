# agents/extractor/parsers/csv_parser.py
"""
CSV Log Parser - Parses CSV formatted logs
"""

import csv
import io
from typing import Dict, Any, List, Optional
from datetime import datetime
import re


class CSVParser:
    """Parser for CSV-formatted logs"""

    def __init__(self):
        self.common_delimiters = [',', ';', '\t', '|']
        self.max_sample_rows = 5

    def parse(self, content: str) -> Dict[str, Any]:
        """Parse CSV log content"""
        try:
            # Detect delimiter
            delimiter = self._detect_delimiter(content)

            # Parse CSV
            reader = csv.DictReader(io.StringIO(content), delimiter=delimiter)
            rows = list(reader)

            if not rows:
                # Try without headers
                rows = self._parse_without_headers(content, delimiter)
                return {
                    "format": "csv_no_headers",
                    "parsed": True,
                    "data": rows,
                    "row_count": len(rows),
                    "delimiter": delimiter,
                    "columns": [f"column_{i}" for i in range(len(rows[0]) if rows else 0)]
                }

            return {
                "format": "csv",
                "parsed": True,
                "data": rows,
                "row_count": len(rows),
                "delimiter": delimiter,
                "columns": list(rows[0].keys()) if rows else [],
                "summary": self._generate_summary(rows)
            }

        except Exception as e:
            return {
                "format": "csv",
                "parsed": False,
                "error": str(e),
                "entry_count": 0,
                "raw_content": content[:1000]  # First 1000 chars for debugging
            }

    def _detect_delimiter(self, content: str) -> str:
        """Detect the CSV delimiter by analyzing first few lines"""
        lines = content.strip().split('\n')
        if not lines:
            return ','

        # Count occurrences of each delimiter in first few lines
        sample_lines = lines[:min(10, len(lines))]
        delimiter_counts = {}

        for delimiter in self.common_delimiters:
            counts = [line.count(delimiter) for line in sample_lines if line.strip()]
            if counts:
                # Check if counts are consistent (same number of delimiters per line)
                if len(set(counts)) <= 2:  # Allow slight variation
                    delimiter_counts[delimiter] = max(counts)

        # Return delimiter with highest consistent count
        if delimiter_counts:
            return max(delimiter_counts, key=delimiter_counts.get)

        return ','  # Default to comma

    def _parse_without_headers(self, content: str, delimiter: str) -> List[Dict[str, Any]]:
        """Parse CSV that doesn't have headers"""
        reader = csv.reader(io.StringIO(content), delimiter=delimiter)
        rows = list(reader)

        if not rows:
            return []

        # Try to detect if first row could be headers
        first_row = rows[0]
        if self._could_be_headers(first_row, rows[1:] if len(rows) > 1 else []):
            # First row is likely headers
            headers = first_row
            data_rows = rows[1:]
        else:
            # Generate generic headers
            headers = [f"column_{i}" for i in range(len(first_row))]
            data_rows = rows

        # Convert to list of dicts
        result = []
        for row in data_rows:
            if row:  # Skip empty rows
                row_dict = {}
                for i, value in enumerate(row):
                    if i < len(headers):
                        row_dict[headers[i]] = value
                result.append(row_dict)

        return result

    def _could_be_headers(self, first_row: List[str], data_rows: List[List[str]]) -> bool:
        """Check if first row could be headers"""
        if not data_rows:
            return False

        # Headers often contain different types of data than values
        # Check if values in first row are all strings while later rows have numbers
        first_row_all_strings = all(
            not self._is_number(val) for val in first_row if val.strip()
        )

        if first_row_all_strings:
            # Check if any data rows have numbers
            for row in data_rows[:5]:
                if any(self._is_number(val) for val in row):
                    return True

        # Check common header patterns
        header_patterns = [
            r'timestamp?', r'time', r'date', r'level', r'severity',
            r'message', r'source', r'host', r'ip', r'status',
            r'error', r'code', r'id', r'name', r'type'
        ]

        for value in first_row:
            value_lower = value.lower().strip()
            for pattern in header_patterns:
                if re.match(pattern, value_lower, re.IGNORECASE):
                    return True

        return False

    def _is_number(self, value: str) -> bool:
        """Check if a string value is a number"""
        try:
            float(value.strip())
            return True
        except (ValueError, TypeError):
            return False

    def _generate_summary(self, rows: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate summary of CSV log data"""
        if not rows:
            return {"error": "No rows to summarize"}

        columns = list(rows[0].keys())

        # Analyze each column
        column_analysis = {}
        for col in columns:
            values = [row.get(col, '') for row in rows]
            non_empty = [v for v in values if v]

            analysis = {
                "non_empty_count": len(non_empty),
                "empty_count": len(values) - len(non_empty),
                "unique_values": len(set(str(v) for v in non_empty[:1000])),  # Limit for performance
                "sample_values": non_empty[:self.max_sample_rows]
            }

            # Detect data type
            if non_empty:
                if all(self._is_number(v) for v in non_empty[:100]):
                    analysis["likely_type"] = "numeric"
                elif all(self._is_timestamp(v) for v in non_empty[:100]):
                    analysis["likely_type"] = "timestamp"
                else:
                    analysis["likely_type"] = "text"

            column_analysis[col] = analysis

        return {
            "total_rows": len(rows),
            "total_columns": len(columns),
            "columns": columns,
            "column_analysis": column_analysis
        }

    def _is_timestamp(self, value: str) -> bool:
        """Check if value looks like a timestamp"""
        timestamp_patterns = [
            r'\d{4}-\d{2}-\d{2}',
            r'\d{2}/\d{2}/\d{4}',
            r'\d{2}:\d{2}:\d{2}',
            r'\w{3}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2}'
        ]

        value_str = str(value)
        return any(re.search(pattern, value_str) for pattern in timestamp_patterns)