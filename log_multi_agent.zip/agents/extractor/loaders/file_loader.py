# agents/extractor/loaders/file_loader.py
"""
File Loader - Handles reading logs from files
"""

from pathlib import Path
from typing import Dict, Any, Optional, Union
import json
import csv
import io
import logging

logger = logging.getLogger(__name__)


class FileLoader:
    """Loader for extracting logs from files"""

    SUPPORTED_ENCODINGS = ['utf-8', 'latin-1', 'ascii', 'utf-16']
    MAX_FILE_SIZE = 100 * 1024 * 1024  # 100MB limit

    def load_file(self, file_path: Union[str, Path]) -> Dict[str, Any]:
        """Load and parse a file"""
        file_path = Path(file_path)

        # Validate file
        validation = self._validate_file(file_path)
        if not validation["valid"]:
            return {"error": validation["error"]}

        # Detect file type
        file_type = self._detect_file_type(file_path)

        # Load based on type
        try:
            if file_type == 'json':
                content = self._load_json(file_path)
            elif file_type == 'csv':
                content = self._load_csv(file_path)
            elif file_type == 'xml':
                content = self._load_xml(file_path)
            elif file_type in ['log', 'text']:
                content = self._load_text(file_path)
            elif file_type == 'compressed':
                content = self._load_compressed(file_path)
            else:
                content = self._load_binary(file_path)

            return {
                "file_path": str(file_path),
                "file_type": file_type,
                "content": content,
                "metadata": {
                    "size": file_path.stat().st_size,
                    "encoding": validation.get("encoding"),
                    "line_count": self._count_lines(content)
                }
            }
        except Exception as e:
            logger.error(f"Failed to load file {file_path}: {str(e)}")
            return {"error": f"Failed to load file: {str(e)}"}

    def _validate_file(self, file_path: Path) -> Dict[str, Any]:
        """Validate file before loading"""
        if not file_path.exists():
            return {"valid": False, "error": f"File not found: {file_path}"}

        if not file_path.is_file():
            return {"valid": False, "error": f"Not a file: {file_path}"}

        # Check file size
        size = file_path.stat().st_size
        if size > self.MAX_FILE_SIZE:
            return {"valid": False, "error": f"File too large: {size / (1024 * 1024):.1f}MB (max: 100MB)"}

        if size == 0:
            return {"valid": False, "error": "File is empty"}

        # Detect encoding
        encoding = self._detect_encoding(file_path)

        return {"valid": True, "encoding": encoding}

    def _detect_encoding(self, file_path: Path) -> str:
        """Detect file encoding"""
        for encoding in self.SUPPORTED_ENCODINGS:
            try:
                with open(file_path, 'r', encoding=encoding) as f:
                    f.read(1024)  # Read sample
                return encoding
            except (UnicodeDecodeError, UnicodeError):
                continue
        return 'utf-8'  # Default fallback

    def _detect_file_type(self, file_path: Path) -> str:
        """Detect file type from extension and content"""
        extension = file_path.suffix.lower()

        type_map = {
            '.log': 'log',
            '.txt': 'text',
            '.json': 'json',
            '.csv': 'csv',
            '.xml': 'xml',
            '.gz': 'compressed',
            '.zip': 'compressed',
            '.tar': 'compressed',
        }

        return type_map.get(extension, 'binary')

    def _load_json(self, file_path: Path) -> Any:
        """Load JSON file"""
        encoding = self._detect_encoding(file_path)
        with open(file_path, 'r', encoding=encoding) as f:
            return json.load(f)

    def _load_csv(self, file_path: Path) -> list:
        """Load CSV file"""
        encoding = self._detect_encoding(file_path)
        rows = []
        with open(file_path, 'r', encoding=encoding) as f:
            reader = csv.DictReader(f)
            for row in reader:
                rows.append(row)
        return rows

    def _load_xml(self, file_path: Path) -> str:
        """Load XML file as text for parsing"""
        encoding = self._detect_encoding(file_path)
        with open(file_path, 'r', encoding=encoding) as f:
            return f.read()

    def _load_text(self, file_path: Path) -> str:
        """Load plain text file"""
        encoding = self._detect_encoding(file_path)
        with open(file_path, 'r', encoding=encoding) as f:
            return f.read()

    def _load_compressed(self, file_path: Path) -> str:
        """Load compressed file"""
        import gzip
        import zipfile

        if file_path.suffix == '.gz':
            with gzip.open(file_path, 'rt') as f:
                return f.read()
        elif file_path.suffix == '.zip':
            with zipfile.ZipFile(file_path, 'r') as zip_ref:
                # Return content of first file in zip
                first_file = zip_ref.namelist()[0]
                return zip_ref.read(first_file).decode('utf-8')

        return "Unsupported compressed format"

    def _load_binary(self, file_path: Path) -> bytes:
        """Load binary file"""
        with open(file_path, 'rb') as f:
            return f.read()

    def _count_lines(self, content: Any) -> int:
        """Count lines in content"""
        if isinstance(content, str):
            return len(content.splitlines())
        elif isinstance(content, list):
            return len(content)
        return 0

    def get_file_info(self, file_path: Path) -> Dict[str, Any]:
        """Get file information without loading content"""
        file_path = Path(file_path)
        if not file_path.exists():
            return {"error": "File not found"}

        return {
            "name": file_path.name,
            "path": str(file_path.absolute()),
            "size": file_path.stat().st_size,
            "modified": file_path.stat().st_mtime,
            "extension": file_path.suffix,
            "type": self._detect_file_type(file_path)
        }