# agents/extractor/loaders/image_loader.py
"""
Image Loader - Handles extracting text from images using OCR
"""

from pathlib import Path
from typing import Dict, Any, Optional, List
import logging
import base64
from io import BytesIO

logger = logging.getLogger(__name__)


class ImageLoader:
    """Loader for extracting text from images using OCR"""

    SUPPORTED_FORMATS = ['.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.webp']

    def __init__(self):
        self.ocr_model = None
        self.preprocessing_enabled = True

    async def initialize_ocr_model(self, model_manager):
        """Initialize the OCR model (DeepSeek OCR)"""
        try:
            self.ocr_model = await model_manager.load_model("deepseek_ocr")
            logger.info("OCR model loaded successfully")
        except Exception as e:
            logger.error(f"Failed to load OCR model: {str(e)}")

    async def extract_from_image(self, image_path: str) -> Dict[str, Any]:
        """Extract text from an image"""
        image_path = Path(image_path)

        # Validate image
        validation = self._validate_image(image_path)
        if not validation["valid"]:
            return {"error": validation["error"]}

        try:
            # Preprocess image if needed
            if self.preprocessing_enabled:
                processed_image = self._preprocess_image(image_path)
            else:
                processed_image = image_path

            # Perform OCR
            ocr_result = await self._perform_ocr(processed_image)

            return {
                "source": str(image_path),
                "format": image_path.suffix.lower(),
                "text": ocr_result.get("text", ""),
                "confidence": ocr_result.get("confidence", 0.0),
                "regions": ocr_result.get("regions", []),
                "metadata": {
                    "size": image_path.stat().st_size,
                    "resolution": self._get_image_resolution(image_path)
                }
            }
        except Exception as e:
            logger.error(f"OCR extraction failed: {str(e)}")
            return {"error": f"OCR extraction failed: {str(e)}"}

    def _validate_image(self, image_path: Path) -> Dict[str, Any]:
        """Validate image file"""
        if not image_path.exists():
            return {"valid": False, "error": f"Image not found: {image_path}"}

        if image_path.suffix.lower() not in self.SUPPORTED_FORMATS:
            return {
                "valid": False,
                "error": f"Unsupported format: {image_path.suffix}. Supported: {self.SUPPORTED_FORMATS}"
            }

        # Check if file is actually an image
        try:
            from PIL import Image
            img = Image.open(image_path)
            img.verify()
        except Exception as e:
            return {"valid": False, "error": f"Invalid image file: {str(e)}"}

        return {"valid": True}

    def _preprocess_image(self, image_path: Path) -> Path:
        """Preprocess image for better OCR"""
        try:
            from PIL import Image, ImageEnhance, ImageFilter

            img = Image.open(image_path)

            # Convert to grayscale
            if img.mode != 'L':
                img = img.convert('L')

            # Enhance contrast
            enhancer = ImageEnhance.Contrast(img)
            img = enhancer.enhance(2.0)

            # Apply sharpening
            img = img.filter(ImageFilter.SHARPEN)

            # Save preprocessed image
            preprocessed_path = image_path.parent / f"preprocessed_{image_path.name}"
            img.save(preprocessed_path)

            return preprocessed_path
        except ImportError:
            logger.warning("PIL not installed, skipping image preprocessing")
            return image_path

    async def _perform_ocr(self, image_path: Path) -> Dict[str, Any]:
        """Perform OCR on the image"""
        # This would integrate with DeepSeek OCR model
        # For demonstration, returning structure

        if self.ocr_model:
            # Actual OCR implementation would go here
            # result = await self.ocr_model.extract_text(image_path)
            pass

        # Simulated OCR result for now
        return {
            "text": "Sample extracted text from image",
            "confidence": 0.95,
            "regions": [
                {
                    "coordinates": [0, 0, 100, 50],
                    "text": "Sample region text",
                    "confidence": 0.95
                }
            ],
            "processing_time": 0.5
        }

    def _get_image_resolution(self, image_path: Path) -> Dict[str, int]:
        """Get image resolution"""
        try:
            from PIL import Image
            with Image.open(image_path) as img:
                return {"width": img.width, "height": img.height}
        except ImportError:
            return {"width": 0, "height": 0}

    def encode_image_base64(self, image_path: Path) -> str:
        """Encode image to base64 for API transfer"""
        with open(image_path, 'rb') as f:
            return base64.b64encode(f.read()).decode('utf-8')