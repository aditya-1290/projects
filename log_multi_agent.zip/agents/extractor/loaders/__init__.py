# agents/extractor/loaders/__init__.py
"""
Loaders for extracting data from different sources
"""

from .file_loader import FileLoader
from .image_loader import ImageLoader
from .terminal_loader import TerminalLoader

__all__ = ['FileLoader', 'ImageLoader', 'TerminalLoader']