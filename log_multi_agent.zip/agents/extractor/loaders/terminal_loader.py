# agents/extractor/loaders/terminal_loader.py
"""
Terminal Loader - Handles extracting logs from terminal commands with user permission
"""

import subprocess
import asyncio
import re
from typing import Dict, Any, Optional, List, Tuple
from pathlib import Path
import logging
from enum import Enum

logger = logging.getLogger(__name__)


class PermissionLevel(Enum):
    READ_ONLY = "read_only"
    READ_EXECUTE = "read_execute"
    FULL_ACCESS = "full_access"
    DENIED = "denied"


class TerminalLoader:
    """Loader for extracting logs from terminal with user permission"""

    # Command categories with their risk levels
    COMMAND_CATEGORIES = {
        "safe_read": {
            "risk": "low",
            "description": "Read-only commands",
            "commands": ["cat", "head", "tail", "less", "grep", "awk", "sed",
                         "sort", "uniq", "wc", "find", "ls", "stat", "file"],
            "permission_required": PermissionLevel.READ_ONLY
        },
        "system_info": {
            "risk": "medium",
            "description": "System information commands",
            "commands": ["ps", "top", "df", "du", "free", "uptime", "who",
                         "last", "journalctl", "dmesg"],
            "permission_required": PermissionLevel.READ_EXECUTE
        },
        "network": {
            "risk": "medium",
            "description": "Network-related commands",
            "commands": ["netstat", "ss", "ifconfig", "ip", "ping", "traceroute"],
            "permission_required": PermissionLevel.READ_EXECUTE
        },
        "restricted": {
            "risk": "high",
            "description": "Potentially dangerous commands",
            "commands": ["kill", "killall", "reboot", "shutdown", "rm",
                         "mv", "cp", "dd", "chmod", "chown"],
            "permission_required": PermissionLevel.FULL_ACCESS
        }
    }

    def __init__(self):
        self.permission_cache: Dict[str, PermissionLevel] = {}
        self.command_history: List[Dict[str, Any]] = []
        self.max_history = 100
        self.timeout = 10  # Default timeout for commands
        self.allowed_paths: List[str] = []  # Paths user has granted access to

    async def execute_with_permission(self, command: str,
                                      working_dir: str = None,
                                      env_vars: Dict[str, str] = None) -> Dict[str, Any]:
        """Execute a terminal command with proper permission checks"""

        # Step 1: Parse and validate the command
        command_validation = self._validate_command(command)
        if not command_validation["valid"]:
            return {
                "success": False,
                "error": command_validation["error"],
                "requires_permission": False
            }

        # Step 2: Check if permission is needed
        permission_info = self._check_permission_required(command)

        # Step 3: Request permission if needed
        if permission_info["required"]:
            permission = await self._request_user_permission(
                command,
                permission_info["category"],
                permission_info["risk_level"]
            )

            if not permission["granted"]:
                return {
                    "success": False,
                    "error": f"Permission denied: {permission['reason']}",
                    "requires_permission": True,
                    "permission_granted": False
                }

            # Cache the permission if user allowed
            if permission.get("cache_permission"):
                self._cache_permission(command, permission_info["category"])

        # Step 4: Sanitize and execute the command
        sanitized_command = self._sanitize_command(command)

        try:
            result = await self._execute_command(
                sanitized_command,
                working_dir,
                env_vars
            )

            # Log command to history
            self._add_to_history(command, result)

            return result

        except Exception as e:
            logger.error(f"Command execution failed: {str(e)}")
            return {
                "success": False,
                "error": f"Command execution failed: {str(e)}",
                "command": command
            }

    def _validate_command(self, command: str) -> Dict[str, Any]:
        """Validate the command before execution"""
        if not command or not command.strip():
            return {"valid": False, "error": "Empty command"}

        # Extract the base command
        base_command = command.split()[0] if command.split() else ""

        # Check for dangerous patterns
        dangerous_patterns = [
            r'rm\s+-rf\s+/',  # Recursive force remove root
            r'>\s*/dev/sda',  # Writing to disk directly
            r'mkfs\.',  # Formatting
            r'dd\s+if=',  # Disk duplicating
            r'chmod\s+777',  # World-writable permissions
            r':\(\)\s*\{',  # Fork bomb
            r'wget.*\|.*sh',  # Piping to shell
            r'curl.*\|.*sh',  # Piping to shell
        ]

        for pattern in dangerous_patterns:
            if re.search(pattern, command):
                return {
                    "valid": False,
                    "error": f"Command blocked for security reasons. Dangerous pattern detected."
                }

        return {"valid": True, "base_command": base_command}

    def _check_permission_required(self, command: str) -> Dict[str, Any]:
        """Check what level of permission is required for the command"""
        base_command = command.split()[0] if command.split() else ""

        # Check if already cached
        if base_command in self.permission_cache:
            return {
                "required": False,
                "category": "cached",
                "risk_level": "cached",
                "cached_permission": self.permission_cache[base_command]
            }

        # Check command categories
        for category, info in self.COMMAND_CATEGORIES.items():
            if base_command in info["commands"]:
                return {
                    "required": True,
                    "category": category,
                    "risk_level": info["risk"],
                    "permission_level": info["permission_required"],
                    "description": info["description"]
                }

        # Unknown command - require full access
        return {
            "required": True,
            "category": "unknown",
            "risk_level": "high",
            "permission_level": PermissionLevel.FULL_ACCESS,
            "description": "Unknown command"
        }

    async def _request_user_permission(self, command: str,
                                       category: str,
                                       risk_level: str) -> Dict[str, Any]:
        """Request permission from the user with detailed information"""

        print("\n" + "=" * 60)
        print("🔐 PERMISSION REQUIRED - Terminal Access Request")
        print("=" * 60)
        print(f"\n📌 Command: {command}")
        print(f"📂 Category: {category.replace('_', ' ').title()}")
        print(f"⚠️  Risk Level: {risk_level.upper()}")

        # Provide context about what the command does
        command_explanation = self._explain_command(command)
        if command_explanation:
            print(f"\n📖 What this command does:")
            print(f"   {command_explanation}")

        # Show what the agent wants to do
        print(f"\n🎯 Purpose: Extract log data for analysis")
        print(f"   This command will help identify and collect relevant log information")

        # Permission options
        print("\n" + "-" * 40)
        print("Permission Options:")
        print("  1. [y] Yes - Allow this command once")
        print("  2. [a] Allow All - Trust all commands from this agent")
        print("  3. [s] Safe Mode - Only allow read-only commands")
        print("  4. [p] Path Only - Allow access to specific path")
        print("  5. [n] No - Deny this command")
        print("-" * 40)

        # Get user input with timeout
        try:
            response = await self._get_user_input_with_timeout(
                "Enter your choice (y/a/s/p/n): ",
                timeout=30
            )
        except TimeoutError:
            print("\n⏰ Permission request timed out. Command denied.")
            return {"granted": False, "reason": "Timeout"}

        response = response.lower().strip()

        if response in ['y', 'yes']:
            print("✅ Permission granted for this command.")
            return {"granted": True, "cache_permission": False}

        elif response in ['a', 'allow', 'all']:
            print("✅ Full access granted for this agent.")
            return {"granted": True, "cache_permission": True}

        elif response in ['s', 'safe']:
            if risk_level == "low":
                print("✅ Read-only permission granted.")
                return {"granted": True, "cache_permission": True}
            else:
                print("❌ This command requires higher privileges than safe mode allows.")
                return {"granted": False, "reason": "Safe mode insufficient"}

        elif response in ['p', 'path']:
            path = input("Enter the allowed path: ").strip()
            if path:
                self.allowed_paths.append(path)
                print(f"✅ Access granted for path: {path}")
                return {"granted": True, "cache_permission": False}
            else:
                print("❌ No path specified.")
                return {"granted": False, "reason": "No path specified"}

        elif response in ['n', 'no']:
            print("❌ Permission denied by user.")
            return {"granted": False, "reason": "User denied"}

        else:
            print("❌ Invalid response. Command denied.")
            return {"granted": False, "reason": "Invalid response"}

    async def _get_user_input_with_timeout(self, prompt: str, timeout: int = 30) -> str:
        """Get user input with timeout"""
        try:
            # Use asyncio to wait for input with timeout
            loop = asyncio.get_event_loop()
            user_input = await loop.run_in_executor(None, input, prompt)
            return user_input
        except Exception:
            raise TimeoutError("Input timeout")

    def _explain_command(self, command: str) -> Optional[str]:
        """Provide a human-readable explanation of the command"""
        explanations = {
            "cat": "Display file contents",
            "grep": "Search for patterns in text",
            "tail": "Display the last part of a file",
            "head": "Display the first part of a file",
            "journalctl": "Query the systemd journal",
            "dmesg": "Print kernel ring buffer messages",
            "ps": "Report process status",
            "top": "Display system tasks",
            "df": "Report file system disk space usage",
            "du": "Estimate file space usage",
            "netstat": "Network statistics",
            "ss": "Socket statistics",
            "awk": "Pattern scanning and processing",
            "sed": "Stream editor for filtering text",
            "sort": "Sort lines of text files",
            "uniq": "Report or omit repeated lines",
            "wc": "Print line, word, and byte counts",
            "find": "Search for files in directory hierarchy",
            "ls": "List directory contents",
        }

        base_command = command.split()[0]
        return explanations.get(base_command)

    def _sanitize_command(self, command: str) -> str:
        """Sanitize the command to prevent injection attacks"""
        # Remove any command chaining operators for safety
        dangerous_operators = [';', '&&', '||', '`', '$(']

        sanitized = command
        for op in dangerous_operators:
            if op in sanitized:
                logger.warning(f"Removing dangerous operator '{op}' from command")
                sanitized = sanitized.split(op)[0]

        return sanitized.strip()

    async def _execute_command(self, command: str,
                               working_dir: str = None,
                               env_vars: Dict[str, str] = None) -> Dict[str, Any]:
        """Execute the sanitized command"""
        try:
            # Prepare environment
            import os
            env = os.environ.copy()
            if env_vars:
                env.update(env_vars)

            # Execute command
            process = await asyncio.create_subprocess_shell(
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=working_dir,
                env=env
            )

            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(),
                    timeout=self.timeout
                )
            except asyncio.TimeoutError:
                process.kill()
                await process.wait()
                return {
                    "success": False,
                    "error": f"Command timed out after {self.timeout} seconds",
                    "command": command
                }

            stdout_text = stdout.decode('utf-8', errors='replace')
            stderr_text = stderr.decode('utf-8', errors='replace')

            return {
                "success": process.returncode == 0,
                "command": command,
                "stdout": stdout_text,
                "stderr": stderr_text,
                "return_code": process.returncode,
                "execution_time": self.timeout  # Would be actual timing in production
            }

        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "command": command
            }

    def _cache_permission(self, command: str, category: str):
        """Cache user permission for future commands"""
        base_command = command.split()[0]

        if category in self.COMMAND_CATEGORIES:
            permission_level = self.COMMAND_CATEGORIES[category]["permission_required"]
        else:
            permission_level = PermissionLevel.READ_ONLY

        self.permission_cache[base_command] = permission_level
        logger.info(f"Cached permission for {base_command}: {permission_level}")

    def _add_to_history(self, command: str, result: Dict[str, Any]):
        """Add command to execution history"""
        entry = {
            "command": command,
            "timestamp": asyncio.get_event_loop().time(),
            "success": result.get("success", False),
            "return_code": result.get("return_code")
        }

        self.command_history.append(entry)

        # Trim history if too large
        if len(self.command_history) > self.max_history:
            self.command_history = self.command_history[-self.max_history:]

    def get_command_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Get recent command history"""
        return self.command_history[-limit:]

    def clear_permissions(self):
        """Clear all cached permissions"""
        self.permission_cache.clear()
        self.allowed_paths.clear()
        logger.info("All permissions cleared")

    def get_permission_status(self) -> Dict[str, Any]:
        """Get current permission status"""
        return {
            "cached_commands": list(self.permission_cache.keys()),
            "allowed_paths": self.allowed_paths,
            "total_commands_executed": len(self.command_history)
        }

    # Convenience methods for common log extraction tasks
    async def extract_logs_from_system(self, log_type: str = "all") -> Dict[str, Any]:
        """Extract system logs with appropriate commands"""
        commands = {
            "syslog": "tail -n 100 /var/log/syslog",
            "auth": "tail -n 100 /var/log/auth.log",
            "kern": "dmesg | tail -n 100",
            "systemd": "journalctl -n 100 --no-pager",
            "all": "tail -n 100 /var/log/syslog; echo '---'; dmesg | tail -n 100"
        }

        command = commands.get(log_type, commands["all"])
        return await self.execute_with_permission(command)

    async def tail_file(self, file_path: str, lines: int = 100) -> Dict[str, Any]:
        """Tail a log file with specified lines"""
        command = f"tail -n {lines} {file_path}"
        return await self.execute_with_permission(command)

    async def search_logs(self, pattern: str, file_path: str = "/var/log/syslog") -> Dict[str, Any]:
        """Search for pattern in log files"""
        command = f"grep -i '{pattern}' {file_path} | tail -n 100"
        return await self.execute_with_permission(command)