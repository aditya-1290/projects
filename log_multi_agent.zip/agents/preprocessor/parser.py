# agents/preprocessor/parser.py
"""
Log Parser - Parses and structures log entries
"""

import re
from typing import Dict, Any, List, Optional
from datetime import datetime
import json


class LogParser:
    """Parses log entries into structured format"""

    def __init__(self):
        self.format_patterns = {
            'syslog': {
                'pattern': r'^(\w{3}\s+\d+\s+\d{2}:\d{2}:\d{2})\s+(\S+)\s+(\S+?)(?:\[(\d+)\])?:\s+(.+)$',
                'fields': ['timestamp', 'hostname', 'process', 'pid', 'message']
            },
            'apache_access': {
                'pattern': r'^(\S+)\s+(\S+)\s+(\S+)\s+\[([^\]]+)\]\s+"(\S+)\s+(\S+)\s+(\S+)"\s+(\d+)\s+(\S+)',
                'fields': ['ip', 'identd', 'user', 'timestamp', 'method', 'url', 'protocol', 'status', 'size']
            },
            'mysql_error': {
                'pattern': r'^(\d{6}\s+\d{1,2}:\d{2}:\d{2})\s+(\S+)\s+(\w+)\s+(.+)$',
                'fields': ['timestamp', 'thread_id', 'level', 'message']
            },
            'python_traceback': {
                'pattern': r'^Traceback \(most recent call last\):',
                'is_multiline': True
            }
        }

    def detect_log_format(self, content: str) -> Dict[str, Any]:
        """Detect the format of the log content"""
        if not content:
            return {"type": "unknown", "confidence": 0.0}

        # Sample first few lines for detection
        lines = content.strip().split('\n')[:10]

        format_scores = {}

        # Test each format
        for format_name, format_info in self.format_patterns.items():
            if 'pattern' in format_info:
                pattern = re.compile(format_info['pattern'])
                matches = 0
                for line in lines:
                    if pattern.match(line):
                        matches += 1

                if matches > 0:
                    format_scores[format_name] = matches / len(lines)

        # Check for JSON format
        try:
            json.loads(content)
            format_scores['json'] = 1.0
        except:
            pass

        # Check for CSV format
        if ',' in lines[0] and len(lines[0].split(',')) > 1:
            format_scores['csv'] = 0.8

        if not format_scores:
            return {"type": "plain_text", "confidence": 0.5}

        best_format = max(format_scores, key=format_scores.get)
        return {
            "type": best_format,
            "confidence": format_scores[best_format],
            "is_structured": best_format != "plain_text",
            "alternative_formats": format_scores
        }

    def parse_to_entries(self, content: str, format_info: Dict) -> List[str]:
        """Parse content into individual log entries"""
        lines = content.strip().split('\n')

        if format_info.get('type') == 'python_traceback':
            # Group traceback lines together
            entries = []
            current_entry = []

            for line in lines:
                if line.startswith('Traceback'):
                    if current_entry:
                        entries.append('\n'.join(current_entry))
                    current_entry = [line]
                elif line.strip() and not line.startswith(' '):
                    if current_entry:
                        entries.append('\n'.join(current_entry))
                    current_entry = [line]
                else:
                    current_entry.append(line)

            if current_entry:
                entries.append('\n'.join(current_entry))

            return entries

        # For structured formats, each line is an entry
        return [line for line in lines if line.strip()]

    def extract_key_fields(self, entry: str, format_info: Dict) -> Dict[str, Any]:
        """Extract key fields from a log entry"""
        format_type = format_info.get('type', 'plain_text')

        result = {
            "raw": entry,
            "timestamp": self._extract_timestamp(entry),
            "level": self._extract_log_level(entry),
            "component": self._extract_component(entry),
            "message": entry
        }

        # Format-specific extraction
        if format_type in self.format_patterns and 'pattern' in self.format_patterns[format_type]:
            pattern_info = self.format_patterns[format_type]
            match = re.match(pattern_info['pattern'], entry)

            if match:
                for i, field in enumerate(pattern_info['fields'], 1):
                    result[field] = match.group(i)
                    if field == 'message':
                        result['message'] = match.group(i)

        # Extract additional fields
        result['has_stack_trace'] = self._has_stack_trace(entry)
        result['error_codes'] = self._extract_error_codes(entry)
        result['ip_addresses'] = self._extract_ip_addresses(entry)

        return result

    def _extract_timestamp(self, entry: str) -> Optional[str]:
        """Extract timestamp from log entry"""
        # Common timestamp patterns
        patterns = [
            r'\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}[.,\d]*Z?',
            r'\d{2}/\d{2}/\d{4}\s+\d{2}:\d{2}:\d{2}',
            r'\w{3}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2}',
            r'\d{6}\s+\d{1,2}:\d{2}:\d{2}',
            r'\[(\d{2}/\w{3}/\d{4}:\d{2}:\d{2}:\d{2}\s+[+-]\d{4})\]'
        ]

        for pattern in patterns:
            match = re.search(pattern, entry)
            if match:
                return match.group(0) if not match.groups() else match.group(1)

        return None

    def _extract_log_level(self, entry: str) -> str:
        """Extract log level from entry"""
        levels = ['CRITICAL', 'FATAL', 'ERROR', 'WARN', 'WARNING',
                  'INFO', 'DEBUG', 'TRACE', 'NOTICE', 'ALERT', 'EMERGENCY']

        entry_upper = entry.upper()
        for level in levels:
            if re.search(r'\b' + level + r'\b', entry_upper):
                return level

        # Check for level in brackets
        match = re.search(r'\[(\w+)\]', entry)
        if match and match.group(1).upper() in levels:
            return match.group(1).upper()

        return 'UNKNOWN'

    def _extract_component(self, entry: str) -> Optional[str]:
        """Extract component/service name from entry"""
        # Common component patterns
        patterns = [
            r'^(\S+?)(?:\[|:|\.)',
            r'(?:from|in|at)\s+(\S+?)(?:\s+|\.py)',
            r'^\[(\S+?)\]',
        ]

        for pattern in patterns:
            match = re.search(pattern, entry)
            if match:
                return match.group(1)

        return 'unknown'

    def _has_stack_trace(self, entry: str) -> bool:
        """Check if entry contains a stack trace"""
        stack_indicators = [
            'Traceback',
            'at ',
            'File "',
            'line \d+',
            'Exception:',
            'Error:',
            'Caused by:'
        ]

        return any(re.search(indicator, entry) for indicator in stack_indicators)

    def _extract_error_codes(self, entry: str) -> List[str]:
        """Extract error codes from entry"""
        patterns = [
            r'error[_\s]?code:?\s*(\w+\d*)',
            r'status[_\s]?code:?\s*(\d+)',
            r'HTTP\s+(\d{3})',
            r'errno:?\s*(\d+)',
            r'exit[_\s]?code:?\s*(\d+)',
        ]

        codes = []
        for pattern in patterns:
            matches = re.findall(pattern, entry, re.IGNORECASE)
            codes.extend(matches)

        return codes

    def _extract_ip_addresses(self, entry: str) -> List[str]:
        """Extract IP addresses from entry"""
        ip_pattern = r'\b(?:\d{1,3}\.){3}\d{1,3}\b'
        return re.findall(ip_pattern, entry)