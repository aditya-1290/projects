# agents/preprocessor/agent.py
"""
Preprocessor Agent - Uses Qwen model to intelligently clean, chunk, normalize, and parse log data.

Model: Qwen-2.5-3B (with fallback to built-in tools if model unavailable)
Features:
- Cleans: removes noise, duplicates, PII, encoding fixes
- Chunks: only if > 4000 tokens (small files preserved)
- Normalizes: timestamps, log levels, hostnames, field names
- Parses: JSON, CSV, XML, Syslog, Apache, plain text
"""

from typing import Dict, Any, List, Optional
import logging
from datetime import datetime
import asyncio
import json
import re

from agents.base_agent import BaseAgent, A2AMessage, MessageType, AgentState

logger = logging.getLogger(__name__)


class PreprocessorAgent(BaseAgent):
    """
    Preprocessor agent that uses Qwen model to intelligently process log data.
    Falls back to built-in tools when model is unavailable.
    """

    def __init__(self, agent_id: str = "preprocessor", capability_path: str = None, config=None, **kwargs):
        """Initialize preprocessor agent."""
        if hasattr(agent_id, 'agent_id') and hasattr(agent_id, 'capabilities'):
            config = agent_id
            agent_id = config.agent_id if hasattr(config, 'agent_id') else "preprocessor"
            if capability_path is None:
                capability_path = getattr(config, 'capability_path', None)
        elif config is not None:
            agent_id = config.agent_id if hasattr(config, 'agent_id') else "preprocessor"
            if capability_path is None:
                capability_path = getattr(config, 'capability_path', None)

        if capability_path is None:
            from pathlib import Path
            default_path = Path(__file__).parent / "capabilities.json"
            if default_path.exists():
                capability_path = str(default_path)

        super().__init__(agent_id=agent_id, capability_path=capability_path)

        self.processing_stats = {
            "total_processed": 0,
            "total_cleaned": 0,
            "total_chunked": 0,
            "total_normalized": 0
        }

    def get_system_prompt(self) -> str:
        """Define the preprocessor's persona and capabilities."""
        return """
        You are an expert log preprocessing agent. Clean and structure this log data.

        Remove: empty lines, duplicates, control characters, ANSI codes
        Mask: emails, IPs, API keys, passwords, tokens (replace with [REDACTED])
        Fix: encoding issues, garbled text
        Preserve: all log entries, timestamps, error messages, stack traces

        Return ONLY valid JSON with this structure:
        {
            "cleaned_content": "the cleaned text here",
            "operations_performed": ["removed X empty lines", "masked Y PII instances"],
            "total_lines": 123,
            "issues_found": []
        }
        """

    # ============================================
    # Main Process Method
    # ============================================

    async def process(self, message: A2AMessage) -> A2AMessage:
        """Process incoming A2A message for log preprocessing."""

        # Handle capability queries
        if message.task and message.task.get("action") == "report_capabilities":
            return A2AMessage(
                message_type=MessageType.RESPONSE,
                sender_id=self.agent_id,
                sender_type=self.capability.agent_name,
                target_id=message.sender_id,
                correlation_id=message.message_id,
                response=self.capability.to_dict(),
                confidence=1.0
            )

        task = message.task or {}

        try:
            self.state = AgentState.PROCESSING

            task_input = {
                "input": task.get("input", task),
                "parameters": task.get("parameters", {}),
                "context": message.context or {}
            }

            result = await self.process_task(task_input)

            self.state = AgentState.IDLE

            return A2AMessage(
                message_type=MessageType.RESPONSE,
                sender_id=self.agent_id,
                sender_type=self.capability.agent_name,
                target_id=message.sender_id,
                correlation_id=message.message_id,
                response=result,
                confidence=result.get("confidence", 0.85)
            )

        except Exception as e:
            self.state = AgentState.ERROR
            logger.error(f"[PREPROCESSOR] Error: {e}", exc_info=True)
            return A2AMessage(
                message_type=MessageType.ERROR,
                sender_id=self.agent_id,
                sender_type=self.capability.agent_name,
                target_id=message.sender_id,
                correlation_id=message.message_id,
                error=str(e)
            )

    # ============================================
    # Core Preprocessing Logic
    # ============================================

    async def process_task(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """
        Preprocess log data using Qwen model with fallback to built-in tools.

        Pipeline: Clean → Token Check → Chunk (if >4000) → Normalize → Parse
        """
        raw_data = task.get("input", {})

        # Extract content from multiple possible locations
        raw_content = (
                raw_data.get("raw_content") or
                raw_data.get("content") or
                raw_data.get("text") or
                ""
        )

        # Also check if extractor already parsed the data
        parsed_data = raw_data.get("data")
        detected_format = raw_data.get("format", "unknown")

        if not raw_content and not parsed_data:
            return {
                "success": False,
                "error": "No content to preprocess",
                "agent_id": self.agent_id
            }

        # If extractor parsed data, extract the raw text from it
        if parsed_data and isinstance(parsed_data, dict):
            if not raw_content:
                raw_content = json.dumps(parsed_data)
            # Extract log entries from parsed data
            entries_list = parsed_data.get("entries", parsed_data.get("data", []))
            if isinstance(entries_list, list):
                raw_content = "\n".join([str(e) for e in entries_list])

        logger.info(f"[PREPROCESSOR] Input: format={detected_format}, "
                    f"length={len(str(raw_content))}, "
                    f"has_parsed_data={parsed_data is not None}")

        try:
            # ⭐ STEP 1: CLEAN - Try Qwen first, fall back to built-in
            cleaned_content, cleaning_ops = await self._clean_with_qwen(str(raw_content))

            # ⭐ STEP 2: Token check
            token_count = self._estimate_tokens(cleaned_content)
            needs_chunking = token_count > 4000

            logger.info(f"[PREPROCESSOR] Tokens: {token_count}, needs_chunking: {needs_chunking}")

            # ⭐ STEP 3: Chunk if needed
            chunks = None
            chunk_count = 1
            if needs_chunking:
                chunks = await self._chunk_content(cleaned_content, token_count)
                chunk_count = len(chunks) if chunks else 1
                logger.info(f"[PREPROCESSOR] Chunked into {chunk_count} chunks")
            else:
                logger.info(f"[PREPROCESSOR] Small file ({token_count} < 4000 tokens) - NO chunking")

            # ⭐ STEP 4: Normalize entries
            normalized_entries = self._normalize_entries(cleaned_content, detected_format, parsed_data)

            # ⭐ STEP 5: Classify log type
            log_type = self._classify_log_type(cleaned_content, detected_format)

            # ⭐ Build result (ensure analyzer can use it)
            result = {
                "success": True,
                "agent_id": self.agent_id,

                # Content for next agents
                "cleaned_content": cleaned_content,
                "raw_content": cleaned_content,

                # Normalized entries for analyzer
                "normalized_data": normalized_entries,
                "entries": normalized_entries,

                # Statistics
                "token_estimate": token_count,
                "was_chunked": needs_chunking,
                "chunk_count": chunk_count,
                "chunks": chunks if needs_chunking else None,
                "total_entries_processed": len(normalized_entries),

                # Classification
                "detected_format": detected_format,
                "log_type": log_type,
                "classification": log_type,

                # Operations summary
                "cleaning_operations": cleaning_ops,
                "processing_summary": (
                    f"Preprocessed {token_count} tokens: "
                    f"{'chunked into ' + str(chunk_count) + ' chunks' if needs_chunking else 'no chunking needed (< 4000 tokens)'}. "
                    f"Format: {detected_format}. Type: {log_type}."
                ),

                "confidence": 0.85,
                "processed_at": datetime.now().isoformat()
            }

            self.processing_stats["total_processed"] += 1
            logger.info(f"[PREPROCESSOR] Done: {result['processing_summary']}")

            return result

        except Exception as e:
            logger.error(f"[PREPROCESSOR] Error: {e}", exc_info=True)
            # Emergency fallback - pass raw content through
            lines = str(raw_content).splitlines()
            basic_entries = [{"raw": line, "message": line} for line in lines if line.strip()]

            return {
                "success": True,
                "agent_id": self.agent_id,
                "cleaned_content": str(raw_content),
                "raw_content": str(raw_content),
                "normalized_data": basic_entries,
                "entries": basic_entries,
                "total_entries_processed": len(basic_entries),
                "token_estimate": self._estimate_tokens(str(raw_content)),
                "was_chunked": False,
                "chunk_count": 1,
                "detected_format": detected_format,
                "log_type": "unknown",
                "classification": "unknown",
                "cleaning_operations": [f"Emergency fallback: {str(e)[:100]}"],
                "processing_summary": f"Emergency fallback processing",
                "confidence": 0.5,
                "warning": str(e)[:200]
            }

    # ============================================
    # STEP 1: Clean with Qwen
    # ============================================

    # agents/preprocessor/agent.py - Replace _clean_with_qwen with this:

    async def _clean_with_qwen(self, content: str) -> tuple:
        """
        Clean content using Qwen model with SHORT timeout.
        Falls back to built-in cleaner if model is slow.
        """
        # Check if model is actually available
        if self.model is None or isinstance(self.model, dict):
            logger.info(f"[PREPROCESSOR] No model, using built-in cleaner")
            return self._builtin_clean(content)

        # ⭐ Use a MUCH shorter timeout (5 seconds) for cleaning
        # Cleaning is a simple task - if it takes longer, built-in is faster
        try:
            logger.info(f"[PREPROCESSOR] Attempting Qwen cleaning...")

            # ⭐ Send a simpler, shorter prompt
            prompt_data = {
                "task": "clean",
                "content": content[:1500],  # Only send first 1500 chars
                "total_length": len(content),
                "instructions": "Clean this: remove duplicates, empty lines, fix encoding. Return JSON with 'cleaned_content'."
            }

            response = await asyncio.wait_for(
                self.think(prompt_data),
                timeout=5  # ⭐ 5 seconds max (was 20s)
            )

            if response and not response.startswith("[") and len(response) > 20:
                json_data = self._extract_json(response)
                if json_data and "cleaned_content" in json_data:
                    ops = json_data.get("operations_performed", ["Qwen cleaning applied"])
                    logger.info(f"[PREPROCESSOR] Qwen cleaning SUCCESS")
                    return json_data["cleaned_content"], ops

            logger.warning(f"[PREPROCESSOR] Qwen response invalid, using built-in")

        except asyncio.TimeoutError:
            logger.info(f"[PREPROCESSOR] Qwen cleaning timed out (5s) - using built-in which is faster")
        except Exception as e:
            logger.warning(f"[PREPROCESSOR] Qwen error: {e}")

        # ⭐ Use built-in cleaner (instant)
        return self._builtin_clean(content)

    def _extract_json(self, text: str) -> Optional[Dict]:
        """Extract JSON from model response."""
        # Try direct parse
        try:
            return json.loads(text)
        except:
            pass

        # Try to find JSON block
        json_patterns = [
            r'```json\s*(\{.*?\})\s*```',
            r'```\s*(\{.*?\})\s*```',
            r'(\{[^{}]*"cleaned_content"[^{}]*\})',
            r'(\{.*\})',
        ]

        for pattern in json_patterns:
            match = re.search(pattern, text, re.DOTALL)
            if match:
                try:
                    return json.loads(match.group(1))
                except:
                    continue

        return None

    def _builtin_clean(self, content: str) -> tuple:
        """Built-in cleaning when model is unavailable."""
        operations = []
        cleaned = content

        # Remove null bytes and control characters
        cleaned = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', cleaned)

        # Remove ANSI color codes
        cleaned = re.sub(r'\x1b\[[0-9;]*m', '', cleaned)

        # Remove empty lines
        lines = cleaned.splitlines()
        non_empty = [l for l in lines if l.strip()]
        empty_removed = len(lines) - len(non_empty)
        if empty_removed > 0:
            operations.append(f"Removed {empty_removed} empty lines")
            cleaned = '\n'.join(non_empty)

        # Remove duplicates
        seen = set()
        unique = []
        dupes = 0
        for line in cleaned.splitlines():
            fingerprint = re.sub(r'\d+', 'N', line)
            if fingerprint not in seen:
                seen.add(fingerprint)
                unique.append(line)
            else:
                dupes += 1

        if dupes > 0:
            operations.append(f"Removed {dupes} duplicate lines")
            cleaned = '\n'.join(unique)

        # Mask PII
        pii_count = 0
        pii_patterns = {
            'EMAIL': r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',
            'IP': r'\b(?:\d{1,3}\.){3}\d{1,3}\b',
            'API_KEY': r'(?i)(api[_-]?key|token|secret|password)[\s:=]+([^\s]{8,})',
        }

        for pii_type, pattern in pii_patterns.items():
            matches = re.findall(pattern, cleaned)
            for match in matches:
                if isinstance(match, tuple):
                    match = match[-1]
                if match in cleaned:
                    cleaned = cleaned.replace(match, f'[REDACTED_{pii_type}]')
                    pii_count += 1

        if pii_count > 0:
            operations.append(f"Masked {pii_count} PII instances")

        if not operations:
            operations.append("No cleaning needed")

        logger.info(f"[PREPROCESSOR] Built-in cleaning: {operations}")
        return cleaned, operations

    # ============================================
    # STEP 2 & 3: Token Estimation & Chunking
    # ============================================

    def _estimate_tokens(self, text: str) -> int:
        """Estimate token count."""
        if not text:
            return 0
        words = len(text.split())
        chars = len(text)
        return int((words * 1.3 + chars / 4) / 2)

    async def _chunk_content(self, content: str, token_count: int) -> List[Dict[str, Any]]:
        """Chunk content into manageable pieces."""
        from agents.preprocessor.chunker import LogChunker
        chunker = LogChunker()

        lines = content.splitlines()
        entries_per_chunk = max(50, min(200, len(lines) // max(1, token_count // 4000)))

        return chunker.create_chunks(lines, chunk_size=entries_per_chunk)

    # ============================================
    # STEP 4: Normalize
    # ============================================

    def _normalize_entries(self, content: str, detected_format: str, parsed_data: Any) -> List[Dict]:
        """Normalize log entries into consistent format."""

        from agents.preprocessor.normalizer import LogNormalizer
        normalizer = LogNormalizer()

        # Use parsed data from extractor if available
        if parsed_data:
            if isinstance(parsed_data, dict):
                entries = parsed_data.get("entries", parsed_data.get("data", []))
                if isinstance(entries, list) and entries:
                    return normalizer.normalize_for_storage(entries[:500])
                # Single entry
                return normalizer.normalize_for_storage([parsed_data])
            elif isinstance(parsed_data, list):
                return normalizer.normalize_for_storage(parsed_data[:500])

        # Parse from raw content
        from agents.preprocessor.parser import LogParser
        parser = LogParser()
        format_info = parser.detect_log_format(content)
        raw_entries = parser.parse_to_entries(content, format_info)

        structured = []
        for entry in raw_entries[:500]:
            fields = parser.extract_key_fields(entry, format_info)
            structured.append(fields)

        return normalizer.normalize_for_storage(structured)

    # ============================================
    # STEP 5: Classify
    # ============================================

    def _classify_log_type(self, content: str, detected_format: str) -> str:
        """Classify log type using keyword detection."""
        content_lower = content.lower()

        # Security logs
        if any(kw in content_lower for kw in
               ['auth', 'login', 'password', 'token', 'unauthorized', 'forbidden', 'session']):
            return "security_log"

        # Error logs
        if any(kw in content_lower for kw in
               ['error', 'exception', 'traceback', 'fatal', 'critical', 'stack trace', 'failed']):
            return "error_log"

        # Access logs
        if detected_format in ["apache", "apache_combined", "apache_common"]:
            return "access_log"
        if any(kw in content_lower for kw in ['get /', 'post /', 'put /', '200 ', '404 ', 'nginx']):
            return "access_log"

        # Database logs
        if any(kw in content_lower for kw in
               ['sql', 'query', 'database', 'mysql', 'postgresql', 'mongodb', 'deadlock']):
            return "database_log"

        # Network logs
        if any(kw in content_lower for kw in ['network', 'firewall', 'packet', 'port', 'tcp', 'udp', 'dns']):
            return "network_log"

        # System logs
        if detected_format in ["syslog"]:
            return "system_log"
        if any(kw in content_lower for kw in ['kernel', 'systemd', 'dmesg', 'syslog', 'journal']):
            return "system_log"

        # Application logs
        if any(kw in content_lower for kw in ['info', 'debug', 'warn', 'starting', 'started', 'stopping', 'config']):
            return "application_log"

        return "general_log"