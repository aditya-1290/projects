"""
Skill Prompts for the Preprocessor Agent.

The Preprocessor cleans, chunks, normalizes, and structures raw log data.
It ensures data is consistent and ready for analysis.

Uses Qwen-2.5-3B (efficient preprocessing model).

Skill catalogue:
  SKILL_LOG_CLEANING         — Remove noise and sanitize log data
  SKILL_PII_REDACTION        — Mask sensitive information
  SKILL_DEDUPLICATION        — Remove duplicate log entries
  SKILL_CHUNKING             — Split large logs into manageable chunks
  SKILL_TIMESTAMP_NORMALIZATION — Standardize timestamps to ISO 8601
  SKILL_LOG_LEVEL_NORMALIZATION — Standardize log levels
  SKILL_HOSTNAME_NORMALIZATION — Normalize hostnames and IPs
  SKILL_FIELD_STANDARDIZATION — Map fields to standard names
  SKILL_FORMAT_STRUCTURING   — Structure parsed data consistently
  SKILL_ENCODING_FIX         — Fix common encoding issues
  SKILL_EMPTY_LINE_REMOVAL   — Remove noise lines
"""

# =============================================================================
# SKILL: Log Cleaning
# Used by: Primary cleaning operation
# =============================================================================

SKILL_LOG_CLEANING = """You are a data quality specialist cleaning log data.

Log data to clean: {content_sample}
Total content length: {content_length}
Detected format: {log_format}

Cleaning operations:

1. REMOVE NOISE
   → Empty lines and whitespace-only lines
   → ANSI color codes and escape sequences
   → Control characters (keep newlines and tabs)
   → Trailing whitespace on each line

2. FIX ENCODING ISSUES
   → Replace garbled characters (锟斤拷 → proper chars)
   → Remove null bytes (\\x00)
   → Fix double-encoded text
   → Handle BOM characters

3. NORMALIZE WHITESPACE
   → Collapse multiple spaces (but preserve log structure)
   → Normalize line endings to \\n
   → Remove trailing whitespace

4. DETECT ISSUES
   → Corrupted lines
   → Truncated entries
   → Inconsistent formatting

Respond ONLY with valid JSON:
{{
  "cleaned_content": "cleaned text",
  "operations_performed": [
    "Removed 15 empty lines",
    "Fixed 3 encoding issues",
    "Removed ANSI color codes from 42 lines",
    "Collapsed excessive whitespace in 8 lines"
  ],
  "issues_detected": [
    "3 corrupted lines at positions 120-122",
    "Possible truncated entry at line 500"
  ],
  "lines_before": 500,
  "lines_after": 482,
  "characters_before": 25000,
  "characters_after": 24850,
  "confidence": 0.95
}}"""


# =============================================================================
# SKILL: PII Redaction
# Used by: When sensitive data is detected
# =============================================================================

SKILL_PII_REDACTION = """You are a data privacy specialist redacting sensitive information.

Content to scan: {content_sample}

PII patterns to detect and redact:

1. EMAIL ADDRESSES
   → Pattern: user@domain.tld
   → Replace with: [REDACTED_EMAIL]

2. IP ADDRESSES
   → Pattern: XXX.XXX.XXX.XXX
   → Replace with: [REDACTED_IP]
   → Exception: Keep internal IPs (10.x, 192.168.x, 172.16-31.x) if configured

3. API KEYS AND TOKENS
   → Pattern: key=..., token=..., api_key=...
   → Replace with: [REDACTED_API_KEY]

4. PASSWORDS AND SECRETS
   → Pattern: password=..., secret=..., passwd=...
   → Replace with: [REDACTED_SECRET]

5. CREDIT CARD NUMBERS
   → Pattern: XXXX-XXXX-XXXX-XXXX
   → Replace with: [REDACTED_CC]

6. SOCIAL SECURITY NUMBERS
   → Pattern: XXX-XX-XXXX
   → Replace with: [REDACTED_SSN]

7. JWT TOKENS
   → Pattern: eyJ... (base64 encoded JSON)
   → Replace with: [REDACTED_JWT]

Respond ONLY with valid JSON:
{{
  "redactions_applied": 12,
  "redaction_details": [
    {{"type": "email", "count": 3, "replaced_with": "[REDACTED_EMAIL]"}},
    {{"type": "ip_address", "count": 5, "replaced_with": "[REDACTED_IP]"}},
    {{"type": "api_key", "count": 2, "replaced_with": "[REDACTED_API_KEY]"}},
    {{"type": "password", "count": 1, "replaced_with": "[REDACTED_SECRET]"}},
    {{"type": "jwt", "count": 1, "replaced_with": "[REDACTED_JWT]"}}
  ],
  "content_modified": true,
  "redaction_confidence": 0.99
}}"""


# =============================================================================
# SKILL: Chunking
# Used by: When logs exceed 4000 tokens
# =============================================================================

SKILL_CHUNKING = """You are splitting large log data into manageable chunks.

Content size: {content_length} characters
Estimated tokens: {token_count}
Maximum tokens per chunk: 4000
Overlap size: 200 tokens

Chunking rules:

1. SIZE CHECK
   → If total tokens < 4000: DO NOT CHUNK (preserve full context)
   → If total tokens >= 4000: Create overlapping chunks

2. CHUNK BOUNDARIES
   → Break at log entry boundaries (newlines)
   → Never split in the middle of a log entry
   → Preserve complete error messages and stack traces

3. OVERLAP STRATEGY
   → 200 token overlap between chunks
   → Preserve context across chunk boundaries
   → Include the last few entries of previous chunk at start of next

4. CHUNK METADATA
   → Assign sequential chunk IDs
   → Track start/end line numbers
   → Generate content hash for deduplication

5. SEMANTIC AWARENESS
   → Group related entries (same error burst, same session)
   → Avoid splitting error+stack trace pairs
   → Keep timestamp-ordered entries together

Respond ONLY with valid JSON:
{{
  "was_chunked": true,
  "original_token_count": 8500,
  "number_of_chunks": 3,
  "chunk_size_tokens": 4000,
  "overlap_tokens": 200,
  "chunks": [
    {{
      "chunk_id": "chunk_0",
      "start_line": 1,
      "end_line": 95,
      "entry_count": 95,
      "token_count": 3950,
      "content_hash": "md5hash",
      "overlaps_with": ["chunk_1"]
    }}
  ],
  "chunking_strategy": "log_entry_boundaries_with_overlap",
  "warnings": [],
  "confidence": 0.95
}}"""


# =============================================================================
# SKILL: Timestamp Normalization
# Used by: Standardizing all timestamps to ISO 8601
# =============================================================================

SKILL_TIMESTAMP_NORMALIZATION = """You are normalizing log timestamps to ISO 8601 format.

Sample timestamps found:
{timestamp_samples}

Normalization steps:

1. DETECT FORMAT
   → ISO 8601: 2024-01-15T10:30:45.123Z
   → Apache: 15/Jan/2024:10:30:45 +0000
   → Syslog: Jan 15 10:30:45
   → MySQL: 240115 10:30:45
   → Unix: 1705312245 (epoch seconds)
   → Custom formats

2. CONVERT TO ISO 8601
   → All timestamps → "YYYY-MM-DDTHH:MM:SS.mmm"
   → Preserve timezone information
   → Add Unix timestamp as secondary field

3. HANDLE EDGE CASES
   → Missing timestamps: mark as null, don't invent
   → Ambiguous formats: flag with low confidence
   → Future timestamps: flag as anomaly
   → Pre-1970 timestamps: handle gracefully

Respond ONLY with valid JSON:
{{
  "normalized_timestamps": [
    {{
      "original": "Jan 15 10:30:45",
      "detected_format": "syslog",
      "normalized": "2024-01-15T10:30:45",
      "unix_timestamp": 1705312245,
      "confidence": 0.98
    }}
  ],
  "formats_detected": ["syslog", "iso8601"],
  "total_normalized": 500,
  "failed_to_parse": 3,
  "anomalies": [
    {{"original": "Jan 15 10:30:45", "issue": "missing year, assumed current"}}
  ]
}}"""


# =============================================================================
# SKILL: Log Level Normalization
# Used by: Standardizing log levels
# =============================================================================

SKILL_LOG_LEVEL_NORMALIZATION = """You are normalizing log severity levels.

Sample levels found: {level_samples}

Standard level mapping:
  EMERGENCY  (0) ← emerg, emergency, panic
  ALERT      (1) ← alert
  CRITICAL   (2) ← crit, critical, fatal, severe
  ERROR      (3) ← err, error
  WARNING    (4) ← warn, warning
  NOTICE     (5) ← notice
  INFO       (6) ← info, information
  DEBUG      (7) ← debug, fine, finer
  TRACE      (8) ← trace, finest

Respond ONLY with valid JSON:
{{
  "normalized_levels": [
    {{"original": "WARN", "normalized": "WARNING", "numeric": 4, "confidence": 1.0}},
    {{"original": "ERR", "normalized": "ERROR", "numeric": 3, "confidence": 1.0}},
    {{"original": "SEVERE", "normalized": "CRITICAL", "numeric": 2, "confidence": 0.9}}
  ],
  "level_distribution": {{
    "ERROR": 120,
    "WARNING": 45,
    "INFO": 300,
    "DEBUG": 35
  }},
  "unknown_levels": 0,
  "confidence": 0.97
}}"""


# =============================================================================
# SKILL: Field Standardization
# Used by: Mapping fields to standard names
# =============================================================================

SKILL_FIELD_STANDARDIZATION = """You are standardizing log field names.

Fields found: {field_names}

Standard field mapping:
  timestamp   ← timestamp, time, ts, datetime, date, @timestamp
  level       ← level, severity, log_level, priority, type
  message     ← message, msg, description, text, content, body
  host        ← host, hostname, server, node, machine, source
  process     ← process, service, component, application, app, daemon
  pid         ← pid, process_id, proc_id
  error_code  ← error_code, errno, exit_code, status_code, code
  ip          ← ip, ip_address, client_ip, source_ip
  user        ← user, username, user_id, account
  session     ← session, session_id, request_id, trace_id

Respond ONLY with valid JSON:
{{
  "field_mappings": [
    {{"original": "datetime", "standardized": "timestamp", "confidence": 1.0}},
    {{"original": "severity", "standardized": "level", "confidence": 1.0}},
    {{"original": "msg", "standardized": "message", "confidence": 0.95}}
  ],
  "unmapped_fields": ["custom_field_1", "custom_field_2"],
  "total_fields": 12,
  "mapped_fields": 10,
  "confidence": 0.92
}}"""