# agents/preprocessor/chunker.py
"""
Log Chunker - Splits large log datasets into manageable chunks
"""

from typing import List, Dict, Any, Iterator
import hashlib


class LogChunker:
    """Chunks large log datasets for processing"""

    def __init__(self):
        self.default_chunk_size = 100  # Default entries per chunk
        self.max_chunk_size = 1000  # Maximum entries per chunk
        self.overlap_size = 10  # Overlap between chunks for context

    def create_chunks(self, entries: List[Any], chunk_size: int = None) -> List[Dict[str, Any]]:
        """Split entries into overlapping chunks"""
        if chunk_size is None:
            chunk_size = self.default_chunk_size

        chunk_size = min(chunk_size, self.max_chunk_size)

        chunks = []
        total_entries = len(entries)

        # Calculate number of chunks
        if total_entries <= chunk_size:
            return [{
                "id": "chunk_0",
                "entries": entries,
                "start_index": 0,
                "end_index": total_entries - 1,
                "size": total_entries,
                "hash": self._hash_entries(entries)
            }]

        # Create overlapping chunks
        stride = chunk_size - self.overlap_size

        for i in range(0, total_entries, stride):
            end = min(i + chunk_size, total_entries)
            chunk_entries = entries[i:end]

            chunk = {
                "id": f"chunk_{len(chunks)}",
                "entries": chunk_entries,
                "start_index": i,
                "end_index": end - 1,
                "size": len(chunk_entries),
                "hash": self._hash_entries(chunk_entries),
                "overlaps_with": []
            }

            # Track overlaps
            if chunks:
                prev_chunk = chunks[-1]
                if chunk["start_index"] <= prev_chunk["end_index"]:
                    prev_chunk["overlaps_with"].append(chunk["id"])
                    chunk["overlaps_with"].append(prev_chunk["id"])

            chunks.append(chunk)

            # Don't create a tiny last chunk
            if end == total_entries:
                break

        return chunks

    def create_semantic_chunks(self, entries: List[str],
                               chunk_by: str = "timestamp_gap") -> List[Dict[str, Any]]:
        """Create chunks based on semantic boundaries"""

        if chunk_by == "timestamp_gap":
            return self._chunk_by_time_gap(entries)
        elif chunk_by == "session":
            return self._chunk_by_session(entries)
        elif chunk_by == "error_burst":
            return self._chunk_by_error_burst(entries)
        else:
            return self.create_chunks(entries)

    def _chunk_by_time_gap(self, entries: List[str]) -> List[Dict[str, Any]]:
        """Chunk entries where there's a significant time gap"""
        chunks = []
        current_chunk = []

        # This would need actual timestamp parsing
        # Simplified version - chunk by empty lines or large gaps

        for entry in entries:
            if entry.strip() == '' and current_chunk:
                chunks.append(current_chunk)
                current_chunk = []
            else:
                current_chunk.append(entry)

        if current_chunk:
            chunks.append(current_chunk)

        return [
            {
                "id": f"semantic_chunk_{i}",
                "entries": chunk,
                "size": len(chunk)
            }
            for i, chunk in enumerate(chunks)
        ]

    def _chunk_by_session(self, entries: List[str]) -> List[Dict[str, Any]]:
        """Chunk entries by session identifier"""
        # This would group entries with same session/host/user
        return self.create_chunks(entries)

    def _chunk_by_error_burst(self, entries: List[str]) -> List[Dict[str, Any]]:
        """Chunk entries around error bursts"""
        # Group consecutive errors together
        return self.create_chunks(entries)

    def _hash_entries(self, entries: List[Any]) -> str:
        """Create a hash of the entries for deduplication"""
        content = ''.join(str(e) for e in entries)
        return hashlib.md5(content.encode()).hexdigest()

    def get_chunk_statistics(self, chunks: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Get statistics about the chunks"""
        if not chunks:
            return {"error": "No chunks"}

        sizes = [c["size"] for c in chunks]

        return {
            "total_chunks": len(chunks),
            "total_entries": sum(sizes),
            "average_chunk_size": sum(sizes) / len(chunks),
            "min_chunk_size": min(sizes),
            "max_chunk_size": max(sizes),
            "has_overlaps": any(c.get("overlaps_with") for c in chunks)
        }