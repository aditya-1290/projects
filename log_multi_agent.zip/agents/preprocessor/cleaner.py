# agents/preprocessor/cleaner.py
"""
Log Cleaner - Cleans and sanitizes log data
"""

import re
from typing import Dict, Any, List, Tuple
import hashlib


class LogCleaner:
    """Cleans and sanitizes log data"""

    def __init__(self):
        self.operations_log = []
        self.sensitive_patterns = {
            'email': r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',
            'ip_address': r'\b(?:\d{1,3}\.){3}\d{1,3}\b',
            'credit_card': r'\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}\b',
            'ssn': r'\b\d{3}-\d{2}-\d{4}\b',
            'api_key': r'(?i)(api[_-]?key|token|secret|password|auth)[\s:=]+([^\s]+)',
            'jwt': r'eyJ[a-zA-Z0-9_-]+\.eyJ[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+'
        }

    def remove_empty_lines(self, content: str) -> str:
        """Remove empty lines from content"""
        lines = content.splitlines()
        non_empty_lines = [line for line in lines if line.strip()]
        removed = len(lines) - len(non_empty_lines)

        if removed > 0:
            self.operations_log.append(f"Removed {removed} empty lines")

        return '\n'.join(non_empty_lines)

    def remove_duplicates(self, content: str) -> str:
        """Remove duplicate lines while preserving order"""
        lines = content.splitlines()
        seen = set()
        unique_lines = []
        duplicates = 0

        for line in lines:
            # Create a fingerprint ignoring timestamps
            fingerprint = self._create_line_fingerprint(line)
            if fingerprint not in seen:
                seen.add(fingerprint)
                unique_lines.append(line)
            else:
                duplicates += 1

        if duplicates > 0:
            self.operations_log.append(f"Removed {duplicates} duplicate lines")

        return '\n'.join(unique_lines)

    def _create_line_fingerprint(self, line: str) -> str:
        """Create fingerprint of a line ignoring variable parts like timestamps"""
        # Remove timestamps
        line = re.sub(r'\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}[.,\d]*Z?', '[TIMESTAMP]', line)
        line = re.sub(r'\d{2}:\d{2}:\d{2}[.,\d]*', '[TIME]', line)

        # Remove IPs
        line = re.sub(r'\b(?:\d{1,3}\.){3}\d{1,3}\b', '[IP]', line)

        # Remove numbers (be careful not to remove too much)
        line = re.sub(r'\b\d+\b', '[NUM]', line)

        return hashlib.md5(line.encode()).hexdigest()

    def fix_encoding(self, content: str) -> str:
        """Fix common encoding issues"""
        fixes = 0

        # Fix common encoding problems
        replacements = {
            '鈥檙': "'",  # Smart quote
            '鈥淿': '"',  # Smart double quote
            '脗漏': '©',  # Copyright
            '脗庐': '®',  # Registered
            '脗鈧?': '€',  # Euro
            '\\x00': '',  # Null bytes
            '\\u0000': '',  # Unicode null
        }

        for old, new in replacements.items():
            if old in content:
                content = content.replace(old, new)
                fixes += 1

        # Remove control characters except newlines and tabs
        cleaned = ''
        for char in content:
            if ord(char) >= 32 or char in '\n\r\t':
                cleaned += char
            else:
                fixes += 1

        if fixes > 0:
            self.operations_log.append(f"Fixed {fixes} encoding issues")

        return cleaned

    def redact_sensitive_data(self, content: str) -> Tuple[str, int]:
        """Redact sensitive information from logs"""
        redactions = 0

        for pattern_name, pattern in self.sensitive_patterns.items():
            matches = re.findall(pattern, content, re.IGNORECASE)
            if matches:
                for match in matches:
                    if isinstance(match, tuple):
                        match = match[0]  # Take first group if multiple
                    content = content.replace(match, f'[REDACTED_{pattern_name.upper()}]')
                    redactions += 1

        if redactions > 0:
            self.operations_log.append(f"Redacted {redactions} sensitive data instances")

        return content, redactions

    def get_operations_log(self) -> List[str]:
        """Get the log of cleaning operations performed"""
        return self.operations_log