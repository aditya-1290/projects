# agents/preprocessor/tools.py (MINIMAL - Just data access utilities)
"""
Preprocessor Tools - Minimal utility tools, reasoning is done by the model
"""

from typing import Dict, Any, List


class PreprocessorTools:
    """Minimal tools - the model does the actual reasoning work"""

    @staticmethod
    def get_sample(data: Any, max_items: int = 100) -> Any:
        """Get a sample of the data for the model to analyze"""
        if isinstance(data, str):
            lines = data.splitlines()
            return '\n'.join(lines[:max_items])
        elif isinstance(data, list):
            return data[:max_items]
        return data

    @staticmethod
    def count_lines(text: str) -> int:
        """Count lines in text"""
        return len(text.splitlines())

    @staticmethod
    def get_unique_lines(text: str) -> int:
        """Count unique lines in text"""
        return len(set(text.splitlines()))