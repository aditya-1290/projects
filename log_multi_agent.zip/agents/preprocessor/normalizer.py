# agents/preprocessor/normalizer.py
"""
Log Normalizer - Normalizes log data to standard format
"""

from typing import Dict, Any, Optional
from datetime import datetime
import re
from enum import Enum


class LogLevel(Enum):
    EMERGENCY = 0
    ALERT = 1
    CRITICAL = 2
    ERROR = 3
    WARNING = 4
    NOTICE = 5
    INFO = 6
    DEBUG = 7
    TRACE = 8


class LogNormalizer:
    """Normalizes log entries to a standard format"""

    def __init__(self):
        self.level_mapping = {
            'EMERG': 'EMERGENCY',
            'EMERGENCY': 'EMERGENCY',
            'ALERT': 'ALERT',
            'CRIT': 'CRITICAL',
            'CRITICAL': 'CRITICAL',
            'ERR': 'ERROR',
            'ERROR': 'ERROR',
            'FATAL': 'CRITICAL',
            'SEVERE': 'CRITICAL',
            'WARN': 'WARNING',
            'WARNING': 'WARNING',
            'NOTICE': 'NOTICE',
            'INFO': 'INFO',
            'INFORMATION': 'INFO',
            'DEBUG': 'DEBUG',
            'TRACE': 'DEBUG',
            'FINE': 'DEBUG',
            'FINER': 'DEBUG',
            'FINEST': 'TRACE',
        }

        self.field_aliases = {
            'timestamp': ['timestamp', 'time', 'ts', 'datetime', 'date', '@timestamp'],
            'level': ['level', 'severity', 'log_level', 'priority', 'type'],
            'message': ['message', 'msg', 'description', 'text', 'content', 'body'],
            'host': ['host', 'hostname', 'server', 'node', 'machine', 'source'],
            'process': ['process', 'service', 'component', 'application', 'app', 'daemon'],
            'pid': ['pid', 'process_id', 'proc_id'],
            'error_code': ['error_code', 'errno', 'exit_code', 'status_code', 'code'],
        }

    def normalize_timestamp(self, entry: Dict[str, Any]) -> Dict[str, Any]:
        """Normalize timestamp to ISO 8601 format"""
        timestamp = entry.get('timestamp')

        if not timestamp:
            # Try to find timestamp in other fields
            for alias in self.field_aliases['timestamp']:
                if alias in entry:
                    timestamp = entry[alias]
                    break

        if timestamp:
            normalized = self._parse_timestamp(str(timestamp))
            if normalized:
                entry['timestamp'] = normalized.isoformat()
                entry['timestamp_unix'] = normalized.timestamp()

        return entry

    def _parse_timestamp(self, timestamp_str: str) -> Optional[datetime]:
        """Parse various timestamp formats"""
        formats = [
            '%Y-%m-%dT%H:%M:%S.%fZ',
            '%Y-%m-%dT%H:%M:%S.%f',
            '%Y-%m-%dT%H:%M:%S',
            '%Y-%m-%d %H:%M:%S.%f',
            '%Y-%m-%d %H:%M:%S',
            '%b %d %H:%M:%S',
            '%b %d %Y %H:%M:%S',
            '%d/%b/%Y:%H:%M:%S %z',
            '%d/%b/%Y %H:%M:%S',
            '%m/%d/%Y %H:%M:%S',
            '%d-%m-%Y %H:%M:%S',
            '%Y%m%d %H:%M:%S',
            '%H:%M:%S.%f',
            '%H:%M:%S',
        ]

        # Remove timezone info for parsing if needed
        timestamp_str = re.sub(r'\s*[+-]\d{4}\s*$', '', timestamp_str)
        timestamp_str = re.sub(r'\s*[A-Z]{3,4}\s*$', '', timestamp_str)

        for fmt in formats:
            try:
                return datetime.strptime(timestamp_str.strip(), fmt)
            except ValueError:
                continue

        return None

    def normalize_log_level(self, entry: Dict[str, Any]) -> Dict[str, Any]:
        """Normalize log level to standard format"""
        level = entry.get('level', '')

        # Try to find level in other fields
        if not level:
            for alias in self.field_aliases['level']:
                if alias in entry:
                    level = entry[alias]
                    break

        if level:
            level_upper = str(level).upper().strip()
            normalized_level = self.level_mapping.get(level_upper, level_upper)
            entry['level'] = normalized_level

            # Add numeric level for sorting
            try:
                entry['level_numeric'] = LogLevel[normalized_level].value
            except KeyError:
                entry['level_numeric'] = -1

        return entry

    def normalize_hostname(self, entry: Dict[str, Any]) -> Dict[str, Any]:
        """Normalize hostname/IP addresses"""
        # Normalize hostnames to lowercase
        for field in ['host', 'hostname']:
            if field in entry:
                entry[field] = str(entry[field]).lower()

        # Handle IP addresses
        if 'ip' in entry:
            ip = str(entry['ip'])
            # Remove port if present
            if ':' in ip:
                ip = ip.split(':')[0]
            entry['ip'] = ip

        return entry

    def standardize_field_names(self, entry: Dict[str, Any]) -> Dict[str, Any]:
        """Standardize field names across different log formats"""
        standardized = {}

        # Map known fields to standard names
        for standard_name, aliases in self.field_aliases.items():
            for alias in aliases:
                if alias in entry and alias != standard_name:
                    value = entry[alias]
                    # Don't overwrite existing standard field
                    if standard_name not in standardized:
                        standardized[standard_name] = value

        # Merge with original entry (standardized fields take precedence)
        result = {**entry, **standardized}

        # Add metadata
        result['normalized'] = True
        result['original_fields'] = list(entry.keys())

        return result

    def normalize_for_storage(self, entries: list) -> list:
        """Normalize entire dataset for storage"""
        normalized = []

        for entry in entries:
            entry = self.normalize_timestamp(entry)
            entry = self.normalize_log_level(entry)
            entry = self.normalize_hostname(entry)
            entry = self.standardize_field_names(entry)
            normalized.append(entry)

        return normalized