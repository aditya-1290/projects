"""
Skill Prompts for the Memory Agent.

The Memory Agent stores, retrieves, and manages context across sessions.
It helps other agents learn from past experiences.

Uses BGE-Small-EN (embeddings model).

Skill catalogue:
  SKILL_MEMORY_STORAGE        — Store experiences for future retrieval
  SKILL_MEMORY_RETRIEVAL      — Find relevant past experiences
  SKILL_CONTEXT_MANAGEMENT    — Maintain session context
  SKILL_PATTERN_RECOGNITION   — Recognize patterns across sessions
  SKILL_KNOWLEDGE_SYNTHESIS   — Synthesize insights from history
  SKILL_MEMORY_CONSOLIDATION  — Merge and prune memories
  SKILL_SIMILARITY_SEARCH     — Find semantically similar past issues
"""

# =============================================================================
# SKILL: Memory Storage
# Used by: Storing experiences
# =============================================================================

SKILL_MEMORY_STORAGE = """You are storing experiences for future retrieval.

Information to store:
{information}

Storage process:

1. ASSESS RELEVANCE
   → Is this worth remembering?
   → Will this be useful in the future?
   → What category does it belong to?

2. EXTRACT KEY POINTS
   → What was the problem?
   → What was the solution?
   → What was the outcome?

3. TAG AND CATEGORIZE
   → Error type tags
   → Technology tags
   → Severity tags
   → User tags

4. STORE WITH METADATA
   → Timestamp
   → Session ID
   → Confidence level
   → Source agent

Respond ONLY with valid JSON:
{{
  "stored": true,
  "memory_id": "mem_abc123",
  "category": "error_resolution",
  "tags": ["database", "connection_timeout", "postgresql"],
  "relevance_score": 0.85,
  "will_be_useful_for": [
    "Similar database timeout errors",
    "PostgreSQL connection issues"
  ],
  "confidence": 0.90
}}"""


# =============================================================================
# SKILL: Memory Retrieval
# Used by: Finding relevant past experiences
# =============================================================================

SKILL_MEMORY_RETRIEVAL = """You are retrieving relevant past experiences.

Query: {query}
Context: {context}

Retrieval process:

1. SEMANTIC SEARCH
   → Find semantically similar past issues
   → Consider error type, technology, symptoms
   → Rank by relevance score

2. TEMPORAL RELEVANCE
   → Prefer recent experiences
   → But don't ignore old patterns that match perfectly

3. SUCCESS WEIGHTING
   → Prefer solutions that worked before
   → Flag solutions that failed previously
   → Note confidence levels

4. SYNTHESIZE
   → Combine insights from multiple memories
   → Identify patterns across retrievals
   → Provide actionable recommendations

Respond ONLY with valid JSON:
{{
  "memories_found": [
    {{
      "memory_id": "mem_abc123",
      "similarity_score": 0.92,
      "problem": "Database connection timeout in auth service",
      "solution_that_worked": "Increased connection pool size from 10 to 50",
      "outcome": "Resolved timeout issues",
      "when": "2024-01-15",
      "relevance": "Same error pattern with same database"
    }}
  ],
  "total_found": 3,
  "best_match": "mem_abc123",
  "synthesized_insight": "Database connection pool exhaustion is recurring. Consider implementing connection pooling with auto-scaling.",
  "confidence": 0.88
}}"""