# agents/memory/agent.py (REDESIGNED - Model-Driven)
"""
Memory Agent - Uses LLM to manage context, retrieve relevant information,
and maintain knowledge across sessions.
"""

from typing import Dict, Any, List, Optional
import logging
from datetime import datetime
import json

from agents.base_agent import BaseAgent, A2AMessage, MessageType, AgentState
from agents.agent_config import AgentConfig

logger = logging.getLogger(__name__)


class MemoryAgent(BaseAgent):
    """
    Memory agent that uses the LLM to determine what's relevant,
    maintain context, and retrieve useful information from history.
    """

    # agents/extractor/agent.py - FIXED __init__
    def __init__(self, agent_id: str = "memory", capability_path: str = None, config=None, **kwargs):
        """
        Initialize extractor agent.
        Supports both:
        - New style: ExtractorAgent(agent_id="extractor", capability_path="...")
        - Old style: ExtractorAgent(config=AgentConfig(...))
        - Test style: ExtractorAgent(AgentConfig(...))  ← FIX THIS CASE
        """
        # FIX: Check if first argument is actually an AgentConfig (test passes it as positional)
        if hasattr(agent_id, 'agent_id') and hasattr(agent_id, 'capabilities'):
            # First argument is actually an AgentConfig object
            config = agent_id
            agent_id = config.agent_id if hasattr(config, 'agent_id') else "extractor"
            if capability_path is None:
                capability_path = getattr(config, 'capability_path', None)
        elif config is not None:
            # Old style with explicit config= parameter
            agent_id = config.agent_id if hasattr(config, 'agent_id') else "extractor"
            if capability_path is None:
                capability_path = getattr(config, 'capability_path', None)

        # Make sure capability_path is not None
        if capability_path is None:
            from pathlib import Path
            default_path = Path(__file__).parent / "capabilities.json"
            if default_path.exists():
                capability_path = str(default_path)

        super().__init__(agent_id=agent_id, capability_path=capability_path)


    def get_system_prompt(self) -> str:
        """Define the memory agent's persona and capabilities"""
        return """
        You are an expert memory and context management agent. Your purpose is to 
        maintain relevant context, retrieve useful information, and help other agents
        make better decisions by providing historical insights.

        Your capabilities:
        - Store and organize information from conversations and analyses
        - Retrieve relevant past experiences and solutions
        - Maintain session context across multiple interactions
        - Identify patterns across different sessions
        - Provide context that helps other agents make better decisions
        - Learn from past successes and failures

        Your thinking process:
        1. Understand what information is being provided or requested
        2. Determine what's important to remember vs what's transient
        3. Organize information in a way that's useful for future retrieval
        4. When retrieving, find the most relevant information
        5. Explain why certain memories are relevant to the current situation

        You help other agents by:
        - Providing relevant historical context
        - Suggesting solutions that worked before
        - Warning about approaches that failed previously
        - Connecting related issues across time
        """

    async def process(self, message: A2AMessage) -> A2AMessage:
        """
        Process incoming A2A message.
        This is the entry point called by the communication bus.
        It bridges A2A protocol to the agent's process_task logic.
        """

        # Handle capability queries
        if message.task and message.task.get("action") == "report_capabilities":
            return A2AMessage(
                message_type=MessageType.RESPONSE,
                sender_id=self.agent_id,
                sender_type=self.capability.agent_name,
                target_id=message.sender_id,
                correlation_id=message.message_id,
                response=self.capability.to_dict(),
                confidence=1.0
            )

        # Check if agent can handle this task
        task = message.task or {}
        if not self.can_handle(task):
            return A2AMessage(
                message_type=MessageType.RESPONSE,
                sender_id=self.agent_id,
                sender_type=self.capability.agent_name,
                target_id=message.sender_id,
                correlation_id=message.message_id,
                response={
                    "can_handle": False,
                    "reason": self.capability.out_of_scope_message,
                    "suggested_agents": self.capability.fallback_agents,
                    "my_capabilities": self.capability.capabilities
                },
                confidence=0.0
            )

        # Process the task using the agent's existing logic
        try:
            self.state = AgentState.PROCESSING

            # Convert A2A task format to what process_task expects
            task_input = {
                "input": task.get("input", task),
                "parameters": task.get("parameters", {}),
                "context": message.context or {}
            }

            # Call the agent's existing process_task method
            result = await self.process_task(task_input)

            self.state = AgentState.IDLE

            return A2AMessage(
                message_type=MessageType.RESPONSE,
                sender_id=self.agent_id,
                sender_type=self.capability.agent_name,
                target_id=message.sender_id,
                correlation_id=message.message_id,
                response=result,
                confidence=0.85
            )

        except Exception as e:
            self.state = AgentState.ERROR
            return A2AMessage(
                message_type=MessageType.ERROR,
                sender_id=self.agent_id,
                sender_type=self.capability.agent_name,
                target_id=message.sender_id,
                correlation_id=message.message_id,
                error=str(e)
            )

    async def process_task(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """Store or retrieve information based on the task"""

        task_type = task.get("type", "store")
        input_data = task.get("input", {})

        if task_type == "store":
            return await self._store_memory(input_data)
        elif task_type == "retrieve":
            return await self._retrieve_memory(input_data)
        elif task_type == "context":
            return await self._get_context(input_data)
        else:
            return await self._manage_memory(input_data)

    async def _store_memory(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Let the model decide what's worth storing"""

        relevance_prompt = {
            "task": "assess_what_to_remember",
            "information": data,
            "existing_knowledge": self.knowledge_base[-5:] if self.knowledge_base else [],
            "questions": [
                "What in this information is worth remembering?",
                "How should this be categorized and tagged?",
                "How might this be useful in the future?",
                "Is this connected to anything we already know?",
                "What's the key takeaway or lesson?"
            ]
        }

        memory_assessment = await self.think(relevance_prompt)

        # Store based on model's assessment
        memory_entry = {
            "timestamp": datetime.now().isoformat(),
            "assessment": memory_assessment,
            "data": data,
            "tags": self._extract_tags(memory_assessment)
        }

        self.knowledge_base.append(memory_entry)

        return {
            "success": True,
            "stored": True,
            "memory_id": len(self.knowledge_base) - 1,
            "assessment": memory_assessment
        }

    async def _retrieve_memory(self, query: Dict[str, Any]) -> Dict[str, Any]:
        """Let the model find most relevant memories"""

        if not self.knowledge_base:
            return {
                "success": True,
                "found": False,
                "message": "No memories stored yet"
            }

        retrieval_prompt = {
            "task": "find_relevant_memories",
            "query": query,
            "available_memories": [
                {
                    "id": i,
                    "timestamp": mem["timestamp"],
                    "summary": str(mem["assessment"])[:500],
                    "tags": mem.get("tags", [])
                }
                for i, mem in enumerate(self.knowledge_base[-20:])  # Last 20 memories
            ],
            "questions": [
                "Which memories are most relevant to this query?",
                "Why are they relevant?",
                "What insights from past experiences apply here?",
                "What patterns do you see across these memories?",
                "What warnings or advice from past experience is applicable?"
            ]
        }

        relevant_memories = await self.think(retrieval_prompt)

        # Let the model synthesize insights
        synthesis_prompt = {
            "task": "synthesize_insights",
            "relevant_memories": relevant_memories,
            "current_query": query,
            "questions": [
                "What key insights from past experiences apply to this situation?",
                "What approaches worked before that might work now?",
                "What mistakes should be avoided?",
                "How does the current situation compare to past ones?"
            ]
        }

        synthesized_insights = await self.think(synthesis_prompt)

        return {
            "success": True,
            "found": True,
            "relevant_memories_found": relevant_memories,
            "synthesized_insights": synthesized_insights
        }

    async def _get_context(self, query: Dict[str, Any]) -> Dict[str, Any]:
        """Provide context for the current task"""

        context_prompt = {
            "task": "provide_context",
            "session_history": self.conversation_context[-10:] if self.conversation_context else [],
            "recent_memories": [
                str(mem["assessment"])[:300]
                for mem in self.knowledge_base[-5:]
            ] if self.knowledge_base else [],
            "current_query": query,
            "questions": [
                "What context is important for understanding the current situation?",
                "What has been discussed already that's relevant?",
                "What patterns or themes are emerging across this session?",
                "What should other agents know before proceeding?"
            ]
        }

        context = await self.think(context_prompt)

        return {
            "success": True,
            "context": context,
            "session_insights": "Analysis of current session patterns"
        }

    async def _manage_memory(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """General memory management - let model decide what to do"""

        management_prompt = {
            "task": "manage_memory",
            "current_state": {
                "total_memories": len(self.knowledge_base),
                "recent_activity": self.conversation_context[-5:] if self.conversation_context else []
            },
            "new_information": data,
            "questions": [
                "What should be done with this information?",
                "Is this new, or does it update existing knowledge?",
                "Should any old memories be consolidated or removed?",
                "What connections do you see with existing knowledge?"
            ]
        }

        decision = await self.think(management_prompt)

        # Store in conversation context
        self.conversation_context.append({
            "timestamp": datetime.now().isoformat(),
            "data": data,
            "decision": decision
        })

        return {
            "success": True,
            "decision": decision,
            "action_taken": "context_updated"
        }

    def _extract_tags(self, assessment: str) -> List[str]:
        """Extract tags from model's assessment"""
        # The model would naturally mention categories and tags
        # This is a simple extraction
        common_tags = ["error", "solution", "configuration", "performance",
                       "security", "network", "database", "application"]

        found_tags = []
        assessment_lower = assessment.lower()
        for tag in common_tags:
            if tag in assessment_lower:
                found_tags.append(tag)

        return found_tags