# agents/memory/tools.py
"""
Memory Tools - Utility functions for memory management
"""

from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta
import json


class MemoryTools:
    """Utility tools for the memory agent"""

    @staticmethod
    def create_memory_entry(content: Any, category: str = "general") -> Dict[str, Any]:
        """Create a structured memory entry"""
        return {
            "id": str(hash(str(content)))[:8],
            "timestamp": datetime.now().isoformat(),
            "category": category,
            "content": content,
            "access_count": 0,
            "last_accessed": None,
            "importance": "medium"
        }

    @staticmethod
    def filter_by_relevance(memories: List[Dict], query: str) -> List[Dict]:
        """Filter memories by relevance to query"""
        query_lower = query.lower()
        relevant = []

        for memory in memories:
            content_str = str(memory.get("content", "")).lower()
            if any(word in content_str for word in query_lower.split()):
                memory["access_count"] = memory.get("access_count", 0) + 1
                memory["last_accessed"] = datetime.now().isoformat()
                relevant.append(memory)

        return relevant

    @staticmethod
    def sort_by_importance(memories: List[Dict]) -> List[Dict]:
        """Sort memories by importance and recency"""

        def importance_score(memory: Dict) -> float:
            access_count = memory.get("access_count", 0)
            last_access = memory.get("last_accessed")

            # Boost recently accessed and frequently accessed
            score = access_count * 0.5

            if last_access:
                try:
                    access_time = datetime.fromisoformat(last_access)
                    hours_ago = (datetime.now() - access_time).total_seconds() / 3600
                    score += max(0, 10 - hours_ago) * 0.5
                except:
                    pass

            return score

        return sorted(memories, key=importance_score, reverse=True)

    @staticmethod
    def extract_keywords(text: str) -> List[str]:
        """Extract keywords from text for tagging"""
        # Simplified keyword extraction
        import re

        # Remove common stop words
        stop_words = {'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for'}

        words = re.findall(r'\b\w{4,}\b', text.lower())
        keywords = [w for w in words if w not in stop_words]

        # Count frequency
        from collections import Counter
        word_freq = Counter(keywords)

        return [word for word, count in word_freq.most_common(10)]

    @staticmethod
    def should_cleanup_memory(memories: List[Dict], max_size: int = 1000) -> bool:
        """Check if memory cleanup is needed"""
        return len(memories) > max_size

    @staticmethod
    def find_connections(memory1: Dict, memory2: Dict) -> List[str]:
        """Find connections between two memories"""
        connections = []

        # Check category overlap
        if memory1.get("category") == memory2.get("category"):
            connections.append(f"Same category: {memory1.get('category')}")

        # Check keyword overlap
        if "keywords" in memory1 and "keywords" in memory2:
            common = set(memory1["keywords"]) & set(memory2["keywords"])
            if common:
                connections.append(f"Shared keywords: {', '.join(common)}")

        # Check time proximity
        if "timestamp" in memory1 and "timestamp" in memory2:
            try:
                t1 = datetime.fromisoformat(memory1["timestamp"])
                t2 = datetime.fromisoformat(memory2["timestamp"])
                if abs((t1 - t2).total_seconds()) < 3600:  # Within 1 hour
                    connections.append("Close in time")
            except:
                pass

        return connections