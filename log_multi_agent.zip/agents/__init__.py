# agents/__init__.py
"""
Agents package for the Log Analysis Multi-Agent System
"""

from .base_agent import BaseAgent
from .agent_config import AgentConfig

__all__ = ['BaseAgent', 'AgentConfig']