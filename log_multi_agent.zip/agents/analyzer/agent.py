# agents/analyzer/agent.py (REDESIGNED FOR DIRECT BASEAGENT INHERITANCE)
"""
Analyzer Agent - Directly inherits from BaseAgent with A2A protocol
"""

from typing import Dict, Any, List, Optional
import logging
from datetime import datetime
from pathlib import Path

from agents.base_agent import BaseAgent, A2AMessage, AgentResponse, MessageType

logger = logging.getLogger(__name__)


class AnalyzerAgent(BaseAgent):
    """
    Analyzer agent that uses the LLM to deeply analyze and understand logs.
    Directly inherits from BaseAgent with full A2A protocol support.
    """

    def __init__(self, agent_id: str = "analyzer", capability_path: str = None, config=None, **kwargs):
        """
        Initialize analyzer agent.
        Supports both:
        - New style: AnalyzerAgent(agent_id="analyzer", capability_path="...")
        - Old style: AnalyzerAgent(config=AgentConfig(...))
        - Test style: AnalyzerAgent(AgentConfig(...))
        """
        # Check if first argument is actually an AgentConfig
        if hasattr(agent_id, 'agent_id') and hasattr(agent_id, 'capabilities'):
            config = agent_id
            agent_id = config.agent_id if hasattr(config, 'agent_id') else "analyzer"
            if capability_path is None:
                capability_path = getattr(config, 'capability_path', None)
        elif config is not None:
            agent_id = config.agent_id if hasattr(config, 'agent_id') else "analyzer"
            if capability_path is None:
                capability_path = getattr(config, 'capability_path', None)

        # Fallback capability path
        if capability_path is None:
            from pathlib import Path
            default_path = Path(__file__).parent / "capabilities.json"
            if default_path.exists():
                capability_path = str(default_path)

        super().__init__(agent_id=agent_id, capability_path=capability_path)

        # Analyzer-specific state
        self.analysis_history = []
        self._model = None

    def get_system_prompt(self) -> str:
        """Define the analyzer's persona and capabilities"""
        return """
        You are an expert log analysis agent. Your purpose is to deeply analyze 
        log data and extract meaningful insights, patterns, and anomalies.

        Your capabilities:
        - Classify logs by type, source, and severity
        - Identify patterns and trends across log entries
        - Detect anomalies, outliers, and unusual behavior
        - Recognize error patterns and their root causes
        - Correlate events across different components
        - Assess severity and potential business impact
        - Generate actionable insights and recommendations

        Your thinking process:
        1. First, understand the context and source of the logs
        2. Look for patterns - both normal and abnormal
        3. Correlate different events and timestamps
        4. Assess the severity and urgency
        5. Form hypotheses about root causes
        6. Generate specific, actionable recommendations

        Always:
        - Provide confidence levels for your findings
        - Explain your reasoning clearly
        - Highlight what's most important first
        - Distinguish between facts and hypotheses
        - Recommend next steps or further investigation if needed
        """

    async def process(self, message: A2AMessage) -> A2AMessage:
        """
        Process incoming A2A message for log analysis.
        This is the main entry point required by BaseAgent.
        """

        # Extract task from message
        task = message.task or {}
        input_data = task.get("input", {})

        # Get log entries to analyze
        entries = (
                input_data.get("normalized_data") or
                input_data.get("entries") or
                input_data.get("data") or
                []
        )

        if not entries:
            raw_content = (
                    input_data.get("cleaned_content") or
                    input_data.get("raw_content") or
                    input_data.get("text") or
                    ""
            )
            if raw_content:
                # Create basic entries from raw text
                lines = str(raw_content).splitlines()
                entries = [{"raw": line, "message": line} for line in lines if line.strip()]
                logger.info(f"[ANALYZER] Created {len(entries)} entries from raw content")

        if not entries:
            return A2AMessage(
                message_type=MessageType.ERROR,
                sender_id=self.agent_id,
                sender_type=self.capability.agent_name,
                target_id=message.sender_id,
                correlation_id=message.message_id,
                error="No log entries to analyze",
                confidence=0.0
            )

        logger.info(f"[ANALYZER] Analyzing {len(entries)} entries")

        try:
            # Perform deep analysis using the model
            analysis_result = await self._deep_analyze(entries, message.context)

            # Build success response
            return A2AMessage(
                message_type=MessageType.RESPONSE,
                sender_id=self.agent_id,
                sender_type=self.capability.agent_name,
                target_id=message.sender_id,
                correlation_id=message.message_id,
                response={
                    "success": True,
                    "agent_id": self.agent_id,
                    "analysis": analysis_result,
                    "timestamp": datetime.now().isoformat()
                },
                confidence=analysis_result.get("confidence", 0.85),
                caveats=analysis_result.get("caveats", [])
            )

        except Exception as e:
            logger.error(f"Analysis error: {e}", exc_info=True)
            return self._create_error_response(message, str(e))

    async def _deep_analyze(self, entries: List[Dict], context: Dict) -> Dict[str, Any]:
        """Perform multi-step deep analysis using the model"""

        # Step 1: Initial assessment
        initial_assessment = await self._think_about({
            "task": "initial_log_assessment",
            "total_entries": len(entries),
            "entry_sample": entries[:20],
            "questions": [
                "What is your first impression of these logs?",
                "What stands out immediately?",
                "What type of system/application generated these?",
                "Are there obvious issues or concerns?"
            ]
        })

        # Step 2: Pattern analysis
        pattern_analysis = await self._think_about({
            "task": "deep_pattern_analysis",
            "initial_assessment": initial_assessment,
            "log_entries": entries[:100],
            "questions": [
                "What patterns do you see across these log entries?",
                "Are there recurring errors or warnings?",
                "What temporal patterns exist?",
                "Do you see correlations between events?",
                "What components are most frequently mentioned?"
            ]
        })

        # Step 3: Anomaly detection
        anomaly_analysis = await self._think_about({
            "task": "anomaly_detection",
            "pattern_analysis": pattern_analysis,
            "log_entries": entries[:100],
            "questions": [
                "What anomalies or unusual patterns do you detect?",
                "Are there outliers?",
                "Do you see signs of security issues?",
                "Are there sudden changes in behavior?",
                "How severe are these anomalies on a scale of 1-10?"
            ]
        })

        # Step 4: Root cause analysis
        root_cause = await self._think_about({
            "task": "root_cause_analysis",
            "pattern_analysis": pattern_analysis,
            "anomaly_analysis": anomaly_analysis,
            "questions": [
                "What do you think is the root cause?",
                "Can you trace the chain of events?",
                "What conditions likely triggered these problems?",
                "How confident are you in this analysis?"
            ]
        })

        # Step 5: Generate recommendations
        recommendations = await self._think_about({
            "task": "generate_recommendations",
            "findings": {
                "patterns": pattern_analysis,
                "anomalies": anomaly_analysis,
                "root_cause": root_cause
            },
            "questions": [
                "What immediate actions should be taken?",
                "What long-term fixes are needed?",
                "What monitoring should be set up?",
                "Prioritize recommendations by urgency"
            ]
        })

        return {
            "initial_assessment": initial_assessment,
            "pattern_analysis": pattern_analysis,
            "anomaly_analysis": anomaly_analysis,
            "root_cause_analysis": root_cause,
            "recommendations": recommendations,
            "confidence": 0.85,
            "caveats": [
                "Analysis based on sample of available logs",
                "Recommendations should be validated in your environment"
            ]
        }

    async def _think_about(self, prompt_data: Dict) -> str:
        """
        Send structured data to the model for reasoning.
        This is the Chain-of-Thought engine.
        """
        # If model is available, use it
        if self._model:
            import json
            formatted_prompt = f"""
{self.get_system_prompt()}

Current Analysis Task:
{json.dumps(prompt_data, indent=2)}

Think step by step and provide your detailed analysis.
"""
            return await self._model.generate(formatted_prompt)

        # Fallback for when model isn't loaded yet
        task_name = prompt_data.get("task", "analysis")
        return f"[{task_name}] Analysis would be performed by the model. Sample size: {prompt_data.get('total_entries', 'unknown')} entries."

    async def start(self):
        """Start the agent and load the model"""
        self.state = AgentState.IDLE if not hasattr(self, 'state') else AgentState.IDLE

        # Load model if model_manager is available
        if self.model_manager:
            try:
                self._model = await self.model_manager.load_model("gemma")
                logger.info(f"Model loaded for {self.agent_id}")
            except Exception as e:
                logger.warning(f"Could not load model for {self.agent_id}: {e}")

        logger.info(f"AnalyzerAgent [{self.agent_id}] started")

    def can_handle(self, task: Dict) -> bool:
        """
        Override to add domain-specific checks.
        First calls parent's can_handle for contract checks,
        then adds analyzer-specific validation.
        """
        # First check the capability contract
        if not super().can_handle(task):
            return False

        # Additional analyzer-specific checks
        input_data = task.get("input", {})

        # We need log entries or normalized data to analyze
        has_data = (
                input_data.get("entries") or
                input_data.get("normalized_data") or
                input_data.get("raw_content")
        )

        if not has_data:
            return False

        return True