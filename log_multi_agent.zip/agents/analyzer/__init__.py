# agents/analyzer/__init__.py
"""
Analyzer Agent - Classifies and analyzes log types
"""

from .agent import AnalyzerAgent

__all__ = ['AnalyzerAgent']