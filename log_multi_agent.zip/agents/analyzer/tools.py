# agents/analyzer/tools.py
"""
Analyzer Tools - Utility functions for log analysis
"""

from typing import Dict, Any, List, Optional
from collections import Counter, defaultdict
import re
from datetime import datetime


class AnalyzerTools:
    """Utility tools for the analyzer agent"""

    @staticmethod
    def get_log_statistics(entries: List[Dict]) -> Dict[str, Any]:
        """Get basic statistics about log entries"""
        if not entries:
            return {}

        levels = Counter()
        components = Counter()
        timestamps = []

        for entry in entries:
            level = entry.get('level', 'UNKNOWN')
            levels[level] += 1

            component = entry.get('component', 'unknown')
            components[component] += 1

            ts = entry.get('timestamp')
            if ts:
                timestamps.append(ts)

        stats = {
            "total_entries": len(entries),
            "level_distribution": dict(levels),
            "top_components": components.most_common(5),
            "error_rate": (levels.get('ERROR', 0) + levels.get('CRITICAL', 0)) / max(len(entries), 1)
        }

        if timestamps:
            stats["time_range"] = {
                "first": min(timestamps),
                "last": max(timestamps)
            }

        return stats

    @staticmethod
    def extract_unique_errors(entries: List[Dict]) -> List[str]:
        """Extract unique error messages"""
        error_messages = set()

        for entry in entries:
            if entry.get('level') in ['ERROR', 'CRITICAL', 'FATAL']:
                message = entry.get('message', '')
                if message:
                    # Normalize the message to group similar errors
                    normalized = re.sub(r'\d+', '<NUMBER>', message)
                    normalized = re.sub(r'0x[0-9a-fA-F]+', '<HEX>', normalized)
                    error_messages.add(normalized)

        return list(error_messages)

    @staticmethod
    def find_error_spikes(entries: List[Dict], window_size: int = 100) -> List[Dict]:
        """Find spikes in error frequency"""
        spikes = []

        for i in range(0, len(entries), window_size):
            window = entries[i:i + window_size]
            errors = sum(1 for e in window if e.get('level') in ['ERROR', 'CRITICAL'])
            error_rate = errors / len(window)

            if error_rate > 0.5:  # More than 50% errors
                spikes.append({
                    "position": i,
                    "error_count": errors,
                    "error_rate": error_rate,
                    "window_size": len(window)
                })

        return spikes

    @staticmethod
    def extract_security_events(entries: List[Dict]) -> List[Dict]:
        """Extract security-related events"""
        security_keywords = [
            'auth', 'login', 'password', 'token', 'permission',
            'access denied', 'forbidden', 'unauthorized', 'hack',
            'injection', 'xss', 'csrf', 'brute force', 'scan'
        ]

        security_events = []

        for entry in entries:
            message = str(entry.get('message', '')).lower()
            for keyword in security_keywords:
                if keyword in message:
                    security_events.append({
                        "entry": entry,
                        "keyword_matched": keyword,
                        "severity": "HIGH" if keyword in ['hack', 'injection', 'brute force'] else "MEDIUM"
                    })
                    break

        return security_events