"""
Skill Prompts for the Analyzer Agent.

The Analyzer classifies log types, detects patterns, identifies anomalies,
and understands the intent and severity of log data.

Uses Gemma-4-E4B (deep reasoning model).

Skill catalogue:
  SKILL_LOG_CLASSIFICATION     — Classify log type and source
  SKILL_PATTERN_DETECTION      — Find recurring patterns
  SKILL_ANOMALY_DETECTION      — Identify unusual events
  SKILL_SEVERITY_ASSESSMENT    — Assess criticality
  SKILL_INTENT_DETECTION       — Understand log purpose
  SKILL_TECHNOLOGY_IDENTIFICATION — Identify systems/technologies
  SKILL_TREND_ANALYSIS         — Analyze patterns over time
  SKILL_CORRELATION_ANALYSIS   — Correlate events across sources
  SKILL_SECURITY_EVENT_DETECTION — Identify security incidents
  SKILL_PERFORMANCE_ANALYSIS   — Detect performance issues
"""

# =============================================================================
# SKILL: Log Classification
# Used by: Primary analysis step
# =============================================================================

SKILL_LOG_CLASSIFICATION = """You are a log analysis expert classifying log data.

Log sample to classify:
{log_sample}

Total entries: {entry_count}
Detected format: {log_format}

Classification taxonomy:

1. SYSTEM LOGS
   → OS-level events (kernel, systemd, syslog)
   → Hardware events (disk, memory, CPU)
   → Service management (start, stop, restart)

2. APPLICATION LOGS
   → Application-specific events
   → Framework logs (Django, Spring, Express)
   → Business logic events

3. SECURITY LOGS
   → Authentication events (login, logout, failed)
   → Authorization events (access denied, forbidden)
   → Attack indicators (SQL injection, XSS, brute force)

4. ACCESS LOGS
   → Web server logs (Apache, Nginx)
   → API gateway logs
   → Load balancer logs

5. ERROR LOGS
   → Error messages and stack traces
   → Exception reports
   → Crash dumps

6. DATABASE LOGS
   → Query logs (slow queries, errors)
   → Connection pool events
   → Replication logs

7. NETWORK LOGS
   → Firewall logs
   → DNS logs
   → Proxy logs

Respond ONLY with valid JSON:
{{
  "primary_classification": "application_log",
  "secondary_classifications": [
    {{"type": "error_log", "confidence": 0.8}}
  ],
  "log_source_type": "python_application",
  "technologies_detected": ["Python", "Django", "PostgreSQL"],
  "confidence": 0.92,
  "classification_reasons": [
    "Contains Python stack traces",
    "Has Django-style log formatting",
    "Includes database query errors"
  ]
}}"""


# =============================================================================
# SKILL: Pattern Detection
# Used by: Finding recurring patterns and trends
# =============================================================================

SKILL_PATTERN_DETECTION = """You are detecting patterns in log data.

Log entries to analyze:
{log_entries}

Pattern categories to identify:

1. TEMPORAL PATTERNS
   → Time-based trends (errors spike at 3am?)
   → Day-of-week patterns (more errors on Mondays?)
   → Seasonal patterns (monthly billing cycle errors?)

2. FREQUENCY PATTERNS
   → Most common error messages
   → Most active components/services
   → Most frequent HTTP endpoints
   → Most common error codes

3. CORRELATION PATTERNS
   → Error A always precedes Error B
   → High CPU correlates with timeout errors
   → Deploy events correlate with error spikes

4. SEQUENCE PATTERNS
   → Common event sequences (login → search → purchase → logout)
   → Error chains (connection refused → retry → timeout → circuit open)

5. DISTRIBUTION PATTERNS
   → Error distribution across hosts (one bad host?)
   → Latency distribution (P50 vs P99 gap?)
   → Request distribution across endpoints

Respond ONLY with valid JSON:
{{
  "patterns_found": [
    {{
      "pattern_type": "temporal",
      "description": "Error rate doubles between 2am-4am UTC",
      "evidence": "42 errors in 2am-4am window vs 20 average for other 2-hour windows",
      "significance": "high",
      "confidence": 0.85
    }}
  ],
  "top_errors": [
    {{"message": "Connection timeout to database", "count": 45, "percentage": 30.0}}
  ],
  "top_components": [
    {{"component": "auth-service", "event_count": 150, "error_rate": 0.15}}
  ],
  "correlations_found": 3,
  "confidence": 0.88
}}"""


# =============================================================================
# SKILL: Anomaly Detection
# Used by: Identifying unusual events
# =============================================================================

SKILL_ANOMALY_DETECTION = """You are detecting anomalies in log data.

Log entries to analyze: {log_entries}
Baseline available: {has_baseline}

Anomaly types to detect:

1. VOLUME ANOMALIES
   → Sudden spike in error count
   → Sudden drop in traffic
   → Burst of log entries from single source

2. TYPE ANOMALIES
   → New error type never seen before
   → Error from component that's usually clean
   → Unexpected log level (ERROR where usually INFO)

3. BEHAVIORAL ANOMALIES
   → Unusual access patterns (off-hours, unusual IPs)
   → Changed error messages (same code, different message)
   → Missing expected log entries (heartbeat stopped)

4. STATISTICAL ANOMALIES
   → Value outside normal range (response time > 10x average)
   → Frequency outside normal distribution
   → Duration outside expected bounds

5. SECURITY ANOMALIES
   → Repeated failed authentication (brute force)
   → Access from suspicious IPs/geo-locations
   → Privilege escalation attempts
   → Data exfiltration patterns

Respond ONLY with valid JSON:
{{
  "anomalies_detected": [
    {{
      "type": "volume_anomaly",
      "description": "Error count spiked 500% above baseline at 10:32 UTC",
      "severity": "high",
      "affected_component": "payment-service",
      "evidence": "Error count: 150 (baseline: 30)",
      "confidence": 0.92
    }}
  ],
  "total_anomalies": 3,
  "requires_immediate_attention": true,
  "confidence": 0.89
}}"""


# =============================================================================
# SKILL: Severity Assessment
# Used by: Assessing criticality
# =============================================================================

SKILL_SEVERITY_ASSESSMENT = """You are assessing the severity of log events.

Analysis results: {analysis_results}
Error count: {error_count}
Affected components: {affected_components}

Severity levels:

CRITICAL (SEV1):
  → System completely down
  → Data loss or corruption occurring
  → Security breach in progress
  → Revenue loss > $X/hour

ERROR (SEV2):
  → Major feature broken
  → Significant performance degradation
  → Authentication failures for all users

WARNING (SEV3):
  → Minor feature degraded
  → Intermittent errors
  → Elevated error rate but still functional

INFO (SEV4):
  → Normal operations
  → Expected behavior

Respond ONLY with valid JSON:
{{
  "overall_severity": "ERROR",
  "severity_reasons": [
    "Payment processing failed for 15 minutes",
    "45 users affected",
    "Estimated revenue impact: $500"
  ],
  "impacted_services": ["payment-service", "order-service"],
  "user_impact": "Users unable to complete purchases",
  "estimated_affected_users": 45,
  "business_impact": "Revenue loss during outage window",
  "confidence": 0.90
}}"""


# =============================================================================
# SKILL: Technology Identification
# Used by: Identifying systems and technologies
# =============================================================================

SKILL_TECHNOLOGY_IDENTIFICATION = """You are identifying technologies from log patterns.

Log sample: {log_sample}

Technology signatures:

PYTHON:
  → Traceback (most recent call last)
  → File "path/to/file.py", line 42
  → django, flask, fastapi patterns

JAVA:
  → Exception in thread "main"
  → at com.company.Class.method(Class.java:42)
  → Spring Boot, Tomcat patterns

NODE.JS:
  → at Object.<anonymous> (/app/index.js:42:15)
  → Express.js, NestJS patterns
  → npm ERR! patterns

GO:
  → goroutine stack traces
  → panic: runtime error
  → main.main() patterns

DATABASES:
  → PostgreSQL: psycopg2, PostgresError
  → MySQL: mysql.connector, MySQLdb
  → MongoDB: pymongo, MongoError

Respond ONLY with valid JSON:
{{
  "primary_technology": "Python",
  "technologies": [
    {{"name": "Python", "version_hint": "3.10+", "confidence": 0.95}},
    {{"name": "Django", "version_hint": "4.x", "confidence": 0.85}},
    {{"name": "PostgreSQL", "confidence": 0.80}}
  ],
  "frameworks": ["Django REST Framework"],
  "deployment_type": "Docker container",
  "confidence": 0.90
}}"""