# agents/agent_config.py
"""
Agent Configuration - Configuration class for agents
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional


@dataclass
class AgentConfig:
    """Configuration for an agent"""
    agent_id: str
    name: str
    description: str
    version: str = "1.0.0"
    capabilities: List[str] = field(default_factory=list)
    model_type: str = "gemma"  # gemma, qwen, deepseek_ocr
    max_retries: int = 3
    timeout: int = 30
    temperature: float = 0.3
    max_tokens: int = 4096
    system_prompt: Optional[str] = None
    custom_config: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'AgentConfig':
        return cls(**data)