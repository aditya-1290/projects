# agents/debugger/agent.py (REDESIGNED - Model-Driven)
"""
Debugger Agent - Uses LLM to deeply analyze code, find bugs, and generate fixes
"""

from typing import Dict, Any, List, Optional
import logging
from datetime import datetime
import re

from agents.base_agent import BaseAgent, A2AMessage, MessageType, AgentState
from agents.agent_config import AgentConfig

logger = logging.getLogger(__name__)


class DebuggerAgent(BaseAgent):
    """
    Debugger agent that uses the LLM to understand code issues,
    trace bugs, analyze stack traces, and generate precise fixes.
    This agent excels at deep code reasoning and patch generation.
    """

    # agents/extractor/agent.py - FIXED __init__
    def __init__(self, agent_id: str = "debugger", capability_path: str = None, config=None, **kwargs):
        if hasattr(agent_id, 'agent_id') and hasattr(agent_id, 'capabilities'):
            config = agent_id
            agent_id = config.agent_id if hasattr(config, 'agent_id') else "debugger"
            if capability_path is None:
                capability_path = getattr(config, 'capability_path', None)
        elif config is not None:
            agent_id = config.agent_id if hasattr(config, 'agent_id') else "debugger"
            if capability_path is None:
                capability_path = getattr(config, 'capability_path', None)

        if capability_path is None:
            default_path = Path(__file__).parent / "capabilities.json"
            if default_path.exists():
                capability_path = str(default_path)

        super().__init__(agent_id=agent_id, capability_path=capability_path)

        # Debugger-specific state
        self.debugging_sessions = []
        self.code_context = {}
        self.bug_reports = []
        self._model = None

    def get_system_prompt(self) -> str:
        """Define the debugger's persona - a senior debugging expert"""
        return """
        You are an expert code debugger and software engineer with deep knowledge 
        of multiple programming languages, frameworks, and debugging techniques.

        Your expertise:
        - Python, JavaScript, Java, Go, Rust, C/C++, and more
        - Web frameworks (Django, Flask, FastAPI, Express, Spring)
        - Database systems and query optimization
        - System-level debugging and performance analysis
        - Security vulnerability identification
        - Memory management and concurrency issues

        Your debugging methodology:
        1. REPRODUCE: Understand how to trigger the bug
        2. ISOLATE: Narrow down the problematic code
        3. UNDERSTAND: Figure out why the bug occurs
        4. FIX: Generate a precise, minimal fix
        5. VERIFY: Ensure the fix actually resolves the issue
        6. PREVENT: Suggest how to avoid similar bugs

        When analyzing code:
        - Read the code carefully, line by line if needed
        - Trace the execution flow mentally
        - Identify edge cases the original developer might have missed
        - Consider race conditions, null checks, boundary conditions
        - Think about performance implications
        - Check for security vulnerabilities

        When generating fixes:
        - Provide the exact code changes (show before AND after)
        - Explain WHY the fix works
        - Mention any side effects or trade-offs
        - Include tests to verify the fix
        - Consider backward compatibility

        Be specific, precise, and thorough. Don't just say "fix the null pointer" - 
        show exactly what to change and why.
        """

    async def process(self, message: A2AMessage) -> A2AMessage:
        """
        Process incoming A2A message.
        This is the entry point called by the communication bus.
        It bridges A2A protocol to the agent's process_task logic.
        """

        # Handle capability queries
        if message.task and message.task.get("action") == "report_capabilities":
            return A2AMessage(
                message_type=MessageType.RESPONSE,
                sender_id=self.agent_id,
                sender_type=self.capability.agent_name,
                target_id=message.sender_id,
                correlation_id=message.message_id,
                response=self.capability.to_dict(),
                confidence=1.0
            )

        # Check if agent can handle this task
        task = message.task or {}
        if not self.can_handle(task):
            return A2AMessage(
                message_type=MessageType.RESPONSE,
                sender_id=self.agent_id,
                sender_type=self.capability.agent_name,
                target_id=message.sender_id,
                correlation_id=message.message_id,
                response={
                    "can_handle": False,
                    "reason": self.capability.out_of_scope_message,
                    "suggested_agents": self.capability.fallback_agents,
                    "my_capabilities": self.capability.capabilities
                },
                confidence=0.0
            )

        # Process the task using the agent's existing logic
        try:
            self.state = AgentState.PROCESSING

            # Convert A2A task format to what process_task expects
            task_input = {
                "input": task.get("input", task),
                "parameters": task.get("parameters", {}),
                "context": message.context or {}
            }

            # Call the agent's existing process_task method
            result = await self.process_task(task_input)

            self.state = AgentState.IDLE

            return A2AMessage(
                message_type=MessageType.RESPONSE,
                sender_id=self.agent_id,
                sender_type=self.capability.agent_name,
                target_id=message.sender_id,
                correlation_id=message.message_id,
                response=result,
                confidence=0.85
            )

        except Exception as e:
            self.state = AgentState.ERROR
            return A2AMessage(
                message_type=MessageType.ERROR,
                sender_id=self.agent_id,
                sender_type=self.capability.agent_name,
                target_id=message.sender_id,
                correlation_id=message.message_id,
                error=str(e)
            )

    async def process_task(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """
        Debug code or analyze errors by letting the model deeply reason.
        Can handle: stack traces, error logs, code snippets, bug descriptions
        """

        input_data = task.get("input", {})
        debug_type = input_data.get("debug_type", "auto")

        logger.info(f"Debugger processing {debug_type} task")

        # Route to appropriate debugging method based on input type
        if "stack_trace" in input_data or "traceback" in input_data:
            return await self._debug_stack_trace(input_data)
        elif "code" in input_data and "error" in input_data:
            return await self._debug_code_with_error(input_data)
        elif "code" in input_data:
            return await self._analyze_code(input_data)
        elif "bug_description" in input_data:
            return await self._hunt_bug(input_data)
        elif "performance" in input_data:
            return await self._analyze_performance(input_data)
        else:
            return await self._general_debugging(input_data)

    async def _debug_stack_trace(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Debug from a stack trace or error traceback"""

        stack_trace = data.get("stack_trace") or data.get("traceback", "")
        error_message = data.get("error_message", "")
        context_code = data.get("context_code", "")
        log_entries = data.get("log_entries", [])

        # Step 1: Understand the error
        error_analysis_prompt = {
            "task": "analyze_stack_trace",
            "error_message": error_message,
            "stack_trace": stack_trace,
            "questions": [
                "What type of error is this?",
                "What line of code is failing?",
                "What is the execution path that led to this error?",
                "What are the variable states likely to be at the crash point?",
                "Is this a logic error, runtime error, or something else?",
                "How severe is this bug?"
            ]
        }

        error_analysis = await self.think(error_analysis_prompt)

        # Step 2: If we have context code, analyze it deeply
        code_analysis = None
        if context_code:
            code_analysis_prompt = {
                "task": "analyze_problematic_code",
                "code": context_code,
                "error_analysis": error_analysis,
                "stack_trace": stack_trace,
                "questions": [
                    "What is this code supposed to do?",
                    "Where exactly is the bug?",
                    "What assumptions did the developer make that are wrong?",
                    "Are there any other potential bugs in this code?",
                    "What edge cases are not handled?"
                ]
            }

            code_analysis = await self.think(code_analysis_prompt)

        # Step 3: Generate the fix
        fix_prompt = {
            "task": "generate_bug_fix",
            "error_analysis": error_analysis,
            "code_analysis": code_analysis,
            "original_code": context_code,
            "questions": [
                "What is the minimal fix needed?",
                "Show the exact code change (BEFORE and AFTER)",
                "Why does this fix work?",
                "Are there alternative fixes? Compare them",
                "What are the trade-offs of this fix?",
                "How can we verify this fix works?"
            ]
        }

        fix = await self.think(fix_prompt)

        # Step 4: Generate tests
        test_prompt = {
            "task": "generate_tests",
            "bug_description": error_analysis,
            "fix": fix,
            "questions": [
                "What test cases would verify this fix?",
                "Include edge cases that might break",
                "What regression tests should be added?",
                "How to test both the happy path and error cases?"
            ]
        }

        tests = await self.think(test_prompt)

        # Step 5: Prevention advice
        prevention_prompt = {
            "task": "prevent_similar_bugs",
            "bug_details": {
                "error": error_analysis,
                "code": code_analysis,
                "fix": fix
            },
            "questions": [
                "What caused this bug? (root cause in development process)",
                "How could this have been caught earlier?",
                "What practices would prevent similar bugs?",
                "What linters, tests, or tools could help?",
                "What patterns should developers watch out for?"
            ]
        }

        prevention = await self.think(prevention_prompt)

        return {
            "success": True,
            "agent_id": self.agent_id,
            "debugging_result": {
                "error_analysis": error_analysis,
                "code_analysis": code_analysis,
                "fix": fix,
                "tests": tests,
                "prevention": prevention,
                "summary": await self._generate_summary(error_analysis, fix)
            },
            "timestamp": datetime.now().isoformat()
        }

    async def _debug_code_with_error(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Debug code when both code and error are provided"""

        code = data.get("code", "")
        error = data.get("error", "")
        language = data.get("language", "auto")

        # Step 1: Reproduce the error mentally
        reproduction_prompt = {
            "task": "reproduce_bug",
            "code": code,
            "error": error,
            "language": language,
            "questions": [
                "Execute this code mentally - what happens?",
                "What inputs would trigger this error?",
                "Can you trace the exact execution path?",
                "What state is the program in when it fails?",
                "Is this deterministic or intermittent?"
            ]
        }

        reproduction = await self.think(reproduction_prompt)

        # Step 2: Find the root cause
        root_cause_prompt = {
            "task": "find_root_cause",
            "code": code,
            "error": error,
            "reproduction": reproduction,
            "questions": [
                "What is the actual root cause, not just the symptom?",
                "Why was this bug introduced?",
                "Is it a logic error, syntax error, or misunderstanding?",
                "Are there multiple issues here?",
                "What's the simplest fix that addresses the root cause?"
            ]
        }

        root_cause = await self.think(root_cause_prompt)

        # Step 3: Generate and explain fix
        fix_prompt = {
            "task": "create_fix",
            "code": code,
            "root_cause": root_cause,
            "questions": [
                "Show the exact code changes needed",
                "Explain each change and why it's necessary",
                "Are there any side effects?",
                "What could go wrong with this fix?",
                "How to test this fix?"
            ]
        }

        fix = await self.think(fix_prompt)

        return {
            "success": True,
            "agent_id": self.agent_id,
            "debugging_result": {
                "reproduction": reproduction,
                "root_cause": root_cause,
                "fix": fix,
                "fixed_code": self._apply_fix(code, fix) if self._can_apply_fix(fix) else None
            },
            "timestamp": datetime.now().isoformat()
        }

    async def _analyze_code(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze code for potential issues without a specific error"""

        code = data.get("code", "")
        language = data.get("language", "auto")
        analysis_type = data.get("analysis_type", "general")

        # Comprehensive code review
        review_prompt = {
            "task": "code_review",
            "code": code,
            "language": language,
            "analysis_type": analysis_type,
            "review_aspects": [
                "BUGS: Are there any bugs or potential runtime errors?",
                "SECURITY: Are there security vulnerabilities?",
                "PERFORMANCE: Are there performance issues?",
                "EDGE_CASES: What edge cases are not handled?",
                "BEST_PRACTICES: Does this follow best practices?",
                "READABILITY: Is the code clear and maintainable?",
                "ERROR_HANDLING: Is error handling adequate?",
                "TYPE_SAFETY: Are there type-related issues?",
                "RESOURCE_MANAGEMENT: Are resources properly managed?",
                "CONCURRENCY: Are there race conditions or deadlocks?"
            ],
            "questions": [
                "Review each aspect and note any issues",
                "Prioritize issues by severity",
                "For each issue, explain why it's a problem",
                "Suggest specific improvements",
                "What's the overall code quality score (0-100)?"
            ]
        }

        code_review = await self.think(review_prompt)

        # If specific issues found, generate fixes
        fixes = None
        if "bug" in code_review.lower() or "issue" in code_review.lower():
            fixes_prompt = {
                "task": "fix_identified_issues",
                "code_review": code_review,
                "original_code": code,
                "questions": [
                    "For each issue identified, provide the fix",
                    "Show before and after code",
                    "Explain the impact of each fix",
                    "Which fixes should be prioritized?"
                ]
            }

            fixes = await self.think(fixes_prompt)

        return {
            "success": True,
            "agent_id": self.agent_id,
            "code_review": {
                "review": code_review,
                "fixes": fixes,
                "quality_score": self._extract_quality_score(code_review)
            },
            "timestamp": datetime.now().isoformat()
        }

    async def _hunt_bug(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Hunt for a bug based on description and symptoms"""

        bug_description = data.get("bug_description", "")
        symptoms = data.get("symptoms", [])
        codebase_context = data.get("codebase_context", "")
        reproduction_steps = data.get("reproduction_steps", "")

        # Step 1: Understand the bug
        understanding_prompt = {
            "task": "understand_bug_report",
            "description": bug_description,
            "symptoms": symptoms,
            "reproduction": reproduction_steps,
            "questions": [
                "What exactly is happening vs what should happen?",
                "What kind of bug does this sound like?",
                "What could cause these symptoms?",
                "What information is missing to diagnose this?",
                "What's your initial hypothesis?"
            ]
        }

        understanding = await self.think(understanding_prompt)

        # Step 2: Generate hypotheses
        hypothesis_prompt = {
            "task": "generate_hypotheses",
            "bug_understanding": understanding,
            "codebase": codebase_context,
            "questions": [
                "What are ALL possible causes for this bug?",
                "Rank hypotheses by likelihood",
                "For each hypothesis, what would confirm or rule it out?",
                "What should we check first?",
                "What debugging steps would you take?"
            ]
        }

        hypotheses = await self.think(hypothesis_prompt)

        # Step 3: Suggest debugging approach
        debugging_approach_prompt = {
            "task": "debugging_strategy",
            "hypotheses": hypotheses,
            "available_tools": ["print statements", "debugger", "logging", "profiler", "unit tests"],
            "questions": [
                "What's the most efficient debugging strategy?",
                "What logging should be added?",
                "What breakpoints should be set?",
                "What tests would help isolate the issue?",
                "How to systematically narrow down the cause?"
            ]
        }

        debugging_strategy = await self.think(debugging_approach_prompt)

        return {
            "success": True,
            "agent_id": self.agent_id,
            "bug_hunt": {
                "understanding": understanding,
                "hypotheses": hypotheses,
                "debugging_strategy": debugging_strategy,
                "next_steps": "Follow the debugging strategy to isolate the cause"
            },
            "timestamp": datetime.now().isoformat()
        }

    async def _analyze_performance(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze performance issues"""

        performance_data = data.get("performance", {})
        code = data.get("code", "")

        performance_prompt = {
            "task": "performance_analysis",
            "performance_metrics": performance_data,
            "code": code,
            "questions": [
                "Where are the performance bottlenecks?",
                "What's the time/space complexity?",
                "Are there unnecessary operations?",
                "What optimizations would have the biggest impact?",
                "Is there a memory leak?",
                "Are there slow database queries or I/O operations?",
                "What caching could be added?",
                "Would parallelization help?"
            ]
        }

        performance_analysis = await self.think(performance_prompt)

        return {
            "success": True,
            "agent_id": self.agent_id,
            "performance_analysis": performance_analysis,
            "timestamp": datetime.now().isoformat()
        }

    async def _general_debugging(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """General debugging - let the model figure out what to do"""

        general_prompt = {
            "task": "general_debugging",
            "provided_information": data,
            "questions": [
                "What debugging approach should we take?",
                "What information do you need that's missing?",
                "What's your assessment of the situation?",
                "What's the first thing you would check?"
            ]
        }

        debugging_plan = await self.think(general_prompt)

        return {
            "success": True,
            "agent_id": self.agent_id,
            "debugging_plan": debugging_plan,
            "message": "Please provide more specific information for detailed debugging",
            "timestamp": datetime.now().isoformat()
        }

    async def _generate_summary(self, error_analysis: str, fix: str) -> str:
        """Generate a concise summary for the user"""
        summary_prompt = {
            "task": "summarize_debugging",
            "error_analysis": error_analysis,
            "fix": fix,
            "question": "Summarize the bug and fix in 3-4 sentences for the developer."
        }

        return await self.think(summary_prompt)

    def _apply_fix(self, original_code: str, fix_description: str) -> Optional[str]:
        """Attempt to apply the fix described by the model"""
        # The model describes the fix - we could try to apply it
        # For safety, we just return None and let the user apply it
        return None

    def _can_apply_fix(self, fix_description: str) -> bool:
        """Check if fix can be automatically applied"""
        # Conservative approach - most fixes should be reviewed by humans
        return False

    def _extract_quality_score(self, review_text: str) -> int:
        """Extract quality score from review"""
        import re
        match = re.search(r'(\d+)[/\s]*100', review_text)
        if match:
            score = int(match.group(1))
            return min(max(score, 0), 100)
        return 70  # Default score