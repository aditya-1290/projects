# agents/debugger/tools.py (MINIMAL)
"""
Debugger Tools - Minimal utilities, model handles all debugging logic
"""

from typing import Dict, Any, List, Optional
import re


class DebuggerTools:
    """Minimal tools - model handles all debugging intelligence"""

    @staticmethod
    def extract_code_blocks(text: str) -> List[str]:
        """Extract code blocks from markdown formatted text"""
        pattern = r'```(?:\w+)?\n(.*?)```'
        matches = re.findall(pattern, text, re.DOTALL)
        return matches

    @staticmethod
    def detect_language(code: str) -> str:
        """Detect programming language from code"""
        indicators = {
            'python': ['def ', 'import ', 'print(', 'class ', 'self', 'None', 'elif '],
            'javascript': ['function', 'const ', 'let ', 'var ', 'console.log', '=>'],
            'java': ['public class', 'System.out', 'void ', 'String[]'],
            'go': ['func ', 'package ', 'fmt.', ':=', 'go '],
            'rust': ['fn ', 'let mut', 'impl ', 'use ', 'println!'],
        }

        scores = {}
        for lang, keywords in indicators.items():
            score = sum(1 for kw in keywords if kw in code)
            scores[lang] = score

        if scores:
            return max(scores, key=scores.get)
        return "unknown"

    @staticmethod
    def format_diff(original: str, modified: str) -> str:
        """Format a simple diff between two code versions"""
        original_lines = original.splitlines()
        modified_lines = modified.splitlines()

        diff = []
        for i, (orig, mod) in enumerate(zip(original_lines, modified_lines)):
            if orig != mod:
                diff.append(f"- {orig}")
                diff.append(f"+ {mod}")

        return '\n'.join(diff)