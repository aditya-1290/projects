# agents/debugger/code_parser.py
"""
Code Parser - Extracts and analyzes code structure for the Debugger Agent
This is a tool the agent uses, not hardcoded logic. The agent decides when and how to use it.
"""

import re
from typing import Dict, Any, List, Optional, Tuple
from pathlib import Path


class CodeParser:
    """
    Parses and extracts information from code to help the debugger understand it.
    The debugger agent decides what information it needs and uses these tools accordingly.
    """

    def __init__(self):
        self.language_patterns = {
            'python': {
                'function': r'def\s+(\w+)\s*\(([^)]*)\)\s*(?:->\s*(\w+))?\s*:',
                'class': r'class\s+(\w+)\s*(?:\(([^)]*)\))?\s*:',
                'import': r'(?:from\s+(\S+)\s+)?import\s+(.*)',
                'decorator': r'@(\w+)',
                'exception': r'except\s+(?:\w+,\s*)*(\w+)(?:\s+as\s+(\w+))?\s*:',
                'raise': r'raise\s+(\w+)',
                'variable': r'(\w+)\s*=\s*(.+)',
                'comment': r'#.*$',
                'docstring': r'""".*?"""|\'\'\'.*?\'\'\'',
            },
            'javascript': {
                'function': r'function\s+(\w+)\s*\(([^)]*)\)|(\w+)\s*=\s*(?:async\s*)?\(([^)]*)\)\s*=>',
                'class': r'class\s+(\w+)(?:\s+extends\s+(\w+))?\s*\{',
                'import': r'(?:import\s+.*?from\s+)?require\s*\(([^)]+)\)|import\s+.*?from\s+[\'"]([^\'"]+)[\'"]',
                'variable': r'(?:const|let|var)\s+(\w+)\s*=\s*(.+)',
                'comment': r'//.*$|/\*.*?\*/',
            },
            'java': {
                'function': r'(?:public|private|protected)?\s*(?:static)?\s*(?:final)?\s*\w+\s+(\w+)\s*\(([^)]*)\)',
                'class': r'(?:public\s+)?class\s+(\w+)(?:\s+extends\s+(\w+))?(?:\s+implements\s+(.*?))?\s*\{',
                'import': r'import\s+([^;]+);',
                'exception': r'catch\s*\((\w+)\s+(\w+)\)',
                'throw': r'throw\s+new\s+(\w+)',
            },
            'go': {
                'function': r'func\s+(?:\((\w+)\s+\*?(\w+)\)\s+)?(\w+)\s*\(([^)]*)\)\s*(?:\(?([^)]*)\)?\s*(?:\{|\w+))?',
                'struct': r'type\s+(\w+)\s+struct\s*\{',
                'import': r'import\s+(?:\((.*?)\)|"([^"]+)")',
            }
        }

    def extract_functions(self, code: str, language: str = 'python') -> List[Dict[str, Any]]:
        """
        Extract all function/method definitions from code.
        The agent uses this to understand what functions exist and find the problematic one.
        """
        patterns = self.language_patterns.get(language, {})
        func_pattern = patterns.get('function')

        if not func_pattern:
            return []

        functions = []
        lines = code.split('\n')

        for i, line in enumerate(lines, 1):
            match = re.search(func_pattern, line)
            if match:
                func_info = {
                    'name': match.group(1) or match.group(3) or 'unknown',
                    'line': i,
                    'line_content': line.strip(),
                    'parameters': match.group(2) or match.group(4) or '',
                    'return_type': match.group(3) if len(match.groups()) > 2 else None,
                }
                functions.append(func_info)

        return functions

    def extract_classes(self, code: str, language: str = 'python') -> List[Dict[str, Any]]:
        """
        Extract class definitions and their inheritance.
        """
        patterns = self.language_patterns.get(language, {})
        class_pattern = patterns.get('class')

        if not class_pattern:
            return []

        classes = []
        lines = code.split('\n')

        for i, line in enumerate(lines, 1):
            match = re.search(class_pattern, line)
            if match:
                class_info = {
                    'name': match.group(1),
                    'line': i,
                    'line_content': line.strip(),
                    'parent_class': match.group(2) if len(match.groups()) > 1 and match.group(2) else None,
                }
                classes.append(class_info)

        return classes

    def extract_imports(self, code: str, language: str = 'python') -> List[str]:
        """
        Extract all imports/dependencies.
        Helps understand what external libraries are being used.
        """
        patterns = self.language_patterns.get(language, {})
        import_pattern = patterns.get('import')

        if not import_pattern:
            return []

        imports = []
        for match in re.finditer(import_pattern, code, re.MULTILINE):
            imports.append(match.group(0).strip())

        return imports

    def find_error_handling(self, code: str, language: str = 'python') -> List[Dict[str, Any]]:
        """
        Find try-catch/except blocks and error handling code.
        Helps the agent understand what errors are being caught and where.
        """
        error_blocks = []

        if language == 'python':
            # Find try-except blocks
            try_pattern = r'try\s*:.*?except\s+(.*?)\s*:'
            for match in re.finditer(try_pattern, code, re.DOTALL):
                line_num = code[:match.start()].count('\n') + 1
                error_blocks.append({
                    'line': line_num,
                    'type': 'try_except',
                    'handles': match.group(1).strip(),
                    'content': match.group(0)
                })

            # Find raise statements
            raise_pattern = r'raise\s+(\w+)(?:\(([^)]*)\))?'
            for match in re.finditer(raise_pattern, code):
                line_num = code[:match.start()].count('\n') + 1
                error_blocks.append({
                    'line': line_num,
                    'type': 'raise',
                    'exception': match.group(1),
                    'message': match.group(2) if match.group(2) else ''
                })

        elif language in ['java', 'javascript']:
            # Find try-catch blocks
            catch_pattern = r'catch\s*\((\w+)\s+(\w+)\)\s*\{([^}]*)\}'
            for match in re.finditer(catch_pattern, code, re.DOTALL):
                line_num = code[:match.start()].count('\n') + 1
                error_blocks.append({
                    'line': line_num,
                    'type': 'catch',
                    'exception_type': match.group(1),
                    'variable': match.group(2),
                    'handler': match.group(3).strip()
                })

        return error_blocks

    def find_comments(self, code: str, language: str = 'python') -> List[Dict[str, Any]]:
        """
        Extract comments which often contain important context about the code.
        """
        patterns = self.language_patterns.get(language, {})
        comment_pattern = patterns.get('comment')

        if not comment_pattern:
            return []

        comments = []
        for match in re.finditer(comment_pattern, code, re.MULTILINE):
            line_num = code[:match.start()].count('\n') + 1
            comment_text = match.group(0).strip()

            # Skip very short comments
            if len(comment_text) > 3:
                comments.append({
                    'line': line_num,
                    'text': comment_text,
                    'is_todo': 'todo' in comment_text.lower() or 'fixme' in comment_text.lower(),
                    'is_hack': 'hack' in comment_text.lower() or 'workaround' in comment_text.lower(),
                })

        return comments

    def get_code_context(self, code: str, line_number: int, context_lines: int = 10) -> str:
        """
        Get surrounding context for a specific line.
        Helps the agent see what's around the problematic code.
        """
        lines = code.split('\n')
        start = max(0, line_number - context_lines - 1)
        end = min(len(lines), line_number + context_lines)

        context = []
        for i in range(start, end):
            marker = '>>>' if i == line_number - 1 else '   '
            context.append(f"{marker} {i + 1:4d} | {lines[i]}")

        return '\n'.join(context)

    def extract_variables(self, code: str, language: str = 'python') -> List[Dict[str, Any]]:
        """
        Extract variable assignments to understand data flow.
        """
        patterns = self.language_patterns.get(language, {})
        var_pattern = patterns.get('variable')

        if not var_pattern:
            return []

        variables = []
        lines = code.split('\n')

        for i, line in enumerate(lines, 1):
            match = re.search(var_pattern, line)
            if match:
                var_info = {
                    'line': i,
                    'name': match.group(1),
                    'value': match.group(2).strip() if len(match.groups()) > 1 else '',
                    'line_content': line.strip()
                }
                variables.append(var_info)

        return variables

    def detect_language(self, code: str) -> str:
        """
        Detect the programming language from the code.
        The agent uses this when it doesn't know the language upfront.
        """
        indicators = {
            'python': ['def ', 'import ', 'print(', 'class ', ':', 'self', 'None', 'elif ', 'from '],
            'javascript': ['function', 'const ', 'let ', 'var ', 'console.log', '=>', '===', 'undefined'],
            'java': ['public class', 'System.out', 'void ', 'String[]', 'extends ', 'implements'],
            'go': ['func ', 'package ', 'fmt.', ':=', 'go ', 'defer '],
            'rust': ['fn ', 'let mut', 'impl ', 'use ', 'println!', 'struct ', 'enum '],
            'typescript': [': string', ': number', ': boolean', 'interface ', 'type ', 'as '],
            'ruby': ['def ', 'end', 'puts ', 'class ', 'require ', 'attr_'],
            'php': ['<?php', 'function ', 'echo ', '->', 'namespace '],
        }

        scores = {}
        for lang, keywords in indicators.items():
            score = sum(1 for kw in keywords if kw in code)
            if score > 0:
                scores[lang] = score

        if not scores:
            return 'unknown'

        return max(scores, key=scores.get)

    def find_call_chain(self, code: str, function_name: str, language: str = 'python') -> List[Dict[str, Any]]:
        """
        Trace where a function is called from and what it calls.
        Helps understand the execution flow leading to an error.
        """
        callers = []
        callees = []

        if language == 'python':
            # Find where this function is called
            caller_pattern = re.compile(rf'(\w+)\s*\(\s*.*?\b{function_name}\b')
            callee_pattern = re.compile(rf'{function_name}\s*\(\s*')

        lines = code.split('\n')

        for i, line in enumerate(lines, 1):
            # Find callers
            if language == 'python':
                for match in re.finditer(rf'(\w+)\s*\([^)]*\b{function_name}\b', line):
                    callers.append({
                        'line': i,
                        'caller': match.group(1),
                        'called': function_name,
                        'context': line.strip()
                    })

            # Find what this function calls
            if language == 'python':
                if re.search(rf'\b{function_name}\s*\(', line):
                    # Find function calls within this line
                    calls = re.findall(r'(\w+)\s*\(', line)
                    for call in calls:
                        if call != function_name:
                            callees.append({
                                'line': i,
                                'calls': call,
                                'context': line.strip()
                            })

        return {
            'function': function_name,
            'called_by': callers,
            'calls_to': callees
        }

    def identify_bug_patterns(self, code: str, language: str = 'python') -> List[Dict[str, Any]]:
        """
        Identify common bug patterns in code.
        This gives the agent hints about potential issues, but the agent
        decides whether they're actually bugs based on context.
        """
        potential_issues = []

        if language == 'python':
            # Common Python bug patterns
            patterns = [
                (r'except\s*:', 'bare_except', 'Bare except clause catches all exceptions'),
                (r'except\s+Exception\s*:', 'broad_except', 'Catching Exception is too broad'),
                (r'==\s*None', 'none_comparison', 'Use "is None" instead of "== None"'),
                (r'!=\s*None', 'none_comparison', 'Use "is not None" instead of "!= None"'),
                (r'=\s*\[\]\s*\*\s*\d+', 'list_multiplication',
                 'List multiplication creates references to same object'),
                (r'defaultdict|mutable.*default.*arg', 'mutable_default',
                 'Mutable default argument can cause unexpected behavior'),
                (r'time\.sleep', 'sleep_in_code', 'Sleep in production code may indicate race condition'),
                (r'\.strip\(\)\s*==\s*[\'\"]', 'strip_then_compare', 'Check for None before calling strip()'),
            ]

        elif language == 'javascript':
            patterns = [
                (r'==(?!=)', 'loose_equality', 'Use === instead of == for strict comparison'),
                (r'var\s+', 'var_usage', 'Consider using const or let instead of var'),
                (r'eval\(', 'eval_usage', 'eval() is dangerous and should be avoided'),
                (r'setTimeout\(.*,\s*0\)', 'zero_timeout', 'setTimeout with 0ms may indicate hacky async handling'),
                (r'console\.log\(.*password', 'sensitive_logging', 'Password or sensitive data logged to console'),
            ]

        else:
            patterns = []

        lines = code.split('\n')
        for i, line in enumerate(lines, 1):
            for pattern, issue_type, description in patterns:
                if re.search(pattern, line):
                    potential_issues.append({
                        'line': i,
                        'type': issue_type,
                        'description': description,
                        'code': line.strip(),
                        'severity': 'warning'
                    })

        return potential_issues

    def structure_code_for_analysis(self, code: str, language: str = None) -> Dict[str, Any]:
        """
        Build a complete structural overview of the code.
        The agent uses this to understand the codebase before diving into debugging.
        """
        if not language:
            language = self.detect_language(code)

        return {
            'language': language,
            'total_lines': len(code.split('\n')),
            'functions': self.extract_functions(code, language),
            'classes': self.extract_classes(code, language),
            'imports': self.extract_imports(code, language),
            'error_handling': self.find_error_handling(code, language),
            'potential_issues': self.identify_bug_patterns(code, language),
            'has_tests': 'test' in code.lower() or 'unittest' in code.lower() or 'pytest' in code.lower(),
        }