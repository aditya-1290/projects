# agents/debugger/__init__.py
"""
Debugger Agent - Code analysis and debugging
"""

from .agent import DebuggerAgent

__all__ = ['DebuggerAgent']     