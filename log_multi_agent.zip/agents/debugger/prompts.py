# =============================================================================
# SKILL: Rust Debugging
# Used by: Step 4 when language = "rust"
# =============================================================================

SKILL_RUST_DEBUG = """You are a Rust language debugging expert.

Error details:
  Panic/Error: {error_type}: {error_message}
  File: {file}, Line: {line}
  Function: {function}

Code context (>>> = error line):
{context}

Rust-specific checks for {error_type}:

panic! / unwrap() on None/Err:
  → Replace unwrap() with ? operator or match
  → Use expect("context") instead of unwrap() for better error messages  
  → Check if Option/Result is being propagated correctly
  → Consider using combinators: map, and_then, or_else

borrow checker errors:
  → Cannot borrow as mutable more than once
  → Cannot borrow as immutable while mutable borrow exists  
  → Use Rc<RefCell<T>> or Arc<Mutex<T>> for shared mutable state
  → Consider restructuring to avoid the borrow conflict
  → Split borrows: borrow different fields separately

lifetime errors:
  → "does not live long enough" - value dropped while still referenced
  → Return references to stack data - use owned types instead
  → Missing lifetime annotations on structs/functions
  → 'static lifetime requirements for spawned threads

use of moved value:
  → Value used after being moved (into function or closure)
  → Clone the value before moving, or pass by reference
  → Check for PartialMove in struct patterns
  → Use .as_ref() or .as_mut() for Option/Result

Send/Sync errors:
  → Type is not Send (can't be transferred between threads)
  → Wrap in Arc<Mutex<T>> for thread-safe sharing
  → Use crossbeam or rayon for parallel processing
  → Check for Rc (not Send) vs Arc (Send + Sync)

unsafe block issues:
  → Raw pointer dereference without null check
  → FFI call with wrong signature
  → Missing safety documentation for unsafe contract
  → Undefined Behavior: use after free, dangling pointer, invalid pointer

Respond ONLY with valid JSON:
{{
  "rust_error_category": "unwrap_none|borrow_conflict|lifetime|move_after_use|send_sync|unsafe_violation|other",
  "root_cause": "precise explanation of why the Rust compiler/panic occurred",
  "fix_description": "what to change",
  "code_before": "exact snippet to replace",
  "code_after": "fixed snippet with proper ownership/borrowing",
  "fix_type": "null_check|ownership|borrowing|lifetime|type_change|other",
  "confidence": 0.85,
  "requires_architecture_change": false,
  "unsafe_alternative_available": false,
  "side_effects": "any risks from the ownership changes",
  "prevention": "how to avoid this class of Rust error",
  "clippy_lint": "relevant clippy lint that would catch this"
}}"""


# =============================================================================
# SKILL: Minified/Compiled/Bundled Code Debugging
# Used by: When error occurs in minified JavaScript or compiled code
# =============================================================================

SKILL_MINIFIED_CODE_DEBUG = """You are debugging minified, bundled, or compiled code.

Error: {error_type}: {error_message}
File reference: {file} (likely minified/bundled)
Line: {line}

Code context (may be minified/obfuscated):
{context}

Strategies for minified/compiled code:

1. USE SOURCE MAPS
   → Look for .map files in deployment directory
   → Use source-map library to reverse the mapping
   → Check if browser DevTools has original sources loaded
   → Check for //# sourceMappingURL= comment at end of bundle

2. IDENTIFY THE BUNDLE
   → webpack:// paths in stack → Webpack bundle
   → node_modules/ reference → third-party dependency
   → Look for recognizable function names in the minified output
   → Check for framework patterns (React.createElement, Vue.extend, etc.)

3. NARROW DOWN FAULT LOCATION
   → Which framework is being used? (React, Vue, Angular patterns)
   → Is this a third-party library error or application code?
   → Look for error boundaries, context providers, service workers
   → Check if error is in vendor chunk or main chunk

4. TYPICAL MINIFIED ERROR MAPPINGS
   → "e is undefined" → null/undefined reference
   → "Cannot read properties of undefined (reading 'X')" → missing data
   → "t is not a function" → calling non-function (wrong import?)
   → "Minified React error #XXX" → Look up at reactjs.org/docs/error-decoder.html

5. REPRODUCE LOCALLY
   → Build the app in dev mode (no minification)
   → Use the same data/inputs that triggered production error
   → Check browser console for unminified stack trace
   → Use React DevTools / Vue DevTools to inspect component tree

Respond ONLY with valid JSON:
{{
  "is_minified": true,
  "likely_bundler": "webpack|esbuild|rollup|vite|parcel|turbopack|unknown",
  "source_map_available": false,
  "source_map_path": null,
  "deobfuscation_hint": "what the minified function likely does based on context",
  "likely_original_location": "where in source code this probably maps to (component/file)",
  "is_third_party_library": false,
  "library_name": null,
  "framework_detected": "React|Vue|Angular|Svelte|Next.js|Nuxt|unknown",
  "reproduction_instructions": "how to reproduce with unminified code",
  "fix_direction": "where to look in source code and what kind of fix is needed",
  "confidence": 0.65,
  "note": "Confidence is lower for minified code. Verify with source maps or dev build."
}}"""