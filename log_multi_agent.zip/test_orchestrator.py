# test_orchestrator.py
import asyncio, sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))


async def test():
    from agents.orchestrator.agent import OrchestratorAgent
    from agents.base_agent import A2AMessage, MessageType

    # Load orchestrator
    cap_path = "agents/orchestrator/capabilities.json"
    orch = OrchestratorAgent(agent_id="orchestrator", capability_path=cap_path)

    # Load model
    from agentos.model_manager import ModelManager
    mm = ModelManager()
    orch.model = await mm.load_model("gemma")

    print(f"Model loaded: {orch.model is not None}")

    # Test with simple log
    msg = A2AMessage(
        message_type=MessageType.REQUEST,
        sender_id="test", sender_type="test",
        target_id="orchestrator",
        task={
            "action": "full_pipeline",
            "query": "Analyze this log",
            "input": {"text": "ERROR: Database connection failed", "source_type": "text"},
            "pipeline": ["extractor", "preprocessor", "analyzer"]
        }
    )

    print("Sending to orchestrator...")
    try:
        response = await orch.process(msg)
        print(f"Response: {response.response}")
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()


asyncio.run(test())