# tests/conftest.py
"""
Pytest configuration and shared fixtures
"""

import pytest
import asyncio
from pathlib import Path
from typing import Dict, Any
import json
import tempfile
import os


@pytest.fixture
def sample_logs():
    """Sample log data for testing"""
    return {
        "syslog": """Jan 15 10:30:15 server1 sshd[1234]: Failed password for root from 192.168.1.100 port 22 ssh2
Jan 15 10:30:18 server1 sshd[1234]: Failed password for root from 192.168.1.100 port 22 ssh2
Jan 15 10:30:22 server1 sshd[1234]: Failed password for root from 192.168.1.100 port 22 ssh2
Jan 15 10:30:25 server1 sshd[1234]: Connection closed by authenticating user root 192.168.1.100 port 22 [preauth]
Jan 15 10:31:01 server1 CRON[5678]: (root) CMD (cd / && run-parts --report /etc/cron.hourly)
Jan 15 10:32:00 server1 kernel: [12345.678] Out of memory: Kill process 9012 (python3) score 950 or sacrifice child
Jan 15 10:32:01 server1 kernel: [12345.679] Killed process 9012 (python3) total-vm:2048MB, anon-rss:1024MB
Jan 15 10:33:00 server1 nginx[3456]: 192.168.1.200 - - [15/Jan/2024:10:33:00 +0000] "POST /api/login HTTP/1.1" 500 1234
""",

        "json_logs": json.dumps([
            {"timestamp": "2024-01-15T10:30:15Z", "level": "ERROR", "message": "Database connection failed",
             "host": "db01"},
            {"timestamp": "2024-01-15T10:30:16Z", "level": "WARNING", "message": "Retrying connection (1/3)",
             "host": "db01"},
            {"timestamp": "2024-01-15T10:30:17Z", "level": "ERROR", "message": "Database connection failed",
             "host": "db01"},
            {"timestamp": "2024-01-15T10:30:18Z", "level": "CRITICAL", "message": "Max retries exceeded",
             "host": "db01"}
        ]),

        "apache_logs": """192.168.1.10 - - [15/Jan/2024:10:30:15 +0000] "GET /index.html HTTP/1.1" 200 2326
192.168.1.11 - - [15/Jan/2024:10:30:16 +0000] "POST /api/data HTTP/1.1" 500 1234
192.168.1.12 - - [15/Jan/2024:10:30:17 +0000] "GET /images/logo.png HTTP/1.1" 404 456
192.168.1.10 - - [15/Jan/2024:10:30:18 +0000] "GET /about.html HTTP/1.1" 200 3456
192.168.1.13 - - [15/Jan/2024:10:30:19 +0000] "GET /admin HTTP/1.1" 403 789
""",

        "python_error": """Traceback (most recent call last):
  File "/app/main.py", line 42, in process_data
    result = data['key'] / divisor
KeyError: 'key'
""",

        "empty_logs": "",

        "malformed_logs": "This is not a log entry\nNeither is this really\nSome random text here\n",
    }


@pytest.fixture
def sample_code():
    """Sample code for debugging tests"""
    return {
        "python_bug": '''def divide_numbers(a, b):
    return a / b

def process_list(items):
    result = []
    for i in range(len(items) + 1):
        result.append(items[i])
    return result
''',
        "python_fixed": '''def divide_numbers(a, b):
    if b == 0:
        raise ValueError("Cannot divide by zero")
    return a / b

def process_list(items):
    result = []
    for i in range(len(items)):
        result.append(items[i])
    return result
''',
        "javascript_bug": '''function getUser(id) {
    return users.find(user => user.id == id).name;
}
''',
    }


@pytest.fixture
def temp_dir():
    """Create a temporary directory for file operations"""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield Path(tmpdir)


@pytest.fixture
def event_loop():
    """Create event loop for async tests"""
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


@pytest.fixture
def mock_model_response():
    """Mock responses for model calls"""
    return {
        "analysis": """
Based on the log analysis:
1. Classification: These are system logs showing authentication failures and resource issues
2. Patterns: Multiple failed SSH attempts from same IP (192.168.1.100)
3. Anomalies: Out of memory event killing python process
4. Severity: HIGH - possible brute force attack and memory issues
5. Recommendations: Block IP 192.168.1.100, investigate memory usage
""",
        "solution": """
Root Cause: The database connection pool is exhausted due to connection leaks
Fix:
1. Check for unclosed connections in the codebase
2. Add connection timeout of 30 seconds
3. Implement connection pooling with max 20 connections
4. Add proper try-finally blocks to ensure connections are closed
""",
        "debug": """
Bug found in process_list function:
Line 5: for i in range(len(items) + 1)  # Bug: +1 causes IndexError
Fix: Change to: for i in range(len(items))

Bug in divide_numbers:
No zero division check
Fix: Add if b == 0 check before division
""",
    }