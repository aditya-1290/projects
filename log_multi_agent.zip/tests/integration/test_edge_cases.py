# tests/integration/test_edge_cases.py
"""
Integration tests for edge cases and error handling
"""

import pytest
import asyncio
from unittest.mock import Mock, AsyncMock, patch

from agents.extractor.agent import ExtractorAgent
from agents.preprocessor.agent import PreprocessorAgent
from agents.analyzer.agent import AnalyzerAgent
from agents.agent_config import AgentConfig


class TestEdgeCases:
    """Test handling of edge cases"""

    @pytest.fixture
    def extractor(self):
        return ExtractorAgent(
            AgentConfig(
                agent_id="ext_edge",
                name="Edge Extractor",
                description="",
                capabilities=["extract_from_text"]
            )
        )

    @pytest.fixture
    def preprocessor(self):
        return PreprocessorAgent(
            AgentConfig(
                agent_id="prep_edge",
                name="Edge Preprocessor",
                description="",
                capabilities=["clean_logs", "normalize_logs"]
            )
        )

    @pytest.fixture
    def analyzer(self):
        return AnalyzerAgent(
            AgentConfig(
                agent_id="analyzer_edge",
                name="Edge Analyzer",
                description="",
                capabilities=["classify_logs"]
            )
        )

    @pytest.mark.asyncio
    async def test_empty_input(self, extractor):
        """Test handling of empty input"""
        with patch.object(extractor, 'think', return_value="No data to extract"):
            result = await extractor.process_task({
                "input": {"text": ""}
            })

            # Should handle gracefully
            assert result is not None

    @pytest.mark.asyncio
    async def test_very_large_input(self, extractor, sample_logs):
        """Test handling of large inputs"""
        # Create large input by repeating
        large_text = sample_logs["syslog"] * 10000

        with patch.object(extractor, 'think', return_value="Large extraction complete"):
            result = await extractor.process_task({
                "input": {"text": large_text}
            })

            assert result is not None

    @pytest.mark.asyncio
    async def test_malformed_logs(self, preprocessor, sample_logs):
        """Test handling of malformed logs"""
        with patch.object(preprocessor, 'think', return_value="Unable to determine format"):
            result = await preprocessor.process_task({
                "input": {"raw_content": sample_logs["malformed_logs"]}
            })

            # Should not crash
            assert result is not None

    @pytest.mark.asyncio
    async def test_mixed_format_logs(self, preprocessor, sample_logs):
        """Test handling of mixed format logs"""
        mixed = sample_logs["syslog"] + "\n" + sample_logs["apache_logs"]

        with patch.object(preprocessor, 'think',
                          return_value="Multiple formats detected"):
            result = await preprocessor.process_task({
                "input": {"raw_content": mixed}
            })

            assert result is not None

    @pytest.mark.asyncio
    async def test_unknown_log_type(self, analyzer):
        """Test classification of unknown log types"""
        unknown_log = "xyz123 random text that doesnt match any pattern\nabc456 more random stuff"

        with patch.object(analyzer, 'think',
                          return_value="Classification: unknown, Confidence: low"):
            result = await analyzer.process_task({
                "input": {
                    "entries": [{"message": unknown_log}]
                }
            })

            assert result is not None

    @pytest.mark.asyncio
    async def test_unicode_and_encoding(self, preprocessor):
        """Test handling of unicode and special characters"""
        unicode_logs = """
        2024-01-15 INFO: User café logged in ✓
        2024-01-15 ERROR: Invalid character: \x00\x01\x02
        2024-01-15 WARNING: Encoding issue: ���
        """

        with patch.object(preprocessor, 'think',
                          return_value="Encoding issues detected and fixed"):
            result = await preprocessor.process_task({
                "input": {"raw_content": unicode_logs}
            })

            assert result is not None

    @pytest.mark.asyncio
    async def test_concurrent_requests(self, extractor):
        """Test handling of concurrent requests"""
        tasks = []

        for i in range(5):
            task = extractor.process_task({
                "input": {"text": f"Log entry {i}"}
            })
            tasks.append(task)

        with patch.object(extractor, 'think', return_value="Extracted"):
            results = await asyncio.gather(*tasks)

            assert len(results) == 5
            for result in results:
                assert result is not None

    @pytest.mark.asyncio
    async def test_agent_timeout_handling(self):
        """Test handling when agent takes too long"""

        async def slow_agent():
            await asyncio.sleep(5)
            return {"result": "too late"}

        try:
            result = await asyncio.wait_for(slow_agent(), timeout=0.1)
            pytest.fail("Should have timed out")
        except asyncio.TimeoutError:
            # Expected behavior
            pass

    @pytest.mark.asyncio
    async def test_permission_denied(self):
        """Test handling of permission denied scenarios"""
        from safety.permission_manager import PermissionManager, PermissionLevel

        pm = PermissionManager()
        pm.register_agent("limited_agent", {
            'file_access': PermissionLevel.NONE,
            'terminal_access': PermissionLevel.NONE,
        })

        assert not pm.can_read_file("limited_agent", "/var/log/syslog")
        assert not pm.can_execute_command("limited_agent", "cat /var/log/syslog")
        assert not pm.can_write_file("limited_agent", "/tmp/output.txt")