# tests/integration/test_model_switching.py
"""
Integration tests for model switching and management
"""

import pytest
from unittest.mock import Mock, patch

from models.manager import ModelManager
from models.model_configs import ModelConfigs
from models.llm.gemma import GemmaModel
from models.llm.qwen import QwenModel


class TestModelSwitching:
    """Test model loading and switching"""

    @pytest.fixture
    def model_manager(self):
        """Create a model manager instance"""
        with patch('models.manager.ModelManager._check_available_models',
                   return_value={'gemma': True, 'qwen': True, 'deepseek_ocr': True}):
            manager = ModelManager()
            return manager

    @pytest.mark.asyncio
    async def test_get_model_config(self):
        """Test retrieving model configurations"""
        gemma_config = ModelConfigs.get_config('gemma')
        assert gemma_config is not None
        assert gemma_config.name == 'qwen2.5-3b-instruct-q4_k_m.gguf'
        assert gemma_config.type == 'llm'

        qwen_config = ModelConfigs.get_config('qwen')
        assert qwen_config is not None
        assert qwen_config.name == 'qwen-2.5-3b-instruct'

    @pytest.mark.asyncio
    async def test_model_assignment_to_agents(self, model_manager):
        """Test assigning appropriate models to agents"""

        agent_types = {
            'extractor': 'deepseek_ocr',
            'preprocessor': 'qwen',
            'analyzer': 'gemma',
            'solver': 'gemma',
            'debugger': 'gemma',
            'critic': 'gemma',
            'memory': 'qwen',
            'orchestrator': 'gemma',
        }

        for agent_type, expected_model in agent_types.items():
            model_key = model_manager.assign_model_to_agent(agent_type)
            assert model_key == expected_model, \
                f"Agent {agent_type} should use {expected_model}, got {model_key}"

    @pytest.mark.asyncio
    async def test_model_info(self, model_manager):
        """Test getting model information"""
        info = model_manager.get_model_info('gemma')

        assert info is not None
        assert info['key'] == 'gemma'
        assert info['type'] == 'llm'
        assert 'is_available' in info
        assert 'is_loaded' in info

    @pytest.mark.asyncio
    async def test_load_unload_models(self, model_manager):
        """Test loading and unloading models"""

        # Mock the actual loading
        with patch.object(model_manager, '_load_gguf_model',
                          return_value={'type': 'llm', 'status': 'loaded'}):
            # Load a model
            model = await model_manager.load_model('gemma')
            assert model is not None
            assert model_manager.is_loaded('gemma')

            # Unload the model
            await model_manager.unload_model('gemma')
            assert not model_manager.is_loaded('gemma')

    @pytest.mark.asyncio
    async def test_unavailable_model(self, model_manager):
        """Test handling of unavailable models"""
        model_manager.available_models['gemma'] = False

        model = await model_manager.load_model('gemma')
        assert model is None

    def test_model_config_updates(self):
        """Test updating model configurations"""
        ModelConfigs.update_config('gemma', temperature=0.5)

        config = ModelConfigs.get_config('gemma')
        assert config.temperature == 0.5

        # Reset
        ModelConfigs.update_config('gemma', temperature=0.3)