# tests/integration/test_a2a_communication.py (FIXED)
"""
Integration tests for Agent-to-Agent communication
"""

import pytest
import asyncio
from unittest.mock import Mock, AsyncMock, patch

from communication.a2a_protocol import A2AProtocol
from communication.message_broker import MessageBroker
from communication.discovery import ServiceDiscovery
from communication.schemas import (
    AgentMessage, MessageSchemas, MessageType, MessagePriority
)


class TestA2ACommunication:
    """Test Agent-to-Agent communication protocol"""

    @pytest.fixture
    async def broker(self):
        """Create a message broker"""
        broker = MessageBroker()
        await broker.start()
        yield broker
        await broker.stop()

    @pytest.fixture
    async def discovery(self):
        """Create service discovery"""
        return ServiceDiscovery()

    @pytest.fixture
    async def protocol_a(self, broker, discovery):
        """Create A2A protocol for agent A"""
        protocol = A2AProtocol(broker=broker, discovery=discovery)
        await protocol.initialize(
            agent_id="agent_a",
            agent_name="Agent A",
            capabilities=["log_analysis", "pattern_detection"]
        )
        return protocol

    @pytest.fixture
    async def protocol_b(self, broker, discovery):
        """Create A2A protocol for agent B"""
        protocol = A2AProtocol(broker=broker, discovery=discovery)
        await protocol.initialize(
            agent_id="agent_b",
            agent_name="Agent B",
            capabilities=["code_debugging", "fix_generation"]
        )
        return protocol

    @pytest.mark.asyncio
    async def test_agent_registration(self, protocol_a, protocol_b, discovery):
        """Test agents can register and discover each other"""
        agents = discovery.get_active_agents()

        assert len(agents) >= 2
        agent_ids = [a.agent_id for a in agents]
        assert "agent_a" in agent_ids
        assert "agent_b" in agent_ids

    @pytest.mark.asyncio
    async def test_capability_discovery(self, protocol_a, discovery):
        """Test finding agents by capability"""
        # FIX: register() is NOT async - remove 'await'
        discovery.register(
            agent_id="agent_a",
            agent_name="Agent A",
            capabilities=["log_analysis"]
        )

        # Find by capability - NOT async
        analyzers = discovery.find_by_capability("log_analysis")
        assert len(analyzers) >= 1
        assert any(a.agent_id == "agent_a" for a in analyzers)

        # Non-existent capability
        cooks = discovery.find_by_capability("cooking")
        assert len(cooks) == 0

    @pytest.mark.asyncio
    async def test_send_task_request(self, protocol_a, protocol_b, broker):
        """Test sending a task from one agent to another"""

        # Set up response handler on agent B
        response_received = asyncio.Future()

        async def handle_task(message: AgentMessage):
            task = message.content
            assert task.get('task_type') == "test_task"

            # Send response back
            response = MessageSchemas.create_task_response(
                sender="agent_b",
                receiver=message.sender,
                task_id=task.get('task_id', ''),
                result={"status": "completed", "data": "test result"}
            )
            response.correlation_id = message.id
            await broker.send(response)

        protocol_b.register_handler(MessageType.TASK_REQUEST, handle_task)

        # Send task from A to B
        response = await protocol_a.send_task(
            target_agent="agent_b",
            task_type="test_task",
            input_data={"test": "data"},
            wait_for_response=True,
            timeout=5.0
        )

        assert response is not None
        assert response.message_type == MessageType.TASK_RESPONSE

    @pytest.mark.asyncio
    async def test_message_broadcast(self, protocol_a, protocol_b, broker):
        """Test broadcasting messages to all agents"""

        received_by_b = asyncio.Future()

        async def handle_broadcast(message: AgentMessage):
            if message.message_type == MessageType.STATUS_UPDATE:
                received_by_b.set_result(message)

        protocol_b.register_handler(MessageType.STATUS_UPDATE, handle_broadcast)

        # Broadcast from A
        broadcast_msg = AgentMessage(
            sender="agent_a",
            receiver="broadcast",
            message_type=MessageType.STATUS_UPDATE,
            content={"status": "testing"}
        )

        await broker.send(broadcast_msg)

        # Wait for B to receive
        try:
            result = await asyncio.wait_for(received_by_b, timeout=2.0)
            assert result.content == {"status": "testing"}
        except asyncio.TimeoutError:
            pytest.fail("Broadcast message not received")

    @pytest.mark.asyncio
    async def test_request_timeout(self, protocol_a, broker):
        """Test handling of request timeouts"""

        # Send to non-responsive agent
        response = await protocol_a.send_task(
            target_agent="nonexistent_agent",
            task_type="test_task",
            input_data={},
            wait_for_response=True,
            timeout=1.0
        )

        assert response is None

    @pytest.mark.asyncio
    async def test_error_handling(self, protocol_a, protocol_b, broker):
        """Test error message handling"""

        error_received = asyncio.Future()

        async def handle_error(message: AgentMessage):
            if message.message_type == MessageType.ERROR:
                error_received.set_result(message)

        protocol_b.register_handler(MessageType.ERROR, handle_error)

        # Send error from A
        await protocol_a.report_error(
            target_agent="agent_b",
            error="Test error message",
            details={"code": 500}
        )

        try:
            error_msg = await asyncio.wait_for(error_received, timeout=2.0)
            assert "Test error message" in error_msg.content.get('error', '')
        except asyncio.TimeoutError:
            pytest.fail("Error message not received")