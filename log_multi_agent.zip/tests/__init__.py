# tests/__init__.py
"""
Tests - Test suite for the multi-agent log analysis system
"""

import pytest