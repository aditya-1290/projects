# tests/e2e/test_full_pipeline.py
"""
End-to-end tests for the complete log analysis pipeline
"""

import pytest
import asyncio
from unittest.mock import Mock, AsyncMock, patch

from agents.orchestrator.agent import OrchestratorAgent
from agents.agent_config import AgentConfig


class TestFullPipeline:
    """End-to-end tests for complete workflows"""

    @pytest.fixture
    def orchestrator(self):
        """Create an orchestrator for end-to-end testing"""
        orchestrator = OrchestratorAgent(
            AgentConfig(
                agent_id="orchestrator_e2e",
                name="E2E Orchestrator",
                description="End-to-end test orchestrator",
                capabilities=[
                    "coordinate_agents", "plan_workflow",
                    "route_tasks", "validate_outputs"
                ],
                model_type="gemma"
            )
        )

        # Mock all agent communications
        orchestrator._has_agent = Mock(return_value=True)
        orchestrator._delegate_to_agent = AsyncMock(return_value={
            "success": True,
            "result": "Mocked agent result"
        })

        return orchestrator

    @pytest.mark.asyncio
    async def test_simple_log_analysis_flow(self, orchestrator, sample_logs):
        """Test: User provides logs → system analyzes and provides insights"""

        user_request = {
            "query": "Analyze these logs for errors",
            "text": sample_logs["syslog"],
            "source_type": "text"
        }

        with patch.object(orchestrator, 'think',
                          return_value="Analysis workflow planned"):
            result = await orchestrator.process_task({
                "input": user_request
            })

            assert result["success"]
            assert "workflow_plan" in result

    @pytest.mark.asyncio
    async def test_error_investigation_flow(self, orchestrator, sample_logs):
        """Test: User reports error → system debugs and provides solution"""

        user_request = {
            "query": "My application keeps crashing with KeyError",
            "error_message": "KeyError: 'key'",
            "logs": sample_logs["python_error"],
            "context": "Running Python web application"
        }

        with patch.object(orchestrator, 'think',
                          return_value="Debug workflow planned"):
            result = await orchestrator.process_task({
                "input": user_request
            })

            assert result["success"]

    @pytest.mark.asyncio
    async def test_security_analysis_flow(self, orchestrator, sample_logs):
        """Test: Detect security issues in logs"""

        user_request = {
            "query": "Check these logs for security issues",
            "logs": sample_logs["syslog"],  # Contains failed SSH attempts
            "focus": "security"
        }

        with patch.object(orchestrator, 'think',
                          return_value="Security analysis workflow planned"):
            result = await orchestrator.process_task({
                "input": user_request
            })

            assert result["success"]

    @pytest.mark.asyncio
    async def test_multi_step_reasoning_flow(self, orchestrator):
        """Test chain-of-thought multi-step reasoning"""

        user_request = {
            "query": "My database is slow and users are getting timeout errors. "
                     "This started after the last deployment. Help me figure out what's wrong.",
            "context": "Production environment, PostgreSQL database"
        }

        # Simulate multi-step reasoning
        think_responses = [
            "Step 1: Understand the problem - Database slowdown after deployment",
            "Step 2: Plan workflow - Extract deployment logs, analyze patterns, check database logs",
            "Step 3: Coordinate agents - Extractor → Preprocessor → Analyzer → Solver",
            "Step 4: Validate results - Check if solution addresses root cause"
        ]

        with patch.object(orchestrator, 'think', side_effect=think_responses):
            result = await orchestrator.process_task({
                "input": user_request
            })

            assert result["success"]

    @pytest.mark.asyncio
    async def test_clarification_flow(self, orchestrator):
        """Test when orchestrator needs to ask for clarification"""

        user_request = {
            "query": "It's broken",
            "logs": None,
            "context": None
        }

        with patch.object(orchestrator, 'think',
                          return_value="Need clarification: What system is broken? What errors are you seeing?"):
            result = await orchestrator.process_task({
                "input": user_request
            })

            # Should ask for clarification, not fail
            assert result is not None

    @pytest.mark.asyncio
    async def test_iterative_improvement_flow(self, orchestrator):
        """Test iteration when first attempt needs improvement"""

        user_request = {
            "query": "Find the root cause of the intermittent failures"
        }

        # First attempt not good enough
        think_responses = [
            "Initial workflow plan",
            "Validation shows needs improvement",
            "Revised approach with more detailed analysis"
        ]

        with patch.object(orchestrator, 'think', side_effect=think_responses):
            # Mock critic saying needs revision
            orchestrator._validate_results = AsyncMock(return_value={
                "validation_result": "REVISE - Needs more detailed analysis",
                "needs_improvement": True,
                "iteration_count": 1
            })

            result = await orchestrator.process_task({
                "input": user_request
            })

            assert result["success"]

    @pytest.mark.asyncio
    async def test_performance_under_load(self, orchestrator):
        """Test system handles multiple requests"""

        requests = []
        for i in range(10):
            requests.append({
                "query": f"Analyze log set {i}",
                "text": f"Sample log data {i}"
            })

        with patch.object(orchestrator, 'think', return_value="Workflow planned"):
            tasks = [
                orchestrator.process_task({"input": req})
                for req in requests
            ]

            results = await asyncio.gather(*tasks)

            assert len(results) == 10
            assert all(r["success"] for r in results)