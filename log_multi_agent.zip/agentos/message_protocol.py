# agentos/message_protocol.py
"""
Message Protocol - Defines the A2A (Agent-to-Agent) communication protocol
"""

from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from enum import Enum
import json


class TaskStatus(Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class AgentTask:
    """Task definition for agent operations"""
    task_id: str
    task_type: str
    agent_id: str
    input_data: Any
    parameters: Dict[str, Any]
    status: TaskStatus = TaskStatus.PENDING
    result: Any = None
    error: Optional[str] = None

    def to_dict(self) -> Dict:
        return {
            "task_id": self.task_id,
            "task_type": self.task_type,
            "agent_id": self.agent_id,
            "input_data": self.input_data,
            "parameters": self.parameters,
            "status": self.status.value,
            "result": self.result,
            "error": self.error
        }


class A2AProtocol:
    """Agent-to-Agent communication protocol"""

    MESSAGE_TYPES = {
        "TASK_REQUEST": "task_request",
        "TASK_RESPONSE": "task_response",
        "CAPABILITY_QUERY": "capability_query",
        "CAPABILITY_RESPONSE": "capability_response",
        "STATUS_UPDATE": "status_update",
        "HEARTBEAT": "heartbeat",
        "ERROR": "error",
        "DATA_TRANSFER": "data_transfer"
    }

    @staticmethod
    def create_task_request(agent_id: str, task_type: str, input_data: Any, parameters: Dict = None) -> Dict:
        """Create a task request message"""
        return {
            "protocol": "a2a_v1",
            "message_type": A2AProtocol.MESSAGE_TYPES["TASK_REQUEST"],
            "agent_id": agent_id,
            "task": {
                "type": task_type,
                "input": input_data,
                "parameters": parameters or {}
            }
        }

    @staticmethod
    def create_capability_query() -> Dict:
        """Create a capability query message"""
        return {
            "protocol": "a2a_v1",
            "message_type": A2AProtocol.MESSAGE_TYPES["CAPABILITY_QUERY"]
        }

    @staticmethod
    def create_capability_response(capabilities: List[str], agent_info: Dict = None) -> Dict:
        """Create a capability response message"""
        return {
            "protocol": "a2a_v1",
            "message_type": A2AProtocol.MESSAGE_TYPES["CAPABILITY_RESPONSE"],
            "capabilities": capabilities,
            "agent_info": agent_info or {}
        }

    @staticmethod
    def validate_message(message: Dict) -> bool:
        """Validate if a message follows the A2A protocol"""
        required_fields = ["protocol", "message_type"]
        return all(field in message for field in required_fields)