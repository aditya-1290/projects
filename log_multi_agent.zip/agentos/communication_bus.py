# agentos/communication_bus.py (FIXED)
"""
Communication Bus - Message passing system between agents
Handles agent registration, message routing, and request-response
"""

from typing import Dict, List, Any, Callable, Optional
from dataclasses import dataclass, field
from datetime import datetime
import asyncio
import json
import uuid
from enum import Enum
import logging

logger = logging.getLogger(__name__)


class MessagePriority(Enum):
    LOW = 1
    NORMAL = 2
    HIGH = 3
    CRITICAL = 4


class MessageType(Enum):
    TASK_REQUEST = "task_request"
    TASK_RESPONSE = "task_response"
    CAPABILITY_QUERY = "capability_query"
    CAPABILITY_RESPONSE = "capability_response"
    STATUS_UPDATE = "status_update"
    HEARTBEAT = "heartbeat"
    ERROR = "error"
    DATA_TRANSFER = "data_transfer"
    AGENT_REGISTER = "agent_register"
    AGENT_UNREGISTER = "agent_unregister"


@dataclass
class Message:
    """Message structure for inter-agent communication"""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    sender: str = ""
    receiver: str = ""
    message_type: MessageType = MessageType.TASK_REQUEST
    content: Any = None
    priority: MessagePriority = MessagePriority.NORMAL
    timestamp: datetime = field(default_factory=datetime.now)
    correlation_id: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "sender": self.sender,
            "receiver": self.receiver,
            "message_type": self.message_type.value if hasattr(self.message_type, 'value') else str(self.message_type),
            "content": self.content,
            "priority": self.priority.value if hasattr(self.priority, 'value') else 2,
            "timestamp": self.timestamp.isoformat(),
            "correlation_id": self.correlation_id,
            "metadata": self.metadata
        }

    @classmethod
    def from_dict(cls, data: Dict) -> 'Message':
        msg_type = data.get("message_type", "task_request")
        if isinstance(msg_type, str):
            try:
                msg_type = MessageType(msg_type)
            except ValueError:
                msg_type = MessageType.TASK_REQUEST

        priority = data.get("priority", 2)
        if isinstance(priority, int):
            try:
                priority = MessagePriority(priority)
            except ValueError:
                priority = MessagePriority.NORMAL

        return cls(
            id=data.get("id", str(uuid.uuid4())),
            sender=data.get("sender", ""),
            receiver=data.get("receiver", ""),
            message_type=msg_type,
            content=data.get("content"),
            priority=priority,
            timestamp=datetime.fromisoformat(data["timestamp"]) if "timestamp" in data else datetime.now(),
            correlation_id=data.get("correlation_id"),
            metadata=data.get("metadata", {})
        )


class CommunicationBus:
    """
    Asynchronous communication bus for agent messaging.
    Handles agent registration, message routing, and request-response patterns.
    """

    def __init__(self):
        # Message subscribers: agent_id -> [callback functions]
        self._subscribers: Dict[str, List[Callable]] = {}

        # Type-based subscribers: message_type -> [callback functions]
        self._type_subscribers: Dict[str, List[Callable]] = {}

        # Registered agents: agent_id -> agent_info
        self._registered_agents: Dict[str, Dict[str, Any]] = {}

        # Message queue
        self._message_queue: asyncio.Queue = asyncio.Queue()

        # Pending requests (for request-response pattern)
        self._pending_requests: Dict[str, asyncio.Future] = {}

        # Message history
        self._message_history: List[Message] = []
        self._max_history = 1000

        # State
        self._active = False
        self._processing_task = None

    # ============================================
    # Lifecycle
    # ============================================

    async def start(self):
        """Start the communication bus"""
        if self._active:
            logger.warning("Communication bus already running")
            return

        self._active = True
        self._processing_task = asyncio.create_task(self._process_messages())
        logger.info("Communication bus started")

    async def stop(self):
        """Stop the communication bus"""
        self._active = False

        if self._processing_task:
            self._processing_task.cancel()
            try:
                await self._processing_task
            except asyncio.CancelledError:
                pass

        # Cancel all pending requests
        for future in self._pending_requests.values():
            if not future.done():
                future.set_exception(Exception("Communication bus shutting down"))

        self._pending_requests.clear()
        logger.info("Communication bus stopped")

    async def _process_messages(self):
        """Process messages from the queue"""
        while self._active:
            try:
                message = await asyncio.wait_for(
                    self._message_queue.get(),
                    timeout=1.0
                )
                await self._route_message(message)

                # Store in history
                self._message_history.append(message)
                if len(self._message_history) > self._max_history:
                    self._message_history = self._message_history[-self._max_history:]

            except asyncio.TimeoutError:
                continue
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Message processing error: {e}")

    # ============================================
    # Agent Registration
    # ============================================

    def register_agent(self, agent_id: str, agent_info: Dict[str, Any] = None,
                       message_handler: Callable = None) -> bool:
        """
        Register an agent with the communication bus.

        Args:
            agent_id: Unique identifier for the agent
            agent_info: Metadata about the agent (name, capabilities, etc.)
            message_handler: Callback function for handling messages

        Returns:
            True if registration successful
        """
        if agent_id in self._registered_agents:
            logger.warning(f"Agent {agent_id} already registered. Updating...")

        # Store agent info
        self._registered_agents[agent_id] = {
            "agent_id": agent_id,
            "info": agent_info or {},
            "registered_at": datetime.now().isoformat(),
            "status": "registered"
        }

        # Subscribe to messages if handler provided
        if message_handler:
            self.subscribe(agent_id, message_handler)

        logger.info(f"Agent registered: {agent_id}")
        return True

    def unregister_agent(self, agent_id: str):
        """Remove an agent from the bus"""
        if agent_id in self._registered_agents:
            del self._registered_agents[agent_id]

        if agent_id in self._subscribers:
            del self._subscribers[agent_id]

        logger.info(f"Agent unregistered: {agent_id}")

    def get_registered_agents(self) -> Dict[str, Dict[str, Any]]:
        """Get all registered agents"""
        return self._registered_agents.copy()

    def get_agent_info(self, agent_id: str) -> Optional[Dict[str, Any]]:
        """Get info for a specific agent"""
        agent_data = self._registered_agents.get(agent_id, {})
        return agent_data.get("info")

    def is_agent_registered(self, agent_id: str) -> bool:
        """Check if an agent is registered"""
        return agent_id in self._registered_agents

    # ============================================
    # Subscription Management
    # ============================================

    def subscribe(self, agent_id: str, callback: Callable):
        """Subscribe an agent to receive messages"""
        if agent_id not in self._subscribers:
            self._subscribers[agent_id] = []

        if callback not in self._subscribers[agent_id]:
            self._subscribers[agent_id].append(callback)
            logger.debug(f"Agent subscribed: {agent_id}")

    def unsubscribe(self, agent_id: str, callback: Callable = None):
        """Unsubscribe an agent from messages"""
        if callback:
            if agent_id in self._subscribers and callback in self._subscribers[agent_id]:
                self._subscribers[agent_id].remove(callback)
        else:
            self._subscribers.pop(agent_id, None)

        logger.debug(f"Agent unsubscribed: {agent_id}")

    def subscribe_to_type(self, message_type: str, callback: Callable):
        """Subscribe to a specific message type (for broadcasts)"""
        type_key = f"type:{message_type}"
        if type_key not in self._type_subscribers:
            self._type_subscribers[type_key] = []
        self._type_subscribers[type_key].append(callback)

    # ============================================
    # Message Routing
    # ============================================

    async def _route_message(self, message: Message):
        """Route a message to its destination(s)"""

        # Handle registration messages internally
        if message.message_type == MessageType.AGENT_REGISTER:
            await self._handle_registration(message)
            return

        # Direct message to specific agent
        if message.receiver and message.receiver != "broadcast":
            if message.receiver in self._subscribers:
                for callback in self._subscribers[message.receiver]:
                    try:
                        result = callback(message)
                        if asyncio.iscoroutine(result):
                            await result
                    except Exception as e:
                        logger.error(f"Callback error for {message.receiver}: {e}")

            # Check for pending request correlation
            if message.correlation_id and message.correlation_id in self._pending_requests:
                future = self._pending_requests.pop(message.correlation_id)
                if not future.done():
                    future.set_result(message)

        # Broadcast message to all registered agents except sender
        elif message.receiver == "broadcast":
            for agent_id, callbacks in self._subscribers.items():
                if agent_id != message.sender:
                    for callback in callbacks:
                        try:
                            result = callback(message)
                            if asyncio.iscoroutine(result):
                                await result
                        except Exception as e:
                            logger.error(f"Broadcast callback error for {agent_id}: {e}")

        # Route by message type for type subscribers
        type_key = f"type:{message.message_type.value if hasattr(message.message_type, 'value') else message.message_type}"
        if type_key in self._type_subscribers:
            for callback in self._type_subscribers[type_key]:
                try:
                    result = callback(message)
                    if asyncio.iscoroutine(result):
                        await result
                except Exception as e:
                    logger.error(f"Type subscriber error: {e}")

    async def _handle_registration(self, message: Message):
        """Handle agent registration messages"""
        content = message.content or {}
        agent_id = content.get("agent_id", message.sender)
        agent_info = content.get("agent_info", {})

        self.register_agent(agent_id, agent_info)

    # ============================================
    # Message Sending
    # ============================================

    async def send_message(self, message: Message) -> bool:
        """Send a message through the bus"""
        try:
            await self._message_queue.put(message)
            return True
        except Exception as e:
            logger.error(f"Failed to send message: {e}")
            return False

    async def request_response(self, message: Message, timeout: float = 30.0) -> Optional[Message]:
        """Send a message and wait for a correlated response"""

        # Create a future for the response
        future = asyncio.Future()
        self._pending_requests[message.id] = future

        # Send the message
        success = await self.send_message(message)

        if not success:
            self._pending_requests.pop(message.id, None)
            return None

        try:
            response = await asyncio.wait_for(future, timeout=timeout)
            return response
        except asyncio.TimeoutError:
            logger.warning(f"Request timed out: {message.id}")
            self._pending_requests.pop(message.id, None)
            return None
        except Exception as e:
            logger.error(f"Request failed: {e}")
            self._pending_requests.pop(message.id, None)
            return None

    async def broadcast(self, message: Message) -> bool:
        """Broadcast a message to all agents"""
        message.receiver = "broadcast"
        return await self.send_message(message)

    # ============================================
    # History & Stats
    # ============================================

    def get_history(self, limit: int = 50, agent_id: str = None,
                    message_type: str = None) -> List[Message]:
        """Get message history with optional filters"""
        messages = self._message_history

        if agent_id:
            messages = [m for m in messages if m.sender == agent_id or m.receiver == agent_id]

        if message_type:
            messages = [m for m in messages if m.message_type.value == message_type]

        return messages[-limit:]

    def get_stats(self) -> Dict[str, Any]:
        """Get communication bus statistics"""
        return {
            "is_running": self._active,
            "registered_agents": len(self._registered_agents),
            "subscribers": len(self._subscribers),
            "queue_size": self._message_queue.qsize(),
            "history_size": len(self._message_history),
            "pending_requests": len(self._pending_requests),
            "agents": list(self._registered_agents.keys())
        }