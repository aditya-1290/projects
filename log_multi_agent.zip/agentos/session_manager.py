# agentos/session_manager.py (FIXED)
"""
Session Manager - Manages user sessions and context
"""

from typing import Dict, Any, Optional, List
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
import uuid
import json
import logging

logger = logging.getLogger(__name__)


@dataclass
class Session:
    """User session information"""
    session_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    created_at: datetime = field(default_factory=datetime.now)
    last_active: datetime = field(default_factory=datetime.now)
    context: Dict[str, Any] = field(default_factory=dict)
    conversation_history: List[Dict] = field(default_factory=list)
    active_agents: Dict[str, str] = field(default_factory=dict)
    preferences: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict:
        return {
            "session_id": self.session_id,
            "created_at": self.created_at.isoformat(),
            "last_active": self.last_active.isoformat(),
            "context": self.context,
            "conversation_history": self.conversation_history,
            "active_agents": self.active_agents,
            "preferences": self.preferences
        }


class SessionManager:
    """Manages user sessions and their contexts"""

    def __init__(self, storage_path: Path = None):
        self._sessions: Dict[str, Session] = {}

        # Fix: Use default path if Config not available
        if storage_path:
            self._storage_path = Path(storage_path)
        else:
            # Try to get from Config, fall back to default
            try:
                from config import Config
                self._storage_path = Config.LOGS_PATH / "sessions"
            except ImportError:
                # Default fallback
                self._storage_path = Path("memory_store/logs/sessions")

        self._storage_path.mkdir(parents=True, exist_ok=True)
        logger.info(f"Session storage: {self._storage_path}")

    def create_session(self, user_id: str = None) -> Session:
        """Create a new session"""
        session = Session()
        if user_id:
            session.context["user_id"] = user_id
        self._sessions[session.session_id] = session
        self._save_session(session)
        return session

    def get_session(self, session_id: str) -> Optional[Session]:
        """Get session by ID"""
        if session_id not in self._sessions:
            session = self._load_session(session_id)
            if session:
                self._sessions[session_id] = session
        return self._sessions.get(session_id)

    def update_session(self, session_id: str, updates: Dict[str, Any]):
        """Update session with new data"""
        session = self.get_session(session_id)
        if session:
            session.last_active = datetime.now()
            for key, value in updates.items():
                if hasattr(session, key):
                    setattr(session, key, value)
            self._save_session(session)

    def add_to_history(self, session_id: str, entry: Dict):
        """Add entry to conversation history"""
        session = self.get_session(session_id)
        if session:
            session.conversation_history.append({
                **entry,
                "timestamp": datetime.now().isoformat()
            })
            self._save_session(session)

    def _save_session(self, session: Session):
        """Save session to disk"""
        filepath = self._storage_path / f"{session.session_id}.json"
        with open(filepath, 'w') as f:
            json.dump(session.to_dict(), f, indent=2)

    def _load_session(self, session_id: str) -> Optional[Session]:
        """Load session from disk"""
        filepath = self._storage_path / f"{session_id}.json"
        if filepath.exists():
            with open(filepath, 'r') as f:
                data = json.load(f)
                session = Session(
                    session_id=data["session_id"],
                    created_at=datetime.fromisoformat(data["created_at"]),
                    last_active=datetime.fromisoformat(data["last_active"]),
                    context=data.get("context", {}),
                    conversation_history=data.get("conversation_history", []),
                    active_agents=data.get("active_agents", {}),
                    preferences=data.get("preferences", {})
                )
                return session
        return None