# agentos/model_manager.py
"""
Model Manager - Handles loading and managing different AI models
Supports: GGUF (llama-cpp), Safetensors (transformers), Sentence Transformers
"""

from typing import Dict, Any, Optional
from pathlib import Path
import logging
import os

logger = logging.getLogger(__name__)


class ModelManager:
    """Manages different AI models used by agents"""

    def __init__(self, models_dir: str = None):
        # Get models directory from env or use default
        if models_dir is None:
            models_dir = os.getenv("MODELS_DIR", "D:\\Models")

        self.models_dir = Path(models_dir)
        self.models_dir.mkdir(parents=True, exist_ok=True)
        self._loaded_models: Dict[str, Any] = {}

        # Model configurations
        self._model_configs = {
            "deepseek_ocr": {
                "type": "ocr",
                "model_name": "DeepSeek-OCR-2",
                "model_path": os.getenv("DEEPSEEK_OCR_PATH", "D:\\Models\\DeepSeek-OCR-2"),
                "purpose": "Image and document text extraction",
                "model_file": "model.safetensors.index.json",  # ⭐ Index file
            },
            "qwen": {
                "type": "llm",
                "model_name": "Qwen-2.5-3B-Instruct",
                "model_file": os.getenv("QWEN_MODEL_FILE", "qwen2.5-3b-instruct-q4_k_m.gguf"),
                "purpose": "Log parsing and preprocessing",
                "temperature": float(os.getenv("QWEN_TEMPERATURE", "0.1")),
                "max_tokens": int(os.getenv("QWEN_MAX_TOKENS", "2048")),
                "n_ctx": int(os.getenv("QWEN_CONTEXT_SIZE", "4096")),
                "n_threads": int(os.getenv("N_THREADS", "4")),
                "n_gpu_layers": int(os.getenv("QWEN_GPU_LAYERS", "0")),
            },
            "gemma": {
                "type": "llm",
                "model_name": "Gemma-4-E4B-it",
                "model_file": os.getenv("GEMMA_MODEL_FILE", "gemma-4-E4B-it-Q5_K_M.gguf"),
                "purpose": "General reasoning and analysis",
                "temperature": float(os.getenv("GEMMA_TEMPERATURE", "0.3")),
                "max_tokens": int(os.getenv("GEMMA_MAX_TOKENS", "4096")),
                "n_ctx": int(os.getenv("GEMMA_CONTEXT_SIZE", "8192")),
                "n_threads": int(os.getenv("N_THREADS", "4")),
                "n_gpu_layers": int(os.getenv("GEMMA_GPU_LAYERS", "0")),
            },
            "embeddings": {
                "type": "embeddings",
                "model_name": "bge-small-en-v1.5",
                "model_path": os.getenv("EMBEDDINGS_MODEL_PATH", "D:\\Models\\bge-small-en-v1.5"),
                "purpose": "Text embeddings for vector storage",
                "model_file": "model.safetensors",  # ⭐ Safetensors file
            }
        }

    # ============================================
    # Main Load Method
    # ============================================

    async def load_model(self, model_key: str) -> Optional[Any]:
        """Load a model by key. Returns the model object or None if unavailable."""

        if model_key in self._loaded_models:
            logger.info(f"Model '{model_key}' already loaded")
            return self._loaded_models[model_key]

        config = self._model_configs.get(model_key)
        if not config:
            logger.error(f"No config for model: {model_key}")
            return None

        logger.info(f"Loading model: {config['model_name']} ({model_key})")

        try:
            model_type = config.get("type", "llm")

            if model_type == "llm":
                model = await self._load_gguf_model(model_key, config)
            elif model_type == "ocr":
                model = await self._load_ocr_model(config)
            elif model_type == "embeddings":
                model = await self._load_embeddings_model(config)
            else:
                logger.error(f"Unknown model type: {model_type}")
                return None

            if model is not None:
                self._loaded_models[model_key] = model
                logger.info(f"Model loaded: {config['model_name']} ({model_key})")
                return model
            else:
                logger.warning(f"Model not available: {config['model_name']}")
                return None

        except Exception as e:
            logger.error(f"Error loading model {model_key}: {e}", exc_info=True)
            return None

    # ============================================
    # GGUF Model Loading (Qwen, Gemma)
    # ============================================

    async def _load_gguf_model(self, model_key: str, config: Dict) -> Optional[Any]:
        """Load a GGUF format model using llama-cpp-python."""

        # Find the GGUF file
        model_file = config.get("model_file", "")
        possible_paths = []

        # 1. Direct path from env
        env_path = os.getenv(f"{model_key.upper()}_MODEL_PATH")
        if env_path:
            possible_paths.append(Path(env_path))

        # 2. MODELS_DIR + model_file
        if model_file:
            possible_paths.append(self.models_dir / model_file)

        # 3. Search for .gguf files
        if self.models_dir.exists():
            for f in self.models_dir.glob("*.gguf"):
                if model_key in f.name.lower() or model_file.replace('.gguf', '') in f.name.lower():
                    possible_paths.append(f)

        # Find first existing
        model_path = None
        for path in possible_paths:
            if path.exists() and path.suffix == ".gguf":
                model_path = path
                break

        if not model_path:
            logger.error(f"GGUF file not found for {model_key}")
            logger.error(f"  Searched: {[str(p) for p in possible_paths]}")
            return None

        try:
            from llama_cpp import Llama

            logger.info(f"Loading GGUF: {model_path.name} ({model_path.stat().st_size / 1024 / 1024:.0f}MB)")

            model = Llama(
                model_path=str(model_path),
                n_ctx=config.get("n_ctx", 4096),
                n_threads=config.get("n_threads", 4),
                n_gpu_layers=config.get("n_gpu_layers", 0),
                verbose=False,
            )
            return model

        except ImportError:
            logger.error("llama-cpp-python not installed. Install: pip install llama-cpp-python")
            return None
        except Exception as e:
            logger.error(f"GGUF load failed: {e}")
            return None

    # ============================================
    # ⭐ OCR Model Loading (DeepSeek-OCR-2 Safetensors)
    # ============================================

    async def _load_ocr_model(self, config: Dict) -> Optional[Any]:
        """
        Load DeepSeek-OCR-2 from safetensors format.
        """
        model_path = Path(config.get("model_path", "D:\\Models\\DeepSeek-OCR-2"))
        model_name = config.get("model_name", "DeepSeek-OCR-2")

        logger.info(f"Loading OCR model: {model_name} from {model_path}")

        # Verify the model folder exists
        if not model_path.exists():
            logger.error(f"OCR model path not found: {model_path}")
            return None

        # Verify key files exist
        index_file = model_path / "model.safetensors.index.json"
        safetensors_file = model_path / "model-00001-of-000001.safetensors"

        if not index_file.exists():
            logger.error(f"Index file not found: {index_file}")
            return None

        if not safetensors_file.exists():
            logger.error(f"Safetensors file not found: {safetensors_file}")
            return None

        logger.info(f"  Index: {index_file.name} ({index_file.stat().st_size / 1024:.0f}KB)")
        logger.info(f"  Model: {safetensors_file.name} ({safetensors_file.stat().st_size / 1024 / 1024:.0f}MB)")

        try:
            # ⭐ Load using transformers AutoModel
            from transformers import AutoModel, AutoProcessor, AutoTokenizer

            logger.info(f"  Loading DeepSeek-OCR-2 via transformers...")

            # Load processor and tokenizer
            processor = AutoProcessor.from_pretrained(
                str(model_path),
                trust_remote_code=True,
                local_files_only=True
            )
            logger.info(f"  Processor loaded: {type(processor).__name__}")

            # Load the model
            import torch
            model = AutoModel.from_pretrained(
                str(model_path),
                trust_remote_code=True,
                torch_dtype=torch.float16,
                device_map="cpu",  # Use "cuda" if GPU available
                local_files_only=True
            )
            model.eval()
            logger.info(f"  Model loaded: {type(model).__name__}")

            # Return as a combined OCR pipeline
            ocr_pipeline = {
                "model": model,
                "processor": processor,
                "model_path": str(model_path),
                "model_name": model_name,
            }

            logger.info(f"DeepSeek-OCR-2 loaded successfully")
            return ocr_pipeline

        except ImportError as e:
            logger.error(f"Missing dependency for OCR: {e}")
            logger.error("Install: pip install transformers torch safetensors")
            return None
        except Exception as e:
            logger.error(f"Failed to load OCR model: {e}")
            return None

    # ============================================
    # ⭐ Embeddings Model Loading (bge-small-en-v1.5 Safetensors)
    # ============================================

    async def _load_embeddings_model(self, config: Dict) -> Optional[Any]:

        model_path = Path(config.get("model_path", "D:\\Models\\bge-small-en-v1.5"))
        model_name = config.get("model_name", "bge-small-en-v1.5")

        logger.info(f"Loading embeddings model: {model_name} from {model_path}")

        # Verify the model folder exists
        if not model_path.exists():
            logger.error(f"Embeddings model path not found: {model_path}")
            return None

        # Verify key files exist
        safetensors_file = model_path / "model.safetensors"
        config_file = model_path / "config_sentence_transformers.json"

        if not safetensors_file.exists():
            logger.error(f"Safetensors file not found: {safetensors_file}")
            return None

        logger.info(f"  Model: {safetensors_file.name} ({safetensors_file.stat().st_size / 1024 / 1024:.0f}MB)")
        logger.info(f"  Config: {config_file.name if config_file.exists() else 'config.json'}")

        try:
            # ⭐ Load using sentence-transformers (handles safetensors natively)
            from sentence_transformers import SentenceTransformer

            logger.info(f"  Loading {model_name} via sentence-transformers...")

            model = SentenceTransformer(
                str(model_path),
                device="cpu"  # Use "cuda" if GPU available
            )

            # Get embedding dimension
            embedding_dim = model.get_sentence_embedding_dimension()
            logger.info(f"  Loaded: {model_name} (dimension={embedding_dim})")

            return model

        except ImportError:
            logger.error("sentence-transformers not installed")
            logger.error("Install: pip install sentence-transformers")
            return None
        except Exception as e:
            logger.error(f"Failed to load embeddings model: {e}")

            # ⭐ Fallback: Try loading with transformers directly
            try:
                from transformers import AutoModel, AutoTokenizer
                import torch

                logger.info(f"  Trying fallback: loading via transformers...")

                tokenizer = AutoTokenizer.from_pretrained(str(model_path))
                model = AutoModel.from_pretrained(str(model_path))

                def encode_fn(texts, **kwargs):
                    """Encode texts using raw transformers model."""
                    if isinstance(texts, str):
                        texts = [texts]
                    inputs = tokenizer(texts, padding=True, truncation=True, return_tensors="pt")
                    with torch.no_grad():
                        outputs = model(**inputs)
                    # Mean pooling
                    attention_mask = inputs["attention_mask"]
                    token_embeddings = outputs.last_hidden_state
                    input_mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
                    embeddings = torch.sum(token_embeddings * input_mask_expanded, 1) / torch.clamp(
                        input_mask_expanded.sum(1), min=1e-9)
                    return embeddings.numpy()

                logger.info(f"  Loaded via transformers fallback")
                return encode_fn

            except Exception as e2:
                logger.error(f"Fallback also failed: {e2}")
                return None

    # ============================================
    # Utility Methods
    # ============================================

    def get_model(self, model_key: str) -> Optional[Any]:
        """Get a loaded model by key."""
        return self._loaded_models.get(model_key)

    def get_loaded_models(self) -> list:
        """Get list of currently loaded model keys."""
        return list(self._loaded_models.keys())

    def is_loaded(self, model_key: str) -> bool:
        """Check if a model is loaded."""
        return model_key in self._loaded_models

    async def unload_model(self, model_key: str):
        """Unload a model from memory."""
        if model_key in self._loaded_models:
            logger.info(f"Unloading model: {model_key}")
            del self._loaded_models[model_key]

    def get_model_config(self, model_key: str) -> Optional[Dict]:
        """Get model configuration."""
        return self._model_configs.get(model_key)