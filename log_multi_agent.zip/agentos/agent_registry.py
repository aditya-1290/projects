# agentos/agent_registry.py
"""
Agent Registry - Central registry for all agents in the system
"""

from typing import Dict, List, Optional, Type
from dataclasses import dataclass
import logging

logger = logging.getLogger(__name__)


@dataclass
class AgentInfo:
    """Information about a registered agent"""
    name: str
    version: str
    capabilities: List[str]
    status: str
    model: str
    description: str


class AgentRegistry:
    """Central registry for managing agents"""

    def __init__(self):
        self._agents: Dict[str, AgentInfo] = {}
        self._agent_instances: Dict[str, any] = {}

    def register_agent(self, agent_id: str, info: AgentInfo, instance: any = None):
        """Register an agent with the system"""
        if agent_id in self._agents:
            logger.warning(f"Agent {agent_id} already registered. Updating...")

        self._agents[agent_id] = info
        if instance:
            self._agent_instances[agent_id] = instance
        logger.info(f"Agent {agent_id} registered successfully")

    def get_agent_info(self, agent_id: str) -> Optional[AgentInfo]:
        """Get information about a registered agent"""
        return self._agents.get(agent_id)

    def get_agent_instance(self, agent_id: str) -> Optional[any]:
        """Get agent instance by ID"""
        return self._agent_instances.get(agent_id)

    def find_agents_by_capability(self, capability: str) -> List[str]:
        """Find agents that have a specific capability"""
        matching_agents = []
        for agent_id, info in self._agents.items():
            if capability in info.capabilities:
                matching_agents.append(agent_id)
        return matching_agents

    def list_all_agents(self) -> Dict[str, AgentInfo]:
        """List all registered agents"""
        return self._agents.copy()

    def update_agent_status(self, agent_id: str, status: str):
        """Update the status of an agent"""
        if agent_id in self._agents:
            self._agents[agent_id].status = status
            logger.info(f"Agent {agent_id} status updated to {status}")

    def remove_agent(self, agent_id: str):
        """Remove an agent from the registry"""
        if agent_id in self._agents:
            del self._agents[agent_id]
            if agent_id in self._agent_instances:
                del self._agent_instances[agent_id]
            logger.info(f"Agent {agent_id} removed from registry")