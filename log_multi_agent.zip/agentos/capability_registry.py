# agentos/capability_registry.py
"""
Capability Registry - Manages agent capabilities and service discovery
"""

from typing import Dict, List, Set, Any
from dataclasses import dataclass, field
import json
from pathlib import Path


@dataclass
class Capability:
    """Define a capability that agents can have"""
    name: str
    description: str
    parameters: Dict[str, Any] = field(default_factory=dict)
    required_tools: List[str] = field(default_factory=list)
    output_format: str = "json"


class CapabilityRegistry:
    """Registry for managing agent capabilities"""

    def __init__(self):
        self._capabilities: Dict[str, Capability] = {}
        self._agent_capabilities: Dict[str, Set[str]] = {}
        self._load_builtin_capabilities()

    def _load_builtin_capabilities(self):
        """Load built-in capabilities"""
        builtin = {
            "log_extraction": Capability(
                name="log_extraction",
                description="Extract logs from various sources including files, images, and terminals",
                parameters={"source_types": ["file", "image", "terminal", "stdin"]},
                required_tools=["file_loader", "ocr", "terminal_access"],
                output_format="structured_log"
            ),
            "log_classification": Capability(
                name="log_classification",
                description="Classify and categorize log entries by type and severity",
                parameters={"log_types": ["server", "error", "access", "security", "application"]},
                required_tools=["pattern_matcher", "severity_analyzer"],
                output_format="classification_report"
            ),
            "error_resolution": Capability(
                name="error_resolution",
                description="Analyze errors and provide solutions or explanations",
                parameters={"resolution_types": ["fix", "explanation", "workaround"]},
                required_tools=["error_database", "code_analyzer"],
                output_format="solution_report"
            ),
            "code_debugging": Capability(
                name="code_debugging",
                description="Debug code issues and generate patches",
                parameters={"languages": ["python", "javascript", "java", "go"]},
                required_tools=["code_parser", "patch_generator"],
                output_format="debug_report"
            ),
            "output_evaluation": Capability(
                name="output_evaluation",
                description="Evaluate and validate agent outputs for quality and safety",
                parameters={"evaluation_criteria": ["accuracy", "completeness", "safety"]},
                required_tools=["evaluator", "safety_checker"],
                output_format="evaluation_report"
            )
        }

        for name, cap in builtin.items():
            self.register_capability(name, cap)

    def register_capability(self, name: str, capability: Capability):
        """Register a new capability"""
        self._capabilities[name] = capability

    def get_capability(self, name: str) -> Capability:
        """Get capability by name"""
        return self._capabilities.get(name)

    def assign_capability_to_agent(self, agent_id: str, capability_name: str):
        """Assign a capability to an agent"""
        if capability_name not in self._capabilities:
            raise ValueError(f"Capability {capability_name} not found")

        if agent_id not in self._agent_capabilities:
            self._agent_capabilities[agent_id] = set()

        self._agent_capabilities[agent_id].add(capability_name)

    def get_agent_capabilities(self, agent_id: str) -> Set[str]:
        """Get all capabilities of an agent"""
        return self._agent_capabilities.get(agent_id, set())

    def can_agent_handle(self, agent_id: str, capability_name: str) -> bool:
        """Check if an agent can handle a specific capability"""
        return capability_name in self._agent_capabilities.get(agent_id, set())

    def load_from_file(self, filepath: Path):
        """Load capabilities from a JSON file"""
        with open(filepath, 'r') as f:
            data = json.load(f)
            for name, cap_data in data.items():
                capability = Capability(**cap_data)
                self.register_capability(name, capability)