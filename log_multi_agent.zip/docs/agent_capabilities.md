
```python
# docs/agent_capabilities.md
"""
Documentation of agent capabilities
"""

# Agent Capabilities Reference

## Extractor Agent
| Capability | Description | Input | Output |
|------------|-------------|-------|--------|
| extract_from_text | Extract logs from text | Raw text | Structured logs |
| extract_from_file | Extract logs from file | File path | Parsed content |
| extract_from_image | OCR from images | Image file | Extracted text |
| extract_from_terminal | Execute commands | Shell command | Command output |

## Preprocessor Agent
| Capability | Description | Input | Output |
|------------|-------------|-------|--------|
| clean_logs | Remove noise, duplicates | Raw logs | Cleaned logs |
| parse_logs | Parse into structured format | Text logs | Structured entries |
| normalize_logs | Standardize fields | Parsed entries | Normalized entries |
| chunk_data | Split large datasets | Entries list | Chunked entries |

## Analyzer Agent
| Capability | Description | Input | Output |
|------------|-------------|-------|--------|
| classify_logs | Identify log type | Log entries | Classification |
| detect_patterns | Find recurring patterns | Log entries | Pattern report |
| identify_anomalies | Find unusual events | Log entries | Anomaly list |
| assess_severity | Evaluate impact | Entries + patterns | Severity score |

## Solver Agent
| Capability | Description | Input | Output |
|------------|-------------|-------|--------|
| generate_solutions | Create fixes | Problem + context | Solution steps |
| explain_errors | Explain issues | Error + context | Plain explanation |
| provide_fixes | Code/config fixes | Bug details | Fixed code |

## Debugger Agent
| Capability | Description | Input | Output |
|------------|-------------|-------|--------|
| analyze_stack_trace | Debug from traceback | Stack trace | Bug analysis |
| code_review | Find code issues | Source code | Review report |
| generate_patch | Create code fix | Bug + code | Patch file |

## Critic Agent
| Capability | Description | Input | Output |
|------------|-------------|-------|--------|
| evaluate_output | Quality assessment | Agent output | Quality score |
| safety_check | Security review | Proposed actions | Safety report |
| suggest_improvements | Enhancement ideas | Current output | Improvements |

## Memory Agent
| Capability | Description | Input | Output |
|------------|-------------|-------|--------|
| store_context | Save information | Data to store | Confirmation |
| retrieve_knowledge | Find relevant info | Search query | Relevant memories |
| learn_from_history | Pattern learning | Session data | Insights |