# docs/a2a_protocol_spec.md
"""
A2A Protocol Specification
"""

# Agent-to-Agent (A2A) Protocol Specification

## Overview

The A2A protocol enables agents to discover each other, communicate tasks, and coordinate workflows.

## Message Format

```json
{
    "id": "uuid",
    "sender": "agent_id",
    "receiver": "agent_id or 'broadcast'",
    "message_type": "task_request|task_response|capability_query|...",
    "priority": 1-4,
    "content": {},
    "correlation_id": "uuid or null",
    "timestamp": "ISO 8601",
    "metadata": {}
}