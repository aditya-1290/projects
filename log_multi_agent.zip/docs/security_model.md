# docs/security_model.md
"""
Security model documentation
"""

# Security Model

## Overview

The system implements multiple layers of security to ensure safe operation.

## Security Layers

### 1. Command Whitelisting
- Only pre-approved commands can be executed
- Commands categorized by risk level (SAFE, LOW, MEDIUM, HIGH, CRITICAL)
- Dangerous patterns blocked at validation stage

### 2. Permission Management
- Each agent has specific permission levels
- File access: NONE → READ → WRITE → ADMIN
- Terminal access: Requires explicit permission
- Temporary permission grants with time limits

### 3. Input Sanitization
- HTML/script tag removal
- Path traversal prevention
- Command injection detection
- SQL injection pattern detection

### 4. Audit Logging
- All agent actions logged
- Security events tracked separately
- Command execution history maintained
- Permission changes recorded

### 5. Output Sanitization
- Secrets masked in outputs (API keys, passwords, tokens)
- File paths sanitized
- Sensitive data redacted

## Permission Levels

| Level | File Access | Command Access | Network Access |
|-------|-------------|----------------|----------------|
| NONE | No access | No commands | No access |
| READ | Read files | Safe commands | No access |
| EXECUTE | Read files | Run commands | Limited |
| WRITE | Read/Write | Run commands | Yes |
| ADMIN | Full access | All commands | Full access |

## Blocked Patterns

### Commands
- `rm -rf /` - Destructive deletion
- `dd if=` - Disk operations
- `mkfs.*` - Filesystem creation
- `chmod 777` - Insecure permissions
- `sudo` - Privilege escalation
- `wget | sh` - Pipe to shell

### Path Access
- `/etc/shadow` - Password hashes
- `/etc/passwd` - User accounts
- `/root/` - Root home
- `/proc/sys/` - Kernel parameters

## Best Practices

1. **Least Privilege:** Agents start with minimal permissions
2. **Time-Limited Grants:** Elevated permissions auto-expire
3. **Audit Everything:** All actions are logged
4. **User Approval:** Sensitive operations require confirmation
5. **Input Validation:** All inputs sanitized before processing