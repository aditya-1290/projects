# docs/architecture.md
"""
Architecture documentation for the log analysis multi-agent system
"""

# Log Analysis Multi-Agent System - Architecture

## Overview

This system is a multi-agent AI system for log analysis, debugging, and troubleshooting. It uses multiple specialized agents, each powered by different LLM models, working together through an A2A (Agent-to-Agent) communication protocol.

## Architecture Diagram

## Agent Roles

### Orchestrator (Master Coordinator)
- **Model:** Gemma-4-E4B-it
- **Role:** Understands user requests, plans workflows, coordinates agents
- **Responsibilities:** Task decomposition, agent routing, quality validation

### Extractor
- **Model:** DeepSeek OCR-2 (images) + custom parsers (text)
- **Role:** Extracts logs from files, images, terminals, direct input
- **Capabilities:** File reading, OCR, terminal access, format detection

### Preprocessor
- **Model:** Qwen-2.5-3B-Instruct
- **Role:** Cleans, normalizes, structures raw log data
- **Capabilities:** Deduplication, timestamp normalization, field extraction

### Analyzer
- **Model:** Gemma-4-E4B-it
- **Role:** Deep analysis of log patterns and anomalies
- **Capabilities:** Pattern detection, anomaly identification, severity assessment

### Solver
- **Model:** Gemma-4-E4B-it
- **Role:** Generates solutions and explanations
- **Capabilities:** Root cause analysis, fix generation, user explanations

### Debugger
- **Model:** Gemma-4-E4B-it
- **Role:** Deep code analysis and debugging
- **Capabilities:** Code review, bug detection, patch generation

### Critic
- **Model:** Gemma-4-E4B-it
- **Role:** Evaluates agent outputs for quality
- **Capabilities:** Quality scoring, safety checking, improvement suggestions

### Memory
- **Model:** Qwen-2.5-3B-Instruct (embeddings)
- **Role:** Manages context and retrieves relevant history
- **Capabilities:** Vector storage, semantic search, pattern learning

## Communication Protocol (A2A)

Agents communicate through a central Message Broker using the A2A protocol:

- **Message Types:** Task Request, Task Response, Capability Query, Status Update
- **Discovery:** Agents register capabilities; orchestrator discovers needed agents
- **Correlation:** Request-response pairs tracked via correlation IDs
- **Broadcast:** Support for broadcasting messages to all agents

## Data Flow

1. User submits request → Orchestrator
2. Orchestrator plans workflow → Routes to appropriate agents
3. Extractor gathers log data → Preprocessor cleans and structures
4. Analyzer finds patterns → Solver generates solutions
5. Critic validates quality → Orchestrator presents to user

## Model Strategy

- **Gemma-4-E4B-it:** Used for reasoning-heavy tasks (analysis, solving, debugging)
- **Qwen-2.5-3B:** Used for lighter processing (preprocessing, memory)
- **DeepSeek OCR-2:** Used for image text extraction