# docs/model_strategy.md
"""
Documentation for model selection and usage strategy
"""

# Model Strategy

## Model Selection Rationale

### Gemma-4-E4B-it (4B parameters)
**Used by:** Orchestrator, Analyzer, Solver, Debugger, Critic

- **Why:** Strong reasoning capabilities, good code understanding
- **Strengths:** Multi-step reasoning, code analysis, explanation generation
- **Trade-offs:** Larger model, slower inference, more memory
- **Settings:** temperature=0.3, max_tokens=4096

### Qwen-2.5-3B-Instruct (3B parameters)
**Used by:** Preprocessor, Memory

- **Why:** Efficient for structured tasks, good embeddings
- **Strengths:** Fast inference, low memory, good text processing
- **Trade-offs:** Less capable at complex reasoning
- **Settings:** temperature=0.1, max_tokens=2048

### DeepSeek OCR-2
**Used by:** Extractor (image processing)

- **Why:** Specialized for text extraction from images
- **Strengths:** High accuracy OCR, multi-language support
- **Trade-offs:** Requires specific model access

## Quantization Strategy

| Use Case | Quantization | Quality Impact |
|----------|-------------|----------------|
| Development | q8_0 or none | Best quality, slower |
| Production | q4_K_M | Good balance |
| Edge/Low-RAM | q4_0 | Lower quality, fastest |

## Hardware Requirements

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| RAM | 8 GB | 16 GB |
| GPU VRAM | 4 GB | 8 GB |
| Storage | 10 GB | 20 GB |
| CPU Cores | 4 | 8 |

## Running on CPU Only

Set `gpu_layers=0` in model configs. Expect slower inference:
- Gemma: 1-3 tokens/second on modern CPU
- Qwen: 3-8 tokens/second on modern CPU