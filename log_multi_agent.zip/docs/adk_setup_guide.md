# docs/adk_setup_guide.md
"""
ADK setup guide for the project
"""

# ADK (Agent Development Kit) Setup Guide

## Prerequisites

- Python 3.10 or higher
- pip (Python package manager)
- Git (for cloning repositories)
- 8GB+ RAM recommended

## Installation

### 1. Clone and Setup

```bash
# Clone the project
git clone <repository-url>
cd log_multi_agent

# Create virtual environment
python -m venv venv
source venv/bin/activate  # Linux/Mac
# or
venv\Scripts\activate     # Windows

# Install dependencies
pip install -r requirements.txt