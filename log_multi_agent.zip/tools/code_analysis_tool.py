# tools/code_analysis_tool.py
"""
Code Analysis Tool - Static code analysis for agents
"""

from typing import Dict, Any, List, Optional
import re
import logging
from pathlib import Path

from .base_tool import BaseTool

logger = logging.getLogger(__name__)


class CodeAnalysisTool(BaseTool):
    """
    Tool for analyzing code structure and patterns.
    Agents use this to understand code before debugging.
    """

    def __init__(self):
        super().__init__(
            name="code_analysis_tool",
            description="Analyze code structure, find patterns, detect issues"
        )

    def get_schema(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "operations": {
                "structure": "Extract code structure (functions, classes, imports)",
                "complexity": "Analyze code complexity",
                "dependencies": "Find dependencies and imports",
                "find_pattern": "Search for specific code patterns",
                "detect_issues": "Find common code issues and anti-patterns"
            }
        }

    async def execute(self, operation: str = 'structure', **kwargs) -> Dict[str, Any]:
        """Execute code analysis operation"""
        self.log_usage(operation=operation, **kwargs)

        try:
            if operation == 'structure':
                return self._analyze_structure(**kwargs)
            elif operation == 'complexity':
                return self._analyze_complexity(**kwargs)
            elif operation == 'dependencies':
                return self._find_dependencies(**kwargs)
            elif operation == 'find_pattern':
                return self._find_code_pattern(**kwargs)
            elif operation == 'detect_issues':
                return self._detect_issues(**kwargs)
            else:
                return {'success': False, 'error': f'Unknown operation: {operation}'}

        except Exception as e:
            self.log_error(str(e))
            return {'success': False, 'error': str(e)}

    def _analyze_structure(self, code: str, language: str = 'python', **kwargs) -> Dict[str, Any]:
        """Extract code structure"""

        structure = {
            'functions': [],
            'classes': [],
            'imports': [],
            'variables': [],
            'total_lines': len(code.split('\n'))
        }

        if language == 'python':
            # Extract functions
            func_pattern = r'def\s+(\w+)\s*\(([^)]*)\)'
            for match in re.finditer(func_pattern, code):
                line_num = code[:match.start()].count('\n') + 1
                structure['functions'].append({
                    'name': match.group(1),
                    'parameters': match.group(2),
                    'line': line_num
                })

            # Extract classes
            class_pattern = r'class\s+(\w+)(?:\(([^)]*)\))?\s*:'
            for match in re.finditer(class_pattern, code):
                line_num = code[:match.start()].count('\n') + 1
                structure['classes'].append({
                    'name': match.group(1),
                    'inherits': match.group(2) if match.group(2) else None,
                    'line': line_num
                })

            # Extract imports
            import_pattern = r'(?:from\s+(\S+)\s+)?import\s+(.*)'
            for match in re.finditer(import_pattern, code):
                structure['imports'].append(match.group(0).strip())

        return {
            'success': True,
            'language': language,
            'structure': structure
        }

    def _analyze_complexity(self, code: str, **kwargs) -> Dict[str, Any]:
        """Analyze code complexity"""

        lines = code.split('\n')

        metrics = {
            'total_lines': len(lines),
            'non_empty_lines': len([l for l in lines if l.strip()]),
            'comment_lines': len([l for l in lines if l.strip().startswith('#')]),
            'max_line_length': max(len(l) for l in lines),
            'avg_line_length': sum(len(l) for l in lines) / max(len(lines), 1),
            'indentation_levels': self._count_indentation(lines),
        }

        # Count control flow statements
        control_flow = {
            'if_statements': len(re.findall(r'\bif\s+', code)),
            'else_statements': len(re.findall(r'\belse\s*:', code)),
            'elif_statements': len(re.findall(r'\belif\s+', code)),
            'for_loops': len(re.findall(r'\bfor\s+', code)),
            'while_loops': len(re.findall(r'\bwhile\s+', code)),
            'try_blocks': len(re.findall(r'\btry\s*:', code)),
            'except_blocks': len(re.findall(r'\bexcept', code)),
            'function_calls': len(re.findall(r'\w+\s*\(', code)),
        }

        return {
            'success': True,
            'metrics': metrics,
            'control_flow': control_flow,
            'complexity_score': self._estimate_complexity(metrics, control_flow)
        }

    def _find_dependencies(self, code: str, language: str = 'python', **kwargs) -> Dict[str, Any]:
        """Find dependencies and imports"""

        dependencies = {
            'stdlib': [],
            'third_party': [],
            'local': []
        }

        if language == 'python':
            import_pattern = r'(?:from\s+(\S+)\s+)?import\s+(.*)'

            stdlib_modules = {'os', 'sys', 're', 'json', 'datetime', 'math', 'random',
                              'collections', 'itertools', 'functools', 'pathlib', 'typing'}

            for match in re.finditer(import_pattern, code):
                module = match.group(1) or match.group(2).split(',')[0].strip()
                module = module.split('.')[0]

                if module in stdlib_modules:
                    dependencies['stdlib'].append(module)
                elif module.startswith('.'):
                    dependencies['local'].append(module)
                else:
                    dependencies['third_party'].append(module)

        return {
            'success': True,
            'dependencies': dependencies
        }

    def _find_code_pattern(self, code: str, pattern_type: str = 'all', **kwargs) -> Dict[str, Any]:
        """Find specific code patterns"""

        patterns = {
            'exception_handling': r'try\s*:.*?except',
            'logging': r'logging\.|logger\.|print\(',
            'database': r'\.execute\(|\.query\(|\.cursor\(|\.commit\(',
            'http_requests': r'requests\.|urllib\.|http\.',
            'file_operations': r'open\(|\.read\(\)|\.write\(',
            'async_code': r'async\s+def|await\s+',
            'decorators': r'@\w+',
            'list_comprehensions': r'\[.*\bfor\b.*\]',
        }

        results = {}

        for name, pattern in patterns.items():
            if pattern_type == 'all' or pattern_type == name:
                matches = re.findall(pattern, code, re.DOTALL)
                results[name] = {
                    'found': len(matches) > 0,
                    'count': len(matches),
                    'samples': matches[:5]
                }

        return {
            'success': True,
            'pattern_type': pattern_type,
            'results': results
        }

    def _detect_issues(self, code: str, language: str = 'python', **kwargs) -> Dict[str, Any]:
        """Detect common code issues"""

        issues = []

        if language == 'python':
            # Check for bare except
            if re.search(r'except\s*:', code):
                issues.append({
                    'type': 'bare_except',
                    'severity': 'medium',
                    'message': 'Bare except clause catches all exceptions including SystemExit'
                })

            # Check for mutable default arguments
            if re.search(r'def\s+\w+\s*\([^)]*=\s*(\[\]|\{\})', code):
                issues.append({
                    'type': 'mutable_default',
                    'severity': 'high',
                    'message': 'Mutable default argument can cause unexpected behavior'
                })

            # Check for == None vs is None
            if re.search(r'==\s*None', code):
                issues.append({
                    'type': 'none_comparison',
                    'severity': 'low',
                    'message': 'Use "is None" instead of "== None"'
                })

            # Check for dangerous eval/exec
            if re.search(r'\beval\(|\bexec\(', code):
                issues.append({
                    'type': 'dangerous_eval',
                    'severity': 'critical',
                    'message': 'eval() or exec() can execute arbitrary code'
                })

        return {
            'success': True,
            'issues_found': len(issues),
            'issues': issues
        }

    def _count_indentation(self, lines: List[str]) -> Dict[str, int]:
        """Count indentation levels"""
        levels = {}

        for line in lines:
            if line.strip():
                indent = len(line) - len(line.lstrip())
                levels[indent] = levels.get(indent, 0) + 1

        return {
            'max_indent': max(levels.keys()) if levels else 0,
            'common_indent': max(levels, key=levels.get) if levels else 0
        }

    def _estimate_complexity(self, metrics: Dict, control_flow: Dict) -> str:
        """Estimate code complexity level"""
        score = 0
        score += control_flow['if_statements'] * 1
        score += control_flow['for_loops'] * 2
        score += control_flow['while_loops'] * 3
        score += control_flow['try_blocks'] * 2

        if score < 10:
            return 'simple'
        elif score < 25:
            return 'moderate'
        elif score < 50:
            return 'complex'
        else:
            return 'very complex'