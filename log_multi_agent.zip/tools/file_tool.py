# tools/file_tool.py
"""
File Tool - File system operations for agents
Agents use this to read, write, and manage files
"""

from typing import Dict, Any, List, Optional
from pathlib import Path
import json
import csv
import logging
import shutil
from datetime import datetime

from .base_tool import BaseTool

logger = logging.getLogger(__name__)


class FileTool(BaseTool):
    """
    Tool for file system operations.
    Agents use this to read logs, save results, and manage files.
    """

    def __init__(self, allowed_paths: List[str] = None):
        super().__init__(
            name="file_tool",
            description="Read, write, and manage files on the filesystem"
        )
        self.allowed_paths = allowed_paths or []
        self.max_file_size = 100 * 1024 * 1024  # 100MB limit

    def get_schema(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "operations": {
                "read": {
                    "description": "Read a file's contents",
                    "parameters": ["path", "encoding", "max_lines"],
                    "returns": "File contents as string or structured data"
                },
                "write": {
                    "description": "Write content to a file",
                    "parameters": ["path", "content", "mode"],
                    "returns": "Success status and file info"
                },
                "list": {
                    "description": "List files in a directory",
                    "parameters": ["path", "pattern", "recursive"],
                    "returns": "List of file information"
                },
                "info": {
                    "description": "Get file metadata",
                    "parameters": ["path"],
                    "returns": "File size, type, modification time"
                },
                "search": {
                    "description": "Search for text in files",
                    "parameters": ["path", "pattern", "file_pattern"],
                    "returns": "Matching lines with context"
                },
                "delete": {
                    "description": "Delete a file or directory",
                    "parameters": ["path", "recursive"],
                    "returns": "Success status"
                }
            }
        }

    async def execute(self, operation: str, **kwargs) -> Dict[str, Any]:
        """Execute a file operation"""
        self.log_usage(operation=operation, **kwargs)

        operations = {
            'read': self._read_file,
            'write': self._write_file,
            'list': self._list_files,
            'info': self._file_info,
            'search': self._search_files,
            'delete': self._delete_file,
        }

        handler = operations.get(operation)
        if not handler:
            return {'success': False, 'error': f'Unknown operation: {operation}'}

        try:
            return await handler(**kwargs)
        except Exception as e:
            self.log_error(str(e))
            return {'success': False, 'error': str(e)}

    async def _read_file(self, path: str, encoding: str = 'utf-8',
                         max_lines: int = None, **kwargs) -> Dict[str, Any]:
        """Read a file's contents"""
        file_path = Path(path)

        # Security: check if path is allowed
        if not self._is_path_allowed(file_path):
            return {'success': False, 'error': f'Access denied: {path}'}

        if not file_path.exists():
            return {'success': False, 'error': f'File not found: {path}'}

        if file_path.stat().st_size > self.max_file_size:
            return {'success': False, 'error': f'File too large: {file_path.stat().st_size} bytes'}

        # Detect file type and read accordingly
        suffix = file_path.suffix.lower()

        try:
            if suffix == '.json':
                with open(file_path, 'r', encoding=encoding) as f:
                    content = json.load(f)
                content_type = 'json'

            elif suffix == '.csv':
                with open(file_path, 'r', encoding=encoding) as f:
                    reader = csv.DictReader(f)
                    content = list(reader)
                content_type = 'csv'

            else:
                with open(file_path, 'r', encoding=encoding) as f:
                    if max_lines:
                        lines = []
                        for i, line in enumerate(f):
                            if i >= max_lines:
                                break
                            lines.append(line.rstrip('\n'))
                        content = '\n'.join(lines)
                    else:
                        content = f.read()
                content_type = 'text'

            return {
                'success': True,
                'path': str(file_path.absolute()),
                'type': content_type,
                'content': content,
                'size': file_path.stat().st_size,
                'lines': len(content) if isinstance(content, str) else len(content)
            }

        except UnicodeDecodeError:
            # Try binary read
            with open(file_path, 'rb') as f:
                content = f.read()

            return {
                'success': True,
                'path': str(file_path.absolute()),
                'type': 'binary',
                'content': f"<binary data: {len(content)} bytes>",
                'size': len(content)
            }

    async def _write_file(self, path: str, content: Any,
                          mode: str = 'w', **kwargs) -> Dict[str, Any]:
        """Write content to a file"""
        file_path = Path(path)

        if not self._is_path_allowed(file_path):
            return {'success': False, 'error': f'Access denied: {path}'}

        # Create parent directories if needed
        file_path.parent.mkdir(parents=True, exist_ok=True)

        try:
            suffix = file_path.suffix.lower()

            if suffix == '.json' and isinstance(content, (dict, list)):
                with open(file_path, mode, encoding='utf-8') as f:
                    json.dump(content, f, indent=2, ensure_ascii=False)

            elif suffix == '.csv' and isinstance(content, list):
                with open(file_path, mode, encoding='utf-8', newline='') as f:
                    if content:
                        writer = csv.DictWriter(f, fieldnames=content[0].keys())
                        writer.writeheader()
                        writer.writerows(content)

            else:
                with open(file_path, mode, encoding='utf-8') as f:
                    f.write(str(content))

            return {
                'success': True,
                'path': str(file_path.absolute()),
                'size': file_path.stat().st_size,
                'message': f'File written successfully'
            }

        except Exception as e:
            return {'success': False, 'error': f'Write failed: {str(e)}'}

    async def _list_files(self, path: str = '.', pattern: str = '*',
                          recursive: bool = False, **kwargs) -> Dict[str, Any]:
        """List files in a directory"""
        dir_path = Path(path)

        if not self._is_path_allowed(dir_path):
            return {'success': False, 'error': f'Access denied: {path}'}

        if not dir_path.exists():
            return {'success': False, 'error': f'Directory not found: {path}'}

        try:
            if recursive:
                files = list(dir_path.rglob(pattern))
            else:
                files = list(dir_path.glob(pattern))

            file_list = []
            for f in files[:1000]:  # Limit to 1000 files
                if f.is_file():
                    file_list.append({
                        'name': f.name,
                        'path': str(f.absolute()),
                        'size': f.stat().st_size,
                        'modified': datetime.fromtimestamp(f.stat().st_mtime).isoformat(),
                        'extension': f.suffix
                    })

            return {
                'success': True,
                'directory': str(dir_path.absolute()),
                'count': len(file_list),
                'files': file_list,
                'truncated': len(files) > 1000
            }

        except Exception as e:
            return {'success': False, 'error': str(e)}

    async def _file_info(self, path: str, **kwargs) -> Dict[str, Any]:
        """Get file metadata"""
        file_path = Path(path)

        if not self._is_path_allowed(file_path):
            return {'success': False, 'error': f'Access denied: {path}'}

        if not file_path.exists():
            return {'success': False, 'error': f'File not found: {path}'}

        stat = file_path.stat()

        return {
            'success': True,
            'name': file_path.name,
            'path': str(file_path.absolute()),
            'size': stat.st_size,
            'size_human': self._format_size(stat.st_size),
            'created': datetime.fromtimestamp(stat.st_ctime).isoformat(),
            'modified': datetime.fromtimestamp(stat.st_mtime).isoformat(),
            'is_file': file_path.is_file(),
            'is_dir': file_path.is_dir(),
            'extension': file_path.suffix,
            'permissions': oct(stat.st_mode)[-3:]
        }

    async def _search_files(self, path: str, pattern: str,
                            file_pattern: str = '*', **kwargs) -> Dict[str, Any]:
        """Search for text in files"""
        import re

        dir_path = Path(path)

        if not self._is_path_allowed(dir_path):
            return {'success': False, 'error': f'Access denied: {path}'}

        matches = []

        try:
            search_pattern = re.compile(pattern, re.IGNORECASE)

            for file_path in dir_path.rglob(file_pattern):
                if file_path.is_file() and file_path.stat().st_size < self.max_file_size:
                    try:
                        with open(file_path, 'r', encoding='utf-8') as f:
                            for i, line in enumerate(f, 1):
                                if search_pattern.search(line):
                                    matches.append({
                                        'file': str(file_path.absolute()),
                                        'line': i,
                                        'content': line.strip()[:200]
                                    })

                                    if len(matches) >= 100:  # Limit results
                                        break
                    except (UnicodeDecodeError, PermissionError):
                        continue

                if len(matches) >= 100:
                    break

            return {
                'success': True,
                'pattern': pattern,
                'matches': len(matches),
                'results': matches,
                'truncated': len(matches) >= 100
            }

        except Exception as e:
            return {'success': False, 'error': str(e)}

    async def _delete_file(self, path: str, recursive: bool = False, **kwargs) -> Dict[str, Any]:
        """Delete a file or directory"""
        file_path = Path(path)

        if not self._is_path_allowed(file_path):
            return {'success': False, 'error': f'Access denied: {path}'}

        if not file_path.exists():
            return {'success': False, 'error': f'File not found: {path}'}

        try:
            if file_path.is_file():
                file_path.unlink()
            elif file_path.is_dir() and recursive:
                shutil.rmtree(file_path)
            else:
                return {'success': False, 'error': 'Use recursive=True to delete directories'}

            return {
                'success': True,
                'path': str(file_path.absolute()),
                'message': 'Deleted successfully'
            }

        except Exception as e:
            return {'success': False, 'error': str(e)}

    def _is_path_allowed(self, path: Path) -> bool:
        """Check if path is in allowed paths"""
        if not self.allowed_paths:
            return True  # No restrictions

        resolved = path.resolve()

        for allowed in self.allowed_paths:
            allowed_path = Path(allowed).resolve()
            try:
                resolved.relative_to(allowed_path)
                return True
            except ValueError:
                continue

        return False

    def _format_size(self, size: int) -> str:
        """Format file size in human readable format"""
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size < 1024:
                return f"{size:.1f} {unit}"
            size /= 1024
        return f"{size:.1f} TB"

    def add_allowed_path(self, path: str):
        """Add a path to the allowed list"""
        self.allowed_paths.append(path)