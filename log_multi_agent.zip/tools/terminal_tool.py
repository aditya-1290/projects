# tools/terminal_tool.py
"""
Terminal Tool - Safe terminal command execution for agents
Agents use this to run shell commands with proper permission checks
"""

from typing import Dict, Any, List, Optional
import subprocess
import asyncio
import os
import re
import logging
from pathlib import Path

from .base_tool import BaseTool

logger = logging.getLogger(__name__)


class TerminalTool(BaseTool):
    """
    Tool for executing terminal commands safely.
    Includes command whitelisting, permission checks, and output capture.
    """

    def __init__(self, allowed_commands: List[str] = None,
                 allowed_paths: List[str] = None):
        super().__init__(
            name="terminal_tool",
            description="Execute terminal commands with safety checks"
        )

        # Default safe commands
        self.allowed_commands = allowed_commands or [
            'cat', 'head', 'tail', 'less', 'grep', 'awk', 'sed',
            'sort', 'uniq', 'wc', 'find', 'ls', 'stat', 'file',
            'ps', 'top', 'df', 'du', 'free', 'uptime',
            'journalctl', 'dmesg', 'netstat', 'ss', 'ping',
            'python', 'python3', 'pip', 'node', 'npm',
            'git', 'docker', 'kubectl', 'systemctl', 'journalctl'
        ]

        self.allowed_paths = allowed_paths or []
        self.blocked_patterns = [
            r'rm\s+-rf\s+/',
            r'>\s*/dev/',
            r'mkfs\.',
            r'dd\s+if=',
            r':\(\)\s*\{',
            r'wget.*\|.*sh',
            r'curl.*\|.*sh',
            r'chmod\s+777',
            r'passwd',
            r'sudo\s+',
        ]

        self.command_history = []
        self.max_history = 100

    def get_schema(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "operations": {
                "execute": {
                    "description": "Execute a shell command",
                    "parameters": ["command", "working_dir", "timeout", "env"],
                    "returns": "stdout, stderr, return code"
                },
                "interactive": {
                    "description": "Run command that needs user confirmation",
                    "parameters": ["command", "reason"],
                    "requires_permission": True
                }
            },
            "security": {
                "allowed_commands": self.allowed_commands,
                "blocked_patterns": ["dangerous patterns blocked"],
                "timeout_default": 30
            }
        }

    async def execute(self, operation: str = 'execute', **kwargs) -> Dict[str, Any]:
        """Execute a terminal operation"""
        self.log_usage(operation=operation, **kwargs)

        try:
            if operation == 'execute':
                return await self._execute_command(**kwargs)
            elif operation == 'interactive':
                return await self._interactive_command(**kwargs)
            else:
                return {'success': False, 'error': f'Unknown operation: {operation}'}

        except Exception as e:
            self.log_error(str(e))
            return {'success': False, 'error': str(e)}

    async def _execute_command(self, command: str, working_dir: str = None,
                               timeout: int = 30, env: Dict[str, str] = None,
                               **kwargs) -> Dict[str, Any]:
        """Execute a shell command"""

        # Validate command
        validation = self._validate_command(command)
        if not validation['valid']:
            return {'success': False, 'error': validation['error']}

        # Sanitize working directory
        if working_dir:
            work_path = Path(working_dir)
            if not work_path.exists():
                return {'success': False, 'error': f'Directory not found: {working_dir}'}
            if self.allowed_paths:
                if not self._is_path_allowed(work_path):
                    return {'success': False, 'error': f'Directory not allowed: {working_dir}'}

        try:
            # Prepare environment
            process_env = os.environ.copy()
            if env:
                process_env.update(env)

            # Execute command
            process = await asyncio.create_subprocess_shell(
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=working_dir,
                env=process_env
            )

            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(),
                    timeout=timeout
                )
            except asyncio.TimeoutError:
                process.kill()
                await process.wait()

                return {
                    'success': False,
                    'error': f'Command timed out after {timeout}s',
                    'command': command,
                    'timeout': timeout
                }

            # Decode output
            stdout_text = stdout.decode('utf-8', errors='replace')
            stderr_text = stderr.decode('utf-8', errors='replace')

            # Limit output size
            max_output = 50000  # 50KB limit
            if len(stdout_text) > max_output:
                stdout_text = stdout_text[:max_output] + f'\n... [truncated {len(stdout_text) - max_output} bytes]'

            result = {
                'success': process.returncode == 0,
                'command': command,
                'return_code': process.returncode,
                'stdout': stdout_text,
                'stderr': stderr_text,
                'has_output': bool(stdout_text.strip()),
                'has_errors': bool(stderr_text.strip()),
            }

            # Add to history
            self._add_to_history(command, result)

            return result

        except Exception as e:
            return {'success': False, 'error': str(e), 'command': command}

    async def _interactive_command(self, command: str, reason: str = "",
                                   **kwargs) -> Dict[str, Any]:
        """
        Execute a command that requires user confirmation.
        The agent explains why it needs to run this command.
        """
        # This would prompt the user in the terminal
        print(f"\n{'=' * 60}")
        print(f"Agent requests terminal access")
        print(f"{'=' * 60}")
        print(f"Command: {command}")
        if reason:
            print(f"Reason: {reason}")
        print(f"{'=' * 60}")

        response = input("Allow? [y/N]: ").strip().lower()

        if response not in ['y', 'yes']:
            return {
                'success': False,
                'error': 'Permission denied by user',
                'command': command
            }

        return await self._execute_command(command, **kwargs)

    def _validate_command(self, command: str) -> Dict[str, Any]:
        """Validate that a command is safe to execute"""

        if not command or not command.strip():
            return {'valid': False, 'error': 'Empty command'}

        # Check for blocked patterns
        for pattern in self.blocked_patterns:
            if re.search(pattern, command):
                return {
                    'valid': False,
                    'error': f'Command blocked for security: matches dangerous pattern'
                }

        # Check if base command is allowed
        base_command = command.strip().split()[0]

        # Allow paths (like /usr/bin/python)
        if '/' in base_command:
            cmd_name = Path(base_command).name
        else:
            cmd_name = base_command

        if cmd_name not in self.allowed_commands:
            return {
                'valid': False,
                'error': f'Command not allowed: {cmd_name}. Allowed: {self.allowed_commands}'
            }

        # Check for command chaining
        dangerous_operators = [';', '&&', '||', '`', '$(']
        for op in dangerous_operators:
            if op in command:
                # Only block if it's actual chaining, not in strings
                if not self._is_in_quotes(command, op):
                    return {
                        'valid': False,
                        'error': f'Command chaining not allowed: {op}'
                    }

        return {'valid': True}

    def _is_in_quotes(self, text: str, char: str) -> bool:
        """Check if a character appears inside quotes"""
        in_single = False
        in_double = False

        for i, c in enumerate(text):
            if c == "'" and not in_double:
                in_single = not in_single
            elif c == '"' and not in_single:
                in_double = not in_double
            elif c == char and (in_single or in_double):
                return True

        return False

    def _is_path_allowed(self, path: Path) -> bool:
        """Check if a path is in the allowed list"""
        resolved = path.resolve()

        for allowed in self.allowed_paths:
            allowed_path = Path(allowed).resolve()
            try:
                resolved.relative_to(allowed_path)
                return True
            except ValueError:
                continue

        return False

    def _add_to_history(self, command: str, result: Dict[str, Any]):
        """Add command to execution history"""
        self.command_history.append({
            'timestamp': asyncio.get_event_loop().time(),
            'command': command,
            'success': result.get('success', False),
            'return_code': result.get('return_code')
        })

        # Trim history
        if len(self.command_history) > self.max_history:
            self.command_history = self.command_history[-self.max_history:]

    def get_history(self, limit: int = 20) -> List[Dict[str, Any]]:
        """Get recent command history"""
        return self.command_history[-limit:]

    def add_allowed_command(self, command: str):
        """Add a command to the allowed list"""
        if command not in self.allowed_commands:
            self.allowed_commands.append(command)

    def clear_history(self):
        """Clear command history"""
        self.command_history.clear()