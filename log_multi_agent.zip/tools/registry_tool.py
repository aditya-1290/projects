# tools/registry.py
"""
Tool Registry - Central registry for all available tools
"""

from typing import Dict, Any, List, Optional
import logging

logger = logging.getLogger(__name__)


class ToolRegistry:
    """
    Registry for managing and discovering tools.
    Agents use this to find available tools and their capabilities.
    """

    def __init__(self):
        self._tools: Dict[str, Any] = {}

    def register(self, tool: Any):
        """Register a tool"""
        self._tools[tool.name] = tool
        logger.info(f"Tool registered: {tool.name}")

    def unregister(self, tool_name: str):
        """Remove a tool"""
        if tool_name in self._tools:
            del self._tools[tool_name]
            logger.info(f"Tool unregistered: {tool_name}")

    def get_tool(self, tool_name: str) -> Optional[Any]:
        """Get a tool by name"""
        return self._tools.get(tool_name)

    def list_tools(self) -> List[str]:
        """List all registered tools"""
        return list(self._tools.keys())

    def get_all_schemas(self) -> Dict[str, Any]:
        """Get schemas for all tools"""
        return {
            name: tool.get_schema()
            for name, tool in self._tools.items()
        }

    def find_tools_for_task(self, task_description: str) -> List[str]:
        """Find tools that might help with a task"""
        relevant = []

        task_lower = task_description.lower()

        for name, tool in self._tools.items():
            tool_desc = tool.description.lower()

            # Simple keyword matching
            keywords = task_lower.split()
            if any(kw in tool_desc or kw in name for kw in keywords):
                relevant.append(name)

        return relevant

    def get_tool_stats(self) -> Dict[str, Any]:
        """Get usage statistics for all tools"""
        return {
            name: tool.get_stats()
            for name, tool in self._tools.items()
        }