# tools/search_tool.py
"""
Search Tool - Search capabilities for agents
"""

from typing import Dict, Any, List, Optional
import re
import logging

from .base_tool import BaseTool

logger = logging.getLogger(__name__)


class SearchTool(BaseTool):
    """
    Tool for searching through text and data.
    Agents use this to find patterns, keywords, and relevant information.
    """

    def __init__(self):
        super().__init__(
            name="search_tool",
            description="Search through text data for patterns and information"
        )

    def get_schema(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "operations": {
                "regex_search": {
                    "description": "Search text using regex patterns",
                    "parameters": ["text", "pattern", "case_sensitive"],
                    "returns": "Matching lines with context"
                },
                "keyword_search": {
                    "description": "Search for keywords in text",
                    "parameters": ["text", "keywords", "match_all"],
                    "returns": "Lines containing keywords"
                },
                "fuzzy_search": {
                    "description": "Fuzzy/approximate text search",
                    "parameters": ["text", "query", "threshold"],
                    "returns": "Similar matches"
                },
                "extract_patterns": {
                    "description": "Extract common patterns (emails, IPs, URLs, etc.)",
                    "parameters": ["text", "pattern_type"],
                    "returns": "Extracted patterns"
                }
            }
        }

    async def execute(self, operation: str = 'keyword_search', **kwargs) -> Dict[str, Any]:
        """Execute a search operation"""
        self.log_usage(operation=operation, **kwargs)

        try:
            if operation == 'regex_search':
                return self._regex_search(**kwargs)
            elif operation == 'keyword_search':
                return self._keyword_search(**kwargs)
            elif operation == 'fuzzy_search':
                return self._fuzzy_search(**kwargs)
            elif operation == 'extract_patterns':
                return self._extract_patterns(**kwargs)
            else:
                return {'success': False, 'error': f'Unknown operation: {operation}'}

        except Exception as e:
            self.log_error(str(e))
            return {'success': False, 'error': str(e)}

    def _regex_search(self, text: str, pattern: str,
                      case_sensitive: bool = False,
                      context_lines: int = 2, **kwargs) -> Dict[str, Any]:
        """Search using regex pattern"""

        flags = 0 if case_sensitive else re.IGNORECASE

        try:
            compiled = re.compile(pattern, flags)
        except re.error as e:
            return {'success': False, 'error': f'Invalid regex: {str(e)}'}

        lines = text.split('\n')
        matches = []

        for i, line in enumerate(lines):
            if compiled.search(line):
                # Get context
                start = max(0, i - context_lines)
                end = min(len(lines), i + context_lines + 1)

                context = []
                for j in range(start, end):
                    marker = '>>>' if j == i else '   '
                    context.append(f"{marker} {j + 1}: {lines[j]}")

                matches.append({
                    'line_number': i + 1,
                    'line': line,
                    'context': '\n'.join(context),
                    'match': compiled.search(line).group(0)
                })

        return {
            'success': True,
            'pattern': pattern,
            'total_matches': len(matches),
            'matches': matches[:50]  # Limit to 50 results
        }

    def _keyword_search(self, text: str, keywords: List[str],
                        match_all: bool = False, **kwargs) -> Dict[str, Any]:
        """Search for keywords in text"""

        lines = text.split('\n')
        matches = []

        for i, line in enumerate(lines):
            line_lower = line.lower()

            if match_all:
                # All keywords must be present
                if all(kw.lower() in line_lower for kw in keywords):
                    matches.append({
                        'line_number': i + 1,
                        'line': line,
                        'matched_keywords': keywords
                    })
            else:
                # Any keyword match
                matched = [kw for kw in keywords if kw.lower() in line_lower]
                if matched:
                    matches.append({
                        'line_number': i + 1,
                        'line': line,
                        'matched_keywords': matched
                    })

        return {
            'success': True,
            'keywords': keywords,
            'match_all': match_all,
            'total_matches': len(matches),
            'matches': matches[:50]
        }

    def _fuzzy_search(self, text: str, query: str,
                      threshold: float = 0.7, **kwargs) -> Dict[str, Any]:
        """Fuzzy/approximate text search"""

        try:
            from difflib import SequenceMatcher
        except ImportError:
            return {'success': False, 'error': 'difflib not available'}

        lines = text.split('\n')
        matches = []

        for i, line in enumerate(lines):
            # Check whole line
            ratio = SequenceMatcher(None, query.lower(), line.lower()).ratio()

            if ratio >= threshold:
                matches.append({
                    'line_number': i + 1,
                    'line': line,
                    'similarity': round(ratio, 2)
                })
            else:
                # Check individual words
                words = line.split()
                for word in words:
                    word_ratio = SequenceMatcher(None, query.lower(), word.lower()).ratio()
                    if word_ratio >= threshold:
                        matches.append({
                            'line_number': i + 1,
                            'line': line,
                            'matched_word': word,
                            'similarity': round(word_ratio, 2)
                        })
                        break

        # Sort by similarity
        matches.sort(key=lambda x: x['similarity'], reverse=True)

        return {
            'success': True,
            'query': query,
            'threshold': threshold,
            'total_matches': len(matches),
            'matches': matches[:20]
        }

    def _extract_patterns(self, text: str, pattern_type: str = 'all', **kwargs) -> Dict[str, Any]:
        """Extract common patterns from text"""

        patterns = {
            'email': r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',
            'url': r'https?://[^\s<>"{}|\\^`\[\]]+',
            'ip': r'\b(?:\d{1,3}\.){3}\d{1,3}\b',
            'date': r'\d{4}-\d{2}-\d{2}|\d{2}/\d{2}/\d{4}',
            'timestamp': r'\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}',
            'phone': r'\+?[\d\s-]{10,}',
            'path': r'(?:/[\w.-]+)+\.?\w*',
            'version': r'\d+\.\d+(?:\.\d+)?',
            'hash': r'[a-f0-9]{32,64}',
        }

        if pattern_type == 'all':
            extract_patterns = patterns
        elif pattern_type in patterns:
            extract_patterns = {pattern_type: patterns[pattern_type]}
        else:
            return {'success': False, 'error': f'Unknown pattern type: {pattern_type}'}

        results = {}

        for name, pattern in extract_patterns.items():
            matches = re.findall(pattern, text, re.IGNORECASE)
            unique_matches = list(set(matches))[:50]  # Unique, limited to 50
            results[name] = {
                'count': len(matches),
                'unique': len(set(matches)),
                'samples': unique_matches[:10]
            }

        return {
            'success': True,
            'pattern_type': pattern_type,
            'results': results
        }