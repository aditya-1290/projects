# tools/sandbox.py
"""
Sandbox - Safe execution environment for agent operations
"""

from typing import Dict, Any, List, Optional
import tempfile
import os
from pathlib import Path
import logging

logger = logging.getLogger(__name__)


class Sandbox:
    """
    Sandboxed environment for safe agent operations.
    Limits file system access, network access, and resource usage.
    """

    def __init__(self, name: str = "agent_sandbox"):
        self.name = name
        self.temp_dir = None
        self.allowed_operations = []
        self.resource_limits = {
            'max_file_size': 10 * 1024 * 1024,  # 10MB
            'max_runtime': 30,  # seconds
            'max_memory': 512 * 1024 * 1024,  # 512MB
        }

    async def setup(self) -> str:
        """Create a sandboxed temporary directory"""
        self.temp_dir = tempfile.mkdtemp(prefix=f"{self.name}_")
        logger.info(f"Sandbox created: {self.temp_dir}")

        return self.temp_dir

    async def cleanup(self):
        """Clean up sandbox directory"""
        if self.temp_dir and os.path.exists(self.temp_dir):
            import shutil
            shutil.rmtree(self.temp_dir)
            logger.info(f"Sandbox cleaned up: {self.temp_dir}")

    def is_allowed_path(self, path: str) -> bool:
        """Check if a path is within the sandbox"""
        if not self.temp_dir:
            return False

        try:
            Path(path).resolve().relative_to(Path(self.temp_dir).resolve())
            return True
        except ValueError:
            return False

    def create_file(self, filename: str, content: str) -> Optional[str]:
        """Create a file within the sandbox"""
        if not self.temp_dir:
            return None

        file_path = Path(self.temp_dir) / filename

        try:
            file_path.parent.mkdir(parents=True, exist_ok=True)

            with open(file_path, 'w') as f:
                f.write(content)

            return str(file_path)

        except Exception as e:
            logger.error(f"Failed to create file in sandbox: {str(e)}")
            return None

    def read_file(self, filename: str) -> Optional[str]:
        """Read a file within the sandbox"""
        if not self.temp_dir:
            return None

        file_path = Path(self.temp_dir) / filename

        if not self.is_allowed_path(str(file_path)):
            return None

        try:
            with open(file_path, 'r') as f:
                return f.read()
        except Exception:
            return None

    def get_sandbox_info(self) -> Dict[str, Any]:
        """Get sandbox information"""
        return {
            'name': self.name,
            'temp_dir': self.temp_dir,
            'exists': os.path.exists(self.temp_dir) if self.temp_dir else False,
            'limits': self.resource_limits
        }