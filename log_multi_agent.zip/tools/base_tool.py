# tools/base_tool.py
"""
Base Tool - Foundation class for all tools
"""

from typing import Dict, Any, Optional, Callable
from abc import ABC, abstractmethod
import logging
from datetime import datetime

logger = logging.getLogger(__name__)


class BaseTool(ABC):
    """
    Abstract base class for all tools.
    Each tool provides specific capabilities that agents can use.
    """

    def __init__(self, name: str, description: str):
        self.name = name
        self.description = description
        self.usage_count = 0
        self.last_used = None
        self.errors = []

    @abstractmethod
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """Execute the tool's functionality"""
        pass

    @abstractmethod
    def get_schema(self) -> Dict[str, Any]:
        """Return the tool's input/output schema for documentation"""
        pass

    def log_usage(self, **kwargs):
        """Log tool usage for monitoring"""
        self.usage_count += 1
        self.last_used = datetime.now()
        logger.debug(f"Tool '{self.name}' used (count: {self.usage_count})")

    def log_error(self, error: str):
        """Log tool errors"""
        self.errors.append({
            'timestamp': datetime.now().isoformat(),
            'error': error
        })
        logger.error(f"Tool '{self.name}' error: {error}")

    def get_stats(self) -> Dict[str, Any]:
        """Get tool usage statistics"""
        return {
            'name': self.name,
            'usage_count': self.usage_count,
            'last_used': self.last_used.isoformat() if self.last_used else None,
            'error_count': len(self.errors),
            'recent_errors': self.errors[-5:] if self.errors else []
        }

    def validate_params(self, params: Dict[str, Any], required: list) -> Optional[str]:
        """Validate that required parameters are present"""
        missing = [p for p in required if p not in params or params[p] is None]

        if missing:
            error_msg = f"Missing required parameters: {', '.join(missing)}"
            self.log_error(error_msg)
            return error_msg

        return None