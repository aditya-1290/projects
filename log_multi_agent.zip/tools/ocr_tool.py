# tools/ocr_tool.py
"""
OCR Tool - Image text extraction for agents
"""

from typing import Dict, Any, List, Optional
from pathlib import Path
import logging

from .base_tool import BaseTool

logger = logging.getLogger(__name__)


class OCRTool(BaseTool):
    """
    Tool for extracting text from images.
    Wraps the DeepSeek OCR model for agent use.
    """

    SUPPORTED_FORMATS = ['.png', '.jpg', '.jpeg', '.bmp', '.webp', '.tiff']

    def __init__(self, ocr_model=None):
        super().__init__(
            name="ocr_tool",
            description="Extract text from images using OCR"
        )
        self.ocr_model = ocr_model

    def get_schema(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "operations": {
                "extract": {
                    "description": "Extract text from an image file",
                    "parameters": ["image_path", "preprocess", "language"],
                    "returns": "Extracted text with confidence scores"
                },
                "batch_extract": {
                    "description": "Extract text from multiple images",
                    "parameters": ["image_paths"],
                    "returns": "List of extraction results"
                },
                "extract_region": {
                    "description": "Extract text from a specific region",
                    "parameters": ["image_path", "x", "y", "width", "height"],
                    "returns": "Text from specified region"
                }
            }
        }

    async def execute(self, operation: str = 'extract', **kwargs) -> Dict[str, Any]:
        """Execute OCR operation"""
        self.log_usage(operation=operation, **kwargs)

        try:
            if operation == 'extract':
                return await self._extract_text(**kwargs)
            elif operation == 'batch_extract':
                return await self._batch_extract(**kwargs)
            elif operation == 'extract_region':
                return await self._extract_region(**kwargs)
            else:
                return {'success': False, 'error': f'Unknown operation: {operation}'}

        except Exception as e:
            self.log_error(str(e))
            return {'success': False, 'error': str(e)}

    async def _extract_text(self, image_path: str, preprocess: bool = True,
                            language: str = 'auto', **kwargs) -> Dict[str, Any]:
        """Extract text from an image"""

        path = Path(image_path)

        if not path.exists():
            return {'success': False, 'error': f'Image not found: {image_path}'}

        if path.suffix.lower() not in self.SUPPORTED_FORMATS:
            return {
                'success': False,
                'error': f'Unsupported format: {path.suffix}. Supported: {self.SUPPORTED_FORMATS}'
            }

        # Preprocess if requested
        processed_path = image_path
        if preprocess:
            try:
                from PIL import Image, ImageEnhance, ImageFilter

                img = Image.open(image_path)

                # Convert to grayscale
                if img.mode != 'L':
                    img = img.convert('L')

                # Enhance contrast
                enhancer = ImageEnhance.Contrast(img)
                img = enhancer.enhance(2.0)

                # Sharpen
                img = img.filter(ImageFilter.SHARPEN)

                # Save preprocessed
                processed_path = str(path.parent / f"_ocr_temp_{path.name}")
                img.save(processed_path)

            except ImportError:
                logger.warning("PIL not available, skipping preprocessing")

        # Run OCR
        if self.ocr_model:
            # Use the actual OCR model
            result = await self.ocr_model.extract_text(processed_path)
        else:
            # Placeholder
            result = {
                'text': f'[OCR would extract text from {path.name}]',
                'confidence': 0.0,
                'regions': []
            }

        # Clean up temp file
        if preprocess and processed_path != image_path:
            try:
                Path(processed_path).unlink()
            except:
                pass

        return {
            'success': True,
            'image': str(path.absolute()),
            'text': result.get('text', ''),
            'confidence': result.get('confidence', 0.0),
            'language': language,
            'preprocessed': preprocess
        }

    async def _batch_extract(self, image_paths: List[str], **kwargs) -> Dict[str, Any]:
        """Extract text from multiple images"""
        results = []

        for path in image_paths:
            result = await self._extract_text(image_path=path, **kwargs)
            results.append(result)

        return {
            'success': True,
            'total': len(image_paths),
            'successful': sum(1 for r in results if r.get('success')),
            'results': results
        }

    async def _extract_region(self, image_path: str, x: int, y: int,
                              width: int, height: int, **kwargs) -> Dict[str, Any]:
        """Extract text from a specific region of an image"""

        try:
            from PIL import Image

            img = Image.open(image_path)
            region = img.crop((x, y, x + width, y + height))

            # Save region as temp file
            temp_path = f"_ocr_region_{Path(image_path).name}"
            region.save(temp_path)

            # Extract text from region
            result = await self._extract_text(image_path=temp_path, preprocess=False)

            # Clean up
            Path(temp_path).unlink(missing_ok=True)

            result['region'] = {'x': x, 'y': y, 'width': width, 'height': height}
            return result

        except ImportError:
            return {'success': False, 'error': 'PIL required for region extraction'}
        except Exception as e:
            return {'success': False, 'error': str(e)}