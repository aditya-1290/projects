# diagnose_models.py
"""Diagnose why models aren't loading."""
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent
sys.path.insert(0, str(PROJECT_ROOT))

# 1. Check what model paths are configured
print("=" * 60)
print("MODEL PATH DIAGNOSTIC")
print("=" * 60)

from config import Config

print(f"\nConfig MODELS_DIR: {Config.MODELS_DIR}")
print(f"Config GEMMA_MODEL_PATH: {Config.GEMMA_MODEL_PATH}")
print(f"Config QWEN_MODEL_PATH: {Config.QWEN_MODEL_PATH}")

# 2. Check actual files on disk
print("\n" + "=" * 60)
print("CHECKING FILES ON DISK")
print("=" * 60)

# Try multiple possible model directories
possible_dirs = [
    Path("D:\\Models"),
    Path("D:/Models"),
    Path.home() / "Models",
    PROJECT_ROOT / "models",
    PROJECT_ROOT.parent / "Models",
]

for d in possible_dirs:
    print(f"\nChecking: {d}")
    if d.exists():
        print(f"  EXISTS: {d}")
        # Look for GGUF files
        gguf_files = list(d.glob("*.gguf"))
        if gguf_files:
            print(f"  GGUF files found:")
            for f in gguf_files:
                size_mb = f.stat().st_size / (1024 * 1024)
                print(f"    - {f.name} ({size_mb:.1f} MB)")
        else:
            print(f"  No .gguf files found")

        # Look for all files
        all_files = list(d.glob("*"))
        print(f"  Total files: {len(all_files)}")
        for f in all_files[:10]:
            print(f"    - {f.name}")
    else:
        print(f"  NOT FOUND: {d}")

# 3. Check environment variables
import os
from dotenv import load_dotenv

load_dotenv()

print("\n" + "=" * 60)
print("ENVIRONMENT VARIABLES")
print("=" * 60)
env_vars = [
    "MODELS_DIR", "GEMMA_MODEL_PATH", "QWEN_MODEL_PATH",
    "DEEPSEEK_OCR_PATH", "QWEN_TEMPERATURE", "QWEN_MAX_TOKENS",
    "GEMMA_TEMPERATURE", "GEMMA_MAX_TOKENS"
]
for var in env_vars:
    print(f"  {var} = {os.getenv(var, 'NOT SET')}")

# 4. Check the model_manager configs
print("\n" + "=" * 60)
print("MODEL MANAGER CONFIGS")
print("=" * 60)

from agentos.model_manager import ModelManager

mm = ModelManager()

for key, config in mm._model_configs.items():
    print(f"\n  Model: {key}")
    print(f"    Type: {config.get('type')}")
    print(f"    Model Name: {config.get('model_name')}")
    print(f"    Model File: {config.get('model_file')}")
    print(f"    Model Path: {config.get('model_path')}")

# 5. Try loading llama-cpp
print("\n" + "=" * 60)
print("LLAMA-CPP AVAILABILITY")
print("=" * 60)

try:
    from llama_cpp import Llama

    print("  llama-cpp-python: INSTALLED")
    print(f"  Version: {Llama.__version__ if hasattr(Llama, '__version__') else 'unknown'}")
except ImportError as e:
    print(f"  llama-cpp-python: NOT INSTALLED - {e}")
    print("  Install with: pip install llama-cpp-python")

# 6. Try to load Qwen model directly
print("\n" + "=" * 60)
print("DIRECT MODEL LOAD TEST")
print("=" * 60)

# Find Qwen model file
qwen_path = None
for d in possible_dirs:
    if d.exists():
        for f in d.glob("*.gguf"):
            if "qwen" in f.name.lower():
                qwen_path = f
                break
    if qwen_path:
        break

if qwen_path:
    print(f"\n  Found Qwen model: {qwen_path}")
    print(f"  Size: {qwen_path.stat().st_size / (1024 * 1024):.1f} MB")

    try:
        from llama_cpp import Llama

        print("  Attempting to load...")
        model = Llama(
            model_path=str(qwen_path),
            n_ctx=4096,
            n_threads=4,
            verbose=True
        )
        print("  SUCCESS: Model loaded!")

        # Test inference
        response = model("Hello, what is 2+2?", max_tokens=50)
        print(f"  Test response: {response['choices'][0]['text'][:100]}")

    except Exception as e:
        print(f"  FAILED: {e}")
        print(f"  Error type: {type(e).__name__}")
else:
    print("\n  Qwen model file NOT FOUND!")
    print("  Looked in:")
    for d in possible_dirs:
        print(f"    - {d}")