# test_pipeline.py
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from agents.extractor.agent import ExtractorAgent
from agents.preprocessor.agent import PreprocessorAgent
from agents.base_agent import A2AMessage, MessageType

TEST_LOG = """2026-04-23 12:17:21,464 - MultiAgentSystem - ERROR - Failed to load Gemma model
2026-04-23 12:18:03,637 - MultiAgentSystem - ERROR - Failed to load Gemma model
2026-04-23 12:25:02,981 - MultiAgentSystem - ERROR - DuckDuckGo returned status 202
2026-04-23 12:43:26,970 - MultiAgentSystem - ERROR - Model path does not exist
2026-04-23 12:46:54,149 - MultiAgentSystem - ERROR - Failed to load Gemma model"""


async def test():
    # Test extractor
    extractor = ExtractorAgent(agent_id="extractor",
                               capability_path="agents/extractor/capabilities.json")

    msg = A2AMessage(
        message_type=MessageType.REQUEST,
        sender_id="system",
        target_id="extractor",
        task={"input": {"text": TEST_LOG, "source_type": "unknown"}}
    )

    response = await extractor.process(msg)
    print(f"Extractor response keys: {response.response.keys() if response.response else 'None'}")
    print(f"Lines extracted: {response.response.get('line_count', 0)}")
    print(f"First 100 chars: {str(response.response.get('raw_content', ''))[:100]}")

    # Test preprocessor
    preprocessor = PreprocessorAgent(agent_id="preprocessor",
                                     capability_path="agents/preprocessor/capabilities.json")

    msg2 = A2AMessage(
        message_type=MessageType.REQUEST,
        sender_id="system",
        target_id="preprocessor",
        task={"input": {"raw_content": TEST_LOG}}
    )

    response2 = await preprocessor.process(msg2)
    print(f"\nPreprocessor response keys: {response2.response.keys() if response2.response else 'None'}")


if __name__ == "__main__":
    import asyncio

    asyncio.run(test())