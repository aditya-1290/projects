# test_gemma_speed.py
import time
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from agentos.model_manager import ModelManager
import asyncio


async def test():
    mm = ModelManager()

    print("Loading Gemma...")
    start = time.time()
    model = await mm.load_model("gemma")
    load_time = time.time() - start
    print(f"Loaded in {load_time:.1f}s")
    print(f"Model type: {type(model).__name__}")

    if hasattr(model, 'create_chat_completion'):
        print("\nTesting inference (this may take a while on CPU)...")

        prompt = "Say 'hello' in one word."
        start = time.time()

        try:
            response = await asyncio.wait_for(
                asyncio.get_event_loop().run_in_executor(
                    None,
                    lambda: model.create_chat_completion(
                        messages=[{"role": "user", "content": prompt}],
                        max_tokens=10,
                        temperature=0.0
                    )
                ),
                timeout=60
            )

            elapsed = time.time() - start
            print(f"Inference took {elapsed:.1f}s")

            text = response.get('choices', [{}])[0].get('message', {}).get('content', '')
            print(f"Response: '{text}'")

            if elapsed > 10:
                print(f"\n⚠️ WARNING: Inference is SLOW ({elapsed:.1f}s)")
                print("This means the solver will timeout waiting for Gemma.")
                print("Set USE_MODEL = False in the solver for instant responses.")
            else:
                print(f"\n✅ Inference is fast enough ({elapsed:.1f}s)")

        except asyncio.TimeoutError:
            print(f"❌ Inference timed out after 60s!")
            print("Gemma is too slow on your hardware.")
            print("Use fallback mode: set USE_MODEL = False")


if __name__ == "__main__":
    asyncio.run(test())