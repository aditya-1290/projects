# models/llm/inference.py
"""
LLM Inference - Common inference interface for all LLM models
"""

from typing import Dict, Any, Optional, List
import logging
import asyncio

logger = logging.getLogger(__name__)


class LLMInference:
    """
    Unified inference interface for all LLM models.
    Handles batching, streaming, and common inference patterns.
    """

    def __init__(self):
        self.models = {}
        self.default_model = None

    def register_model(self, name: str, model: Any, prompt_formatter: callable):
        """Register a model with its prompt formatter"""
        self.models[name] = {
            'model': model,
            'format_prompt': prompt_formatter,
        }

        if not self.default_model:
            self.default_model = name

    async def generate(self, prompt: str, model_name: str = None,
                       system_prompt: str = None, **kwargs) -> str:
        """Generate a response from a model"""
        model_name = model_name or self.default_model

        if model_name not in self.models:
            return f"Error: Model '{model_name}' not registered"

        model_info = self.models[model_name]
        model = model_info['model']
        formatter = model_info['format_prompt']

        # Format the prompt if needed
        if system_prompt:
            formatted_prompt = formatter(system_prompt, prompt)
        else:
            formatted_prompt = prompt

        # Run inference in a thread to not block
        loop = asyncio.get_event_loop()

        try:
            result = await loop.run_in_executor(
                None,
                lambda: model(formatted_prompt, **kwargs)
            )

            if isinstance(result, dict):
                return result.get('choices', [{}])[0].get('text', '')
            return str(result)

        except Exception as e:
            logger.error(f"Inference error: {str(e)}")
            return f"Error during inference: {str(e)}"

    async def generate_with_history(self, messages: List[Dict[str, str]],
                                    model_name: str = None, **kwargs) -> str:
        """Generate a response with conversation history"""
        # Extract system prompt if present
        system_prompt = None
        user_messages = []

        for msg in messages:
            if msg['role'] == 'system':
                system_prompt = msg['content']
            else:
                user_messages.append(msg)

        # Get the last user message
        last_message = user_messages[-1]['content'] if user_messages else ""
        history = user_messages[:-1] if len(user_messages) > 1 else []

        return await self.generate(
            prompt=last_message,
            model_name=model_name,
            system_prompt=system_prompt,
            history=history,
            **kwargs
        )

    async def stream_generate(self, prompt: str, model_name: str = None, **kwargs):
        """Stream tokens as they're generated"""
        model_name = model_name or self.default_model

        if model_name not in self.models:
            yield "Error: Model not found"
            return

        model = self.models[model_name]['model']

        # Streaming implementation would go here
        # This is a simplified example
        loop = asyncio.get_event_loop()

        def sync_generate():
            return model(prompt, stream=True, **kwargs)

        generator = await loop.run_in_executor(None, sync_generate)

        for token in generator:
            yield token