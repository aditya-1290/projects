# models/llm/context_manager.py
"""
Context Manager - Manages context windows for LLM inference
"""

from typing import Dict, Any, List, Optional
import tiktoken


class ContextManager:
    """
    Manages context windows and token limits for LLM models.
    Helps prevent context overflow and manages conversation history.
    """

    def __init__(self, max_tokens: int = 4096):
        self.max_tokens = max_tokens
        self.reserved_tokens = 500  # Reserve for model response
        self.available_tokens = max_tokens - self.reserved_tokens

    def count_tokens(self, text: str) -> int:
        """Count the number of tokens in text"""
        # Using cl100k_base encoding (common for many models)
        # Adjust based on your specific model's tokenizer
        try:
            encoding = tiktoken.get_encoding("cl100k_base")
            return len(encoding.encode(text))
        except Exception:
            # Fallback: rough estimate (4 chars per token)
            return len(text) // 4

    def fit_text_to_context(self, text: str, max_tokens: int = None) -> str:
        """Trim text to fit within token limit"""
        limit = max_tokens or self.available_tokens

        token_count = self.count_tokens(text)

        if token_count <= limit:
            return text

        # Trim from the middle, keeping start and end
        lines = text.split('\n')

        # Keep first 25% and last 75%
        start_lines = int(len(lines) * 0.25)

        start = '\n'.join(lines[:start_lines])
        end = '\n'.join(lines[start_lines:])

        # Further trim end if needed
        while self.count_tokens(start + "\n...[truncated]...\n" + end) > limit:
            end_lines = end.split('\n')
            if len(end_lines) > 1:
                end = '\n'.join(end_lines[1:])
            else:
                break

        return start + "\n...[truncated]...\n" + end

    def manage_conversation_history(self, messages: List[Dict[str, str]],
                                    system_prompt: str = "") -> List[Dict[str, str]]:
        """Trim conversation history to fit context window"""
        if not messages:
            return []

        # Count system prompt tokens
        system_tokens = self.count_tokens(system_prompt) if system_prompt else 0
        available = self.available_tokens - system_tokens

        # Start from most recent messages
        kept_messages = []
        total_tokens = 0

        for msg in reversed(messages):
            msg_tokens = self.count_tokens(msg.get('content', ''))

            if total_tokens + msg_tokens > available:
                break

            kept_messages.insert(0, msg)
            total_tokens += msg_tokens

        return kept_messages

    def chunk_long_text(self, text: str, chunk_size: int = None) -> List[str]:
        """Split long text into overlapping chunks for processing"""
        chunk_size = chunk_size or (self.available_tokens // 2)
        overlap = chunk_size // 4

        lines = text.split('\n')
        chunks = []
        current_chunk = []
        current_tokens = 0

        for line in lines:
            line_tokens = self.count_tokens(line)

            if current_tokens + line_tokens > chunk_size and current_chunk:
                chunks.append('\n'.join(current_chunk))

                # Keep overlap lines
                overlap_tokens = 0
                overlap_lines = []

                for ol in reversed(current_chunk):
                    ol_tokens = self.count_tokens(ol)
                    if overlap_tokens + ol_tokens > overlap:
                        break
                    overlap_lines.insert(0, ol)
                    overlap_tokens += ol_tokens

                current_chunk = overlap_lines
                current_tokens = overlap_tokens

            current_chunk.append(line)
            current_tokens += line_tokens

        if current_chunk:
            chunks.append('\n'.join(current_chunk))

        return chunks

    def get_context_stats(self, text: str) -> Dict[str, Any]:
        """Get statistics about text size relative to context"""
        token_count = self.count_tokens(text)

        return {
            'token_count': token_count,
            'max_tokens': self.max_tokens,
            'available_tokens': self.available_tokens,
            'usage_percent': (token_count / self.max_tokens) * 100,
            'fits_context': token_count <= self.available_tokens,
            'tokens_remaining': self.available_tokens - token_count,
        }