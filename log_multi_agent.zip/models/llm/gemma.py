# models/llm/gemma.py
"""
Gemma Model - Specific handling for Gemma-4-E4B-it
"""

from typing import Optional, Any, List, Dict
import logging

logger = logging.getLogger(__name__)


class GemmaModel:
    """
    Gemma model wrapper.
    Handles Gemma-specific prompt formatting and inference.
    """

    # Gemma uses a specific chat template
    CHAT_TEMPLATE = """<bos><start_of_turn>user
{user_message}<end_of_turn>
<start_of_turn>model
{model_response}<end_of_turn>
"""

    SYSTEM_PROMPT_TEMPLATE = """<bos><start_of_turn>system
{system_prompt}<end_of_turn>
"""

    def __init__(self, model: Any = None):
        self.model = model
        self.model_name = "gemma-4-e4b-it"

    def load(self, model_path: str, **kwargs) -> bool:
        """Load the Gemma model"""
        from .loader import LLMLoader

        loader = LLMLoader()

        # Gemma specific defaults
        gemma_kwargs = {
            'n_ctx': kwargs.get('n_ctx', 8192),
            'n_threads': kwargs.get('n_threads', 4),
            'use_mlock': kwargs.get('use_mlock', True),
            **kwargs
        }

        self.model = loader.load_gguf(model_path, **gemma_kwargs)
        return self.model is not None

    def format_prompt(self, system_prompt: str, user_message: str,
                      history: List[Dict[str, str]] = None) -> str:
        """
        Format a prompt in Gemma's expected format.
        Gemma uses <start_of_turn> and <end_of_turn> tokens.
        """
        prompt = ""

        # Add system prompt if provided
        if system_prompt:
            prompt += self.SYSTEM_PROMPT_TEMPLATE.format(system_prompt=system_prompt)

        # Add conversation history
        if history:
            for msg in history:
                if msg['role'] == 'user':
                    prompt += f"<start_of_turn>user\n{msg['content']}<end_of_turn>\n"
                elif msg['role'] == 'assistant':
                    prompt += f"<start_of_turn>model\n{msg['content']}<end_of_turn>\n"

        # Add current user message
        prompt += f"<start_of_turn>user\n{user_message}<end_of_turn>\n"
        prompt += "<start_of_turn>model\n"

        return prompt

    def generate(self, prompt: str, max_tokens: int = 4096,
                 temperature: float = 0.7, **kwargs) -> str:
        """Generate a response from the Gemma model"""
        if not self.model:
            return "Error: Model not loaded"

        try:
            # Using llama-cpp-python API
            response = self.model(
                prompt,
                max_tokens=max_tokens,
                temperature=temperature,
                top_p=kwargs.get('top_p', 0.9),
                top_k=kwargs.get('top_k', 40),
                repeat_penalty=kwargs.get('repeat_penalty', 1.1),
                stop=kwargs.get('stop', ['<end_of_turn>', '<start_of_turn>']),
                echo=False,
            )

            return response['choices'][0]['text']

        except Exception as e:
            logger.error(f"Gemma generation error: {str(e)}")
            return f"Error generating response: {str(e)}"

    def generate_with_context(self, system_prompt: str, user_message: str,
                              history: List[Dict] = None, **kwargs) -> str:
        """Generate a response with full context"""
        prompt = self.format_prompt(system_prompt, user_message, history)
        return self.generate(prompt, **kwargs)