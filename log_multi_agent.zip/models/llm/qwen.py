# models/llm/qwen.py
"""
Qwen Model - Specific handling for Qwen-2.5-3B
"""

from typing import Optional, Any, List, Dict
import logging

logger = logging.getLogger(__name__)


class QwenModel:
    """
    Qwen model wrapper.
    Handles Qwen-specific prompt formatting and inference.
    """

    # Qwen uses a different chat template than Gemma
    CHAT_TEMPLATE = """<|im_start|>system
{system_prompt}<|im_end|>
<|im_start|>user
{user_message}<|im_end|>
<|im_start|>assistant
"""

    def __init__(self, model: Any = None):
        self.model = model
        self.model_name = "qwen-2.5-3b-instruct"

    def load(self, model_path: str, **kwargs) -> bool:
        """Load the Qwen model"""
        from .loader import LLMLoader

        loader = LLMLoader()

        # Qwen specific defaults (smaller model, less context needed)
        qwen_kwargs = {
            'n_ctx': kwargs.get('n_ctx', 4096),
            'n_threads': kwargs.get('n_threads', 4),
            'use_mlock': kwargs.get('use_mlock', False),
            **kwargs
        }

        self.model = loader.load_gguf(model_path, **qwen_kwargs)
        return self.model is not None

    def format_prompt(self, system_prompt: str, user_message: str,
                      history: List[Dict[str, str]] = None) -> str:
        """
        Format a prompt in Qwen's expected format.
        Qwen uses <|im_start|> and <|im_end|> tokens.
        """
        prompt = f"<|im_start|>system\n{system_prompt}<|im_end|>\n"

        # Add conversation history
        if history:
            for msg in history:
                if msg['role'] == 'user':
                    prompt += f"<|im_start|>user\n{msg['content']}<|im_end|>\n"
                elif msg['role'] == 'assistant':
                    prompt += f"<|im_start|>assistant\n{msg['content']}<|im_end|>\n"

        # Add current user message
        prompt += f"<|im_start|>user\n{user_message}<|im_end|>\n"
        prompt += "<|im_start|>assistant\n"

        return prompt

    def generate(self, prompt: str, max_tokens: int = 2048,
                 temperature: float = 0.1, **kwargs) -> str:
        """
        Generate a response from the Qwen model.
        Qwen is used for preprocessing tasks, so lower temperature for consistency.
        """
        if not self.model:
            return "Error: Model not loaded"

        try:
            response = self.model(
                prompt,
                max_tokens=max_tokens,
                temperature=temperature,
                top_p=kwargs.get('top_p', 0.9),
                top_k=kwargs.get('top_k', 40),
                repeat_penalty=kwargs.get('repeat_penalty', 1.1),
                stop=kwargs.get('stop', ['<|im_end|>', '<|im_start|>']),
                echo=False,
            )

            return response['choices'][0]['text']

        except Exception as e:
            logger.error(f"Qwen generation error: {str(e)}")
            return f"Error generating response: {str(e)}"