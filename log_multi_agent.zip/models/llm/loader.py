# models/llm/loader.py
"""
LLM Loader - Handles loading GGUF format LLM models
"""

from typing import Optional, Any
from pathlib import Path
import logging

logger = logging.getLogger(__name__)


class LLMLoader:
    """Loads GGUF format language models"""

    def __init__(self):
        self.loaded_models = {}

    def load_gguf(self, model_path: str, **kwargs) -> Optional[Any]:
        """
        Load a GGUF model file.
        Supports Gemma, Qwen, and other GGUF format models.
        """
        path = Path(model_path)

        if not path.exists():
            logger.error(f"Model file not found: {path}")
            return None

        logger.info(f"Loading GGUF model: {path.name}")

        try:
            # Using llama-cpp-python
            from llama_cpp import Llama

            model = Llama(
                model_path=str(path),
                n_ctx=kwargs.get('n_ctx', 4096),
                n_threads=kwargs.get('n_threads', 4),
                n_gpu_layers=kwargs.get('n_gpu_layers', 0),
                use_mlock=kwargs.get('use_mlock', True),
                verbose=kwargs.get('verbose', False),
            )

            logger.info(f"Model loaded: {path.name}")
            return model

        except ImportError:
            logger.error(
                "llama-cpp-python not installed. "
                "Install with: pip install llama-cpp-python"
            )
            return None
        except Exception as e:
            logger.error(f"Failed to load model: {str(e)}")
            return None

    def load_with_config(self, model_path: str, config: dict) -> Optional[Any]:
        """Load a model with a configuration dictionary"""
        return self.load_gguf(model_path, **config)

    def get_model_metadata(self, model_path: str) -> Optional[dict]:
        """Get metadata from a GGUF file without fully loading it"""
        path = Path(model_path)

        if not path.exists():
            return None

        # Basic file info
        import os
        stat = path.stat()

        return {
            'file_name': path.name,
            'file_size_mb': stat.st_size / (1024 * 1024),
            'last_modified': stat.st_mtime,
        }