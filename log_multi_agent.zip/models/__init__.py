# models/__init__.py
"""
Models - Model loading and inference layer
Handles GGUF models, OCR models, and embeddings
"""

from .model_configs import ModelConfigs
from .manager import ModelManager

__all__ = ['ModelConfigs', 'ModelManager']