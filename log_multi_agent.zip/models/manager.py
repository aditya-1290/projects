# models/manager.py
"""
Model Manager - Handles loading, unloading, and inference for all models
"""

from typing import Dict, Any, Optional, List
from pathlib import Path
import logging
import asyncio

from .model_configs import ModelConfigs, ModelConfig

logger = logging.getLogger(__name__)


class ModelManager:
    """
    Central manager for all AI models.
    Handles loading GGUF files, running inference, and managing resources.
    """

    def __init__(self, models_dir: str = "D:\\Models"):
        self.models_dir = Path(models_dir)
        self.models_dir.mkdir(parents=True, exist_ok=True)

        self._loaded_models: Dict[str, Any] = {}
        self._model_configs = ModelConfigs.get_all_models()

        # Check which models are available
        self.available_models = self._check_available_models()

    def _check_available_models(self) -> Dict[str, bool]:
        """Check which models are actually downloaded and available"""
        available = {}

        for model_key, config in self._model_configs.items():
            model_path = ModelConfigs.get_model_path(model_key)
            if model_path and model_path.exists():
                available[model_key] = True
                logger.info(f"Model found: {model_key} at {model_path}")
            else:
                available[model_key] = False
                logger.warning(f"Model not found: {model_key} ({model_path})")

        return available

    async def load_model(self, model_key: str) -> Optional[Any]:
        """
        Load a model into memory.
        The actual loading depends on the model type (GGUF, OCR, etc.)
        """
        if model_key in self._loaded_models:
            logger.info(f"Model {model_key} already loaded")
            return self._loaded_models[model_key]

        if not self.available_models.get(model_key):
            logger.error(f"Model {model_key} is not available")
            return None

        config = ModelConfigs.get_config(model_key)
        if not config:
            logger.error(f"No config found for model {model_key}")
            return None

        logger.info(f"Loading model: {config.name} ({model_key})")

        try:
            if config.type == 'llm':
                model = await self._load_gguf_model(config)
            elif config.type == 'ocr':
                model = await self._load_ocr_model(config)
            elif config.type == 'embeddings':
                model = await self._load_embeddings_model(config)
            else:
                logger.error(f"Unknown model type: {config.type}")
                return None

            self._loaded_models[model_key] = model
            logger.info(f"Model {config.name} loaded successfully")

            return model

        except Exception as e:
            logger.error(f"Failed to load model {model_key}: {str(e)}")
            return None

    async def _load_gguf_model(self, config: ModelConfig) -> Any:
        """
        Load a GGUF format model using llama-cpp-python or similar.
        This is where you'd integrate with the actual GGUF loading library.
        """
        model_path = ModelConfigs.get_model_path(config.model_file.split('/')[-1]
                                                 if '/' in config.model_file
                                                 else config.model_file)

        if not model_path or not model_path.exists():
            raise FileNotFoundError(f"GGUF model not found: {model_path}")

        logger.info(f"Loading GGUF model from: {model_path}")

        # Example using llama-cpp-python (you'd need to install it)
        try:
            # Uncomment when you have llama-cpp-python installed
            # from llama_cpp import Llama
            #
            # model = Llama(
            #     model_path=str(model_path),
            #     n_ctx=config.context_size,
            #     n_threads=config.n_threads,
            #     n_gpu_layers=config.gpu_layers,
            #     use_mlock=config.use_mlock,
            #     verbose=config.verbose,
            # )

            # For now, return a placeholder that explains what to do
            logger.warning("llama-cpp-python not installed. Install with: pip install llama-cpp-python")

            model = {
                'type': 'gguf',
                'name': config.name,
                'path': str(model_path),
                'config': config,
                'status': 'placeholder',
                'message': 'Install llama-cpp-python to enable GGUF model loading'
            }

            return model

        except ImportError:
            logger.error("llama-cpp-python not installed")
            raise

    async def _load_ocr_model(self, config: ModelConfig) -> Any:
        """
        Load the OCR model (DeepSeek OCR).
        This handles image-to-text extraction.
        """
        logger.info(f"Loading OCR model: {config.name}")

        # DeepSeek OCR integration would go here
        # This could be:
        # - An API call to DeepSeek
        # - A local model loaded with transformers
        # - A custom integration

        try:
            # Placeholder - replace with actual OCR model loading
            # from transformers import pipeline
            # ocr_model = pipeline('image-to-text', model=config.name)

            model = {
                'type': 'ocr',
                'name': config.name,
                'config': config,
                'status': 'placeholder',
                'message': 'Configure DeepSeek OCR integration here'
            }

            return model

        except Exception as e:
            logger.error(f"Failed to load OCR model: {str(e)}")
            raise

    async def _load_embeddings_model(self, config: ModelConfig) -> Any:
        """
        Load the embeddings model for vector storage and retrieval.
        """
        logger.info(f"Loading embeddings model: {config.name}")

        try:
            # Placeholder - replace with actual embeddings model
            # from sentence_transformers import SentenceTransformer
            # model = SentenceTransformer(config.name)

            model = {
                'type': 'embeddings',
                'name': config.name,
                'config': config,
                'status': 'placeholder',
                'message': 'Configure embeddings model here'
            }

            return model

        except Exception as e:
            logger.error(f"Failed to load embeddings model: {str(e)}")
            raise

    async def unload_model(self, model_key: str):
        """Unload a model to free memory"""
        if model_key in self._loaded_models:
            logger.info(f"Unloading model: {model_key}")
            del self._loaded_models[model_key]

    async def unload_all(self):
        """Unload all models"""
        logger.info("Unloading all models")
        self._loaded_models.clear()

    def is_loaded(self, model_key: str) -> bool:
        """Check if a model is loaded"""
        return model_key in self._loaded_models

    def get_loaded_models(self) -> List[str]:
        """Get list of currently loaded models"""
        return list(self._loaded_models.keys())

    def get_model_info(self, model_key: str) -> Optional[Dict[str, Any]]:
        """Get information about a model"""
        config = ModelConfigs.get_config(model_key)
        if not config:
            return None

        return {
            'key': model_key,
            'name': config.name,
            'type': config.type,
            'is_available': self.available_models.get(model_key, False),
            'is_loaded': self.is_loaded(model_key),
            'config': {
                'context_size': config.context_size,
                'max_tokens': config.max_tokens,
                'temperature': config.temperature,
            }
        }