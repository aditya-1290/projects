# models/embeddings/__init__.py
"""
Embeddings - Text embeddings for vector storage and retrieval
"""

from .embedding_model import EmbeddingModel

__all__ = ['EmbeddingModel']