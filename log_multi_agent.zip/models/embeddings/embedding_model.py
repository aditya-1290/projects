# models/embeddings/embedding_model.py
"""
Embedding Model - Generates text embeddings for semantic search
"""

from typing import List, Dict, Any, Optional
import logging
import hashlib

logger = logging.getLogger(__name__)


class EmbeddingModel:
    """
    Text embedding model for semantic search and retrieval.
    Used by the Memory agent to find relevant past experiences.
    """

    def __init__(self, model: Any = None):
        self.model = model
        self.model_name = "bge-small-en-v1.5"
        self.dimension = 384  # Embedding dimension for MiniLM
        self.cache = {}  # Simple cache for embeddings

    def load(self, model_path: str = None) -> bool:
        """Load the embeddings model"""
        logger.info(f"Loading embeddings model: {self.model_name}")

        try:
            # Using sentence-transformers
            from sentence_transformers import SentenceTransformer

            self.model = SentenceTransformer(self.model_name)

            logger.info("Embeddings model loaded")
            return True

        except ImportError:
            logger.warning(
                "sentence-transformers not installed. "
                "Install with: pip install sentence-transformers"
            )
            return False
        except Exception as e:
            logger.error(f"Failed to load embeddings model: {str(e)}")
            return False

    def embed(self, text: str) -> List[float]:
        """
        Generate embedding vector for text.
        """
        if not text:
            return [0.0] * self.dimension

        # Check cache
        cache_key = hashlib.md5(text.encode()).hexdigest()
        if cache_key in self.cache:
            return self.cache[cache_key]

        try:
            if self.model:
                # Using sentence-transformers
                embedding = self.model.encode(text, convert_to_numpy=True)
                result = embedding.tolist()
            else:
                # Fallback: random embedding (for testing)
                import random
                random.seed(hash(text))
                result = [random.uniform(-1, 1) for _ in range(self.dimension)]

            # Cache the result
            self.cache[cache_key] = result

            return result

        except Exception as e:
            logger.error(f"Embedding generation failed: {str(e)}")
            return [0.0] * self.dimension

    def embed_batch(self, texts: List[str]) -> List[List[float]]:
        """Generate embeddings for multiple texts"""
        if self.model:
            try:
                embeddings = self.model.encode(texts, convert_to_numpy=True)
                return embeddings.tolist()
            except Exception as e:
                logger.error(f"Batch embedding failed: {str(e)}")

        # Fallback: embed one by one
        return [self.embed(text) for text in texts]

    def similarity(self, embedding1: List[float], embedding2: List[float]) -> float:
        """
        Calculate cosine similarity between two embeddings.
        """
        if not embedding1 or not embedding2:
            return 0.0

        try:
            import numpy as np

            a = np.array(embedding1)
            b = np.array(embedding2)

            dot_product = np.dot(a, b)
            norm_a = np.linalg.norm(a)
            norm_b = np.linalg.norm(b)

            if norm_a == 0 or norm_b == 0:
                return 0.0

            return float(dot_product / (norm_a * norm_b))

        except Exception as e:
            logger.error(f"Similarity calculation failed: {str(e)}")
            return 0.0

    def find_most_similar(self, query: str, candidates: List[str],
                          top_k: int = 5) -> List[Dict[str, Any]]:
        """
        Find most similar texts to a query.
        """
        if not query or not candidates:
            return []

        query_embedding = self.embed(query)
        candidate_embeddings = self.embed_batch(candidates)

        # Calculate similarities
        similarities = []
        for i, cand_embedding in enumerate(candidate_embeddings):
            sim = self.similarity(query_embedding, cand_embedding)
            similarities.append({
                'index': i,
                'text': candidates[i][:200],  # Truncate for display
                'similarity': sim
            })

        # Sort by similarity (highest first)
        similarities.sort(key=lambda x: x['similarity'], reverse=True)

        return similarities[:top_k]

    def clear_cache(self):
        """Clear the embedding cache"""
        self.cache.clear()
        logger.info("Embedding cache cleared")

    def get_cache_stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        return {
            'cached_entries': len(self.cache),
            'dimension': self.dimension,
            'model_name': self.model_name,
            'model_loaded': self.model is not None
        }