# models/model_configs.py
"""
Model Configurations - Central config for all models used in the system
"""

from typing import Dict, Any, Optional
from pathlib import Path
from dataclasses import dataclass, field
import os


@dataclass
class ModelConfig:
    """Configuration for a single model"""
    name: str
    type: str  # 'llm', 'ocr', 'embeddings'
    model_path: Optional[str] = None
    model_file: Optional[str] = None
    context_size: int = 4096
    max_tokens: int = 2048
    temperature: float = 0.7
    top_p: float = 0.9
    top_k: int = 40
    repeat_penalty: float = 1.1
    gpu_layers: int = 0  # 0 = CPU only
    n_threads: int = 4
    use_mlock: bool = True
    verbose: bool = False


class ModelConfigs:
    """Manages configurations for all models in the system"""
    MODELS_DIR = Path(os.getenv("MODEL_DIR", "D:/python_tasks/models"))
    MODELS = {
        'gemma': ModelConfig(
            name='gemma-4-E4B-it-Q5_K_M.gguf',
            type='llm',
            model_file='gemma-4-E4B-it-Q5_K_M.gguf',
            context_size=8192,
            max_tokens=4096,
            temperature=0.3,
            gpu_layers=0,  # Set based on your GPU
        ),
        'qwen': ModelConfig(
            name='qwen2.5-3b-instruct-q4_k_m.gguf',
            type='llm',
            model_file='qwen2.5-3b-instruct-q4_k_m.gguf',
            context_size=4096,
            max_tokens=2048,
            temperature=0.1,
            gpu_layers=0,
        ),
        'deepseek_ocr': ModelConfig(
            name='deepseek-ocr-2',
            type='ocr',
            model_path=str(MODELS_DIR / 'DeepSeek_OCR-2'),
            model_file='model.safetensors.index.json'
        ),
        'embeddings': ModelConfig(
            name='bge-small-en-v1.5',
            type='embeddings',
            model_path=str(MODELS_DIR / 'bge_small_en-v1.5'),
            model_file='model.safetensors'
        ),
    }

    @classmethod
    def get_config(cls, model_key: str) -> Optional[ModelConfig]:
        """Get configuration for a specific model"""
        return cls.MODELS.get(model_key)

    @classmethod
    def get_all_models(cls) -> Dict[str, ModelConfig]:
        """Get all model configurations"""
        return cls.MODELS.copy()

    @classmethod
    def update_config(cls, model_key: str, **kwargs):
        """Update a model's configuration dynamically"""
        if model_key in cls.MODELS:
            config = cls.MODELS[model_key]
            for key, value in kwargs.items():
                if hasattr(config, key):
                    setattr(config, key, value)

    @classmethod
    def get_model_path(cls, model_key: str) -> Optional[Path]:
        """Get the full path to a model file"""
        config = cls.get_config(model_key)
        if not config:
            return None
        if config.type == 'llm':
            return cls.MODELS_DIR / config.model_file
        elif config.type in ('ocr', 'embeddings'):
            return Path(config.model_path)
        return None