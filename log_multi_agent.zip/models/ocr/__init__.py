# models/ocr/__init__.py
"""
OCR - Optical Character Recognition (DeepSeek OCR)
"""

from .deepseek_ocr import DeepSeekOCR

__all__ = ['DeepSeekOCR']