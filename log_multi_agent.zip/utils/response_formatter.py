# utils/response_formatter.py
"""
Response Formatter - Formats agent outputs for user display
"""

from typing import Dict, Any, List, Optional
from datetime import datetime


class ResponseFormatter:
    """Utility for formatting responses for display"""

    @staticmethod
    def format_analysis_result(analysis: Dict[str, Any]) -> str:
        """Format analysis results for user display"""
        sections = []

        sections.append("=" * 60)
        sections.append("LOG ANALYSIS RESULTS")
        sections.append("=" * 60)

        # Classification
        if 'classification' in analysis:
            sections.append(f"\n📊 Classification: {analysis['classification']}")

        # Summary
        if 'summary' in analysis:
            sections.append(f"\n📝 Summary:\n{analysis['summary']}")

        # Patterns
        if 'patterns' in analysis:
            sections.append(f"\n🔍 Patterns Found:\n{analysis['patterns']}")

        # Anomalies
        if 'anomalies' in analysis:
            sections.append(f"\n⚠️ Anomalies:\n{analysis['anomalies']}")

        # Recommendations
        if 'recommendations' in analysis:
            sections.append(f"\n💡 Recommendations:\n{analysis['recommendations']}")

        sections.append("\n" + "=" * 60)

        return '\n'.join(sections)

    @staticmethod
    def format_solution(solution: Dict[str, Any]) -> str:
        """Format solution for user display"""
        sections = []

        sections.append("=" * 60)
        sections.append("SOLUTION")
        sections.append("=" * 60)

        if 'problem_understanding' in solution:
            sections.append(f"\n🔍 Problem:\n{solution['problem_understanding']}")

        if 'recommended_solution' in solution:
            sections.append(f"\n✅ Solution:\n{solution['recommended_solution']}")

        if 'user_explanation' in solution:
            sections.append(f"\n📖 Explanation:\n{solution['user_explanation']}")

        if 'risk_assessment' in solution:
            sections.append(f"\n⚠️ Risks:\n{solution['risk_assessment']}")

        sections.append("\n" + "=" * 60)

        return '\n'.join(sections)

    @staticmethod
    def format_error(error: str, details: Dict = None) -> str:
        """Format error message for user display"""
        sections = []

        sections.append("=" * 60)
        sections.append("❌ ERROR")
        sections.append("=" * 60)
        sections.append(f"\n{error}")

        if details:
            sections.append(f"\nDetails:")
            for key, value in details.items():
                sections.append(f"  {key}: {value}")

        sections.append("\n" + "=" * 60)

        return '\n'.join(sections)

    @staticmethod
    def format_debug_result(debug_result: Dict[str, Any]) -> str:
        """Format debugging results for display"""
        sections = []

        sections.append("=" * 60)
        sections.append("DEBUGGING RESULTS")
        sections.append("=" * 60)

        if 'error_analysis' in debug_result:
            sections.append(f"\n🐛 Error Analysis:\n{debug_result['error_analysis']}")

        if 'code_analysis' in debug_result:
            sections.append(f"\n📋 Code Analysis:\n{debug_result['code_analysis']}")

        if 'fix' in debug_result:
            sections.append(f"\n🔧 Fix:\n{debug_result['fix']}")

        if 'tests' in debug_result:
            sections.append(f"\n🧪 Tests:\n{debug_result['tests']}")

        if 'prevention' in debug_result:
            sections.append(f"\n🛡️ Prevention:\n{debug_result['prevention']}")

        sections.append("\n" + "=" * 60)

        return '\n'.join(sections)

    @staticmethod
    def format_workflow_result(result: Dict[str, Any]) -> str:
        """Format orchestrator workflow result"""
        sections = []

        sections.append("=" * 60)
        sections.append("WORKFLOW COMPLETE")
        sections.append("=" * 60)

        if 'final_response' in result:
            sections.append(f"\n{result['final_response']}")

        if 'workflow_plan' in result:
            sections.append(f"\n📋 Workflow:\n{result['workflow_plan'][:200]}...")

        sections.append("\n" + "=" * 60)

        return '\n'.join(sections)

    @staticmethod
    def truncate_for_display(text: str, max_length: int = 500) -> str:
        """Truncate text for display with indicator"""
        if len(text) <= max_length:
            return text

        return text[:max_length] + f"\n... [truncated {len(text) - max_length} characters]"