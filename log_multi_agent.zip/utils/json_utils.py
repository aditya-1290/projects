# utils/json_utils.py
"""
JSON Utilities - Safe JSON parsing and manipulation
"""

import json
from typing import Any, Dict, List, Optional


class JSONUtils:
    """Utility functions for JSON handling"""

    @staticmethod
    def safe_parse(text: str) -> Optional[Any]:
        """Safely parse a JSON string, returning None on failure"""
        if not text or not text.strip():
            return None

        try:
            return json.loads(text)
        except json.JSONDecodeError:
            # Try to extract JSON from text
            import re

            # Find JSON-like structures
            json_match = re.search(r'\{.*\}|\[.*\]', text, re.DOTALL)
            if json_match:
                try:
                    return json.loads(json_match.group(0))
                except json.JSONDecodeError:
                    pass

            return None

    @staticmethod
    def safe_dumps(obj: Any, indent: int = 2, default=str) -> str:
        """Safely convert an object to JSON string"""
        try:
            return json.dumps(obj, indent=indent, default=default, ensure_ascii=False)
        except (TypeError, ValueError) as e:
            return json.dumps({'error': f'Serialization failed: {str(e)}'}, indent=indent)

    @staticmethod
    def extract_value(data: Dict, path: str, default: Any = None) -> Any:
        """Extract a value from nested dict using dot notation"""
        keys = path.split('.')
        current = data

        for key in keys:
            if isinstance(current, dict):
                current = current.get(key)
            else:
                return default

            if current is None:
                return default

        return current

    @staticmethod
    def flatten_dict(data: Dict, prefix: str = "") -> Dict[str, Any]:
        """Flatten a nested dictionary"""
        result = {}

        for key, value in data.items():
            full_key = f"{prefix}.{key}" if prefix else key

            if isinstance(value, dict):
                result.update(JSONUtils.flatten_dict(value, full_key))
            elif isinstance(value, list):
                for i, item in enumerate(value):
                    if isinstance(item, dict):
                        result.update(JSONUtils.flatten_dict(item, f"{full_key}[{i}]"))
                    else:
                        result[f"{full_key}[{i}]"] = item
            else:
                result[full_key] = value

        return result

    @staticmethod
    def deep_merge(base: Dict, override: Dict) -> Dict:
        """Deep merge two dictionaries"""
        result = base.copy()

        for key, value in override.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = JSONUtils.deep_merge(result[key], value)
            else:
                result[key] = value

        return result