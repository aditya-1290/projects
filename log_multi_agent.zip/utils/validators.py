# utils/validators.py
"""
Validators - Input validation utilities
"""

import re
from typing import Any, Dict, List, Optional
from pathlib import Path


class Validators:
    """Validation utilities for inputs and data"""

    @staticmethod
    def is_valid_ip(ip: str) -> bool:
        """Check if string is a valid IP address"""
        pattern = r'^(\d{1,3}\.){3}\d{1,3}$'
        if not re.match(pattern, ip):
            return False

        parts = ip.split('.')
        return all(0 <= int(part) <= 255 for part in parts)

    @staticmethod
    def is_valid_hostname(hostname: str) -> bool:
        """Check if string is a valid hostname"""
        if len(hostname) > 255:
            return False

        pattern = r'^[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?$'

        # Check each label
        labels = hostname.split('.')
        return all(re.match(pattern, label) for label in labels if label)

    @staticmethod
    def is_valid_timestamp(ts: str) -> bool:
        """Check if string could be a valid timestamp"""
        from datetime import datetime

        common_formats = [
            '%Y-%m-%dT%H:%M:%S.%fZ',
            '%Y-%m-%dT%H:%M:%S',
            '%Y-%m-%d %H:%M:%S',
            '%b %d %H:%M:%S',
            '%d/%b/%Y:%H:%M:%S %z',
        ]

        for fmt in common_formats:
            try:
                datetime.strptime(ts.strip(), fmt)
                return True
            except (ValueError, AttributeError):
                continue

        return False

    @staticmethod
    def is_valid_log_level(level: str) -> bool:
        """Check if string is a valid log level"""
        valid_levels = [
            'EMERGENCY', 'ALERT', 'CRITICAL', 'ERROR', 'WARNING',
            'NOTICE', 'INFO', 'DEBUG', 'TRACE',
            'EMERG', 'ALERT', 'CRIT', 'ERR', 'WARN', 'NOTICE',
            'FATAL', 'SEVERE', 'FINE', 'FINER', 'FINEST'
        ]

        return level.upper() in [l.upper() for l in valid_levels]

    @staticmethod
    def is_valid_file_path(path: str) -> bool:
        """Check if a file path is valid and safe"""
        # Check for path traversal
        if '..' in path:
            return False

        # Check for null bytes
        if '\x00' in path:
            return False

        # Check length
        if len(path) > 4096:
            return False

        return True

    @staticmethod
    def sanitize_filename(filename: str) -> str:
        """Sanitize a filename to be safe"""
        # Remove path separators
        filename = filename.replace('/', '_').replace('\\', '_')

        # Remove dangerous characters
        dangerous = '<>:"|?*'
        for char in dangerous:
            filename = filename.replace(char, '_')

        # Remove leading dots and spaces
        filename = filename.lstrip('. ')

        if not filename:
            filename = 'unnamed'

        if len(filename) > 255:
            filename = filename[:255]

        return filename

    @staticmethod
    def validate_model_response(response: str,
                                required_fields: List[str] = None) -> Dict[str, Any]:
        """Validate a model response for basic quality"""
        issues = []

        if not response or not response.strip():
            issues.append('Empty response')
            return {'valid': False, 'issues': issues}

        # Check minimum length
        if len(response) < 10:
            issues.append('Response too short')

        # Check for error indicators
        error_indicators = ['Error:', 'Exception:', 'Traceback', 'Failed:']
        for indicator in error_indicators:
            if indicator in response:
                issues.append(f'Response contains error indicator: {indicator}')

        # Check required fields if specified
        if required_fields:
            for field in required_fields:
                if field.lower() not in response.lower():
                    issues.append(f'Missing required field: {field}')

        return {
            'valid': len([i for i in issues if 'error' not in i.lower()]) == 0,
            'issues': issues,
            'length': len(response)
        }