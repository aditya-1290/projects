# utils/confidence.py
"""
Confidence Scorer - Calculates confidence levels for agent outputs
"""

from typing import Dict, Any, List, Optional


class ConfidenceScorer:
    """Utility for scoring confidence in agent outputs"""

    @staticmethod
    def score_extraction_quality(extracted_data: Dict[str, Any]) -> float:
        """Score the quality of extracted data"""
        score = 0.0
        factors = 0

        # Check if data was successfully extracted
        if extracted_data.get('success'):
            score += 1.0
        factors += 1

        # Check OCR confidence if applicable
        if 'confidence' in extracted_data:
            score += extracted_data['confidence']
            factors += 1

        # Check if content is non-empty
        content = extracted_data.get('raw_content', '')
        if content and len(content) > 0:
            score += 1.0
        else:
            score += 0.0
        factors += 1

        # Check for errors
        if extracted_data.get('error'):
            score -= 0.5
            factors += 1

        return max(0.0, min(1.0, score / max(factors, 1)))

    @staticmethod
    def score_analysis_quality(analysis: Dict[str, Any]) -> float:
        """Score the quality of log analysis"""
        score = 0.0
        factors = 0

        # Has classification
        if analysis.get('classification'):
            score += 1.0
        factors += 1

        # Has patterns
        if analysis.get('patterns'):
            score += 1.0
        factors += 1

        # Has recommendations
        if analysis.get('recommendations'):
            score += 1.0
        factors += 1

        # Has anomalies
        if analysis.get('anomalies'):
            score += 0.5
        factors += 1

        return max(0.0, min(1.0, score / max(factors, 1)))

    @staticmethod
    def score_solution_quality(solution: Dict[str, Any]) -> float:
        """Score the quality of a solution"""
        score = 0.0
        factors = 0

        if solution.get('recommended_solution'):
            score += 1.0
        factors += 1

        if solution.get('user_explanation'):
            score += 0.5
        factors += 1

        if solution.get('risk_assessment'):
            score += 0.5
        factors += 1

        return max(0.0, min(1.0, score / max(factors, 1)))

    @staticmethod
    def score_model_response(response: str, expected_keywords: List[str] = None) -> float:
        """Score a model response based on completeness"""
        if not response:
            return 0.0

        score = 0.5  # Base score for having a response

        # Longer responses tend to be more thorough (to a point)
        length = len(response)
        if length > 1000:
            score += 0.2
        elif length > 500:
            score += 0.1

        # Check for reasoning indicators
        reasoning_markers = ['because', 'therefore', 'however', 'first', 'second', 'finally']
        for marker in reasoning_markers:
            if marker in response.lower():
                score += 0.05

        # Check expected keywords
        if expected_keywords:
            keyword_score = sum(1 for kw in expected_keywords if kw.lower() in response.lower())
            score += min(0.3, keyword_score * 0.1)

        return max(0.0, min(1.0, score))