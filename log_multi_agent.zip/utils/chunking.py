# utils/chunking.py
"""
Text Chunker - Splits large texts into manageable chunks
"""

from typing import List, Optional, Iterator
import re


class TextChunker:
    """Utilities for chunking large texts"""

    def __init__(self, max_chunk_size: int = 4000, overlap: int = 200):
        self.max_chunk_size = max_chunk_size
        self.overlap = overlap

    def chunk_by_lines(self, text: str, max_lines: int = 100) -> List[str]:
        """Chunk text by lines"""
        lines = text.split('\n')
        chunks = []

        for i in range(0, len(lines), max_lines - self.overlap):
            chunk = '\n'.join(lines[i:i + max_lines])
            chunks.append(chunk)

        return chunks

    def chunk_by_size(self, text: str) -> List[str]:
        """Chunk text by character size"""
        if len(text) <= self.max_chunk_size:
            return [text]

        chunks = []
        start = 0

        while start < len(text):
            end = start + self.max_chunk_size

            if end >= len(text):
                chunks.append(text[start:])
                break

            # Try to break at a natural boundary
            chunk_text = text[start:end]

            # Try newline first
            last_newline = chunk_text.rfind('\n')
            if last_newline > self.max_chunk_size // 2:
                end = start + last_newline
            else:
                # Try sentence boundary
                last_period = chunk_text.rfind('. ')
                if last_period > self.max_chunk_size // 2:
                    end = start + last_period + 1

            chunks.append(text[start:end])
            start = end - self.overlap

        return chunks

    def chunk_by_sentence(self, text: str, max_sentences: int = 50) -> List[str]:
        """Chunk text by sentences"""
        sentences = re.split(r'(?<=[.!?])\s+', text)
        chunks = []

        for i in range(0, len(sentences), max_sentences):
            chunk = ' '.join(sentences[i:i + max_sentences])
            chunks.append(chunk)

        return chunks

    def chunk_log_entries(self, entries: List[str], entries_per_chunk: int = 50) -> List[List[str]]:
        """Chunk log entries with overlap"""
        chunks = []

        for i in range(0, len(entries), entries_per_chunk - self.overlap):
            chunk = entries[i:i + entries_per_chunk]
            chunks.append(chunk)

        return chunks

    def chunk_with_context(self, text: str, search_term: str,
                           context_lines: int = 5) -> List[str]:
        """Create chunks centered around a search term"""
        lines = text.split('\n')
        matches = []

        for i, line in enumerate(lines):
            if search_term.lower() in line.lower():
                start = max(0, i - context_lines)
                end = min(len(lines), i + context_lines + 1)

                context = '\n'.join(lines[start:end])
                matches.append({
                    'line_number': i + 1,
                    'context': context,
                    'matched_line': line
                })

        return matches