# utils/model_utils.py
"""
Model Utilities - Helper functions for model interaction
"""

from typing import Dict, Any, List, Optional
import re
import json


class ModelUtils:
    """Utilities for working with LLM models"""

    @staticmethod
    def extract_json_from_response(response: str) -> Optional[Dict]:
        """Try to extract JSON from a model's text response"""
        # Try direct JSON parse first
        try:
            return json.loads(response)
        except json.JSONDecodeError:
            pass

        # Try to find JSON in markdown code blocks
        json_block_pattern = r'```(?:json)?\s*(\{.*?\}|\[.*?\])\s*```'
        match = re.search(json_block_pattern, response, re.DOTALL)

        if match:
            try:
                return json.loads(match.group(1))
            except json.JSONDecodeError:
                pass

        # Try to find bare JSON objects
        brace_pattern = r'\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}'
        match = re.search(brace_pattern, response)

        if match:
            try:
                return json.loads(match.group(0))
            except json.JSONDecodeError:
                pass

        return None

    @staticmethod
    def extract_code_blocks(response: str) -> List[Dict[str, str]]:
        """Extract code blocks from model response"""
        pattern = r'```(\w+)?\s*\n(.*?)```'
        matches = re.findall(pattern, response, re.DOTALL)

        code_blocks = []
        for language, code in matches:
            code_blocks.append({
                'language': language or 'text',
                'code': code.strip()
            })

        return code_blocks

    @staticmethod
    def extract_list_items(response: str) -> List[str]:
        """Extract list items from model response"""
        items = []

        # Match bullet points and numbered lists
        patterns = [
            r'[-*]\s+(.*?)(?=\n[-*\d]|\n\n|$)',
            r'\d+\.\s+(.*?)(?=\n[-*\d]|\n\n|$)',
        ]

        for pattern in patterns:
            matches = re.findall(pattern, response, re.DOTALL)
            items.extend([m.strip() for m in matches])

        return items if items else [response]

    @staticmethod
    def estimate_tokens(text: str) -> int:
        """Estimate token count (rough approximation)"""
        # Rough estimate: 4 characters per token for English text
        # Or ~0.75 words per token
        words = len(text.split())
        chars = len(text)

        # Average of word-based and char-based estimates
        return int((words * 1.3 + chars / 4) / 2)

    @staticmethod
    def truncate_to_token_limit(text: str, max_tokens: int) -> str:
        """Truncate text to approximate token limit"""
        estimated = ModelUtils.estimate_tokens(text)

        if estimated <= max_tokens:
            return text

        # Calculate ratio to truncate
        ratio = max_tokens / estimated * 0.9  # 10% safety margin

        # Truncate by characters
        target_chars = int(len(text) * ratio)
        truncated = text[:target_chars]

        # Try to break at a natural point
        last_period = truncated.rfind('.')
        last_newline = truncated.rfind('\n')

        if last_period > target_chars * 0.8:
            truncated = truncated[:last_period + 1]
        elif last_newline > target_chars * 0.8:
            truncated = truncated[:last_newline]

        return truncated + "\n\n[truncated...]"

    @staticmethod
    def clean_model_output(text: str) -> str:
        """Clean common artifacts from model output"""
        # Remove excessive whitespace
        text = re.sub(r'\n{4,}', '\n\n\n', text)

        # Remove trailing whitespace
        text = '\n'.join(line.rstrip() for line in text.split('\n'))

        # Remove common prefixes the model might add
        prefixes_to_remove = [
            'Sure! ', 'Certainly! ', 'Of course! ', 'Here is ', 'Here are ',
            'I can help with that. ', 'Let me help you. '
        ]

        for prefix in prefixes_to_remove:
            if text.startswith(prefix):
                text = text[len(prefix):]
                break

        return text.strip()

    @staticmethod
    def parse_agent_confidence(text: str) -> Optional[float]:
        """Extract confidence score from model output"""
        patterns = [
            r'confidence[:\s]+(\d+(?:\.\d+)?)\s*%',
            r'(\d+(?:\.\d+)?)\s*%\s*confiden',
            r'score[:\s]+(\d+(?:\.\d+)?)\s*/\s*100',
            r'(\d+(?:\.\d+)?)\s*/\s*100',
        ]

        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                score = float(match.group(1))
                if score > 1:  # Percentage format
                    score /= 100
                return min(1.0, max(0.0, score))

        return None