# safety/command_whitelist.py
"""
Command Whitelist - Controls which commands agents can execute
"""

from typing import Dict, Any, List, Optional, Set
from enum import Enum
import re
import logging

logger = logging.getLogger(__name__)


class CommandRisk(Enum):
    SAFE = "safe"  # Read-only, no side effects
    LOW = "low"  # Minor system info
    MEDIUM = "medium"  # Could affect system state
    HIGH = "high"  # Could cause damage
    CRITICAL = "critical"  # Extremely dangerous


class CommandWhitelist:
    """
    Manages which commands agents are allowed to execute.
    Categorizes commands by risk level and enforces restrictions.
    """

    def __init__(self):
        # Define commands by risk category
        self.commands: Dict[str, Dict[str, Any]] = {
            # SAFE: Read-only operations
            'cat': {
                'risk': CommandRisk.SAFE,
                'description': 'Display file contents',
                'allowed_args': [],
                'blocked_args': []
            },
            'head': {
                'risk': CommandRisk.SAFE,
                'description': 'Display first lines of file',
                'allowed_args': ['-n'],
                'blocked_args': []
            },
            'tail': {
                'risk': CommandRisk.SAFE,
                'description': 'Display last lines of file',
                'allowed_args': ['-n', '-f'],
                'blocked_args': []
            },
            'grep': {
                'risk': CommandRisk.SAFE,
                'description': 'Search text patterns',
                'allowed_args': ['-i', '-v', '-r', '-n', '-l', '-c', '-A', '-B', '-C'],
                'blocked_args': []
            },
            'wc': {
                'risk': CommandRisk.SAFE,
                'description': 'Count words/lines',
                'allowed_args': ['-l', '-w', '-c'],
                'blocked_args': []
            },
            'ls': {
                'risk': CommandRisk.SAFE,
                'description': 'List directory contents',
                'allowed_args': ['-l', '-a', '-h', '-t', '-r'],
                'blocked_args': []
            },
            'find': {
                'risk': CommandRisk.SAFE,
                'description': 'Find files',
                'allowed_args': ['-name', '-type', '-size', '-mtime'],
                'blocked_args': ['-exec', '-delete']
            },
            'file': {
                'risk': CommandRisk.SAFE,
                'description': 'Determine file type',
                'allowed_args': [],
                'blocked_args': []
            },
            'stat': {
                'risk': CommandRisk.SAFE,
                'description': 'Display file status',
                'allowed_args': [],
                'blocked_args': []
            },

            # LOW: System information
            'ps': {
                'risk': CommandRisk.LOW,
                'description': 'Process status',
                'allowed_args': ['aux', '-ef', '-eo'],
                'blocked_args': []
            },
            'df': {
                'risk': CommandRisk.LOW,
                'description': 'Disk free',
                'allowed_args': ['-h', '-i'],
                'blocked_args': []
            },
            'du': {
                'risk': CommandRisk.LOW,
                'description': 'Disk usage',
                'allowed_args': ['-h', '-s', '--max-depth'],
                'blocked_args': []
            },
            'free': {
                'risk': CommandRisk.LOW,
                'description': 'Memory usage',
                'allowed_args': ['-h', '-m', '-g'],
                'blocked_args': []
            },
            'uptime': {
                'risk': CommandRisk.LOW,
                'description': 'System uptime',
                'allowed_args': [],
                'blocked_args': []
            },
            'who': {
                'risk': CommandRisk.LOW,
                'description': 'Logged in users',
                'allowed_args': [],
                'blocked_args': []
            },
            'journalctl': {
                'risk': CommandRisk.LOW,
                'description': 'Systemd journal',
                'allowed_args': ['-n', '-u', '-p', '--since', '--until', '--no-pager'],
                'blocked_args': ['--rotate', '--vacuum']
            },
            'dmesg': {
                'risk': CommandRisk.LOW,
                'description': 'Kernel messages',
                'allowed_args': ['-T', '-l'],
                'blocked_args': []
            },

            # MEDIUM: Could affect system
            'netstat': {
                'risk': CommandRisk.MEDIUM,
                'description': 'Network statistics',
                'allowed_args': ['-tuln', '-an', '-r'],
                'blocked_args': []
            },
            'ss': {
                'risk': CommandRisk.MEDIUM,
                'description': 'Socket statistics',
                'allowed_args': ['-tuln', '-an'],
                'blocked_args': []
            },
            'ping': {
                'risk': CommandRisk.MEDIUM,
                'description': 'Network connectivity test',
                'allowed_args': ['-c', '-i', '-W'],
                'blocked_args': ['-f', '-s']
            },
            'git': {
                'risk': CommandRisk.MEDIUM,
                'description': 'Version control',
                'allowed_args': ['status', 'log', 'diff', 'show', 'branch'],
                'blocked_args': ['push', 'commit', 'merge', 'rebase']
            },
            'docker': {
                'risk': CommandRisk.MEDIUM,
                'description': 'Container operations',
                'allowed_args': ['ps', 'logs', 'inspect', 'stats'],
                'blocked_args': ['rm', 'stop', 'kill', 'exec']
            },
            'systemctl': {
                'risk': CommandRisk.MEDIUM,
                'description': 'Service management',
                'allowed_args': ['status', 'list-units', 'show'],
                'blocked_args': ['start', 'stop', 'restart', 'enable', 'disable']
            },
        }

        # Patterns that are always blocked
        self.blocked_patterns = [
            r'rm\s+(-rf?|--recursive)',  # File deletion
            r'>\s*/dev/',  # Writing to devices
            r'mkfs\.',  # Filesystem creation
            r'dd\s+if=',  # Disk duplication
            r':\(\)\s*\{',  # Fork bomb
            r'wget.*\|.*sh',  # Pipe to shell
            r'curl.*\|.*sh',  # Pipe to shell
            r'chmod\s+777',  # World-writable
            r'chmod\s+o\+w',  # Other writable
            r'sudo\s+',  # Privilege escalation
            r'su\s+',  # User switching
            r'passwd',  # Password changes
            r'shutdown',  # System shutdown
            r'reboot',  # System reboot
            r'init\s+[0-6]',  # Runlevel changes
        ]

        # Paths that are always blocked
        self.blocked_paths = [
            '/etc/shadow',
            '/etc/passwd',
            '/etc/sudoers',
            '/root/',
            '/boot/',
            '/proc/sys/',
        ]

    def is_allowed(self, command: str) -> tuple[bool, str]:
        """
        Check if a command is allowed.
        Returns (allowed, reason).
        """
        if not command or not command.strip():
            return False, "Empty command"

        # Extract base command
        parts = command.strip().split()
        base_cmd = parts[0]

        # Handle path-based commands (/usr/bin/python)
        if '/' in base_cmd:
            from pathlib import Path
            base_cmd = Path(base_cmd).name

        # Check blocked patterns first
        for pattern in self.blocked_patterns:
            if re.search(pattern, command):
                return False, f"Command matches blocked pattern: {pattern}"

        # Check if command is in whitelist
        if base_cmd not in self.commands:
            return False, f"Command not in whitelist: {base_cmd}"

        cmd_info = self.commands[base_cmd]

        # Check blocked args
        for blocked in cmd_info.get('blocked_args', []):
            if blocked in command:
                return False, f"Blocked argument: {blocked}"

        # Check for command chaining
        dangerous_ops = [';', '&&', '||', '`', '$(']
        for op in dangerous_ops:
            if op in command:
                # Check if it's inside quotes
                if not self._in_quotes(command, op):
                    return False, f"Command chaining not allowed: {op}"

        # Check for blocked paths
        for blocked_path in self.blocked_paths:
            if blocked_path in command:
                return False, f"Access to blocked path: {blocked_path}"

        return True, "Command allowed"

    def get_risk_level(self, command: str) -> CommandRisk:
        """Get the risk level of a command"""
        base_cmd = command.strip().split()[0]

        if '/' in base_cmd:
            from pathlib import Path
            base_cmd = Path(base_cmd).name

        cmd_info = self.commands.get(base_cmd)
        if cmd_info:
            return cmd_info['risk']

        return CommandRisk.CRITICAL  # Unknown commands are critical risk

    def needs_permission(self, command: str) -> bool:
        """Check if command needs explicit user permission"""
        risk = self.get_risk_level(command)
        return risk in [CommandRisk.MEDIUM, CommandRisk.HIGH, CommandRisk.CRITICAL]

    def add_command(self, name: str, risk: CommandRisk,
                    description: str = "", allowed_args: List[str] = None,
                    blocked_args: List[str] = None):
        """Add a new command to the whitelist"""
        self.commands[name] = {
            'risk': risk,
            'description': description,
            'allowed_args': allowed_args or [],
            'blocked_args': blocked_args or []
        }
        logger.info(f"Command added to whitelist: {name} (risk: {risk.value})")

    def remove_command(self, name: str):
        """Remove a command from the whitelist"""
        if name in self.commands:
            del self.commands[name]
            logger.info(f"Command removed from whitelist: {name}")

    def add_blocked_pattern(self, pattern: str):
        """Add a pattern to the blocked list"""
        self.blocked_patterns.append(pattern)
        logger.info(f"Blocked pattern added: {pattern}")

    def add_blocked_path(self, path: str):
        """Add a path to the blocked list"""
        self.blocked_paths.append(path)
        logger.info(f"Blocked path added: {path}")

    def get_commands_by_risk(self, risk: CommandRisk) -> List[str]:
        """Get all commands at a specific risk level"""
        return [
            cmd for cmd, info in self.commands.items()
            if info['risk'] == risk
        ]

    def get_all_allowed_commands(self) -> List[str]:
        """Get list of all allowed commands"""
        return list(self.commands.keys())

    def _in_quotes(self, text: str, char: str) -> bool:
        """Check if character appears inside quotes"""
        in_single = False
        in_double = False

        for c in text:
            if c == "'" and not in_double:
                in_single = not in_single
            elif c == '"' and not in_single:
                in_double = not in_double
            elif c == char and (in_single or in_double):
                return True

        return False