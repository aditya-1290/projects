# safety/audit_logger.py
"""
Audit Logger - Logs all agent actions for security and debugging
"""

from typing import Dict, Any, List, Optional
import logging
from datetime import datetime
from pathlib import Path
import json
import threading

logger = logging.getLogger(__name__)


class AuditLogger:
    """
    Logs all agent activities for audit trail.
    Tracks: commands executed, files accessed, permissions used, errors.
    """

    def __init__(self, log_dir: str = "memory_store/logs"):
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)

        self.audit_log_file = self.log_dir / f"audit_{datetime.now().strftime('%Y%m%d')}.log"
        self.security_log_file = self.log_dir / f"security_{datetime.now().strftime('%Y%m%d')}.log"

        self.entries: List[Dict[str, Any]] = []
        self.security_events: List[Dict[str, Any]] = []

        self.max_entries = 10000
        self.lock = threading.Lock()

    def log_agent_action(self, agent_id: str, action: str,
                         details: Dict[str, Any] = None,
                         status: str = "success"):
        """Log an agent action"""

        entry = {
            'timestamp': datetime.now().isoformat(),
            'agent_id': agent_id,
            'action': action,
            'details': details or {},
            'status': status
        }

        with self.lock:
            self.entries.append(entry)

            # Trim if too large
            if len(self.entries) > self.max_entries:
                self.entries = self.entries[-self.max_entries:]

        # Write to file
        self._write_entry(entry)

        logger.debug(f"Audit: {agent_id} -> {action} ({status})")

    def log_file_access(self, agent_id: str, file_path: str,
                        operation: str, result: str = "success"):
        """Log file access"""
        self.log_agent_action(
            agent_id=agent_id,
            action='file_access',
            details={
                'file': file_path,
                'operation': operation,
                'result': result
            }
        )

    def log_command_execution(self, agent_id: str, command: str,
                              return_code: int, duration: float = 0):
        """Log command execution"""
        self.log_agent_action(
            agent_id=agent_id,
            action='command_execution',
            details={
                'command': command[:200],  # Truncate long commands
                'return_code': return_code,
                'duration': duration
            },
            status='success' if return_code == 0 else 'failed'
        )

    def log_permission_check(self, agent_id: str, permission: str,
                             granted: bool, reason: str = ""):
        """Log permission check"""
        self.log_agent_action(
            agent_id=agent_id,
            action='permission_check',
            details={
                'permission': permission,
                'granted': granted,
                'reason': reason
            },
            status='granted' if granted else 'denied'
        )

    def log_security_event(self, event_type: str, severity: str,
                           agent_id: str, description: str,
                           details: Dict[str, Any] = None):
        """Log a security-related event"""

        event = {
            'timestamp': datetime.now().isoformat(),
            'event_type': event_type,
            'severity': severity,
            'agent_id': agent_id,
            'description': description,
            'details': details or {}
        }

        with self.lock:
            self.security_events.append(event)

        # Write to security log
        self._write_security_event(event)

        # Log at appropriate level
        log_level = logging.CRITICAL if severity == 'critical' else \
            logging.ERROR if severity == 'high' else \
                logging.WARNING
        logger.log(log_level, f"Security: [{severity}] {event_type} - {description}")

    def log_model_usage(self, agent_id: str, model_name: str,
                        tokens_used: int, duration: float):
        """Log model usage"""
        self.log_agent_action(
            agent_id=agent_id,
            action='model_usage',
            details={
                'model': model_name,
                'tokens': tokens_used,
                'duration': duration
            }
        )

    def log_error(self, agent_id: str, error_type: str,
                  error_message: str, traceback: str = None):
        """Log an error"""
        self.log_agent_action(
            agent_id=agent_id,
            action='error',
            details={
                'error_type': error_type,
                'message': error_message[:500],
                'traceback': traceback[:1000] if traceback else None
            },
            status='error'
        )

    def _write_entry(self, entry: Dict[str, Any]):
        """Write an audit entry to file"""
        try:
            with open(self.audit_log_file, 'a') as f:
                f.write(json.dumps(entry) + '\n')
        except Exception as e:
            logger.error(f"Failed to write audit log: {str(e)}")

    def _write_security_event(self, event: Dict[str, Any]):
        """Write a security event to file"""
        try:
            with open(self.security_log_file, 'a') as f:
                f.write(json.dumps(event) + '\n')
        except Exception as e:
            logger.error(f"Failed to write security log: {str(e)}")

    def get_recent_actions(self, agent_id: str = None,
                           limit: int = 50) -> List[Dict[str, Any]]:
        """Get recent audit entries, optionally filtered by agent"""
        with self.lock:
            if agent_id:
                filtered = [e for e in self.entries if e['agent_id'] == agent_id]
                return filtered[-limit:]
            return self.entries[-limit:]

    def get_security_events(self, severity: str = None,
                            limit: int = 50) -> List[Dict[str, Any]]:
        """Get security events, optionally filtered by severity"""
        with self.lock:
            if severity:
                filtered = [e for e in self.security_events
                            if e['severity'] == severity]
                return filtered[-limit:]
            return self.security_events[-limit:]

    def get_agent_stats(self, agent_id: str) -> Dict[str, Any]:
        """Get statistics for a specific agent"""
        with self.lock:
            agent_entries = [e for e in self.entries if e['agent_id'] == agent_id]

            if not agent_entries:
                return {'agent_id': agent_id, 'total_actions': 0}

            actions = {}
            errors = 0
            commands = 0

            for entry in agent_entries:
                action = entry['action']
                actions[action] = actions.get(action, 0) + 1

                if entry['status'] == 'error':
                    errors += 1

                if action == 'command_execution':
                    commands += 1

            return {
                'agent_id': agent_id,
                'total_actions': len(agent_entries),
                'actions_breakdown': actions,
                'errors': errors,
                'commands_executed': commands,
                'first_action': agent_entries[0]['timestamp'] if agent_entries else None,
                'last_action': agent_entries[-1]['timestamp'] if agent_entries else None,
            }

    def get_summary(self) -> Dict[str, Any]:
        """Get audit summary"""
        with self.lock:
            agents = set(e['agent_id'] for e in self.entries)

            return {
                'total_entries': len(self.entries),
                'total_security_events': len(self.security_events),
                'active_agents': list(agents),
                'agent_count': len(agents),
                'period': {
                    'start': self.entries[0]['timestamp'] if self.entries else None,
                    'end': self.entries[-1]['timestamp'] if self.entries else None,
                }
            }

    def search(self, query: str, limit: int = 50) -> List[Dict[str, Any]]:
        """Search audit entries"""
        query_lower = query.lower()

        with self.lock:
            matches = []
            for entry in reversed(self.entries):
                entry_str = json.dumps(entry).lower()
                if query_lower in entry_str:
                    matches.append(entry)
                    if len(matches) >= limit:
                        break

            return matches

    def rotate_logs(self):
        """Rotate log files (call daily)"""
        self.audit_log_file = self.log_dir / f"audit_{datetime.now().strftime('%Y%m%d')}.log"
        self.security_log_file = self.log_dir / f"security_{datetime.now().strftime('%Y%m%d')}.log"
        logger.info("Audit logs rotated")