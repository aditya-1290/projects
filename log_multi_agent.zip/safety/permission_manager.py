# safety/permission_manager.py
"""
Permission Manager - Controls what agents can access and do
"""

from typing import Dict, Any, List, Optional, Set
from enum import Enum
from pathlib import Path
import logging
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)


class PermissionLevel(Enum):
    NONE = "none"  # No access
    READ = "read"  # Read-only
    EXECUTE = "execute"  # Can run commands
    WRITE = "write"  # Can modify files
    ADMIN = "admin"  # Full access


class PermissionManager:
    """
    Manages permissions for agents.
    Controls what files, commands, and resources agents can access.
    """

    def __init__(self):
        # Agent permissions: agent_id -> permissions dict
        self.agent_permissions: Dict[str, Dict[str, Any]] = {}

        # Default permissions for new agents
        self.default_permissions = {
            'file_access': PermissionLevel.READ,
            'terminal_access': PermissionLevel.NONE,
            'network_access': PermissionLevel.NONE,
            'allowed_paths': [],
            'allowed_commands': [],
            'max_file_size': 10 * 1024 * 1024,  # 10MB
            'max_runtime': 30,  # seconds
        }

        # Active permission grants (temporary)
        self.temporary_grants: Dict[str, Dict[str, Any]] = {}

    def register_agent(self, agent_id: str, permissions: Dict[str, Any] = None):
        """Register an agent with specific permissions"""
        if permissions is None:
            permissions = self.default_permissions.copy()

        self.agent_permissions[agent_id] = permissions
        logger.info(f"Agent registered with permissions: {agent_id}")

    def unregister_agent(self, agent_id: str):
        """Remove an agent's permissions"""
        if agent_id in self.agent_permissions:
            del self.agent_permissions[agent_id]
        if agent_id in self.temporary_grants:
            del self.temporary_grants[agent_id]
        logger.info(f"Agent unregistered: {agent_id}")

    def can_read_file(self, agent_id: str, file_path: str) -> bool:
        """Check if agent can read a file"""
        perms = self.agent_permissions.get(agent_id, self.default_permissions)

        if perms['file_access'] == PermissionLevel.NONE:
            return False

        # Check if path is allowed
        allowed_paths = perms.get('allowed_paths', [])
        if allowed_paths:
            return self._is_path_within(str(file_path), allowed_paths)

        return True  # No path restrictions

    def can_write_file(self, agent_id: str, file_path: str) -> bool:
        """Check if agent can write to a file"""
        perms = self.agent_permissions.get(agent_id, self.default_permissions)

        if perms['file_access'] not in [PermissionLevel.WRITE, PermissionLevel.ADMIN]:
            return False

        allowed_paths = perms.get('allowed_paths', [])
        if allowed_paths:
            return self._is_path_within(str(file_path), allowed_paths)

        return False  # Write requires explicit path permission

    def can_execute_command(self, agent_id: str, command: str) -> bool:
        """Check if agent can execute a command"""
        perms = self.agent_permissions.get(agent_id, self.default_permissions)

        if perms['terminal_access'] == PermissionLevel.NONE:
            return False

        # Check if command is allowed
        allowed_commands = perms.get('allowed_commands', [])
        if allowed_commands:
            base_cmd = command.strip().split()[0]
            if base_cmd not in allowed_commands:
                return False

        return True

    def grant_temporary_permission(self, agent_id: str, permission: str,
                                   value: Any, duration: int = 300) -> bool:
        """
        Grant temporary elevated permission.
        Duration in seconds (default 5 minutes).
        """
        if agent_id not in self.agent_permissions:
            return False

        grant_id = f"{agent_id}_{permission}_{datetime.now().timestamp()}"

        self.temporary_grants[grant_id] = {
            'agent_id': agent_id,
            'permission': permission,
            'value': value,
            'granted_at': datetime.now(),
            'expires_at': datetime.now() + timedelta(seconds=duration)
        }

        # Apply the temporary permission
        self.agent_permissions[agent_id][permission] = value

        logger.info(f"Temporary permission granted: {agent_id} -> {permission} "
                    f"(expires in {duration}s)")

        return True

    def revoke_temporary_permissions(self, agent_id: str):
        """Revoke all temporary permissions for an agent"""
        if agent_id not in self.agent_permissions:
            return

        # Reset to original permissions
        self.agent_permissions[agent_id] = self.default_permissions.copy()

        # Remove temporary grants
        expired = [
            gid for gid, grant in self.temporary_grants.items()
            if grant['agent_id'] == agent_id
        ]
        for gid in expired:
            del self.temporary_grants[gid]

        logger.info(f"Temporary permissions revoked for: {agent_id}")

    def cleanup_expired_grants(self):
        """Remove expired temporary grants"""
        now = datetime.now()
        expired = [
            gid for gid, grant in self.temporary_grants.items()
            if grant['expires_at'] < now
        ]

        for gid in expired:
            grant = self.temporary_grants[gid]
            agent_id = grant['agent_id']

            # Reset the permission to default
            if agent_id in self.agent_permissions:
                perm = grant['permission']
                self.agent_permissions[agent_id][perm] = self.default_permissions.get(perm)

            del self.temporary_grants[gid]

        if expired:
            logger.info(f"Cleaned up {len(expired)} expired permission grants")

    def get_agent_permissions(self, agent_id: str) -> Dict[str, Any]:
        """Get current permissions for an agent"""
        return self.agent_permissions.get(agent_id, self.default_permissions).copy()

    def set_permission(self, agent_id: str, permission: str, value: Any):
        """Set a specific permission for an agent"""
        if agent_id not in self.agent_permissions:
            self.register_agent(agent_id)

        self.agent_permissions[agent_id][permission] = value
        logger.info(f"Permission updated: {agent_id}.{permission} = {value}")

    def add_allowed_path(self, agent_id: str, path: str):
        """Add a path to agent's allowed paths"""
        if agent_id not in self.agent_permissions:
            self.register_agent(agent_id)

        if 'allowed_paths' not in self.agent_permissions[agent_id]:
            self.agent_permissions[agent_id]['allowed_paths'] = []

        self.agent_permissions[agent_id]['allowed_paths'].append(path)

    def add_allowed_command(self, agent_id: str, command: str):
        """Add a command to agent's allowed commands"""
        if agent_id not in self.agent_permissions:
            self.register_agent(agent_id)

        if 'allowed_commands' not in self.agent_permissions[agent_id]:
            self.agent_permissions[agent_id]['allowed_commands'] = []

        self.agent_permissions[agent_id]['allowed_commands'].append(command)

    def _is_path_within(self, target: str, allowed: List[str]) -> bool:
        """Check if a path is within any of the allowed paths"""
        target_path = Path(target).resolve()

        for allowed_path in allowed:
            try:
                target_path.relative_to(Path(allowed_path).resolve())
                return True
            except ValueError:
                continue

        return False

    def get_all_agents(self) -> List[str]:
        """Get list of all registered agents"""
        return list(self.agent_permissions.keys())