# safety/input_sanitizer.py
"""
Input Sanitizer - Sanitizes user inputs and agent outputs
"""

from typing import Dict, Any, List, Optional
import re
import html
import logging
from pathlib import Path

logger = logging.getLogger(__name__)


class InputSanitizer:
    """
    Sanitizes inputs and outputs to prevent injection attacks
    and handle malicious content.
    """

    def __init__(self):
        # Patterns for dangerous content
        self.dangerous_patterns = [
            (r'<script[^>]*>.*?</script>', 'script_tag'),
            (r'javascript\s*:', 'javascript_protocol'),
            (r'on\w+\s*=\s*["\']', 'event_handler'),
            (r'\.\.\/|\.\.\\', 'path_traversal'),
            (r'\b(union|select|insert|update|delete|drop)\b.*\b(from|into|where)\b', 'sql_injection'),
            (r'\$\(.*\)', 'command_substitution'),
            (r'`[^`]+`', 'backtick_execution'),
            (r'\bexec\s*\(', 'exec_function'),
            (r'\beval\s*\(', 'eval_function'),
        ]

        # Maximum lengths
        self.max_input_length = 100000  # 100KB
        self.max_path_length = 4096
        self.max_command_length = 10000

    def sanitize_text_input(self, text: str) -> Dict[str, Any]:
        """Sanitize general text input"""

        if not text:
            return {'sanitized': '', 'issues': [], 'truncated': False}

        issues = []

        # Check length
        if len(text) > self.max_input_length:
            text = text[:self.max_input_length]
            issues.append('Input truncated: exceeded maximum length')

        # Check for dangerous patterns
        for pattern, issue_type in self.dangerous_patterns:
            if re.search(pattern, text, re.IGNORECASE):
                issues.append(f'Potentially dangerous content detected: {issue_type}')

        # HTML escape to prevent XSS
        sanitized = html.escape(text, quote=True)

        # Remove null bytes
        sanitized = sanitized.replace('\x00', '')

        return {
            'sanitized': sanitized,
            'issues': issues,
            'truncated': len(text) > self.max_input_length,
            'safe': len(issues) == 0
        }

    def sanitize_file_path(self, path: str) -> Dict[str, Any]:
        """Sanitize a file path to prevent path traversal"""

        if not path:
            return {'sanitized': '', 'issues': ['Empty path'], 'safe': False}

        issues = []

        # Check length
        if len(path) > self.max_path_length:
            path = path[:self.max_path_length]
            issues.append('Path truncated: too long')

        # Check for path traversal
        if '..' in path:
            issues.append('Path traversal attempt detected')

        # Resolve and normalize the path
        try:
            resolved = Path(path).resolve()

            # Prevent access to system directories
            dangerous_paths = ['/etc', '/root', '/sys', '/proc', '/dev']
            resolved_str = str(resolved)

            for dangerous in dangerous_paths:
                if resolved_str.startswith(dangerous):
                    issues.append(f'Access to system directory blocked: {dangerous}')
                    break

            sanitized = resolved_str

        except Exception:
            sanitized = path
            issues.append('Path normalization failed')

        return {
            'sanitized': sanitized,
            'issues': issues,
            'safe': len(issues) == 0
        }

    def sanitize_command(self, command: str) -> Dict[str, Any]:
        """Sanitize a shell command"""

        if not command:
            return {'sanitized': '', 'issues': ['Empty command'], 'safe': False}

        issues = []

        # Check length
        if len(command) > self.max_command_length:
            command = command[:self.max_command_length]
            issues.append('Command truncated: too long')

        # Remove dangerous characters
        dangerous_chars = ['\x00', '\r', '\b']
        for char in dangerous_chars:
            if char in command:
                command = command.replace(char, '')
                issues.append(f'Removed dangerous character: {repr(char)}')

        # Check for command injection attempts
        injection_patterns = [
            (r'[;&|]', 'Command chaining operator'),
            (r'`[^`]+`', 'Command substitution'),
            (r'\$\([^)]+\)', 'Variable substitution'),
        ]

        for pattern, desc in injection_patterns:
            if re.search(pattern, command):
                # Check if it's inside quotes
                if not self._in_quotes(command, re.search(pattern, command).group(0)):
                    issues.append(f'Potential command injection: {desc}')

        return {
            'sanitized': command.strip(),
            'issues': issues,
            'safe': len(issues) == 0
        }

    def sanitize_filename(self, filename: str) -> str:
        """Sanitize a filename to be safe for filesystem use"""

        # Remove path separators
        filename = filename.replace('/', '_').replace('\\', '_')

        # Remove or replace dangerous characters
        dangerous = '<>:"|?*'
        for char in dangerous:
            filename = filename.replace(char, '_')

        # Remove leading dots and spaces
        filename = filename.lstrip('. ')

        # Limit length
        if len(filename) > 255:
            name, ext = (filename.rsplit('.', 1) + [''])[:2]
            filename = name[:255 - len(ext) - 1] + ('.' + ext if ext else '')

        # Ensure not empty
        if not filename:
            filename = 'unnamed'

        return filename

    def sanitize_json_data(self, data: Any) -> Any:
        """Recursively sanitize JSON-like data"""
        import json

        if isinstance(data, str):
            return self.sanitize_text_input(data)['sanitized']

        elif isinstance(data, dict):
            return {
                self.sanitize_text_input(str(k))['sanitized']: self.sanitize_json_data(v)
                for k, v in data.items()
            }

        elif isinstance(data, list):
            return [self.sanitize_json_data(item) for item in data]

        elif isinstance(data, (int, float, bool)) or data is None:
            return data

        else:
            return str(data)

    def sanitize_agent_output(self, output: str) -> str:
        """Sanitize agent output before showing to user"""

        # Remove any system paths that shouldn't be exposed
        sanitized = re.sub(r'/home/\w+', '/home/[user]', output)
        sanitized = re.sub(r'/Users/\w+', '/Users/[user]', sanitized)

        # Mask potential secrets
        secret_patterns = [
            (r'(?i)(api[_-]?key|token|secret|password|auth)\s*[:=]\s*([^\s]+)',
             r'\1=[REDACTED]'),
            (r'(?i)(Bearer\s+)([a-zA-Z0-9._-]+)',
             r'\1[REDACTED]'),
        ]

        for pattern, replacement in secret_patterns:
            sanitized = re.sub(pattern, replacement, sanitized)

        return sanitized

    def _in_quotes(self, text: str, substring: str) -> bool:
        """Check if a substring appears inside quotes"""
        try:
            index = text.index(substring)
        except ValueError:
            return False

        in_single = False
        in_double = False

        for i, c in enumerate(text[:index]):
            if c == "'" and not in_double:
                in_single = not in_single
            elif c == '"' and not in_single:
                in_double = not in_double

        return in_single or in_double

    def validate_and_sanitize(self, input_type: str, value: str) -> Dict[str, Any]:
        """Validate and sanitize input based on type"""

        sanitizers = {
            'text': self.sanitize_text_input,
            'path': self.sanitize_file_path,
            'command': self.sanitize_command,
            'filename': lambda x: {'sanitized': self.sanitize_filename(x),
                                   'issues': [], 'safe': True},
        }

        sanitizer = sanitizers.get(input_type, self.sanitize_text_input)

        if input_type == 'filename':
            return sanitizer(value)

        return sanitizer(value)