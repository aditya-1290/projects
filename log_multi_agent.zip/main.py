# main.py
"""
Log Analysis Multi-Agent System
Main entry point - Terminal-based interactive interface

Model Strategy:
- Preloaded at startup: Qwen, Gemma, Embeddings
- Lazy loaded on demand: DeepSeek OCR (when image extraction needed)
- No model: Orchestrator (routing only)

Initialization Sequence:
1. Load Models FIRST
2. Verify models work
3. Start Communication Bus
4. Initialize Infrastructure (registries, safety, session)
5. Initialize Each Agent INDEPENDENTLY with its model
6. Register Agents on Communication Bus
7. Discover Agent Capabilities via A2A
"""

import sys
import os
import asyncio
from pathlib import Path
from typing import Dict, Any, Optional, List
import signal
import importlib
import uuid
import json

PROJECT_ROOT = Path(__file__).parent
sys.path.insert(0, str(PROJECT_ROOT))

from dotenv import load_dotenv

load_dotenv()

from utils.logger import setup_logger

logger = setup_logger("log_multi_agent")

try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table

    console = Console()
    USE_RICH = True
except ImportError:
    USE_RICH = False
    console = None

# ============================================
# Agent Registry
# ============================================

AGENT_REGISTRY = [
    {
        "agent_id": "orchestrator",
        "module": "agents.orchestrator.agent",
        "class": "OrchestratorAgent",
        "capabilities_file": "agents/orchestrator/capabilities.json",
        "model_key": None,
        "description": "Router only - no model needed"
    },
    {
        "agent_id": "extractor",
        "module": "agents.extractor.agent",
        "class": "ExtractorAgent",
        "capabilities_file": "agents/extractor/capabilities.json",
        "model_key": "qwen",
        "description": "Extracts logs from files, images, terminals, and text"
    },
    {
        "agent_id": "preprocessor",
        "module": "agents.preprocessor.agent",
        "class": "PreprocessorAgent",
        "capabilities_file": "agents/preprocessor/capabilities.json",
        "model_key": "qwen",
        "description": "Cleans, parses, and normalizes log data"
    },
    {
        "agent_id": "analyzer",
        "module": "agents.analyzer.agent",
        "class": "AnalyzerAgent",
        "capabilities_file": "agents/analyzer/capabilities.json",
        "model_key": "gemma",
        "description": "Analyzes logs for patterns, anomalies, and insights"
    },
    {
        "agent_id": "solver",
        "module": "agents.solver.agent",
        "class": "SolverAgent",
        "capabilities_file": "agents/solver/capabilities.json",
        "model_key": "gemma",
        "description": "Generates solutions and explanations for issues"
    },
    {
        "agent_id": "debugger",
        "module": "agents.debugger.agent",
        "class": "DebuggerAgent",
        "capabilities_file": "agents/debugger/capabilities.json",
        "model_key": "gemma",
        "description": "Debugs code, finds bugs, generates patches"
    },
    {
        "agent_id": "critic",
        "module": "agents.critic.agent",
        "class": "CriticAgent",
        "capabilities_file": "agents/critic/capabilities.json",
        "model_key": "gemma",
        "description": "Evaluates outputs for quality and safety"
    },
    {
        "agent_id": "memory",
        "module": "agents.memory.agent",
        "class": "MemoryAgent",
        "capabilities_file": "agents/memory/capabilities.json",
        "model_key": "embeddings",
        "description": "Manages context and retrieves relevant knowledge"
    },
]

AGENT_TIMEOUTS = {
    "orchestrator": 30,
    "extractor": 60,
    "preprocessor": 60,
    "analyzer": 60,
    "solver": 600,
    "debugger": 60,
    "critic": 45,
    "memory": 30,
}

# Fallback pipelines when primary agent fails
FALLBACK_PIPELINES = {
    "extractor": ["preprocessor", "analyzer", "solver", "critic"],  # Skip extractor, use raw text
    "preprocessor": ["analyzer", "solver", "critic"],  # Skip preprocessor, analyze raw
    "analyzer": ["solver", "critic"],  # Skip analyzer, solve directly
    "solver": ["debugger", "critic"],  # Try debugger instead
    "debugger": ["solver", "critic"],  # Try solver instead
    "critic": [],  # No fallback, deliver as-is
}


class LogAnalysisSystem:
    """Main system controller."""

    def __init__(self):
        self.comm_bus = None
        self.model_manager = None
        self.agent_registry = None
        self.capability_registry = None
        self.session_manager = None
        self.audit_logger = None
        self.input_sanitizer = None
        self.permission_manager = None
        self.command_whitelist = None
        self.agents: Dict[str, Any] = {}
        self.orchestrator = None
        self.session_id = None
        self.running = False
        self.initialized = False
        self.request_count = 0
        self._loaded_models = {}
        self._failed_agents = {}

    # ============================================
    # Initialization
    # ============================================

    async def initialize(self):
        self._print_header()
        try:
            await self._load_all_models()
            await self._verify_models()
            await self._start_communication_bus()
            await self._init_infrastructure()
            await self._initialize_all_agents()
            await self._register_agents_on_bus()
            await self._discover_agent_capabilities()
            self._finalize_setup()
            self.initialized = True
            self.running = True
            self._print_ready()
        except Exception as e:
            logger.error(f"Initialization failed: {e}", exc_info=True)
            self._print_error(f"Failed to initialize: {e}")
            raise

    # ============================================
    # Helper Methods
    # ============================================

    def _safe_get(self, obj, path, default=None):
        try:
            for part in path.split('.'):
                obj = getattr(obj, part)
            return obj if obj is not None else default
        except:
            return default

    def _get_agent_model_key(self, agent_id: str) -> str:
        model_map = {
            "extractor": "qwen", "preprocessor": "qwen",
            "analyzer": "gemma", "solver": "gemma",
            "debugger": "gemma", "critic": "gemma",
            "memory": "embeddings", "orchestrator": "none"
        }
        return model_map.get(agent_id, "none")

    def _get_agent_description(self, agent_id: str) -> str:
        for config in AGENT_REGISTRY:
            if config["agent_id"] == agent_id:
                return config["description"]
        return ""

    def _finalize_setup(self):
        if self.audit_logger:
            try:
                self.audit_logger.log_agent_action(
                    "system", "system_initialized",
                    details={"agents_registered": len(self.agents), "session_id": self.session_id}
                )
            except:
                pass
        logger.info(f"System initialized with {len(self.agents)} agents")

    # ============================================
    # STEP 1: Load Models
    # ============================================

    async def _load_all_models(self):
        self._print_section("Loading Models")
        from agentos.model_manager import ModelManager
        self.model_manager = ModelManager()

        models_to_load = [
            {"key": "qwen", "name": "Qwen-2.5-3B", "purpose": "Extractor & Preprocessor",
             "required_by": ["extractor", "preprocessor"]},
            {"key": "gemma", "name": "Gemma-4-E4B", "purpose": "Analyzer, Solver, Debugger, Critic",
             "required_by": ["analyzer", "solver", "debugger", "critic"]},
            {"key": "embeddings", "name": "BGE-Small-EN", "purpose": "Memory Agent", "required_by": ["memory"]}
        ]

        for mc in models_to_load:
            try:
                self._print_step(f"Loading {mc['name']} ({mc['purpose']})...")
                model = await self.model_manager.load_model(mc["key"])
                if model is not None and not isinstance(model, dict):
                    self._loaded_models[mc["key"]] = model
                    self._print_success(f"Loaded {mc['name']} -> {', '.join(mc['required_by'])}")
                else:
                    self._print_warning(f"{mc['name']} not available")
                    self._loaded_models[mc["key"]] = None
            except Exception as e:
                self._print_warning(f"Failed: {str(e)[:80]}")
                self._loaded_models[mc["key"]] = None

        loaded = sum(1 for m in self._loaded_models.values() if m is not None)
        self._print_success(f"Models loaded: {loaded}/{len(self._loaded_models)}")

    async def _verify_models(self):
        self._print_section("Verifying Models")
        for model_key, model in self._loaded_models.items():
            if model is None: continue
            self._print_step(f"Testing {model_key}...")
            try:
                if hasattr(model, 'create_chat_completion'):
                    loop = asyncio.get_event_loop()
                    response = await asyncio.wait_for(
                        loop.run_in_executor(None, lambda m=model: m.create_chat_completion(
                            messages=[{"role": "user", "content": "Say 'ready'."}], max_tokens=10, temperature=0.0
                        )), timeout=30
                    )
                    text = response.get('choices', [{}])[0].get('message', {}).get('content', '')
                    self._print_success(
                        f"  {model_key}: '{text.strip()[:50]}'") if text.strip() else self._print_warning(
                        f"  {model_key}: Empty")
            except asyncio.TimeoutError:
                self._print_error(f"  {model_key}: Timed out")
            except Exception as e:
                self._print_error(f"  {model_key}: {str(e)[:80]}")

    async def _start_communication_bus(self):
        self._print_section("Starting Communication Bus")
        from agentos.communication_bus import CommunicationBus
        self.comm_bus = CommunicationBus()
        await self.comm_bus.start()
        self._print_success("Communication bus running")

    async def _init_infrastructure(self):
        self._print_section("Initializing Infrastructure")
        from agentos.agent_registry import AgentRegistry
        from agentos.capability_registry import CapabilityRegistry
        from agentos.session_manager import SessionManager
        from safety.input_sanitizer import InputSanitizer
        from safety.audit_logger import AuditLogger
        from safety.permission_manager import PermissionManager
        from safety.command_whitelist import CommandWhitelist

        self.agent_registry = AgentRegistry()
        self.capability_registry = CapabilityRegistry()
        self._print_success("Registries ready")

        self.session_manager = SessionManager()
        session = self.session_manager.create_session()
        self.session_id = session.session_id
        self._print_success(f"Session: {self.session_id[:8]}...")

        self.input_sanitizer = InputSanitizer()
        self.audit_logger = AuditLogger()
        self.permission_manager = PermissionManager()
        self.command_whitelist = CommandWhitelist()
        self._print_success("Safety components ready")

    async def _initialize_all_agents(self):
        self._print_section("Initializing Agents")
        ok, fail = 0, 0
        for config in AGENT_REGISTRY:
            try:
                if await self._initialize_single_agent(config):
                    ok += 1
                else:
                    fail += 1
            except Exception as e:
                logger.error(f"Failed {config['agent_id']}: {e}")
                fail += 1
        self._print_success(f"Agents: {ok}/{ok + fail}")
        if fail: self._print_warning(f"Failed: {fail}")

    async def _initialize_single_agent(self, config: Dict[str, str]) -> bool:
        agent_id = config["agent_id"]
        try:
            self._print_step(f"Initializing {agent_id}...")
            capabilities_path = PROJECT_ROOT / config["capabilities_file"]
            if not capabilities_path.exists():
                self._print_warning(f"  {agent_id}: Capabilities file missing")
                return False

            module = importlib.import_module(config["module"])
            AgentClass = getattr(module, config["class"])
            agent = AgentClass(agent_id=agent_id, capability_path=str(capabilities_path))

            model_key = config.get("model_key")
            if model_key and model_key in self._loaded_models:
                model = self._loaded_models[model_key]
                if model is not None:
                    agent.model = model
                    self._print_success(f"  {agent_id}: Model '{model_key}' assigned")
                else:
                    agent.model = None
                    self._print_warning(f"  {agent_id}: Model '{model_key}' unavailable")
            elif model_key is None:
                agent.model = None
                self._print_success(f"  {agent_id}: No model required")

            agent.model_manager = self.model_manager
            agent.comm_bus = self.comm_bus
            self.agents[agent_id] = agent
            if agent_id == "orchestrator":
                self.orchestrator = agent
            return True
        except Exception as e:
            logger.error(f"Failed {agent_id}: {e}", exc_info=True)
            self._print_error(f"  {agent_id}: Failed - {str(e)[:80]}")
            return False

    async def _register_agents_on_bus(self):
        self._print_section("Registering Agents on Bus")
        ok = 0
        for agent_id, agent in self.agents.items():
            try:
                await self._register_agent_on_bus(agent_id, agent)
                ok += 1
            except Exception as e:
                logger.error(f"Failed to register {agent_id}: {e}")
        self._print_success(f"Registered: {ok}/{len(self.agents)}")

    async def _register_agent_on_bus(self, agent_id: str, agent: Any):
        agent_info = {
            "name": self._safe_get(agent, 'capability.agent_name', agent_id),
            "domain": self._safe_get(agent, 'capability.domain', 'general'),
            "capabilities": self._safe_get(agent, 'capability.capabilities', []),
            "version": "1.0.0",
            "model": self._get_agent_model_key(agent_id),
            "description": self._get_agent_description(agent_id)
        }
        system_self = self

        async def message_bridge(comm_msg, ag=agent, ai=agent_info, aid=agent_id):
            from agents.base_agent import A2AMessage, MessageType as AMT
            from agentos.communication_bus import Message, MessageType as BusMT
            import traceback

            try:
                task_content = comm_msg.content if isinstance(comm_msg.content, dict) else {"input": comm_msg.content}
                if aid == "extractor" and isinstance(task_content, dict):
                    input_data = task_content.get("input", {})
                    if isinstance(input_data, dict) and "text" in input_data and "raw_content" not in input_data:
                        input_data["raw_content"] = input_data["text"]

                agent_msg = A2AMessage(
                    message_id=comm_msg.id, message_type=AMT.REQUEST,
                    sender_id=comm_msg.sender, sender_type="system",
                    target_id=comm_msg.receiver, correlation_id=comm_msg.id,
                    task=task_content, context=comm_msg.metadata or {}
                )

                agent_timeout = AGENT_TIMEOUTS.get(aid, 120)
                try:
                    response = await asyncio.wait_for(ag.receive_message(agent_msg), timeout=agent_timeout)
                except asyncio.TimeoutError:
                    logger.warning(f"Agent {aid} timed out ({agent_timeout}s)")
                    response = None

                if response:
                    result = response.response if response.response else response.to_dict()
                    if response.error: result = {"success": False, "error": response.error}
                    try:
                        confidence = ag.calculate_confidence(result, agent_msg.task or {})
                    except:
                        confidence = 0.5
                    if isinstance(result, dict) and "success" not in result:
                        result["success"] = not result.get("error")
                    system_self._print_agent_result(ai.get("name", aid), confidence)

                    reply = Message(id=str(uuid.uuid4()), sender=aid, receiver=comm_msg.sender,
                                    message_type=BusMT.TASK_RESPONSE, content=result,
                                    correlation_id=comm_msg.id, metadata={"confidence": confidence})
                    await system_self.comm_bus.send_message(reply)
                    return reply
                else:
                    error_result = {"success": False, "error": f"Agent {aid} timed out"}
                    system_self._print_agent_result(ai.get("name", aid), 0.0, error=error_result["error"])
                    reply = Message(id=str(uuid.uuid4()), sender=aid, receiver=comm_msg.sender,
                                    message_type=BusMT.TASK_RESPONSE, content=error_result,
                                    correlation_id=comm_msg.id, metadata={"confidence": 0.0})
                    await system_self.comm_bus.send_message(reply)
                    return reply
            except Exception as e:
                error_result = {"success": False, "error": str(e)}
                system_self._print_agent_result(ai.get("name", aid), 0.0, error=str(e))
                try:
                    reply = Message(id=str(uuid.uuid4()), sender=aid, receiver=comm_msg.sender,
                                    message_type=BusMT.TASK_RESPONSE, content=error_result,
                                    correlation_id=comm_msg.id, metadata={"confidence": 0.0})
                    await system_self.comm_bus.send_message(reply)
                    return reply
                except:
                    return None

        self.comm_bus.register_agent(agent_id=agent_id, agent_info=agent_info, message_handler=message_bridge)

        from agentos.agent_registry import AgentInfo
        self.agent_registry.register_agent(agent_id=agent_id, info=AgentInfo(
            name=agent_info["name"], version=agent_info["version"],
            capabilities=agent_info["capabilities"], status="active",
            model=agent_info["model"], description=agent_info["description"]
        ), instance=agent)

        for cap_name in agent_info["capabilities"]:
            if isinstance(cap_name, str):
                try:
                    self.capability_registry.assign_capability_to_agent(agent_id, cap_name)
                except ValueError:
                    pass
        logger.info(f"Agent {agent_id} registered on bus")

    async def _discover_agent_capabilities(self):
        self._print_section("Discovering Agent Capabilities")
        self._print_success("Capability discovery complete")

    # ============================================
    # Pipeline Execution with RETRY & FALLBACK
    # ============================================

    async def _analyze_input(self, user_input: str) -> Dict[str, Any]:
        return {"action": "execute_pipeline", "query": "Process this input",
                "input": {"text": user_input, "source_type": "unknown"}}

    # main.py - Replace _execute_pipeline and related methods with these:

    # main.py - Replace _execute_pipeline to add confidence-based re-processing:

    async def _execute_pipeline(self, task: Dict[str, Any]) -> str:
        """Execute pipeline with confidence-based multi-step reasoning."""
        if not self.orchestrator:
            return "System not ready."

        # Get pipeline from orchestrator
        self._print_pipeline_progress("orchestrator", "start", "Determining workflow...")
        from agents.base_agent import A2AMessage, MessageType as AMT
        route_msg = A2AMessage(
            message_type=AMT.REQUEST, sender_id="system", sender_type="system",
            target_id="orchestrator", task={"action": "route_request", "input": task}
        )
        route_response = await self.orchestrator.receive_message(route_msg)

        pipeline = ["extractor", "preprocessor", "analyzer", "solver", "critic"]
        if route_response and route_response.response:
            pipeline = route_response.response.get("pipeline", pipeline)
            self._print_pipeline_progress("orchestrator", "ok", f"Pipeline: {' -> '.join(pipeline)}")
        else:
            self._print_pipeline_progress("orchestrator", "fail", "Using default pipeline")

        if USE_RICH: console.print()

        input_data = task.get("input", {})
        context = input_data.copy() if isinstance(input_data, dict) else {"text": str(input_data)}
        if not context.get("text") and not context.get("raw_content"):
            if isinstance(input_data, dict):
                inner = input_data.get("input", {})
                if isinstance(inner, dict) and inner.get("text"):
                    context["text"] = inner["text"]

        logger.info(f"Pipeline start - text length: {len(str(context.get('text', '')))}")

        results = {}
        failed_agents = []
        max_retries = 2

        # ⭐ Confidence thresholds for multi-step reasoning
        CONFIDENCE_HIGH = 0.80  # Good enough, move on
        CONFIDENCE_MEDIUM = 0.60  # Acceptable but could improve
        CONFIDENCE_LOW = 0.40  # Needs retry
        max_reasoning_steps = 2  # Max additional reasoning attempts

        for agent_id in pipeline:
            if agent_id not in self.agents:
                self._print_pipeline_progress(agent_id, "skip", "Agent not registered")
                continue

            agent_success = False
            last_error = None
            best_result = None
            best_confidence = 0.0
            reasoning_attempts = 0

            # ⭐ Try agent with retries AND multi-step reasoning
            for attempt in range(max_retries + 1):
                if attempt > 0:
                    self._print_pipeline_progress(agent_id, "wait", f"Retry {attempt}/{max_retries}...")

                self._print_pipeline_progress(agent_id, "start",
                                              f"Processing..." if attempt == 0 else f"Retrying...")

                # ⭐ Add reasoning context on retries
                agent_task = {
                    "action": "process",
                    "input": context,
                    "context": {
                        "pipeline_step": agent_id,
                        "previous_results": list(results.keys()),
                        "attempt": attempt + 1,
                        "reasoning_step": reasoning_attempts,
                        "previous_error": last_error,
                        "previous_confidence": best_confidence
                    }
                }

                from agentos.communication_bus import Message, MessageType
                msg = Message(
                    sender="system", receiver=agent_id,
                    message_type=MessageType.TASK_REQUEST, content=agent_task
                )

                try:
                    agent_timeout = AGENT_TIMEOUTS.get(agent_id, 120)
                    response = await asyncio.wait_for(
                        self.comm_bus.request_response(msg, timeout=agent_timeout),
                        timeout=agent_timeout + 10
                    )

                    if response and response.content:
                        result = response.content

                        if isinstance(result, dict) and result.get("success", True):
                            confidence = result.get("confidence", 0.85)

                            # ⭐ Display agent output
                            self._display_agent_output(agent_id, result)

                            # ⭐ Check confidence for multi-step reasoning
                            if confidence < CONFIDENCE_LOW and reasoning_attempts < max_reasoning_steps:
                                # Low confidence - try again with better context
                                reasoning_attempts += 1
                                self._print_pipeline_progress(agent_id, "wait",
                                                              f"Low confidence ({confidence:.0%}) - re-processing (step {reasoning_attempts})...")
                                last_error = f"Low confidence: {confidence:.0%}"
                                context["_reasoning_required"] = True
                                context["_previous_attempt"] = result
                                continue  # Try again without consuming retry

                            elif confidence < CONFIDENCE_MEDIUM and reasoning_attempts < max_reasoning_steps:
                                # Medium confidence - try once more
                                reasoning_attempts += 1
                                self._print_pipeline_progress(agent_id, "wait",
                                                              f"Medium confidence ({confidence:.0%}) - refining (step {reasoning_attempts})...")
                                context["_refine_required"] = True
                                context["_previous_attempt"] = result
                                continue

                            # Good enough or max reasoning reached
                            results[agent_id] = result
                            context.update(result)
                            agent_success = True
                            best_result = result
                            best_confidence = confidence

                            # Show confidence level
                            if confidence >= CONFIDENCE_HIGH:
                                self._print_pipeline_progress(agent_id, "ok",
                                                              f"Done (confidence: {confidence:.0%} - high)")
                            elif confidence >= CONFIDENCE_MEDIUM:
                                self._print_pipeline_progress(agent_id, "ok",
                                                              f"Done (confidence: {confidence:.0%} - medium)")
                            else:
                                self._print_pipeline_progress(agent_id, "ok",
                                                              f"Done (confidence: {confidence:.0%} - accepted after {reasoning_attempts} refinements)")

                            break  # Success
                        else:
                            error_msg = result.get("error", "Unknown error") if isinstance(result,
                                                                                           dict) else "Invalid response"
                            last_error = error_msg
                            self._print_pipeline_progress(agent_id, "fail",
                                                          f"Attempt {attempt + 1}: {str(error_msg)[:100]}")
                    else:
                        last_error = "No response received"
                        self._print_pipeline_progress(agent_id, "fail", f"Attempt {attempt + 1}: No response")

                except asyncio.TimeoutError:
                    last_error = f"Timed out after {AGENT_TIMEOUTS.get(agent_id, 120)}s"
                    self._print_pipeline_progress(agent_id, "fail", f"Attempt {attempt + 1}: Timeout")
                except Exception as e:
                    last_error = str(e)
                    self._print_pipeline_progress(agent_id, "fail", f"Attempt {attempt + 1}: {str(e)[:100]}")

            if not agent_success:
                failed_agents.append(agent_id)
                results[agent_id] = {"success": False, "error": last_error or "Failed after retries"}
                self._print_pipeline_progress(agent_id, "skip",
                                              f"Skipped after {max_retries} retries + {reasoning_attempts} reasoning steps")

        if USE_RICH: console.print()
        final_output = self._build_final_output(results, pipeline, failed_agents, context)
        return final_output

    def _display_agent_output(self, agent_id: str, result: Dict[str, Any]):
        """Display agent output on CLI with formatting."""

        if agent_id == "extractor":
            lines = result.get("line_count", 0)
            fmt = result.get("format", result.get("detected_format", "unknown"))
            source = result.get("source_type", "unknown")
            parsed = result.get("parsed", False)
            entry_count = result.get("entry_count", 0)

            info = f"Extracted {lines} lines from {source}"
            if fmt: info += f" | Format: {fmt}"
            if parsed: info += f" | Parsed: {entry_count} entries"
            self._print_pipeline_progress(agent_id, "ok", info)

            # Show sample of extracted content
            raw = result.get("raw_content", "")
            if raw:
                sample_lines = str(raw).splitlines()[:3]
                if sample_lines:
                    if USE_RICH:
                        console.print(f"     [dim]Sample:[/]")
                        for line in sample_lines:
                            console.print(f"     [dim]  {line[:120]}[/]")
                    else:
                        print(f"     Sample:")
                        for line in sample_lines:
                            print(f"       {line[:120]}")

        elif agent_id == "preprocessor":
            entries = result.get("total_entries_processed", 0)
            token_est = result.get("token_estimate", 0)
            was_chunked = result.get("was_chunked", False)
            log_type = result.get("log_type", "")
            cleaning_ops = result.get("cleaning_operations", [])

            info = f"Processed {entries} entries ({token_est} tokens)"
            if was_chunked:
                info += f" | Chunked: {result.get('chunk_count', 1)} chunks"
            else:
                info += " | No chunking (<4000 tokens)"
            if log_type: info += f" | Type: {log_type}"
            self._print_pipeline_progress(agent_id, "ok", info)

            # Show cleaning operations
            if cleaning_ops:
                if USE_RICH:
                    console.print(f"     [dim]Cleaning: {', '.join(cleaning_ops[:3])}[/]")
                else:
                    print(f"     Cleaning: {', '.join(cleaning_ops[:3])}")

        elif agent_id == "analyzer":
            classification = result.get("classification", result.get("log_type", ""))
            patterns = result.get("patterns", result.get("patterns_found", []))
            anomalies = result.get("anomalies", result.get("anomalies_detected", []))
            severity = result.get("severity", "")

            info = "Analysis complete"
            if classification: info += f" | {classification}"
            if severity: info += f" | Severity: {severity}"
            self._print_pipeline_progress(agent_id, "ok", info)

            # Show patterns
            if patterns and isinstance(patterns, list) and len(patterns) > 0:
                if USE_RICH:
                    console.print(f"     [dim]Patterns: {len(patterns)} found[/]")
                else:
                    print(f"     Patterns: {len(patterns)} found")

            # Show anomalies
            if anomalies and isinstance(anomalies, list) and len(anomalies) > 0:
                if USE_RICH:
                    console.print(f"     [yellow]Anomalies: {len(anomalies)} detected[/]")
                else:
                    print(f"     Anomalies: {len(anomalies)} detected")

        elif agent_id == "solver":
            has_errors = result.get("has_errors", False)
            error_count = result.get("error_count", 0)
            solution = result.get("recommended_solution", result.get("solution", ""))
            explanation = result.get("user_explanation", "")

            if has_errors:
                info = f"Found {error_count} error(s) | Solution generated"
            else:
                info = "No critical errors | Solution generated"
            self._print_pipeline_progress(agent_id, "ok", info)

            # Show solution preview
            if solution:
                if USE_RICH:
                    console.print(f"     [bold green]Solution:[/]")
                    console.print(f"     [green]{str(solution)[:300]}[/]")
                else:
                    print(f"     Solution:")
                    print(f"       {str(solution)[:300]}")

            # Show explanation
            if explanation:
                if USE_RICH:
                    console.print(f"     [dim]Explanation: {str(explanation)[:200]}[/]")
                else:
                    print(f"     Explanation: {str(explanation)[:200]}")

        elif agent_id == "debugger":
            fix = result.get("fix", result.get("patch", ""))
            root_cause = result.get("root_cause", "")

            self._print_pipeline_progress(agent_id, "ok", "Debug analysis complete")

            if root_cause:
                if USE_RICH:
                    console.print(f"     [bold red]Root Cause: {str(root_cause)[:200]}[/]")
                else:
                    print(f"     Root Cause: {str(root_cause)[:200]}")

            if fix:
                if USE_RICH:
                    console.print(f"     [bold green]Fix: {str(fix)[:200]}[/]")
                else:
                    print(f"     Fix: {str(fix)[:200]}")

        elif agent_id == "critic":
            score = result.get("quality_score", "N/A")
            grade = result.get("grade", "N/A")
            verdict = result.get("verdict", "N/A")
            safety = result.get("safety_level", "N/A")
            strengths = result.get("strengths", [])
            weaknesses = result.get("weaknesses", [])

            info = f"Quality: {score}/100 ({grade}) | Verdict: {verdict} | Safety: {safety}"
            self._print_pipeline_progress(agent_id, "ok", info)

            if strengths:
                if USE_RICH:
                    console.print(f"     [green]Strengths: {', '.join(strengths[:3])}[/]")
                else:
                    print(f"     Strengths: {', '.join(strengths[:3])}")

            if weaknesses:
                if USE_RICH:
                    console.print(f"     [yellow]Weaknesses: {', '.join(weaknesses[:3])}[/]")
                else:
                    print(f"     Weaknesses: {', '.join(weaknesses[:3])}")

    def _get_alternative_agent(self, agent_id: str) -> Optional[str]:
        """Get alternative agent if primary fails."""
        alternatives = {
            "extractor": "preprocessor",  # Preprocessor can sometimes handle raw text
            "preprocessor": "analyzer",  # Analyzer can handle unpreprocessed data
            "analyzer": "solver",  # Solver can work with raw analysis
            "solver": "debugger",  # Debugger for complex issues
            "debugger": "solver",  # Solver for simpler approach
            "critic": None,  # No alternative for critic
        }
        return alternatives.get(agent_id)

    # main.py - Replace _build_final_output with this fixed version:

    def _build_final_output(self, results: Dict[str, Any], pipeline: List[str],
                            failed_agents: List[str], context: Dict[str, Any]) -> str:
        """
        Build comprehensive final output with:
        - Pipeline summary
        - Error resolution suggestions
        - Quality assessment
        - Actionable next steps
        """
        lines = []

        # Header
        lines.append("")
        lines.append("=" * 70)
        lines.append("  LOG ANALYSIS RESULTS")
        lines.append("=" * 70)
        lines.append("")

        # Pipeline summary
        lines.append("PIPELINE EXECUTION:")
        lines.append("-" * 40)
        for agent_id in pipeline:
            if agent_id in results:
                result = results[agent_id]
                status = "[OK]" if result.get("success", True) else "[FAIL]"
                lines.append(f"  {status} {agent_id.title()}")
            elif f"{agent_id}_fallback" in results:
                lines.append(f"  [WARN] {agent_id.title()} (fallback used)")
            elif agent_id in failed_agents:
                lines.append(f"  [FAIL] {agent_id.title()} (failed)")
        lines.append("")

        # Failed agents
        if failed_agents:
            lines.append(f"WARNING: {len(failed_agents)} agent(s) did not complete:")
            for agent_id in failed_agents:
                error = results.get(agent_id, {}).get("error", "Unknown error")
                lines.append(f"  - {agent_id}: {str(error)[:150]}")
            lines.append("")

        # Error resolution suggestions
        solver_result = results.get("solver", {})
        preprocessor_result = results.get("preprocessor", {})
        critic_result = results.get("critic", {})
        extractor_result = results.get("extractor", {})

        lines.append("ERROR RESOLUTION SUGGESTIONS:")
        lines.append("-" * 40)

        if solver_result.get("has_errors", False):
            error_count = solver_result.get("error_count", 0)
            lines.append(f"  Errors Detected: {error_count}")

            # Show errors
            errors = solver_result.get("errors", [])
            if errors:
                for i, error in enumerate(errors[:5], 1):
                    error_type = error.get("type", "ERROR")
                    severity = error.get("severity", "medium")
                    message = error.get("message", "")[:150]
                    lines.append(f"  {i}. [{severity.upper()}] {error_type}: {message}")

            lines.append("")

            # Show solution
            solution = solver_result.get("recommended_solution", solver_result.get("solution", ""))
            if solution:
                lines.append("  RECOMMENDED SOLUTION:")
                for line in str(solution).split('\n')[:8]:
                    lines.append(f"     {line}")
                lines.append("")

            # ⭐ FIXED: Handle sub_tasks that are strings
            sub_tasks = solver_result.get("sub_tasks", {})
            if sub_tasks:
                lines.append("  ANALYSIS COMPLETED:")
                for task_name, task_info in sub_tasks.items():
                    if isinstance(task_info, dict):
                        status = task_info.get("status", "done")
                    elif isinstance(task_info, str):
                        status = task_info
                    else:
                        status = str(task_info)
                    lines.append(f"     [OK] {task_name.title()}: {status}")
                lines.append("")
        else:
            lines.append("  No critical errors detected in the logs.")

            # Show problem understanding if available
            problem = solver_result.get("problem_understanding", "")
            if problem:
                lines.append(f"  Summary: {str(problem)[:300]}")
            lines.append("")

        # Quality assessment
        if critic_result:
            lines.append("QUALITY ASSESSMENT:")
            lines.append("-" * 40)
            score = critic_result.get("quality_score", "N/A")
            grade = critic_result.get("grade", "N/A")
            verdict = critic_result.get("verdict", "N/A")
            safety = critic_result.get("safety_level", "safe")
            safe_to_exec = critic_result.get("safe_to_execute", True)

            lines.append(f"  Quality Score: {score}/100 ({grade})")
            lines.append(f"  Verdict: {verdict}")
            lines.append(f"  Safety: {safety}")
            if not safe_to_exec:
                lines.append(f"  WARNING: Some recommendations may not be safe to execute directly")

            improvements = critic_result.get("improvements", [])
            if improvements:
                lines.append(f"  Suggested Improvements:")
                for imp in improvements[:3]:
                    lines.append(f"    - {str(imp)[:150]}")
            lines.append("")

        # Log metadata
        lines.append("-" * 70)
        log_type = preprocessor_result.get("log_type", solver_result.get("log_type", "unknown"))
        entries = preprocessor_result.get("total_entries_processed", extractor_result.get("entry_count", 0))
        fmt = extractor_result.get("format", preprocessor_result.get("detected_format", "unknown"))
        lines.append(f"  Log Type: {log_type} | Entries: {entries} | Format: {fmt}")

        # Safety note
        if critic_result and not critic_result.get("safe_to_execute", True):
            lines.append("  Review safety warnings before executing any recommended actions")

        lines.append("=" * 70)

        return "\n".join(lines)

    def _print_agent_success(self, agent_id: str, result: Dict):
        """Print agent success with relevant details."""
        if agent_id == "extractor":
            lines = result.get("line_count", 0)
            fmt = result.get("format", "")
            info = f"Extracted {lines} lines"
            if fmt: info += f" [{fmt}]"
            self._print_pipeline_progress(agent_id, "ok", info)
        elif agent_id == "preprocessor":
            entries = result.get("total_entries_processed", 0)
            token_est = result.get("token_estimate", 0)
            was_chunked = result.get("was_chunked", False)
            log_type = result.get("log_type", "")
            info = f"Processed {entries} entries ({token_est} tokens)"
            if was_chunked:
                info += " | Chunked"
            else:
                info += " | No chunking (<4000)"
            if log_type: info += f" | {log_type}"
            self._print_pipeline_progress(agent_id, "ok", info)
        elif agent_id == "analyzer":
            self._print_pipeline_progress(agent_id, "ok", "Analysis complete")
        elif agent_id == "solver":
            has_errors = result.get("has_errors", False)
            info = "Solution generated"
            if has_errors: info += " | Errors found"
            self._print_pipeline_progress(agent_id, "ok", info)
        elif agent_id == "debugger":
            self._print_pipeline_progress(agent_id, "ok", "Debug complete")
        elif agent_id == "critic":
            score = result.get("quality_score", "")
            verdict = result.get("verdict", "")
            info = "Evaluation complete"
            if score: info += f" | Score: {score}"
            if verdict: info += f" | {verdict}"
            self._print_pipeline_progress(agent_id, "ok", info)
        else:
            self._print_pipeline_progress(agent_id, "ok", "Done")

    def _print_failed_agents_summary(self):
        """Print summary of failed agents and how they were handled."""
        if USE_RICH:
            console.print("\n[bold yellow]! Note: Some agents encountered issues:[/]")
        else:
            print("\n! Note: Some agents encountered issues:")
        for agent_id, error in self._failed_agents.items():
            fallback = FALLBACK_PIPELINES.get(agent_id, [])
            if fallback:
                msg = f"  - {agent_id}: skipped (used {', '.join(fallback)} instead)"
            else:
                msg = f"  - {agent_id}: {str(error)[:100]}"
            if USE_RICH:
                console.print(f"  [dim]{msg}[/]")
            else:
                print(msg)
        print()

    # ============================================
    # Final Output Formatting with Suggestions
    # ============================================

    def _format_final_output_with_suggestions(self, synthesis: Dict, results: Dict) -> str:
        """Format final output with actionable error resolution suggestions."""
        lines = []

        # Header
        lines.append("=" * 65)
        lines.append("  LOG ANALYSIS RESULTS")
        lines.append("=" * 65)
        lines.append("")

        # ⭐ 1. WHAT WAS FOUND
        solver_result = results.get("solver", {})
        preprocessor_result = results.get("preprocessor", {})
        extractor_result = results.get("extractor", {})
        analyzer_result = results.get("analyzer", {})
        critic_result = results.get("critic", {})

        log_type = preprocessor_result.get("log_type", "unknown")
        entries = preprocessor_result.get("total_entries_processed", 0)
        fmt = extractor_result.get("format", "unknown")

        lines.append(f"Source: {fmt} | Type: {log_type} | Entries: {entries}")
        lines.append("")

        # ⭐ 2. ERRORS FOUND
        errors = solver_result.get("errors", [])
        has_errors = solver_result.get("has_errors", False)

        if has_errors and errors:
            lines.append("ERRORS DETECTED:")
            lines.append("-" * 40)
            for i, error in enumerate(errors[:10], 1):
                error_type = error.get('type', 'ERROR')
                severity = error.get('severity', 'medium')
                message = error.get('message', '')[:120]
                icon = "🔴" if severity in ["high", "critical"] else "🟡"
                lines.append(f"  {icon} [{severity.upper()}] {error_type}: {message}")
            lines.append("")
        else:
            lines.append("No critical errors detected in the logs.")
            lines.append("")

        # ⭐ 3. ROOT CAUSE
        problem_understanding = solver_result.get("problem_understanding", "")
        if problem_understanding:
            lines.append("ROOT CAUSE ANALYSIS:")
            lines.append("-" * 40)
            lines.append(f"  {problem_understanding[:500]}")
            lines.append("")

        # ⭐ 4. SOLUTION STEPS (most important!)
        solution = solver_result.get("recommended_solution", solver_result.get("solution", ""))
        if solution:
            lines.append("HOW TO FIX THIS ERROR:")
            lines.append("-" * 40)
            # Extract steps
            steps = self._extract_steps_from_text(solution)
            if steps:
                for step in steps[:10]:
                    lines.append(f"  {step}")
            else:
                lines.append(f"  {solution[:500]}")
            lines.append("")

        # ⭐ 5. SIMPLE EXPLANATION
        explanation = solver_result.get("user_explanation", "")
        if explanation:
            lines.append("IN PLAIN ENGLISH:")
            lines.append("-" * 40)
            lines.append(f"  {explanation[:300]}")
            lines.append("")

        # ⭐ 6. RISK ASSESSMENT
        risk = solver_result.get("risk_assessment", "")
        if risk:
            lines.append("RISKS TO BE AWARE OF:")
            lines.append("-" * 40)
            lines.append(f"  {risk[:300]}")
            lines.append("")

        # ⭐ 7. QUALITY & SAFETY
        if critic_result:
            score = critic_result.get("quality_score", "N/A")
            safety = critic_result.get("safety_level", "N/A")
            safe = critic_result.get("safe_to_execute", True)
            verdict = critic_result.get("verdict", "N/A")

            lines.append(f"Quality Score: {score}/100 | Safety: {safety} | Verdict: {verdict}")
            if not safe:
                lines.append("WARNING: Some recommendations may not be safe to execute directly.")

            warnings = critic_result.get("safety_warnings", [])
            if warnings:
                for w in warnings[:3]:
                    lines.append(f"  ! {w[:150]}")
            lines.append("")

        # ⭐ 8. FAILED AGENTS NOTE
        if self._failed_agents:
            lines.append("NOTE:")
            for agent_id, error in self._failed_agents.items():
                fallback = FALLBACK_PIPELINES.get(agent_id, [])
                if fallback:
                    lines.append(f"  - {agent_id} was unavailable, used alternative agents instead")
                else:
                    lines.append(f"  - {agent_id} encountered issues: {str(error)[:100]}")
            lines.append("")

        # Footer
        lines.append("=" * 65)
        lines.append(f"Analysis completed at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append("=" * 65)

        return "\n".join(lines)

    def _extract_steps_from_text(self, text: str) -> List[str]:
        """Extract numbered steps from solution text."""
        import re
        steps = []
        lines = text.split('\n')
        for line in lines:
            line = line.strip()
            if re.match(r'^(?:Step\s*\d+[:\s]|\d+[\.\)]\s|[-*]\s)', line, re.IGNORECASE):
                steps.append(line)
        if not steps:
            steps = [l.strip() for l in lines if l.strip() and len(l.strip()) > 10][:10]
        return steps[:10]

    def _format_pipeline_results(self, results: Dict[str, Any], pipeline: List[str]) -> str:
        return self._build_final_output(results, pipeline, [], {})

    async def _process_task(self, task: Dict[str, Any]) -> str:
        try:
            result = await self._execute_pipeline(task)
            self.request_count += 1
            return result
        except Exception as e:
            logger.error(f"Pipeline error: {e}", exc_info=True)
            return f"Error: {str(e)}"

    # ============================================
    # Interactive Mode
    # ============================================

    async def run_interactive(self):
        """Run the system in interactive mode."""
        print("\nPaste logs, code, file path, or terminal command.")
        print("For multi-line logs, paste directly and press Enter twice when done.")
        print("Type 'help' for commands, 'exit' to quit.\n")

        while self.running:
            try:
                if USE_RICH:
                    console.print("[bold green]You[/]: (paste content, press Enter twice to finish)")
                else:
                    print("You: (paste content, press Enter twice to finish)")

                lines = []
                empty_count = 0
                while True:
                    try:
                        line = input()
                    except EOFError:
                        break
                    if line.strip() == "":
                        empty_count += 1
                        if empty_count >= 2: break
                    else:
                        empty_count = 0
                        lines.append(line)

                if not lines: continue
                user_input = "\n".join(lines).strip()
                if not user_input: continue

                cmd = user_input.lower().strip()
                if cmd in ['exit', 'quit', 'q']:
                    self._print_goodbye()
                    break
                elif cmd in ['help', '?']:
                    self._show_help()
                    continue
                elif cmd == 'status':
                    self._show_status()
                    continue
                elif cmd == 'agents':
                    self._show_agents()
                    continue
                elif cmd == 'models':
                    self._show_models()
                    continue
                elif cmd == 'clear':
                    os.system('cls' if os.name == 'nt' else 'clear')
                    self._print_header()
                    continue

                line_count = len(user_input.splitlines())
                if USE_RICH:
                    console.print(f"[dim](Received {line_count} lines)[/]")
                else:
                    print(f"(Received {line_count} lines)")

                task = await self._analyze_input(user_input)
                if USE_RICH:
                    console.print("[dim]Processing...[/]")
                else:
                    print("Processing...")

                response = await self._process_task(task)
                if response is None:
                    response = "No response from system."

                print()
                if USE_RICH:
                    console.print(Panel(str(response), title="Results", border_style="blue"))
                else:
                    print(f"Results:\n{response}")
                print()

            except KeyboardInterrupt:
                print()
                self._print_goodbye()
                break
            except Exception as e:
                logger.error(f"Error: {e}", exc_info=True)
                print(f"Error: {e}")

    # ============================================
    # Display Methods
    # ============================================

    def _show_help(self):
        print("\nCommands: help | status | agents | models | clear | exit")
        print("Models: Qwen + Gemma + Embeddings (preloaded) | DeepSeek OCR (on-demand)")
        print("Pipeline: Extract -> Preprocess -> Analyze -> Solve -> Critic")
        print("If any agent fails, the orchestrator automatically reroutes.\n")

    def _show_status(self):
        loaded = self.model_manager.get_loaded_models() if self.model_manager else []
        print(f"\nStatus: {'Running' if self.running else 'Stopped'}")
        print(f"Agents: {len(self.agents)} | Requests: {self.request_count}")
        print(f"Models loaded: {loaded}")

    def _show_agents(self):
        print("\nRegistered Agents:")
        for aid, agent in self.agents.items():
            cfg = next((a for a in AGENT_REGISTRY if a["agent_id"] == aid), {})
            model_status = "OK" if agent.model else "NO MODEL"
            print(f"  {aid}: model={cfg.get('model_key', 'none')} [{model_status}]")

    def _show_models(self):
        loaded = self.model_manager.get_loaded_models() if self.model_manager else []
        print("\nModel Status:")
        for mk in ["qwen", "gemma", "embeddings", "deepseek_ocr"]:
            status = "Loaded" if mk in loaded else "Not loaded"
            print(f"  {mk}: {status}")

    # ============================================
    # Print Helpers
    # ============================================

    def _print_header(self):
        h = ("\n"
             "  LOG ANALYSIS MULTI-AGENT SYSTEM v1.0\n"
             "  Gemma-4-E4B | Qwen-2.5-3B | Embeddings | DeepSeek OCR\n")
        if USE_RICH:
            console.print(h, style="bold cyan")
        else:
            print(h)

    def _print_section(self, t):
        if USE_RICH:
            console.print(f"[bold]{t}[/]")
        else:
            print(f"\n{t}")

    def _print_step(self, m):
        if USE_RICH:
            console.print(f"  ... {m}", style="dim")
        else:
            print(f"  ... {m}")

    def _print_success(self, m):
        if USE_RICH:
            console.print(f"  OK {m}", style="green")
        else:
            print(f"  OK {m}")

    def _print_warning(self, m):
        if USE_RICH:
            console.print(f"  ! {m}", style="yellow")
        else:
            print(f"  ! {m}")

    def _print_error(self, m):
        if USE_RICH:
            console.print(f"  X {m}", style="red")
        else:
            print(f"  X {m}")

    def _print_ready(self):
        loaded = self.model_manager.get_loaded_models() if self.model_manager else []
        qwen_status = "OK" if "qwen" in loaded else "NO"
        gemma_status = "OK" if "gemma" in loaded else "NO"
        emb_status = "OK" if "embeddings" in loaded else "NO"
        m = (f"\nSystem Ready\n"
             f"  Models: Qwen={qwen_status} | Gemma={gemma_status} | Embeddings={emb_status} | OCR=on-demand\n"
             f"  Agents: {len(self.agents)}\n"
             f"\nPaste logs below. Type 'help' for commands.\n")
        if USE_RICH:
            console.print(m, style="green")
        else:
            print(m)

    def _print_goodbye(self):
        m = "\nGoodbye!\n"
        if USE_RICH:
            console.print(m, style="bold yellow")
        else:
            print(m)

    def _print_agent_result(self, agent_name: str, confidence: float, response: Any = None, error: str = None):
        if confidence >= 0.8:
            level, bar = "HIGH", "--------"
        elif confidence >= 0.6:
            level, bar = "MEDIUM", "----"
        elif confidence >= 0.4:
            level, bar = "LOW", "--"
        else:
            level, bar = "POOR", "-"
        if USE_RICH:
            if error:
                console.print(f"  {agent_name}: {confidence:.0%} [{bar}] {level} - {error}", style="red")
            elif confidence < 0.5:
                console.print(f"  {agent_name}: {confidence:.0%} [{bar}] {level}", style="yellow")
            else:
                console.print(f"  {agent_name}: {confidence:.0%} [{bar}] {level}", style="green")
        else:
            print(f"  {agent_name}: {confidence:.0%} [{bar}] {level}")
            if error: print(f"    Error: {error}")

    def _print_pipeline_progress(self, agent_id: str, status: str, details: str = ""):
        icons = {"start": ">", "ok": "OK", "fail": "FAIL", "skip": "--", "wait": ".."}
        icon = icons.get(status, "  ")
        if USE_RICH:
            style = {"ok": "green", "fail": "red", "start": "bold cyan", "wait": "yellow"}.get(status, "dim")
            console.print(f"  {icon} {agent_id}: {details}", style=style)
        else:
            print(f"  {icon} {agent_id}: {details}")

    # ============================================
    # Shutdown
    # ============================================

    async def shutdown(self):
        if not self.running: return
        self.running = False
        self._print_step("Shutting down...")
        tasks = [t for t in asyncio.all_tasks() if t is not asyncio.current_task()]
        for task in tasks: task.cancel()
        if tasks: await asyncio.gather(*tasks, return_exceptions=True)
        for agent_id, agent in self.agents.items():
            try:
                if hasattr(agent, 'shutdown'): await agent.shutdown()
            except:
                pass
        if self.comm_bus:
            try:
                await asyncio.wait_for(self.comm_bus.stop(), timeout=5)
            except asyncio.TimeoutError:
                pass
        self._print_success("Shutdown complete")


async def main():
    system = LogAnalysisSystem()
    should_exit = False

    def signal_handler():
        nonlocal should_exit
        if should_exit: print("\n\nForce quitting..."); os._exit(1)
        should_exit = True
        print("\n\nShutting down... (Press Ctrl+C again to force quit)")

    try:
        loop = asyncio.get_event_loop()
        loop.add_signal_handler(signal.SIGINT, signal_handler)
        loop.add_signal_handler(signal.SIGTERM, signal_handler)
    except NotImplementedError:
        signal.signal(signal.SIGINT, lambda s, f: signal_handler())

    try:
        await system.initialize()
        if len(sys.argv) > 1:
            await system.run_single_query(" ".join(sys.argv[1:]))
        else:
            await system.run_interactive()
    except KeyboardInterrupt:
        print("\n\nShutting down...")
    except asyncio.CancelledError:
        pass
    except Exception as e:
        logger.error(f"Fatal error: {e}", exc_info=True)
        print(f"\nFatal error: {e}")
    finally:
        try:
            await asyncio.wait_for(system.shutdown(), timeout=10)
        except (asyncio.TimeoutError, asyncio.CancelledError):
            print("\nForce quitting..."); os._exit(0)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nExited."); os._exit(0)