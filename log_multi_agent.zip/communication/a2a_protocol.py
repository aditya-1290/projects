# communication/a2a_protocol.py
"""
A2A Protocol - Agent-to-Agent communication protocol implementation
"""

from typing import Dict, Any, List, Optional, Callable
import asyncio
import logging
from datetime import datetime

from .schemas import (
    AgentMessage, MessageSchemas, MessageType,
    MessagePriority, CapabilityInfo
)
from .message_broker import MessageBroker
from .discovery import ServiceDiscovery

logger = logging.getLogger(__name__)


class A2AProtocol:
    """
    Agent-to-Agent communication protocol.
    Provides high-level API for agent communication.
    """

    def __init__(self, broker: MessageBroker = None,
                 discovery: ServiceDiscovery = None):
        self.broker = broker or MessageBroker()
        self.discovery = discovery or ServiceDiscovery()
        self.agent_id = None
        self.message_handlers: Dict[str, Callable] = {}

    async def initialize(self, agent_id: str, agent_name: str,
                         capabilities: List[str], model: str = ""):
        """Initialize the protocol for an agent"""
        self.agent_id = agent_id

        # Register with service discovery
        self.discovery.register(
            agent_id=agent_id,
            agent_name=agent_name,
            capabilities=capabilities,
            model=model
        )

        # Subscribe to messages
        self.broker.subscribe(agent_id, self._handle_message)

        logger.info(f"A2A Protocol initialized for: {agent_name} ({agent_id})")

    async def _handle_message(self, message: AgentMessage):
        """Handle incoming messages"""

        # Route to specific handler based on message type
        handler_key = message.message_type.value
        if handler_key in self.message_handlers:
            await self.message_handlers[handler_key](message)
        else:
            logger.debug(f"No handler for message type: {handler_key}")

    def register_handler(self, message_type: MessageType, handler: Callable):
        """Register a handler for a specific message type"""
        self.message_handlers[message_type.value] = handler

    async def send_task(self, target_agent: str, task_type: str,
                        input_data: Any, parameters: Dict = None,
                        wait_for_response: bool = True,
                        timeout: float = 60.0) -> Optional[AgentMessage]:
        """Send a task to another agent"""

        message = MessageSchemas.create_task_request(
            sender=self.agent_id,
            receiver=target_agent,
            task_type=task_type,
            input_data=input_data,
            parameters=parameters
        )

        if wait_for_response:
            return await self.broker.send_and_wait(message, timeout=timeout)
        else:
            await self.broker.send(message)
            return None

    async def respond_to_task(self, original_message: AgentMessage,
                              result: Any, success: bool = True,
                              reasoning: str = None):
        """Send a response to a task request"""

        task_id = original_message.content.get('task_id', '')

        response = MessageSchemas.create_task_response(
            sender=self.agent_id,
            receiver=original_message.sender,
            task_id=task_id,
            result=result,
            success=success,
            reasoning=reasoning
        )

        # Set correlation ID
        response.correlation_id = original_message.id

        await self.broker.send(response)

    async def query_capabilities(self,
                                 required_capability: str = None) -> List[CapabilityInfo]:
        """Query other agents for their capabilities"""

        # First check local discovery
        if required_capability:
            return self.discovery.find_by_capability(required_capability)
        else:
            return self.discovery.get_active_agents()

    async def broadcast_task(self, task_type: str, input_data: Any,
                             required_capability: str = None) -> Dict[str, Any]:
        """Broadcast a task to all agents (or those with required capability)"""

        # Find target agents
        if required_capability:
            targets = self.discovery.find_by_capability(required_capability)
        else:
            targets = self.discovery.get_active_agents()

        results = {}

        for target in targets:
            if target.agent_id != self.agent_id:
                response = await self.send_task(
                    target_agent=target.agent_id,
                    task_type=task_type,
                    input_data=input_data,
                    wait_for_response=True,
                    timeout=30.0
                )
                results[target.agent_id] = response.content if response else None

        return results

    async def send_heartbeat(self):
        """Send heartbeat to maintain active status"""
        self.discovery.heartbeat(self.agent_id)

    async def report_error(self, target_agent: str, error: str,
                           details: Dict = None):
        """Report an error to another agent or orchestrator"""

        message = MessageSchemas.create_error_message(
            sender=self.agent_id,
            receiver=target_agent,
            error=error,
            details=details
        )

        await self.broker.send(message)

    async def request_clarification(self, target_agent: str,
                                    question: str, context: Dict = None) -> Optional[AgentMessage]:
        """Request clarification from another agent"""

        message = MessageSchemas.create_clarification_request(
            sender=self.agent_id,
            receiver=target_agent,
            question=question,
            context=context
        )

        return await self.broker.send_and_wait(message, timeout=30.0)

    async def shutdown(self):
        """Shutdown the protocol"""
        if self.agent_id:
            self.discovery.unregister(self.agent_id)
            self.broker.unsubscribe(self.agent_id)

        logger.info(f"A2A Protocol shutdown for: {self.agent_id}")

    def get_stats(self) -> Dict[str, Any]:
        """Get protocol statistics"""
        return {
            'agent_id': self.agent_id,
            'broker_stats': self.broker.get_stats(),
            'health': self.discovery.check_health()
        }