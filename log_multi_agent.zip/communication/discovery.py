# communication/discovery.py
"""
Service Discovery - Allows agents to discover each other's capabilities
"""

from typing import Dict, Any, List, Optional
import logging
from datetime import datetime

from .schemas import CapabilityInfo

logger = logging.getLogger(__name__)


class ServiceDiscovery:
    """
    Service discovery for agents.
    Agents register their capabilities and can discover other agents.
    """

    def __init__(self):
        self.agents: Dict[str, CapabilityInfo] = {}
        self.heartbeat_timeout = 30  # seconds
        self.last_heartbeat: Dict[str, datetime] = {}

    def register(self, agent_id: str, agent_name: str,
                 capabilities: List[str], model: str = "",
                 description: str = "") -> bool:
        """Register an agent with its capabilities"""

        info = CapabilityInfo(
            agent_id=agent_id,
            agent_name=agent_name,
            capabilities=capabilities,
            status="active",
            model=model,
            description=description
        )

        self.agents[agent_id] = info
        self.last_heartbeat[agent_id] = datetime.now()

        logger.info(f"Agent registered: {agent_name} ({agent_id}) "
                    f"with {len(capabilities)} capabilities")

        return True

    def unregister(self, agent_id: str):
        """Remove an agent from discovery"""
        if agent_id in self.agents:
            agent_name = self.agents[agent_id].agent_name
            del self.agents[agent_id]

            if agent_id in self.last_heartbeat:
                del self.last_heartbeat[agent_id]

            logger.info(f"Agent unregistered: {agent_name} ({agent_id})")

    def update_status(self, agent_id: str, status: str):
        """Update agent status"""
        if agent_id in self.agents:
            self.agents[agent_id].status = status
            logger.debug(f"Agent status updated: {agent_id} -> {status}")

    def heartbeat(self, agent_id: str):
        """Update agent heartbeat timestamp"""
        if agent_id in self.agents:
            self.last_heartbeat[agent_id] = datetime.now()
            if self.agents[agent_id].status != "active":
                self.agents[agent_id].status = "active"

    def find_by_capability(self, capability: str) -> List[CapabilityInfo]:
        """Find agents with a specific capability"""
        matching = []

        for agent_id, info in self.agents.items():
            if capability in info.capabilities:
                matching.append(info)

        return matching

    def find_agent(self, agent_id: str) -> Optional[CapabilityInfo]:
        """Find an agent by ID"""
        return self.agents.get(agent_id)

    def get_active_agents(self) -> List[CapabilityInfo]:
        """Get all currently active agents"""
        now = datetime.now()
        active = []

        for agent_id, info in self.agents.items():
            last_hb = self.last_heartbeat.get(agent_id)

            if last_hb and (now - last_hb).total_seconds() < self.heartbeat_timeout:
                active.append(info)
            else:
                # Mark as inactive if heartbeat missed
                info.status = "inactive"

        return active

    def get_all_capabilities(self) -> Dict[str, List[str]]:
        """Get mapping of all available capabilities"""
        capabilities = {}

        for info in self.agents.values():
            for cap in info.capabilities:
                if cap not in capabilities:
                    capabilities[cap] = []
                capabilities[cap].append(info.agent_id)

        return capabilities

    def check_health(self) -> Dict[str, Any]:
        """Health check for all agents"""
        now = datetime.now()
        health = {}

        for agent_id, info in self.agents.items():
            last_hb = self.last_heartbeat.get(agent_id)

            if last_hb:
                seconds_since = (now - last_hb).total_seconds()
                is_healthy = seconds_since < self.heartbeat_timeout
            else:
                seconds_since = None
                is_healthy = False

            health[agent_id] = {
                'name': info.agent_name,
                'status': info.status,
                'healthy': is_healthy,
                'last_heartbeat_seconds_ago': seconds_since,
                'capabilities': info.capabilities
            }

        return health