# communication/schemas.py
"""
Message Schemas - Defines message formats for A2A communication
"""

from typing import Dict, Any, List, Optional
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import uuid
import json


class MessageType(Enum):
    TASK_REQUEST = "task_request"
    TASK_RESPONSE = "task_response"
    CAPABILITY_QUERY = "capability_query"
    CAPABILITY_RESPONSE = "capability_response"
    STATUS_UPDATE = "status_update"
    HEARTBEAT = "heartbeat"
    ERROR = "error"
    DATA_TRANSFER = "data_transfer"
    CLARIFICATION = "clarification_request"


class MessagePriority(Enum):
    LOW = 1
    NORMAL = 2
    HIGH = 3
    CRITICAL = 4


@dataclass
class AgentMessage:
    """Standard message format for agent communication"""

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    sender: str = ""
    receiver: str = ""
    message_type: MessageType = MessageType.TASK_REQUEST
    priority: MessagePriority = MessagePriority.NORMAL
    content: Any = None
    correlation_id: Optional[str] = None
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'id': self.id,
            'sender': self.sender,
            'receiver': self.receiver,
            'message_type': self.message_type.value,
            'priority': self.priority.value,
            'content': self.content,
            'correlation_id': self.correlation_id,
            'timestamp': self.timestamp,
            'metadata': self.metadata
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), default=str)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'AgentMessage':
        return cls(
            id=data.get('id', str(uuid.uuid4())),
            sender=data.get('sender', ''),
            receiver=data.get('receiver', ''),
            message_type=MessageType(data.get('message_type', 'task_request')),
            priority=MessagePriority(data.get('priority', 2)),
            content=data.get('content'),
            correlation_id=data.get('correlation_id'),
            timestamp=data.get('timestamp', datetime.now().isoformat()),
            metadata=data.get('metadata', {})
        )

    @classmethod
    def from_json(cls, json_str: str) -> 'AgentMessage':
        return cls.from_dict(json.loads(json_str))


@dataclass
class TaskRequest:
    """Task request sent to an agent"""

    task_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    task_type: str = ""
    input_data: Dict[str, Any] = field(default_factory=dict)
    parameters: Dict[str, Any] = field(default_factory=dict)
    timeout: int = 60
    priority: MessagePriority = MessagePriority.NORMAL

    def to_dict(self) -> Dict[str, Any]:
        return {
            'task_id': self.task_id,
            'task_type': self.task_type,
            'input_data': self.input_data,
            'parameters': self.parameters,
            'timeout': self.timeout,
            'priority': self.priority.value
        }


@dataclass
class TaskResponse:
    """Response from an agent after task completion"""

    task_id: str = ""
    success: bool = False
    result: Any = None
    error: Optional[str] = None
    reasoning: Optional[str] = None
    agent_id: str = ""
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return {
            'task_id': self.task_id,
            'success': self.success,
            'result': self.result,
            'error': self.error,
            'reasoning': self.reasoning,
            'agent_id': self.agent_id,
            'timestamp': self.timestamp
        }


@dataclass
class CapabilityInfo:
    """Information about agent capabilities"""

    agent_id: str = ""
    agent_name: str = ""
    capabilities: List[str] = field(default_factory=list)
    status: str = "unknown"
    model: str = ""
    description: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            'agent_id': self.agent_id,
            'agent_name': self.agent_name,
            'capabilities': self.capabilities,
            'status': self.status,
            'model': self.model,
            'description': self.description
        }


class MessageSchemas:
    """Factory for creating properly formatted messages"""

    @staticmethod
    def create_task_request(sender: str, receiver: str, task_type: str,
                            input_data: Any, parameters: Dict = None) -> AgentMessage:
        """Create a task request message"""
        task = TaskRequest(
            task_type=task_type,
            input_data=input_data,
            parameters=parameters or {}
        )

        return AgentMessage(
            sender=sender,
            receiver=receiver,
            message_type=MessageType.TASK_REQUEST,
            content=task.to_dict()
        )

    @staticmethod
    def create_task_response(sender: str, receiver: str, task_id: str,
                             result: Any, success: bool = True,
                             reasoning: str = None) -> AgentMessage:
        """Create a task response message"""
        response = TaskResponse(
            task_id=task_id,
            success=success,
            result=result,
            reasoning=reasoning,
            agent_id=sender
        )

        return AgentMessage(
            sender=sender,
            receiver=receiver,
            message_type=MessageType.TASK_RESPONSE,
            content=response.to_dict(),
            correlation_id=task_id
        )

    @staticmethod
    def create_capability_query(sender: str,
                                required_capability: str = None) -> AgentMessage:
        """Create a capability query message"""
        return AgentMessage(
            sender=sender,
            receiver="broadcast",
            message_type=MessageType.CAPABILITY_QUERY,
            content={'required_capability': required_capability}
        )

    @staticmethod
    def create_capability_response(sender: str, receiver: str,
                                   capabilities: CapabilityInfo) -> AgentMessage:
        """Create a capability response message"""
        return AgentMessage(
            sender=sender,
            receiver=receiver,
            message_type=MessageType.CAPABILITY_RESPONSE,
            content=capabilities.to_dict()
        )

    @staticmethod
    def create_error_message(sender: str, receiver: str,
                             error: str, details: Dict = None) -> AgentMessage:
        """Create an error message"""
        return AgentMessage(
            sender=sender,
            receiver=receiver,
            message_type=MessageType.ERROR,
            priority=MessagePriority.HIGH,
            content={
                'error': error,
                'details': details or {}
            }
        )

    @staticmethod
    def create_clarification_request(sender: str, receiver: str,
                                     question: str, context: Dict = None) -> AgentMessage:
        """Create a clarification request"""
        return AgentMessage(
            sender=sender,
            receiver=receiver,
            message_type=MessageType.CLARIFICATION,
            content={
                'question': question,
                'context': context or {}
            }
        )