# communication/message_broker.py
"""
Message Broker - Handles message routing between agents
"""

from typing import Dict, Any, List, Optional, Callable
import asyncio
from collections import defaultdict
import logging
from datetime import datetime

from .schemas import AgentMessage, MessageType

logger = logging.getLogger(__name__)


class MessageBroker:
    """
    Central message broker for agent communication.
    Handles message routing, queuing, and delivery.
    """

    def __init__(self):
        # Subscribers: agent_id -> list of callbacks
        self.subscribers: Dict[str, List[Callable]] = defaultdict(list)

        # Message type subscribers: type -> list of callbacks
        self.type_subscribers: Dict[str, List[Callable]] = defaultdict(list)

        # Message queue for async processing
        self.message_queue: asyncio.Queue = asyncio.Queue()

        # Correlation tracking for request-response
        self.pending_requests: Dict[str, asyncio.Future] = {}

        # Message history
        self.message_history: List[AgentMessage] = []
        self.max_history = 1000

        # Broker state
        self.is_running = False
        self.processing_task = None

    async def start(self):
        """Start the message broker"""
        self.is_running = True
        self.processing_task = asyncio.create_task(self._process_messages())
        logger.info("Message broker started")

    async def stop(self):
        """Stop the message broker"""
        self.is_running = False

        if self.processing_task:
            self.processing_task.cancel()
            try:
                await self.processing_task
            except asyncio.CancelledError:
                pass

        logger.info("Message broker stopped")

    async def _process_messages(self):
        """Process messages from the queue"""
        while self.is_running:
            try:
                message = await asyncio.wait_for(
                    self.message_queue.get(),
                    timeout=1.0
                )

                await self._route_message(message)

                # Store in history
                self.message_history.append(message)
                if len(self.message_history) > self.max_history:
                    self.message_history = self.message_history[-self.max_history:]

            except asyncio.TimeoutError:
                continue
            except Exception as e:
                logger.error(f"Message processing error: {str(e)}")

    async def _route_message(self, message: AgentMessage):
        """Route a message to its destination"""

        # Direct message to specific agent
        if message.receiver and message.receiver != "broadcast":
            if message.receiver in self.subscribers:
                for callback in self.subscribers[message.receiver]:
                    try:
                        await callback(message)
                    except Exception as e:
                        logger.error(f"Callback error for {message.receiver}: {str(e)}")

            # Check for pending request correlation
            if message.correlation_id and message.correlation_id in self.pending_requests:
                future = self.pending_requests.pop(message.correlation_id)
                if not future.done():
                    future.set_result(message)

        # Broadcast message
        elif message.receiver == "broadcast":
            for agent_id, callbacks in self.subscribers.items():
                if agent_id != message.sender:  # Don't send to self
                    for callback in callbacks:
                        try:
                            await callback(message)
                        except Exception as e:
                            logger.error(f"Broadcast callback error: {str(e)}")

        # Route by message type
        type_key = message.message_type.value
        if type_key in self.type_subscribers:
            for callback in self.type_subscribers[type_key]:
                try:
                    if message.receiver != "broadcast" or True:  # Always for type subscribers
                        await callback(message)
                except Exception as e:
                    logger.error(f"Type subscriber error: {str(e)}")

    def subscribe(self, agent_id: str, callback: Callable):
        """Subscribe an agent to receive messages"""
        self.subscribers[agent_id].append(callback)
        logger.debug(f"Agent subscribed: {agent_id}")

    def unsubscribe(self, agent_id: str, callback: Callable = None):
        """Unsubscribe an agent from messages"""
        if callback:
            if agent_id in self.subscribers:
                self.subscribers[agent_id].remove(callback)
        else:
            if agent_id in self.subscribers:
                del self.subscribers[agent_id]

        logger.debug(f"Agent unsubscribed: {agent_id}")

    def subscribe_to_type(self, message_type: MessageType, callback: Callable):
        """Subscribe to a specific message type"""
        type_key = message_type.value
        self.type_subscribers[type_key].append(callback)
        logger.debug(f"Subscribed to message type: {type_key}")

    async def send(self, message: AgentMessage) -> bool:
        """Send a message through the broker"""
        try:
            await self.message_queue.put(message)
            return True
        except Exception as e:
            logger.error(f"Failed to send message: {str(e)}")
            return False

    async def send_and_wait(self, message: AgentMessage,
                            timeout: float = 30.0) -> Optional[AgentMessage]:
        """Send a message and wait for response"""

        # Create a future for the response
        future = asyncio.Future()
        self.pending_requests[message.id] = future

        # Send the message
        success = await self.send(message)

        if not success:
            if message.id in self.pending_requests:
                del self.pending_requests[message.id]
            return None

        try:
            response = await asyncio.wait_for(future, timeout=timeout)
            return response
        except asyncio.TimeoutError:
            logger.warning(f"Request timed out: {message.id}")
            if message.id in self.pending_requests:
                del self.pending_requests[message.id]
            return None

    def get_history(self, limit: int = 50,
                    agent_id: str = None,
                    message_type: MessageType = None) -> List[AgentMessage]:
        """Get message history with optional filters"""
        messages = self.message_history

        if agent_id:
            messages = [m for m in messages
                        if m.sender == agent_id or m.receiver == agent_id]

        if message_type:
            messages = [m for m in messages if m.message_type == message_type]

        return messages[-limit:]

    def get_stats(self) -> Dict[str, Any]:
        """Get broker statistics"""
        return {
            'is_running': self.is_running,
            'subscribers': len(self.subscribers),
            'type_subscribers': len(self.type_subscribers),
            'queue_size': self.message_queue.qsize(),
            'history_size': len(self.message_history),
            'pending_requests': len(self.pending_requests),
            'agents': list(self.subscribers.keys())
        }