# communication/__init__.py
"""
Communication - Agent-to-Agent (A2A) communication protocol
"""

from .a2a_protocol import A2AProtocol
from .message_broker import MessageBroker
from .discovery import ServiceDiscovery
from .schemas import MessageSchemas

__all__ = [
    'A2AProtocol',
    'MessageBroker',
    'ServiceDiscovery',
    'MessageSchemas'
]