# config.py
"""
Configuration settings for the Log Analysis Multi-Agent System
"""

import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()


class Config:
    # Project paths
    BASE_DIR = Path(__file__).parent
    MEMORY_STORE_PATH = BASE_DIR / "memory_store"
    CHROMA_DB_PATH = MEMORY_STORE_PATH / "chroma_db"
    LOGS_PATH = MEMORY_STORE_PATH / "logs"
    PROMPTS_PATH = BASE_DIR / "prompts"

    # Model configurations
    DEEPSEEK_OCR_MODEL = "deepseek-ocr-2"
    QWEN_MODEL = "qwen-2.5-3b-instruct"
    GEMMA_MODEL = "gemma-4-e4b-it"

    # Model paths
    MODELS_DIR = Path("D:/python_tasks/models")
    GEMMA_MODEL_PATH = MODELS_DIR / "gemma-4-E4B-it-Q5_K_M.gguf"
    QWEN_MODEL_PATH = MODELS_DIR / "qwen-2.5-3b-instruct.gguf"

    # Agent configurations
    MAX_RETRIES = 3
    CONFIDENCE_THRESHOLD = 0.7
    MAX_CHUNK_SIZE = 4096

    # Communication settings
    A2A_TIMEOUT = 30  # seconds
    MESSAGE_QUEUE_SIZE = 100

    # Safety settings
    COMMAND_WHITELIST = [
        "cat", "grep", "tail", "head", "awk", "sed",
        "ls", "find", "wc", "sort", "uniq"
    ]

    # Model temperature settings
    AGENT_TEMPERATURES = {
        "extractor": 0.1,
        "preprocessor": 0.1,
        "analyzer": 0.3,
        "solver": 0.5,
        "debugger": 0.4,
        "critic": 0.2,
        "memory": 0.1,
        "orchestrator": 0.3
    }

    @classmethod
    def ensure_directories(cls):
        """Create necessary directories if they don't exist"""
        cls.MEMORY_STORE_PATH.mkdir(exist_ok=True)
        cls.CHROMA_DB_PATH.mkdir(exist_ok=True)
        cls.LOGS_PATH.mkdir(exist_ok=True)
        cls.PROMPTS_PATH.mkdir(exist_ok=True)