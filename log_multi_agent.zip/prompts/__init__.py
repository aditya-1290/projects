# prompts/__init__.py
"""
Prompts - Prompt templates for all agents
Each agent loads its specific prompt file to guide model behavior
"""

from pathlib import Path
from typing import Dict, Optional
import logging

logger = logging.getLogger(__name__)


class PromptLoader:
    """Loads prompt templates from files"""

    def __init__(self, prompts_dir: str = "prompts"):
        self.prompts_dir = Path(prompts_dir)

    def load(self, filename: str) -> str:
        """Load a prompt from a text file"""
        filepath = self.prompts_dir / filename

        if not filepath.exists():
            logger.warning(f"Prompt file not found: {filepath}")
            return ""

        with open(filepath, 'r', encoding='utf-8') as f:
            return f.read()

    def load_all(self) -> Dict[str, str]:
        """Load all prompt files"""
        prompts = {}

        if self.prompts_dir.exists():
            for filepath in self.prompts_dir.glob("*.txt"):
                prompts[filepath.stem] = self.load(filepath.name)

        return prompts