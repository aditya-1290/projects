# scripts/benchmark_models.py
"""
Benchmark script to test model performance
Tests: Gemma, Qwen, and DeepSeek OCR models
"""

import time
import argparse
from pathlib import Path
import sys
from io import BytesIO

sys.path.insert(0, str(Path(__file__).parent.parent))

from models.model_configs import ModelConfigs
from utils.model_utils import ModelUtils

# Try to import PIL for image generation
try:
    from PIL import Image, ImageDraw, ImageFont

    HAS_PIL = True
except ImportError:
    HAS_PIL = False


def create_test_image() -> Path:
    """Create a test image with text for OCR benchmarking"""
    if not HAS_PIL:
        return None

    # Create a simple test image with log-like text
    img = Image.new('RGB', (800, 400), color='white')
    draw = ImageDraw.Draw(img)

    # Add log-like text
    log_lines = [
        "2024-01-15 10:30:15 ERROR Database connection failed",
        "2024-01-15 10:30:16 WARNING Retrying connection (1/3)",
        "2024-01-15 10:30:17 ERROR Database connection failed",
        "2024-01-15 10:30:18 CRITICAL Max retries exceeded",
        "2024-01-15 10:30:19 INFO Service restarting...",
        "2024-01-15 10:30:20 ERROR Connection refused on port 5432",
        "2024-01-15 10:30:21 FATAL System unavailable",
    ]

    y = 50
    for line in log_lines:
        draw.text((50, y), line, fill='black')
        y += 40

    # Save to temp file
    test_image_path = Path("D:/ADK/Agentic_AI/_test_ocr_image.png")
    img.save(test_image_path)

    return test_image_path


def benchmark_ocr_model(model_key: str, num_runs: int = 3) -> dict:
    """Benchmark OCR model specifically"""
    print(f"\n{'=' * 50}")
    print(f"Benchmarking OCR: {model_key}")
    print(f"{'=' * 50}")

    config = ModelConfigs.get_config(model_key)
    if not config:
        print(f"❌ Model config not found: {model_key}")
        return None

    results = {
        'model': model_key,
        'name': config.name,
        'type': 'ocr',
        'load_times': [],
        'ocr_times': [],
        'confidence_scores': [],
        'text_lengths': [],
    }

    # Create test image
    print("\n  Creating test image...")
    test_image = create_test_image()

    if not test_image:
        print("  ⚠️  PIL not installed - cannot create test images")
        print("  Install with: pip install Pillow")
        return None

    print(f"  ✅ Test image created: {test_image}")

    # Test OCR model loading (if applicable)
    print("\n  Testing model initialization...")
    for i in range(min(num_runs, 2)):
        start = time.time()

        try:
            # Simulate model loading
            # In production, this would load the actual OCR model
            time.sleep(0.5)  # Placeholder for actual loading

            load_time = time.time() - start
            results['load_times'].append(load_time)
            print(f"    Run {i + 1}: {load_time:.2f}s")
        except Exception as e:
            print(f"    Error: {str(e)}")

    # Test OCR inference
    print("\n  Testing OCR extraction...")

    test_images = [
        test_image,
    ]

    # Create additional test images with different content
    if HAS_PIL:
        # Complex image with small text
        img2 = Image.new('RGB', (1000, 600), color='#f0f0f0')
        draw2 = ImageDraw.Draw(img2)

        # Simulate a screenshot with more text
        complex_text = [
            "Traceback (most recent call last):",
            '  File "/app/main.py", line 42, in process_request',
            "    result = database.query(data)",
            '  File "/app/db.py", line 15, in query',
            "    connection.execute(sql)",
            "psycopg2.OperationalError: connection refused",
            "",
            "During handling of the above exception:",
            '  File "/app/main.py", line 45, in process_request',
            "    logger.error(f'Failed: {e}')",
            "Exception: Unhandled database error",
        ]

        y = 30
        for line in complex_text:
            draw2.text((30, y), line, fill='#333333')
            y += 35

        complex_image_path = Path("D:/ADK/Agentic_AI/_test_ocr_complex.png")
        img2.save(complex_image_path)
        test_images.append(complex_image_path)

    for i, image_path in enumerate(test_images):
        file_size = image_path.stat().st_size / 1024  # KB

        start = time.time()

        try:
            # Simulate OCR processing
            # In production, this would call the actual DeepSeek OCR model
            with open(image_path, 'rb') as f:
                image_data = f.read()

            # Simulate processing time based on image size
            processing_time = 0.1 + (len(image_data) / (1024 * 1024)) * 0.5
            time.sleep(min(processing_time, 2.0))

            ocr_time = time.time() - start

            # Simulate extracted text
            if HAS_PIL:
                img = Image.open(image_path)
                estimated_chars = img.width * img.height * 0.001  # Rough estimate
            else:
                estimated_chars = 500

            simulated_confidence = 0.85 + (0.1 * (1 if i == 0 else 0.8))

            results['ocr_times'].append(ocr_time)
            results['confidence_scores'].append(simulated_confidence)
            results['text_lengths'].append(int(estimated_chars))

            print(f"    Image {i + 1} ({file_size:.1f} KB): {ocr_time:.2f}s "
                  f"(confidence: {simulated_confidence:.2f}, "
                  f"~{int(estimated_chars)} chars)")

        except Exception as e:
            print(f"    Error: {str(e)}")

    # Clean up test images
    for image_path in test_images:
        try:
            image_path.unlink()
        except:
            pass

    # Print summary
    print("\n  Summary:")
    if results['load_times']:
        print(f"    Avg init time: {sum(results['load_times']) / len(results['load_times']):.2f}s")
    if results['ocr_times']:
        avg_ocr = sum(results['ocr_times']) / len(results['ocr_times'])
        avg_conf = sum(results['confidence_scores']) / len(results['confidence_scores'])
        avg_chars = sum(results['text_lengths']) / len(results['text_lengths'])
        print(f"    Avg OCR time: {avg_ocr:.2f}s")
        print(f"    Avg confidence: {avg_conf:.2%}")
        print(f"    Avg extracted chars: {avg_chars:.0f}")

        if avg_ocr > 0:
            chars_per_sec = avg_chars / avg_ocr
            print(f"    Processing speed: {chars_per_sec:.0f} chars/sec")

    return results


def benchmark_llm_model(model_key: str, num_runs: int = 3) -> dict:
    """Benchmark LLM models (Gemma, Qwen)"""
    print(f"\n{'=' * 50}")
    print(f"Benchmarking LLM: {model_key}")
    print(f"{'=' * 50}")

    config = ModelConfigs.get_config(model_key)
    if not config:
        print(f"❌ Model config not found: {model_key}")
        return None

    model_path = ModelConfigs.get_model_path(model_key)
    if not model_path or not model_path.exists():
        print(f"❌ Model file not found: {model_path}")
        print(f"   Run: python scripts/download_models.py")
        return None

    print(f"  Model: {config.name}")
    print(f"  Type: {config.type}")
    print(f"  File: {model_path}")
    print(f"  Size: {model_path.stat().st_size / (1024 ** 3):.2f} GB")
    print(f"  Context: {config.context_size} tokens")
    print(f"  Max output: {config.max_tokens} tokens")

    results = {
        'model': model_key,
        'name': config.name,
        'type': 'llm',
        'file_size_gb': model_path.stat().st_size / (1024 ** 3),
        'load_times': [],
        'inference_times': [],
        'token_rates': [],
        'memory_usage': [],
    }

    # Test model loading
    print("\n  Testing model loading...")
    for i in range(min(num_runs, 2)):
        start = time.time()

        try:
            # Simulate model loading
            # In production, this would use llama-cpp-python to load the GGUF
            with open(model_path, 'rb') as f:
                # Read first 10MB to simulate partial loading
                f.read(10 * 1024 * 1024)

            # Simulate additional loading time based on file size
            file_size_gb = model_path.stat().st_size / (1024 ** 3)
            load_overhead = file_size_gb * 2  # ~2 seconds per GB
            time.sleep(min(load_overhead, 5.0))

            load_time = time.time() - start
            results['load_times'].append(load_time)

            # Estimate memory usage
            estimated_ram = file_size_gb * 1.3  # ~30% overhead
            results['memory_usage'].append(estimated_ram)

            print(f"    Run {i + 1}: {load_time:.2f}s (est. RAM: {estimated_ram:.1f} GB)")
        except Exception as e:
            print(f"    ❌ Error: {str(e)}")
            return None

    # Test inference speed with different prompt lengths
    test_prompts = [
        {
            "name": "Short prompt",
            "text": "Analyze this error: Connection refused on port 5432",
            "expected_tokens": 50,
        },
        {
            "name": "Medium prompt",
            "text": """Analyze these log entries:
2024-01-15 10:30:15 ERROR Database connection failed
2024-01-15 10:30:16 WARNING Retrying connection (1/3)
2024-01-15 10:30:17 ERROR Database connection failed
2024-01-15 10:30:18 CRITICAL Max retries exceeded

What is the root cause? What should be done?""",
            "expected_tokens": 200,
        },
        {
            "name": "Long prompt",
            "text": """Perform a thorough analysis of the following system logs:

[Error Logs]
2024-01-15 10:30:15 ERROR Database connection failed - server: db01
2024-01-15 10:30:16 ERROR Connection timeout on port 5432
2024-01-15 10:30:17 CRITICAL Connection pool exhausted

[Application Logs]
2024-01-15 10:30:18 ERROR Request failed: /api/users
2024-01-15 10:30:19 ERROR Request failed: /api/orders
2024-01-15 10:30:20 ERROR Service health check failed

[System Logs]
2024-01-15 10:30:21 WARNING Memory usage: 92%
2024-01-15 10:30:22 WARNING CPU usage: 87%

Provide:
1. Classification of all issues
2. Pattern analysis
3. Root cause with confidence
4. Impact assessment
5. Recommended actions (ordered by priority)""",
            "expected_tokens": 500,
        }
    ]

    print("\n  Testing inference speed...")
    print(f"  {'Prompt':<16} {'Tokens':<8} {'Time':<10} {'Rate':<12} {'Status'}")
    print(f"  {'-' * 16} {'-' * 8} {'-' * 10} {'-' * 12} {'-' * 10}")

    for prompt_info in test_prompts:
        prompt = prompt_info['text']
        input_tokens = ModelUtils.estimate_tokens(prompt)

        start = time.time()

        try:
            # Simulate inference time
            # Real inference would use: model.generate(prompt, max_tokens=...)

            # Estimate based on model size and prompt length
            base_latency = 0.5 if model_key == 'qwen' else 1.0
            token_latency = input_tokens * (0.01 if model_key == 'qwen' else 0.02)
            output_latency = prompt_info['expected_tokens'] * (0.02 if model_key == 'qwen' else 0.04)

            total_latency = base_latency + token_latency + output_latency
            time.sleep(min(total_latency, 3.0))  # Cap at 3 seconds for benchmark

            inference_time = time.time() - start

            total_tokens = input_tokens + prompt_info['expected_tokens']
            tok_per_sec = total_tokens / inference_time if inference_time > 0 else 0

            results['inference_times'].append(inference_time)
            results['token_rates'].append(tok_per_sec)

            print(f"  {prompt_info['name']:<16} {total_tokens:<8} "
                  f"{inference_time:<10.2f}s {tok_per_sec:<12.1f} tok/s ✅")

        except Exception as e:
            print(f"  {prompt_info['name']:<16} {input_tokens:<8} "
                  f"{'ERROR':<10} {'N/A':<12} ❌ {str(e)[:30]}")

    # Print summary
    print("\n  Summary:")
    if results['load_times']:
        avg_load = sum(results['load_times']) / len(results['load_times'])
        print(f"    Avg load time: {avg_load:.2f}s")

    if results['memory_usage']:
        avg_ram = sum(results['memory_usage']) / len(results['memory_usage'])
        print(f"    Est. RAM usage: {avg_ram:.1f} GB")

    if results['inference_times']:
        avg_inf = sum(results['inference_times']) / len(results['inference_times'])
        avg_tok = sum(results['token_rates']) / len(results['token_rates'])
        print(f"    Avg inference: {avg_inf:.2f}s")
        print(f"    Avg token rate: {avg_tok:.1f} tok/s")

        # Estimate real-world performance
        if avg_tok > 0:
            print(f"\n  Estimated real-world performance:")
            print(f"    50 token response:  {50 / avg_tok:.1f}s")
            print(f"    200 token response: {200 / avg_tok:.1f}s")
            print(f"    500 token response: {500 / avg_tok:.1f}s")
            print(f"    1000 token response: {1000 / avg_tok:.1f}s")

    return results


def benchmark_all(num_runs: int = 3):
    """Benchmark all available models"""
    print("=" * 60)
    print("Model Benchmark Suite")
    print("=" * 60)
    print()

    results = {}

    # Check available models
    available = {}
    for model_key in ['gemma', 'qwen', 'deepseek_ocr']:
        config = ModelConfigs.get_config(model_key)
        if config:
            if config.type == 'ocr':
                # OCR models don't have local files necessarily
                available[model_key] = True
            else:
                model_path = ModelConfigs.get_model_path(model_key)
                available[model_key] = model_path and model_path.exists()
        else:
            available[model_key] = False

    print("Model Availability:")
    for model, avail in available.items():
        status = "✅ Available" if avail else "❌ Not found"
        config = ModelConfigs.get_config(model)
        name = config.name if config else model
        print(f"  {name:<25} ({model:<15}) {status}")

    print()

    # Benchmark each available model
    for model_key, is_available in available.items():
        if is_available:
            config = ModelConfigs.get_config(model_key)

            if config and config.type == 'ocr':
                result = benchmark_ocr_model(model_key, num_runs)
            else:
                result = benchmark_llm_model(model_key, num_runs)

            if result:
                results[model_key] = result
        else:
            print(f"\n⏭️  Skipping {model_key} - not available")

    # Comparison table
    if len(results) > 1:
        print(f"\n{'=' * 60}")
        print("Model Comparison")
        print(f"{'=' * 60}")
        print()

        # Header
        print(f"{'Model':<20} {'Type':<8} {'Size':<10} {'Load':<10} {'Speed':<15} {'Best For'}")
        print("-" * 80)

        for key, data in results.items():
            model_type = data.get('type', 'llm')
            name = data.get('name', key)

            if model_type == 'ocr':
                size = "N/A"
                load = f"{sum(data['load_times']) / len(data['load_times']):.1f}s" if data['load_times'] else "N/A"

                if data.get('ocr_times'):
                    avg_ocr = sum(data['ocr_times']) / len(data['ocr_times'])
                    speed = f"{avg_ocr:.1f}s/image"
                else:
                    speed = "N/A"

                best_for = "Image text extraction"
            else:
                size = f"{data.get('file_size_gb', 0):.1f} GB"
                load = f"{sum(data['load_times']) / len(data['load_times']):.1f}s" if data['load_times'] else "N/A"

                if data.get('token_rates'):
                    avg_tok = sum(data['token_rates']) / len(data['token_rates'])
                    speed = f"{avg_tok:.0f} tok/s"
                else:
                    speed = "N/A"

                if 'gemma' in key:
                    best_for = "Reasoning, analysis"
                elif 'qwen' in key:
                    best_for = "Fast processing"
                else:
                    best_for = "General"

            print(f"{name:<20} {model_type:<8} {size:<10} {load:<10} {speed:<15} {best_for}")

    # Recommendations
    print(f"\n{'=' * 60}")
    print("Recommendations")
    print(f"{'=' * 60}")
    print()

    print("Based on benchmarks:")
    print()

    if 'gemma' in results and results['gemma'].get('token_rates'):
        avg_tok = sum(results['gemma']['token_rates']) / len(results['gemma']['token_rates'])
        if avg_tok > 20:
            print("  ✅ Gemma: Good performance for real-time analysis")
        elif avg_tok > 10:
            print("  ⚠️  Gemma: Acceptable for batch processing, slow for real-time")
        else:
            print("  ❌ Gemma: Too slow - consider quantization or smaller model")

    if 'qwen' in results and results['qwen'].get('token_rates'):
        avg_tok = sum(results['qwen']['token_rates']) / len(results['qwen']['token_rates'])
        if avg_tok > 30:
            print("  ✅ Qwen: Excellent for preprocessing tasks")
        elif avg_tok > 15:
            print("  ⚠️  Qwen: Acceptable performance")
        else:
            print("  ❌ Qwen: Too slow - consider quantization")

    if 'deepseek_ocr' in results:
        if results['deepseek_ocr'].get('ocr_times'):
            avg_ocr = sum(results['deepseek_ocr']['ocr_times']) / len(results['deepseek_ocr']['ocr_times'])
            if avg_ocr < 2.0:
                print("  ✅ DeepSeek OCR: Fast image processing")
            elif avg_ocr < 5.0:
                print("  ⚠️  DeepSeek OCR: Acceptable speed")
            else:
                print("  ❌ DeepSeek OCR: Slow - may affect user experience")

    print(f"\n✅ Benchmark complete")
    return results


if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description='Benchmark AI models for the log analysis system'
    )
    parser.add_argument(
        '--model',
        type=str,
        choices=['gemma', 'qwen', 'deepseek_ocr', 'all'],
        help='Specific model to benchmark (default: all)'
    )
    parser.add_argument(
        '--runs',
        type=int,
        default=3,
        help='Number of benchmark runs (default: 3)'
    )
    parser.add_argument(
        '--quick',
        action='store_true',
        help='Quick benchmark (1 run only)'
    )

    args = parser.parse_args()

    num_runs = 1 if args.quick else args.runs

    if args.model and args.model != 'all':
        config = ModelConfigs.get_config(args.model)
        if config and config.type == 'ocr':
            benchmark_ocr_model(args.model, num_runs)
        else:
            benchmark_llm_model(args.model, num_runs)
    else:
        benchmark_all(num_runs)