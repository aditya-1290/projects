# scripts/download_models.sh

set -e

echo "========================================="
echo "Log Analysis Multi-Agent System"
echo "Model Download Script"
echo "========================================="
echo ""

# Configuration
MODELS_DIR="D:\Models"
GEMMA_MODEL="gemma-4-e4b-it.gguf"
QWEN_MODEL="qwen-2.5-3b-instruct.gguf"
EMBEDDINGS_MODEL="bge-small-en-v1.5"

# Create models directory
mkdir -p "$MODELS_DIR"

echo "📦 Models will be downloaded to: $MODELS_DIR"
echo ""

# Function to check if file exists
check_exists() {
    if [ -f "$MODELS_DIR/$1" ]; then
        echo "✅ $1 already exists"
        return 0
    fi
    return 1
}

# Download Gemma model
echo "========================================="
echo "Downloading Gemma-4-E4B-it (4B parameters)"
echo "Used by: Analyzer, Solver, Debugger, Critic, Orchestrator"
echo "========================================="
echo ""

if check_exists "$GEMMA_MODEL"; then
    echo "Skipping Gemma download..."
else
    echo "⚠️  Gemma model requires manual download due to license requirements."
    echo ""
    echo "Please download from one of these sources:"
    echo "1. Hugging Face: https://huggingface.co/google/gemma-4-e4b-it"
    echo "2. Ollama: ollama pull gemma:7b (then convert to GGUF)"
    echo ""
    echo "After downloading, place the file at:"
    echo "   $MODELS_DIR/$GEMMA_MODEL"
    echo ""

    read -p "Press Enter to continue once downloaded, or Ctrl+C to skip..."
fi

# Download Qwen model
echo ""
echo "========================================="
echo "Downloading Qwen-2.5-3B-Instruct (3B parameters)"
echo "Used by: Preprocessor, Memory"
echo "========================================="
echo ""

if check_exists "$QWEN_MODEL"; then
    echo "Skipping Qwen download..."
else
    echo "⚠️  Qwen model requires manual download."
    echo ""
    echo "Download from:"
    echo "1. Hugging Face: https://huggingface.co/Qwen/Qwen2.5-3B-Instruct-GGUF"
    echo "2. Choose the appropriate quantization (q4_K_M recommended for 4-bit)"
    echo ""
    echo "After downloading, place the file at:"
    echo "   $MODELS_DIR/$QWEN_MODEL"
    echo ""

    read -p "Press Enter to continue once downloaded, or Ctrl+C to skip..."
fi

# Download Embeddings model
echo ""
echo "========================================="
echo "Downloading Embedding Model"
echo "Used by: Memory (vector storage)"
echo "========================================="
echo ""

# Check if already downloaded via Python
python3 -c "from sentence_transformers import SentenceTransformer; SentenceTransformer('$EMBEDDINGS_MODEL')" 2>/dev/null && {
    echo "✅ $EMBEDDINGS_MODEL already downloaded"
} || {
    echo "Downloading $EMBEDDINGS_MODEL..."
    pip install sentence-transformers
    python3 -c "from sentence_transformers import SentenceTransformer; SentenceTransformer('$EMBEDDINGS_MODEL')"
    echo "✅ Embeddings model downloaded"
}

echo ""
echo "========================================="
echo "Checking Model Status"
echo "========================================="
echo ""

# Check all models
echo "Gemma model:"
[ -f "$MODELS_DIR/$GEMMA_MODEL" ] && echo "  ✅ Found" || echo "  ❌ Not found - download required"

echo "Qwen model:"
[ -f "$MODELS_DIR/$QWEN_MODEL" ] && echo "  ✅ Found" || echo "  ❌ Not found - download required"

echo "Embeddings model:"
python3 -c "from sentence_transformers import SentenceTransformer; SentenceTransformer('$EMBEDDINGS_MODEL')" 2>/dev/null && \
    echo "  ✅ Available" || echo "  ❌ Not available"

echo ""
echo "========================================="
echo "Download Complete"
echo "========================================="
echo ""
echo "Next steps:"
echo "1. Verify models: python scripts/benchmark_models.py"
echo "2. Start the system: python main.py"