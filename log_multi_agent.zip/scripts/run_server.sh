# scripts/run_server.sh
#!/bin/bash
"""
Script to start the log analysis multi-agent system
"""

#!/bin/bash

set -e

echo "========================================="
echo "Log Analysis Multi-Agent System"
echo "Starting Server..."
echo "========================================="
echo ""

# Configuration
PYTHON_CMD="python3"
MAIN_SCRIPT="main.py"
LOG_DIR="./memory_store/logs"

# Check Python version
echo "Checking Python version..."
$PYTHON_CMD --version

# Check and create log directory
mkdir -p "$LOG_DIR"

# Check for virtual environment
if [ -d "venv" ]; then
    echo "Activating virtual environment..."
    source venv/bin/activate
elif [ -d ".venv" ]; then
    echo "Activating virtual environment..."
    source .venv/bin/activate
fi

# Check requirements
echo ""
echo "Checking dependencies..."
if [ -f "requirements.txt" ]; then
    $PYTHON_CMD -c "import pkg_resources; pkg_resources.require(open('requirements.txt').readlines())" 2>/dev/null || {
        echo "⚠️  Some dependencies missing. Install with:"
        echo "   pip install -r requirements.txt"
    }
fi

# Check models
echo ""
echo "Checking models..."
$PYTHON_CMD -c "
from models.model_configs import ModelConfigs
import os

for model_key in ['gemma', 'qwen']:
    path = ModelConfigs.get_model_path(model_key)
    if path and path.exists():
        print(f'  ✅ {model_key}: {path}')
    else:
        print(f'  ❌ {model_key}: not found at {path}')
        print(f'     Run: bash scripts/download_models.sh')
"

# Start the system
echo ""
echo "========================================="
echo "Starting Multi-Agent System..."
echo "========================================="
echo ""
echo "Available commands:"
echo "  help     - Show available commands"
echo "  analyze  - Analyze log data"
echo "  debug    - Debug code or errors"
echo "  status   - Show system status"
echo "  exit     - Exit the system"
echo ""

# Run the main script
$PYTHON_CMD "$MAIN_SCRIPT" "$@"