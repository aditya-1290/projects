# scripts/init_adk_project.sh
#!/bin/bash
"""
Initialize the ADK (Agent Development Kit) project structure
"""

#!/bin/bash

set -e

echo "========================================="
echo "ADK Project Initialization"
echo "========================================="
echo ""

PROJECT_DIR="./log_multi_agent"

# Create directory structure
echo "Creating project structure..."

directories=(
    "agentos"
    "agents/extractor/loaders"
    "agents/extractor/parsers"
    "agents/preprocessor"
    "agents/analyzer"
    "agents/solver"
    "agents/debugger"
    "agents/critic"
    "agents/memory"
    "agents/orchestrator"
    "models/llm"
    "models/ocr"
    "models/embeddings"
    "models/downloaded"
    "tools"
    "safety"
    "communication"
    "memory_store/chroma_db"
    "memory_store/logs"
    "prompts"
    "utils"
    "tests/integration"
    "tests/e2e"
    "scripts"
    "docs"
)

for dir in "${directories[@]}"; do
    mkdir -p "$PROJECT_DIR/$dir"
    echo "  ✅ $dir"
done

# Create __init__.py files
echo ""
echo "Creating __init__.py files..."

find "$PROJECT_DIR" -type d -exec touch {}/__init__.py \; 2>/dev/null || true

# Create .env file
echo ""
echo "Creating .env configuration..."
cat > "$PROJECT_DIR/.env" << 'EOF'
# Model configuration
GEMMA_MODEL_PATH=models/downloaded/gemma-4-e4b-it.gguf
QWEN_MODEL_PATH=models/downloaded/qwen-2.5-3b-instruct.gguf

# System settings
LOG_LEVEL=INFO
MAX_WORKERS=4
TIMEOUT=60

# Security
COMMAND_TIMEOUT=30
MAX_FILE_SIZE=104857600
ALLOWED_PATHS=/var/log,./logs,./test_logs

# Memory
CHROMA_DB_PATH=memory_store/chroma_db
MAX_MEMORIES=10000
EOF

# Create .gitignore
echo "Creating .gitignore..."
cat > "$PROJECT_DIR/.gitignore" << 'EOF'
# Python
__pycache__/
*.py[cod]
*.so
*.egg-info/
dist/
build/
venv/
.venv/

# Models
models/downloaded/*.gguf
models/downloaded/*.bin

# Environment
.env
*.env.local

# Logs
memory_store/logs/*.log
memory_store/chroma_db/

# IDE
.vscode/
.idea/
*.swp
*.swo

# OS
.DS_Store
Thumbs.db
EOF

echo ""
echo "========================================="
echo "Project initialized: $PROJECT_DIR"
echo "========================================="
echo ""
echo "Next steps:"
echo "1. cd $PROJECT_DIR"
echo "2. python -m venv venv && source venv/bin/activate"
echo "3. pip install -r requirements.txt"
echo "4. bash scripts/download_models.sh"
echo "5. python main.py"