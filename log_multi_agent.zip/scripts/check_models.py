# scripts/check_models.py (NEW - Diagnostic script)
"""
Check model files and paths
"""

import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

print("=" * 60)
print("Model Path Diagnostics")
print("=" * 60)

# Current working directory
print(f"\nCurrent directory: {Path.cwd()}")

# Models directory
models_dir = os.getenv("MODELS_DIR", "models/downloaded")
models_path = Path(models_dir)

print(f"\nModels directory from .env: {models_dir}")
print(f"Resolved path: {models_path.resolve()}")
print(f"Directory exists: {models_path.exists()}")

# Check for all .gguf files
if models_path.exists():
    gguf_files = list(models_path.rglob("*.gguf"))
    print(f"\nFound {len(gguf_files)} .gguf files:")
    for f in gguf_files:
        size_gb = f.stat().st_size / (1024 ** 3)
        print(f"  - {f.name} ({size_gb:.2f} GB)")
        print(f"    Path: {f.resolve()}")
else:
    print(f"\n⚠️  Models directory not found!")
    print(f"   Create it: mkdir -p {models_path.resolve()}")

    # Check if models exist elsewhere
    all_gguf = list(Path(".").rglob("*.gguf"))
    if all_gguf:
        print(f"\n  But found .gguf files elsewhere:")
        for f in all_gguf:
            print(f"  - {f.resolve()}")

# Check specific model paths from .env
print(f"\nEnvironment variables:")
for key in ['GEMMA_MODEL_PATH', 'QWEN_MODEL_PATH', 'MODELS_DIR']:
    value = os.getenv(key, 'NOT SET')
    exists = Path(value).exists() if value != 'NOT SET' else False
    status = "✅" if exists else "❌"
    print(f"  {status} {key}={value}")

# Recommendations
print(f"\n{'=' * 60}")
print("Recommendations:")
print(f"{'=' * 60}")

if not models_path.exists():
    print(f"1. Create the models directory:")
    print(f"   mkdir -p {models_path.resolve()}")

gguf_files = list(Path(".").rglob("*.gguf"))
if not gguf_files:
    print(f"2. Download the models:")
    print(f"   - Gemma: https://huggingface.co/google/gemma-4-e4b-it")
    print(f"   - Qwen: https://huggingface.co/Qwen/Qwen2.5-3B-Instruct-GGUF")
    print(f"   Place them in: {models_path.resolve()}")
else:
    print(f"1. Models found but not in expected location")
    print(f"   Move them to: {models_path.resolve()}")
    print(f"   Or update .env with correct paths")