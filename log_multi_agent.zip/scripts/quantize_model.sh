# scripts/quantize_model.sh
#!/bin/bash
"""
Script to quantize GGUF models for better performance
"""

#!/bin/bash

set -e

echo "========================================="
echo "Model Quantization Script"
echo "========================================="
echo ""

# Check for llama.cpp tools
check_llama_tools() {
    if ! command -v llama-quantize &> /dev/null; then
        echo "❌ llama-quantize not found"
        echo "Please install llama.cpp first:"
        echo "  git clone https://github.com/ggerganov/llama.cpp"
        echo "  cd llama.cpp && make"
        echo "  export PATH=\$PATH:\$(pwd)"
        exit 1
    fi
}

# Function to quantize a model
quantize_model() {
    local input_model=$1
    local output_model=$2
    local quantization_type=${3:-"q4_K_M"}

    echo "Quantizing: $input_model"
    echo "  Output: $output_model"
    echo "  Type: $quantization_type"
    echo ""

    if [ -f "$output_model" ]; then
        echo "  Output already exists, skipping..."
        return
    fi

    llama-quantize "$input_model" "$output_model" "$quantization_type"

    if [ $? -eq 0 ]; then
        original_size=$(du -h "$input_model" | cut -f1)
        quantized_size=$(du -h "$output_model" | cut -f1)

        echo "  ✅ Quantization complete"
        echo "  Original size: $original_size"
        echo "  Quantized size: $quantized_size"
    else
        echo "  ❌ Quantization failed"
    fi

    echo ""
}

check_llama_tools

MODELS_DIR="./models/downloaded"

echo "Available quantization types:"
echo "  q4_0    - 4-bit quantization (smallest, fastest)"
echo "  q4_K_M  - 4-bit quantization (balanced, recommended)"
echo "  q5_K_M  - 5-bit quantization (better quality)"
echo "  q8_0    - 8-bit quantization (highest quality)"
echo ""

# Quantization configuration
QUANT_TYPE="q4_K_M"

echo "Using quantization type: $QUANT_TYPE"
echo ""
echo "========================================="

# Quantize Gemma model
GEMMA_INPUT="$MODELS_DIR/gemma-4-e4b-it.gguf"
GEMMA_OUTPUT="$MODELS_DIR/gemma-4-e4b-it-${QUANT_TYPE}.gguf"

if [ -f "$GEMMA_INPUT" ]; then
    echo "Quantizing Gemma model..."
    quantize_model "$GEMMA_INPUT" "$GEMMA_OUTPUT" "$QUANT_TYPE"
else
    echo "⚠️  Gemma model not found at: $GEMMA_INPUT"
fi

# Quantize Qwen model
QWEN_INPUT="$MODELS_DIR/qwen-2.5-3b-instruct.gguf"
QWEN_OUTPUT="$MODELS_DIR/qwen-2.5-3b-instruct-${QUANT_TYPE}.gguf"

if [ -f "$QWEN_INPUT" ]; then
    echo "Quantizing Qwen model..."
    quantize_model "$QWEN_INPUT" "$QWEN_OUTPUT" "$QUANT_TYPE"
else
    echo "⚠️  Qwen model not found at: $QWEN_INPUT"
fi

echo "========================================="
echo "Quantization Complete"
echo "========================================="
echo ""
echo "To use quantized models, update model_configs.py:"
echo "  ModelConfigs.update_config('gemma', model_file='gemma-4-e4b-it-${QUANT_TYPE}.gguf')"
echo "  ModelConfigs.update_config('qwen', model_file='qwen-2.5-3b-instruct-${QUANT_TYPE}.gguf')"