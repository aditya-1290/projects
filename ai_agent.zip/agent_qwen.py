# agent.py

from google.adk.agents.llm_agent import Agent
from local_qwen import generate_response

def qwen_tool(prompt: str) -> dict:
    """Generate response using local Qwen model"""
    response = generate_response(prompt)
    return {"status": "success", "response": response}


root_agent = Agent(
    model='local-qwen',  # just a label now
    name='root_agent',
    description="Local Qwen-powered assistant",
    instruction="Use qwen_tool to answer user queries.",
    tools=[qwen_tool],
)

print(qwen_tool("Explain FastAPI in simple terms"))
