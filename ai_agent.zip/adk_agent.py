"""
agent.py — Google ADK agent definition.

This file is the standard ADK entry point. ADK reads `root_agent` from here
when you run:  adk run .  or  adk web

The tools are imported from tools.py so they stay in sync with the HF runner.
"""

from google.adk.agents.llm_agent import LlmAgent
from tools import ALL_TOOLS

# ---------------------------------------------------------------------------
# ADK Agent
# NOTE: ADK does not natively support local HuggingFace models.
# It works with hosted model endpoints. Options:
#   - Use a Gemini model string (e.g. 'gemini-2.0-flash')  ← easiest
#   - Point to a local OpenAI-compatible server (e.g. vLLM or LM Studio)
#     by setting the model to the server URL
# ---------------------------------------------------------------------------
root_agent = LlmAgent(
    # ── Option 1: Gemini (default, requires GOOGLE_API_KEY in .env) ──────────
    model="gemini-2.0-flash",

    # ── Option 2: Local OpenAI-compatible server (e.g. vLLM serving Qwen) ───
    # model="http://localhost:8000/v1",   # uncomment and set your server URL

    name="global_assistant",
    description=(
        "A world-aware assistant providing real-time time, weather, "
        "currency, and timezone information for cities worldwide."
    ),
    instruction="""You are a knowledgeable and friendly global assistant. You help users with:

1. Current Time     — Use `get_current_time` for the time in a specific city.
2. Weather          — Use `get_weather` for real-time weather. Default to Celsius.
3. Currency         — Use `convert_currency` for live forex conversions.
4. Date & Timezone  — Use `get_date_info` for date/day/week info for a city.
5. World Clock      — Use `get_world_clock` to compare times across multiple cities at once.

Always use tools for live data — never guess or make up values.
Be concise, clear, and friendly in your responses.""",
    tools=ALL_TOOLS,
)