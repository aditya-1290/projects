"""
run_adk.py — Run the agent programmatically using Google ADK in Python.

This is an alternative to using the `adk run` / `adk web` CLI commands.
It lets you call the ADK agent directly from a Python script.

Usage:
    python run_adk.py

Requirements:
    pip install google-adk python-dotenv

Make sure your .env file contains:
    GOOGLE_API_KEY=your_gemini_api_key   ← needed for ADK's Gemini backend
    OPENWEATHER_KEY=...
    EXCHANGERATE_KEY=...
    TIMEZONEDB_KEY=...
"""

import asyncio
from dotenv import load_dotenv
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types as genai_types

# Import the ADK root_agent defined in agent.py
from adk_agent import root_agent

load_dotenv()

# ---------------------------------------------------------------------------
# ADK session + runner setup
# ---------------------------------------------------------------------------
SESSION_SERVICE = InMemorySessionService()
APP_NAME        = "global_assistant"
USER_ID         = "local_user"
SESSION_ID      = "session_001"

runner = Runner(
    agent=root_agent,
    app_name=APP_NAME,
    session_service=SESSION_SERVICE,
)


# ---------------------------------------------------------------------------
# Send a single message and get the agent's reply
# ---------------------------------------------------------------------------
async def ask(user_message: str) -> str:
    # Create session on first use
    try:
        SESSION_SERVICE.get_session(
            app_name=APP_NAME,
            user_id=USER_ID,
            session_id=SESSION_ID,
        )
    except Exception:
        SESSION_SERVICE.create_session(
            app_name=APP_NAME,
            user_id=USER_ID,
            session_id=SESSION_ID,
        )

    content = genai_types.Content(
        role="user",
        parts=[genai_types.Part(text=user_message)],
    )

    final_reply = ""
    async for event in runner.run_async(
        user_id=USER_ID,
        session_id=SESSION_ID,
        new_message=content,
    ):
        # The last text event from the agent is the final reply
        if event.is_final_response() and event.content and event.content.parts:
            final_reply = event.content.parts[0].text

    return final_reply


# ---------------------------------------------------------------------------
# Interactive CLI
# ---------------------------------------------------------------------------
async def main():
    print("=" * 50)
    print("  Global Assistant  (Google ADK mode)")
    print("=" * 50)
    print("Ask about time, weather, currency, or dates.")
    print("Type 'exit' to quit.\n")

    while True:
        try:
            user_input = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")
            break

        if not user_input:
            continue
        if user_input.lower() in ("exit", "quit"):
            print("Goodbye!")
            break

        reply = await ask(user_input)
        print(f"\nAgent: {reply}\n")


if __name__ == "__main__":
    asyncio.run(main())