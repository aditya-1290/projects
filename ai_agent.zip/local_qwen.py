from transformers import AutoModelForCausalLM, AutoTokenizer
import torch

MODEL_PATH = "D:/python_tasks/models/qwen2.5-7b-instruct"

print("Loading model...")

tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH)
model = AutoModelForCausalLM.from_pretrained(
    MODEL_PATH,
    torch_dtype=torch.float16,
    device_map="auto"
)

print("Model loaded ✅")


def generate_response(prompt: str) -> str:
    inputs = tokenizer(prompt, return_tensors="pt").to(model.device)

    outputs = model.generate(
        **inputs,
        max_new_tokens=200,
        temperature=0.7
    )

    return tokenizer.decode(outputs[0], skip_special_tokens=True)