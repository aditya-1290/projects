"""
run_hf.py — Run the agent locally using Qwen2.5-7B-Instruct via HuggingFace Transformers.

Usage:
    python run_hf.py

No ADK needed. The model runs entirely on your machine.
Make sure your .env file has the three API keys before running.
"""

import json
import inspect
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
from tools import TOOL_REGISTRY, ALL_TOOLS

# ---------------------------------------------------------------------------
# Model config — change MODEL_PATH to your local folder if already downloaded
# ---------------------------------------------------------------------------
MODEL_PATH = "D:/python_tasks/models/qwen2.5-7b-instruct"  # or e.g. "/models/Qwen2.5-7B-Instruct"

print(f"Loading model from: {MODEL_PATH}")
tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH)
model = AutoModelForCausalLM.from_pretrained(
    MODEL_PATH,
    # torch_dtype=torch.bfloat16,   # use torch.float32 if running CPU-only
    torch_dtype=torch.bfloat16,
    device_map="auto",             # auto picks GPU if available, else CPU
)
print("Model ready!\n")


# ---------------------------------------------------------------------------
# Auto-build OpenAI-style tool schemas from Python function signatures
# (Qwen2.5's chat template consumes these natively)
# ---------------------------------------------------------------------------
def build_tool_schema(fn) -> dict:
    sig  = inspect.signature(fn)
    doc  = inspect.getdoc(fn) or ""
    desc = doc.split("\n")[0]
    params, required = {}, []

    for name, param in sig.parameters.items():
        ann = param.annotation
        if ann in (int, float):  ptype = "number"
        elif ann == bool:        ptype = "boolean"
        elif ann == list:        ptype = "array"
        else:                    ptype = "string"

        param_desc = ""
        for line in doc.split("\n"):
            stripped = line.strip()
            if stripped.startswith(f"{name}:"):
                param_desc = stripped[len(name) + 1:].strip()

        params[name] = {"type": ptype, "description": param_desc}
        if param.default == inspect.Parameter.empty:
            required.append(name)

    return {
        "type": "function",
        "function": {
            "name": fn.__name__,
            "description": desc,
            "parameters": {
                "type": "object",
                "properties": params,
                "required": required,
            },
        },
    }


tool_schemas = [build_tool_schema(fn) for fn in ALL_TOOLS]

# ---------------------------------------------------------------------------
# System prompt
# ---------------------------------------------------------------------------
SYSTEM_PROMPT = """You are a knowledgeable and friendly global assistant. You help users with:

1. Current Time     — Use `get_current_time` for the time in a specific city.
2. Weather          — Use `get_weather` for real-time weather. Default to Celsius.
3. Currency         — Use `convert_currency` for live forex conversions.
4. Date & Timezone  — Use `get_date_info` for date/day/week info for a city.
5. World Clock      — Use `get_world_clock` to compare times across multiple cities.

Always use tools for live data — never guess. Be concise and friendly."""


# ---------------------------------------------------------------------------
# Agentic loop: prompt → model → tool call (if any) → final answer
# ---------------------------------------------------------------------------
def run_agent(user_message: str) -> str:
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user",   "content": user_message},
    ]

    while True:
        # Apply Qwen2.5 chat template — injects tool schemas into the prompt
        text = tokenizer.apply_chat_template(
            messages,
            tools=tool_schemas,
            tokenize=False,
            add_generation_prompt=True,
        )
        inputs = tokenizer([text], return_tensors="pt").to(model.device)

        with torch.no_grad():
            output_ids = model.generate(
                **inputs,
                max_new_tokens=512,
                do_sample=False,
            )

        # Decode only the newly generated tokens
        new_tokens    = output_ids[0][inputs["input_ids"].shape[-1]:]
        response_text = tokenizer.decode(new_tokens, skip_special_tokens=False)

        # ── Did the model request a tool? ───────────────────────────────────
        if "<tool_call>" in response_text:
            try:
                raw_call  = response_text.split("<tool_call>")[1].split("</tool_call>")[0].strip()
                tool_call = json.loads(raw_call)
                fn_name   = tool_call["name"]
                fn_args   = tool_call.get("arguments", tool_call.get("parameters", {}))

                print(f"  [Tool Call]   → {fn_name}({fn_args})")

                if fn_name in TOOL_REGISTRY:
                    tool_result = TOOL_REGISTRY[fn_name](**fn_args)
                else:
                    tool_result = {"status": "error", "message": f"Unknown tool: {fn_name}"}

                print(f"  [Tool Result] → {tool_result}\n")

                # Append tool exchange to conversation and loop for final reply
                messages.append({"role": "assistant", "content": response_text})
                messages.append({
                    "role": "tool",
                    "name": fn_name,
                    "content": json.dumps(tool_result),
                })
                continue  # ← model will now generate the final answer

            except (json.JSONDecodeError, KeyError, IndexError) as e:
                return f"[Tool parse error: {e}]\nRaw output:\n{response_text}"

        # ── No tool call — this is the final natural language answer ────────
        clean = (
            response_text
            .replace("<|im_end|>", "")
            .replace("<|im_start|>", "")
            .strip()
        )
        return clean


# ---------------------------------------------------------------------------
# Interactive CLI
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    print("=" * 50)
    print("  Qwen2.5-7B Local Agent  (HuggingFace mode)")
    print("=" * 50)
    print("Ask about time, weather, currency, or dates.")
    print("Type 'exit' to quit.\n")

    while True:
        try:
            user_input = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")
            break

        if not user_input:
            continue
        if user_input.lower() in ("exit", "quit"):
            print("Goodbye!")
            break

        answer = run_agent(user_input)
        print(f"\nAgent: {answer}\n")